"""Read-only machine counters; no process metrics, permissions or dependencies.

CPU is aggregate busy time between observations. RAM excludes memory the OS
reports as available (Linux/Windows) or free/inactive (Mach). Optional GPU
counters come only from an installed driver; unavailable values stay unknown.
"""

from __future__ import annotations

import csv
import ctypes
import io
import math
import os
import platform
import plistlib
import subprocess
import sys
import threading
from functools import lru_cache
from typing import Any

from .machine import MAX_GPU_COUNT, MAX_MEMORY_BYTES, _nvidia_smi_path, _read_text, sanitize_capability

MAX_GPU_SAMPLES = 16
GPU_PROBE_TIMEOUT_SECONDS = 0.75
MAX_GPU_OUTPUT_BYTES = 512 * 1024
_GPU_PROBE_LOCK = threading.Lock()


def _memory_pair(total: int, available: int) -> tuple[int, int] | None:
    if not 0 < total <= MAX_MEMORY_BYTES or not 0 <= available <= total:
        return None
    return total - available, total


def _linux_cpu() -> tuple[int, int] | None:
    fields = _read_text("/proc/stat", limit=4096).partition("\n")[0].split()
    if len(fields) < 5 or fields[0] != "cpu":
        return None
    try:
        ticks = [int(value) for value in fields[1:9]]
    except ValueError:
        return None
    if any(value < 0 for value in ticks):
        return None
    # guest/guest_nice are already included in user/nice. I/O wait is not busy.
    idle = ticks[3] + (ticks[4] if len(ticks) > 4 else 0)
    return sum(ticks) - idle, sum(ticks)


def _linux_memory() -> tuple[int, int] | None:
    values: dict[str, int] = {}
    for line in _read_text("/proc/meminfo", limit=16384).splitlines():
        name, _, raw = line.partition(":")
        fields = raw.split()
        if len(fields) == 2 and fields[1] == "kB" and fields[0].isdigit():
            values[name] = int(fields[0]) * 1024
    total = values.get("MemTotal", 0)
    available = values.get("MemAvailable")
    if available is None:
        # Older kernels: reclaimable caches are not application memory.
        if not {"MemFree", "Buffers", "Cached"} <= values.keys():
            return None
        available = (values["MemFree"] + values["Buffers"] + values["Cached"]
                     + values.get("SReclaimable", 0) - values.get("Shmem", 0))
    return _memory_pair(total, available)


class _FileTime(ctypes.Structure):
    _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]

    @property
    def ticks(self) -> int:
        return (int(self.high) << 32) | int(self.low)


class _MemoryStatus(ctypes.Structure):
    _fields_ = [("length", ctypes.c_uint32), ("load", ctypes.c_uint32)] + [
        (name, ctypes.c_uint64) for name in (
            "total_physical", "available_physical", "total_pagefile", "available_pagefile",
            "total_virtual", "available_virtual", "available_extended_virtual",
        )
    ]


@lru_cache(maxsize=1)
def _windows_api() -> Any:
    api = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    api.GetSystemTimes.argtypes = [ctypes.POINTER(_FileTime)] * 3
    api.GetSystemTimes.restype = ctypes.c_int
    api.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(_MemoryStatus)]
    api.GlobalMemoryStatusEx.restype = ctypes.c_int
    return api


def _windows_cpu() -> tuple[int, int] | None:
    # GetSystemTimes covers the calling processor group on machines above 64
    # logical CPUs. Do not misrepresent one group's load as the whole host.
    if (os.cpu_count() or 1) > 64:
        return None
    idle, kernel, user = _FileTime(), _FileTime(), _FileTime()
    if not _windows_api().GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
        return None
    total = kernel.ticks + user.ticks  # Windows kernel time includes idle.
    return (total - idle.ticks, total) if idle.ticks <= total else None


def _windows_memory() -> tuple[int, int] | None:
    status = _MemoryStatus()
    status.length = ctypes.sizeof(status)
    if not _windows_api().GlobalMemoryStatusEx(ctypes.byref(status)):
        return None
    return _memory_pair(status.total_physical, status.available_physical)


@lru_cache(maxsize=1)
def _darwin_api() -> Any:
    api = ctypes.CDLL("/usr/lib/libSystem.B.dylib")
    api.mach_host_self.argtypes = []
    api.mach_host_self.restype = ctypes.c_uint32
    api.mach_port_deallocate.argtypes = [ctypes.c_uint32, ctypes.c_uint32]
    api.mach_port_deallocate.restype = ctypes.c_int
    for name in ("host_statistics", "host_statistics64"):
        call = getattr(api, name)
        call.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
        call.restype = ctypes.c_int
    api.sysctlbyname.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
    api.sysctlbyname.restype = ctypes.c_int
    return api


def _darwin_host_info(flavor: int, *, wide: bool = False) -> list[int] | None:
    api = _darwin_api()
    host = api.mach_host_self()
    try:
        # Spare capacity tolerates newer Mach statistics revisions; only the
        # stable, documented uint32 prefix is interpreted below.
        data = (ctypes.c_uint32 * 256)()
        count = ctypes.c_uint32(len(data))
        call = api.host_statistics64 if wide else api.host_statistics
        if call(host, flavor, ctypes.byref(data), ctypes.byref(count)) or not 4 <= count.value <= len(data):
            return None
        return list(data[:count.value])
    finally:
        task = ctypes.c_uint32.in_dll(api, "mach_task_self_").value
        api.mach_port_deallocate(task, host)


def _darwin_cpu() -> tuple[int, int] | None:
    ticks = _darwin_host_info(3)  # HOST_CPU_LOAD_INFO: user, system, idle, nice
    if ticks is None:
        return None
    total = sum(ticks[:4])
    return total - ticks[2], total


def _darwin_memory() -> tuple[int, int] | None:
    api = _darwin_api()
    total = ctypes.c_uint64()
    size = ctypes.c_size_t(ctypes.sizeof(total))
    if api.sysctlbyname(b"hw.memsize", ctypes.byref(total), ctypes.byref(size), None, 0):
        return None
    pages = _darwin_host_info(4, wide=True)  # HOST_VM_INFO64: free, active, inactive, wired
    if pages is None:
        return None
    # Speculative pages are already included in free; do not subtract twice.
    available = (pages[0] + pages[2]) * os.sysconf("SC_PAGE_SIZE")
    return _memory_pair(total.value, available)


def _safe_counter(function: Any) -> Any:
    try:
        return function()
    except (OSError, ValueError, AttributeError, OverflowError):
        return None


def _gpu_output(argv: list[str]) -> bytes | None:
    """Bound both fixed driver command output and its lifetime, including hang."""
    if not _GPU_PROBE_LOCK.acquire(blocking=False):
        return None
    try:
        process = subprocess.Popen(
            argv, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except OSError:
        _GPU_PROBE_LOCK.release()
        return None
    output: list[bytes] = []
    assert process.stdout is not None

    def read() -> None:
        try:
            output.append(process.stdout.read(MAX_GPU_OUTPUT_BYTES + 1))
        except OSError:
            pass

    reader = threading.Thread(target=read, name="meshia-gpu-counters", daemon=True)
    reader.start()
    reader.join(GPU_PROBE_TIMEOUT_SECONDS)
    try:
        if reader.is_alive() or not output or len(output[0]) > MAX_GPU_OUTPUT_BYTES:
            return None
        if process.wait(timeout=0.1) != 0:
            return None
        return output[0]
    except subprocess.TimeoutExpired:
        return None
    finally:
        if process.poll() is None:
            process.kill()
        def reap() -> None:
            try:
                process.wait()
                reader.join()
                process.stdout.close()
            finally:
                _GPU_PROBE_LOCK.release()
        # An unresponsive kernel driver can delay even SIGKILL. Keep at most
        # one probe outstanding and let the control loop continue meanwhile.
        reaper = threading.Thread(target=reap, name="meshia-gpu-reaper", daemon=True)
        reaper.start()
        reaper.join(0.1)


def _number(value: Any, maximum: float, *, minimum: float = 0) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) and minimum <= result <= maximum else None


def _apple_gpu() -> list[dict[str, Any]]:
    raw = _gpu_output(["/usr/sbin/ioreg", "-r", "-c", "IOAccelerator", "-d", "1", "-a"])
    if raw is None:
        return []
    try:
        entries = plistlib.loads(raw)
    except (ValueError, plistlib.InvalidFileException):
        return []
    if not isinstance(entries, list):
        return []
    result = []
    for entry in entries[:MAX_GPU_SAMPLES]:
        stats = entry.get("PerformanceStatistics") if isinstance(entry, dict) else None
        if not isinstance(stats, dict):
            continue
        percent = _number(stats.get("Device Utilization %"), 100)
        if percent is not None:
            # Apple GPU allocations share physical system memory. Do not call
            # allocation counters dedicated VRAM or invent a separate total.
            result.append({"index": len(result), "utilization_percent": percent,
                           "memory_kind": "unified", "memory_total_bytes": None})
    return result


def _nvidia_gpu(path: str) -> list[dict[str, Any]]:
    raw = _gpu_output([path, "--query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw",
                       "--format=csv,noheader,nounits"])
    if raw is None:
        return []
    result = []
    seen: set[int] = set()
    for row in csv.reader(io.StringIO(raw.decode("utf-8", errors="replace"))):
        if len(row) != 7 or len(result) >= MAX_GPU_SAMPLES:
            continue
        index = _number(row[0], MAX_GPU_COUNT - 1)
        if index is None or not index.is_integer() or int(index) in seen:
            continue
        item: dict[str, Any] = {"index": int(index), "memory_kind": "dedicated"}
        for key, value, maximum, scale in (
            ("utilization_percent", row[2], 100, 1),
            ("memory_used_bytes", row[3], MAX_MEMORY_BYTES / 1048576, 1048576),
            ("memory_total_bytes", row[4], MAX_MEMORY_BYTES / 1048576, 1048576),
            ("temperature_celsius", row[5], 200, 1),
            ("power_watts", row[6], 100000, 1),
        ):
            number = _number(value, maximum)
            if number is not None:
                measured = int(number * scale) if scale != 1 else number
                # Some drivers use zero for an unsupported memory capacity.
                # The wire contract requires a known total to be positive.
                if key != "memory_total_bytes" or measured > 0:
                    item[key] = measured
        if item.get("memory_used_bytes", 0) > item.get("memory_total_bytes", MAX_MEMORY_BYTES):
            item.pop("memory_used_bytes", None)
            item.pop("memory_total_bytes", None)
        if len(item) == 2:  # Driver unavailable/N/A is not a measured zero.
            continue
        name = sanitize_capability(row[1], fallback="")
        if name:
            item["name"] = name
        seen.add(int(index))
        result.append(item)
    return result


class HostSampler:
    """One host sample per existing signed metrics interval; never per workspace."""

    def __init__(self) -> None:
        self._cpu, self._memory = {
            "linux": (_linux_cpu, _linux_memory),
            "darwin": (_darwin_cpu, _darwin_memory),
            "win32": (_windows_cpu, _windows_memory),
        }.get(sys.platform, (lambda: None, lambda: None))
        self._previous = _safe_counter(self._cpu)

    def sample(self) -> dict[str, Any]:
        current = _safe_counter(self._cpu)
        percent = None
        if current is not None and self._previous is not None:
            busy = current[0] - self._previous[0]
            total = current[1] - self._previous[1]
            if total > 0 and 0 <= busy <= total:
                percent = round(100 * busy / total, 3)
        self._previous = current
        memory = _safe_counter(self._memory)
        result: dict[str, Any] = {
            "host_cpu_percent": percent,
            "host_memory_used_bytes": memory[0] if memory is not None else None,
            "host_memory_total_bytes": memory[1] if memory is not None else None,
            "gpu": [],
        }
        if sys.platform == "darwin" and platform.machine().lower() in {"arm64", "aarch64"}:
            result["gpu"] = _safe_counter(_apple_gpu) or []
        elif sys.platform in {"linux", "win32"} and (path := _nvidia_smi_path()):
            result["gpu"] = _safe_counter(lambda: _nvidia_gpu(path)) or []
        return result
