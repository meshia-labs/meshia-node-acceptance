"""Windows workspace containment: the NTFS twin of :mod:`meshia_node.workspace`.

The POSIX boundary pins the workspace root as a file descriptor and walks
``openat(…, O_NOFOLLOW)`` so no symlink can redirect an operation. Windows has
no ``dir_fd`` support and no ``O_NOFOLLOW``, so this implementation keeps the
same three-stage discipline with NTFS-native mechanics:

1. **Lexically** — the identical :func:`~meshia_node.workspace.split_relative`
   (forward slashes only; backslashes, drive letters, ``..`` all refused);
2. **Structurally** — every component is ``lstat``'d and refused if it carries
   ``FILE_ATTRIBUTE_REPARSE_POINT`` (symlinks, junctions, and mount points are
   all reparse points — the union of what ``O_NOFOLLOW`` catches on Linux);
3. **Canonically** — the assembled target is ``realpath``'d and must stay
   under the ``realpath``'d root, compared case-folded because NTFS is
   case-insensitive.

Atomic publish uses a sibling temporary + ``os.replace`` (atomic on NTFS) and
flushes the file before publication. Directory flush is attempted wherever the
runtime exposes a directory handle; stock Windows Python has no portable
directory-fsync equivalent. Without an fd-pinned walk there is a small
check-to-use window that a *local same-user* process could race; the boundary's
threat model is remote payloads, and the machine owner's own account is already
trusted on every platform.

Host scope addresses drives through a POSIX-shaped alias — ``/c/Users/name`` →
``C:\\Users\\name`` — so the wire protocol stays identical across platforms.
The denylist covers the node's own state plus the Windows credential stores
(SAM/SYSTEM hives, DPAPI master keys, Credential Manager, ssh host keys).
"""

from __future__ import annotations

import errno
import hashlib
import os
import re
import stat as stat_module
import sys
import threading
import time
import uuid
from collections import deque
from contextlib import contextmanager, nullcontext
from dataclasses import replace
from pathlib import Path
from typing import Any, Callable, ContextManager, Iterable, Iterator, Mapping, Sequence, TypeVar

from .errors import (
    InvalidTask,
    RetentionCapacityUnavailable,
    UnsafePath,
    WorkspaceAdoptionRequired,
    WorkspaceClaimInvalid,
)
from .util import TAGGED_SHA256_RE, directory_entry_identity_stat, sha256_hex
from .workspace import (
    FileFingerprint,
    FingerprintReplaceResult,
    HashedRegularFile,
    RetiredRegularFile,
    RetainedStorageUsage,
    RetiredQuarantinePromotion,
    RetiredQuarantineStatus,
    WorkspaceRootClaim,
    WorkspaceRootClaimStatus,
    MAX_HOST_WRITE_BYTES,
    MAX_ANCHORED_RANGE_BYTES,
    MAX_LIST_ENTRIES,
    MAX_PATH_BYTES,
    MAX_READ_BYTES,
    MAX_STREAM_FILE_BYTES,
    MAX_WRITE_BYTES,
    MOUNT_STAGE_DIRECTORY,
    STREAM_IO_BYTES,
    STREAM_TEMP_MARKER_SUFFIX,
    STREAM_TEMP_SCAVENGE_MAX_ENTRIES,
    STREAM_TEMP_STALE_SECONDS,
    RETIRED_QUARANTINE_MAX_AGE_SECONDS,
    RETIRED_QUARANTINE_MAX_BYTES,
    RETIRED_QUARANTINE_MAX_ENTRIES,
    RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX,
    RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
    RETAINED_STORAGE_ACCOUNT_MATERIALIZED_ROW,
    WORKSPACE_METADATA_DIRECTORY,
    WORKSPACE_ROOT_CLAIM_NAME,
    WORKSPACE_ROOT_CLAIM_SCHEMA,
    _WORKSPACE_ROOT_CLAIM_MAX_BYTES,
    _STREAM_TEMP_MARKER_MAX_BYTES,
    _MESHIA_RESERVED_TEMP_SEGMENT_RE,
    _RetiredQuarantineRecord,
    _RETAINED_STORAGE_ACCOUNTS,
    _bounded_retire_conflict_name,
    _bounded_sorted_names,
    _copy_hash_open_regular,
    _copy_open_regular_identity,
    _allocated_file_bytes,
    _directory_namespace_time_ns,
    _hash_open_regular,
    _legacy_owned_temporary_for_target,
    _marker_stage_payload_is_bound,
    _marker_temporary_matches,
    _marker_staging_name,
    _owned_temporary_kind,
    _owned_temporary_name,
    _split_owned_relative,
    _parse_stream_temp_marker,
    _parse_retire_temp_marker,
    _parse_retired_quarantine_marker,
    _pid_is_live as _posix_pid_is_live,
    _regular_fingerprint,
    _same_regular_state_after_rename,
    _retire_target_from_marker_name,
    _stream_temp_marker_bytes,
    _retire_temp_marker_bytes,
    _retired_quarantine_marker_bytes,
    _serialize_retired_quarantine,
    _stream_chunks_to_descriptor,
    _validate_stream_contract,
    _validate_retired_quarantine_bounds,
    retired_quarantine_recovery_path,
    _canonical_workspace_root,
    _parse_workspace_root_claim,
    _validated_claim_arguments,
    _validate_workspace_root_claim_expectations,
    _directory_has_entries,
    _inspect_workspace_root_entries,
    _workspace_root_claim_bytes,
    _workspace_root_input_path,
    split_relative,
)

# Windows lets another process hold a transient handle on a file we just created —
# Defender's real-time scan and the Search Indexer both do it routinely — and then
# replace/unlink/rmdir fail with ERROR_ACCESS_DENIED or ERROR_SHARING_VIOLATION.
# The condition clears in milliseconds, so a bounded retry is the difference
# between "works on my box" and "flakes on the customer's box". Every Fabric
# hydrate and every write_file command lands on this path.
_SHARING_RETRIES = 6
_SHARING_BACKOFF_SECONDS = 0.02
_RETRYABLE_WINERRORS = frozenset({5, 32, 33})

_REPARSE_POINT = getattr(stat_module, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
_PROCESS_SYNCHRONIZE = 0x00100000
_WAIT_OBJECT_0 = 0x00000000
_WAIT_TIMEOUT = 0x00000102
_ERROR_INVALID_PARAMETER = 87
_HOST_DRIVE_RE = re.compile(r"^/([A-Za-z])(?:/(.*))?$", re.S)
# O_BINARY/O_NOINHERIT only exist on Windows; the getattr fallback keeps every
# method of this module exercisable by the cross-platform test suite.
_OPEN_FLAGS = getattr(os, "O_BINARY", 0) | getattr(os, "O_NOINHERIT", 0)
_WINDOWS_CHANGE_TIME_UNAVAILABLE = 0
_WINDOWS_FILE_BASIC_INFO_CLASS = 0
_WINDOWS_TICKS_BETWEEN_EPOCHS = 116_444_736_000_000_000
_WINDOWS_FILE_READ_DATA = 0x00000001
_WINDOWS_FILE_READ_ATTRIBUTES = 0x00000080
_WINDOWS_FILE_SHARE_READ = 0x00000001
_WINDOWS_FILE_SHARE_WRITE = 0x00000002
_WINDOWS_FILE_SHARE_DELETE = 0x00000004
_WINDOWS_OPEN_EXISTING = 3
_WINDOWS_FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000
_WINDOWS_FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
_DescriptorResult = TypeVar("_DescriptorResult")


def _open_windows_mount_stage(
    path: str, *, create: bool, delete_access: bool = False, writable: bool = True,
) -> int:
    """Keep a private stage readable across atomic publication and unlink.

    CRT os.open omits FILE_SHARE_DELETE. A long-lived mounted description
    must retain its inode while the namespace moves, not close/reopen around
    rename. CREATE_NEW keeps creation exclusive; recovery never truncates.
    Retained read aliases use the same sharing flags without write access.
    """
    import ctypes
    import msvcrt
    from ctypes import wintypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
        wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel32.CreateFileW.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    handle = kernel32.CreateFileW(
        path, 0x80000000 | (0x40000000 if writable else 0) | (0x00010000 if delete_access else 0),
        _WINDOWS_FILE_SHARE_READ | _WINDOWS_FILE_SHARE_WRITE | _WINDOWS_FILE_SHARE_DELETE,
        None, 1 if create else _WINDOWS_OPEN_EXISTING,
        _WINDOWS_FILE_FLAG_OPEN_REPARSE_POINT, None,
    )
    if handle in (None, -1, ctypes.c_void_p(-1).value):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        descriptor = msvcrt.open_osfhandle(handle, (os.O_RDWR if writable else os.O_RDONLY) | _OPEN_FLAGS)
    except BaseException:
        kernel32.CloseHandle(handle)
        raise
    try:
        os.set_inheritable(descriptor, False)
        info = os.fstat(descriptor)
        current = os.lstat(path)
        if (_is_reparse(info) or _is_reparse(current)
                or not stat_module.S_ISREG(info.st_mode) or info.st_nlink != 1
                or not _same_file_identity(info, current)):
            raise UnsafePath("The mounted-write stage is not a single-link regular file.")
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _windows_rename_stage_handle(
    descriptor: int, target: str, *, replace_existing: bool,
) -> None:
    """One atomic native replacement, retaining existing target descriptions.

    FileRenameInfoEx with POSIX semantics is the NTFS equivalent of POSIX
    replacement: old handles keep their old inode; new opens see the stage.
    A new destination uses no replacement flags so a concurrent creation is
    rejected atomically. There is no unlink, readonly bypass, or weaker fallback.
    https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information
    """
    import ctypes
    import msvcrt
    from ctypes import wintypes

    class RenameInfo(ctypes.Structure):
        # Fixed-width fields match WinSDK FILE_RENAME_INFO on both host ABIs;
        # c_wchar/c_ulong have different sizes on POSIX test hosts.
        _fields_ = [("flags", ctypes.c_uint32), ("root", ctypes.c_void_p),
                    ("name_bytes", ctypes.c_uint32), ("name", ctypes.c_uint16 * 1)]

    name = target.encode("utf-16-le")
    if not name or "\0" in target or len(name) > 65532:
        raise UnsafePath("The mounted-write destination name is invalid.")
    length = max(ctypes.sizeof(RenameInfo), RenameInfo.name.offset + len(name) + 2)
    buffer = ctypes.create_string_buffer(length)
    info = RenameInfo.from_buffer(buffer)
    info.flags = (0x1 | 0x2) if replace_existing else 0  # REPLACE_IF_EXISTS | POSIX_SEMANTICS
    info.name_bytes = len(name)
    ctypes.memmove(ctypes.addressof(buffer) + RenameInfo.name.offset, name, len(name))
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.SetFileInformationByHandle.argtypes = [wintypes.HANDLE, ctypes.c_int,
                                                   wintypes.LPVOID, wintypes.DWORD]
    kernel32.SetFileInformationByHandle.restype = wintypes.BOOL
    if not kernel32.SetFileInformationByHandle(
        msvcrt.get_osfhandle(descriptor), 22, buffer, length  # FileRenameInfoEx
    ):
        raise ctypes.WinError(ctypes.get_last_error())


def _publish_windows_mount_stage(
    source: str, target: str, expected_source: FileFingerprint,
    expected_target: FileFingerprint | None,
) -> None:
    # This is an additional short-lived rename handle, never a close/reopen of
    # the mount's original description. Its DELETE access cannot be kept on
    # ordinary stages because CRT readers do not themselves share DELETE.
    descriptor = _open_windows_mount_stage(source, create=False, delete_access=True)
    try:
        current = _regular_fingerprint_from_descriptor(
            descriptor, "The mounted-write stage must remain a single-link file."
        )
        if current != expected_source:
            raise InvalidTask("The mounted-write stage changed before publication.")
        if _path_fingerprint(target) != expected_target:
            raise InvalidTask("The mounted-write destination changed before publication.")
        _windows_rename_stage_handle(
            descriptor, target, replace_existing=expected_target is not None,
        )
    finally:
        os.close(descriptor)


def _set_windows_descriptor_times_ns(
    descriptor: int,
    atime_ns: int,
    mtime_ns: int,
    *,
    set_file_time=None,
    get_osfhandle=None,
) -> None:
    """Set times on the pinned writable handle, never reopen a pathname."""

    import ctypes
    from ctypes import wintypes

    class FileTime(ctypes.Structure):
        # DWORD is fixed-width on Windows; c_uint32 keeps Linux/macOS tests exact.
        _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]

    def file_time(nanoseconds: int) -> FileTime:
        ticks = nanoseconds // 100 + _WINDOWS_TICKS_BETWEEN_EPOCHS
        if not 0 < ticks < 2**64 - 1:
            raise OSError(errno.EINVAL, "The mounted timestamp is invalid.")
        return FileTime(ticks & 0xFFFFFFFF, ticks >> 32)

    accessed, modified = file_time(atime_ns), file_time(mtime_ns)
    if set_file_time is None or get_osfhandle is None:
        import msvcrt  # pragma: no cover - Windows handle transport

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.SetFileTime.argtypes = [
            wintypes.HANDLE, ctypes.POINTER(FileTime),
            ctypes.POINTER(FileTime), ctypes.POINTER(FileTime),
        ]
        kernel32.SetFileTime.restype = wintypes.BOOL
        set_file_time = kernel32.SetFileTime
        get_osfhandle = msvcrt.get_osfhandle
    if not set_file_time(
        get_osfhandle(descriptor), None, ctypes.byref(accessed), ctypes.byref(modified)
    ):
        get_last_error = getattr(ctypes, "get_last_error", lambda: 0)
        code = get_last_error()
        if hasattr(ctypes, "WinError"):
            raise ctypes.WinError(code)
        raise OSError(errno.EIO, f"The pinned timestamp update failed ({code}).")


def _uses_windows_change_time() -> bool:
    return sys.platform == "win32"


def _windows_change_time_ns_from_handle(
    handle: object,
    *,
    get_file_information_by_handle_ex=None,
) -> int | None:
    """Read NTFS ChangeTime from an already-open file or directory handle.

    Python's ``st_ctime`` is file creation time on Windows, so it cannot fence
    a same-size write whose mtime is restored. ``FileBasicInfo.ChangeTime`` is
    the kernel-maintained metadata-change clock we need. Failure is deliberately
    represented as unknown; callers must never turn that into reclaim authority.
    """

    import ctypes
    from ctypes import wintypes

    class FileBasicInformation(ctypes.Structure):
        _fields_ = [
            ("creation_time", ctypes.c_longlong),
            ("last_access_time", ctypes.c_longlong),
            ("last_write_time", ctypes.c_longlong),
            ("change_time", ctypes.c_longlong),
            ("file_attributes", wintypes.DWORD),
        ]

    if get_file_information_by_handle_ex is None:
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.GetFileInformationByHandleEx.argtypes = [
                wintypes.HANDLE,
                ctypes.c_int,
                wintypes.LPVOID,
                wintypes.DWORD,
            ]
            kernel32.GetFileInformationByHandleEx.restype = wintypes.BOOL
            get_file_information_by_handle_ex = (
                kernel32.GetFileInformationByHandleEx
            )
        except (AttributeError, OSError):
            return None

    assert get_file_information_by_handle_ex is not None
    try:
        information = FileBasicInformation()
        succeeded = get_file_information_by_handle_ex(
            handle,
            _WINDOWS_FILE_BASIC_INFO_CLASS,
            ctypes.byref(information),
            ctypes.sizeof(information),
        )
    except (OSError, OverflowError, ValueError):
        return None
    if not succeeded:
        return None
    change_ticks = int(information.change_time)
    if change_ticks <= _WINDOWS_TICKS_BETWEEN_EPOCHS:
        return None
    return (change_ticks - _WINDOWS_TICKS_BETWEEN_EPOCHS) * 100


def _windows_change_time_ns_from_descriptor(
    descriptor: int,
    *,
    get_file_information_by_handle_ex=None,
    get_osfhandle=None,
) -> int | None:
    """Read NTFS ChangeTime from an already-open regular-file descriptor."""

    if get_osfhandle is None:
        try:
            import msvcrt  # pragma: no cover - imported on Windows hosts

            get_osfhandle = msvcrt.get_osfhandle
        except ImportError:
            return None
    try:
        handle = get_osfhandle(descriptor)
    except (OSError, OverflowError, ValueError):
        return None
    return _windows_change_time_ns_from_handle(
        handle,
        get_file_information_by_handle_ex=get_file_information_by_handle_ex,
    )


@contextmanager
def _windows_path_change_time_witness(
    path: str,
    *,
    desired_access: int,
    share_mode: int,
    flags: int,
    create_file=None,
    get_file_information_by_handle_ex=None,
    close_handle=None,
) -> Iterator[Callable[[], int | None]]:
    """Pin one path and expose its native NTFS metadata-change clock."""

    import ctypes
    from ctypes import wintypes

    if (
        create_file is None
        or get_file_information_by_handle_ex is None
        or close_handle is None
    ):
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateFileW.argtypes = [
                wintypes.LPCWSTR,
                wintypes.DWORD,
                wintypes.DWORD,
                wintypes.LPVOID,
                wintypes.DWORD,
                wintypes.DWORD,
                wintypes.HANDLE,
            ]
            kernel32.CreateFileW.restype = wintypes.HANDLE
            kernel32.GetFileInformationByHandleEx.argtypes = [
                wintypes.HANDLE,
                ctypes.c_int,
                wintypes.LPVOID,
                wintypes.DWORD,
            ]
            kernel32.GetFileInformationByHandleEx.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL
            create_file = kernel32.CreateFileW
            get_file_information_by_handle_ex = (
                kernel32.GetFileInformationByHandleEx
            )
            close_handle = kernel32.CloseHandle
        except (AttributeError, OSError):
            yield lambda: None
            return

    assert create_file is not None
    assert get_file_information_by_handle_ex is not None
    assert close_handle is not None
    try:
        handle = create_file(
            os.path.abspath(path),
            desired_access,
            share_mode,
            None,
            _WINDOWS_OPEN_EXISTING,
            flags,
            None,
        )
    except (OSError, OverflowError, TypeError, ValueError):
        yield lambda: None
        return
    handle_value = getattr(handle, "value", handle)
    if handle_value in {-1, ctypes.c_void_p(-1).value, None}:
        yield lambda: None
        return
    try:
        yield lambda: _windows_change_time_ns_from_handle(
            handle,
            get_file_information_by_handle_ex=get_file_information_by_handle_ex,
        )
    finally:
        try:
            close_handle(handle)
        except (OSError, OverflowError, TypeError, ValueError):
            pass


def _windows_retirement_file_write_fence(
    path: str,
) -> ContextManager[Callable[[], int | None]]:
    """Pin the retiring file while refusing existing or newly opened writers.

    ``FILE_SHARE_DELETE`` permits our namespace rename. The handle must request
    file-data access: Windows explicitly exempts attribute-only handles from
    share-mode enforcement. With read-data access, deliberately omitting
    ``FILE_SHARE_WRITE`` makes ``CreateFileW`` fail while a writable handle is
    live and prevents a new write-capable handle until post-rename validation
    finishes. This closes the interval in which a same-size writer could
    restore mtime and have its ChangeTime mistaken for our rename.
    """

    return _windows_path_change_time_witness(
        path,
        desired_access=_WINDOWS_FILE_READ_DATA | _WINDOWS_FILE_READ_ATTRIBUTES,
        share_mode=_WINDOWS_FILE_SHARE_READ | _WINDOWS_FILE_SHARE_DELETE,
        flags=_WINDOWS_FILE_FLAG_OPEN_REPARSE_POINT,
    )


def _regular_fingerprint_from_descriptor(
    descriptor: int, message: str
) -> FileFingerprint:
    """Fingerprint an open file, using real Windows ChangeTime when available."""

    fingerprint = _regular_fingerprint(os.fstat(descriptor), message)
    if not _uses_windows_change_time():
        return fingerprint
    change_time_ns = _windows_change_time_ns_from_descriptor(descriptor)
    return replace(
        fingerprint,
        ctime_ns=(
            change_time_ns
            if change_time_ns is not None
            else _WINDOWS_CHANGE_TIME_UNAVAILABLE
        ),
    )


def _has_windows_change_time(fingerprint: FileFingerprint) -> bool:
    """Whether a Windows fingerprint can safely authorize byte reclamation."""

    return not _uses_windows_change_time() or fingerprint.ctime_ns > 0


def _copy_hash_open_regular_stable(
    descriptor: int,
    destination_fd: int | None,
    max_bytes: int,
    chunk_bytes: int,
    on_chunk: Callable[[bytes, int], None] | None,
    chunk_sizes: Sequence[int] | None = None,
) -> HashedRegularFile:
    """Run the shared streaming hash under a Windows ChangeTime fence."""

    before = _regular_fingerprint_from_descriptor(
        descriptor, "The source must be a single-link regular file."
    )
    hashed = _copy_hash_open_regular(
        descriptor,
        destination_fd,
        max_bytes,
        chunk_bytes,
        on_chunk,
        chunk_sizes,
    )
    after = _regular_fingerprint_from_descriptor(
        descriptor, "The source must remain a single-link regular file."
    )
    if (
        before != after
        or not _same_regular_state_after_rename(hashed.fingerprint, after)
    ):
        raise InvalidTask("The workspace file changed while it was being hashed.")
    return replace(hashed, fingerprint=after)


def _hash_open_regular_stable(
    descriptor: int, max_bytes: int
) -> HashedRegularFile:
    return _copy_hash_open_regular_stable(
        descriptor, None, max_bytes, STREAM_IO_BYTES, None
    )


def _copy_open_regular_identity_stable(
    descriptor: int,
    destination_fd: int,
    expected: FileFingerprint,
    max_bytes: int,
    chunk_bytes: int,
) -> FileFingerprint:
    """Run the shared identity copy while preserving Windows ChangeTime."""

    before = _regular_fingerprint_from_descriptor(
        descriptor, "The source must be a single-link regular file."
    )
    if before != expected:
        raise InvalidTask("The workspace file no longer has the recorded identity.")
    portable_before = _regular_fingerprint(
        os.fstat(descriptor), "The source must be a single-link regular file."
    )
    copied = _copy_open_regular_identity(
        descriptor,
        destination_fd,
        portable_before,
        max_bytes,
        chunk_bytes,
    )
    after = _regular_fingerprint_from_descriptor(
        descriptor, "The source must remain a single-link regular file."
    )
    if (
        before != after
        or not _same_regular_state_after_rename(copied, after)
    ):
        raise InvalidTask("The workspace file changed while it was being copied.")
    return after


def _win32_pid_is_live(
    pid: int,
    *,
    open_process=None,
    wait_for_single_object=None,
    close_handle=None,
    get_last_error=None,
) -> bool:
    """Probe a Windows process without sending it a signal.

    CPython implements ``os.kill(pid, 0)`` with ``TerminateProcess`` on
    Windows, so the POSIX liveness idiom is destructive there. A denied or
    otherwise ambiguous query deliberately means "live": startup recovery
    must preserve hidden bytes unless process death is proven.
    """

    if pid <= 0:
        return False
    if any(
        function is None
        for function in (
            open_process,
            wait_for_single_object,
            close_handle,
            get_last_error,
        )
    ):
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel32.WaitForSingleObject.restype = wintypes.DWORD
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL
        open_process = kernel32.OpenProcess
        wait_for_single_object = kernel32.WaitForSingleObject
        close_handle = kernel32.CloseHandle
        get_last_error = ctypes.get_last_error

    assert open_process is not None
    assert wait_for_single_object is not None
    assert close_handle is not None
    assert get_last_error is not None
    handle = open_process(_PROCESS_SYNCHRONIZE, False, pid)
    if not handle:
        return int(get_last_error()) != _ERROR_INVALID_PARAMETER
    try:
        result = int(wait_for_single_object(handle, 0))
        if result == _WAIT_OBJECT_0:
            return False
        # WAIT_TIMEOUT proves the process is live. WAIT_FAILED and unexpected
        # statuses are ambiguous, so fail closed and retain the owned temp.
        return True
    finally:
        close_handle(handle)


def _process_is_live(pid: int) -> bool:
    if sys.platform == "win32":
        return _win32_pid_is_live(pid)
    # The Windows boundary is deliberately exercised on POSIX in unit tests;
    # the ordinary signal-zero probe is safe only on that platform.
    return _posix_pid_is_live(pid)



def _is_retryable_sharing_error(error: OSError) -> bool:
    """Only retry NTFS access/share/lock contention, never permanent errors."""
    return getattr(error, "winerror", None) in _RETRYABLE_WINERRORS


def _retry_sharing_violation(operation, *arguments):
    """Run a filesystem mutation, retrying the transient Windows sharing errors.

    Returns whatever `operation` returns. FileNotFoundError is re-raised
    immediately — a missing file is an answer, not contention.
    """
    for attempt in range(_SHARING_RETRIES):
        try:
            return operation(*arguments)
        except FileNotFoundError:
            raise
        except OSError as error:
            if not _is_retryable_sharing_error(error) or attempt == _SHARING_RETRIES - 1:
                raise
            time.sleep(_SHARING_BACKOFF_SECONDS * (attempt + 1))
    raise AssertionError("unreachable")  # pragma: no cover


def _replace_stream_with_retry(
    temporary: str, target: str, expected_existing_sha256: str | None
) -> None:
    """Retry NTFS contention without carrying a stale optimistic CAS forward."""
    for attempt in range(_SHARING_RETRIES):
        if attempt and expected_existing_sha256 is not None:
            current = _hash_existing_target(target)
            if current is None or current.tagged_sha256 != expected_existing_sha256:
                raise InvalidTask(
                    "The destination changed while atomic replacement was retrying."
                )
        try:
            os.replace(temporary, target)
            return
        except FileNotFoundError:
            raise
        except OSError as error:
            if not _is_retryable_sharing_error(error) or attempt == _SHARING_RETRIES - 1:
                raise
            time.sleep(_SHARING_BACKOFF_SECONDS * (attempt + 1))
    raise AssertionError("unreachable")  # pragma: no cover


def _write_marker_stage_path(stage: str, data: bytes) -> None:
    descriptor = os.open(
        stage, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _OPEN_FLAGS, 0o600
    )
    try:
        if sys.platform != "win32":
            os.fchmod(descriptor, 0o600)
        view = memoryview(data)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise InvalidTask("Writing the retire owner marker made no progress.")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _write_private_marker_path(marker: str, data: bytes) -> None:
    """Publish a complete private marker without exposing partial JSON."""

    stage = os.path.join(
        os.path.dirname(marker), _marker_staging_name(os.path.basename(marker))
    )
    published = False
    try:
        _write_marker_stage_path(stage, data)
        _move_no_clobber(stage, marker)
        published = True
    except BaseException:
        if published:
            try:
                _retry_sharing_violation(os.unlink, marker)
            except OSError:
                pass
        try:
            _retry_sharing_violation(os.unlink, stage)
        except OSError:
            pass
        raise


def _replace_private_marker_path(marker: str, data: bytes) -> None:
    stage = os.path.join(
        os.path.dirname(marker), _marker_staging_name(os.path.basename(marker))
    )
    try:
        _write_marker_stage_path(stage, data)
        _retry_sharing_violation(os.replace, stage, marker)
    finally:
        try:
            _retry_sharing_violation(os.unlink, stage)
        except OSError:
            pass


def _move_no_clobber(source: str, destination: str) -> None:
    if sys.platform == "win32":
        _retry_sharing_violation(os.rename, source, destination)
        return
    os.link(source, destination, follow_symlinks=False)
    os.unlink(source)


def _is_reparse(info: os.stat_result) -> bool:
    return bool(getattr(info, "st_file_attributes", 0) & _REPARSE_POINT) or stat_module.S_ISLNK(
        info.st_mode
    )


def _normcase(path: str) -> str:
    return os.path.normcase(path)


def _same_file_identity(left: os.stat_result, right: os.stat_result) -> bool:
    return left.st_dev == right.st_dev and left.st_ino == right.st_ino


def _open_windows_workspace_root(
    root: Path | str, *, create: bool
) -> tuple[Path, str, os.stat_result, bool]:
    """Inspect the literal root before realpath can follow a reparse point."""

    path = _workspace_root_input_path(root)
    created = False
    try:
        before = os.lstat(path)
    except FileNotFoundError:
        if not create:
            raise
        try:
            path.mkdir(mode=0o700, parents=True)
            created = True
        except FileExistsError:
            pass
        try:
            before = os.lstat(path)
        except OSError as error:
            raise UnsafePath("The workspace root could not be created safely.") from error
    except OSError as error:
        raise UnsafePath("The workspace root could not be inspected safely.") from error
    if _is_reparse(before):
        raise UnsafePath("The workspace root must not be a reparse point.")
    if not stat_module.S_ISDIR(before.st_mode):
        raise UnsafePath("The workspace root must be a directory.")
    canonical_root = _canonical_workspace_root(path)
    try:
        current = os.lstat(path)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The workspace root changed while it was being canonicalized."
        ) from error
    if _is_reparse(current) or not _same_file_identity(before, current):
        raise WorkspaceClaimInvalid(
            "The workspace root changed while it was being canonicalized."
        )
    return path, canonical_root, current, created


def _assert_windows_workspace_root_current(
    path: Path, identity: os.stat_result
) -> None:
    try:
        current = os.lstat(path)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The claimed workspace root is no longer available."
        ) from error
    if (
        _is_reparse(current)
        or not stat_module.S_ISDIR(current.st_mode)
        or not _same_file_identity(current, identity)
    ):
        raise WorkspaceClaimInvalid(
            "The claimed workspace root was replaced after validation."
        )


def _verify_windows_private_path(path: Path, *, directory: bool, repair: bool) -> None:
    if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
        from .winsec import ensure_owner_restricted, is_owner_restricted

        try:
            if repair:
                ensure_owner_restricted(path)
            restricted = is_owner_restricted(path)
        except Exception as error:
            raise WorkspaceClaimInvalid(
                "The workspace ownership metadata DACL could not be verified."
            ) from error
        if not restricted:
            raise WorkspaceClaimInvalid(
                "The workspace ownership metadata must have an owner-only DACL."
            )
        return
    try:
        info = os.lstat(path)
        expected = 0o700 if directory else 0o600
        if stat_module.S_IMODE(info.st_mode) != expected and repair:
            os.chmod(path, expected, follow_symlinks=False)
            info = os.lstat(path)
        if stat_module.S_IMODE(info.st_mode) != expected:
            raise WorkspaceClaimInvalid(
                f"The workspace ownership metadata must use mode {expected:04o}."
            )
        if hasattr(os, "geteuid") and info.st_uid != os.geteuid():
            raise WorkspaceClaimInvalid(
                "The workspace ownership metadata has a different owner."
            )
    except WorkspaceClaimInvalid:
        raise
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The workspace ownership metadata privacy could not be verified."
        ) from error


def _open_windows_workspace_metadata(
    root_path: Path,
    *,
    create: bool,
    repair_privacy: bool,
) -> tuple[Path, bool]:
    metadata = root_path / WORKSPACE_METADATA_DIRECTORY
    created = False
    try:
        before = os.lstat(metadata)
    except FileNotFoundError:
        if not create:
            raise
        try:
            os.mkdir(metadata, 0o700)
            created = True
        except FileExistsError:
            pass
        try:
            before = os.lstat(metadata)
        except OSError as error:
            raise WorkspaceClaimInvalid(
                "The private workspace metadata directory could not be created safely."
            ) from error
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The private workspace metadata directory could not be inspected safely."
        ) from error
    if _is_reparse(before) or not stat_module.S_ISDIR(before.st_mode):
        raise WorkspaceClaimInvalid(
            "The private workspace metadata path must be a real directory."
        )
    _verify_windows_private_path(
        metadata, directory=True, repair=repair_privacy
    )
    try:
        current = os.lstat(metadata)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The private workspace metadata directory changed during validation."
        ) from error
    if _is_reparse(current) or not _same_file_identity(before, current):
        raise WorkspaceClaimInvalid(
            "The private workspace metadata directory changed during validation."
        )
    return metadata, created


def _read_windows_workspace_root_claim(
    metadata: Path, *, canonical_root: str
) -> WorkspaceRootClaim | None:
    marker = metadata / WORKSPACE_ROOT_CLAIM_NAME
    try:
        before = os.lstat(marker)
    except FileNotFoundError:
        return None
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker could not be inspected safely."
        ) from error
    if _is_reparse(before) or not stat_module.S_ISREG(before.st_mode):
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker must be a regular file."
        )
    try:
        descriptor = os.open(marker, os.O_RDONLY | _OPEN_FLAGS)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker could not be opened safely."
        ) from error
    try:
        opened = os.fstat(descriptor)
        if (
            _is_reparse(opened)
            or not _same_file_identity(before, opened)
            or not stat_module.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
        ):
            raise WorkspaceClaimInvalid(
                "The workspace ownership marker is not a private single-link file."
            )
        _verify_windows_private_path(marker, directory=False, repair=False)
        data = os.read(descriptor, _WORKSPACE_ROOT_CLAIM_MAX_BYTES + 1)
        current = os.lstat(marker)
        if _is_reparse(current) or not _same_file_identity(opened, current):
            raise WorkspaceClaimInvalid(
                "The workspace ownership marker changed while it was being read."
            )
    finally:
        os.close(descriptor)
    return _parse_workspace_root_claim(data, canonical_root=canonical_root)


def _fsync_directory_path_when_supported(path: Path) -> None:
    try:
        descriptor = os.open(path, os.O_RDONLY | _OPEN_FLAGS)
    except OSError:
        # Windows exposes no portable directory flush handle. The atomic file
        # replace remains durable to the strongest level available to Python.
        return
    try:
        os.fsync(descriptor)
    except OSError:
        if sys.platform != "win32":
            raise
    finally:
        os.close(descriptor)


def _write_windows_workspace_root_claim(
    root_path: Path,
    metadata: Path,
    claim: WorkspaceRootClaim,
    *,
    replace: bool,
) -> None:
    stage = metadata / f".workspace-root.{uuid.uuid4().hex}.tmp"
    marker = metadata / WORKSPACE_ROOT_CLAIM_NAME
    descriptor = os.open(
        stage,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | _OPEN_FLAGS,
        0o600,
    )
    published = False
    try:
        try:
            view = memoryview(_workspace_root_claim_bytes(claim))
            while view:
                written = os.write(descriptor, view)
                if written <= 0:
                    raise WorkspaceClaimInvalid(
                        "Writing the workspace ownership marker made no progress."
                    )
                view = view[written:]
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        _verify_windows_private_path(stage, directory=False, repair=sys.platform != "win32")
        if replace:
            _retry_sharing_violation(os.replace, stage, marker)
        elif sys.platform == "win32":  # pragma: no cover - Windows no-clobber rename
            _retry_sharing_violation(os.rename, stage, marker)
        else:
            os.link(stage, marker, follow_symlinks=False)
            os.unlink(stage)
        published = True
        _fsync_directory_path_when_supported(metadata)
        _fsync_directory_path_when_supported(root_path)
    finally:
        if not published:
            try:
                os.unlink(stage)
            except OSError:
                pass


def workspace_root_claim_status(
    root: Path | str,
    *,
    installation_id: str | None = None,
    workspace_id: str | None = None,
    host_id: str | None = None,
    session_id: str | None = None,
    require_bound: bool = False,
) -> WorkspaceRootClaimStatus:
    """Inspect Windows ownership without creating or repairing anything."""

    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    ownership_expected = bool(
        workspace_id is not None
        or host_id is not None
        or session_id is not None
        or require_bound
    )
    root_path = _workspace_root_input_path(root)
    display_root = str(root_path)
    try:
        root_path, canonical_root, identity, _ = _open_windows_workspace_root(
            root, create=False
        )
    except FileNotFoundError:
        if ownership_expected:
            return WorkspaceRootClaimStatus(
                state="invalid",
                canonical_root=display_root,
                reason="The claimed workspace root is missing.",
            )
        return WorkspaceRootClaimStatus(state="missing", canonical_root=display_root)
    except (UnsafePath, WorkspaceClaimInvalid, OSError) as error:
        return WorkspaceRootClaimStatus(
            state="invalid", canonical_root=display_root, reason=str(error)
        )
    try:
        metadata_name, has_public_entries = _inspect_workspace_root_entries(root_path)
        if metadata_name is None:
            if ownership_expected:
                return WorkspaceRootClaimStatus(
                    state="invalid",
                    canonical_root=canonical_root,
                    reason="The workspace ownership marker is missing.",
                )
            state = "adoption_required" if has_public_entries else "unclaimed_empty"
            return WorkspaceRootClaimStatus(state=state, canonical_root=canonical_root)
        metadata, _ = _open_windows_workspace_metadata(
            root_path, create=False, repair_privacy=False
        )
        claim = _read_windows_workspace_root_claim(
            metadata, canonical_root=canonical_root
        )
        if claim is None:
            if ownership_expected:
                raise WorkspaceClaimInvalid(
                    "The workspace ownership marker is missing."
                )
            if _directory_has_entries(metadata):
                raise WorkspaceClaimInvalid(
                    "The reserved metadata directory contains data but no ownership marker."
                )
            return WorkspaceRootClaimStatus(
                state=(
                    "adoption_required" if has_public_entries else "unclaimed_empty"
                ),
                canonical_root=canonical_root,
            )
        claim = _validate_workspace_root_claim_expectations(
            claim,
            installation_id=installation_id,
            workspace_id=workspace_id,
            host_id=host_id,
            session_id=session_id,
            require_bound=require_bound,
        )
        _assert_windows_workspace_root_current(root_path, identity)
        return WorkspaceRootClaimStatus(
            state="bound" if claim.is_bound else "provisional",
            canonical_root=canonical_root,
            claim=claim,
        )
    except (UnsafePath, WorkspaceClaimInvalid, OSError) as error:
        return WorkspaceRootClaimStatus(
            state="invalid", canonical_root=canonical_root, reason=str(error)
        )


def claim_workspace_root(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str | None = None,
    adopt: bool = False,
    adoption_pending: bool | None = None,
) -> WorkspaceRootClaim:
    """Create an exclusive provisional Windows workspace claim."""

    if not isinstance(adopt, bool):
        raise InvalidTask("adopt must be a boolean.")
    if adoption_pending is not None and not isinstance(adoption_pending, bool):
        raise InvalidTask("adoption_pending must be a boolean or None.")
    installation_id, requested_workspace_id, _, _ = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=None,
        session_id=None,
    )
    assert installation_id is not None
    claimed_workspace_id = requested_workspace_id or str(uuid.uuid4())
    root_path, canonical_root, identity, _ = _open_windows_workspace_root(
        root, create=True
    )
    metadata_name, has_public_entries = _inspect_workspace_root_entries(root_path)
    if metadata_name is not None:
        metadata, _ = _open_windows_workspace_metadata(
            root_path, create=False, repair_privacy=False
        )
        existing = _read_windows_workspace_root_claim(
            metadata, canonical_root=canonical_root
        )
        if existing is not None:
            existing = _validate_workspace_root_claim_expectations(
                existing,
                installation_id=installation_id,
                workspace_id=requested_workspace_id,
                host_id=None,
                session_id=None,
                require_bound=False,
            )
            if adoption_pending is not None and existing.adoption_pending != adoption_pending:
                raise WorkspaceClaimInvalid(
                    "adoption_pending does not match the existing ownership marker."
                )
            _assert_windows_workspace_root_current(root_path, identity)
            return existing
        if _directory_has_entries(metadata):
            raise WorkspaceClaimInvalid(
                "The reserved metadata directory contains data but no ownership marker."
            )
        if has_public_entries and not adopt:
            raise WorkspaceAdoptionRequired(
                "The non-empty workspace requires explicit adoption before Meshia can use it."
            )
        metadata, _ = _open_windows_workspace_metadata(
            root_path, create=False, repair_privacy=True
        )
    else:
        if has_public_entries and not adopt:
            raise WorkspaceAdoptionRequired(
                "The non-empty workspace requires explicit adoption before Meshia can use it."
            )
        metadata, _ = _open_windows_workspace_metadata(
            root_path, create=True, repair_privacy=True
        )
    pending = has_public_entries if adoption_pending is None else adoption_pending
    claim = WorkspaceRootClaim(
        schema=WORKSPACE_ROOT_CLAIM_SCHEMA,
        workspace_id=claimed_workspace_id,
        installation_id=installation_id,
        canonical_root=canonical_root,
        adoption_pending=pending,
    )
    try:
        _write_windows_workspace_root_claim(
            root_path, metadata, claim, replace=False
        )
    except FileExistsError as error:
        raise WorkspaceClaimInvalid(
            "Another process claimed the workspace concurrently; retry validation."
        ) from error
    stored = _read_windows_workspace_root_claim(
        metadata, canonical_root=canonical_root
    )
    if stored != claim:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker did not persist exactly."
        )
    _assert_windows_workspace_root_current(root_path, identity)
    return stored


def validate_workspace_root_claim(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    host_id: str | None = None,
    session_id: str | None = None,
    require_bound: bool = False,
) -> WorkspaceRootClaim:
    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    root_path, canonical_root, identity, _ = _open_windows_workspace_root(
        root, create=False
    )
    metadata_name, _ = _inspect_workspace_root_entries(root_path)
    if metadata_name is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    metadata, _ = _open_windows_workspace_metadata(
        root_path, create=False, repair_privacy=False
    )
    claim = _read_windows_workspace_root_claim(
        metadata, canonical_root=canonical_root
    )
    if claim is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    claim = _validate_workspace_root_claim_expectations(
        claim,
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
        require_bound=require_bound,
    )
    _assert_windows_workspace_root_current(root_path, identity)
    return claim


def _replace_windows_workspace_claim_state(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    host_id: str,
    session_id: str,
    complete_adoption: bool,
) -> WorkspaceRootClaim:
    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    assert None not in (installation_id, workspace_id, host_id, session_id)
    root_path, canonical_root, identity, _ = _open_windows_workspace_root(
        root, create=False
    )
    metadata_name, _ = _inspect_workspace_root_entries(root_path)
    if metadata_name is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    metadata, _ = _open_windows_workspace_metadata(
        root_path, create=False, repair_privacy=False
    )
    current = _read_windows_workspace_root_claim(
        metadata, canonical_root=canonical_root
    )
    if current is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    _validate_workspace_root_claim_expectations(
        current,
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=(host_id if current.is_bound or complete_adoption else None),
        session_id=(session_id if current.is_bound or complete_adoption else None),
        require_bound=complete_adoption,
    )
    if current.is_bound:
        if not complete_adoption or not current.adoption_pending:
            _assert_windows_workspace_root_current(root_path, identity)
            return current
        updated = WorkspaceRootClaim(
            schema=current.schema,
            workspace_id=current.workspace_id,
            installation_id=current.installation_id,
            canonical_root=current.canonical_root,
            adoption_pending=False,
            host_id=current.host_id,
            session_id=current.session_id,
        )
    else:
        if complete_adoption:
            raise WorkspaceClaimInvalid(
                "The workspace ownership claim has not been bound yet."
            )
        updated = WorkspaceRootClaim(
            schema=current.schema,
            workspace_id=current.workspace_id,
            installation_id=current.installation_id,
            canonical_root=current.canonical_root,
            adoption_pending=current.adoption_pending,
            host_id=host_id,
            session_id=session_id,
        )
    _write_windows_workspace_root_claim(root_path, metadata, updated, replace=True)
    stored = _read_windows_workspace_root_claim(
        metadata, canonical_root=canonical_root
    )
    if stored != updated:
        raise WorkspaceClaimInvalid(
            "The updated workspace ownership marker did not persist exactly."
        )
    _assert_windows_workspace_root_current(root_path, identity)
    return stored


def bind_workspace_root_claim(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    host_id: str,
    session_id: str,
) -> WorkspaceRootClaim:
    return _replace_windows_workspace_claim_state(
        root,
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
        complete_adoption=False,
    )


def rebind_workspace_root_claim(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    expected_host_id: str,
    expected_session_id: str,
    host_id: str,
    session_id: str,
) -> WorkspaceRootClaim:
    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    _, _, expected_host_id, expected_session_id = _validated_claim_arguments(
        installation_id=None,
        workspace_id=None,
        host_id=expected_host_id,
        session_id=expected_session_id,
    )
    assert None not in (
        installation_id,
        workspace_id,
        expected_host_id,
        expected_session_id,
        host_id,
        session_id,
    )
    root_path, canonical_root, identity, _ = _open_windows_workspace_root(
        root, create=False
    )
    metadata_name, _ = _inspect_workspace_root_entries(root_path)
    if metadata_name is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    metadata, _ = _open_windows_workspace_metadata(
        root_path, create=False, repair_privacy=False
    )
    current = _read_windows_workspace_root_claim(
        metadata, canonical_root=canonical_root
    )
    if current is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    _validate_workspace_root_claim_expectations(
        current,
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=None,
        session_id=None,
        require_bound=True,
    )
    if current.host_id == host_id and current.session_id == session_id:
        _assert_windows_workspace_root_current(root_path, identity)
        return current
    if (
        current.host_id != expected_host_id
        or current.session_id != expected_session_id
    ):
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker no longer has the expected prior binding."
        )
    rebound = WorkspaceRootClaim(
        schema=current.schema,
        workspace_id=current.workspace_id,
        installation_id=current.installation_id,
        canonical_root=current.canonical_root,
        adoption_pending=current.adoption_pending,
        host_id=host_id,
        session_id=session_id,
    )
    _write_windows_workspace_root_claim(root_path, metadata, rebound, replace=True)
    stored = _read_windows_workspace_root_claim(
        metadata, canonical_root=canonical_root
    )
    if stored != rebound:
        raise WorkspaceClaimInvalid(
            "The rebound workspace ownership marker did not persist exactly."
        )
    _assert_windows_workspace_root_current(root_path, identity)
    return stored


def complete_workspace_root_adoption(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    host_id: str,
    session_id: str,
) -> WorkspaceRootClaim:
    return _replace_windows_workspace_claim_state(
        root,
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
        complete_adoption=True,
    )


class WindowsWorkspaceBoundary:
    """A pinned directory that writes can never leave — NTFS edition."""

    def __init__(
        self,
        root: Path | str,
        *,
        recover_stream_temps: bool = True,
        retired_quarantine_max_bytes: int = RETIRED_QUARANTINE_MAX_BYTES,
        retired_quarantine_max_entries: int = RETIRED_QUARANTINE_MAX_ENTRIES,
        retired_quarantine_max_age_seconds: float = RETIRED_QUARANTINE_MAX_AGE_SECONDS,
    ) -> None:
        (
            self._retired_quarantine_max_bytes,
            self._retired_quarantine_max_entries,
            self._retired_quarantine_max_age_seconds,
        ) = _validate_retired_quarantine_bounds(
            retired_quarantine_max_bytes,
            retired_quarantine_max_entries,
            retired_quarantine_max_age_seconds,
        )
        try:
            self._root_path, canonical_root, self._root_identity, _ = (
                _open_windows_workspace_root(root, create=False)
            )
        except FileNotFoundError as error:
            path = _workspace_root_input_path(root)
            raise UnsafePath(f"The synchronized workspace {path} does not exist.") from error
        self.root = Path(canonical_root)
        self._stream_recovery_scan: Iterator[
            tuple[str, os.stat_result | None, bool]
        ] | None = None
        self._blocked_retire_targets: set[str] = set()
        self._ambiguous_retire_recovery = False
        self._stream_recovery_retry_required = False
        self._stream_recovery_quarantine_seen: dict[
            str, _RetiredQuarantineRecord
        ] = {}
        # Exact owner markers whose authenticated data inode was already
        # physically reclaimed. These paths are metadata-only cleanup work;
        # recovery may bypass the live owner-PID guard but must never unlink a
        # data path based on this in-memory evidence.
        self._retired_marker_cleanup: set[str] = set()
        self._retired_quarantine: dict[str, _RetiredQuarantineRecord] = {}
        self._retired_quarantine_lock = threading.RLock()
        self._retained_retirement_reservations: set[str] = set()
        self._retired_quarantine_visible_promotions: list[
            RetiredQuarantinePromotion
        ] = []
        self._retired_quarantine_promotion_overflow = False
        self._retired_quarantine_maintenance_error = False
        self.stream_recovery_pending = True
        if recover_stream_temps:
            self.recover_stale_stream_temps()

    # The POSIX boundary owns a root descriptor; here there is nothing to free,
    # but the context-manager shape is part of the public interface.
    def close(self) -> None:
        if self._stream_recovery_scan is not None:
            self._stream_recovery_scan.close()
            self._stream_recovery_scan = None
        return None

    def __enter__(self) -> "WindowsWorkspaceBoundary":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def recover_stale_stream_temps(
        self,
        *,
        min_age_seconds: float = STREAM_TEMP_STALE_SECONDS,
        max_entries: int = STREAM_TEMP_SCAVENGE_MAX_ENTRIES,
    ) -> tuple[int, bool]:
        """Boundedly recover only marker-owned staging remnants."""
        if min_age_seconds < 0 or max_entries < 1:
            raise InvalidTask("Invalid stream-temp recovery bounds.")
        cutoff_ns = time.time_ns() - int(min_age_seconds * 1_000_000_000)
        visited = 0
        removed = 0
        if self._stream_recovery_scan is None:
            self._stream_recovery_retry_required = False
            self._stream_recovery_quarantine_seen = {}
            self._stream_recovery_scan = self._iter_stream_recovery_entries()
        while visited < max_entries:
            try:
                path, info, is_directory = next(self._stream_recovery_scan)
            except StopIteration:
                self._stream_recovery_scan = None
                if self._stream_recovery_retry_required:
                    self._stream_recovery_quarantine_seen = {}
                    self.stream_recovery_pending = True
                    return removed, True
                self._retired_quarantine = dict(
                    self._stream_recovery_quarantine_seen
                )
                self._stream_recovery_quarantine_seen = {}
                self.stream_recovery_pending = False
                try:
                    self.maintain_retired_quarantine()
                except (InvalidTask, OSError, UnsafePath):
                    self._retired_quarantine_maintenance_error = True
                return removed, False
            visited += 1
            if not is_directory and path.endswith(STREAM_TEMP_MARKER_SUFFIX):
                marker_name = os.path.basename(path)
                temporary_name = marker_name[
                    : -len(STREAM_TEMP_MARKER_SUFFIX)
                ]
                if _owned_temporary_kind(temporary_name) == "write":
                    recovered = bool(
                        info is not None
                        and self._recover_marker_stage_path(path, info)
                    )
                    if recovered:
                        removed += 1
                    elif info is None:
                        self._stream_recovery_retry_required = True
                    continue
                outcome = (
                    self._recover_stream_marker_path(path, info, cutoff_ns)
                    if info is not None
                    else "retry"
                )
                if outcome == "removed":
                    removed += 1
                elif outcome == "blocked":
                    target = _retire_target_from_marker_name(marker_name)
                    if (
                        target is None
                        and _owned_temporary_kind(temporary_name) == "retire"
                    ):
                        target = _read_blocked_retire_target_path(path, info)
                        if target is None:
                            self._ambiguous_retire_recovery = True
                    if target is not None:
                        relative_parent = os.path.relpath(
                            os.path.dirname(path), str(self.root)
                        )
                        relative = (
                            target
                            if relative_parent == "."
                            else os.path.join(relative_parent, target)
                        )
                        self._blocked_retire_targets.add(
                            _normcase(relative.replace(os.sep, "/"))
                        )
        self.stream_recovery_pending = True
        return removed, True

    def _iter_stream_recovery_entries(
        self,
    ) -> Iterator[tuple[str, os.stat_result | None, bool]]:
        pending: list[tuple[str, ...]] = [()]
        discovered = 0
        while pending:
            parts = pending.pop()
            try:
                directory = self._directory(list(parts))
                entries = os.scandir(directory)
            except (OSError, UnsafePath):
                self._stream_recovery_retry_required = True
                continue
            try:
                try:
                    for entry in entries:
                        discovered += 1
                        if discovered > MAX_LIST_ENTRIES:
                            self._stream_recovery_retry_required = True
                            return
                        try:
                            info = directory_entry_identity_stat(entry)
                        except FileNotFoundError:
                            continue
                        except OSError:
                            self._stream_recovery_retry_required = True
                            yield entry.path, None, False
                            continue
                        is_directory = (
                            stat_module.S_ISDIR(info.st_mode)
                            and not _is_reparse(info)
                        )
                        yield entry.path, info, is_directory
                        if is_directory:
                            pending.append((*parts, entry.name))
                except OSError:
                    self._stream_recovery_retry_required = True
            finally:
                entries.close()

    def retire_recovery_blocked(self, path: str) -> bool:
        normalized = "/".join(split_relative(path))
        return (
            self.stream_recovery_pending
            or self._stream_recovery_retry_required
            or self._retired_quarantine_maintenance_error
            or self._ambiguous_retire_recovery
            or _normcase(normalized) in self._blocked_retire_targets
        )

    @staticmethod
    def _recover_marker_stage_path(
        stage_path: str, stage_info: os.stat_result
    ) -> bool:
        temporary = os.path.basename(stage_path)[
            : -len(STREAM_TEMP_MARKER_SUFFIX)
        ]
        if (
            _owned_temporary_kind(temporary) != "write"
            or _is_reparse(stage_info)
            or not stat_module.S_ISREG(stage_info.st_mode)
            or stage_info.st_nlink not in (1, 2)
        ):
            return False
        try:
            descriptor = os.open(stage_path, os.O_RDONLY | _OPEN_FLAGS)
        except OSError:
            return False
        try:
            data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
            opened = os.fstat(descriptor)
        except OSError:
            return False
        finally:
            os.close(descriptor)
        if (
            len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
            or _is_reparse(opened)
            or not stat_module.S_ISREG(opened.st_mode)
            or opened.st_dev != stage_info.st_dev
            or opened.st_ino != stage_info.st_ino
            or opened.st_nlink != stage_info.st_nlink
            or not _marker_stage_payload_is_bound(os.path.basename(stage_path), data)
        ):
            return False
        if stage_info.st_nlink == 2:
            token = temporary.rsplit("-", 1)[-1]
            published = False
            for kind in ("stream", "retire"):
                final_path = os.path.join(
                    os.path.dirname(stage_path),
                    f".__{kind}__.meshia-{token}{STREAM_TEMP_MARKER_SUFFIX}",
                )
                try:
                    final_info = os.lstat(final_path)
                except FileNotFoundError:
                    continue
                except OSError:
                    return False
                if (
                    final_info.st_dev == stage_info.st_dev
                    and final_info.st_ino == stage_info.st_ino
                ):
                    published = True
                    break
            if not published:
                return False
        try:
            _retry_sharing_violation(os.unlink, stage_path)
            return True
        except OSError:
            return False

    def _recover_stream_marker_path(
        self, marker_path: str, marker_info: os.stat_result, cutoff_ns: int
    ) -> str:
        marker_name = os.path.basename(marker_path)
        if marker_info.st_nlink == 2:
            stage_path = os.path.join(
                os.path.dirname(marker_path), _marker_staging_name(marker_name)
            )
            try:
                stage_info = os.lstat(stage_path)
            except OSError:
                return "blocked"
            if (
                stage_info.st_dev != marker_info.st_dev
                or stage_info.st_ino != marker_info.st_ino
                or not self._recover_marker_stage_path(stage_path, stage_info)
            ):
                return "blocked"
            try:
                marker_info = os.lstat(marker_path)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
        if (
            _is_reparse(marker_info)
            or not stat_module.S_ISREG(marker_info.st_mode)
            or marker_info.st_nlink != 1
        ):
            return "blocked"
        try:
            descriptor = os.open(marker_path, os.O_RDONLY | _OPEN_FLAGS)
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"
        try:
            try:
                data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
                opened = os.fstat(descriptor)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if (
                len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
                or _is_reparse(opened)
                or not stat_module.S_ISREG(opened.st_mode)
                or opened.st_nlink != 1
                or opened.st_dev != marker_info.st_dev
                or opened.st_ino != marker_info.st_ino
            ):
                return "blocked"
        finally:
            os.close(descriptor)
        quarantined = _parse_retired_quarantine_marker(marker_name, data)
        if quarantined is not None:
            return self._recover_quarantined_file_path(marker_path, quarantined)
        retired = _parse_retire_temp_marker(marker_name, data)
        if retired is not None:
            marker_cleanup = _normcase(marker_path) in self._retired_marker_cleanup
            if marker_cleanup:
                temporary = os.path.join(
                    os.path.dirname(marker_path), str(retired["temporary"])
                )
                try:
                    os.lstat(temporary)
                except FileNotFoundError:
                    try:
                        _retry_sharing_violation(os.unlink, marker_path)
                    except OSError:
                        self._stream_recovery_retry_required = True
                        return "retry"
                    self._retired_marker_cleanup.discard(_normcase(marker_path))
                    return "removed"
                except OSError:
                    self._stream_recovery_retry_required = True
                    return "retry"
                # Data unexpectedly exists, so the marker-only proof is no
                # longer applicable. Fall through to ordinary safe recovery.
                self._retired_marker_cleanup.discard(_normcase(marker_path))
            if _process_is_live(int(retired["owner_pid"])):
                return "blocked"
            return (
                "removed"
                if _recover_retired_marker_path(marker_path, retired)
                else "blocked"
            )
        marker = _parse_stream_temp_marker(marker_name, data)
        if marker is None or marker_info.st_mtime_ns > cutoff_ns:
            return "blocked"
        if _process_is_live(int(marker["owner_pid"])):
            return "blocked"
        parent = os.path.dirname(marker_path)
        temporary = os.path.join(parent, str(marker["temporary"]))
        target = os.path.join(parent, str(marker["target"]))
        try:
            temp_info = os.lstat(temporary)
        except FileNotFoundError:
            try:
                _retry_sharing_violation(os.unlink, marker_path)
                return "removed"
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"
        if (
            _is_reparse(temp_info)
            or not stat_module.S_ISREG(temp_info.st_mode)
            or temp_info.st_nlink not in (1, 2)
        ):
            return "blocked"
        if temp_info.st_nlink == 2:
            try:
                target_info = os.lstat(target)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if (
                _is_reparse(target_info)
                or not stat_module.S_ISREG(target_info.st_mode)
                or target_info.st_dev != temp_info.st_dev
                or target_info.st_ino != temp_info.st_ino
                or target_info.st_nlink != 2
            ):
                return "blocked"
        try:
            _retry_sharing_violation(os.unlink, temporary)
            _retry_sharing_violation(os.unlink, marker_path)
            return "removed"
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"

    def _recover_quarantined_file_path(
        self, marker_path: str, marker: dict[str, object]
    ) -> str:
        parent = os.path.dirname(marker_path)
        temporary = os.path.join(parent, str(marker["temporary"]))
        conflict = os.path.join(parent, str(marker["conflict"]))
        if str(marker["conflict"]) != _bounded_retire_conflict_name(
            str(marker["target"]), str(marker["temporary"])
        ):
            return "blocked"
        relative_parent = os.path.relpath(parent, str(self.root))
        prefix = "" if relative_parent == "." else relative_parent.replace(os.sep, "/") + "/"
        record = _RetiredQuarantineRecord(
            original_path=f"{prefix}{marker['target']}",
            temporary_path=f"{prefix}{marker['temporary']}",
            marker_path=f"{prefix}{os.path.basename(marker_path)}",
            conflict_path=f"{prefix}{marker['conflict']}",
            quarantined_at_ns=int(marker["quarantined_at_ns"]),
            recorded_size_bytes=int(marker["recorded_size_bytes"]),
            device_id=int(marker["device_id"]),
            file_id=int(marker["file_id"]),
            recorded_sha256=marker["recorded_sha256"],
            recorded_mtime_ns=marker["recorded_mtime_ns"],
            recorded_ctime_ns=marker["recorded_ctime_ns"],
            retain_unchanged=bool(marker["retain_unchanged"]),
            accounting_owner=str(marker["accounting_owner"]),
        )
        for existing in self._stream_recovery_quarantine_seen.values():
            if (
                existing.marker_path != record.marker_path
                and (existing.device_id, existing.file_id)
                == (record.device_id, record.file_id)
            ):
                return "blocked"
        try:
            temp_info = os.lstat(temporary)
        except FileNotFoundError:
            try:
                conflict_info = os.lstat(conflict)
            except FileNotFoundError:
                recovery_path = retired_quarantine_recovery_path(
                    record.conflict_path
                )
                try:
                    recovery = self.stat_fingerprint(recovery_path)
                except (InvalidTask, OSError, UnsafePath):
                    return "blocked"
                if recovery is None:
                    # The authenticated marker is the only remaining object.
                    # No data path is touched here: physical reclaim either
                    # completed earlier in this process or before startup.
                    try:
                        _retry_sharing_violation(os.unlink, marker_path)
                    except OSError:
                        self._stream_recovery_retry_required = True
                        return "retry"
                    self._retired_marker_cleanup.discard(_normcase(marker_path))
                    return "removed"
                if (
                    recovery.device_id != record.device_id
                    or recovery.file_id != record.file_id
                ):
                    return "blocked"
                self._stream_recovery_quarantine_seen[record.marker_path] = record
                self._queue_visible_quarantine_promotion(
                    record, visible_path=recovery_path
                )
                return "tracked"
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if (
                _is_reparse(conflict_info)
                or not stat_module.S_ISREG(conflict_info.st_mode)
                or conflict_info.st_nlink != 1
                or conflict_info.st_dev != record.device_id
                or conflict_info.st_ino != record.file_id
            ):
                return "blocked"
            self._stream_recovery_quarantine_seen[record.marker_path] = record
            self._queue_visible_quarantine_promotion(record)
            return "tracked"
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"
        if (
            _is_reparse(temp_info)
            or not stat_module.S_ISREG(temp_info.st_mode)
            or temp_info.st_dev != record.device_id
            or temp_info.st_ino != record.file_id
            or temp_info.st_nlink not in (1, 2)
        ):
            return "blocked"
        if temp_info.st_nlink == 2:
            try:
                conflict_info = os.lstat(conflict)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if (
                _is_reparse(conflict_info)
                or conflict_info.st_dev != temp_info.st_dev
                or conflict_info.st_ino != temp_info.st_ino
                or conflict_info.st_nlink != 2
            ):
                return "blocked"
            try:
                _retry_sharing_violation(os.unlink, temporary)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            self._stream_recovery_quarantine_seen[record.marker_path] = record
            self._queue_visible_quarantine_promotion(record)
            return "tracked"
        self._stream_recovery_quarantine_seen[record.marker_path] = record
        return "tracked"

    # ----------------------------------------------------------- path plumbing

    def _canonical_check(self, parts: list[str]) -> None:
        _assert_windows_workspace_root_current(self._root_path, self._root_identity)
        candidate = _normcase(os.path.realpath(os.path.join(str(self.root), *parts)))
        root = _normcase(str(self.root))
        if candidate != root and not candidate.startswith(root + os.sep):
            raise UnsafePath("The resolved path escapes the workspace root.")

    def _walk(self, parts: list[str], *, create: bool = False) -> str:
        """Verify every existing component is a reparse-free directory.

        Returns the absolute path assembled from validated components. With
        `create`, missing intermediate directories are created (0700-equivalent
        privacy comes from the parent's inherited DACL).
        """
        self._canonical_check(parts)
        current = str(self.root)
        for part in parts[:-1] if parts else []:
            current = os.path.join(current, part)
            try:
                info = os.lstat(current)
            except FileNotFoundError:
                if not create:
                    raise UnsafePath(
                        "A workspace path component is missing, not a directory, or is a "
                        "symbolic link."
                    ) from None
                try:
                    os.mkdir(current)
                except FileExistsError:
                    # A concurrent apply created it. Validate the winner just
                    # like every pre-existing component before proceeding.
                    try:
                        info = os.lstat(current)
                    except OSError as error:
                        raise UnsafePath(
                            "A workspace path component is missing, not a directory, or is a "
                            "symbolic link."
                        ) from error
                    if _is_reparse(info) or not stat_module.S_ISDIR(info.st_mode):
                        raise UnsafePath(
                            "A workspace path component is missing, not a directory, or is a "
                            "symbolic link."
                        )
                continue
            except OSError as error:
                raise UnsafePath(
                    "A workspace path component is missing, not a directory, or is a "
                    "symbolic link."
                ) from error
            if _is_reparse(info) or not stat_module.S_ISDIR(info.st_mode):
                raise UnsafePath(
                    "A workspace path component is missing, not a directory, or is a "
                    "symbolic link."
                )
        return os.path.join(current, parts[-1]) if parts else current

    def _directory(self, parts: list[str]) -> str:
        _assert_windows_workspace_root_current(self._root_path, self._root_identity)
        target = self._walk(parts) if parts else str(self.root)
        if parts:
            try:
                info = os.lstat(target)
            except OSError as error:
                raise UnsafePath(
                    "A workspace path component is missing, not a directory, or is a "
                    "symbolic link."
                ) from error
            if _is_reparse(info) or not stat_module.S_ISDIR(info.st_mode):
                raise UnsafePath(
                    "A workspace path component is missing, not a directory, or is a "
                    "symbolic link."
                )
        return target

    def _optional_file_target(self, parts: list[str]) -> str | None:
        """Resolve a file target, returning ``None`` when a parent vanished."""
        self._canonical_check(parts)
        current = str(self.root)
        for part in parts[:-1]:
            current = os.path.join(current, part)
            try:
                info = os.lstat(current)
            except FileNotFoundError:
                return None
            except OSError as error:
                raise UnsafePath(
                    "A workspace path component is not a directory or is a symbolic link."
                ) from error
            if _is_reparse(info) or not stat_module.S_ISDIR(info.st_mode):
                raise UnsafePath(
                    "A workspace path component is not a directory or is a symbolic link."
                )
        return os.path.join(current, parts[-1])

    # ------------------------------------------------------------------- reads

    def exists(self, path: str) -> bool:
        try:
            target = self._walk(split_relative(path))
        except UnsafePath:
            return False
        try:
            os.lstat(target)
            return True
        except OSError:
            return False

    def read_file(self, path: str, max_bytes: int = 262_144) -> tuple[bytes, bool]:
        if not 1 <= max_bytes <= MAX_READ_BYTES:
            raise InvalidTask("read_file max_bytes is outside the allowed range.")
        target = self._walk(split_relative(path))
        try:
            info = os.lstat(target)
        except OSError as error:
            raise UnsafePath("The source cannot be opened safely.") from error
        if _is_reparse(info) or not stat_module.S_ISREG(info.st_mode):
            raise UnsafePath("read_file accepts regular files only.")
        try:
            descriptor = os.open(target, os.O_RDONLY | _OPEN_FLAGS)
        except OSError as error:
            raise UnsafePath("The source cannot be opened safely.") from error
        try:
            data = b""
            while len(data) <= max_bytes:
                chunk = os.read(descriptor, max_bytes + 1 - len(data))
                if not chunk:
                    break
                data += chunk
            return data[:max_bytes], len(data) > max_bytes
        finally:
            os.close(descriptor)

    def stat_fingerprint(self, path: str) -> FileFingerprint | None:
        """Stat one reparse-free regular file without reading its contents."""
        target = self._optional_file_target(split_relative(path))
        if target is None:
            return None
        opened = _open_regular_descriptor(target, missing_ok=True, source=True)
        if opened is None:
            return None
        descriptor, fingerprint = opened
        try:
            if _path_fingerprint(target, source=True) != fingerprint:
                raise InvalidTask("The workspace file changed while it was being statted.")
            return fingerprint
        finally:
            os.close(descriptor)

    def read_regular_range(
        self,
        path: str,
        offset_bytes: int,
        size_bytes: int,
        expected: FileFingerprint,
    ) -> bytes:
        """Read one bounded block from an unchanged reparse-free file."""

        if (
            isinstance(offset_bytes, bool)
            or not isinstance(offset_bytes, int)
            or offset_bytes < 0
            or isinstance(size_bytes, bool)
            or not isinstance(size_bytes, int)
            or not 0 <= size_bytes <= MAX_ANCHORED_RANGE_BYTES
            or not isinstance(expected, FileFingerprint)
            or offset_bytes + size_bytes > expected.size_bytes
        ):
            raise InvalidTask("The anchored workspace range is invalid.")
        target = self._optional_file_target(split_relative(path))
        if target is None:
            raise InvalidTask("The anchored workspace source disappeared.")
        opened = _open_regular_descriptor(target, missing_ok=True, source=True)
        if opened is None:
            raise InvalidTask("The anchored workspace source disappeared.")
        descriptor, before = opened
        try:
            if before != expected:
                raise InvalidTask("The anchored workspace source changed.")
            os.lseek(descriptor, offset_bytes, os.SEEK_SET)
            data = bytearray()
            while len(data) < size_bytes:
                chunk = os.read(descriptor, size_bytes - len(data))
                if not chunk:
                    break
                data.extend(chunk)
            after = _regular_fingerprint_from_descriptor(
                descriptor,
                "The source must remain a single-link regular file.",
            )
            if (
                len(data) != size_bytes
                or after != expected
                or _path_fingerprint(target, source=True) != expected
            ):
                raise InvalidTask("The anchored workspace source changed during read.")
            return bytes(data)
        finally:
            os.close(descriptor)

    def with_regular_file_descriptor(
        self,
        path: str,
        operation: Callable[[int], _DescriptorResult],
        *,
        allow_mtime_change: bool = False,
        share_delete: bool = False,
    ) -> _DescriptorResult:
        """Confine metadata updates with the same identity fences as POSIX."""

        if not callable(operation):
            raise InvalidTask("The workspace descriptor operation must be callable.")
        target = self._optional_file_target(split_relative(path))
        if target is None:
            raise FileNotFoundError(path)
        opened = _open_regular_descriptor(
            target, missing_ok=True, source=True, writable=allow_mtime_change, share_delete=share_delete
        )
        if opened is None:
            raise FileNotFoundError(path)
        descriptor, before = opened
        try:
            if _path_fingerprint(target, source=True) != before:
                raise InvalidTask("The workspace file changed before its metadata operation.")
            result = operation(descriptor)
            after = _regular_fingerprint_from_descriptor(
                descriptor, "The source must remain a single-link regular file."
            )
            unchanged = (
                before.size_bytes == after.size_bytes
                and before.device_id == after.device_id
                and before.file_id == after.file_id
                and (allow_mtime_change or before.mtime_ns == after.mtime_ns)
            )
            if not unchanged or _path_fingerprint(target, source=True) != after:
                raise InvalidTask("The workspace file changed during its metadata operation.")
            return result
        finally:
            os.close(descriptor)

    def hash_regular_file(
        self, path: str, max_bytes: int = MAX_STREAM_FILE_BYTES
    ) -> HashedRegularFile | None:
        """Hash a stable regular file in bounded chunks, returning ``None`` if absent."""
        target = self._optional_file_target(split_relative(path))
        if target is None:
            return None
        opened = _open_regular_descriptor(target, missing_ok=True, source=True)
        if opened is None:
            return None
        descriptor, _ = opened
        try:
            hashed = _hash_open_regular_stable(descriptor, max_bytes)
            if _path_fingerprint(target, source=True) != hashed.fingerprint:
                raise InvalidTask("The workspace file changed while it was being hashed.")
            return hashed
        finally:
            os.close(descriptor)

    def copy_regular_file_to_descriptor(
        self,
        path: str,
        destination_fd: int,
        *,
        max_bytes: int = MAX_STREAM_FILE_BYTES,
        chunk_bytes: int = STREAM_IO_BYTES,
        on_chunk: Callable[[bytes, int], None] | None = None,
        chunk_sizes: Sequence[int] | None = None,
    ) -> HashedRegularFile | None:
        """Confined one-pass stage+hash into a caller-owned descriptor."""
        target = self._optional_file_target(split_relative(path))
        if target is None:
            return None
        opened = _open_regular_descriptor(target, missing_ok=True, source=True)
        if opened is None:
            return None
        source_fd, _ = opened
        try:
            hashed = _copy_hash_open_regular_stable(
                source_fd,
                destination_fd,
                max_bytes,
                chunk_bytes,
                on_chunk,
                chunk_sizes,
            )
            if _path_fingerprint(target, source=True) != hashed.fingerprint:
                raise InvalidTask("The workspace file changed while it was being copied.")
            return hashed
        finally:
            os.close(source_fd)

    def copy_regular_file_identity_to_descriptor(
        self,
        path: str,
        destination_fd: int,
        *,
        expected_fingerprint: FileFingerprint,
        max_bytes: int = MAX_STREAM_FILE_BYTES,
        chunk_bytes: int = STREAM_IO_BYTES,
    ) -> FileFingerprint | None:
        """Copy one exact reparse-free identity without hashing its contents."""

        target = self._optional_file_target(split_relative(path))
        if target is None:
            return None
        opened = _open_regular_descriptor(target, missing_ok=True, source=True)
        if opened is None:
            return None
        descriptor, before = opened
        try:
            if before != expected_fingerprint or _path_fingerprint(
                target, source=True
            ) != before:
                raise InvalidTask(
                    "The workspace file no longer has the recorded identity."
                )
            copied = _copy_open_regular_identity_stable(
                descriptor,
                destination_fd,
                expected_fingerprint,
                max_bytes,
                chunk_bytes,
            )
            if _path_fingerprint(target, source=True) != copied:
                raise InvalidTask(
                    "The workspace file changed while it was being copied."
                )
            return copied
        finally:
            os.close(descriptor)

    def sha256_if_present(self, path: str, max_bytes: int = 1_048_576) -> str | None:
        try:
            data, truncated = self.read_file(path, max_bytes)
        except (UnsafePath, OSError):
            return None
        if truncated:
            raise InvalidTask(f"Workspace file {path} exceeds the 1 MiB Fabric limit.")
        return sha256_hex(data)

    def snapshot(self, path: str, max_bytes: int = 1_048_576) -> bytes | None:
        try:
            data, truncated = self.read_file(path, max_bytes)
        except (UnsafePath, OSError):
            return None
        if truncated:
            raise InvalidTask(f"Workspace file {path} exceeds the 1 MiB Fabric limit.")
        return data

    def list(
        self, path: str = ".", max_entries: int = 1_000, recursive: bool = False
    ) -> tuple[list[str], bool]:
        if not 1 <= max_entries <= MAX_LIST_ENTRIES:
            raise InvalidTask("list max_entries is outside the allowed range.")
        parts = split_relative(path, allow_root=True)
        entries: list[str] = []
        truncated = False
        pending: deque[tuple[list[str], str]] = deque(((list(parts), ""),))
        while pending:
            branch, prefix = pending.popleft()
            directory = self._directory(branch)
            try:
                remaining = max_entries - len(entries)
                with os.scandir(directory) as directory_entries:
                    names, directory_truncated = _bounded_sorted_names(
                        (
                            item.name
                            for item in directory_entries
                            if item.name.casefold()
                            != WORKSPACE_METADATA_DIRECTORY.casefold()
                            and _MESHIA_RESERVED_TEMP_SEGMENT_RE.fullmatch(item.name)
                            is None
                        ),
                        remaining,
                    )
            except OSError as error:
                raise UnsafePath(
                    "A workspace path component is missing, not a directory, or is a "
                    "symbolic link."
                ) from error
            for name in names:
                relative = f"{prefix}{name}"
                try:
                    info = os.lstat(os.path.join(directory, name))
                    is_dir = stat_module.S_ISDIR(info.st_mode) and not _is_reparse(info)
                except OSError:
                    is_dir = False
                entries.append(f"{relative}/" if is_dir else relative)
                if recursive and is_dir:
                    pending.append((branch + [name], f"{relative}/"))
            if directory_truncated:
                truncated = True
            if truncated:
                break
        return entries, truncated

    def directory_exists(self, path: str = ".") -> bool:
        """Return whether a public path is a reparse-free directory."""

        try:
            self._directory(split_relative(path, allow_root=True))
        except (OSError, UnsafePath):
            return False
        return True

    # ---------------------------------------------------------- native mount

    def create_directory(self, path: str, *, create_parents: bool = False) -> None:
        """Create one reparse-free public directory for a WinFsp callback."""

        target = self._walk(split_relative(path), create=create_parents)
        try:
            os.mkdir(target)
        except FileExistsError as error:
            raise UnsafePath("The directory destination already exists.") from error
        try:
            info = os.lstat(target)
        except OSError as error:
            raise UnsafePath("The created workspace directory is unsafe.") from error
        if _is_reparse(info) or not stat_module.S_ISDIR(info.st_mode):
            raise UnsafePath("The created workspace directory is unsafe.")

    def remove_empty_directory(self, path: str) -> None:
        """Remove one exact empty directory without traversing a reparse point."""

        target = self._directory(split_relative(path))
        try:
            _retry_sharing_violation(os.rmdir, target)
        except FileNotFoundError as error:
            raise InvalidTask("The directory does not exist.") from error

    def prune_empty_directories(self, path: str) -> int:
        """Remove only empty, reparse-free descendants and their source root."""

        split_relative(path)
        if not self.directory_exists(path):
            return 0
        entries, truncated = self.list(
            path,
            max_entries=MAX_LIST_ENTRIES,
            recursive=True,
        )
        if truncated:
            raise InvalidTask("The empty-directory prune exceeded its bounded scan.")
        directories = [
            f"{path}/{entry[:-1]}" for entry in entries if entry.endswith("/")
        ]
        removed = 0
        for candidate in sorted(
            (*directories, path),
            key=lambda value: value.count("/"),
            reverse=True,
        ):
            try:
                self.remove_empty_directory(candidate)
            except InvalidTask:
                continue
            except OSError as error:
                if error.errno in (errno.ENOENT, errno.ENOTEMPTY, errno.EEXIST):
                    continue
                raise
            else:
                removed += 1
        return removed

    def mount_staging_directory(self) -> Path:
        """Return the private same-volume staging directory used by WinFsp writes."""

        _assert_windows_workspace_root_current(self._root_path, self._root_identity)
        metadata, _created = _open_windows_workspace_metadata(
            self._root_path, create=True, repair_privacy=True
        )
        staging = metadata / MOUNT_STAGE_DIRECTORY
        try:
            before = os.lstat(staging)
        except FileNotFoundError:
            try:
                os.mkdir(staging, 0o700)
            except FileExistsError:
                pass
            try:
                before = os.lstat(staging)
            except OSError as error:
                raise UnsafePath(
                    "The private mounted-write staging directory is unsafe."
                ) from error
        except OSError as error:
            raise UnsafePath(
                "The private mounted-write staging directory is unsafe."
            ) from error
        if _is_reparse(before) or not stat_module.S_ISDIR(before.st_mode):
            raise UnsafePath("The private mounted-write staging directory is unsafe.")
        _verify_windows_private_path(staging, directory=True, repair=True)
        current = os.lstat(staging)
        if _is_reparse(current) or not _same_file_identity(before, current):
            raise UnsafePath("The private mounted-write staging directory changed.")
        return staging

    def open_mount_stage_descriptor(self, path: Path | str, *, create: bool = False) -> int:
        candidate = Path(path)
        root = self.mount_staging_directory()
        if (_normcase(str(candidate.parent.resolve(strict=True))) != _normcase(str(root.resolve(strict=True)))
                or re.fullmatch(r"[0-9a-f]{32}\.data", candidate.name) is None):
            raise UnsafePath("The mounted-write stage is outside Meshia's private store.")
        if sys.platform == "win32":
            return _open_windows_mount_stage(str(candidate), create=create)
        # Cross-platform boundary tests exercise this Windows facade on POSIX.
        flags = os.O_RDWR | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
        if create:
            flags |= os.O_CREAT | os.O_EXCL
        return os.open(candidate, flags, 0o600)

    def publish_mount_stage(
        self,
        path: str,
        stage_path: Path | str,
        *,
        expected_stage_fingerprint: FileFingerprint,
        expected_existing_fingerprint: FileFingerprint | None,
    ) -> FileFingerprint:
        """Atomically adopt one sealed private stage into the NTFS namespace."""

        if not isinstance(expected_stage_fingerprint, FileFingerprint):
            raise InvalidTask("expected_stage_fingerprint must be a FileFingerprint.")
        if expected_existing_fingerprint is not None and not isinstance(
            expected_existing_fingerprint, FileFingerprint
        ):
            raise InvalidTask(
                "expected_existing_fingerprint must be a FileFingerprint or null."
            )
        candidate = Path(stage_path)
        staging_root = self.mount_staging_directory()
        try:
            candidate_parent = candidate.parent.resolve(strict=True)
            expected_parent = staging_root.resolve(strict=True)
        except OSError as error:
            raise UnsafePath("The mounted-write stage directory disappeared.") from error
        if (
            _normcase(str(candidate_parent)) != _normcase(str(expected_parent))
            or candidate.name in ("", ".", "..")
        ):
            raise UnsafePath("The mounted-write stage is outside Meshia's private store.")
        opened = _open_regular_descriptor(str(candidate), missing_ok=False, source=True)
        assert opened is not None
        descriptor, before = opened
        try:
            if before != expected_stage_fingerprint:
                raise InvalidTask("The mounted-write stage changed before publication.")
        finally:
            # Stock Windows opens commonly deny rename while this descriptor is
            # live. Revalidate the path immediately after close and before the
            # atomic replace; same-user local races are outside this boundary.
            os.close(descriptor)
        if _path_fingerprint(str(candidate), source=True) != before:
            raise InvalidTask("The mounted-write stage changed before publication.")

        target = self._walk(split_relative(path), create=True)
        if _path_fingerprint(target) != expected_existing_fingerprint:
            raise InvalidTask("The mounted-write destination changed before publication.")
        try:
            if sys.platform == "win32":
                _retry_sharing_violation(
                    _publish_windows_mount_stage, str(candidate), target,
                    before, expected_existing_fingerprint,
                )
            else:
                _retry_sharing_violation(os.replace, str(candidate), target)
        except OSError as error:
            raise UnsafePath("The mounted-write stage could not be published.") from error
        published = _path_fingerprint(target)
        if published is None or not _same_regular_state_after_rename(before, published):
            raise InvalidTask("The mounted write changed during publication.")
        return published

    def rename_file_by_fingerprint(
        self,
        source: str,
        destination: str,
        *,
        expected_fingerprint: FileFingerprint,
        expected_destination_fingerprint: FileFingerprint | None = None,
        expected_destination_sha256: str | None = None,
        create_parents: bool = False,
    ) -> FileFingerprint:
        """Rename an exact local inode with an optional destination CAS."""

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        if expected_destination_fingerprint is not None and not isinstance(
            expected_destination_fingerprint, FileFingerprint
        ):
            raise InvalidTask(
                "expected_destination_fingerprint must be a FileFingerprint or null."
            )
        if (expected_destination_fingerprint is None) != (
            expected_destination_sha256 is None
        ) or (
            expected_destination_sha256 is not None
            and TAGGED_SHA256_RE.fullmatch(expected_destination_sha256) is None
        ):
            raise InvalidTask(
                "A destination fingerprint requires its tagged SHA-256 digest."
            )
        source_parts = split_relative(source)
        destination_parts = split_relative(destination)
        source_target = self._optional_file_target(source_parts)
        if source_target is None:
            raise InvalidTask("The rename source does not exist.")
        opened = _open_regular_descriptor(source_target, missing_ok=False, source=True)
        assert opened is not None
        descriptor, before = opened
        try:
            if before != expected_fingerprint:
                raise InvalidTask("The rename source changed before commit.")
        finally:
            os.close(descriptor)
        if _path_fingerprint(source_target, source=True) != before:
            raise InvalidTask("The rename source changed before commit.")
        if source_parts == destination_parts:
            return before

        destination_target = self._walk(destination_parts, create=create_parents)
        destination_fingerprint = _path_fingerprint(destination_target)
        same_file = destination_fingerprint == before
        same_parent = _normcase(os.path.dirname(source_target)) == _normcase(
            os.path.dirname(destination_target)
        )
        if (
            not (same_file and same_parent)
            and destination_fingerprint != expected_destination_fingerprint
        ):
            raise UnsafePath("The rename destination changed before commit.")
        if same_file:
            temporary = os.path.join(
                os.path.dirname(source_target), _owned_temporary_name("rename")
            )
            moved = False
            try:
                _retry_sharing_violation(os.rename, source_target, temporary)
                moved = True
                _retry_sharing_violation(os.rename, temporary, destination_target)
                moved = False
            finally:
                if moved:
                    try:
                        _retry_sharing_violation(os.rename, temporary, source_target)
                    except OSError:
                        pass
        else:
            destination_retired: tuple[str, str, HashedRegularFile] | None = None
            destination_retired_active = False
            source_retired: tuple[str, str, FileFingerprint] | None = None
            published = False
            try:
                if expected_destination_fingerprint is not None:
                    opened_destination = _open_regular_descriptor(
                        destination_target, missing_ok=False
                    )
                    assert opened_destination is not None
                    destination_descriptor, opened_destination_fingerprint = (
                        opened_destination
                    )
                    try:
                        if (
                            opened_destination_fingerprint
                            != expected_destination_fingerprint
                            or _path_fingerprint(destination_target)
                            != opened_destination_fingerprint
                        ):
                            raise UnsafePath(
                                "The rename destination changed before commit."
                            )
                    finally:
                        os.close(destination_descriptor)
                    retired_target = os.path.join(
                        os.path.dirname(destination_target),
                        _owned_temporary_name("retire"),
                    )
                    retired_marker = retired_target + STREAM_TEMP_MARKER_SUFFIX
                    assert expected_destination_sha256 is not None
                    destination_retired = (
                        retired_target,
                        retired_marker,
                        HashedRegularFile(
                            expected_destination_fingerprint,
                            expected_destination_sha256.removeprefix("sha256:"),
                        ),
                    )
                    _write_private_marker_path(
                        retired_marker,
                        _retire_temp_marker_bytes(
                            os.path.basename(retired_target),
                            os.path.basename(destination_target),
                        ),
                    )
                    destination_retired_active = True
                    _retry_sharing_violation(
                        os.rename, destination_target, retired_target
                    )
                    retired_fingerprint = _path_fingerprint(
                        retired_target, source=True
                    )
                    if retired_fingerprint is None or not (
                        _same_regular_state_after_rename(
                            expected_destination_fingerprint,
                            retired_fingerprint,
                        )
                    ):
                        recovered = _recover_retired_marker_path(
                            retired_marker,
                            {
                                "temporary": os.path.basename(retired_target),
                                "target": os.path.basename(destination_target),
                                "owner_pid": os.getpid(),
                            },
                        )
                        destination_retired_active = not recovered
                        raise UnsafePath(
                            "The rename destination changed immediately before commit."
                        )
                    destination_retired = (
                        retired_target,
                        retired_marker,
                        HashedRegularFile(
                            retired_fingerprint,
                            expected_destination_sha256.removeprefix("sha256:"),
                        ),
                    )

                source_retired_target = os.path.join(
                    os.path.dirname(source_target), _owned_temporary_name("retire")
                )
                source_retired_marker = (
                    source_retired_target + STREAM_TEMP_MARKER_SUFFIX
                )
                _write_private_marker_path(
                    source_retired_marker,
                    _retire_temp_marker_bytes(
                        os.path.basename(source_retired_target),
                        os.path.basename(source_target),
                    ),
                )
                source_retired = (
                    source_retired_target,
                    source_retired_marker,
                    before,
                )
                _retry_sharing_violation(
                    os.rename, source_target, source_retired_target
                )
                source_retired_fingerprint = _path_fingerprint(
                    source_retired_target, source=True
                )
                if source_retired_fingerprint is None:
                    raise InvalidTask("The rename source disappeared during commit.")
                source_retired = (
                    source_retired_target,
                    source_retired_marker,
                    source_retired_fingerprint,
                )
                if not _same_regular_state_after_rename(
                    before, source_retired_fingerprint
                ):
                    raise InvalidTask(
                        "The rename source changed immediately before commit."
                    )

                _move_no_clobber(source_retired_target, destination_target)
                published = True
                try:
                    _retry_sharing_violation(os.unlink, source_retired_marker)
                    source_retired = None
                except OSError:
                    # Startup recovery removes a marker whose temporary is gone.
                    pass
                after = _path_fingerprint(destination_target)
                if after is None or not _same_regular_state_after_rename(
                    source_retired_fingerprint, after
                ):
                    raise InvalidTask("The workspace file changed during rename.")

                if destination_retired is not None:
                    current_retired_fingerprint = _path_fingerprint(
                        destination_retired[0], source=True
                    )
                    if current_retired_fingerprint is None:
                        raise InvalidTask(
                            "The retired rename destination disappeared before commit."
                        )
                    if (
                        current_retired_fingerprint
                        != destination_retired[2].fingerprint
                    ):
                        self._restore_retired_file_target(
                            destination_target, destination_retired
                        )
                    else:
                        self._quarantine_retired_file_target(
                            destination_target,
                            destination_retired,
                            destination,
                            HashedRegularFile(
                                current_retired_fingerprint,
                                destination_retired[2].sha256,
                            ),
                        )
                    destination_retired_active = False
                return after
            finally:
                if source_retired is not None:
                    recovered = _recover_retired_marker_path(
                        source_retired[1],
                        {
                            "temporary": os.path.basename(source_retired[0]),
                            "target": os.path.basename(source_target),
                            "owner_pid": os.getpid(),
                        },
                    )
                    if published and not recovered:
                        self._stream_recovery_retry_required = True
                if destination_retired_active and destination_retired is not None:
                    recovered = _recover_retired_marker_path(
                        destination_retired[1],
                        {
                            "temporary": os.path.basename(
                                destination_retired[0]
                            ),
                            "target": os.path.basename(destination_target),
                            "owner_pid": os.getpid(),
                        },
                    )
                    if not recovered:
                        self._stream_recovery_retry_required = True
        after = _path_fingerprint(destination_target)
        if after is None or not _same_regular_state_after_rename(before, after):
            raise InvalidTask("The workspace file changed during rename.")
        return after

    def remove_file_by_fingerprint(
        self,
        path: str,
        *,
        expected_fingerprint: FileFingerprint,
        tracked_handles_closed: bool = False,
    ) -> bool | None:
        """Remove one exact local inode without reading its large contents.

        ``True`` means reclaimed, ``False`` means absent, and ``None`` means
        ChangeTime or Windows sharing state could not prove a safe unlink.
        """

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        if not isinstance(tracked_handles_closed, bool):
            raise InvalidTask("tracked_handles_closed must be a boolean.")
        target = self._optional_file_target(split_relative(path))
        if target is None:
            return False
        opened = _open_regular_descriptor(target, missing_ok=True)
        if opened is None:
            return False
        descriptor, before = opened
        try:
            if before != expected_fingerprint:
                raise InvalidTask("The file changed before removal.")
        finally:
            os.close(descriptor)
        if _path_fingerprint(target) != before:
            raise InvalidTask("The file changed before removal.")
        if not _has_windows_change_time(before):
            # This API is remote/cancellation cleanup authority. Portable
            # Windows ctime is creation time and cannot prove a quiet inode.
            return None
        try:
            _retry_sharing_violation(os.unlink, target)
        except FileNotFoundError:
            return False
        except OSError as error:
            if _is_retryable_sharing_error(error):
                return None
            raise
        return True

    def native_unlink_file_by_fingerprint(
        self, path: str, *, expected_fingerprint: FileFingerprint
    ) -> bool:
        """Apply an explicit user unlink using native Windows semantics.

        Unlike remote cleanup, a user-issued unlink does not claim that the
        inode stayed quiet for later reclamation. It removes the currently
        matched name directly, even when ChangeTime is unavailable.
        """

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        target = self._optional_file_target(split_relative(path))
        if target is None:
            return False
        opened = _open_regular_descriptor(target, missing_ok=True)
        if opened is None:
            return False
        descriptor, before = opened
        try:
            if before != expected_fingerprint:
                raise InvalidTask("The file changed before removal.")
        finally:
            os.close(descriptor)
        if _path_fingerprint(target) != before:
            raise InvalidTask("The file changed before removal.")
        try:
            _retry_sharing_violation(os.unlink, target)
        except FileNotFoundError:
            return False
        return True

    def has_pending_fingerprint_removal(
        self, path: str, *, expected_fingerprint: FileFingerprint
    ) -> bool:
        """Windows currently completes exact removal without POSIX retire evidence."""

        split_relative(path)
        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        return False

    # ------------------------------------------------------------------ writes

    def write_file(
        self,
        path: str,
        data: bytes,
        *,
        create_parents: bool = False,
        overwrite: bool = True,
        expected_sha256: str | None = None,
    ) -> None:
        if len(data) > MAX_WRITE_BYTES:
            raise InvalidTask("write_file exceeds the 8 MiB limit.")
        if expected_sha256 is not None and not TAGGED_SHA256_RE.match(expected_sha256):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        tagged = f"sha256:{hashlib.sha256(data).hexdigest()}"
        chunks: tuple[bytes, ...] = (data,) if data else ()
        self.write_stream(
            path,
            chunks,
            expected_size=len(data),
            expected_sha256=tagged,
            create_parents=create_parents,
            overwrite=overwrite,
            expected_existing_sha256=expected_sha256,
        )

    def write_stream(
        self,
        path: str,
        chunks: Iterable[bytes],
        *,
        expected_size: int,
        expected_sha256: str | None = None,
        expected_file_digest: str | None = None,
        block_descriptor: Mapping[str, Any] | None = None,
        tree_source: Any | None = None,
        create_parents: bool = False,
        overwrite: bool = True,
        expected_existing_sha256: str | None = None,
        expected_existing_fingerprint: FileFingerprint | None = None,
        retain_replaced: bool = False,
        require_retention_capacity: bool = False,
    ) -> RetiredRegularFile | None:
        """Verify and atomically publish a stream with an optional optimistic CAS."""
        _validate_stream_contract(
            expected_size, expected_sha256, expected_existing_sha256,
            expected_file_digest=expected_file_digest, block_descriptor=block_descriptor,
        )
        if not isinstance(retain_replaced, bool):
            raise InvalidTask("retain_replaced must be a boolean.")
        if not isinstance(require_retention_capacity, bool):
            raise InvalidTask("require_retention_capacity must be a boolean.")
        if require_retention_capacity and not retain_replaced:
            raise InvalidTask(
                "require_retention_capacity requires retain_replaced."
            )
        if retain_replaced and expected_existing_sha256 is None:
            raise InvalidTask(
                "retain_replaced requires expected_existing_sha256."
            )
        if expected_existing_sha256 is not None and not overwrite:
            raise InvalidTask(
                "expected_existing_sha256 cannot be combined with overwrite=false."
            )
        if expected_existing_fingerprint is not None and (
            not isinstance(expected_existing_fingerprint, FileFingerprint)
            or expected_existing_sha256 is None
        ):
            raise InvalidTask(
                "expected_existing_fingerprint requires an existing digest guard."
            )
        if require_retention_capacity and (
            expected_existing_fingerprint is None
            or not _has_windows_change_time(expected_existing_fingerprint)
        ):
            raise BlockingIOError(
                errno.EAGAIN,
                "Windows ChangeTime is unavailable for safe remote replacement.",
            )
        target = self._walk(split_relative(path), create=create_parents)
        parent, name = os.path.dirname(target), os.path.basename(target)
        existing = _path_fingerprint(target)
        if existing is not None and not overwrite:
            raise UnsafePath("The destination exists and overwrite is false.")
        retention_reservation = (
            self._reserve_retained_retirement_slot()
            if require_retention_capacity
            else None
        )
        if require_retention_capacity and retention_reservation is None:
            raise RetentionCapacityUnavailable()
        try:
            if expected_existing_sha256 is not None:
                if expected_existing_fingerprint is not None:
                    if _path_fingerprint(target) != expected_existing_fingerprint:
                        raise InvalidTask(
                            "The destination fingerprint changed before streaming."
                        )
                else:
                    preflight = _hash_existing_target(target)
                    if preflight is None:
                        raise InvalidTask(
                            "expected_existing_sha256 requires an existing destination."
                        )
                    if preflight.tagged_sha256 != expected_existing_sha256:
                        raise InvalidTask(
                            "The destination digest does not match expected_existing_sha256."
                        )
        except BaseException:
            self._release_retained_retirement_slot(retention_reservation)
            raise

        temporary = os.path.join(parent, _owned_temporary_name("stream"))
        marker = temporary + STREAM_TEMP_MARKER_SUFFIX
        descriptor = -1
        published = False
        marker_created = False
        retain_staged = False
        retained_result: RetiredRegularFile | None = None
        try:
            marker_data = _stream_temp_marker_bytes(
                os.path.basename(temporary), name, expected_size, expected_sha256, expected_file_digest
            )
            _write_private_marker_path(marker, marker_data)
            marker_created = True
            descriptor = os.open(
                temporary,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | _OPEN_FLAGS,
                0o600,
            )
            try:
                # On NTFS the sibling inherits the workspace directory's DACL;
                # the mode is additionally exact when these mechanics are
                # exercised by the platform-neutral suite on POSIX.
                if sys.platform != "win32":
                    os.fchmod(descriptor, 0o600)
                _stream_chunks_to_descriptor(
                    descriptor,
                    chunks,
                    expected_size=expected_size,
                    expected_sha256=expected_sha256,
                    expected_file_digest=expected_file_digest,
                    block_descriptor=block_descriptor,
                    tree_source=tree_source,
                )
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
                descriptor = -1

            retired: tuple[str, str, HashedRegularFile] | None = None
            if expected_existing_sha256 is not None:
                retired = self._retire_file_target(
                    target,
                    expected=(
                        HashedRegularFile(
                            expected_existing_fingerprint,
                            expected_existing_sha256.removeprefix("sha256:"),
                        )
                        if expected_existing_fingerprint is not None
                        else None
                    ),
                )
                if retired is None:
                    raise InvalidTask(
                        "expected_existing_sha256 requires an existing destination."
                    )
                if retired[2].tagged_sha256 != expected_existing_sha256:
                    self._restore_retired_file_target(target, retired)
                    raise InvalidTask(
                        "The destination digest does not match expected_existing_sha256."
                    )
            else:
                _path_fingerprint(target)

            try:
                if retired is not None:
                    try:
                        # rename is no-clobber on NTFS. A newer editor-created
                        # destination wins and is preserved for the coordinator.
                        _move_no_clobber(temporary, target)
                    except BaseException:
                        self._restore_retired_file_target(target, retired)
                        raise
                    published = True
                    if retain_replaced:
                        relative_parent = "/".join(split_relative(path)[:-1])
                        temporary_name = os.path.basename(retired[0])
                        temporary_path = (
                            f"{relative_parent}/{temporary_name}"
                            if relative_parent
                            else temporary_name
                        )
                        retained_result = RetiredRegularFile(
                            original_path=path,
                            temporary_path=temporary_path,
                            marker_path=f"{temporary_path}{STREAM_TEMP_MARKER_SUFFIX}",
                            initial=retired[2],
                            retention_reservation=retention_reservation,
                        )
                        retention_reservation = None
                    else:
                        self._finish_internal_retired_file_target(
                            target, retired, path
                        )
                elif overwrite:
                    _replace_stream_with_retry(
                        temporary, target, expected_existing_sha256
                    )
                elif sys.platform == "win32":  # os.rename is no-clobber on NTFS
                    _retry_sharing_violation(os.rename, temporary, target)
                else:
                    # Keep the Windows implementation's tests honest on POSIX,
                    # where rename would otherwise overwrite an unexpected file.
                    os.link(temporary, target, follow_symlinks=False)
                    os.unlink(temporary)
            except OSError as error:
                if _is_retryable_sharing_error(error):
                    retain_staged = True
                    raise InvalidTask(
                        "Windows kept the verified staged file after persistent sharing "
                        f"contention: {os.path.basename(temporary)}"
                    ) from error
                raise
            published = True
            try:
                _retry_sharing_violation(os.unlink, marker)
                marker_created = False
            except OSError:
                pass
        finally:
            if descriptor >= 0:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
            if not published and not retain_staged:
                try:
                    _retry_sharing_violation(os.unlink, temporary)
                except OSError:
                    pass
            if marker_created and not retain_staged:
                try:
                    _retry_sharing_violation(os.unlink, marker)
                except OSError:
                    pass
            self._release_retained_retirement_slot(retention_reservation)
        return retained_result

    def replace_stream_by_fingerprint(
        self,
        path: str,
        chunks: Iterable[bytes],
        *,
        expected_size: int,
        expected_sha256: str,
        expected_existing_fingerprint: FileFingerprint,
        create_parents: bool = False,
    ) -> FingerprintReplaceResult:
        """Replace one exact identity without reading or hashing the loser.

        Windows can reject renames while another process holds a non-sharing
        handle, so the descriptor is closed immediately before the bounded
        rename retry. The moved entry is then reopened and matched against the
        complete recorded ``FileFingerprint`` before publication. A race can
        therefore make the operation fail, but can never authorize overwrite
        of a different object.
        """

        _validate_stream_contract(expected_size, expected_sha256, None)
        if not isinstance(expected_existing_fingerprint, FileFingerprint):
            raise InvalidTask(
                "expected_existing_fingerprint must be a FileFingerprint."
            )
        if not _has_windows_change_time(expected_existing_fingerprint):
            raise BlockingIOError(
                errno.EAGAIN,
                "Windows ChangeTime is unavailable for safe remote replacement.",
            )
        parts = split_relative(path)
        target = self._walk(parts, create=create_parents)
        parent, name = os.path.dirname(target), os.path.basename(target)
        incoming = os.path.join(parent, _owned_temporary_name("stream"))
        incoming_marker = incoming + STREAM_TEMP_MARKER_SUFFIX
        retired = os.path.join(parent, _owned_temporary_name("retire"))
        retired_marker = retired + STREAM_TEMP_MARKER_SUFFIX
        conflict_name = _bounded_retire_conflict_name(
            name, os.path.basename(retired)
        )
        conflict = os.path.join(parent, conflict_name)
        incoming_fd = -1
        existing_fd = -1
        incoming_marker_created = False
        retired_marker_created = False
        published = False
        incoming_fingerprint: FileFingerprint | None = None
        try:
            _write_private_marker_path(
                incoming_marker,
                _stream_temp_marker_bytes(
                    os.path.basename(incoming),
                    name,
                    expected_size,
                    expected_sha256,
                ),
            )
            incoming_marker_created = True
            incoming_fd = os.open(
                incoming,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | _OPEN_FLAGS,
                0o600,
            )
            try:
                if sys.platform != "win32":
                    os.fchmod(incoming_fd, 0o600)
                _stream_chunks_to_descriptor(
                    incoming_fd,
                    chunks,
                    expected_size=expected_size,
                    expected_sha256=expected_sha256,
                )
                os.fsync(incoming_fd)
                incoming_fingerprint = _regular_fingerprint_from_descriptor(
                    incoming_fd,
                    "The verified stream stage must remain a regular file.",
                )
            finally:
                os.close(incoming_fd)
                incoming_fd = -1

            opened = _open_regular_descriptor(target, missing_ok=False)
            assert opened is not None
            existing_fd, opened_fingerprint = opened
            if (
                opened_fingerprint != expected_existing_fingerprint
                or _path_fingerprint(target) != opened_fingerprint
            ):
                raise InvalidTask(
                    "The conflict loser no longer has the recorded identity."
                )
            # NTFS commonly denies a rename while this CRT handle is open.
            # Close immediately before retiring, then prove that the exact
            # object, not merely some pathname, was the object actually moved.
            os.close(existing_fd)
            existing_fd = -1
            _write_private_marker_path(
                retired_marker,
                _retire_temp_marker_bytes(os.path.basename(retired), name),
            )
            retired_marker_created = True
            _retry_sharing_violation(os.rename, target, retired)
            retired_fingerprint = _path_fingerprint(retired, source=True)
            if retired_fingerprint is None or not _same_regular_state_after_rename(
                expected_existing_fingerprint, retired_fingerprint
            ):
                recovered = _recover_retired_marker_path(
                    retired_marker,
                    {
                        "temporary": os.path.basename(retired),
                        "target": name,
                        "owner_pid": os.getpid(),
                    },
                )
                retired_marker_created = not recovered
                raise InvalidTask(
                    "The conflict loser changed immediately before replacement."
                )

            _move_no_clobber(incoming, target)
            published = True
            published_fingerprint = _path_fingerprint(target)
            if (
                incoming_fingerprint is None
                or published_fingerprint is None
                or not _same_regular_state_after_rename(
                    incoming_fingerprint, published_fingerprint
                )
            ):
                raise InvalidTask("The replacement changed during publication.")
            try:
                _retry_sharing_violation(os.unlink, incoming_marker)
                incoming_marker_created = False
            except OSError:
                pass

            # Always keep the unhashable loser at a visible deterministic
            # sibling. This also preserves writes through any share-delete
            # handle that NTFS allowed to remain open across the rename.
            _move_no_clobber(retired, conflict)
            preserved_fingerprint = _path_fingerprint(conflict, source=True)
            if preserved_fingerprint is None or not _same_regular_state_after_rename(
                expected_existing_fingerprint, preserved_fingerprint
            ):
                raise InvalidTask("The preserved conflict loser changed identity.")
            try:
                _retry_sharing_violation(os.unlink, retired_marker)
                retired_marker_created = False
            except OSError:
                # The temporary is already gone and the visible sibling owns
                # the bytes; recovery can now remove only the stale marker.
                if not _recover_retired_marker_path(
                    retired_marker,
                    {
                        "temporary": os.path.basename(retired),
                        "target": name,
                        "owner_pid": os.getpid(),
                    },
                ):
                    raise
                retired_marker_created = False
            prefix = "/".join(parts[:-1])
            preserved_path = f"{prefix}/{conflict_name}" if prefix else conflict_name
            return FingerprintReplaceResult(
                written=HashedRegularFile(
                    published_fingerprint,
                    expected_sha256.removeprefix("sha256:"),
                ),
                preserved_path=preserved_path,
            )
        finally:
            if incoming_fd >= 0:
                os.close(incoming_fd)
            if existing_fd >= 0:
                os.close(existing_fd)
            if not published:
                try:
                    _retry_sharing_violation(os.unlink, incoming)
                except OSError:
                    pass
            if incoming_marker_created:
                try:
                    _retry_sharing_violation(os.unlink, incoming_marker)
                except OSError:
                    pass
            if retired_marker_created:
                _recover_retired_marker_path(
                    retired_marker,
                    {
                        "temporary": os.path.basename(retired),
                        "target": name,
                        "owner_pid": os.getpid(),
                    },
                )

    def preserve_file_by_fingerprint(
        self, path: str, *, expected_fingerprint: FileFingerprint
    ) -> str:
        """Move an exact identity to a visible no-clobber recovery sibling."""

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        parts = split_relative(path)
        target = self._optional_file_target(parts)
        if target is None:
            raise InvalidTask("The conflict loser disappeared before preservation.")
        parent, name = os.path.dirname(target), os.path.basename(target)
        retired = os.path.join(parent, _owned_temporary_name("retire"))
        marker = retired + STREAM_TEMP_MARKER_SUFFIX
        conflict_name = _bounded_retire_conflict_name(
            name, os.path.basename(retired)
        )
        conflict = os.path.join(parent, conflict_name)
        descriptor = -1
        marker_created = False
        try:
            opened = _open_regular_descriptor(target, missing_ok=False)
            assert opened is not None
            descriptor, opened_fingerprint = opened
            if (
                opened_fingerprint != expected_fingerprint
                or _path_fingerprint(target) != opened_fingerprint
            ):
                raise InvalidTask(
                    "The conflict loser no longer has the recorded identity."
                )
            os.close(descriptor)
            descriptor = -1
            _write_private_marker_path(
                marker,
                _retire_temp_marker_bytes(os.path.basename(retired), name),
            )
            marker_created = True
            _retry_sharing_violation(os.rename, target, retired)
            retired_fingerprint = _path_fingerprint(retired, source=True)
            if retired_fingerprint is None or not _same_regular_state_after_rename(
                expected_fingerprint, retired_fingerprint
            ):
                raise InvalidTask(
                    "The conflict loser changed immediately before preservation."
                )
            _move_no_clobber(retired, conflict)
            preserved_fingerprint = _path_fingerprint(conflict, source=True)
            if preserved_fingerprint is None or not _same_regular_state_after_rename(
                expected_fingerprint, preserved_fingerprint
            ):
                raise InvalidTask("The recovery sibling changed identity.")
            try:
                _retry_sharing_violation(os.unlink, marker)
                marker_created = False
            except OSError:
                if not _recover_retired_marker_path(
                    marker,
                    {
                        "temporary": os.path.basename(retired),
                        "target": name,
                        "owner_pid": os.getpid(),
                    },
                ):
                    raise
                marker_created = False
            prefix = "/".join(parts[:-1])
            return f"{prefix}/{conflict_name}" if prefix else conflict_name
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            if marker_created:
                _recover_retired_marker_path(
                    marker,
                    {
                        "temporary": os.path.basename(retired),
                        "target": name,
                        "owner_pid": os.getpid(),
                    },
                )

    def _retire_file_target(
        self,
        target: str,
        *,
        expected: HashedRegularFile | None = None,
    ) -> tuple[str, str, HashedRegularFile] | None:
        if self.stream_recovery_pending or self._stream_recovery_retry_required:
            raise InvalidTask("Retired-inode quarantine recovery is incomplete.")
        self.maintain_retired_quarantine()
        parent, name = os.path.dirname(target), os.path.basename(target)
        temporary = os.path.join(parent, _owned_temporary_name("retire"))
        marker = temporary + STREAM_TEMP_MARKER_SUFFIX
        _write_private_marker_path(
            marker,
            _retire_temp_marker_bytes(os.path.basename(temporary), name),
        )
        uses_windows_witness = _uses_windows_change_time()
        # On Windows, the read-capable target handle below is the stronger
        # witness: it excludes writers and pins the exact file object across
        # our rename. NTFS directory ChangeTime does not provide a dependable
        # ordering interval for a child rename. POSIX retains its parent-time
        # witness because it does not have the Windows share-mode fence.
        namespace_witness: ContextManager[Callable[[], int | None]] = (
            nullcontext(lambda: None)
            if uses_windows_witness
            else nullcontext(lambda: _directory_namespace_time_ns(os.stat(parent)))
        )
        file_write_fence: ContextManager[Callable[[], int | None]]
        if uses_windows_witness and expected is not None:
            file_write_fence = _windows_retirement_file_write_fence(target)
        else:
            file_write_fence = nullcontext(lambda: None)
        with (
            namespace_witness as read_parent_namespace_time,
            file_write_fence as read_pinned_file_change_time,
        ):
            pinned_file_before = read_pinned_file_change_time()
            if expected is not None and uses_windows_witness:
                if (
                    pinned_file_before is None
                    or pinned_file_before != expected.fingerprint.ctime_ns
                ):
                    _retry_sharing_violation(os.unlink, marker)
                    raise BlockingIOError(
                        errno.EAGAIN,
                        "The Windows retirement write fence is unavailable.",
                    )
            if (
                expected is not None
                and _path_fingerprint(target) != expected.fingerprint
            ):
                _retry_sharing_violation(os.unlink, marker)
                raise InvalidTask("The workspace file changed before retirement.")
            parent_before_rename = read_parent_namespace_time()
            try:
                _retry_sharing_violation(os.rename, target, temporary)
            except FileNotFoundError:
                _retry_sharing_violation(os.unlink, marker)
                return None
            except BaseException:
                try:
                    _retry_sharing_violation(os.unlink, marker)
                except OSError:
                    pass
                raise
            parent_after_rename = read_parent_namespace_time()
            try:
                if expected is not None:
                    retired_fingerprint = _path_fingerprint(temporary, source=True)
                    pinned_file_after = read_pinned_file_change_time()
                    if (
                        retired_fingerprint is None
                        or not _same_regular_state_after_rename(
                            expected.fingerprint, retired_fingerprint
                        )
                        or (
                            uses_windows_witness
                            and pinned_file_after != retired_fingerprint.ctime_ns
                        )
                    ):
                        raise InvalidTask(
                            "The workspace file changed during retirement."
                        )
                    if (
                        not uses_windows_witness
                        and retired_fingerprint.ctime_ns
                        != expected.fingerprint.ctime_ns
                        and (
                            parent_before_rename is None
                            or parent_after_rename is None
                            or parent_after_rename <= parent_before_rename
                            or not (
                                parent_before_rename
                                <= retired_fingerprint.ctime_ns
                                <= parent_after_rename
                            )
                        )
                    ):
                        raise InvalidTask(
                            "The workspace retirement lacked an exact namespace witness."
                        )
                    return temporary, marker, HashedRegularFile(
                        retired_fingerprint, expected.sha256
                    )
                captured = _hash_existing_target(temporary)
                if captured is None:
                    raise InvalidTask(
                        "The workspace file disappeared while being retired."
                    )
                return temporary, marker, captured
            except BaseException:
                _recover_retired_marker_path(
                    marker,
                    {
                        "temporary": os.path.basename(temporary),
                        "target": name,
                        "owner_pid": os.getpid(),
                    },
                )
                raise

    @staticmethod
    def _restore_retired_file_target(
        target: str, retired: tuple[str, str, HashedRegularFile]
    ) -> str:
        temporary, marker, _captured = retired
        restored = target
        try:
            _move_no_clobber(temporary, target)
        except FileExistsError:
            restored = os.path.join(
                os.path.dirname(target),
                _bounded_retire_conflict_name(
                    os.path.basename(target), os.path.basename(temporary)
                ),
            )
            _move_no_clobber(temporary, restored)
        _retry_sharing_violation(os.unlink, marker)
        return restored

    def _queue_visible_quarantine_promotion(
        self,
        record: _RetiredQuarantineRecord,
        *,
        visible_path: str | None = None,
    ) -> None:
        promotion = RetiredQuarantinePromotion(
            original_path=record.original_path,
            visible_path=visible_path or record.conflict_path,
            temporary_path=record.temporary_path,
            marker_path=record.marker_path,
            conflict_path=record.conflict_path,
            quarantined_at_ns=record.quarantined_at_ns,
            recorded_size_bytes=record.recorded_size_bytes,
            device_id=record.device_id,
            file_id=record.file_id,
            recorded_sha256=record.recorded_sha256,
            recorded_mtime_ns=record.recorded_mtime_ns,
            recorded_ctime_ns=record.recorded_ctime_ns,
            retain_unchanged=record.retain_unchanged,
            accounting_owner=record.accounting_owner,
        )
        for index, item in enumerate(
            self._retired_quarantine_visible_promotions
        ):
            if _normcase(item.marker_path) != _normcase(promotion.marker_path):
                continue
            if replace(item, visible_path=promotion.visible_path) != promotion:
                self._retired_quarantine_maintenance_error = True
                raise InvalidTask(
                    "A retired-inode marker cannot identify two promotions."
                )
            self._retired_quarantine_visible_promotions[index] = promotion
            return
        if (
            len(self._retired_quarantine_visible_promotions)
            >= RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX
        ):
            self._retired_quarantine_promotion_overflow = True
            return
        self._retired_quarantine_visible_promotions.append(promotion)

    @_serialize_retired_quarantine
    def drain_retired_quarantine_promotions(
        self, *, max_entries: int = RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX
    ) -> tuple[RetiredQuarantinePromotion, ...]:
        if (
            isinstance(max_entries, bool)
            or not isinstance(max_entries, int)
            or not 1 <= max_entries <= RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX
        ):
            raise InvalidTask("Invalid retired-inode promotion drain bound.")
        drained = tuple(self._retired_quarantine_visible_promotions[:max_entries])
        del self._retired_quarantine_visible_promotions[:max_entries]
        if not self._retired_quarantine_visible_promotions:
            self._retired_quarantine_promotion_overflow = False
        return drained

    @_serialize_retired_quarantine
    def retained_retired_files(
        self, *, max_entries: int = RETIRED_QUARANTINE_MAX_ENTRIES
    ) -> tuple[RetiredRegularFile, ...]:
        if (
            isinstance(max_entries, bool)
            or not isinstance(max_entries, int)
            or not 1 <= max_entries <= RETIRED_QUARANTINE_MAX_ENTRIES
        ):
            raise InvalidTask("Invalid retained retirement scan bound.")
        retained: list[RetiredRegularFile] = []
        for record in sorted(
            self._retired_quarantine.values(),
            key=lambda item: (item.quarantined_at_ns, item.marker_path),
        ):
            if not record.retain_unchanged or record.recorded_sha256 is None:
                continue
            _size, interrupted = self._inspect_quarantine_record(record)
            if interrupted:
                continue
            assert record.recorded_mtime_ns is not None
            assert record.recorded_ctime_ns is not None
            retained.append(
                RetiredRegularFile(
                    original_path=record.original_path,
                    temporary_path=record.temporary_path,
                    marker_path=record.marker_path,
                    initial=HashedRegularFile(
                        FileFingerprint(
                            size_bytes=record.recorded_size_bytes,
                            mtime_ns=record.recorded_mtime_ns,
                            ctime_ns=record.recorded_ctime_ns,
                            device_id=record.device_id,
                            file_id=record.file_id,
                        ),
                        record.recorded_sha256,
                    ),
                    accounting_owner=record.accounting_owner,
                )
            )
            if len(retained) >= max_entries:
                break
        return tuple(retained)

    @_serialize_retired_quarantine
    def defer_retired_quarantine_promotion(
        self, promotion: RetiredQuarantinePromotion
    ) -> None:
        if not isinstance(promotion, RetiredQuarantinePromotion):
            raise InvalidTask("promotion must be retired-inode evidence.")
        record = _RetiredQuarantineRecord(
            original_path=promotion.original_path,
            temporary_path=promotion.temporary_path,
            marker_path=promotion.marker_path,
            conflict_path=promotion.conflict_path,
            quarantined_at_ns=promotion.quarantined_at_ns,
            recorded_size_bytes=promotion.recorded_size_bytes,
            device_id=promotion.device_id,
            file_id=promotion.file_id,
            recorded_sha256=promotion.recorded_sha256,
            recorded_mtime_ns=promotion.recorded_mtime_ns,
            recorded_ctime_ns=promotion.recorded_ctime_ns,
            retain_unchanged=promotion.retain_unchanged,
            accounting_owner=promotion.accounting_owner,
        )
        self._queue_visible_quarantine_promotion(
            record, visible_path=promotion.visible_path
        )

    @_serialize_retired_quarantine
    def acknowledge_retired_quarantine_promotion(
        self,
        promotion: RetiredQuarantinePromotion,
        *,
        expected_fingerprint: FileFingerprint,
    ) -> None:
        if not isinstance(promotion, RetiredQuarantinePromotion):
            raise InvalidTask("promotion must be retired-inode evidence.")
        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        if (
            expected_fingerprint.device_id != promotion.device_id
            or expected_fingerprint.file_id != promotion.file_id
            or self.stat_fingerprint(promotion.visible_path) != expected_fingerprint
        ):
            raise InvalidTask("The promoted retired inode changed before handoff.")
        record = _RetiredQuarantineRecord(
            original_path=promotion.original_path,
            temporary_path=promotion.temporary_path,
            marker_path=promotion.marker_path,
            conflict_path=promotion.conflict_path,
            quarantined_at_ns=promotion.quarantined_at_ns,
            recorded_size_bytes=promotion.recorded_size_bytes,
            device_id=promotion.device_id,
            file_id=promotion.file_id,
            recorded_sha256=promotion.recorded_sha256,
            recorded_mtime_ns=promotion.recorded_mtime_ns,
            recorded_ctime_ns=promotion.recorded_ctime_ns,
            retain_unchanged=promotion.retain_unchanged,
            accounting_owner=promotion.accounting_owner,
        )
        marker = self._walk(_split_owned_relative(record.marker_path))
        try:
            self._validate_quarantine_marker_path(marker, record)
            _retry_sharing_violation(os.unlink, marker)
        except (InvalidTask, OSError, UnsafePath):
            self._retired_quarantine_maintenance_error = True
            raise
        key = next(
            (
                path
                for path in self._retired_quarantine
                if _normcase(path) == _normcase(record.marker_path)
            ),
            None,
        )
        if key is not None:
            self._retired_quarantine.pop(key, None)
        self._retired_quarantine_visible_promotions = [
            item
            for item in self._retired_quarantine_visible_promotions
            if _normcase(item.marker_path) != _normcase(record.marker_path)
        ]

    @staticmethod
    def _quarantine_promotion_candidates(
        items: list[tuple[_RetiredQuarantineRecord, int]],
        *,
        now_ns: int,
        max_entries: int,
        max_bytes: int,
        max_age_seconds: float,
        extra_entries: int = 0,
        extra_bytes: int = 0,
    ) -> list[_RetiredQuarantineRecord]:
        ordered = sorted(
            items,
            key=lambda item: (
                item[0].quarantined_at_ns,
                _normcase(item[0].marker_path),
            ),
        )
        selected: list[_RetiredQuarantineRecord] = []
        selected_paths: set[str] = set()
        age_ns = int(max_age_seconds * 1_000_000_000)
        for record, _size in ordered:
            if (
                not record.retain_unchanged
                and now_ns - record.quarantined_at_ns >= age_ns
            ):
                selected.append(record)
                selected_paths.add(_normcase(record.marker_path))
        remaining_count = len(items) - len(selected) + extra_entries
        remaining_bytes = (
            sum(
                size
                for record, size in items
                if _normcase(record.marker_path) not in selected_paths
                and not record.retain_unchanged
            )
            + extra_bytes
        )
        for record, size in ordered:
            if remaining_count <= max_entries and remaining_bytes <= max_bytes:
                break
            if _normcase(record.marker_path) in selected_paths:
                continue
            if record.retain_unchanged:
                continue
            selected.append(record)
            selected_paths.add(_normcase(record.marker_path))
            remaining_count -= 1
            if not record.retain_unchanged:
                remaining_bytes -= size
        return selected

    def _inspect_quarantine_record(
        self, record: _RetiredQuarantineRecord
    ) -> tuple[int, bool]:
        temporary = self._walk(_split_owned_relative(record.temporary_path))
        conflict = self._walk(split_relative(record.conflict_path))
        try:
            info = os.lstat(temporary)
        except FileNotFoundError:
            try:
                info = os.lstat(conflict)
            except FileNotFoundError:
                recovery = self.stat_fingerprint(
                    retired_quarantine_recovery_path(record.conflict_path)
                )
                if (
                    recovery is None
                    or recovery.device_id != record.device_id
                    or recovery.file_id != record.file_id
                ):
                    raise InvalidTask(
                        "A retired-inode quarantine entry disappeared."
                    ) from None
                return recovery.size_bytes, True
            except OSError as error:
                raise InvalidTask(
                    "A retired-inode quarantine entry disappeared."
                ) from error
            if (
                _is_reparse(info)
                or not stat_module.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or info.st_dev != record.device_id
                or info.st_ino != record.file_id
            ):
                raise InvalidTask("A retired-inode promotion identity changed.")
            return (
                _allocated_file_bytes(info)
                if record.retain_unchanged
                else int(info.st_size)
            ), True
        except OSError as error:
            raise InvalidTask(
                "A retired-inode quarantine entry cannot be inspected."
            ) from error
        if (
            _is_reparse(info)
            or not stat_module.S_ISREG(info.st_mode)
            or info.st_dev != record.device_id
            or info.st_ino != record.file_id
            or info.st_nlink not in (1, 2)
        ):
            raise InvalidTask("A retired-inode quarantine identity changed.")
        if info.st_nlink == 2:
            try:
                conflict_info = os.lstat(conflict)
            except OSError as error:
                raise InvalidTask(
                    "A retired-inode promotion cannot be verified."
                ) from error
            if (
                _is_reparse(conflict_info)
                or conflict_info.st_dev != info.st_dev
                or conflict_info.st_ino != info.st_ino
                or conflict_info.st_nlink != 2
            ):
                raise InvalidTask("A retired-inode promotion identity changed.")
            return (
                _allocated_file_bytes(info)
                if record.retain_unchanged
                else int(info.st_size)
            ), True
        if record.retain_unchanged:
            current = _path_fingerprint(temporary, source=True)
            if current is None:
                raise InvalidTask("A retired-inode quarantine entry disappeared.")
            if (
                record.recorded_mtime_ns is None
                or record.recorded_ctime_ns is None
                or record.recorded_ctime_ns <= 0
                or current.size_bytes != record.recorded_size_bytes
                or current.mtime_ns != record.recorded_mtime_ns
                or (
                    _has_windows_change_time(current)
                    and current.ctime_ns != record.recorded_ctime_ns
                )
            ):
                return _allocated_file_bytes(info), True
        return (
            _allocated_file_bytes(info)
            if record.retain_unchanged
            else int(info.st_size)
        ), False

    @classmethod
    def inspect_retired_quarantine(
        cls,
        root: Path | str,
        *,
        now_ns: int | None = None,
        max_scan_entries: int = MAX_LIST_ENTRIES,
        retired_quarantine_max_bytes: int = RETIRED_QUARANTINE_MAX_BYTES,
        retired_quarantine_max_entries: int = RETIRED_QUARANTINE_MAX_ENTRIES,
        retired_quarantine_max_age_seconds: float = RETIRED_QUARANTINE_MAX_AGE_SECONDS,
    ) -> RetiredQuarantineStatus:
        """Read quarantine metrics without recovery or namespace mutation."""

        max_bytes, max_entries, max_age = _validate_retired_quarantine_bounds(
            retired_quarantine_max_bytes,
            retired_quarantine_max_entries,
            retired_quarantine_max_age_seconds,
        )
        observed_now = time.time_ns() if now_ns is None else now_ns
        if (
            isinstance(observed_now, bool)
            or not isinstance(observed_now, int)
            or isinstance(max_scan_entries, bool)
            or not isinstance(max_scan_entries, int)
            or not 1 <= max_scan_entries <= MAX_LIST_ENTRIES
        ):
            raise InvalidTask("Invalid retired-inode quarantine inspection bounds.")
        resolved = Path(os.path.realpath(str(Path(root).expanduser())))
        if not resolved.is_dir() or _is_reparse(os.lstat(resolved)):
            raise UnsafePath(f"The synchronized workspace {resolved} is unavailable.")
        pending: list[tuple[str, ...]] = [()]
        visited = 0
        scan_pending = False
        active_retire_pending = False
        blocked = False
        interrupted = 0
        identities: set[tuple[int, int]] = set()
        items: list[tuple[_RetiredQuarantineRecord, int]] = []

        def directory_path(parts: tuple[str, ...]) -> str:
            current = str(resolved)
            for part in parts:
                current = os.path.join(current, part)
                info = os.lstat(current)
                if _is_reparse(info) or not stat_module.S_ISDIR(info.st_mode):
                    raise UnsafePath("The quarantine scan reached an unsafe directory.")
            return current

        while pending and not scan_pending:
            parts = pending.pop()
            try:
                directory = directory_path(parts)
                entries = os.scandir(directory)
            except (OSError, UnsafePath):
                scan_pending = True
                break
            try:
                try:
                    for entry in entries:
                        visited += 1
                        if visited > max_scan_entries:
                            scan_pending = True
                            break
                        try:
                            info = entry.stat(follow_symlinks=False)
                        except OSError:
                            scan_pending = True
                            break
                        if stat_module.S_ISDIR(info.st_mode) and not _is_reparse(info):
                            pending.append((*parts, entry.name))
                            continue
                        if not entry.name.endswith(STREAM_TEMP_MARKER_SUFFIX):
                            continue
                        temporary_name = entry.name[
                            : -len(STREAM_TEMP_MARKER_SUFFIX)
                        ]
                        if _owned_temporary_kind(temporary_name) != "retire":
                            continue
                        try:
                            marker_fd = os.open(
                                entry.path, os.O_RDONLY | _OPEN_FLAGS
                            )
                            try:
                                data = os.read(
                                    marker_fd, _STREAM_TEMP_MARKER_MAX_BYTES + 1
                                )
                                marker_info = os.fstat(marker_fd)
                            finally:
                                os.close(marker_fd)
                        except OSError:
                            scan_pending = True
                            break
                        if (
                            len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
                            or _is_reparse(marker_info)
                            or not stat_module.S_ISREG(marker_info.st_mode)
                            or marker_info.st_nlink not in (1, 2)
                        ):
                            blocked = True
                            continue
                        marker = _parse_retired_quarantine_marker(
                            entry.name, data
                        )
                        if marker is None:
                            if _parse_retire_temp_marker(entry.name, data) is None:
                                blocked = True
                            else:
                                active_retire_pending = True
                            continue
                        if (
                            marker_info.st_nlink != 1
                            or str(marker["conflict"])
                            != _bounded_retire_conflict_name(
                                str(marker["target"]), str(marker["temporary"])
                            )
                        ):
                            blocked = True
                            continue
                        identity = (
                            int(marker["device_id"]), int(marker["file_id"])
                        )
                        if identity in identities:
                            blocked = True
                            continue
                        identities.add(identity)
                        prefix = "/".join(parts)
                        relative_prefix = f"{prefix}/" if prefix else ""
                        record = _RetiredQuarantineRecord(
                            original_path=f"{relative_prefix}{marker['target']}",
                            temporary_path=f"{relative_prefix}{marker['temporary']}",
                            marker_path=f"{relative_prefix}{entry.name}",
                            conflict_path=f"{relative_prefix}{marker['conflict']}",
                            quarantined_at_ns=int(marker["quarantined_at_ns"]),
                            recorded_size_bytes=int(marker["recorded_size_bytes"]),
                            device_id=identity[0],
                            file_id=identity[1],
                            recorded_sha256=marker["recorded_sha256"],
                            recorded_mtime_ns=marker["recorded_mtime_ns"],
                            recorded_ctime_ns=marker["recorded_ctime_ns"],
                            retain_unchanged=bool(marker["retain_unchanged"]),
                            accounting_owner=str(marker["accounting_owner"]),
                        )
                        temporary = os.path.join(
                            directory, str(marker["temporary"])
                        )
                        conflict = os.path.join(directory, str(marker["conflict"]))
                        try:
                            temp_info = os.lstat(temporary)
                        except FileNotFoundError:
                            try:
                                conflict_info = os.lstat(conflict)
                            except FileNotFoundError:
                                recovery_path = os.path.join(
                                    str(resolved),
                                    *split_relative(
                                        retired_quarantine_recovery_path(
                                            record.conflict_path
                                        )
                                    ),
                                )
                                try:
                                    conflict_info = os.lstat(recovery_path)
                                except OSError:
                                    blocked = True
                                    continue
                            except OSError:
                                blocked = True
                                continue
                            if (
                                _is_reparse(conflict_info)
                                or conflict_info.st_dev != identity[0]
                                or conflict_info.st_ino != identity[1]
                            ):
                                blocked = True
                            else:
                                interrupted += 1
                            continue
                        except OSError:
                            scan_pending = True
                            break
                        if (
                            _is_reparse(temp_info)
                            or not stat_module.S_ISREG(temp_info.st_mode)
                            or temp_info.st_dev != identity[0]
                            or temp_info.st_ino != identity[1]
                            or temp_info.st_nlink not in (1, 2)
                        ):
                            blocked = True
                            continue
                        if temp_info.st_nlink == 2:
                            try:
                                conflict_info = os.lstat(conflict)
                            except OSError:
                                blocked = True
                                continue
                            if (
                                conflict_info.st_dev != identity[0]
                                or conflict_info.st_ino != identity[1]
                            ):
                                blocked = True
                            else:
                                interrupted += 1
                        elif record.retain_unchanged:
                            current = _path_fingerprint(temporary, source=True)
                            if (
                                current is None
                                or record.recorded_mtime_ns is None
                                or record.recorded_ctime_ns is None
                                or record.recorded_ctime_ns <= 0
                                or current.size_bytes
                                != record.recorded_size_bytes
                                or current.mtime_ns
                                != record.recorded_mtime_ns
                                or (
                                    _has_windows_change_time(current)
                                    and current.ctime_ns
                                    != record.recorded_ctime_ns
                                )
                            ):
                                interrupted += 1
                            else:
                                items.append(
                                    (record, _allocated_file_bytes(temp_info))
                                )
                        else:
                            items.append(
                                (
                                    record,
                                    (
                                        _allocated_file_bytes(temp_info)
                                        if record.retain_unchanged
                                        else int(temp_info.st_size)
                                    ),
                                )
                            )
                except OSError:
                    scan_pending = True
            finally:
                entries.close()
        candidates = cls._quarantine_promotion_candidates(
            items,
            now_ns=observed_now,
            max_entries=max_entries,
            max_bytes=max_bytes,
            max_age_seconds=max_age,
        )
        oldest = min(
            (record.quarantined_at_ns for record, _size in items), default=None
        )
        return RetiredQuarantineStatus(
            entry_count=len(items),
            bytes_on_disk=sum(size for _record, size in items),
            oldest_quarantined_at_ns=oldest,
            oldest_age_seconds=(
                max(0.0, (observed_now - oldest) / 1_000_000_000)
                if oldest is not None
                else 0.0
            ),
            promotion_backlog=len(candidates) + interrupted,
            visible_promotion_backlog=0,
            visible_promotion_overflow=False,
            max_entries=max_entries,
            max_bytes=max_bytes,
            max_age_seconds=max_age,
            recovery_pending=(
                scan_pending or bool(pending) or active_retire_pending
            ),
            recovery_blocked=blocked,
        )

    @_serialize_retired_quarantine
    def retired_quarantine_status(
        self, *, now_ns: int | None = None
    ) -> RetiredQuarantineStatus:
        observed_now = time.time_ns() if now_ns is None else now_ns
        if isinstance(observed_now, bool) or not isinstance(observed_now, int):
            raise InvalidTask("now_ns must be an integer nanosecond timestamp.")
        items: list[tuple[_RetiredQuarantineRecord, int]] = []
        interrupted = 0
        blocked = (
            self._ambiguous_retire_recovery
            or self._retired_quarantine_maintenance_error
        )
        retained_usage: RetainedStorageUsage | None
        try:
            retained_usage = self.retained_storage_usage()
        except (InvalidTask, UnsafePath):
            retained_usage = None
            blocked = True
        for record in list(self._retired_quarantine.values()):
            try:
                size, is_interrupted = self._inspect_quarantine_record(record)
            except (InvalidTask, UnsafePath):
                blocked = True
                continue
            if is_interrupted:
                interrupted += 1
            else:
                items.append((record, size))
        candidates = self._quarantine_promotion_candidates(
            items,
            now_ns=observed_now,
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
        )
        oldest = min(
            (record.quarantined_at_ns for record, _size in items), default=None
        )
        return RetiredQuarantineStatus(
            entry_count=len(items),
            bytes_on_disk=sum(size for _record, size in items),
            oldest_quarantined_at_ns=oldest,
            oldest_age_seconds=(
                max(0.0, (observed_now - oldest) / 1_000_000_000)
                if oldest is not None
                else 0.0
            ),
            promotion_backlog=len(candidates) + interrupted,
            visible_promotion_backlog=len(
                self._retired_quarantine_visible_promotions
            ),
            visible_promotion_overflow=self._retired_quarantine_promotion_overflow,
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
            recovery_pending=(
                self.stream_recovery_pending
                or self._stream_recovery_retry_required
            ),
            recovery_blocked=blocked,
            retained_owner_count=(
                retained_usage.owner_count if retained_usage is not None else None
            ),
            logical_retained_bytes=(
                retained_usage.logical_bytes if retained_usage is not None else None
            ),
            allocated_retained_bytes=(
                retained_usage.allocated_bytes if retained_usage is not None else None
            ),
            retention_reservation_count=(
                retained_usage.reservation_count
                if retained_usage is not None
                else None
            ),
        )

    @_serialize_retired_quarantine
    def maintain_retired_quarantine(
        self, *, now_ns: int | None = None
    ) -> tuple[str, ...]:
        observed_now = time.time_ns() if now_ns is None else now_ns
        if isinstance(observed_now, bool) or not isinstance(observed_now, int):
            raise InvalidTask("now_ns must be an integer nanosecond timestamp.")
        if self.stream_recovery_pending or self._stream_recovery_retry_required:
            raise InvalidTask("Retired-inode quarantine recovery is incomplete.")
        if self._ambiguous_retire_recovery:
            raise InvalidTask("Retired-inode quarantine recovery is blocked.")
        self._retired_quarantine_maintenance_error = False
        promoted: list[str] = []
        items: list[tuple[_RetiredQuarantineRecord, int]] = []
        for record in list(self._retired_quarantine.values()):
            try:
                size, interrupted = self._inspect_quarantine_record(record)
            except (InvalidTask, OSError, UnsafePath):
                self._retired_quarantine_maintenance_error = True
                raise
            if interrupted:
                promoted.append(self._promote_quarantine_record(record))
            else:
                items.append((record, size))
        for record in self._quarantine_promotion_candidates(
            items,
            now_ns=observed_now,
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
        ):
            key = _normcase(record.marker_path)
            if any(_normcase(path) == key for path in self._retired_quarantine):
                promoted.append(self._promote_quarantine_record(record))
        return tuple(promoted)

    def _promote_quarantine_record(
        self, record: _RetiredQuarantineRecord
    ) -> str:
        temporary = self._walk(_split_owned_relative(record.temporary_path))
        marker = self._walk(_split_owned_relative(record.marker_path))
        conflict = self._walk(split_relative(record.conflict_path))
        visible_path = record.conflict_path
        try:
            self._validate_quarantine_marker_path(marker, record)
            try:
                temp_info = os.lstat(temporary)
            except FileNotFoundError:
                temp_info = None
            except OSError as error:
                raise InvalidTask(
                    "A retired-inode quarantine entry cannot be inspected."
                ) from error
            if temp_info is not None:
                if (
                    _is_reparse(temp_info)
                    or not stat_module.S_ISREG(temp_info.st_mode)
                    or temp_info.st_dev != record.device_id
                    or temp_info.st_ino != record.file_id
                    or temp_info.st_nlink not in (1, 2)
                ):
                    raise InvalidTask("A retired-inode quarantine identity changed.")
                if temp_info.st_nlink == 1:
                    try:
                        _move_no_clobber(temporary, conflict)
                    except FileExistsError:
                        conflict_info = os.lstat(conflict)
                        if (
                            conflict_info.st_dev != temp_info.st_dev
                            or conflict_info.st_ino != temp_info.st_ino
                        ):
                            raise InvalidTask(
                                "The deterministic retire conflict name is occupied."
                            ) from None
                if os.path.exists(temporary):
                    conflict_info = os.lstat(conflict)
                    if (
                        conflict_info.st_dev != record.device_id
                        or conflict_info.st_ino != record.file_id
                    ):
                        raise InvalidTask(
                            "A retired-inode promotion identity changed."
                        )
                    _retry_sharing_violation(os.unlink, temporary)
            try:
                conflict_info = os.lstat(conflict)
            except FileNotFoundError:
                recovery_path = retired_quarantine_recovery_path(
                    record.conflict_path
                )
                recovery = self.stat_fingerprint(recovery_path)
                if (
                    recovery is None
                    or recovery.device_id != record.device_id
                    or recovery.file_id != record.file_id
                ):
                    raise InvalidTask(
                        "A retired-inode quarantine entry disappeared."
                    ) from None
                visible_path = recovery_path
                conflict_info = None
            except OSError as error:
                raise InvalidTask(
                    "A retired-inode quarantine entry disappeared."
                ) from error
            if conflict_info is not None and (
                _is_reparse(conflict_info)
                or not stat_module.S_ISREG(conflict_info.st_mode)
                or conflict_info.st_dev != record.device_id
                or conflict_info.st_ino != record.file_id
            ):
                raise InvalidTask("A retired-inode promotion identity changed.")
        except (InvalidTask, OSError, UnsafePath):
            self._retired_quarantine_maintenance_error = True
            raise
        self._queue_visible_quarantine_promotion(
            record, visible_path=visible_path
        )
        return visible_path

    @staticmethod
    def _validate_quarantine_marker_path(
        marker_path: str, record: _RetiredQuarantineRecord
    ) -> None:
        try:
            descriptor = os.open(marker_path, os.O_RDONLY | _OPEN_FLAGS)
        except OSError as error:
            raise InvalidTask(
                "The retired-inode quarantine marker is unavailable."
            ) from error
        try:
            info = os.fstat(descriptor)
            data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
            if (
                _is_reparse(info)
                or not stat_module.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
            ):
                raise InvalidTask("The retired-inode quarantine marker is invalid.")
        finally:
            os.close(descriptor)
        marker = _parse_retired_quarantine_marker(os.path.basename(marker_path), data)
        expected_conflict = _bounded_retire_conflict_name(
            os.path.basename(record.original_path),
            os.path.basename(record.temporary_path),
        )
        if (
            marker is None
            or marker.get("temporary")
            != os.path.basename(record.temporary_path)
            or marker.get("target") != os.path.basename(record.original_path)
            or marker.get("conflict") != os.path.basename(record.conflict_path)
            or marker.get("conflict") != expected_conflict
            or marker.get("device_id") != record.device_id
            or marker.get("file_id") != record.file_id
            or marker.get("recorded_sha256") != record.recorded_sha256
            or marker.get("recorded_size_bytes") != record.recorded_size_bytes
            or marker.get("recorded_mtime_ns") != record.recorded_mtime_ns
            or marker.get("recorded_ctime_ns") != record.recorded_ctime_ns
            or marker.get("retain_unchanged") != record.retain_unchanged
            or marker.get("accounting_owner") != record.accounting_owner
        ):
            raise InvalidTask("The retired-inode quarantine marker is invalid.")

    @_serialize_retired_quarantine
    def _reserve_retired_quarantine(
        self,
        incoming_bytes: int,
        *,
        retain_unchanged: bool = False,
        retention_reservation: str | None = None,
    ) -> bool:
        if not isinstance(retain_unchanged, bool):
            raise InvalidTask("retain_unchanged must be a boolean.")
        if (
            retention_reservation is not None
            and retention_reservation not in self._retained_retirement_reservations
        ):
            raise InvalidTask("The retained retirement reservation is invalid.")
        reserved_elsewhere = len(self._retained_retirement_reservations) - (
            1 if retention_reservation is not None else 0
        )
        self.maintain_retired_quarantine()
        items: list[tuple[_RetiredQuarantineRecord, int]] = []
        for record in list(self._retired_quarantine.values()):
            size, interrupted = self._inspect_quarantine_record(record)
            if interrupted:
                self._promote_quarantine_record(record)
            else:
                items.append((record, size))
        for record in self._quarantine_promotion_candidates(
            items,
            now_ns=time.time_ns(),
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
            extra_entries=1 + reserved_elsewhere,
            extra_bytes=0 if retain_unchanged else incoming_bytes,
        ):
            key = _normcase(record.marker_path)
            if any(_normcase(path) == key for path in self._retired_quarantine):
                self._promote_quarantine_record(record)
        current: list[tuple[_RetiredQuarantineRecord, int]] = []
        for record in list(self._retired_quarantine.values()):
            size, interrupted = self._inspect_quarantine_record(record)
            if interrupted:
                self._promote_quarantine_record(record)
            else:
                current.append((record, size))
        current_bytes = sum(
            size for record, size in current if not record.retain_unchanged
        )
        return (
            len(current) + 1 + reserved_elsewhere
            <= self._retired_quarantine_max_entries
        ) and (
            retain_unchanged
            or current_bytes + incoming_bytes <= self._retired_quarantine_max_bytes
        )

    @_serialize_retired_quarantine
    def _quarantine_retired_file_target(
        self,
        target: str,
        retired: tuple[str, str, HashedRegularFile],
        original_path: str,
        current: HashedRegularFile,
        *,
        retain_unchanged: bool = False,
        retention_reservation: str | None = None,
        accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
    ) -> str | None:
        if not isinstance(retain_unchanged, bool):
            raise InvalidTask("retain_unchanged must be a boolean.")
        if accounting_owner not in _RETAINED_STORAGE_ACCOUNTS:
            raise InvalidTask("Invalid retained storage accounting owner.")
        temporary, marker, _initial = retired
        _validate_retire_marker_path(
            marker,
            temporary=os.path.basename(temporary),
            target=os.path.basename(target),
        )
        fingerprint = _path_fingerprint(temporary, source=True)
        if fingerprint is None:
            raise InvalidTask("The retired source disappeared before quarantine.")
        if (
            fingerprint.device_id != current.fingerprint.device_id
            or fingerprint.file_id != current.fingerprint.file_id
        ):
            raise InvalidTask("The retired workspace file changed identity.")
        if fingerprint != current.fingerprint and not (
            not _has_windows_change_time(fingerprint)
            and _has_windows_change_time(current.fingerprint)
            and _same_regular_state_after_rename(
                fingerprint, current.fingerprint
            )
        ):
            restored = self._restore_retired_file_target(target, retired)
            return str(Path(restored).relative_to(self.root)).replace(os.sep, "/")
        if not _has_windows_change_time(fingerprint):
            # A remote operation can lose ChangeTime access after its safe
            # preflight. Retain the last proven positive baseline; maintenance
            # will neither reclaim nor expose it until ChangeTime is readable
            # again, at which point genuine late-writer drift is detectable.
            fingerprint = current.fingerprint
        reserved = self._reserve_retired_quarantine(
            fingerprint.size_bytes,
            retain_unchanged=retain_unchanged,
            retention_reservation=retention_reservation,
        )
        if not reserved:
            if not retain_unchanged:
                restored = self._restore_retired_file_target(target, retired)
                return str(Path(restored).relative_to(self.root)).replace(os.sep, "/")
            raise RetentionCapacityUnavailable()
        conflict_name = _bounded_retire_conflict_name(
            os.path.basename(target), os.path.basename(temporary)
        )
        quarantined_at_ns = time.time_ns()
        marker_data = _retired_quarantine_marker_bytes(
            os.path.basename(temporary),
            os.path.basename(target),
            conflict_name,
            current,
            quarantined_at_ns,
            retain_unchanged=retain_unchanged,
            accounting_owner=accounting_owner,
        )
        try:
            _replace_private_marker_path(marker, marker_data)
        except BaseException:
            self._retired_quarantine_maintenance_error = True
            raise
        prefix = "/".join(split_relative(original_path)[:-1])
        relative_prefix = f"{prefix}/" if prefix else ""
        record = _RetiredQuarantineRecord(
            original_path=original_path,
            temporary_path=f"{relative_prefix}{os.path.basename(temporary)}",
            marker_path=f"{relative_prefix}{os.path.basename(marker)}",
            conflict_path=f"{relative_prefix}{conflict_name}",
            quarantined_at_ns=quarantined_at_ns,
            recorded_size_bytes=fingerprint.size_bytes,
            device_id=fingerprint.device_id,
            file_id=fingerprint.file_id,
            recorded_sha256=current.sha256,
            recorded_mtime_ns=fingerprint.mtime_ns,
            recorded_ctime_ns=fingerprint.ctime_ns,
            retain_unchanged=retain_unchanged,
            accounting_owner=accounting_owner,
        )
        self._retired_quarantine[_normcase(record.marker_path)] = record
        self._release_retained_retirement_slot(retention_reservation)
        promoted = self.maintain_retired_quarantine()
        return record.conflict_path if record.conflict_path in promoted else None

    def _finish_internal_retired_file_target(
        self,
        target: str,
        retired: tuple[str, str, HashedRegularFile],
        original_path: str,
    ) -> str | None:
        temporary, _marker, initial = retired
        current = _hash_existing_target(temporary)
        if current is None:
            raise InvalidTask("The retired workspace file disappeared before commit.")
        if current != initial:
            restored = self._restore_retired_file_target(target, retired)
            return str(Path(restored).relative_to(self.root)).replace(os.sep, "/")
        return self._quarantine_retired_file_target(
            target, retired, original_path, current
        )

    @_serialize_retired_quarantine
    def retained_retirement_capacity_available(self) -> bool:
        return (
            len(self._retired_quarantine)
            + len(self._retained_retirement_reservations)
            < self._retired_quarantine_max_entries
        )

    @_serialize_retired_quarantine
    def retained_storage_usage(self) -> RetainedStorageUsage:
        logical_bytes = 0
        allocated_bytes = 0
        additional_logical_bytes = 0
        materialized_row_logical_bytes = 0
        additional_allocated_bytes = 0
        materialized_row_allocated_bytes = 0
        owner_count = 0
        seen_identities: set[tuple[int, int]] = set()
        for record in self._retired_quarantine.values():
            marker = self._walk(_split_owned_relative(record.marker_path))
            self._validate_quarantine_marker_path(marker, record)
            candidates = (
                (_split_owned_relative(record.temporary_path)),
                split_relative(record.conflict_path),
                split_relative(
                    retired_quarantine_recovery_path(record.conflict_path)
                ),
            )
            for parts in candidates:
                target = self._optional_file_target(parts)
                if target is None:
                    continue
                try:
                    info = os.lstat(target)
                except OSError:
                    continue
                identity = (int(info.st_dev), int(info.st_ino))
                if (
                    _is_reparse(info)
                    or not stat_module.S_ISREG(info.st_mode)
                    or identity != (record.device_id, record.file_id)
                ):
                    continue
                if identity in seen_identities:
                    break
                seen_identities.add(identity)
                owner_count += 1
                logical_bytes += int(info.st_size)
                charged = _allocated_file_bytes(info)
                allocated_bytes += charged
                if (
                    record.accounting_owner
                    == RETAINED_STORAGE_ACCOUNT_MATERIALIZED_ROW
                ):
                    materialized_row_logical_bytes += int(info.st_size)
                    materialized_row_allocated_bytes += charged
                else:
                    additional_logical_bytes += int(info.st_size)
                    additional_allocated_bytes += charged
                break
        return RetainedStorageUsage(
            owner_count=owner_count,
            logical_bytes=logical_bytes,
            allocated_bytes=allocated_bytes,
            reservation_count=len(self._retained_retirement_reservations),
            additional_logical_bytes=additional_logical_bytes,
            materialized_row_logical_bytes=materialized_row_logical_bytes,
            additional_allocated_bytes=additional_allocated_bytes,
            materialized_row_allocated_bytes=materialized_row_allocated_bytes,
        )

    @_serialize_retired_quarantine
    def has_retained_retirement(self, path: str) -> bool:
        normalized = _normcase("/".join(split_relative(path)))
        return any(
            record.retain_unchanged
            and _normcase(record.original_path) == normalized
            for record in self._retired_quarantine.values()
        )

    def allocated_file_bytes(self, path: str) -> int:
        target = self._optional_file_target(split_relative(path))
        if target is None:
            return 0
        info = os.lstat(target)
        if _is_reparse(info):
            raise UnsafePath("The workspace path must be a regular file.")
        _regular_fingerprint(info, "The workspace path must be a regular file.")
        return _allocated_file_bytes(info)

    @_serialize_retired_quarantine
    def _reserve_retained_retirement_slot(self) -> str | None:
        if (
            len(self._retired_quarantine)
            + len(self._retained_retirement_reservations)
            >= self._retired_quarantine_max_entries
        ):
            return None
        token = uuid.uuid4().hex
        self._retained_retirement_reservations.add(token)
        return token

    @_serialize_retired_quarantine
    def _release_retained_retirement_slot(self, token: str | None) -> None:
        if token is not None:
            self._retained_retirement_reservations.discard(token)

    def retire_file(
        self,
        path: str,
        *,
        require_retention_capacity: bool = False,
        expected_file: HashedRegularFile | None = None,
        accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
    ) -> RetiredRegularFile | None:
        if not isinstance(require_retention_capacity, bool):
            raise InvalidTask("require_retention_capacity must be a boolean.")
        if expected_file is not None and not isinstance(expected_file, HashedRegularFile):
            raise InvalidTask("expected_file must be a HashedRegularFile.")
        if accounting_owner not in _RETAINED_STORAGE_ACCOUNTS:
            raise InvalidTask("Invalid retained storage accounting owner.")
        if require_retention_capacity and (
            expected_file is None
            or not _has_windows_change_time(expected_file.fingerprint)
        ):
            raise BlockingIOError(
                errno.EAGAIN,
                "Windows ChangeTime is unavailable for safe remote retirement.",
            )
        retention_reservation = (
            self._reserve_retained_retirement_slot()
            if require_retention_capacity
            else None
        )
        if require_retention_capacity and retention_reservation is None:
            raise RetentionCapacityUnavailable()
        try:
            parts = split_relative(path)
            target = self._optional_file_target(parts)
            if target is None:
                return None
            retired = self._retire_file_target(target, expected=expected_file)
            if retired is None:
                return None
            relative_parent = "/".join(parts[:-1])
            temporary_name = os.path.basename(retired[0])
            temporary_path = (
                f"{relative_parent}/{temporary_name}"
                if relative_parent
                else temporary_name
            )
            result = RetiredRegularFile(
                original_path=path,
                temporary_path=temporary_path,
                marker_path=f"{temporary_path}{STREAM_TEMP_MARKER_SUFFIX}",
                initial=retired[2],
                retention_reservation=retention_reservation,
                accounting_owner=accounting_owner,
            )
            retention_reservation = None
            return result
        finally:
            self._release_retained_retirement_slot(retention_reservation)

    def hash_retired_file(self, retired: RetiredRegularFile) -> HashedRegularFile:
        self._validate_retired_file(retired)
        marker = self._walk(_split_owned_relative(retired.marker_path))
        target = self._optional_file_target(
            _split_owned_relative(retired.temporary_path)
        )
        if target is None:
            raise InvalidTask("The retired workspace file disappeared before commit.")
        _validate_retire_marker_path(
            marker,
            temporary=os.path.basename(target),
            target=split_relative(retired.original_path)[-1],
        )
        opened = _open_regular_descriptor(target, missing_ok=True, source=True)
        if opened is None:
            raise InvalidTask("The retired workspace file disappeared before commit.")
        descriptor, _ = opened
        try:
            captured = _hash_open_regular_stable(
                descriptor, MAX_STREAM_FILE_BYTES
            )
            if _path_fingerprint(target, source=True) != captured.fingerprint:
                raise InvalidTask("The retired workspace file changed while hashing.")
            return captured
        finally:
            os.close(descriptor)

    def finish_retired_file(
        self,
        retired: RetiredRegularFile,
        *,
        preserve: bool = False,
        quarantine_unchanged: bool = True,
        tracked_handles_closed: bool = False,
        retain_unchanged: bool = False,
    ) -> str | None:
        self._validate_retired_file(retired)
        if (
            not isinstance(preserve, bool)
            or not isinstance(quarantine_unchanged, bool)
            or not isinstance(tracked_handles_closed, bool)
            or not isinstance(retain_unchanged, bool)
        ):
            raise InvalidTask("retire finalization flags must be booleans.")
        if retain_unchanged and (preserve or not quarantine_unchanged):
            raise InvalidTask(
                "retain_unchanged requires non-preserving quarantine finalization."
            )
        # Keep catalog transitions serialized without holding the lock while a
        # large retired file is hashed below.
        with self._retired_quarantine_lock:
            existing = next(
                (
                    record
                    for path, record in self._retired_quarantine.items()
                    if _normcase(path) == _normcase(retired.marker_path)
                ),
                None,
            )
            if existing is None:
                existing = self._load_retired_quarantine_record(retired)
            if existing is not None:
                if preserve:
                    result = self._promote_quarantine_record(existing)
                    self._release_retained_retirement_slot(
                        retired.retention_reservation
                    )
                    return result
                promoted = self.maintain_retired_quarantine()
                result = (
                    existing.conflict_path
                    if existing.conflict_path in promoted
                    else None
                )
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return result
        target = self._walk(split_relative(retired.original_path))
        temporary = self._walk(_split_owned_relative(retired.temporary_path))
        marker = self._walk(_split_owned_relative(retired.marker_path))
        internal = (temporary, marker, retired.initial)
        if preserve:
            restored = self._restore_retired_file_target(target, internal)
            result = str(Path(restored).relative_to(self.root)).replace(os.sep, "/")
            self._release_retained_retirement_slot(retired.retention_reservation)
            return result
        if retain_unchanged:
            current_fingerprint = _path_fingerprint(temporary, source=True)
            same_without_available_change_time = bool(
                current_fingerprint is not None
                and not _has_windows_change_time(current_fingerprint)
                and _has_windows_change_time(retired.initial.fingerprint)
                and _same_regular_state_after_rename(
                    current_fingerprint, retired.initial.fingerprint
                )
            )
            if (
                current_fingerprint != retired.initial.fingerprint
                and not same_without_available_change_time
            ):
                # Fingerprint drift is already sufficient to deny reclamation.
                # Restore visibly in O(1); the sync lane hashes/stages outside
                # the mount admission fence instead of blocking on 50 GiB.
                restored = self._restore_retired_file_target(target, internal)
                result = str(Path(restored).relative_to(self.root)).replace(
                    os.sep, "/"
                )
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return result
            current = retired.initial
        else:
            current = self.hash_retired_file(retired)
            if current != retired.initial:
                restored = self._restore_retired_file_target(target, internal)
                result = str(Path(restored).relative_to(self.root)).replace(
                    os.sep, "/"
                )
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return result
        if not quarantine_unchanged:
            _validate_retire_marker_path(
                marker,
                temporary=os.path.basename(temporary),
                target=os.path.basename(target),
            )
            # Windows sharing modes are the kernel-owned handle fence: an
            # incompatible live description makes this unlink retry/fail
            # instead of anonymously deleting writable bytes.
            _retry_sharing_violation(os.unlink, temporary)
            _retry_sharing_violation(os.unlink, marker)
            self._release_retained_retirement_slot(retired.retention_reservation)
            return None
        return self._quarantine_retired_file_target(
            target,
            internal,
            retired.original_path,
            current,
            retain_unchanged=retain_unchanged,
            retention_reservation=retired.retention_reservation,
            accounting_owner=retired.accounting_owner,
        )

    def finish_retired_file_by_fingerprint(
        self,
        retired: RetiredRegularFile,
        *,
        tracked_handles_closed: bool,
    ) -> bool | None:
        """Reclaim an unchanged retire under mount and Windows sharing fences.

        ``True`` means reclaimed, ``False`` means fingerprint drift or missing
        ChangeTime authority, and ``None`` means a live Windows sharing lease
        kept the last-link unlink busy. The caller can durably retain the quiet
        inode for a later RELEASE retry without confusing contention with a
        content conflict.
        """

        self._validate_retired_file(retired)
        if tracked_handles_closed is not True:
            raise UnsafePath(
                "Fingerprint retirement requires a tracked-handle cleanup fence."
            )
        temporary = self._walk(_split_owned_relative(retired.temporary_path))
        marker_path = self._walk(_split_owned_relative(retired.marker_path))
        with self._retired_quarantine_lock:
            existing = next(
                (
                    record
                    for path, record in self._retired_quarantine.items()
                    if _normcase(path) == _normcase(retired.marker_path)
                ),
                None,
            )
            if existing is None:
                existing = self._load_retired_quarantine_record(retired)
            if existing is not None:
                if not existing.retain_unchanged:
                    return False
                self._validate_quarantine_marker_path(marker_path, existing)
                expected = FileFingerprint(
                    size_bytes=existing.recorded_size_bytes,
                    mtime_ns=(
                        existing.recorded_mtime_ns
                        if existing.recorded_mtime_ns is not None
                        else -1
                    ),
                    ctime_ns=(
                        existing.recorded_ctime_ns
                        if existing.recorded_ctime_ns is not None
                        else -1
                    ),
                    device_id=existing.device_id,
                    file_id=existing.file_id,
                )
            else:
                _validate_retire_marker_path(
                    marker_path,
                    temporary=os.path.basename(temporary),
                    target=split_relative(retired.original_path)[-1],
                )
                expected = retired.initial.fingerprint
            if not _has_windows_change_time(expected):
                return False
            current = _path_fingerprint(temporary, source=True)
            if current is not None and not _has_windows_change_time(current):
                return None
            if current != expected:
                return False
            try:
                _retry_sharing_violation(os.unlink, temporary)
            except OSError as error:
                if _is_retryable_sharing_error(error):
                    return None
                raise InvalidTask(
                    "The retired workspace file could not be finalized."
                ) from error
            try:
                _retry_sharing_violation(os.unlink, marker_path)
            except OSError:
                # The content inode is already reclaimed; a marker-only retry
                # is harmless and startup recovery removes it once the sharing
                # lease clears. Do not misreport a completed last-link unlink.
                self._retired_marker_cleanup.add(_normcase(marker_path))
                self._stream_recovery_scan = None
                self._stream_recovery_retry_required = True
                self.stream_recovery_pending = True
            else:
                self._retired_marker_cleanup.discard(_normcase(marker_path))
            if existing is not None:
                self._retired_quarantine.pop(
                    next(
                        (
                            path
                            for path in self._retired_quarantine
                            if _normcase(path) == _normcase(existing.marker_path)
                        ),
                        existing.marker_path,
                    ),
                    None,
                )
                self._retired_quarantine_visible_promotions = [
                    item
                    for item in self._retired_quarantine_visible_promotions
                    if _normcase(item.marker_path) != _normcase(existing.marker_path)
                ]
            self._release_retained_retirement_slot(retired.retention_reservation)
            return True

    def _load_retired_quarantine_record(
        self, retired: RetiredRegularFile
    ) -> _RetiredQuarantineRecord | None:
        marker_path = self._walk(_split_owned_relative(retired.marker_path))
        try:
            descriptor = os.open(marker_path, os.O_RDONLY | _OPEN_FLAGS)
        except FileNotFoundError:
            return None
        try:
            data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
            info = os.fstat(descriptor)
            if (
                len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
                or _is_reparse(info)
                or not stat_module.S_ISREG(info.st_mode)
                or info.st_nlink != 1
            ):
                return None
        finally:
            os.close(descriptor)
        marker = _parse_retired_quarantine_marker(os.path.basename(marker_path), data)
        if marker is None:
            return None
        if str(marker["conflict"]) != _bounded_retire_conflict_name(
            str(marker["target"]), str(marker["temporary"])
        ):
            raise InvalidTask("The retired-inode quarantine marker is invalid.")
        prefix = "/".join(split_relative(retired.original_path)[:-1])
        relative_prefix = f"{prefix}/" if prefix else ""
        record = _RetiredQuarantineRecord(
            original_path=retired.original_path,
            temporary_path=f"{relative_prefix}{marker['temporary']}",
            marker_path=retired.marker_path,
            conflict_path=f"{relative_prefix}{marker['conflict']}",
            quarantined_at_ns=int(marker["quarantined_at_ns"]),
            recorded_size_bytes=int(marker["recorded_size_bytes"]),
            device_id=int(marker["device_id"]),
            file_id=int(marker["file_id"]),
            recorded_sha256=marker["recorded_sha256"],
            recorded_mtime_ns=marker["recorded_mtime_ns"],
            recorded_ctime_ns=marker["recorded_ctime_ns"],
            retain_unchanged=bool(marker["retain_unchanged"]),
            accounting_owner=str(marker["accounting_owner"]),
        )
        if (
            _normcase(record.temporary_path) != _normcase(retired.temporary_path)
            or record.accounting_owner != retired.accounting_owner
        ):
            raise InvalidTask("The retired-inode quarantine marker is invalid.")
        self._retired_quarantine[_normcase(record.marker_path)] = record
        return record

    @staticmethod
    def _validate_retired_file(retired: RetiredRegularFile) -> None:
        if not isinstance(retired, RetiredRegularFile):
            raise InvalidTask("retired must be a RetiredRegularFile.")
        if retired.accounting_owner not in _RETAINED_STORAGE_ACCOUNTS:
            raise InvalidTask("Invalid retained storage accounting owner.")
        original = split_relative(retired.original_path)
        temporary = _split_owned_relative(retired.temporary_path)
        marker = _split_owned_relative(retired.marker_path)
        if (
            temporary[:-1] != original[:-1]
            or marker[:-1] != original[:-1]
            or not (
                _owned_temporary_kind(temporary[-1]) == "retire"
                or _legacy_owned_temporary_for_target(
                    temporary[-1], original[-1]
                )
            )
            or marker[-1] != temporary[-1] + STREAM_TEMP_MARKER_SUFFIX
        ):
            raise InvalidTask("The retired workspace token is invalid.")

    def rename_file(
        self,
        source: str,
        destination: str,
        *,
        expected_sha256: str,
        create_parents: bool = False,
    ) -> None:
        """Optimistically guarded, no-copy, no-clobber regular-file rename."""
        if not isinstance(expected_sha256, str) or not TAGGED_SHA256_RE.fullmatch(
            expected_sha256
        ):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        source_parts = split_relative(source)
        destination_parts = split_relative(destination)
        source_target = self._optional_file_target(source_parts)
        if source_target is None:
            raise InvalidTask("The rename source does not exist.")
        preflight = _hash_existing_target(source_target)
        if preflight is None:
            raise InvalidTask("The rename source does not exist.")
        if preflight.tagged_sha256 != expected_sha256:
            raise InvalidTask("The rename source digest does not match expected_sha256.")
        if source_parts == destination_parts:
            return
        destination_target = self._walk(destination_parts, create=create_parents)
        destination_fingerprint = _path_fingerprint(destination_target)
        same_file = destination_fingerprint == preflight.fingerprint
        same_parent = _normcase(os.path.dirname(source_target)) == _normcase(
            os.path.dirname(destination_target)
        )
        if destination_fingerprint is not None and not (same_file and same_parent):
            raise UnsafePath("The rename destination already exists.")
        current = _hash_existing_target(source_target)
        if current is None or current.tagged_sha256 != expected_sha256:
            raise InvalidTask("The rename source changed before commit.")
        if same_file:
            temporary = os.path.join(
                os.path.dirname(source_target),
                _owned_temporary_name("rename"),
            )
            moved = False
            try:
                _retry_sharing_violation(os.rename, source_target, temporary)
                moved = True
                _retry_sharing_violation(os.rename, temporary, destination_target)
                moved = False
            finally:
                if moved:
                    try:
                        _retry_sharing_violation(os.rename, temporary, source_target)
                    except OSError:
                        pass
        else:
            _retry_sharing_violation(os.rename, source_target, destination_target)

    def remove_file(
        self,
        path: str,
        *,
        expected_sha256: str | None = None,
        expected_fingerprint: FileFingerprint | None = None,
    ) -> bool:
        """Remove one file with an optional content-and-identity CAS guard."""

        if (expected_sha256 is None) != (expected_fingerprint is None):
            raise InvalidTask(
                "expected_sha256 and expected_fingerprint must be supplied together."
            )
        if expected_sha256 is not None and not TAGGED_SHA256_RE.fullmatch(
            expected_sha256
        ):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        if expected_fingerprint is not None and not isinstance(
            expected_fingerprint, FileFingerprint
        ):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        target = self._walk(split_relative(path))
        if expected_sha256 is not None:
            retired = self._retire_file_target(target)
            if retired is None:
                return False
            if (
                retired[2].tagged_sha256 != expected_sha256
                or retired[2].fingerprint.device_id
                != expected_fingerprint.device_id
                or retired[2].fingerprint.file_id != expected_fingerprint.file_id
            ):
                self._restore_retired_file_target(target, retired)
                raise InvalidTask("The workspace file changed before removal.")
            self._finish_internal_retired_file_target(target, retired, path)
            return True
        for attempt in range(_SHARING_RETRIES):
            try:
                # removes a link itself, never what it points at
                os.unlink(target)
                return True
            except FileNotFoundError:
                return False
            except OSError as error:
                if (
                    not _is_retryable_sharing_error(error)
                    or attempt == _SHARING_RETRIES - 1
                ):
                    raise UnsafePath(
                        "The workspace file could not be removed safely."
                    ) from error
                time.sleep(_SHARING_BACKOFF_SECONDS * (attempt + 1))
        raise AssertionError("unreachable")  # pragma: no cover

    def remove_tree(self, path: str) -> None:
        parts = split_relative(path)
        try:
            directory = self._directory(parts)
        except UnsafePath:
            return
        children: list[tuple[str, bool]] = []
        try:
            for name in os.listdir(directory):
                try:
                    info = os.lstat(os.path.join(directory, name))
                except OSError:
                    continue
                children.append(
                    (name, stat_module.S_ISDIR(info.st_mode) and not _is_reparse(info))
                )
        except OSError:
            return
        for name, is_directory in children:
            child = f"{'/'.join(parts)}/{name}"
            self.remove_tree(child) if is_directory else self.remove_file(child)
        try:
            _retry_sharing_violation(os.rmdir, directory)
        except OSError:
            pass

    def make_directory(self, path: str) -> None:
        parts = split_relative(path)
        target = self._walk(parts, create=True)
        try:
            os.mkdir(target)
        except FileExistsError:
            pass

    def absolute(self, path: str, allow_root: bool = False) -> Path:
        parts = split_relative(path, allow_root=allow_root)
        self._canonical_check(parts)
        return Path(os.path.join(str(self.root), *parts))


# ------------------------------------------------------------------ host scope

# Reads must never surface credential material. Windows' classic stores: the
# registry hives with password hashes, DPAPI master keys, Credential Manager
# vaults, and sshd host keys.
def _default_denied_prefixes() -> tuple[str, ...]:
    system_root = os.environ.get("SystemRoot", r"C:\Windows")
    app_data = os.environ.get("APPDATA", "")
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    program_data = os.environ.get("ProgramData", r"C:\ProgramData")
    candidates = [
        os.path.join(system_root, "System32", "config"),
        os.path.join(program_data, "ssh"),
    ]
    if app_data:
        candidates.append(os.path.join(app_data, "Microsoft", "Protect"))
        candidates.append(os.path.join(app_data, "Microsoft", "Credentials"))
    if local_app_data:
        candidates.append(os.path.join(local_app_data, "Microsoft", "Credentials"))
        candidates.append(os.path.join(local_app_data, "Microsoft", "Vault"))
    return tuple(candidates)


def host_denied_prefixes(meshia_home: Path | str) -> tuple[str, ...]:
    """The node's own state is never readable through host scope."""
    return (str(Path(meshia_home).expanduser()),) + _default_denied_prefixes()


def map_host_path(path: str) -> str:
    """Translate the protocol's POSIX-shaped host path to a Windows path.

    ``/c/Users/name`` → ``C:\\Users\\name``. The wire contract stays absolute,
    forward-slashed, and traversal-free on every platform; only the node knows
    it is addressing a drive. Pure, so it is unit-testable anywhere.
    """
    if not isinstance(path, str) or "\0" in path:
        raise UnsafePath("Host-scope paths must be NUL-free strings.")
    if len(path.encode("utf-8")) > MAX_PATH_BYTES:
        raise UnsafePath("Host-scope paths must be at most 4096 bytes.")
    if "\\" in path:
        raise UnsafePath("Host-scope paths use forward slashes, e.g. /c/Users/name.")
    match = _HOST_DRIVE_RE.match(path)
    if not match:
        raise UnsafePath(
            "Host-scope paths must be absolute and start with a drive component, "
            "e.g. /c/Users/name."
        )
    drive, rest = match.group(1), match.group(2) or ""
    if any(part in ("", ".", "..") for part in rest.split("/")) and rest:
        raise UnsafePath("Host-scope paths cannot contain empty, dot, or parent components.")
    tail = rest.replace("/", "\\")
    return f"{drive.upper()}:\\{tail}" if tail else f"{drive.upper()}:\\"


def _reject_denied(resolved: str, denied_prefixes: Iterable[str], message: str) -> None:
    target = _normcase(resolved)
    for prefix in denied_prefixes:
        canonical = _normcase(
            os.path.realpath(prefix) if os.path.exists(prefix) else prefix
        ).rstrip("\\")
        if target == canonical or target.startswith(canonical + "\\"):
            raise UnsafePath(message)


def _host_target(path: str, denied_prefixes: Iterable[str]) -> str:
    resolved = os.path.realpath(map_host_path(path))
    _reject_denied(
        resolved, denied_prefixes, "That host path is not readable by the Meshia node."
    )
    return resolved


def host_read_file(
    path: str, max_bytes: int, denied_prefixes: Iterable[str] = ()
) -> tuple[bytes, bool]:
    """Read-only, reparse-checked read of an absolute host path."""
    if not 1 <= max_bytes <= MAX_READ_BYTES:
        raise InvalidTask("read_file max_bytes is outside the allowed range.")
    target = _host_target(path, denied_prefixes)
    try:
        info = os.lstat(target)
    except OSError as error:
        raise UnsafePath("The host file cannot be opened safely.") from error
    if _is_reparse(info) or not stat_module.S_ISREG(info.st_mode):
        raise UnsafePath("Host-scope read_file accepts regular files only.")
    try:
        descriptor = os.open(target, os.O_RDONLY | _OPEN_FLAGS)
    except OSError as error:
        raise UnsafePath("The host file cannot be opened safely.") from error
    try:
        data = b""
        while len(data) <= max_bytes:
            chunk = os.read(descriptor, max_bytes + 1 - len(data))
            if not chunk:
                break
            data += chunk
        return data[:max_bytes], len(data) > max_bytes
    finally:
        os.close(descriptor)


def host_list(
    path: str, max_entries: int, denied_prefixes: Iterable[str] = ()
) -> tuple[list[str], bool]:
    """Read-only directory listing of an absolute host path."""
    if not 1 <= max_entries <= MAX_LIST_ENTRIES:
        raise InvalidTask("list max_entries is outside the allowed range.")
    target = _host_target(path, denied_prefixes)
    try:
        names = sorted(os.listdir(target))
    except OSError as error:
        raise UnsafePath("The host directory cannot be opened safely.") from error
    truncated = len(names) > max_entries
    return names[:max_entries], truncated


def host_write_file(
    path: str,
    data: bytes,
    denied_prefixes: Iterable[str] = (),
    *,
    expected_sha256: str | None = None,
) -> str:
    """Atomically write an absolute host path. **`full` access mode only.**

    The caller gates on the live access mode; this is the mechanism. It keeps
    the POSIX discipline: bounded size, optional compare-and-swap, a refusal
    to touch anything that is not a single-link regular file, and a sibling
    temporary published with ``os.replace`` so a failed write never truncates
    the destination.
    """
    if not isinstance(data, bytes):  # pragma: no cover - callers encode first
        raise InvalidTask("Host-scope write_file content must be bytes.")
    if len(data) > MAX_HOST_WRITE_BYTES:
        raise InvalidTask("Host-scope write_file content must be at most 1 MiB.")
    if expected_sha256 is not None and not TAGGED_SHA256_RE.match(expected_sha256):
        raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
    mapped = map_host_path(path)
    directory, name = os.path.split(mapped.rstrip("\\"))
    if not name or name in (".", ".."):
        raise UnsafePath("Host-scope write_file needs a file name, not a directory.")
    parent_path = os.path.realpath(directory or "\\")
    target = os.path.join(parent_path, name)
    _reject_denied(
        target, denied_prefixes, "That host path is not writable by the Meshia node."
    )
    try:
        parent_info = os.lstat(parent_path)
    except OSError as error:
        raise UnsafePath("The host directory cannot be opened safely.") from error
    if not stat_module.S_ISDIR(parent_info.st_mode):
        raise UnsafePath("The host directory cannot be opened safely.")

    existing = _existing_regular_file(target, MAX_HOST_WRITE_BYTES)
    if existing is None:
        if expected_sha256 is not None:
            raise InvalidTask("expected_sha256 requires an existing destination.")
    elif expected_sha256 is not None and f"sha256:{sha256_hex(existing)}" != expected_sha256.lower():
        raise InvalidTask("The destination digest does not match expected_sha256.")
    try:
        _atomic_publish(parent_path, name, data)
    except UnsafePath:
        raise
    except OSError as error:
        raise UnsafePath("The host destination is not writable.") from error
    return target


# ------------------------------------------------------------------- internals


def _read_blocked_retire_target_path(
    marker_path: str, marker_info: os.stat_result | None
) -> str | None:
    if marker_info is None:
        return None
    try:
        descriptor = os.open(marker_path, os.O_RDONLY | _OPEN_FLAGS)
    except OSError:
        return None
    try:
        data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
        opened = os.fstat(descriptor)
        if (
            len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
            or _is_reparse(opened)
            or not stat_module.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or opened.st_dev != marker_info.st_dev
            or opened.st_ino != marker_info.st_ino
        ):
            return None
    finally:
        os.close(descriptor)
    marker = _parse_retire_temp_marker(os.path.basename(marker_path), data)
    return str(marker["target"]) if marker is not None else None


def _validate_retire_marker_path(
    marker_path: str, *, temporary: str, target: str
) -> None:
    try:
        descriptor = os.open(marker_path, os.O_RDONLY | _OPEN_FLAGS)
    except OSError as error:
        raise InvalidTask("The retired workspace owner marker is unavailable.") from error
    try:
        info = os.fstat(descriptor)
        data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
        if (
            _is_reparse(info)
            or not stat_module.S_ISREG(info.st_mode)
            or info.st_nlink != 1
            or len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
        ):
            raise InvalidTask("The retired workspace owner marker is invalid.")
    finally:
        os.close(descriptor)
    marker = _parse_retire_temp_marker(os.path.basename(marker_path), data)
    if (
        marker is None
        or marker.get("temporary") != temporary
        or marker.get("target") != target
    ):
        raise InvalidTask("The retired workspace owner marker is invalid.")


def _recover_retired_marker_path(
    marker_path: str, marker: dict[str, object]
) -> bool:
    parent = os.path.dirname(marker_path)
    temporary = os.path.join(parent, str(marker["temporary"]))
    target = os.path.join(parent, str(marker["target"]))
    try:
        temp_info = os.lstat(temporary)
    except FileNotFoundError:
        try:
            os.unlink(marker_path)
            return True
        except OSError:
            return False
    except OSError:
        return False
    if (
        _is_reparse(temp_info)
        or not stat_module.S_ISREG(temp_info.st_mode)
        or temp_info.st_nlink not in (1, 2)
    ):
        return False
    conflict = os.path.join(
        parent,
        _bounded_retire_conflict_name(
            os.path.basename(target), os.path.basename(temporary)
        ),
    )
    if temp_info.st_nlink == 2:
        restored: str | None = None
        for candidate in (target, conflict):
            try:
                candidate_info = os.lstat(candidate)
            except OSError:
                continue
            if (
                not _is_reparse(candidate_info)
                and stat_module.S_ISREG(candidate_info.st_mode)
                and candidate_info.st_dev == temp_info.st_dev
                and candidate_info.st_ino == temp_info.st_ino
                and candidate_info.st_nlink == 2
            ):
                restored = candidate
                break
        if restored is None:
            return False
        try:
            _retry_sharing_violation(os.unlink, temporary)
            _retry_sharing_violation(os.unlink, marker_path)
            return True
        except OSError:
            return False
    try:
        _move_no_clobber(temporary, target)
    except FileExistsError:
        try:
            _move_no_clobber(temporary, conflict)
        except OSError:
            return False
    except OSError:
        return False
    try:
        _retry_sharing_violation(os.unlink, marker_path)
        return True
    except OSError:
        return False


def _path_fingerprint(target: str, *, source: bool = False) -> FileFingerprint | None:
    try:
        info = os.lstat(target)
    except FileNotFoundError:
        return None
    except OSError as error:
        noun = "source" if source else "destination"
        raise UnsafePath(f"The {noun} cannot be inspected safely.") from error
    if _is_reparse(info):
        noun = "source" if source else "destination"
        raise UnsafePath(f"The {noun} cannot be inspected safely.")
    message = (
        "The source must be a single-link regular file."
        if source
        else "The destination must be a single-link regular file."
    )
    inspected = _regular_fingerprint(info, message)
    if not _uses_windows_change_time():
        return inspected
    try:
        descriptor = os.open(target, os.O_RDONLY | _OPEN_FLAGS)
    except FileNotFoundError:
        return None
    except OSError as error:
        noun = "source" if source else "destination"
        raise UnsafePath(f"The {noun} cannot be inspected safely.") from error
    try:
        opened = _regular_fingerprint_from_descriptor(descriptor, message)
        # A final-component replacement between lstat and open must never
        # inherit the first path's authority. ChangeTime itself may advance,
        # but byte-visible state and file identity must still be exact.
        if not _same_regular_state_after_rename(inspected, opened):
            raise InvalidTask(
                "The workspace file changed while it was being inspected."
            )
        return opened
    finally:
        os.close(descriptor)


def _open_regular_descriptor(
    target: str, *, missing_ok: bool, source: bool = False,
    writable: bool = False, share_delete: bool = False,
) -> tuple[int, FileFingerprint] | None:
    before = _path_fingerprint(target, source=source)
    if before is None:
        if missing_ok:
            return None
        noun = "source" if source else "destination"
        raise UnsafePath(f"The {noun} cannot be opened safely.")
    try:
        # A timestamp update uses SetFileTime and FlushFileBuffers on this same
        # handle; Windows requires write access for these metadata operations.
        access = os.O_RDWR if writable else os.O_RDONLY
        descriptor = (
            _open_windows_mount_stage(target, create=False, writable=writable)
            if share_delete and sys.platform == "win32"
            else os.open(target, access | _OPEN_FLAGS)
        )
    except FileNotFoundError:
        if missing_ok:
            return None
        noun = "source" if source else "destination"
        raise UnsafePath(f"The {noun} cannot be opened safely.") from None
    except OSError as error:
        noun = "source" if source else "destination"
        raise UnsafePath(f"The {noun} cannot be opened safely.") from error
    try:
        message = (
            "The source must be a single-link regular file."
            if source
            else "The destination must be a single-link regular file."
        )
        opened = _regular_fingerprint_from_descriptor(descriptor, message)
        # Detect a final-component replacement between lstat and open.  This is
        # the closest portable equivalent to POSIX O_NOFOLLOW on Windows.
        if opened != before:
            raise InvalidTask("The workspace file changed while it was being opened.")
        return descriptor, opened
    except BaseException:
        os.close(descriptor)
        raise


def _hash_existing_target(target: str) -> HashedRegularFile | None:
    opened = _open_regular_descriptor(target, missing_ok=True)
    if opened is None:
        return None
    descriptor, _ = opened
    try:
        hashed = _hash_open_regular_stable(descriptor, MAX_STREAM_FILE_BYTES)
        if _path_fingerprint(target) != hashed.fingerprint:
            raise InvalidTask("The destination changed during compare-and-swap.")
        return hashed
    finally:
        os.close(descriptor)


def _existing_regular_file(target: str, limit: int) -> bytes | None:
    """Read the destination, refusing reparse points and multiply-linked files."""
    try:
        info = os.lstat(target)
    except FileNotFoundError:
        return None
    except OSError as error:
        raise UnsafePath("The destination cannot be inspected safely.") from error
    if _is_reparse(info):
        raise UnsafePath("The destination cannot be inspected safely.")
    if not stat_module.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise UnsafePath("The destination must be a single-link regular file.")
    try:
        descriptor = os.open(target, os.O_RDONLY | _OPEN_FLAGS)
    except OSError as error:
        raise UnsafePath("The destination cannot be inspected safely.") from error
    try:
        chunks: list[bytes] = []
        while True:
            chunk = os.read(descriptor, 262_144)
            if not chunk:
                break
            chunks.append(chunk)
            if sum(len(part) for part in chunks) > limit:
                raise InvalidTask(
                    f"The destination exceeds the {limit // (1024 * 1024)} MiB inspection limit."
                )
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def _atomic_publish(parent: str, name: str, data: bytes) -> None:
    """Durable sibling temporary, then ``os.replace`` (atomic on NTFS)."""
    temporary = os.path.join(parent, _owned_temporary_name("write"))
    descriptor = os.open(
        temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _OPEN_FLAGS
    )
    published = False
    try:
        try:
            view = memoryview(data)
            while view:
                written = os.write(descriptor, view)
                if written <= 0:
                    raise InvalidTask("Writing the file made no progress.")
                view = view[written:]
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        _retry_sharing_violation(os.replace, temporary, os.path.join(parent, name))
        published = True
    finally:
        if not published:
            try:
                os.unlink(temporary)
            except OSError:
                pass


__all__ = [
    "WindowsWorkspaceBoundary",
    "host_denied_prefixes",
    "host_list",
    "host_read_file",
    "host_write_file",
    "map_host_path",
]
