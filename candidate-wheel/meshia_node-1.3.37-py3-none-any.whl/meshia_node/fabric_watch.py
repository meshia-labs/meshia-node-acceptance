"""Bounded, cross-platform collection of local Fabric file changes.

This module deliberately stops at the local filesystem boundary.  Watcher
threads collect and coalesce paths; they never perform network I/O. The
synchronization coordinator drains the resulting events and owns all expensive
or durable work. A deliberately throttled content reconciler hashes at most a
small global byte budget per interval. It is only a safety net for native-event
loss and filesystems whose metadata can be restored after an in-place edit.

Packaged installs require ``watchdog`` so native FSEvents, inotify, and
ReadDirectoryChangesW collection is the default.  The import and backend start
remain guarded as a fail-safe for damaged/minimal environments: a conservative,
dependency-free ``os.scandir`` fallback compares metadata and shares the same
throttled content safety pass. The fallback waits for two identical observations
before reporting a put and two complete observations before reporting a delete.
Unsupported local items are isolated as bounded per-path health issues and
masked from mutation generation so valid siblings keep syncing. Backend event
loss and bounded event-queue overflow still fail closed and ask the coordinator
for authoritative reconciliation instead of trusting partial observations.
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import stat
import sys
import threading
import time
import unicodedata
import uuid
from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Literal, Mapping

from .errors import StateError, UnsafePath
from .fabric_native_watch import (
    attach_fsevents_loss_hook,
    configure_observer_ingress,
    native_backend_name,
    observer_ingress_snapshot,
    reset_observer_loss,
)
from .util import directory_entry_identity_stat
from .workspace import split_relative

try:  # Required in packages; guarded so the scanner remains a recovery fallback.
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer
    from watchdog.observers.api import EventDispatcher
    try:
        from watchdog.observers.kqueue import KqueueObserver
    except (ImportError, AttributeError):  # unavailable off BSD/macOS
        KqueueObserver = None  # type: ignore[assignment,misc]
except ImportError:  # pragma: no cover - fail-safe outside an intact packaged install
    FileSystemEventHandler = object  # type: ignore[assignment,misc]
    Observer = None  # type: ignore[assignment,misc]
    EventDispatcher = None  # type: ignore[assignment,misc]
    KqueueObserver = None  # type: ignore[assignment,misc]


class RemoteApplyDeferred(StateError):
    """Watcher recovery or bounded admission must finish before remote CAS."""


DEFAULT_DEBOUNCE_SECONDS = 0.300
DEFAULT_SCAN_INTERVAL_SECONDS = 0.750
DEFAULT_MAX_PENDING_EVENTS = 8_192
DEFAULT_MAX_LOCAL_ISSUES = 256
# Match the server namespace ceiling. A lower local cap turns every recovery
# scan of an otherwise valid workspace into permanent overflow.
DEFAULT_MAX_SCAN_ENTRIES = 250_000
DEFAULT_SUPPRESSION_SECONDS = 2.0
DEFAULT_CONTENT_RECONCILE_INTERVAL_SECONDS = 15.0
DEFAULT_CONTENT_RECONCILE_BYTES = 8 * 1024 * 1024
DEFAULT_CONTENT_RECONCILE_FILES = 64
# A packaged native backend is the low-latency authority. Full-tree walks are a
# coarse corruption scrub, not its normal change detector. Liveness is checked
# separately so lengthening this cadence never hides a dead native collector.
DEFAULT_NATIVE_HEALTH_SCRUB_SECONDS = 10 * 60.0
DEFAULT_NATIVE_HEALTH_SCRUB_JITTER = 0.20
DEFAULT_NATIVE_COLLECTOR_HEALTH_SECONDS = 5.0
DEFAULT_NATIVE_SCAN_MAX_DUTY = 0.05
DEFAULT_FALLBACK_SCAN_MAX_DUTY = 0.20
# Watchdog's macOS FSEvents observer can return successfully from ``start``
# before its emitter reports that the stream could not be created. Give the
# emitter one short, bounded startup window so that state never advertises a
# dead native collector for an entire safety-scan interval.
_NATIVE_START_HEALTH_SECONDS = 0.250
DEFAULT_REMOTE_APPLY_ARM_SECONDS = 300.0
DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS = 60.0
DEFAULT_MAX_REMOTE_APPLIES = 4_096
_CONTENT_READ_BYTES = 256 * 1024
_INVALID_FILE_STATE = object()
_MESHIA_TEMP_NAME = re.compile(
    r"^\..+\.meshia-(?:rename-)?[0-9a-f]{32}(?:\.owner)?$"
)
_MACOS_ROOT_ICON_BOOKKEEPING = "Icon\r"

ChangeKind = Literal["put", "delete", "rename"]


@dataclass(frozen=True)
class FabricWatchEvent:
    """One normalized workspace mutation.

    ``path`` is the destination for a rename. ``source_path`` is populated only
    for renames. All paths use forward slashes regardless of host platform.
    """

    kind: ChangeKind
    path: str
    source_path: str | None = None


@dataclass(frozen=True, slots=True)
class FabricWatchRecovery:
    """Watermark for one bounded overflow-recovery scan."""

    generation: int
    through_sequence: int


@dataclass(frozen=True, slots=True)
class FabricWatchHealth:
    """Cheap immutable collector state for status/readiness reporting."""

    backend: str
    using_native: bool
    collector_healthy: bool
    reconciliation_needed: bool
    ingress_queue_depth: int
    ingress_queue_capacity: int
    last_loss_or_error: str | None
    local_issues: tuple["FabricWatchIssue", ...]
    local_issues_saturated: bool


@dataclass(frozen=True, slots=True, order=True)
class FabricWatchIssue:
    """One unsupported local item isolated from the portable namespace."""

    code: str
    path: str


@dataclass(frozen=True, slots=True)
class _MetadataSnapshot:
    files: dict[str, "_Fingerprint"]
    complete: bool
    namespace_entries: int
    issues: tuple[FabricWatchIssue, ...]
    issues_saturated: bool
    masked_prefixes: frozenset[str]

    def __iter__(self) -> Iterable[object]:
        # Retain the narrow private-test/debug unpacking contract.
        yield self.files
        yield self.complete
        yield self.namespace_entries


def _bounded_issue_path(path: str) -> str:
    """Bound health memory while keeping ordinary paths exact and stable."""

    if len(path) <= 512:
        return path
    raw = path.encode("utf-8", "surrogatepass")
    suffix = hashlib.blake2b(raw, digest_size=12, person=b"meshia-issue").hexdigest()
    return f"{path[:480]}…#{suffix}"


def _path_is_masked(path: str, prefixes: set[str] | frozenset[str]) -> bool:
    if not prefixes:
        return False
    if "." in prefixes:
        return True
    candidate = path
    while True:
        if candidate in prefixes:
            return True
        separator = candidate.rfind("/")
        if separator < 0:
            return False
        candidate = candidate[:separator]


def _lexical_relative(root: Path, path: Path | str) -> str | None:
    """Return an exact in-root spelling without making it portable or following it."""

    try:
        raw = os.fspath(path)
    except TypeError:
        return None
    if not raw or "\0" in raw:
        return None
    candidate = Path(raw)
    if not candidate.is_absolute():
        if "\\" in raw or raw.startswith("~"):
            return None
        components = raw.split("/")
        if any(component in ("", ".", "..") for component in components):
            return None
        candidate = root.joinpath(*components)
    absolute = Path(os.path.abspath(os.fspath(candidate)))
    try:
        if os.path.commonpath((os.fspath(root), os.fspath(absolute))) != os.fspath(root):
            return None
        return absolute.relative_to(root).as_posix()
    except ValueError:
        return None


class _IssueAccumulator:
    def __init__(self, capacity: int) -> None:
        self.capacity = capacity
        self.issues: dict[tuple[str, str], FabricWatchIssue] = {}
        self.masked_prefixes: set[str] = set()
        self.saturated = False

    def add(self, code: str, path: str, *, mask: bool = True) -> None:
        bounded_path = _bounded_issue_path(path)
        key = (code, bounded_path)
        if key not in self.issues:
            if len(self.issues) >= self.capacity:
                self.saturated = True
                return
            self.issues[key] = FabricWatchIssue(code, bounded_path)
        if mask:
            self.masked_prefixes.add(path)

    def snapshot(
        self, files: dict[str, "_Fingerprint"], complete: bool, entries: int
    ) -> _MetadataSnapshot:
        return _MetadataSnapshot(
            files,
            complete and not self.saturated,
            entries,
            tuple(sorted(self.issues.values())),
            self.saturated,
            frozenset(self.masked_prefixes),
        )


@dataclass
class _PendingEvent:
    event: FabricWatchEvent
    observed_at: float
    sequence: int
    rename_contains_put: bool = False
    active: bool = True


@dataclass(frozen=True, slots=True)
class _Fingerprint:
    size: int
    mtime_ns: int
    ctime_ns: int
    inode: int
    device: int


@dataclass
class _ContentProbe:
    path: str
    fingerprint: _Fingerprint
    offset: int
    hasher: object


@dataclass(frozen=True)
class _ExpectedPostState:
    fingerprint: _Fingerprint
    sha256: bytes | None = None


@dataclass
class _RemoteApply:
    token: str
    paths: tuple[str, ...]
    armed_sequence: int
    phase: Literal["armed", "committed"]
    expires_at: float
    expected: dict[str, _ExpectedPostState | None]


class FabricWatch:
    """Collect local workspace changes without doing synchronization work.

    The public ``record_*`` methods also make the normalization/coalescing
    layer independently testable and let platform adapters feed events without
    depending on watchdog's concrete event classes.
    """

    def __init__(
        self,
        root: Path | str,
        *,
        debounce_seconds: float = DEFAULT_DEBOUNCE_SECONDS,
        scan_interval_seconds: float = DEFAULT_SCAN_INTERVAL_SECONDS,
        max_pending_events: int = DEFAULT_MAX_PENDING_EVENTS,
        max_local_issues: int = DEFAULT_MAX_LOCAL_ISSUES,
        max_scan_entries: int = DEFAULT_MAX_SCAN_ENTRIES,
        content_reconcile_interval_seconds: float = (
            DEFAULT_CONTENT_RECONCILE_INTERVAL_SECONDS
        ),
        content_reconcile_bytes: int = DEFAULT_CONTENT_RECONCILE_BYTES,
        content_reconcile_files: int = DEFAULT_CONTENT_RECONCILE_FILES,
        max_remote_applies: int = DEFAULT_MAX_REMOTE_APPLIES,
        clock: Callable[[], float] = time.monotonic,
        force_fallback: bool = False,
    ) -> None:
        resolved = Path(os.path.realpath(os.path.abspath(os.fspath(root))))
        if not resolved.is_dir():
            raise ValueError(f"Fabric watch root is not a directory: {resolved}")
        if debounce_seconds < 0:
            raise ValueError("debounce_seconds must not be negative")
        if scan_interval_seconds <= 0:
            raise ValueError("scan_interval_seconds must be positive")
        if max_pending_events < 1:
            raise ValueError("max_pending_events must be positive")
        if max_local_issues < 1:
            raise ValueError("max_local_issues must be positive")
        if max_scan_entries < 1:
            raise ValueError("max_scan_entries must be positive")
        if content_reconcile_interval_seconds <= 0:
            raise ValueError("content_reconcile_interval_seconds must be positive")
        if content_reconcile_bytes < 1:
            raise ValueError("content_reconcile_bytes must be positive")
        if content_reconcile_files < 1:
            raise ValueError("content_reconcile_files must be positive")
        if max_remote_applies < 1:
            raise ValueError("max_remote_applies must be positive")

        self.root = resolved
        self.debounce_seconds = debounce_seconds
        self.scan_interval_seconds = scan_interval_seconds
        self.max_pending_events = max_pending_events
        self.max_local_issues = max_local_issues
        self.max_scan_entries = max_scan_entries
        self.content_reconcile_interval_seconds = content_reconcile_interval_seconds
        self.content_reconcile_bytes = content_reconcile_bytes
        self.content_reconcile_files = content_reconcile_files
        self.max_remote_applies = max_remote_applies
        self._clock = clock
        self._force_fallback = force_fallback

        self.wake_event = threading.Event()
        self._lock = threading.RLock()
        # ``wake_event`` is an edge notification, not a mirror of durable
        # watcher state.  A level-set event for ``_pending`` or ``_overflow``
        # makes a coordinator retry loop spin through its network backoff.  The
        # generation pair lets the single consumer clear one observed edge
        # while preserving a notification that races that clear.
        self._wake_generation = 0
        self._consumed_wake_generation = 0
        # Async transfer completion and shutdown notifications share the Event
        # for an interruptible wait, but use a separate generation. Watch queue
        # drains must never consume a Future completion that landed later in the
        # same coordinator poll.
        self._external_wake_generation = 0
        self._consumed_external_wake_generation = 0
        self._debounce_notified_sequences: set[int] = set()
        self._pending: list[_PendingEvent] = []
        self._pending_by_sequence: dict[int, _PendingEvent] = {}
        self._pending_by_path: dict[str, list[int]] = {}
        self._active_pending_count = 0
        self._pending_tombstones = 0
        self._sequence = 0
        self._overflow = False
        self._remote_applies: dict[str, _RemoteApply] = {}
        self._remote_apply_by_path: dict[str, str] = {}
        self._recovery_generation = 0

        self._scan_initialized = False
        self._scan_baseline: dict[str, _Fingerprint] = {}
        self._scan_candidates: dict[str, tuple[_Fingerprint, int]] = {}
        self._missing_candidates: dict[str, int] = {}

        self._content_digests: dict[str, bytes] = {}
        self._content_candidates: dict[str, tuple[bytes, int]] = {}
        self._content_probe: _ContentProbe | None = None
        self._content_cursor: str | None = None
        self._last_content_reconcile_at = float("-inf")
        self._scan_mutex = threading.Lock()
        self._last_scan_namespace_entries = 0
        self._last_scan_duration_seconds = 0.0
        self._native_health_scrub_seconds = _jittered_native_health_scrub_seconds(
            self.root
        )

        self._stop_event = threading.Event()
        self._scan_thread: threading.Thread | None = None
        self._observer: object | None = None
        self._started = False
        self._using_native = False
        self._generation = 0
        self._healthy = True
        self._failed_collectors: list[object] = []
        self._last_native_loss: str | None = None
        self._last_collector_error: str | None = None
        self._local_issues: dict[tuple[str, str], FabricWatchIssue] = {}
        self._local_issues_saturated = False
        self._local_issue_generation = 0

    @property
    def overflow(self) -> bool:
        """Whether a full local/remote reconciliation is required."""

        with self._lock:
            return self._overflow

    @property
    def recovery_generation(self) -> int:
        """Monotonic identity of the latest overflow/recovery requirement."""

        with self._lock:
            return self._recovery_generation

    @property
    def using_native(self) -> bool:
        with self._lock:
            return self._using_native

    @property
    def healthy(self) -> bool:
        """Whether every previously started collector stopped cleanly."""

        with self._lock:
            return self._healthy

    def health_snapshot(self) -> FabricWatchHealth:
        """Return collector state without I/O, scanning, or mutation."""

        with self._lock:
            observer = self._observer
            started = self._started
            using_native = self._using_native
            ingress = observer_ingress_snapshot(observer)
            if not started:
                backend = "stopped"
            elif using_native:
                backend = native_backend_name(observer)
            else:
                backend = "fallback"
            return FabricWatchHealth(
                backend=backend,
                using_native=using_native,
                collector_healthy=self._healthy,
                reconciliation_needed=self._overflow,
                ingress_queue_depth=ingress.depth,
                ingress_queue_capacity=ingress.capacity,
                last_loss_or_error=(
                    ingress.last_loss
                    or self._last_native_loss
                    or self._last_collector_error
                ),
                local_issues=tuple(sorted(self._local_issues.values())),
                local_issues_saturated=self._local_issues_saturated,
            )

    @property
    def next_wake_delay(self) -> float:
        """Seconds until the next local edge or exact watcher deadline.

        New filesystem observations and overflow transitions are delivered as
        one-shot edges. Pending debounce deadlines and armed remote-apply
        expirations are timers: each ready debounce set is exposed once until
        the coordinator drains it, while an expired armed apply transitions to
        durable overflow when :meth:`wait` (or any ordinary watcher operation)
        next prunes it. Durable pending/overflow state alone never returns zero.
        """

        with self._lock:
            if self._has_unconsumed_wake_locked() or self.wake_event.is_set():
                return 0.0
            return self._next_wake_delay_locked(self._clock())

    def seed_durable_content_baselines(self, baselines: Mapping[str, str]) -> int:
        """Seed up to 1,000 trusted clean digests before collection starts.

        This lets the first bounded content probe detect an edit that preserved
        size and timestamps across a daemon restart.  The method never stats or
        opens user files and therefore keeps startup work proportional to the
        caller's bounded SQLite page.
        """

        if not isinstance(baselines, Mapping) or len(baselines) > 1_000:
            raise ValueError("at most 1000 durable content baselines may be seeded")
        normalized: dict[str, bytes] = {}
        for raw_path, raw_digest in baselines.items():
            if not isinstance(raw_path, str) or not isinstance(raw_digest, str):
                raise ValueError("durable content baselines must map paths to digests")
            relative = self._safe_relative(raw_path, require_regular=False)
            if relative is None or _ignored_path(relative):
                continue
            try:
                digest = bytes.fromhex(raw_digest)
            except ValueError as error:
                raise ValueError("a durable content baseline digest is invalid") from error
            if len(digest) != 32 or raw_digest != raw_digest.lower():
                raise ValueError("a durable content baseline digest is invalid")
            normalized[relative] = digest
        with self._lock:
            if self._started:
                raise RuntimeError("durable baselines must be seeded before watch start")
            self._content_digests.update(normalized)
        return len(normalized)

    def wake(self) -> None:
        """Notify the single coordinator consumer of external control work."""

        with self._lock:
            self._signal_external_wake_locked()

    def begin_poll(self) -> bool:
        """Consume only notifications that predate one coordinator poll.

        Call this as the first operation in the serialized coordinator poll.
        A watcher event or async completion arriving after this fence retains a
        newer generation through all later watch drains in the same poll. The
        method also consumes a debounce deadline exactly once, which prevents a
        zero-delay scheduling property from spinning when the poll fails before
        reaching :meth:`drain`.
        """

        with self._lock:
            now = self._clock()
            self._prune_remote_applies_locked(now)
            deadline_ready = self._mark_ready_debounce_notified_locked(now)
            edge_ready = self._consume_wake_locked(include_external=True)
            return deadline_ready or edge_ready

    def wait(self, timeout: float) -> bool:
        """Wait for and consume one edge or exact local deadline.

        The clear and generation snapshot are serialized with every internal
        producer. If a producer runs re-entrantly during ``Event.clear`` (the
        deterministic form of the real clear/check race), its newer generation
        is restored before the lock is released. A debounce deadline is
        delivered at most once for an unchanged pending sequence set, so an
        unrelated coordinator error cannot turn ready local state into a hot
        loop.
        """

        if timeout < 0:
            raise ValueError("timeout must not be negative")
        real_deadline = time.monotonic() + float(timeout)
        while True:
            with self._lock:
                now = self._clock()
                self._prune_remote_applies_locked(now)
                deadline_ready = self._mark_ready_debounce_notified_locked(now)
                edge_ready = self._consume_wake_locked(include_external=True)
                if deadline_ready or edge_ready:
                    return True
                remaining = max(0.0, real_deadline - time.monotonic())
                if remaining <= 0:
                    return False
                local_delay = self._next_wake_delay_locked(now)
                wait_seconds = min(remaining, local_delay)

            signaled = self.wake_event.wait(wait_seconds)

            with self._lock:
                now = self._clock()
                self._prune_remote_applies_locked(now)
                deadline_ready = self._mark_ready_debounce_notified_locked(now)
                edge_ready = self._consume_wake_locked(include_external=True)
                if deadline_ready or edge_ready:
                    return True
                if signaled:
                    # Compatibility for a direct ``wake_event.set()`` caller.
                    # In-tree control callers should use ``wake()`` so the
                    # generation fence also covers the clear/check race.
                    self.wake_event.clear()
                    self._refresh_wake_locked()
                    return True
            if time.monotonic() >= real_deadline:
                return False

    def start(self) -> None:
        """Start packaged native collection, falling back if import/start fails."""

        with self._lock:
            if self._started:
                return
            self._failed_collectors = [
                collector
                for collector in self._failed_collectors
                if _collector_is_alive(collector)
            ]
            if self._failed_collectors:
                self._healthy = False
                raise RuntimeError("a previous Fabric watcher collector is still running")
            self._healthy = True
            self._generation += 1
            generation = self._generation
            stop_event = threading.Event()
            self._stop_event = stop_event
            self._started = True

        native_started = False
        native_contract_failed = False
        if Observer is not None and not self._force_fallback:
            for observer_type in _native_observer_candidates():
                observer = None
                observer_started = False
                try:
                    observer = observer_type()
                    configure_observer_ingress(
                        observer,
                        max_events=self.max_pending_events,
                        on_loss=lambda reason: self._handle_native_loss(
                            generation, reason
                        ),
                    )
                    observer.schedule(
                        _WatchdogHandler(self, generation), str(self.root), recursive=True
                    )
                    if not attach_fsevents_loss_hook(
                        observer, max_raw_events=self.max_pending_events
                    ):
                        # The emitter has not started, so dropping this object is
                        # safer than calling FSEvents remove_watch on a stream
                        # that was never created.
                        observer = None
                        native_contract_failed = True
                        raise RuntimeError(
                            "the pinned FSEvents loss hook could not be validated"
                        )
                    is_fsevents = "fsevents" in str(
                        getattr(observer_type, "__module__", "")
                    ).lower()
                    fsevents_logger = logging.getLogger("fsevents")
                    prior_disabled = fsevents_logger.disabled
                    if is_fsevents:
                        # Watchdog logs its asynchronous startup exception before
                        # callers can inspect emitter health. We handle that
                        # exact failure below and immediately try kqueue, so do
                        # not leak an alarming third-party traceback into the
                        # user's persistent service log.
                        fsevents_logger.disabled = True
                    try:
                        observer.start()
                        observer_started = True
                        survived_start = _collector_survived_start(observer)
                    finally:
                        if is_fsevents:
                            fsevents_logger.disabled = prior_disabled
                    if not survived_start:
                        # A failed FSEvents emitter must not be stopped through
                        # Watchdog's ordinary path: watchdog 6 calls remove_watch
                        # for a stream that was never created, which can terminate
                        # the process on macOS. Retire only the still-live dispatcher
                        # and try kqueue before the conservative scanner.
                        _retire_dead_emitter_collector(observer)
                        observer = None
                        raise RuntimeError("native Fabric watcher emitter did not start")
                except Exception as error:
                    # A native backend can be importable but unavailable (for
                    # example, an exhausted inotify watch budget). Falling back
                    # to the next native candidate or the scanner is safe.
                    with self._lock:
                        self._last_collector_error = (
                            f"{type(error).__name__}: {error}"
                        )
                    try:
                        if observer is not None and observer_started:
                            observer.stop()
                            observer.join(timeout=2.0)
                    except Exception:
                        pass
                    if (
                        observer is not None
                        and observer_started
                        and _collector_is_alive(observer)
                    ):
                        with self._lock:
                            self._failed_collectors.append(observer)
                            self._healthy = False
                            self._started = False
                            stop_event.set()
                            self._mark_overflow_locked()
                        raise RuntimeError("native Fabric watcher failed to stop")
                    if native_contract_failed:
                        # A changed/unknown FSEvents contract is a packaging
                        # degradation, not an ordinary backend outage. Do not
                        # silently substitute another unvalidated native stream.
                        break
                    continue

                discard_observer = False
                with self._lock:
                    if not self._generation_is_active_locked(generation):
                        discard_observer = True
                    else:
                        self._observer = observer
                        self._using_native = True
                if discard_observer:
                    failed_to_stop = False
                    try:
                        observer.stop()
                        observer.join(timeout=2.0)
                    except Exception:
                        failed_to_stop = True
                    else:
                        failed_to_stop = _collector_is_alive(observer)
                    if failed_to_stop:
                        with self._lock:
                            self._failed_collectors.append(observer)
                            self._healthy = False
                            self._mark_overflow_locked()
                    return
                native_started = True
                break

        if not native_started:
            with self._lock:
                self._using_native = False
        # Prime synchronously so pre-existing files are a baseline, not uploads.
        # Its measured cost also seeds the adaptive cadence; a large namespace
        # therefore does not immediately enter an expensive fixed-rate loop.
        scan_started_at = self._clock()
        self._scan_once(generation, reconcile_content=False)
        scan_duration = max(0.0, self._clock() - scan_started_at)
        interval = self._adaptive_scan_interval(
            using_native=native_started,
            scan_duration=scan_duration,
        )
        thread = threading.Thread(
            target=self._scan_loop,
            args=(stop_event, generation, interval),
            name="meshia-fabric-metadata-scan",
            daemon=True,
        )
        with self._lock:
            if not self._generation_is_active_locked(generation):
                return
            self._scan_thread = thread
            # Starting while holding the lifecycle lock prevents ``stop`` from
            # observing and joining a Thread that has not started yet.
            thread.start()

    def stop(self) -> None:
        """Stop collection. Safe to call more than once."""

        with self._lock:
            if not self._started:
                return
            self._started = False
            stop_event = self._stop_event
            stop_event.set()
            observer = self._observer
            thread = self._scan_thread
            self._observer = None
            self._scan_thread = None
            self._using_native = False

        failed: list[object] = []
        if observer is not None:
            try:
                observer.stop()  # type: ignore[attr-defined]
                observer.join(timeout=5.0)  # type: ignore[attr-defined]
            except Exception:
                failed.append(observer)
            else:
                if _collector_is_alive(observer):
                    failed.append(observer)
        if thread is not None and thread is not threading.current_thread():
            try:
                thread.join(timeout=max(5.0, self.scan_interval_seconds * 2))
            except Exception:
                failed.append(thread)
            else:
                if thread.is_alive():
                    failed.append(thread)

        with self._lock:
            if failed:
                self._failed_collectors.extend(failed)
                self._healthy = False
                self._last_collector_error = "native collector did not stop cleanly"
                self._mark_overflow_locked()
            elif not any(_collector_is_alive(item) for item in self._failed_collectors):
                self._failed_collectors.clear()
                self._healthy = True

    def __enter__(self) -> "FabricWatch":
        self.start()
        return self

    def __exit__(self, *_: object) -> None:
        self.stop()

    # --------------------------------------------------------- event ingress

    def record_put(self, path: Path | str, *, now: float | None = None) -> bool:
        """Record a create/modify for an existing, regular, non-symlink file."""

        relative = self._safe_relative(path, require_regular=True)
        if relative is None or _ignored_path(relative):
            return False
        with self._lock:
            self._clear_local_issues_for_path_locked(relative)
        return self._record(FabricWatchEvent("put", relative), now)

    def record_delete(self, path: Path | str, *, now: float | None = None) -> bool:
        """Record removal of a safe workspace-relative path."""

        relative = self._safe_relative(path, require_regular=False)
        if relative is None or _ignored_path(relative):
            return False
        return self._record(FabricWatchEvent("delete", relative), now)

    def record_rename(
        self,
        source: Path | str,
        destination: Path | str,
        *,
        now: float | None = None,
    ) -> bool:
        """Record a paired move, collapsing atomic editor saves when safe."""

        source_relative = self._safe_relative(source, require_regular=False)
        # A fast a->b->c chain may have moved b again before watchdog dispatches
        # the first callback. Keep the paired rename even when the destination
        # is already absent; the subsequent rename can then coalesce the chain.
        destination_relative = self._safe_relative(destination, require_regular=False)
        if source_relative is None and destination_relative is None:
            return False
        if source_relative is None:
            assert destination_relative is not None
            if self._safe_relative(destination, require_regular=True) is None:
                return False
            source_issue_path = _lexical_relative(self.root, source)
            if source_issue_path is not None:
                with self._lock:
                    self._clear_local_issues_for_path_locked(source_issue_path)
            return self._record(FabricWatchEvent("put", destination_relative), now)
        if destination_relative is None:
            return self._record(FabricWatchEvent("delete", source_relative), now)

        source_ignored = _ignored_path(source_relative)
        destination_ignored = _ignored_path(destination_relative)
        destination_is_root_icon = (
            destination_relative == _MACOS_ROOT_ICON_BOOKKEEPING
        )
        if destination_ignored:
            if destination_is_root_icon and not source_ignored:
                # Finder's exact root icon file is reserved local bookkeeping.
                # Moving a synchronized file onto it still removes the source
                # from the portable namespace.
                return self._record(
                    FabricWatchEvent("delete", source_relative), now
                )
            # A normal file moving to a Meshia transaction path is an
            # intermediate transaction state. Waiting for the companion move
            # avoids publishing a false delete.
            return False
        if source_ignored:
            # WorkspaceBoundary writes a private temp, fsyncs, then renames it
            # over the destination. The private path is never remote-visible.
            if self._safe_relative(destination, require_regular=True) is None:
                return False
            return self._record(FabricWatchEvent("put", destination_relative), now)
        return self._record(
            FabricWatchEvent("rename", destination_relative, source_relative), now
        )

    def mark_overflow(self) -> None:
        """Fail closed after native event loss or another authoritative ambiguity."""

        with self._lock:
            self._mark_overflow_locked()

    def _handle_native_loss(self, generation: int, reason: str) -> None:
        with self._lock:
            if not self._generation_is_active_locked(generation):
                return
            self._last_native_loss = reason
            self._mark_overflow_locked()

    def _report_local_issue(self, code: str, path: str) -> None:
        issue = FabricWatchIssue(code, _bounded_issue_path(path))
        key = (issue.code, issue.path)
        with self._lock:
            if key in self._local_issues:
                return
            if len(self._local_issues) >= self.max_local_issues:
                if not self._local_issues_saturated:
                    self._local_issues_saturated = True
                    self._local_issue_generation += 1
                return
            self._local_issues[key] = issue
            self._local_issue_generation += 1

    def _commit_scan_issues_locked(
        self,
        issues: tuple[FabricWatchIssue, ...],
        saturated: bool,
        through_generation: int,
    ) -> None:
        scanned = {(issue.code, issue.path): issue for issue in issues}
        if self._local_issue_generation == through_generation:
            changed = (
                scanned != self._local_issues
                or saturated != self._local_issues_saturated
            )
            self._local_issues = scanned
            self._local_issues_saturated = saturated
            if changed:
                self._local_issue_generation += 1
            return
        # A native callback raced the scan. Preserve its newer issue and merge
        # the bounded scan result; a later scrub can prove individual repairs.
        changed = False
        for key, issue in scanned.items():
            if key in self._local_issues:
                continue
            if len(self._local_issues) >= self.max_local_issues:
                saturated = True
                break
            self._local_issues[key] = issue
            changed = True
        new_saturated = self._local_issues_saturated or saturated
        if new_saturated != self._local_issues_saturated:
            self._local_issues_saturated = new_saturated
            changed = True
        if changed:
            self._local_issue_generation += 1

    def _clear_local_issues_for_path_locked(self, path: str) -> None:
        bounded = _bounded_issue_path(path)
        removed = [key for key in self._local_issues if key[1] == bounded]
        if not removed:
            return
        for key in removed:
            self._local_issues.pop(key, None)
        self._local_issue_generation += 1

    def _validate_directory_event(self, path: Path | str) -> None:
        """Fail closed if a newly visible directory is not portable."""

        self._safe_relative(
            path,
            require_regular=False,
            allow_directory=True,
        )

    def begin_recovery(self) -> FabricWatchRecovery:
        """Capture the event watermark covered by a full namespace scan."""

        # ``poll_once`` is also exercised without ``start`` in deterministic
        # callers. Establish a before-recovery baseline if lifecycle priming
        # has not happened yet; otherwise an edit between the coordinator's
        # namespace scan and its acknowledgment could become a silent first
        # baseline. Events observed during this bounded scan remain sequenced
        # before the watermark and are covered by the subsequent full scan.
        with self._lock:
            needs_baseline = not self._scan_initialized
        if needs_baseline:
            with self._scan_mutex:
                with self._lock:
                    needs_baseline = not self._scan_initialized
                    issue_generation = self._local_issue_generation
                if needs_baseline:
                    result = self._metadata_snapshot()
                    with self._lock:
                        self._commit_scan_issues_locked(
                            result.issues,
                            result.issues_saturated,
                            issue_generation,
                        )
                        if not self._scan_initialized:
                            if result.complete:
                                self._scan_baseline = dict(result.files)
                                self._scan_candidates.clear()
                                self._missing_candidates.clear()
                                self._scan_initialized = True
                    if result.complete:
                        self._reconcile_content(
                            result.files,
                            None,
                            masked_prefixes=result.masked_prefixes,
                        )
        with self._lock:
            return FabricWatchRecovery(self._recovery_generation, self._sequence)

    def acknowledge_recovery(self, recovery: FabricWatchRecovery) -> bool:
        """Resume after a full reconciliation without losing concurrent events.

        Events observed after ``begin_recovery`` remain queued. If another
        overflow invalidated the scan, the generation mismatch keeps the watch
        fail-closed and the caller must scan again.
        """

        if not isinstance(recovery, FabricWatchRecovery):
            raise TypeError("recovery must be a FabricWatchRecovery")
        with self._lock:
            if recovery.generation != self._recovery_generation:
                self._refresh_wake_locked()
                return False
            if not self._scan_initialized:
                # Without a complete before-scan baseline, accepting recovery
                # would make the current namespace an untrusted first baseline
                # and could absorb a concurrent edit.
                self._refresh_wake_locked()
                return False
            scan_thread = self._scan_thread
            if self._started and (
                scan_thread is None
                or (
                    scan_thread is not threading.current_thread()
                    and not scan_thread.is_alive()
                )
            ):
                # A full reconciliation may repair current namespace state,
                # but it cannot make a dead collector observe the next edit.
                # Keep the service fail-closed until it is stopped/restarted.
                self._healthy = False
                self._refresh_wake_locked()
                return False
            self._overflow = False
            reset_observer_loss(self._observer)
            self._replace_pending_locked(
                pending
                for pending in self._pending
                if pending.active and pending.sequence > recovery.through_sequence
            )
            # Keep the last trusted metadata/content baselines. The full
            # reconciliation advances changed paths through
            # ``acknowledge_local_state``. Anything that changes after that
            # scan remains different from this baseline and is detected by the
            # next fallback/content passes instead of being absorbed as fresh.
            self._scan_candidates.clear()
            self._missing_candidates.clear()
            self._content_candidates.clear()
            self._content_probe = None
            self._content_cursor = None
            self._last_content_reconcile_at = float("-inf")
            if not any(
                _collector_is_alive(item) for item in self._failed_collectors
            ):
                self._healthy = True
            # The acknowledged recovery consumes its overflow edge. Any event
            # recorded re-entrantly while the Event is cleared advances the
            # generation and is restored by the consume fence.
            self._consume_wake_locked(include_external=False)
            self._refresh_wake_locked()
            return True

    # ------------------------------------------------------- remote applies

    def arm_remote_apply(
        self,
        *paths: Path | str,
        timeout_seconds: float = DEFAULT_REMOTE_APPLY_ARM_SECONDS,
        now: float | None = None,
    ) -> str:
        """Arm exact paths before a coordinator-owned namespace CAS.

        Events continue entering the normal bounded queue while armed. They
        are removed only after :meth:`commit_remote_apply` verifies the exact
        post-state, so a local edit racing the remote apply cannot disappear.
        Recovery and admission contention raise StateError so the coordinator
        retains the intent and retries after its existing reconciliation fence.
        """

        if not paths:
            raise ValueError("at least one remote-apply path is required")
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        normalized: list[str] = []
        for path in paths:
            relative = self._safe_relative(path, require_regular=False)
            if relative is None or _ignored_path(relative):
                raise ValueError("remote-apply path is not a safe workspace file")
            if relative not in normalized:
                normalized.append(relative)
        observed_at = self._clock() if now is None else now
        with self._lock:
            self._prune_remote_applies_locked(observed_at)
            if self._overflow:
                raise RemoteApplyDeferred("cannot arm a remote apply while recovery is required")
            if len(self._remote_applies) >= self.max_remote_applies:
                for existing in tuple(self._remote_applies.values()):
                    if existing.phase == "committed":
                        self._retire_remote_apply_locked(existing)
                        if len(self._remote_applies) < self.max_remote_applies:
                            break
            if len(self._remote_applies) >= self.max_remote_applies:
                raise RemoteApplyDeferred("the bounded remote-apply token table is full")
            for path in normalized:
                existing_token = self._remote_apply_by_path.get(path)
                if existing_token is None:
                    continue
                existing = self._remote_applies[existing_token]
                if existing.phase == "armed":
                    raise RemoteApplyDeferred("a remote apply is already armed for this path")
                self._retire_remote_apply_locked(existing)
            token = uuid.uuid4().hex
            apply = _RemoteApply(
                token=token,
                paths=tuple(normalized),
                armed_sequence=self._sequence,
                phase="armed",
                expires_at=observed_at + timeout_seconds,
                expected={},
            )
            self._remote_applies[token] = apply
            for path in normalized:
                self._remote_apply_by_path[path] = token
            return token

    def renew_remote_apply(
        self,
        token: str,
        *,
        timeout_seconds: float = DEFAULT_REMOTE_APPLY_ARM_SECONDS,
        now: float | None = None,
    ) -> bool:
        """Renew a long-running armed transfer without changing its watermark."""

        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        observed_at = self._clock() if now is None else now
        with self._lock:
            self._prune_remote_applies_locked(observed_at)
            apply = self._remote_applies.get(token)
            if apply is None or apply.phase != "armed":
                return False
            apply.expires_at = observed_at + timeout_seconds
            return True

    def commit_remote_apply(
        self,
        token: str,
        expected: Mapping[Path | str, object | None],
        *,
        ttl_seconds: float = DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
        now: float | None = None,
    ) -> bool:
        """Validate and commit one remote apply's exact post-state.

        Present values may be a ``FileFingerprint`` or a ``HashedRegularFile``-
        compatible object. Passing the latter also seeds the periodic SHA-256
        baseline. ``None`` requires the path to be absent. No file content is
        read by this method or by native watcher callbacks.

        A token revoked by overflow, expiry, or abort fails the fence without
        throwing: its caller may already have performed the namespace CAS and
        must finish through the ordinary unverified-post-state recovery path.
        """

        if not token:
            raise ValueError("remote-apply token is required")
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        normalized: dict[str, _ExpectedPostState | None] = {}
        for path, state in expected.items():
            relative = self._safe_relative(path, require_regular=False)
            if relative is None:
                raise ValueError("remote-apply expected path is unsafe")
            normalized[relative] = _coerce_expected_post_state(state)
        observed_at = self._clock() if now is None else now
        with self._lock:
            self._prune_remote_applies_locked(observed_at)
            apply = self._remote_applies.get(token)
            if apply is None:
                return False
            if apply.phase != "armed":
                raise ValueError("remote-apply token is not armed")
            if set(normalized) != set(apply.paths):
                raise ValueError("remote-apply post-state must cover every armed path")

            current = {
                path: self._current_file_state_locked(path) for path in apply.paths
            }
            if any(state is _INVALID_FILE_STATE for state in current.values()) or any(
                current[path]
                != (state.fingerprint if state is not None else None)
                for path, state in normalized.items()
            ):
                self._retire_remote_apply_locked(apply)
                self._mark_overflow_locked()
                return False

            armed_paths = set(apply.paths)
            for pending in self._pending:
                if not pending.active:
                    continue
                event_paths = _event_paths(pending.event)
                if (
                    pending.sequence > apply.armed_sequence
                    and event_paths.intersection(armed_paths)
                    and not event_paths.issubset(armed_paths)
                ):
                    self._retire_remote_apply_locked(apply)
                    self._mark_overflow_locked()
                    return False
            self._replace_pending_locked(
                pending
                for pending in self._pending
                if pending.active
                and not (
                    pending.sequence > apply.armed_sequence
                    and _event_paths(pending.event)
                    and _event_paths(pending.event).issubset(armed_paths)
                )
            )
            self._apply_expected_post_state_locked(normalized)
            apply.phase = "committed"
            apply.expected = normalized
            apply.expires_at = observed_at + ttl_seconds
            self._refresh_wake_locked()
            return True

    def abort_remote_apply(self, token: str, *, now: float | None = None) -> bool:
        """Abort an uncommitted apply without discarding its queued events."""

        observed_at = self._clock() if now is None else now
        with self._lock:
            self._prune_remote_applies_locked(observed_at)
            apply = self._remote_applies.get(token)
            if apply is None:
                return False
            self._retire_remote_apply_locked(apply)
            self._refresh_wake_locked()
            return True

    def acknowledge_local_state(
        self,
        expected: Mapping[Path | str, object | None],
        *,
        absorb_late_events_seconds: float = 0.0,
    ) -> bool:
        """Advance scanner baselines after local events are durably staged.

        Once the current exact state matches the durable stage, queued hints
        wholly covered by those paths are redundant and removed. A state that
        changed after staging does not match, so every hint remains queued.
        Rename handoffs may retain the exact post-state briefly so delayed
        native callbacks are absorbed without a second stage or upload.
        """

        if absorb_late_events_seconds < 0:
            raise ValueError("absorb_late_events_seconds must not be negative")
        normalized: dict[str, _ExpectedPostState | None] = {}
        for path, state in expected.items():
            relative = self._safe_relative(path, require_regular=False)
            if relative is None:
                return False
            normalized[relative] = _coerce_expected_post_state(state)
        observed_at = self._clock()
        with self._lock:
            self._prune_remote_applies_locked(observed_at)
            current = {
                path: self._current_file_state_locked(path) for path in normalized
            }
            if any(state is _INVALID_FILE_STATE for state in current.values()) or any(
                current[path]
                != (state.fingerprint if state is not None else None)
                for path, state in normalized.items()
            ):
                return False
            covered_paths = set(normalized)
            self._replace_pending_locked(
                pending
                for pending in self._pending
                if pending.active
                and not _event_paths(pending.event).issubset(covered_paths)
            )
            self._apply_expected_post_state_locked(normalized)
            if absorb_late_events_seconds > 0 and not self._overflow:
                self._retain_exact_post_state_locked(
                    normalized,
                    observed_at=observed_at,
                    ttl_seconds=absorb_late_events_seconds,
                )
            self._refresh_wake_locked()
            return True

    def _retain_exact_post_state_locked(
        self,
        expected: Mapping[str, _ExpectedPostState | None],
        *,
        observed_at: float,
        ttl_seconds: float,
    ) -> None:
        """Bound delayed local callbacks by the committed-apply invariant."""

        existing_tokens = {
            token
            for path in expected
            if (token := self._remote_apply_by_path.get(path)) is not None
        }
        existing = [self._remote_applies[token] for token in existing_tokens]
        if any(apply.phase == "armed" for apply in existing):
            # An in-flight remote namespace CAS owns suppression authority.
            # The durable local operation still provides the recovery fallback.
            return
        for apply in existing:
            self._retire_remote_apply_locked(apply)
        if len(self._remote_applies) >= self.max_remote_applies:
            for apply in tuple(self._remote_applies.values()):
                if apply.phase == "committed":
                    self._retire_remote_apply_locked(apply)
                    if len(self._remote_applies) < self.max_remote_applies:
                        break
        if len(self._remote_applies) >= self.max_remote_applies:
            return

        token = uuid.uuid4().hex
        apply = _RemoteApply(
            token=token,
            paths=tuple(expected),
            armed_sequence=self._sequence,
            phase="committed",
            expires_at=observed_at + ttl_seconds,
            expected=dict(expected),
        )
        self._remote_applies[token] = apply
        for path in apply.paths:
            self._remote_apply_by_path[path] = token

    # ------------------------------------------------------ legacy one-shot

    def suppress_path(
        self,
        path: Path | str,
        *,
        ttl_seconds: float = DEFAULT_SUPPRESSION_SECONDS,
        recursive: bool = False,
        now: float | None = None,
    ) -> bool:
        """Discard only already-queued hints for an explicitly journaled write.

        This compatibility method never suppresses future events. Remote
        namespace mutations must use ``arm_remote_apply`` and
        ``commit_remote_apply`` so their exact post-state is validated.
        """

        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        relative = self._safe_relative(
            path, require_regular=False, allow_directory=recursive
        )
        if relative is None:
            return False
        with self._lock:
            self._replace_pending_locked(
                pending
                for pending in self._pending
                if pending.active
                and not self._event_matches_suppression(
                    pending.event, relative, recursive
                )
            )
            if recursive:
                self._forget_content_tree_locked(relative)
            else:
                self._forget_content_locked(relative)
            self._refresh_wake_locked()
        return True

    def suppress_paths(
        self,
        paths: Iterable[Path | str],
        *,
        ttl_seconds: float = DEFAULT_SUPPRESSION_SECONDS,
        recursive: bool = False,
        now: float | None = None,
    ) -> int:
        """Discard already-queued hints for several explicitly journaled paths."""

        observed_at = self._clock() if now is None else now
        return sum(
            self.suppress_path(
                path,
                ttl_seconds=ttl_seconds,
                recursive=recursive,
                now=observed_at,
            )
            for path in paths
        )

    # ------------------------------------------------------------- draining

    def drain(
        self, now: float | None = None, max_events: int = 1_000
    ) -> list[FabricWatchEvent]:
        """Return debounced events in observation order.

        During overflow no partial events are returned. The coordinator must
        reconcile the complete namespace and call :meth:`acknowledge_recovery`.
        """

        if max_events < 1:
            raise ValueError("max_events must be positive")
        observed_at = self._clock() if now is None else now
        with self._lock:
            self._consume_wake_locked(include_external=False)
            self._prune_remote_applies_locked(observed_at)
            if self._overflow:
                self._refresh_wake_locked()
                return []
            ready: list[_PendingEvent] = []
            waiting: list[_PendingEvent] = []
            for pending in self._pending:
                if not pending.active:
                    continue
                if (
                    len(ready) < max_events
                    and pending.observed_at + self.debounce_seconds <= observed_at
                ):
                    ready.append(pending)
                else:
                    waiting.append(pending)
            self._replace_pending_locked(waiting)
            if ready:
                ready_waiting = [
                    pending
                    for pending in waiting
                    if pending.observed_at + self.debounce_seconds <= observed_at
                ]
                if ready_waiting:
                    # A bounded drain left immediately actionable work. It is a
                    # new edge, not a level mirror of the remaining queue.
                    self._debounce_notified_sequences.difference_update(
                        pending.sequence for pending in ready_waiting
                    )
                    self._signal_wake_locked()
            self._refresh_wake_locked()
            return [pending.event for pending in sorted(ready, key=lambda item: item.sequence)]

    # ------------------------------------------------------ fallback scanner

    def scan_once(self) -> bool:
        """Run one bounded metadata and periodic-content reconciliation scan.

        Returns ``True`` only for a complete scan. This public method is useful
        for deterministic recovery and tests. Content reads share one global
        per-interval byte/file budget and never retain file handles.
        """

        return self._scan_once(None, reconcile_content=True)

    def _scan_once(
        self, expected_generation: int | None, *, reconcile_content: bool
    ) -> bool:
        with self._scan_mutex:
            return self._scan_once_serialized(expected_generation, reconcile_content)

    def _scan_once_serialized(
        self, expected_generation: int | None, reconcile_content: bool
    ) -> bool:
        with self._lock:
            issue_generation = self._local_issue_generation
        result = self._metadata_snapshot()

        with self._lock:
            if not self._accept_generation_locked(expected_generation):
                return False
            self._last_scan_namespace_entries = result.namespace_entries
            self._commit_scan_issues_locked(
                result.issues,
                result.issues_saturated,
                issue_generation,
            )
            if not result.complete:
                # A bounded/incomplete local scan is observable but does not
                # invalidate unrelated native events or authoritative state.
                return False
            snapshot = dict(result.files)
            if result.masked_prefixes:
                for path, fingerprint in self._scan_baseline.items():
                    if _path_is_masked(path, result.masked_prefixes):
                        snapshot.setdefault(path, fingerprint)
            if self._overflow:
                # An overflowed event stream cannot be repaired by guessing a
                # delta. The owner must reconcile both authorities explicitly.
                return True
            if not self._scan_initialized:
                self._scan_baseline = snapshot
                self._scan_candidates.clear()
                self._missing_candidates.clear()
                self._scan_initialized = True
            else:
                observed_at = self._clock()
                for path, fingerprint in snapshot.items():
                    if self._scan_baseline.get(path) == fingerprint:
                        self._scan_candidates.pop(path, None)
                        self._missing_candidates.pop(path, None)
                        continue
                    candidate, count = self._scan_candidates.get(path, (fingerprint, 0))
                    if candidate == fingerprint:
                        count += 1
                    else:
                        count = 1
                    self._scan_candidates[path] = (fingerprint, count)
                    self._missing_candidates.pop(path, None)
                    if count >= 2:
                        event = FabricWatchEvent("put", path)
                        if self._enqueue_locked(event, observed_at):
                            self._scan_baseline[path] = fingerprint
                            self._scan_candidates.pop(path, None)

                missing = set(self._scan_baseline).difference(snapshot)
                for path in list(self._missing_candidates):
                    if path not in missing:
                        self._missing_candidates.pop(path, None)
                for path in missing:
                    count = self._missing_candidates.get(path, 0) + 1
                    self._missing_candidates[path] = count
                    if count >= 2:
                        event = FabricWatchEvent("delete", path)
                        if self._enqueue_locked(event, observed_at):
                            self._scan_baseline.pop(path, None)
                            self._missing_candidates.pop(path, None)
                            self._scan_candidates.pop(path, None)
                self._refresh_wake_locked()

        if reconcile_content:
            self._reconcile_content(
                snapshot,
                expected_generation,
                masked_prefixes=result.masked_prefixes,
            )
        return True

    # -------------------------------------------------------------- internals

    def _scan_loop(
        self, stop_event: threading.Event, generation: int, interval: float
    ) -> None:
        scan_due_in = interval
        while True:
            with self._lock:
                native_before_wait = self._using_native
            wait_seconds = (
                min(scan_due_in, DEFAULT_NATIVE_COLLECTOR_HEALTH_SECONDS)
                if native_before_wait
                else scan_due_in
            )
            if stop_event.wait(wait_seconds):
                return
            scan_due_in = max(0.0, scan_due_in - wait_seconds)
            if not self._generation_is_active(generation):
                return
            with self._lock:
                observer = self._observer if self._using_native else None
            if observer is not None and not _collector_is_alive(observer):
                with self._lock:
                    if self._generation_is_active_locked(generation):
                        if self._observer is observer:
                            self._observer = None
                        self._using_native = False
                        self._healthy = False
                        self._last_collector_error = "native collector stopped unexpectedly"
                        self._mark_overflow_locked()
                _retire_dead_emitter_collector(observer)
                # Once native collection is gone, this loop is the primary
                # collector and must use the low-latency fallback cadence.
                scan_due_in = self.scan_interval_seconds
            with self._lock:
                overflow = self._overflow
                using_native = self._using_native
            if overflow:
                # Recovery owns the next authoritative namespace walk. Repeating
                # a 250k scan cannot clear this watermark and only burns CPU/I/O;
                # retain a non-zero health/fallback tick so this cannot spin.
                if scan_due_in <= 0:
                    scan_due_in = (
                        DEFAULT_NATIVE_COLLECTOR_HEALTH_SECONDS
                        if using_native
                        else self.scan_interval_seconds
                    )
                continue
            if using_native and scan_due_in > 0:
                # Cheap liveness tick; the jittered health scrub is not due.
                continue
            scan_started_at = self._clock()
            try:
                self._scan_once(generation, reconcile_content=True)
            except Exception as error:
                # A dead fallback must never look healthy while silently
                # missing local edits. Fail closed, but keep retrying at the
                # fallback cadence so a transient scanner failure cannot wedge
                # this generation permanently.
                with self._lock:
                    if self._generation_is_active_locked(generation):
                        self._healthy = False
                        self._last_collector_error = (
                            f"{type(error).__name__}: {error}"
                        )
                        self._mark_overflow_locked()
                scan_due_in = self.scan_interval_seconds
            else:
                scan_duration = max(0.0, self._clock() - scan_started_at)
                with self._lock:
                    using_native = self._using_native
                scan_due_in = self._adaptive_scan_interval(
                    using_native=using_native,
                    scan_duration=scan_duration,
                )

    def _adaptive_scan_interval(
        self, *, using_native: bool, scan_duration: float
    ) -> float:
        """Return idle time after a completed scan.

        For each scan plus its following idle period, the measured scanner duty
        is at most the selected target. Native callbacks retain their 300ms
        debounce; a full metadata/content walk is only a coarse, per-root
        jittered corruption scrub. Collector liveness has its own five-second
        check and is therefore independent of this expensive cadence.
        """

        duration = max(0.0, float(scan_duration))
        if using_native:
            base_interval = self._native_health_scrub_seconds
            duty = DEFAULT_NATIVE_SCAN_MAX_DUTY
        else:
            base_interval = self.scan_interval_seconds
            duty = DEFAULT_FALLBACK_SCAN_MAX_DUTY
        duty_limited_idle = duration * (1.0 - duty) / duty
        selected = max(base_interval, duty_limited_idle)
        with self._lock:
            self._last_scan_duration_seconds = duration
        return selected

    def _record(self, event: FabricWatchEvent, now: float | None) -> bool:
        observed_at = self._clock() if now is None else now
        with self._lock:
            return self._enqueue_locked(event, observed_at)

    def _enqueue_locked(self, event: FabricWatchEvent, observed_at: float) -> bool:
        self._prune_remote_applies_locked(observed_at)
        committed = self._handle_committed_event_locked(event)
        if committed is not None:
            return committed

        armed_sequence = max(
            (
                self._remote_applies[token].armed_sequence
                for path in _event_paths(event)
                if (token := self._remote_apply_by_path.get(path)) is not None
                and self._remote_applies[token].phase == "armed"
            ),
            default=-1,
        )

        # Repeated backend notifications for one final put/delete carry no new
        # information. Per-path histories identify the only relevant suffix;
        # unrelated queued paths never participate in a callback-time scan.
        replace_pending: _PendingEvent | None = None
        rename_contains_put = False
        if event.kind in ("put", "delete"):
            previous_pending = self._latest_pending_for_path_locked(event.path)
            if previous_pending is not None:
                previous = previous_pending.event
                if previous.kind == "rename":
                    if (
                        event.kind == "put"
                        and previous.path == event.path
                        and previous_pending.sequence > armed_sequence
                        and self._paths_unchanged_after_locked(
                            previous_pending, _event_paths(previous)
                        )
                    ):
                        # Staging the rename hashes its final destination. Fold
                        # later destination writes into that operation so a
                        # second put cannot replace the rename's durable
                        # delete-after-ack intent for the old source.
                        previous_pending.observed_at = observed_at
                        previous_pending.rename_contains_put = True
                        self._debounce_notified_sequences.discard(
                            previous_pending.sequence
                        )
                        self._forget_content_locked(event.path)
                        self._signal_wake_locked()
                        return True
                elif previous.kind in ("put", "delete"):
                    if previous_pending.sequence > armed_sequence:
                        if (
                            event.kind == "delete"
                            and previous.kind == "put"
                            and self._scan_initialized
                            and event.path not in self._scan_baseline
                        ):
                            # A file born and removed inside one debounce window
                            # never had a remote identity or durable local stage.
                            self._deactivate_pending_locked(previous_pending)
                            self._refresh_wake_locked()
                            return False
                        replace_pending = previous_pending
                        if event.kind == "put" and previous.kind == "delete":
                            # A delete followed by recreate has one final put
                            # state. A preceding rename into this path retains
                            # ownership of its source tombstone when no later
                            # event touched the rename's other endpoint.
                            earlier = self._latest_pending_for_path_locked(
                                event.path,
                                before_sequence=previous_pending.sequence,
                            )
                            ignored = frozenset((previous_pending.sequence,))
                            if (
                                earlier is not None
                                and earlier.event.kind == "rename"
                                and earlier.event.path == event.path
                                and earlier.sequence > armed_sequence
                                and self._paths_unchanged_after_locked(
                                    earlier,
                                    _event_paths(earlier.event),
                                    ignored_sequences=ignored,
                                )
                            ):
                                self._deactivate_pending_locked(previous_pending)
                                earlier.observed_at = observed_at
                                earlier.rename_contains_put = True
                                self._debounce_notified_sequences.discard(
                                    earlier.sequence
                                )
                                self._forget_content_locked(event.path)
                                self._signal_wake_locked()
                                return True
        elif event.kind == "rename":
            # A put followed by moving that exact file carries one final
            # namespace operation. Preserve it as a rename: local metadata
            # cannot prove whether the source has a sparse, remote-only
            # identity. The coordinator's durable remote index decides whether
            # this is a true rename or an atomic-save destination put.
            event_paths = _event_paths(event)
            while True:
                previous_pending = self._latest_pending_touching_locked(event_paths)
                if previous_pending is None:
                    break
                previous = previous_pending.event
                if previous.kind in ("put", "delete") and previous.path == event.path:
                    if previous_pending.sequence > armed_sequence:
                        # Atomic replacement commonly reports a create/modify
                        # or removal of the destination before the paired move.
                        # The rename stager hashes the final destination and
                        # carries its durable target precondition, so a separate
                        # destination event is redundant and conflict-prone.
                        self._deactivate_pending_locked(previous_pending)
                        continue
                    break
                if previous.kind == "put" and previous.path == event.source_path:
                    if previous_pending.sequence > armed_sequence:
                        rename_contains_put = True
                        self._deactivate_pending_locked(previous_pending)
                    break
                # The newest event touching either endpoint is an explicit
                # dependency and blocks older suffix coalescing.
                break
            # Collapse consecutive rename chains (a->b, b->c) without losing
            # the original source identity. Intervening mutations may commute
            # only when they are disjoint from the entire eventual chain.
            previous_pending = self._latest_pending_for_path_locked(
                event.source_path or ""
            )
            if (
                previous_pending is not None
                and previous_pending.event.kind == "rename"
                and previous_pending.event.path == event.source_path
            ):
                previous = previous_pending.event
                original = previous.source_path
                assert original is not None
                chain_paths = {original, event.source_path, event.path}
                if (
                    previous_pending.sequence > armed_sequence
                    and self._paths_unchanged_after_locked(
                        previous_pending, chain_paths
                    )
                ):
                    rename_contains_put = (
                        rename_contains_put or previous_pending.rename_contains_put
                    )
                    if original == event.path:
                        if not rename_contains_put:
                            # An unmodified a->b->a round trip has no namespace
                            # effect.
                            self._deactivate_pending_locked(previous_pending)
                            self._refresh_wake_locked()
                            return False
                        # A create/modify folded into this rename chain is still
                        # a content mutation at its original path.
                        event = FabricWatchEvent("put", original)
                        replace_pending = previous_pending
                    else:
                        event = FabricWatchEvent("rename", event.path, original)
                        replace_pending = previous_pending

        if replace_pending is not None:
            self._deactivate_pending_locked(replace_pending)
        if self._active_pending_count >= self.max_pending_events:
            self._mark_overflow_locked()

        if event.kind == "rename":
            if event.source_path is not None:
                self._forget_content_locked(event.source_path)
            self._forget_content_locked(event.path)
        else:
            self._forget_content_locked(event.path)
        self._sequence += 1
        self._append_pending_locked(
            _PendingEvent(
                event,
                observed_at,
                self._sequence,
                rename_contains_put=rename_contains_put and event.kind == "rename",
            )
        )
        self._signal_wake_locked()
        return True

    def _mark_overflow_locked(self) -> None:
        transitioned = not self._overflow
        for apply in tuple(self._remote_applies.values()):
            self._retire_remote_apply_locked(apply)
        self._pending.clear()
        self._pending_by_sequence.clear()
        self._pending_by_path.clear()
        self._active_pending_count = 0
        self._pending_tombstones = 0
        self._debounce_notified_sequences.clear()
        self._overflow = True
        self._recovery_generation += 1
        if transitioned:
            self._signal_wake_locked()
        else:
            # Repeated native overflow callbacks still invalidate an in-flight
            # recovery watermark, but the coordinator's current retry deadline
            # owns the next attempt. Durable overflow is not a wake level.
            self._refresh_wake_locked()

    def _accept_generation_locked(self, expected_generation: int | None) -> bool:
        return expected_generation is None or self._generation_is_active_locked(
            expected_generation
        )

    def _generation_is_active_locked(self, generation: int) -> bool:
        return self._started and self._generation == generation

    def _generation_is_active(self, generation: int) -> bool:
        with self._lock:
            return self._generation_is_active_locked(generation)

    def _run_for_generation(self, generation: int, action: Callable[[], object]) -> None:
        # Hold the re-entrant lock through normalization/enqueue so a callback
        # from an observer that was just stopped cannot leak into a new start.
        with self._lock:
            if self._generation_is_active_locked(generation):
                action()

    def _refresh_wake_locked(self) -> None:
        if self._has_unconsumed_wake_locked():
            self.wake_event.set()
            return
        self.wake_event.clear()
        # ``Event.clear`` is normally a constant-time primitive. Keeping this
        # re-check makes the generation fence explicit and also covers a
        # deterministic re-entrant clear hook used by the race regression.
        if self._has_unconsumed_wake_locked():
            self.wake_event.set()

    def _has_unconsumed_wake_locked(self) -> bool:
        return bool(
            self._wake_generation != self._consumed_wake_generation
            or self._external_wake_generation
            != self._consumed_external_wake_generation
        )

    def _signal_wake_locked(self) -> None:
        self._wake_generation += 1
        self.wake_event.set()

    def _signal_external_wake_locked(self) -> None:
        self._external_wake_generation += 1
        self.wake_event.set()

    def _consume_wake_locked(self, *, include_external: bool) -> bool:
        observed_generation = self._wake_generation
        observed_external_generation = self._external_wake_generation
        raw_signal = self.wake_event.is_set()
        internal_ready = observed_generation != self._consumed_wake_generation
        external_ready = (
            observed_external_generation
            != self._consumed_external_wake_generation
        )
        raw_only = raw_signal and not internal_ready and not external_ready
        if not internal_ready and not (include_external and (external_ready or raw_only)):
            return False
        if internal_ready:
            self._consumed_wake_generation = observed_generation
        if include_external and external_ready:
            self._consumed_external_wake_generation = observed_external_generation
        self.wake_event.clear()
        self._refresh_wake_locked()
        return True

    def _index_pending_locked(self, pending: _PendingEvent) -> None:
        self._pending_by_sequence[pending.sequence] = pending
        self._active_pending_count += 1
        for path in _event_paths(pending.event):
            self._pending_by_path.setdefault(path, []).append(pending.sequence)

    def _append_pending_locked(self, pending: _PendingEvent) -> None:
        self._pending.append(pending)
        self._index_pending_locked(pending)

    def _deactivate_pending_locked(self, pending: _PendingEvent) -> None:
        if not pending.active:
            return
        pending.active = False
        self._pending_by_sequence.pop(pending.sequence, None)
        self._active_pending_count -= 1
        self._pending_tombstones += 1
        self._debounce_notified_sequences.discard(pending.sequence)
        for path in _event_paths(pending.event):
            history = self._pending_by_path.get(path)
            if history is None:
                continue
            while history and history[-1] not in self._pending_by_sequence:
                history.pop()
            if not history:
                self._pending_by_path.pop(path, None)
        # Tombstones make arbitrary coalescing removal O(1). Rebuild only after
        # a full queue's worth have accumulated, which bounds memory while
        # keeping compaction amortized and out of ordinary callback bursts.
        if self._pending_tombstones > self.max_pending_events:
            self._replace_pending_locked(self._pending)

    def _replace_pending_locked(self, pending_events: Iterable[_PendingEvent]) -> None:
        retained = [pending for pending in pending_events if pending.active]
        self._pending = retained
        self._pending_by_sequence.clear()
        self._pending_by_path.clear()
        self._active_pending_count = 0
        self._pending_tombstones = 0
        for pending in retained:
            self._index_pending_locked(pending)
        self._retain_debounce_notifications_locked()

    def _latest_pending_for_path_locked(
        self,
        path: str,
        *,
        before_sequence: int | None = None,
        ignored_sequences: frozenset[int] = frozenset(),
    ) -> _PendingEvent | None:
        history = self._pending_by_path.get(path)
        if not history:
            return None
        index = len(history) - 1
        while index >= 0:
            sequence = history[index]
            pending = self._pending_by_sequence.get(sequence)
            if pending is None or not pending.active:
                if index == len(history) - 1:
                    history.pop()
                index -= 1
                continue
            if sequence in ignored_sequences or (
                before_sequence is not None and sequence >= before_sequence
            ):
                index -= 1
                continue
            return pending
        if not history:
            self._pending_by_path.pop(path, None)
        return None

    def _latest_pending_touching_locked(
        self,
        paths: Iterable[str],
        *,
        ignored_sequences: frozenset[int] = frozenset(),
    ) -> _PendingEvent | None:
        candidates = (
            self._latest_pending_for_path_locked(
                path, ignored_sequences=ignored_sequences
            )
            for path in paths
        )
        return max(
            (candidate for candidate in candidates if candidate is not None),
            key=lambda candidate: candidate.sequence,
            default=None,
        )

    def _paths_unchanged_after_locked(
        self,
        pending: _PendingEvent,
        paths: Iterable[str],
        *,
        ignored_sequences: frozenset[int] = frozenset(),
    ) -> bool:
        latest = self._latest_pending_touching_locked(
            paths, ignored_sequences=ignored_sequences
        )
        return latest is None or latest.sequence <= pending.sequence

    def _retain_debounce_notifications_locked(self) -> None:
        self._debounce_notified_sequences.intersection_update(
            self._pending_by_sequence
        )

    def _mark_ready_debounce_notified_locked(self, now: float) -> bool:
        if self._overflow:
            return False
        ready = {
            pending.sequence
            for pending in self._pending
            if pending.active
            and pending.sequence not in self._debounce_notified_sequences
            and pending.observed_at + self.debounce_seconds <= now
        }
        if not ready:
            return False
        self._debounce_notified_sequences.update(ready)
        return True

    def _next_wake_delay_locked(self, now: float) -> float:
        deadlines = [
            pending.observed_at + self.debounce_seconds
            for pending in self._pending
            if pending.active
            and not self._overflow
            and pending.sequence not in self._debounce_notified_sequences
        ]
        deadlines.extend(
            apply.expires_at
            for apply in self._remote_applies.values()
            if apply.phase == "armed"
        )
        if not deadlines:
            return float("inf")
        return max(0.0, min(deadlines) - now)

    def _prune_remote_applies_locked(self, now: float) -> None:
        expired = [
            apply for apply in self._remote_applies.values() if apply.expires_at <= now
        ]
        expired_armed = any(apply.phase == "armed" for apply in expired)
        for apply in expired:
            self._retire_remote_apply_locked(apply)
        if expired_armed:
            # The mutation outcome is unknown. Queued hints cannot prove which
            # authority won, so require a complete reconciliation.
            self._mark_overflow_locked()

    def _retire_remote_apply_locked(self, apply: _RemoteApply) -> None:
        self._remote_applies.pop(apply.token, None)
        for path in apply.paths:
            if self._remote_apply_by_path.get(path) == apply.token:
                self._remote_apply_by_path.pop(path, None)

    def _handle_committed_event_locked(
        self, event: FabricWatchEvent
    ) -> bool | None:
        event_paths = _event_paths(event)
        token_ids = {
            token
            for path in event_paths
            if (token := self._remote_apply_by_path.get(path)) is not None
            and self._remote_applies[token].phase == "committed"
        }
        if not token_ids:
            return None
        if len(token_ids) != 1:
            self._mark_overflow_locked()
            return False
        apply = self._remote_applies[next(iter(token_ids))]
        if not event_paths.issubset(apply.paths):
            # A rename into/out of the committed path is a new user mutation.
            self._retire_remote_apply_locked(apply)
            return None
        current = {
            path: self._current_file_state_locked(path) for path in apply.paths
        }
        if any(state is _INVALID_FILE_STATE for state in current.values()):
            self._retire_remote_apply_locked(apply)
            self._mark_overflow_locked()
            return False
        if all(
            current[path]
            == (state.fingerprint if state is not None else None)
            for path, state in apply.expected.items()
        ):
            # Delayed/coalesced callback for the verified remote CAS.
            self._apply_expected_post_state_locked(apply.expected)
            return False
        # A different exact state is a later local mutation. Stop absorbing and
        # let the normal event path enqueue it immediately.
        self._retire_remote_apply_locked(apply)
        return None

    @staticmethod
    def _event_matches_suppression(
        event: FabricWatchEvent, path: str, recursive: bool
    ) -> bool:
        candidates = (event.path, event.source_path)
        return any(
            candidate is not None
            and (
                candidate == path
                or (recursive and candidate.startswith(path.rstrip("/") + "/"))
            )
            for candidate in candidates
        )

    def _current_file_state_locked(
        self, relative: str
    ) -> _Fingerprint | None | object:
        if not relative or any(
            component in ("", ".", "..") for component in relative.split("/")
        ):
            return _INVALID_FILE_STATE
        current = self.root
        components = relative.split("/")
        for index, component in enumerate(components):
            observed = _lstat_exact_component(current, component)
            if observed is _INVALID_FILE_STATE:
                return _INVALID_FILE_STATE
            if observed is None:
                return None
            candidate, info = observed
            if index < len(components) - 1:
                if not stat.S_ISDIR(info.st_mode):
                    return _INVALID_FILE_STATE
                current = candidate
                continue
            if not stat.S_ISREG(info.st_mode):
                return _INVALID_FILE_STATE
            if info.st_nlink != 1:
                return _INVALID_FILE_STATE
            return _fingerprint(info)
        return _INVALID_FILE_STATE

    def _apply_expected_post_state_locked(
        self, expected: Mapping[str, _ExpectedPostState | None]
    ) -> None:
        for path, state in expected.items():
            # The exact post-state was just validated through a no-symlink,
            # single-link component walk. Clear any native callback issue that
            # was recorded during WorkspaceBoundary's owned link publication
            # window; otherwise Linux can retain a stale HARDLINK health issue
            # until the next coarse namespace scrub.
            self._clear_local_issues_for_path_locked(path)
            self._scan_candidates.pop(path, None)
            self._missing_candidates.pop(path, None)
            self._forget_content_locked(path)
            if state is None:
                self._scan_baseline.pop(path, None)
                continue
            self._scan_baseline[path] = state.fingerprint
            if state.sha256 is not None:
                self._content_digests[path] = state.sha256

    def _safe_relative(
        self,
        path: Path | str,
        *,
        require_regular: bool,
        allow_directory: bool = False,
    ) -> str | None:
        """Normalize a host/native path and reject escapes or symlink walks."""

        try:
            raw = os.fspath(path)
        except TypeError:
            return None
        if not raw or "\0" in raw:
            return None
        candidate = Path(raw)
        if not candidate.is_absolute():
            # Logical API paths always use '/'. On POSIX a backslash is a valid
            # filename but not a valid Fabric separator; rejecting it keeps the
            # namespace portable to Windows.
            if "\\" in raw or raw.startswith("~"):
                return None
            components = raw.split("/")
            if any(component in ("", ".", "..") for component in components):
                return None
            candidate = self.root.joinpath(*components)

        absolute = Path(os.path.abspath(os.fspath(candidate)))
        try:
            common = os.path.commonpath((os.fspath(self.root), os.fspath(absolute)))
        except ValueError:
            return None
        if common != os.fspath(self.root) or absolute == self.root:
            return None
        try:
            relative_path = absolute.relative_to(self.root)
        except ValueError:
            return None
        issue_path = relative_path.as_posix()
        reserved_private_leaf = _reserved_private_temporary_leaf(issue_path)

        # lstat each existing component. A missing final path is expected for
        # deletes, but a symlink in any surviving ancestor is always unsafe.
        current = self.root
        final_info: os.stat_result | None = None
        for index, component in enumerate(relative_path.parts):
            if component in ("", ".", ".."):
                return None
            current = current / component
            try:
                info = os.lstat(current)
            except FileNotFoundError:
                break
            except OSError:
                self._report_local_issue("UNREADABLE_PATH", issue_path)
                return None
            if stat.S_ISLNK(info.st_mode) or _is_reparse_point(info):
                self._report_local_issue("SYMLINK_OR_REPARSE", issue_path)
                return None
            if (
                stat.S_ISREG(info.st_mode)
                and info.st_nlink != 1
                and not (
                    index == len(relative_path.parts) - 1
                    and reserved_private_leaf
                )
            ):
                # WorkspaceBoundary intentionally refuses hardlinks: treating
                # two aliases as independent remote objects would make a write
                # through one silently mutate the other. Fail closed instead
                # of feeding an endless hash/requeue loop to the coordinator.
                self._report_local_issue("HARDLINK", issue_path)
                return None
            if index == len(relative_path.parts) - 1:
                final_info = info

        real_parent = Path(os.path.realpath(os.fspath(absolute.parent)))
        try:
            if os.path.commonpath((os.fspath(self.root), os.fspath(real_parent))) != os.fspath(
                self.root
            ):
                return None
        except ValueError:
            return None

        if require_regular:
            try:
                info = os.lstat(absolute)
            except OSError:
                return None
            if not stat.S_ISREG(info.st_mode):
                if not stat.S_ISDIR(info.st_mode):
                    self._report_local_issue("UNSUPPORTED_FILE_TYPE", issue_path)
                return None
            if info.st_nlink != 1 and not reserved_private_leaf:
                self._report_local_issue("HARDLINK", issue_path)
                return None
        elif final_info is not None and not (
            stat.S_ISREG(final_info.st_mode)
            or (allow_directory and stat.S_ISDIR(final_info.st_mode))
        ):
            if not stat.S_ISDIR(final_info.st_mode):
                self._report_local_issue("UNSUPPORTED_FILE_TYPE", issue_path)
            return None
        relative = issue_path
        if _ignored_path(relative):
            # Meshia's exact private transaction names never enter the public
            # namespace. Validate them structurally above, then let the caller
            # ignore them without classifying our own atomic writes as errors.
            # A private leaf does not excuse a non-portable user ancestor.
            if not _ignored_path_has_portable_ancestors(relative):
                self._report_local_issue("UNSUPPORTED_NAME", relative)
                return None
            return relative
        try:
            # The synchronized namespace must round-trip across macOS, Linux,
            # and Windows. Reject a host-local spelling here instead of
            # emitting an event that WorkspaceBoundary deterministically
            # refuses and the coordinator would otherwise requeue forever.
            split_relative(relative)
        except (UnsafePath, UnicodeError):
            # Unsupported user names must never look synchronized while their
            # bytes remain local. Preserve and isolate only this item.
            self._report_local_issue("UNSUPPORTED_NAME", relative)
            return None
        return relative

    def _metadata_snapshot(
        self,
    ) -> _MetadataSnapshot:
        snapshot: dict[str, _Fingerprint] = {}
        issues = _IssueAccumulator(self.max_local_issues)
        # Store two fixed 128-bit digests per path: NFC+Unicode-upper and
        # NFC+Unicode-lower. APFS/NTFS aliases are not described by either
        # transform alone (for example final sigma is upper-only while theta
        # symbol is lower-only), and the namespaces must remain separate.
        # Fixed-width keys bound memory independently of user path lengths; a
        # cryptographic digest collision deliberately fails closed.
        portable_upper_paths: dict[bytes, str] = {}
        portable_lower_paths: dict[bytes, str] = {}
        pending: list[tuple[Path, str]] = [(self.root, "")]
        visited = 0
        while pending:
            directory, directory_relative = pending.pop()
            if directory_relative and _path_is_masked(
                directory_relative, issues.masked_prefixes
            ):
                continue
            try:
                entries = os.scandir(directory)
            except OSError:
                issues.add(
                    "UNREADABLE_DIRECTORY", directory_relative or ".", mask=True
                )
                continue
            try:
                with entries:
                    for entry in entries:
                        # Check before stat/path/dict allocations. The iterator
                        # itself is lazy, so a huge flat directory cannot burst
                        # memory before the global scan cap takes effect.
                        if visited >= self.max_scan_entries:
                            issues.add("SCAN_LIMIT_REACHED", ".", mask=True)
                            return issues.snapshot(snapshot, False, visited)
                        visited += 1
                        relative = Path(entry.path).relative_to(self.root).as_posix()
                        try:
                            info = directory_entry_identity_stat(entry)
                        except OSError:
                            issues.add("UNREADABLE_PATH", relative, mask=True)
                            continue
                        if (
                            stat.S_ISLNK(info.st_mode)
                            or _is_reparse_point(info)
                        ):
                            issues.add("SYMLINK_OR_REPARSE", relative, mask=True)
                            continue
                        if _ignored_path(relative):
                            if not _ignored_path_has_portable_ancestors(relative):
                                issues.add("UNSUPPORTED_NAME", relative, mask=True)
                            continue
                        try:
                            split_relative(relative)
                        except (UnsafePath, UnicodeError):
                            # Unsupported host-local names cannot exist in the
                            # portable Fabric namespace. Preserve them locally,
                            # exclude only their exact item/subtree.
                            issues.add("UNSUPPORTED_NAME", relative, mask=True)
                            continue
                        upper_digest, lower_digest = _portable_collision_digests(
                            relative
                        )
                        collision_paths = {
                            owner
                            for owner in (
                                portable_upper_paths.get(upper_digest),
                                portable_lower_paths.get(lower_digest),
                            )
                            if owner is not None and owner != relative
                        }
                        if collision_paths:
                            # A case/Unicode-fold alias cannot round-trip across
                            # the supported filesystems. Mask every physical
                            # spelling; never normalize either into the other.
                            issues.add(
                                "PORTABLE_NAME_COLLISION", relative, mask=True
                            )
                            snapshot.pop(relative, None)
                            for owner in collision_paths:
                                issues.add(
                                    "PORTABLE_NAME_COLLISION", owner, mask=True
                                )
                                snapshot.pop(owner, None)
                            continue
                        else:
                            portable_upper_paths[upper_digest] = relative
                            portable_lower_paths[lower_digest] = relative
                        if stat.S_ISDIR(info.st_mode):
                            pending.append((Path(entry.path), relative))
                        elif stat.S_ISREG(info.st_mode):
                            if info.st_nlink != 1:
                                issues.add("HARDLINK", relative, mask=True)
                            else:
                                snapshot[relative] = _fingerprint(info)
                        else:
                            issues.add("UNSUPPORTED_FILE_TYPE", relative, mask=True)
            except OSError:
                issues.add(
                    "UNREADABLE_DIRECTORY", directory_relative or ".", mask=True
                )
        return issues.snapshot(snapshot, True, visited)

    def _reconcile_content(
        self,
        snapshot: dict[str, _Fingerprint],
        expected_generation: int | None,
        *,
        masked_prefixes: frozenset[str] = frozenset(),
    ) -> None:
        now = self._clock()
        with self._lock:
            if (
                not self._accept_generation_locked(expected_generation)
                or self._overflow
                or now
                < self._last_content_reconcile_at
                + self.content_reconcile_interval_seconds
            ):
                return
            self._last_content_reconcile_at = now
            # Select the pass once. The previous per-file successor search
            # rescanned all N paths up to 64 times (16M comparisons at the
            # valid 250k namespace ceiling). One filter/sort plus binary cursor
            # lookup keeps selection independent of the file budget.
            eligible = sorted(
                path
                for path, fingerprint in snapshot.items()
                if self._scan_baseline.get(path) == fingerprint
                and path not in self._scan_candidates
                and not _path_is_masked(path, masked_prefixes)
            )
            probe = self._content_probe
            if probe is not None:
                position = bisect_left(eligible, probe.path)
                if (
                    position >= len(eligible)
                    or eligible[position] != probe.path
                    or snapshot.get(probe.path) != probe.fingerprint
                ):
                    self._content_probe = None
                    probe = None
            after = probe.path if probe is not None else self._content_cursor

        if not eligible:
            return
        start = bisect_right(eligible, after) if after is not None else 0
        if start >= len(eligible):
            start = 0
        selected = 0
        active_path = probe.path if probe is not None else None

        remaining = self.content_reconcile_bytes
        files_opened = 0
        while remaining > 0 and files_opened < self.content_reconcile_files:
            with self._lock:
                if (
                    not self._accept_generation_locked(expected_generation)
                    or self._overflow
                ):
                    return
                if probe is not None and self._content_probe is not probe:
                    probe = None
                if probe is None:
                    while selected < len(eligible):
                        path = eligible[(start + selected) % len(eligible)]
                        selected += 1
                        if path == active_path:
                            continue
                        fingerprint = snapshot.get(path)
                        if (
                            fingerprint is None
                            or self._scan_baseline.get(path) != fingerprint
                            or path in self._scan_candidates
                        ):
                            continue
                        probe = _ContentProbe(path, fingerprint, 0, hashlib.sha256())
                        self._content_probe = probe
                        break
                if probe is None:
                    return

            consumed, complete, digest = self._advance_content_probe(probe, remaining)
            files_opened += 1
            remaining -= consumed
            if not complete:
                # A zero-byte consumption means the file became unavailable;
                # move on instead of spinning within the same bounded pass.
                if consumed == 0:
                    with self._lock:
                        if self._content_probe is probe:
                            self._content_probe = None
                            self._content_cursor = probe.path
                return

            with self._lock:
                if (
                    not self._accept_generation_locked(expected_generation)
                    or self._content_probe is not probe
                ):
                    return
                self._content_probe = None
                self._content_cursor = probe.path
                if digest is not None:
                    self._finish_content_probe_locked(probe.path, digest, now)

    def _advance_content_probe(
        self, probe: _ContentProbe, byte_budget: int
    ) -> tuple[int, bool, bytes | None]:
        path = self.root.joinpath(*probe.path.split("/"))
        flags = os.O_RDONLY
        flags |= getattr(os, "O_BINARY", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        fd: int | None = None
        consumed = 0
        try:
            fd = os.open(path, flags)
            opened = os.fstat(fd)
            if opened.st_nlink != 1 or _fingerprint(opened) != probe.fingerprint:
                return 0, False, None
            os.lseek(fd, probe.offset, os.SEEK_SET)
            while consumed < byte_budget and probe.offset < probe.fingerprint.size:
                request = min(
                    _CONTENT_READ_BYTES,
                    byte_budget - consumed,
                    probe.fingerprint.size - probe.offset,
                )
                data = os.read(fd, request)
                if not data:
                    return consumed, False, None
                probe.hasher.update(data)  # type: ignore[attr-defined]
                probe.offset += len(data)
                consumed += len(data)
            if probe.offset < probe.fingerprint.size:
                return consumed, False, None
            finished = os.fstat(fd)
            if finished.st_nlink != 1 or _fingerprint(finished) != probe.fingerprint:
                return consumed, False, None
            return consumed, True, probe.hasher.digest()  # type: ignore[attr-defined]
        except OSError:
            return consumed, False, None
        finally:
            if fd is not None:
                os.close(fd)

    def _finish_content_probe_locked(self, path: str, digest: bytes, now: float) -> None:
        baseline = self._content_digests.get(path)
        if baseline is None:
            self._content_digests[path] = digest
            self._content_candidates.pop(path, None)
            return
        if baseline == digest:
            self._content_candidates.pop(path, None)
            return
        candidate, count = self._content_candidates.get(path, (digest, 0))
        count = count + 1 if candidate == digest else 1
        self._content_candidates[path] = (digest, count)
        if count < 2:
            return
        event = FabricWatchEvent("put", path)
        if self._enqueue_locked(event, now):
            self._content_digests[path] = digest
            self._content_candidates.pop(path, None)

    def _forget_content_locked(self, path: str) -> None:
        self._content_digests.pop(path, None)
        self._content_candidates.pop(path, None)
        if self._content_probe is not None and self._content_probe.path == path:
            self._content_probe = None

    def _forget_content_tree_locked(self, path: str) -> None:
        prefix = path.rstrip("/") + "/"
        for candidate in tuple(self._content_digests):
            if candidate == path or candidate.startswith(prefix):
                self._content_digests.pop(candidate, None)
                self._content_candidates.pop(candidate, None)
        if self._content_probe is not None and (
            self._content_probe.path == path
            or self._content_probe.path.startswith(prefix)
        ):
            self._content_probe = None


class _WatchdogHandler(FileSystemEventHandler):  # type: ignore[misc]
    """Thin adapter: callbacks only normalize/enqueue metadata events."""

    def __init__(self, watch: FabricWatch, generation: int) -> None:
        try:
            super().__init__()
        except TypeError:  # ``object`` in damaged/minimal environments
            pass
        self.watch = watch
        self.generation = generation

    def on_created(self, event: object) -> None:
        self._put_or_recover(event)

    def on_any_event(self, event: object) -> None:
        if str(getattr(event, "event_type", "")).lower() == "overflow":
            self.watch._run_for_generation(self.generation, self.watch.mark_overflow)

    def on_modified(self, event: object) -> None:
        self._put_or_recover(event)

    def on_deleted(self, event: object) -> None:
        if bool(getattr(event, "is_directory", False)):
            self.watch._run_for_generation(self.generation, self.watch.mark_overflow)
            return
        self.watch._run_for_generation(
            self.generation,
            lambda: self.watch.record_delete(str(getattr(event, "src_path", ""))),
        )

    def on_moved(self, event: object) -> None:
        if bool(getattr(event, "is_directory", False)):
            self.watch._run_for_generation(self.generation, self.watch.mark_overflow)
            return
        self.watch._run_for_generation(
            self.generation,
            lambda: self.watch.record_rename(
                str(getattr(event, "src_path", "")),
                str(getattr(event, "dest_path", "")),
            ),
        )

    def _put_or_recover(self, event: object) -> None:
        if bool(getattr(event, "is_directory", False)):
            # Creating a directory is harmless; its file children arrive as
            # individual events. Still validate a newly visible directory so
            # an empty NFD/reserved directory cannot look synchronized forever.
            # Modification of an existing directory carries no file mutation.
            if str(getattr(event, "event_type", "")).lower() == "created":
                self.watch._run_for_generation(
                    self.generation,
                    lambda: self.watch._validate_directory_event(
                        str(getattr(event, "src_path", ""))
                    ),
                )
            return
        self.watch._run_for_generation(
            self.generation,
            lambda: self.watch.record_put(str(getattr(event, "src_path", ""))),
        )


def _ignored_path(path: str) -> bool:
    """Return whether a path belongs to Meshia's private transaction machinery."""

    # Finder custom-folder bookkeeping uses this one control-character leaf at
    # the mounted root. Do not ignore nested ``Icon\r`` paths or any broader
    # class of Finder-looking user names.
    return path == _MACOS_ROOT_ICON_BOOKKEEPING or any(
        _ignored_component(component) for component in path.split("/")
    )


def _ignored_component(name: str) -> bool:
    # ``.meshia`` is the explicitly reserved private state namespace.
    # WorkspaceBoundary's sibling publish/rename temporaries carry exactly one
    # 32-hex UUID. Broader substring/suffix guesses would silently hide valid
    # user files such as ``report.meshia-conflict-notes``.
    return name == ".meshia" or _MESHIA_TEMP_NAME.fullmatch(name) is not None


def _ignored_path_has_portable_ancestors(path: str) -> bool:
    """Validate user-owned ancestors before the first private component."""

    if path == _MACOS_ROOT_ICON_BOOKKEEPING:
        return True

    parts = path.split("/")
    private_index = next(
        (index for index, part in enumerate(parts) if _ignored_component(part)),
        None,
    )
    if private_index is None:
        return False
    if private_index == 0:
        return True
    try:
        split_relative("/".join(parts[:private_index]))
    except (UnsafePath, UnicodeError):
        return False
    return True


def _reserved_private_temporary_leaf(path: str) -> bool:
    """Recognize only an exact reserved transaction leaf with safe ancestors.

    WorkspaceBoundary's create-if-absent publication briefly hardlinks its
    private stream temporary to the final name before unlinking the temporary.
    That expected two-link window must not become a persistent local HARDLINK
    issue. The exemption is deliberately narrower than ``_ignored_path``:
    Finder bookkeeping, the ``.meshia`` directory, nested children, and broad
    Meshia-looking user names retain ordinary hardlink validation.
    """

    leaf = path.rsplit("/", 1)[-1]
    return (
        _MESHIA_TEMP_NAME.fullmatch(leaf) is not None
        and _ignored_path_has_portable_ancestors(path)
    )


def _portable_collision_digests(path: str) -> tuple[bytes, bytes]:
    """Return bounded upper/lower keys matching the portable server policy."""

    # Never trim or rewrite the exact namespace spelling. Normalize before
    # casing and again after casing because both transforms can change Unicode
    # composition. Upper and lower are intentionally separate namespaces: a
    # key from one transform must never collide with the other transform.
    nfc = unicodedata.normalize("NFC", path)
    upper = unicodedata.normalize("NFC", nfc.upper()).encode("utf-8")
    lower = unicodedata.normalize("NFC", nfc.lower()).encode("utf-8")
    return (
        hashlib.blake2b(b"U\x00" + upper, digest_size=16).digest(),
        hashlib.blake2b(b"L\x00" + lower, digest_size=16).digest(),
    )


def _fingerprint(info: os.stat_result) -> _Fingerprint:
    return _Fingerprint(
        info.st_size,
        info.st_mtime_ns,
        info.st_ctime_ns,
        getattr(info, "st_ino", 0),
        getattr(info, "st_dev", 0),
    )


def _coerce_expected_post_state(value: object | None) -> _ExpectedPostState | None:
    if value is None:
        return None
    digest: bytes | None = None
    fingerprint_value = value
    if hasattr(value, "fingerprint"):
        fingerprint_value = getattr(value, "fingerprint")
        sha256 = getattr(value, "sha256", None)
        if not isinstance(sha256, str) or len(sha256) != 64:
            raise ValueError("hashed post-state must carry a SHA-256 digest")
        try:
            digest = bytes.fromhex(sha256)
        except ValueError as error:
            raise ValueError("hashed post-state SHA-256 is invalid") from error
    try:
        fingerprint = _Fingerprint(
            size=int(getattr(fingerprint_value, "size_bytes")),
            mtime_ns=int(getattr(fingerprint_value, "mtime_ns")),
            ctime_ns=int(getattr(fingerprint_value, "ctime_ns")),
            inode=int(getattr(fingerprint_value, "file_id")),
            device=int(getattr(fingerprint_value, "device_id")),
        )
    except (AttributeError, TypeError, ValueError) as error:
        raise ValueError("post-state must carry a valid file fingerprint") from error
    if fingerprint.size < 0 or fingerprint.inode < 0 or fingerprint.device < 0:
        raise ValueError("post-state size and file identity must not be negative")
    return _ExpectedPostState(fingerprint, digest)


def _event_paths(event: FabricWatchEvent) -> set[str]:
    result = {event.path}
    if event.source_path is not None:
        result.add(event.source_path)
    return result


def _is_reparse_point(info: os.stat_result) -> bool:
    attributes = int(getattr(info, "st_file_attributes", 0))
    marker = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0))
    return bool(marker and attributes & marker)


def _lstat_exact_component(
    parent: Path, component: str
) -> tuple[Path, os.stat_result] | None | object:
    """Inspect one exact child without enumerating an arbitrarily wide parent.

    A direct ``lstat`` is O(1) on the directory index, but case-insensitive
    APFS/NTFS can resolve a differently-spelled alias.  macOS's ``F_GETPATH``
    and Windows's canonical final path recover the directory entry's actual
    spelling so case-only renames retain the prior exact-name semantics.
    """

    candidate = parent / component
    try:
        info = os.lstat(candidate)
    except FileNotFoundError:
        return None
    except OSError:
        return _INVALID_FILE_STATE
    if stat.S_ISLNK(info.st_mode) or _is_reparse_point(info):
        return _INVALID_FILE_STATE
    actual_name = _actual_component_name(candidate, info)
    if actual_name is _INVALID_FILE_STATE:
        return _INVALID_FILE_STATE
    if actual_name is not None and actual_name != component:
        return None
    return candidate, info


def _actual_component_name(
    candidate: Path, observed: os.stat_result
) -> str | None | object:
    """Return an OS-canonical final component where case aliases are possible."""

    if sys.platform == "darwin":
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
        flags |= getattr(os, "O_NONBLOCK", 0)
        if stat.S_ISDIR(observed.st_mode):
            flags |= getattr(os, "O_DIRECTORY", 0)
        descriptor = -1
        try:
            descriptor = os.open(candidate, flags)
            opened = os.fstat(descriptor)
            if (
                opened.st_dev != observed.st_dev
                or opened.st_ino != observed.st_ino
            ):
                return _INVALID_FILE_STATE
            import fcntl

            raw = fcntl.fcntl(
                descriptor,
                getattr(fcntl, "F_GETPATH", 50),
                b"\0" * 1_024,
            )
            canonical = os.fsdecode(raw.split(b"\0", 1)[0])
            if not canonical:
                return _INVALID_FILE_STATE
            return os.path.basename(canonical)
        except (ImportError, OSError, ValueError):
            return _INVALID_FILE_STATE
        finally:
            if descriptor >= 0:
                os.close(descriptor)
    if sys.platform == "win32":
        try:
            canonical = os.path.realpath(candidate)
        except (OSError, ValueError):
            return _INVALID_FILE_STATE
        return os.path.basename(canonical) if canonical else _INVALID_FILE_STATE
    if sys.platform.startswith("linux") and hasattr(os, "O_PATH"):
        descriptor = -1
        try:
            descriptor = os.open(
                candidate,
                os.O_PATH | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0),
            )
            opened = os.fstat(descriptor)
            if opened.st_dev != observed.st_dev or opened.st_ino != observed.st_ino:
                return _INVALID_FILE_STATE
            canonical = os.readlink(f"/proc/self/fd/{descriptor}")
        except OSError:
            # Linux normally exposes the opened dentry through procfs. A
            # hardened environment without procfs still has exact lookup on the
            # ordinary case-sensitive filesystem; retain that safe fast path.
            return None
        finally:
            if descriptor >= 0:
                os.close(descriptor)
        return os.path.basename(canonical) if canonical else _INVALID_FILE_STATE
    # Other supported POSIX filesystems use exact component lookup.
    return None


def _collector_is_alive(collector: object) -> bool:
    try:
        is_alive = getattr(collector, "is_alive")
        if not bool(is_alive()):
            return False
        emitters = _collector_emitters(collector)
        if emitters is None:
            return True
        # A scheduled Watchdog observer always owns at least one emitter. The
        # dispatcher thread can remain alive after FSEvents/inotify has died,
        # so dispatcher liveness alone is a false-positive health signal.
        return bool(emitters) and all(_thread_is_alive(emitter) for emitter in emitters)
    except Exception:
        # Unknown liveness after a failed join is not safe to treat as stopped.
        return True


def _jittered_native_health_scrub_seconds(root: Path) -> float:
    """Return a stable-per-process/root jitter without global RNG state."""

    material = os.fsencode(os.fspath(root)) + b"\0" + str(os.getpid()).encode("ascii")
    value = int.from_bytes(
        hashlib.blake2b(material, digest_size=8, person=b"meshia-scrub").digest(),
        "big",
    )
    unit = value / ((1 << 64) - 1)
    factor = 1.0 + DEFAULT_NATIVE_HEALTH_SCRUB_JITTER * (2.0 * unit - 1.0)
    return DEFAULT_NATIVE_HEALTH_SCRUB_SECONDS * factor


def _native_observer_candidates() -> tuple[type, ...]:
    """Prefer FSEvents, then kqueue on macOS, before polling."""

    if Observer is None:
        return ()
    candidates: list[type] = [Observer]
    if (
        sys.platform == "darwin"
        and KqueueObserver is not None
        and KqueueObserver is not Observer
        and "fsevents" in str(getattr(Observer, "__module__", "")).lower()
    ):
        candidates.append(KqueueObserver)
    return tuple(candidates)


def _thread_is_alive(thread: object) -> bool:
    try:
        return bool(getattr(thread, "is_alive")())
    except Exception:
        return False


def _collector_emitters(collector: object) -> tuple[object, ...] | None:
    """Return Watchdog emitters, or ``None`` for an injected/generic collector."""

    if not hasattr(collector, "emitters"):
        return None
    try:
        return tuple(getattr(collector, "emitters"))
    except Exception:
        return ()


def _collector_survived_start(collector: object) -> bool:
    """Observe Watchdog's asynchronous emitter startup for a bounded window."""

    if _collector_emitters(collector) is None:
        return _collector_is_alive(collector)
    deadline = time.monotonic() + _NATIVE_START_HEALTH_SECONDS
    while True:
        if not _collector_is_alive(collector):
            return False
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return True
        time.sleep(min(0.010, remaining))


def _retire_dead_emitter_collector(collector: object) -> None:
    """Stop only a dead-emitter observer's dispatcher without re-stopping emitters.

    Watchdog 6's FSEvents emitter invokes ``remove_watch`` from ``stop`` even
    when ``add_watch`` failed asynchronously. On macOS that path can deliver a
    fatal signal to the process. Once every emitter is already dead, waking and
    joining the observer dispatcher is sufficient and avoids that unsafe call.
    Generic/injected collectors retain the ordinary best-effort stop path.
    """

    emitters = _collector_emitters(collector)
    if emitters is not None and emitters and not any(
        _thread_is_alive(emitter) for emitter in emitters
    ):
        try:
            stopped_event = getattr(collector, "_stopped_event")
            stopped_event.set()
            event_queue = getattr(collector, "event_queue")
            if EventDispatcher is not None:
                event_queue.put_nowait(EventDispatcher.stop_event)
            getattr(collector, "join")(timeout=2.0)
            return
        except Exception:
            # The collector is already non-authoritative and its threads are
            # daemons. Falling through must never endanger the node process.
            return
    try:
        getattr(collector, "stop")()
        getattr(collector, "join")(timeout=2.0)
    except Exception:
        return


__all__ = [
    "DEFAULT_DEBOUNCE_SECONDS",
    "DEFAULT_CONTENT_RECONCILE_BYTES",
    "DEFAULT_CONTENT_RECONCILE_INTERVAL_SECONDS",
    "DEFAULT_FALLBACK_SCAN_MAX_DUTY",
    "DEFAULT_MAX_LOCAL_ISSUES",
    "DEFAULT_MAX_SCAN_ENTRIES",
    "DEFAULT_NATIVE_COLLECTOR_HEALTH_SECONDS",
    "DEFAULT_NATIVE_HEALTH_SCRUB_SECONDS",
    "DEFAULT_NATIVE_SCAN_MAX_DUTY",
    "FabricWatch",
    "FabricWatchEvent",
    "FabricWatchHealth",
    "FabricWatchIssue",
    "FabricWatchRecovery",
]
