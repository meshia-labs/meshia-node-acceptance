"""Private, bounded request-body staging; writing an upload never uses a socket."""
from __future__ import annotations

import base64
import binascii
import hashlib
import threading
import time

from .native_app_http import AppError

MAX_UPLOAD_BYTES = 4 * 1024 * 1024
MAX_UPLOAD_CHUNK_BYTES = 1024 * 1024
UPLOAD_SECONDS = 240
IDLE_SECONDS = 30


class AppUpload:
    def __init__(self, stream_id, app, fingerprint=None):
        self.stream_id, self.app, self.fingerprint = stream_id, app, fingerprint
        self._fence, self._instance = app.fence, app.instance_id
        self.created = self.touched = time.monotonic()
        self.deadline = self.created + UPLOAD_SECONDS
        self.closed, self.closed_at, self.error = False, None, None
        self.body_complete = self.taken = False
        self.sequence = self.total_bytes = 0
        self.body_digest = self.last = self._last_fingerprint = None
        self._body = bytearray()
        self._lock = threading.RLock()

    def _failure(self, now):
        if self.closed:
            return self.error or AppError("APP_STREAM_CLOSED", "This app upload is closed.", 410)
        if (self.app.fence != self._fence or self.app.instance_id != self._instance
                or self.app.stopped.is_set() or self.app.done.is_set() or now >= self.app.deadline):
            return AppError("APP_AUTHORITY_CHANGED", "App upload authority ended.", 403)
        # After take(), the response owns cleanup and its own transfer timer.
        # Keep the final ACK replayable without letting an old staging timer
        # erase the digest that binds open retries during that response.
        if not self.taken and (now >= self.deadline or now - self.touched >= IDLE_SECONDS):
            return AppError("APP_HTTP_TIMEOUT", "App upload exceeded its transfer or idle deadline.", 504)
        return None

    def _check(self):
        failure = self._failure(time.monotonic())
        if failure is not None:
            self.close(failure)
            raise failure

    def write(self, sequence, body_base64, end_of_body):
        with self._lock:
            self._check()
            if (type(sequence) is not int or sequence < 0 or type(end_of_body) is not bool
                    or not isinstance(body_base64, str)):
                raise AppError("APP_REQUEST_INVALID", "Invalid app upload sequence, chunk or final marker.", 400)
            if len(body_base64) > ((MAX_UPLOAD_CHUNK_BYTES + 2) // 3) * 4:
                raise AppError("APP_BODY_TOO_LARGE", "App upload chunks must be at most 1 MiB.", 413)
            try:
                data = base64.b64decode(body_base64, validate=True)
            except (ValueError, binascii.Error):
                raise AppError("APP_REQUEST_INVALID", "App upload chunks must be standard base64.", 400) from None
            if len(data) > MAX_UPLOAD_CHUNK_BYTES:
                raise AppError("APP_BODY_TOO_LARGE", "App upload chunks must be at most 1 MiB.", 413)
            fingerprint = hashlib.sha256(body_base64.encode("ascii") + bytes([end_of_body])).digest()
            if self.last is not None and sequence == self.sequence - 1:
                if fingerprint != self._last_fingerprint:
                    raise AppError("APP_STREAM_SEQUENCE_INVALID", "A retried upload chunk must be identical.")
                self.touched = time.monotonic()
                return dict(self.last)
            if sequence != self.sequence:
                raise AppError("APP_STREAM_SEQUENCE_INVALID", "Write the next upload sequence or replay its last chunk.")
            if self.body_complete or self.taken:
                raise AppError("APP_UPLOAD_COMPLETE", "This app upload body is already complete.")
            if self.total_bytes + len(data) > MAX_UPLOAD_BYTES:
                raise AppError("APP_BODY_TOO_LARGE", "App upload exceeds the 4 MiB request limit.", 413)
            self._body.extend(data)
            self.total_bytes += len(data)
            self.sequence += 1
            self.body_complete = end_of_body
            self.touched = time.monotonic()
            self._last_fingerprint = fingerprint
            self.last = {"schema": "meshia.connected_host_app_http_result.v1", "operation": "write",
                         "stream_id": self.stream_id, "instance_id": self._instance,
                         "sequence": sequence, "next_sequence": self.sequence,
                         "accepted_bytes": len(data), "total_bytes": self.total_bytes,
                         "body_complete": self.body_complete}
            return dict(self.last)

    def take(self):
        with self._lock:
            self._check()
            if not self.body_complete:
                raise AppError("APP_UPLOAD_INCOMPLETE", "Finish the app upload body before opening its request.")
            if self.taken:
                raise AppError("APP_UPLOAD_CONSUMED", "This app upload body was already transferred.")
            body = bytes(self._body)
            self.body_digest = hashlib.sha256(body).hexdigest()
            self._body.clear()
            self.taken = True
            self.touched = time.monotonic()
            return body, self.body_digest

    def close(self, error=None):
        with self._lock:
            if not self.closed:
                self.closed, self.closed_at, self.error = True, time.monotonic(), error
            self._body.clear()
            self.last = self._last_fingerprint = self.body_digest = None

    def expire(self, now):
        with self._lock:
            if not self.closed:
                failure = self._failure(now)
                if failure is not None:
                    self.close(failure)
