"""Meshia projects, agents, MCP and native workspace files in one installable."""

from __future__ import annotations

__version__ = "1.3.29"
__all__ = ["__version__"]
