"""Workspace containment — the node's hardest security boundary.

Every workspace path is checked three independent ways before a byte moves:

1. **Lexically** — reject absolute paths, ``..``/``.`` components, empty
   components, backslashes, drive letters, non-NFC/nonportable names, Meshia's
   private temp namespace, NUL/control bytes, and over-long paths.
2. **Structurally** — walk the path one component at a time with ``openat`` +
   ``O_NOFOLLOW`` + ``O_DIRECTORY`` from a pinned workspace-root descriptor, so
   a symlink anywhere in the chain fails instead of escaping.
3. **Canonically** — ``realpath`` the assembled target and require it to sit
   under the realpath'd root.

Workspace writes only ever happen through :class:`WorkspaceBoundary`, and only
inside the workspace. Host-scope reads (:func:`host_read_file`,
:func:`host_list`) open ``O_RDONLY | O_NOFOLLOW`` and stay view-only.

:func:`host_write_file` is the one path that writes *outside* the workspace. It
exists only for `full` access mode and every caller must gate it on the node's
live access mode (see :class:`~meshia_node.executor.CommandExecutor`); it is
never reachable from `limited`. Even in `full` mode it keeps the same denylist,
``O_NOFOLLOW``, realpath and atomic-publish discipline as every other write.
"""

from __future__ import annotations

import ctypes
import errno
import hashlib
import json
import math
import os
import re
import stat as stat_module
import sys
import threading
import time
import unicodedata
import uuid
from collections import deque
from dataclasses import dataclass, replace
from functools import wraps
from heapq import nsmallest
from pathlib import Path
from typing import Callable, Iterable, Iterator, Sequence, TypeVar, cast

from .errors import (
    InvalidTask,
    RetentionCapacityUnavailable,
    UnsafePath,
    WorkspaceAdoptionRequired,
    WorkspaceClaimInvalid,
)
from .util import TAGGED_SHA256_RE, sha256_hex

MAX_PATH_BYTES = 4096
MAX_PATH_UTF16_UNITS = 1024
MAX_WRITE_BYTES = 8 * 1024 * 1024
# Host-scope writes are capped harder than workspace writes: they leave the
# workspace, so they are only ever meant for small configuration-sized files.
MAX_HOST_WRITE_BYTES = 1024 * 1024
MAX_READ_BYTES = 4 * 1024 * 1024
# The Fabric namespace contract is bounded at 250,000 files. Recovery must be
# able to enumerate that truthful bound instead of wedging forever at 10,001.
MAX_LIST_ENTRIES = 250_000
# The durable Fabric manifest accepts files up to 1 TiB.  The streaming APIs
# use the same logical ceiling without imposing the command-oriented 8 MiB
# in-memory limit above.  This is a validation limit, not a preallocation.
MAX_STREAM_FILE_BYTES = 1 << 40
STREAM_IO_BYTES = 1024 * 1024
# MeshiaFabric's canonical CAS accepts extents through 64 MiB.  Keeping this
# anchored read seam at the same bound lets the bulk lane stream large local
# files without a second full-size private copy.  Callers still choose much
# smaller extents for ordinary files and cap aggregate in-flight bytes.
MAX_ANCHORED_RANGE_BYTES = 64 * 1024 * 1024
STREAM_TEMP_SCHEMA = "meshia.workspace_stream_temp.v1"
RETIRE_TEMP_SCHEMA = "meshia.workspace_retire_temp.v1"
FINGERPRINT_REMOVE_TEMP_SCHEMA = "meshia.workspace_fingerprint_remove_temp.v1"
RETIRED_QUARANTINE_SCHEMA = "meshia.workspace_retired_quarantine.v1"
RETAINED_STORAGE_ACCOUNT_ADDITIONAL = "additional"
RETAINED_STORAGE_ACCOUNT_MATERIALIZED_ROW = "materialized_row"
_RETAINED_STORAGE_ACCOUNTS = frozenset(
    {
        RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
        RETAINED_STORAGE_ACCOUNT_MATERIALIZED_ROW,
    }
)
STREAM_TEMP_MARKER_SUFFIX = ".owner"
STREAM_TEMP_SCAVENGE_MAX_ENTRIES = 4_096
# An owner marker plus a dead PID is sufficient proof of abandonment. Live
# writers are never scavenged, even when a very large stream runs for days.
STREAM_TEMP_STALE_SECONDS = 0
_STREAM_TEMP_MARKER_MAX_BYTES = 4_096
RETIRED_QUARANTINE_MAX_BYTES = 512 * 1024 * 1024
RETIRED_QUARANTINE_MAX_ENTRIES = 128
RETIRED_QUARANTINE_MAX_AGE_SECONDS = 300.0
RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX = 4_096
RETIRED_QUARANTINE_RECOVERY_DIRECTORY = "Meshia Recovered Files"
WORKSPACE_ROOT_CLAIM_SCHEMA = "meshia.workspace_root.v1"
WORKSPACE_METADATA_DIRECTORY = ".meshia"
MOUNT_STAGE_DIRECTORY = "mount-writes"
WORKSPACE_ROOT_CLAIM_NAME = "workspace-root.json"
WORKSPACE_ROOT_CLAIM_RELATIVE_PATH = (
    f"{WORKSPACE_METADATA_DIRECTORY}/{WORKSPACE_ROOT_CLAIM_NAME}"
)
_WORKSPACE_ROOT_CLAIM_MAX_BYTES = 4_096
_WORKSPACE_ROOT_CLAIM_STAGE_RE = re.compile(
    r"^\.workspace-root\.[0-9a-f]{32}\.tmp$", re.IGNORECASE
)
# Every Unix-only open flag is resolved through getattr: this module's body runs
# on Windows too (the dispatch at the bottom swaps the implementations in only
# after the body has executed), and a bare os.O_NOFOLLOW there is an
# AttributeError at import — which manifests as the whole CLI refusing to start.
_O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_O_CLOEXEC = getattr(os, "O_CLOEXEC", 0)
_O_DIRECTORY = getattr(os, "O_DIRECTORY", 0)
_DIR_FLAGS = os.O_RDONLY | _O_DIRECTORY | _O_NOFOLLOW | _O_CLOEXEC
_FILE_FLAGS = os.O_RDONLY | _O_NOFOLLOW | _O_CLOEXEC

_QuarantineMethod = TypeVar("_QuarantineMethod", bound=Callable[..., object])
_DescriptorResult = TypeVar("_DescriptorResult")


def _serialize_retired_quarantine(
    method: _QuarantineMethod,
) -> _QuarantineMethod:
    """Keep one workspace's retire catalog and filesystem transition atomic."""

    @wraps(method)
    def serialized(self: object, *args: object, **kwargs: object) -> object:
        lock = getattr(self, "_retired_quarantine_lock")
        with lock:
            return method(self, *args, **kwargs)

    return cast(_QuarantineMethod, serialized)


def _bounded_sorted_names(names: Iterable[str], limit: int) -> tuple[list[str], bool]:
    """Return the lexicographically first ``limit`` names with bounded memory.

    ``os.listdir`` allocates every name before a caller can enforce the Fabric
    namespace ceiling.  ``nsmallest`` consumes a lazy ``scandir`` iterator while
    retaining only the requested output plus one look-ahead item, preserving the
    existing deterministic ordering and exact truncation contract.
    """

    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 0:
        raise ValueError("directory-name limit must be a non-negative integer")
    selected = nsmallest(limit + 1, names)
    return selected[:limit], len(selected) > limit

# Host-scope reads are view-only, but they still must never surface the node's
# own key material or classic credential files.
DEFAULT_DENIED_PREFIXES: tuple[str, ...] = (
    "/etc/shadow",
    "/etc/gshadow",
    "/etc/sudoers",
    "/etc/ssh/ssh_host",
    "/proc/keys",
    "/proc/kcore",
)
_PORTABLE_FORBIDDEN_CHARS = frozenset('<>:"|?*')
_MESHIA_RESERVED_TEMP_SEGMENT_RE = re.compile(
    r"^\..+\.meshia-(?:rename-)?[0-9a-f]{32}(?:\.owner)?$", re.IGNORECASE
)
_OWNED_TEMP_NAME_RE = re.compile(
    r"^\.__(?P<kind>stream|retire|write|rename)__\.meshia-"
    r"(?:(?:rename)-)?(?P<token>[0-9a-f]{32})$",
    re.IGNORECASE,
)
_PORTABLE_RESERVED_STEMS = frozenset(
    {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        "CLOCK$",
        "CONIN$",
        "CONOUT$",
        *(f"COM{suffix}" for suffix in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "¹", "²", "³")),
        *(f"LPT{suffix}" for suffix in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "¹", "²", "³")),
    }
)


@dataclass(frozen=True, slots=True)
class WorkspaceRootClaim:
    """Exclusive installation ownership recorded inside one workspace root."""

    schema: str
    workspace_id: str
    installation_id: str
    canonical_root: str
    adoption_pending: bool
    host_id: str | None = None
    session_id: str | None = None

    @property
    def is_bound(self) -> bool:
        """Whether the provisional installation claim has a live remote binding."""

        return self.host_id is not None and self.session_id is not None


@dataclass(frozen=True, slots=True)
class WorkspaceRootClaimStatus:
    """Read-only workspace-adoption state suitable for CLI presentation."""

    state: str
    canonical_root: str
    claim: WorkspaceRootClaim | None = None
    reason: str | None = None

    @property
    def requires_adoption(self) -> bool:
        return self.state == "adoption_required"


def _canonical_uuid(value: object, field: str, *, stored: bool = False) -> str:
    error_type = WorkspaceClaimInvalid if stored else InvalidTask
    if not isinstance(value, str):
        raise error_type(f"{field} must be a canonical UUID string.")
    try:
        parsed = str(uuid.UUID(value))
    except (ValueError, AttributeError) as error:
        raise error_type(f"{field} must be a canonical UUID string.") from error
    if parsed != value:
        raise error_type(f"{field} must be a canonical UUID string.")
    return parsed


def _workspace_root_input_path(root: Path | str) -> Path:
    try:
        raw = os.fspath(Path(root).expanduser())
    except (TypeError, ValueError, RuntimeError) as error:
        raise UnsafePath("The workspace root path is invalid.") from error
    if not isinstance(raw, str) or not raw or "\0" in raw:
        raise UnsafePath("The workspace root path is invalid.")
    return Path(os.path.abspath(raw))


def _canonical_workspace_root(path: Path) -> str:
    return os.path.normcase(os.path.realpath(str(path)))


def _workspace_root_claim_bytes(claim: WorkspaceRootClaim) -> bytes:
    payload: dict[str, object] = {
        "canonical_root": claim.canonical_root,
        "installation_id": claim.installation_id,
        "schema": claim.schema,
        "workspace_id": claim.workspace_id,
    }
    payload["adoption_pending"] = claim.adoption_pending
    if claim.is_bound:
        assert claim.host_id is not None and claim.session_id is not None
        payload["host_id"] = claim.host_id
        payload["session_id"] = claim.session_id
    return (
        json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n"
    ).encode("utf-8")


def _parse_workspace_root_claim(
    data: bytes, *, canonical_root: str
) -> WorkspaceRootClaim:
    if len(data) > _WORKSPACE_ROOT_CLAIM_MAX_BYTES:
        raise WorkspaceClaimInvalid("The workspace ownership marker is too large.")
    def reject_duplicate_fields(pairs: list[tuple[str, object]]) -> dict[str, object]:
        document: dict[str, object] = {}
        for key, value in pairs:
            if key in document:
                raise WorkspaceClaimInvalid(
                    "The workspace ownership marker contains duplicate fields."
                )
            document[key] = value
        return document

    try:
        document = json.loads(
            data.decode("utf-8"), object_pairs_hook=reject_duplicate_fields
        )
    except WorkspaceClaimInvalid:
        raise
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker is not valid UTF-8 JSON."
        ) from error
    if not isinstance(document, dict):
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker must be a JSON object."
        )
    base_fields = {
        "schema",
        "workspace_id",
        "installation_id",
        "canonical_root",
        "adoption_pending",
    }
    bound_fields = base_fields | {"host_id", "session_id"}
    fields = set(document)
    if fields not in (base_fields, bound_fields):
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker has an invalid schema."
        )
    if document.get("schema") != WORKSPACE_ROOT_CLAIM_SCHEMA:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker schema is unsupported."
        )
    adoption_pending = document.get("adoption_pending")
    if not isinstance(adoption_pending, bool):
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker has an invalid adoption_pending flag."
        )
    stored_root = document.get("canonical_root")
    if not isinstance(stored_root, str) or not stored_root or "\0" in stored_root:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker has an invalid canonical_root."
        )
    if stored_root != canonical_root:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker belongs to a different canonical root."
        )
    workspace_id = _canonical_uuid(document.get("workspace_id"), "workspace_id", stored=True)
    installation_id = _canonical_uuid(
        document.get("installation_id"), "installation_id", stored=True
    )
    host_id: str | None = None
    session_id: str | None = None
    if fields == bound_fields:
        host_id = _canonical_uuid(document.get("host_id"), "host_id", stored=True)
        session_id = _canonical_uuid(document.get("session_id"), "session_id", stored=True)
    return WorkspaceRootClaim(
        schema=WORKSPACE_ROOT_CLAIM_SCHEMA,
        workspace_id=workspace_id,
        installation_id=installation_id,
        canonical_root=stored_root,
        adoption_pending=adoption_pending,
        host_id=host_id,
        session_id=session_id,
    )


def _validate_workspace_root_claim_expectations(
    claim: WorkspaceRootClaim,
    *,
    installation_id: str | None,
    workspace_id: str | None,
    host_id: str | None,
    session_id: str | None,
    require_bound: bool,
) -> WorkspaceRootClaim:
    if installation_id is not None and claim.installation_id != installation_id:
        raise WorkspaceClaimInvalid(
            "The workspace is claimed by a different Meshia installation."
        )
    if workspace_id is not None and claim.workspace_id != workspace_id:
        raise WorkspaceClaimInvalid(
            "The workspace_id does not match the ownership marker."
        )
    if (host_id is None) != (session_id is None):
        raise InvalidTask("host_id and session_id must be supplied together.")
    if host_id is not None and (
        claim.host_id != host_id or claim.session_id != session_id
    ):
        raise WorkspaceClaimInvalid(
            "The workspace binding does not match the ownership marker."
        )
    if require_bound and not claim.is_bound:
        raise WorkspaceClaimInvalid(
            "The workspace ownership claim has not been bound yet."
        )
    return claim


def _validated_claim_arguments(
    *,
    installation_id: str | None,
    workspace_id: str | None,
    host_id: str | None,
    session_id: str | None,
) -> tuple[str | None, str | None, str | None, str | None]:
    if (host_id is None) != (session_id is None):
        raise InvalidTask("host_id and session_id must be supplied together.")
    return (
        _canonical_uuid(installation_id, "installation_id")
        if installation_id is not None
        else None,
        _canonical_uuid(workspace_id, "workspace_id")
        if workspace_id is not None
        else None,
        _canonical_uuid(host_id, "host_id") if host_id is not None else None,
        _canonical_uuid(session_id, "session_id") if session_id is not None else None,
    )


@dataclass(frozen=True, slots=True)
class FileFingerprint:
    """Cheap change hint for a single-link file, never content authority.

    Callers must still hash before suppressing a durable content update.  In
    particular, Windows does not expose NTFS's change time through portable
    ``stat`` fields on every supported Python version.
    """

    size_bytes: int
    mtime_ns: int
    ctime_ns: int
    device_id: int
    file_id: int


@dataclass(frozen=True, slots=True)
class HashedRegularFile:
    """A content digest tied to the exact file fingerprint that was read."""

    fingerprint: FileFingerprint
    sha256: str

    @property
    def tagged_sha256(self) -> str:
        return f"sha256:{self.sha256}"


@dataclass(frozen=True, slots=True)
class FingerprintReplaceResult:
    """Result of replacing an exact local identity without hashing its bytes."""

    written: HashedRegularFile
    preserved_path: str | None


@dataclass(frozen=True, slots=True)
class RetiredRegularFile:
    """A crash-recoverable old namespace entry retained through sync commit."""

    original_path: str
    temporary_path: str
    marker_path: str
    initial: HashedRegularFile
    retention_reservation: str | None = None
    accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL


@dataclass(frozen=True, slots=True)
class RetiredQuarantineStatus:
    """Bounded accounting for retired inodes awaiting safe reclamation.

    ``entry_count`` and ``bytes_on_disk`` retain the legacy promotion-queue
    view for compatibility.  The explicit retained fields are the authoritative
    live storage metrics: they include quiet quarantine owners, exact-removal
    owners, and owner-slot reservations, while keeping logical policy bytes
    separate from physical allocation.
    """

    entry_count: int
    bytes_on_disk: int
    oldest_quarantined_at_ns: int | None
    oldest_age_seconds: float
    promotion_backlog: int
    visible_promotion_backlog: int
    visible_promotion_overflow: bool
    max_entries: int
    max_bytes: int
    max_age_seconds: float
    recovery_pending: bool
    recovery_blocked: bool
    retained_owner_count: int | None = None
    logical_retained_bytes: int | None = None
    allocated_retained_bytes: int | None = None
    retention_reservation_count: int | None = None


@dataclass(frozen=True, slots=True)
class RetainedStorageUsage:
    """Physical and logical usage owned outside the public namespace."""

    owner_count: int
    logical_bytes: int
    allocated_bytes: int
    reservation_count: int
    additional_logical_bytes: int = 0
    materialized_row_logical_bytes: int = 0
    additional_allocated_bytes: int = 0
    materialized_row_allocated_bytes: int = 0


@dataclass(frozen=True, slots=True)
class RetiredQuarantinePromotion:
    """One visible retired inode whose durable owner marker awaits handoff."""

    original_path: str
    visible_path: str
    temporary_path: str
    marker_path: str
    conflict_path: str
    quarantined_at_ns: int
    recorded_size_bytes: int
    device_id: int
    file_id: int
    recorded_sha256: str | None = None
    recorded_mtime_ns: int | None = None
    recorded_ctime_ns: int | None = None
    retain_unchanged: bool = False
    accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL


@dataclass(frozen=True, slots=True)
class _RetiredQuarantineRecord:
    original_path: str
    temporary_path: str
    marker_path: str
    conflict_path: str
    quarantined_at_ns: int
    recorded_size_bytes: int
    device_id: int
    file_id: int
    recorded_sha256: str | None = None
    recorded_mtime_ns: int | None = None
    recorded_ctime_ns: int | None = None
    retain_unchanged: bool = False
    accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL


@dataclass(frozen=True, slots=True)
class _PendingFingerprintRemoval:
    """One exact delete-owned retire marker awaiting local finalization."""

    original_path: str
    temporary_path: str
    marker_path: str
    expected_fingerprint: FileFingerprint
    retired_ctime_ns: int | None = None


def _validate_retired_quarantine_bounds(
    max_bytes: int, max_entries: int, max_age_seconds: float
) -> tuple[int, int, float]:
    if (
        isinstance(max_bytes, bool)
        or not isinstance(max_bytes, int)
        or max_bytes < 0
        or isinstance(max_entries, bool)
        or not isinstance(max_entries, int)
        or max_entries < 0
        or isinstance(max_age_seconds, bool)
        or not isinstance(max_age_seconds, (int, float))
        or not math.isfinite(float(max_age_seconds))
        or float(max_age_seconds) < 0
    ):
        raise InvalidTask("Invalid retired-inode quarantine bounds.")
    return max_bytes, max_entries, float(max_age_seconds)


def _fingerprint_from_stat(info: os.stat_result) -> FileFingerprint:
    return FileFingerprint(
        size_bytes=int(info.st_size),
        mtime_ns=int(
            getattr(info, "st_mtime_ns", int(float(info.st_mtime) * 1_000_000_000))
        ),
        ctime_ns=int(
            getattr(info, "st_ctime_ns", int(float(info.st_ctime) * 1_000_000_000))
        ),
        device_id=int(info.st_dev),
        file_id=int(info.st_ino),
    )


def _allocated_file_bytes(info: os.stat_result) -> int:
    """Return charged local blocks, falling back to logical size portably."""

    blocks = getattr(info, "st_blocks", None)
    if isinstance(blocks, int) and not isinstance(blocks, bool) and blocks >= 0:
        return blocks * 512
    return int(info.st_size)


def _regular_fingerprint(info: os.stat_result, message: str) -> FileFingerprint:
    if not stat_module.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise UnsafePath(message)
    return _fingerprint_from_stat(info)


def _same_regular_state_after_rename(
    before: FileFingerprint, after: FileFingerprint
) -> bool:
    """Match file identity and byte-visible state across our namespace rename.

    Some filesystems advance inode change-time for rename/link operations. The
    caller must first prove the complete pre-rename ``FileFingerprint`` on an
    open no-follow descriptor and path. After the rename, device/inode, size,
    and modification time prove that the same byte state was moved while
    allowing only the ctime transition caused by our own namespace operation.
    """

    return (
        before.size_bytes == after.size_bytes
        and before.mtime_ns == after.mtime_ns
        and before.device_id == after.device_id
        and before.file_id == after.file_id
    )


def _directory_namespace_time_ns(info: os.stat_result) -> int:
    """Return the directory-entry modification time that witnesses a rename."""

    return int(
        getattr(info, "st_mtime_ns", int(float(info.st_mtime) * 1_000_000_000))
    )


_INOTIFY_FILE_CHANGE_MASK = 0x00000002 | 0x00000004 | 0x00000008
_INOTIFY_DELETE_SELF_MASK = 0x00000400
_INOTIFY_EXPECTED_RENAME_MASK = 0x00000800
_INOTIFY_UNTRUSTWORTHY_MASK = (
    _INOTIFY_DELETE_SELF_MASK | 0x00002000 | 0x00004000 | 0x00008000
)


def _open_linux_file_change_watch(descriptor: int) -> int:
    """Watch an already-open Linux inode without reading its contents.

    Timestamp fingerprints are intentionally cheap, but a coarse or unusual
    filesystem can collapse a same-size write and the retirement rename into
    one ctime interval. inotify supplies the missing kernel mutation witness on
    Linux while macOS and other platforms retain the stat-based guard.
    """

    if not sys.platform.startswith("linux"):
        return -1
    watch = -1
    try:
        library = ctypes.CDLL(None, use_errno=True)
        initialize = library.inotify_init1
        initialize.argtypes = (ctypes.c_int,)
        initialize.restype = ctypes.c_int
        add_watch = library.inotify_add_watch
        add_watch.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_uint32)
        add_watch.restype = ctypes.c_int
        watch = int(
            initialize(
                getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_CLOEXEC", 0)
            )
        )
        if watch < 0:
            return -1
        watched = int(
            add_watch(
                watch,
                f"/proc/self/fd/{descriptor}".encode("ascii"),
                _INOTIFY_FILE_CHANGE_MASK
                | _INOTIFY_EXPECTED_RENAME_MASK
                | _INOTIFY_DELETE_SELF_MASK,
            )
        )
        if watched < 0:
            os.close(watch)
            return -1
        return watch
    except (AttributeError, OSError):
        if watch >= 0:
            os.close(watch)
        return -1


def _linux_file_change_watch_detected(watch: int) -> bool:
    """Drain one nonblocking inotify watch and fail closed on unsafe events."""

    if watch < 0:
        return False
    while True:
        try:
            payload = os.read(watch, 4096)
        except BlockingIOError:
            return False
        except OSError:
            return True
        if not payload:
            return True
        offset = 0
        while offset < len(payload):
            if len(payload) - offset < 16:
                return True
            mask = int.from_bytes(payload[offset + 4 : offset + 8], sys.byteorder)
            name_bytes = int.from_bytes(
                payload[offset + 12 : offset + 16], sys.byteorder
            )
            if mask & (_INOTIFY_FILE_CHANGE_MASK | _INOTIFY_UNTRUSTWORTHY_MASK):
                return True
            offset += 16 + name_bytes


def _validate_stream_contract(
    expected_size: int,
    expected_sha256: str,
    expected_existing_sha256: str | None,
) -> None:
    if isinstance(expected_size, bool) or not isinstance(expected_size, int):
        raise InvalidTask("expected_size must be an integer number of bytes.")
    if not 0 <= expected_size <= MAX_STREAM_FILE_BYTES:
        raise InvalidTask("expected_size must be between 0 bytes and 1 TiB.")
    if not isinstance(expected_sha256, str) or not TAGGED_SHA256_RE.fullmatch(
        expected_sha256
    ):
        raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
    if expected_existing_sha256 is not None and (
        not isinstance(expected_existing_sha256, str)
        or not TAGGED_SHA256_RE.fullmatch(expected_existing_sha256)
    ):
        raise InvalidTask(
            "expected_existing_sha256 must be a tagged lowercase SHA-256 digest."
        )


def _stream_chunks_to_descriptor(
    descriptor: int,
    chunks: Iterable[bytes],
    *,
    expected_size: int,
    expected_sha256: str,
) -> None:
    """Write and verify immutable chunks without ever aggregating the file."""
    hasher = hashlib.sha256()
    total = 0
    try:
        iterator = iter(chunks)
    except TypeError as error:
        raise InvalidTask("chunks must be an iterable of bytes objects.") from error
    for chunk in iterator:
        if not isinstance(chunk, bytes):
            raise InvalidTask("Every streamed file chunk must be bytes.")
        if not chunk:
            raise InvalidTask(
                "Streamed file chunks must be non-empty; use no chunks for an empty file."
            )
        if len(chunk) > expected_size - total:
            raise InvalidTask("Streamed content exceeds expected_size.")
        hasher.update(chunk)
        total += len(chunk)
        view = memoryview(chunk)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise InvalidTask("Writing the workspace file made no progress.")
            view = view[written:]
    if total != expected_size:
        raise InvalidTask(
            f"Streamed content size {total} does not match expected_size {expected_size}."
        )
    if f"sha256:{hasher.hexdigest()}" != expected_sha256:
        raise InvalidTask("Streamed content does not match expected_sha256.")


def _copy_hash_open_regular(
    descriptor: int,
    destination_fd: int | None,
    max_bytes: int,
    chunk_bytes: int,
    on_chunk: Callable[[bytes, int], None] | None,
    chunk_sizes: Sequence[int] | None = None,
) -> HashedRegularFile:
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int):
        raise InvalidTask("max_bytes must be an integer number of bytes.")
    if not 0 <= max_bytes <= MAX_STREAM_FILE_BYTES:
        raise InvalidTask("max_bytes must be between 0 bytes and 1 TiB.")
    if isinstance(chunk_bytes, bool) or not isinstance(chunk_bytes, int):
        raise InvalidTask("chunk_bytes must be an integer number of bytes.")
    if not 1 <= chunk_bytes <= 4 * 1024 * 1024:
        raise InvalidTask("chunk_bytes must be between 1 byte and 4 MiB.")
    if destination_fd is not None and (
        isinstance(destination_fd, bool) or not isinstance(destination_fd, int) or destination_fd < 0
    ):
        raise InvalidTask("destination_fd must be an open file descriptor.")
    before_info = os.fstat(descriptor)
    before = _regular_fingerprint(
        before_info, "The source must be a single-link regular file."
    )
    if before.size_bytes > max_bytes:
        raise InvalidTask("The workspace file exceeds the streaming inspection limit.")
    planned_chunks: tuple[int, ...] | None = None
    if chunk_sizes is not None:
        planned_chunks = tuple(chunk_sizes)
        if (
            any(
                isinstance(size, bool)
                or not isinstance(size, int)
                or not 1 <= size <= 4 * 1024 * 1024
                for size in planned_chunks
            )
            or sum(planned_chunks) != before.size_bytes
        ):
            raise InvalidTask(
                "chunk_sizes must exactly cover the file with 1-byte to 4-MiB extents."
            )
    if destination_fd is not None:
        destination_info = os.fstat(destination_fd)
        if (
            stat_module.S_ISREG(destination_info.st_mode)
            and destination_info.st_dev == before_info.st_dev
            and destination_info.st_ino == before_info.st_ino
        ):
            raise InvalidTask("Source and destination descriptors must name different files.")
    hasher = hashlib.sha256()
    total = 0
    remaining = before.size_bytes
    chunk_index = 0
    while remaining:
        requested = (
            planned_chunks[chunk_index]
            if planned_chunks is not None
            else min(chunk_bytes, remaining)
        )
        first = os.read(descriptor, requested)
        if len(first) == requested:
            payload = first
        else:
            chunk = bytearray(first)
            while len(chunk) < requested:
                part = os.read(descriptor, requested - len(chunk))
                if not part:
                    break
                chunk.extend(part)
            payload = bytes(chunk)
        if not payload:
            break
        if len(payload) != requested:
            break
        if on_chunk is not None:
            on_chunk(payload, total)
        if destination_fd is not None:
            view = memoryview(payload)
            while view:
                written = os.write(destination_fd, view)
                if written <= 0:
                    raise InvalidTask("Copying the workspace file made no progress.")
                view = view[written:]
        total += len(payload)
        remaining -= len(payload)
        hasher.update(payload)
        chunk_index += 1
    after_info = os.fstat(descriptor)
    after = _regular_fingerprint(
        after_info, "The source must remain a single-link regular file."
    )
    if before != after or total != after.size_bytes:
        raise InvalidTask("The workspace file changed while it was being hashed.")
    return HashedRegularFile(fingerprint=after, sha256=hasher.hexdigest())


def _copy_open_regular_identity(
    descriptor: int,
    destination_fd: int,
    expected: FileFingerprint,
    max_bytes: int,
    chunk_bytes: int,
) -> FileFingerprint:
    """Copy one descriptor anchored by stat identity, deliberately without hashing."""

    if not isinstance(expected, FileFingerprint):
        raise InvalidTask("expected must be a FileFingerprint.")
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int):
        raise InvalidTask("max_bytes must be an integer number of bytes.")
    if not 0 <= max_bytes <= MAX_STREAM_FILE_BYTES:
        raise InvalidTask("max_bytes must be between 0 bytes and 1 TiB.")
    if isinstance(chunk_bytes, bool) or not isinstance(chunk_bytes, int):
        raise InvalidTask("chunk_bytes must be an integer number of bytes.")
    if not 1 <= chunk_bytes <= 4 * 1024 * 1024:
        raise InvalidTask("chunk_bytes must be between 1 byte and 4 MiB.")
    if (
        isinstance(destination_fd, bool)
        or not isinstance(destination_fd, int)
        or destination_fd < 0
    ):
        raise InvalidTask("destination_fd must be an open file descriptor.")
    before_info = os.fstat(descriptor)
    before = _regular_fingerprint(
        before_info, "The source must be a single-link regular file."
    )
    if before != expected:
        raise InvalidTask("The workspace file no longer has the recorded identity.")
    if before.size_bytes > max_bytes:
        raise InvalidTask("The workspace file exceeds the streaming inspection limit.")
    destination_info = os.fstat(destination_fd)
    if (
        stat_module.S_ISREG(destination_info.st_mode)
        and destination_info.st_dev == before_info.st_dev
        and destination_info.st_ino == before_info.st_ino
    ):
        raise InvalidTask("Source and destination descriptors must name different files.")

    os.ftruncate(destination_fd, before.size_bytes)

    def read_at(offset: int, size: int) -> bytes:
        if hasattr(os, "pread"):
            return os.pread(descriptor, size, offset)
        os.lseek(descriptor, offset, os.SEEK_SET)
        return os.read(descriptor, size)

    def write_at(data: memoryview, offset: int) -> int:
        if hasattr(os, "pwrite"):
            return os.pwrite(destination_fd, data, offset)
        os.lseek(destination_fd, offset, os.SEEK_SET)
        return os.write(destination_fd, data)

    def copy_extent(start: int, end: int) -> None:
        offset = start
        while offset < end:
            chunk = read_at(offset, min(chunk_bytes, end - offset))
            if not chunk:
                raise InvalidTask("The workspace file was truncated during copy.")
            view = memoryview(chunk)
            written_offset = offset
            while view:
                written = write_at(view, written_offset)
                if written <= 0:
                    raise InvalidTask("Copying the workspace file made no progress.")
                view = view[written:]
                written_offset += written
            offset += len(chunk)

    sparse_supported = bool(
        hasattr(os, "SEEK_DATA") and hasattr(os, "SEEK_HOLE")
    )
    if sparse_supported and before.size_bytes:
        offset = 0
        try:
            while offset < before.size_bytes:
                try:
                    data_offset = os.lseek(descriptor, offset, os.SEEK_DATA)
                except OSError as error:
                    if error.errno == errno.ENXIO:
                        break
                    raise
                hole_offset = os.lseek(descriptor, data_offset, os.SEEK_HOLE)
                copy_extent(data_offset, min(hole_offset, before.size_bytes))
                offset = max(hole_offset, data_offset + 1)
        except OSError as error:
            if error.errno not in {
                errno.EINVAL,
                getattr(errno, "ENOTSUP", errno.EINVAL),
                getattr(errno, "EOPNOTSUPP", errno.EINVAL),
            }:
                raise
            os.ftruncate(destination_fd, 0)
            os.ftruncate(destination_fd, before.size_bytes)
            copy_extent(0, before.size_bytes)
    else:
        copy_extent(0, before.size_bytes)
    after = _regular_fingerprint(
        os.fstat(descriptor), "The source must remain a single-link regular file."
    )
    if after != expected:
        raise InvalidTask("The workspace file changed while it was being copied.")
    return after


def _hash_open_regular(descriptor: int, max_bytes: int) -> HashedRegularFile:
    return _copy_hash_open_regular(
        descriptor, None, max_bytes, STREAM_IO_BYTES, None
    )


def _fsync_directory_when_supported(descriptor: int) -> None:
    """Persist a directory entry, tolerating filesystems that cannot fsync dirs."""
    try:
        os.fsync(descriptor)
    except OSError as error:
        unsupported = {
            errno.EINVAL,
            getattr(errno, "ENOTSUP", errno.EINVAL),
            getattr(errno, "EOPNOTSUPP", errno.EINVAL),
        }
        if error.errno not in unsupported:
            raise


def _marker_staging_name(marker: str) -> str:
    if not marker.endswith(STREAM_TEMP_MARKER_SUFFIX):
        raise InvalidTask("The private marker name is invalid.")
    temporary = marker[: -len(STREAM_TEMP_MARKER_SUFFIX)]
    match = _OWNED_TEMP_NAME_RE.fullmatch(temporary)
    if match is None or str(match.group("kind")).lower() not in {"stream", "retire"}:
        raise InvalidTask("The private marker name is invalid.")
    return f".__write__.meshia-{str(match.group('token')).lower()}{STREAM_TEMP_MARKER_SUFFIX}"


def _marker_stage_payload_is_bound(stage_name: str, data: bytes) -> bool:
    """Authenticate a marker-publication stage against its embedded token."""

    if not stage_name.endswith(STREAM_TEMP_MARKER_SUFFIX):
        return False
    temporary = stage_name[: -len(STREAM_TEMP_MARKER_SUFFIX)]
    match = _OWNED_TEMP_NAME_RE.fullmatch(temporary)
    if match is None or str(match.group("kind")).lower() != "write":
        return False
    token = str(match.group("token")).lower()
    stream_marker = f".__stream__.meshia-{token}{STREAM_TEMP_MARKER_SUFFIX}"
    retire_marker = f".__retire__.meshia-{token}{STREAM_TEMP_MARKER_SUFFIX}"
    return (
        _parse_stream_temp_marker(stream_marker, data) is not None
        or _parse_retire_temp_marker(retire_marker, data) is not None
        or _parse_fingerprint_remove_temp_marker(retire_marker, data) is not None
        or _parse_retired_quarantine_marker(retire_marker, data) is not None
    )


def _write_marker_stage_at(parent: int, stage: str, data: bytes) -> None:
    descriptor = os.open(
        stage,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_CLOEXEC,
        0o600,
        dir_fd=parent,
    )
    try:
        os.fchmod(descriptor, 0o600)
        view = memoryview(data)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise InvalidTask("Writing the retire owner marker made no progress.")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _write_private_marker_at(parent: int, marker: str, data: bytes) -> None:
    """Publish a complete private marker without ever exposing partial JSON."""

    stage = _marker_staging_name(marker)
    published = False
    try:
        _write_marker_stage_at(parent, stage, data)
        os.link(
            stage,
            marker,
            src_dir_fd=parent,
            dst_dir_fd=parent,
            follow_symlinks=False,
        )
        published = True
        _fsync_directory_when_supported(parent)
        os.unlink(stage, dir_fd=parent)
        _fsync_directory_when_supported(parent)
    except BaseException:
        if published:
            try:
                os.unlink(marker, dir_fd=parent)
            except OSError:
                pass
        try:
            os.unlink(stage, dir_fd=parent)
        except OSError:
            pass
        try:
            _fsync_directory_when_supported(parent)
        except OSError:
            pass
        raise


def _replace_private_marker_at(parent: int, marker: str, data: bytes) -> None:
    """Atomically replace one owned marker with another complete state."""

    stage = _marker_staging_name(marker)
    try:
        _write_marker_stage_at(parent, stage, data)
        os.replace(stage, marker, src_dir_fd=parent, dst_dir_fd=parent)
        _fsync_directory_when_supported(parent)
    finally:
        try:
            os.unlink(stage, dir_fd=parent)
        except OSError:
            pass


def _stream_temp_marker_bytes(
    temporary: str, target: str, expected_size: int, expected_sha256: str
) -> bytes:
    return json.dumps(
        {
            "expected_sha256": expected_sha256,
            "expected_size": expected_size,
            "owner_pid": os.getpid(),
            "schema": STREAM_TEMP_SCHEMA,
            "target": target,
            "temporary": temporary,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _owned_temporary_name(kind: str) -> str:
    """Return a NAME_MAX-safe sibling independent of a user component length."""

    if kind not in {"stream", "retire", "write", "rename"}:
        raise ValueError("unknown Meshia temporary kind")
    separator = "rename-" if kind == "rename" else ""
    return f".__{kind}__.meshia-{separator}{uuid.uuid4().hex}"


def _owned_temporary_kind(name: str) -> str | None:
    match = _OWNED_TEMP_NAME_RE.fullmatch(name)
    if match is None:
        return None
    kind = str(match.group("kind")).lower()
    has_rename_separator = ".meshia-rename-" in name.lower()
    if has_rename_separator != (kind == "rename"):
        return None
    return kind


def _legacy_owned_temporary_for_target(
    temporary: str, target: str, *, rename: bool = False
) -> bool:
    prefix = f".{target}.meshia-{'rename-' if rename else ''}"
    token = temporary[len(prefix) :] if temporary.startswith(prefix) else ""
    return len(token) == 32 and all(
        character in "0123456789abcdef" for character in token.lower()
    )


def _marker_temporary_matches(
    temporary: str, target: str, *, kind: str
) -> bool:
    return _owned_temporary_kind(temporary) == kind or (
        kind in {"stream", "retire"}
        and _legacy_owned_temporary_for_target(temporary, target)
    )


def _bounded_retire_conflict_name(
    target: str, temporary: str, *, name_max: int = 255
) -> str:
    """Return the stable visible name used to reclaim one quarantined inode."""

    match = _OWNED_TEMP_NAME_RE.fullmatch(temporary)
    identity = (
        str(match.group("token")).lower()
        if match is not None and str(match.group("kind")).lower() == "retire"
        else hashlib.sha256(temporary.encode("utf-8")).hexdigest()[:32]
    )
    suffix = f".meshia-conflict-retired-{identity}"
    bounded_name_max = min(255, max(1, int(name_max)))
    budget = bounded_name_max - len(suffix.encode("utf-8"))
    if budget < 1:
        raise InvalidTask("The workspace filesystem cannot name a retire conflict safely.")
    prefix = target
    while prefix and len(prefix.encode("utf-8")) > budget:
        prefix = prefix[:-1]
    prefix = prefix.rstrip(" .") or "r"
    if len(prefix.encode("utf-8")) > budget:
        raise InvalidTask("The workspace filesystem cannot name a retire conflict safely.")
    return f"{prefix}{suffix}"


def retired_quarantine_recovery_path(conflict_path: str) -> str:
    """Return the deterministic top-level home for orphaned retire evidence."""

    conflict_name = split_relative(conflict_path)[-1]
    return f"{RETIRED_QUARANTINE_RECOVERY_DIRECTORY}/{conflict_name}"


def _retire_temp_marker_bytes(temporary: str, target: str) -> bytes:
    """Describe an atomic retire so crash recovery never strands user bytes."""

    return json.dumps(
        {
            "owner_pid": os.getpid(),
            "schema": RETIRE_TEMP_SCHEMA,
            "target": target,
            "temporary": temporary,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _fingerprint_remove_temp_marker_bytes(
    temporary: str,
    target: str,
    expected_fingerprint: FileFingerprint,
    *,
    retired_ctime_ns: int | None = None,
) -> bytes:
    """Persist delete intent so recovery cannot resurrect an accepted delete."""

    if not isinstance(expected_fingerprint, FileFingerprint):
        raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
    if retired_ctime_ns is not None and (
        isinstance(retired_ctime_ns, bool) or not isinstance(retired_ctime_ns, int)
    ):
        raise InvalidTask("retired_ctime_ns must be an integer or None.")
    return json.dumps(
        {
            "expected_ctime_ns": expected_fingerprint.ctime_ns,
            "expected_device_id": expected_fingerprint.device_id,
            "expected_file_id": expected_fingerprint.file_id,
            "expected_mtime_ns": expected_fingerprint.mtime_ns,
            "expected_size_bytes": expected_fingerprint.size_bytes,
            "owner_pid": os.getpid(),
            "retired_ctime_ns": retired_ctime_ns,
            "schema": FINGERPRINT_REMOVE_TEMP_SCHEMA,
            "target": target,
            "temporary": temporary,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _retired_quarantine_marker_bytes(
    temporary: str,
    target: str,
    conflict: str,
    captured: HashedRegularFile,
    quarantined_at_ns: int,
    *,
    retain_unchanged: bool = False,
    accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
) -> bytes:
    if accounting_owner not in _RETAINED_STORAGE_ACCOUNTS:
        raise InvalidTask("Invalid retained storage accounting owner.")
    return json.dumps(
        {
            "accounting_owner": accounting_owner,
            "conflict": conflict,
            "device_id": captured.fingerprint.device_id,
            "file_id": captured.fingerprint.file_id,
            "quarantined_at_ns": quarantined_at_ns,
            "recorded_sha256": captured.sha256,
            "recorded_ctime_ns": captured.fingerprint.ctime_ns,
            "recorded_mtime_ns": captured.fingerprint.mtime_ns,
            "recorded_size_bytes": captured.fingerprint.size_bytes,
            "retain_unchanged": retain_unchanged,
            "schema": RETIRED_QUARANTINE_SCHEMA,
            "target": target,
            "temporary": temporary,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _retire_target_from_marker_name(marker_name: str) -> str | None:
    """Recover the target spelling from an owned-looking sibling marker.

    This deliberately does not trust the marker body: malformed or unreadable
    metadata must still block an eviction from treating the hidden target as a
    proven absence.
    """

    if not marker_name.endswith(STREAM_TEMP_MARKER_SUFFIX):
        return None
    temporary = marker_name[: -len(STREAM_TEMP_MARKER_SUFFIX)]
    if _owned_temporary_kind(temporary) is not None:
        # Bounded v2 names intentionally contain no user target spelling.
        return None
    if not temporary.startswith(".") or ".meshia-" not in temporary:
        return None
    target, token = temporary[1:].rsplit(".meshia-", 1)
    if (
        not target
        or len(token) != 32
        or any(character not in "0123456789abcdef" for character in token)
    ):
        return None
    return target


def _parse_stream_temp_marker(marker_name: str, data: bytes) -> dict[str, object] | None:
    try:
        value = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or set(value) != {
        "expected_sha256",
        "expected_size",
        "owner_pid",
        "schema",
        "target",
        "temporary",
    }:
        return None
    temporary = value.get("temporary")
    target = value.get("target")
    owner_pid = value.get("owner_pid")
    expected_size = value.get("expected_size")
    expected_sha256 = value.get("expected_sha256")
    if (
        value.get("schema") != STREAM_TEMP_SCHEMA
        or not isinstance(temporary, str)
        or not isinstance(target, str)
        or marker_name != temporary + STREAM_TEMP_MARKER_SUFFIX
        or not _marker_temporary_matches(temporary, target, kind="stream")
        or not isinstance(owner_pid, int)
        or isinstance(owner_pid, bool)
        or owner_pid <= 0
        or not isinstance(expected_size, int)
        or isinstance(expected_size, bool)
        or not 0 <= expected_size <= MAX_STREAM_FILE_BYTES
        or not isinstance(expected_sha256, str)
        or not TAGGED_SHA256_RE.fullmatch(expected_sha256)
    ):
        return None
    try:
        if split_relative(target) != [target]:
            return None
    except (InvalidTask, UnsafePath):
        return None
    return value


def _parse_retire_temp_marker(marker_name: str, data: bytes) -> dict[str, object] | None:
    try:
        value = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or set(value) != {
        "owner_pid",
        "schema",
        "target",
        "temporary",
    }:
        return None
    temporary = value.get("temporary")
    target = value.get("target")
    owner_pid = value.get("owner_pid")
    if (
        value.get("schema") != RETIRE_TEMP_SCHEMA
        or not isinstance(temporary, str)
        or not isinstance(target, str)
        or marker_name != temporary + STREAM_TEMP_MARKER_SUFFIX
        or not _marker_temporary_matches(temporary, target, kind="retire")
        or not isinstance(owner_pid, int)
        or isinstance(owner_pid, bool)
        or owner_pid <= 0
    ):
        return None
    try:
        if split_relative(target) != [target]:
            return None
    except (InvalidTask, UnsafePath):
        return None
    return value


def _parse_fingerprint_remove_temp_marker(
    marker_name: str, data: bytes
) -> dict[str, object] | None:
    try:
        value = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    numeric_fields = {
        "expected_ctime_ns",
        "expected_device_id",
        "expected_file_id",
        "expected_mtime_ns",
        "expected_size_bytes",
        "owner_pid",
    }
    if not isinstance(value, dict) or set(value) not in (
        numeric_fields
        | {
            "schema",
            "target",
            "temporary",
        },
        numeric_fields
        | {
            "retired_ctime_ns",
            "schema",
            "target",
            "temporary",
        },
    ):
        return None
    retired_ctime_ns = value.get("retired_ctime_ns")
    if retired_ctime_ns is not None and (
        isinstance(retired_ctime_ns, bool) or not isinstance(retired_ctime_ns, int)
    ):
        return None
    temporary = value.get("temporary")
    target = value.get("target")
    if (
        value.get("schema") != FINGERPRINT_REMOVE_TEMP_SCHEMA
        or not isinstance(temporary, str)
        or not isinstance(target, str)
        or marker_name != temporary + STREAM_TEMP_MARKER_SUFFIX
        or not _marker_temporary_matches(temporary, target, kind="retire")
        or any(
            isinstance(value.get(field), bool)
            or not isinstance(value.get(field), int)
            for field in numeric_fields
        )
        or int(value["owner_pid"]) <= 0
        or not 0 <= int(value["expected_size_bytes"]) <= MAX_STREAM_FILE_BYTES
        or int(value["expected_device_id"]) < 0
        or int(value["expected_file_id"]) < 0
    ):
        return None
    try:
        if split_relative(target) != [target]:
            return None
    except (InvalidTask, UnsafePath):
        return None
    # A marker written by an older build or before the post-rename identity was
    # durably captured is intentionally incomplete. Recovery must restore that
    # inode instead of guessing whether a ctime transition was only our rename.
    value["retired_ctime_ns"] = retired_ctime_ns
    return value


def _parse_retired_quarantine_marker(
    marker_name: str, data: bytes
) -> dict[str, object] | None:
    try:
        value = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict):
        return None
    legacy_fields = {
        "conflict",
        "device_id",
        "file_id",
        "quarantined_at_ns",
        "recorded_size_bytes",
        "schema",
        "target",
        "temporary",
    }
    previous_fields = legacy_fields | {
        "recorded_sha256",
        "recorded_ctime_ns",
        "recorded_mtime_ns",
        "retain_unchanged",
    }
    current_fields = previous_fields | {"accounting_owner"}
    if set(value) not in (legacy_fields, previous_fields, current_fields):
        return None
    temporary = value.get("temporary")
    target = value.get("target")
    conflict = value.get("conflict")
    numeric = (
        value.get("device_id"),
        value.get("file_id"),
        value.get("quarantined_at_ns"),
        value.get("recorded_size_bytes"),
    )
    if set(value) == legacy_fields:
        value["recorded_ctime_ns"] = None
        value["recorded_mtime_ns"] = None
        value["recorded_sha256"] = None
        value["retain_unchanged"] = False
        value["accounting_owner"] = RETAINED_STORAGE_ACCOUNT_ADDITIONAL
    elif set(value) == previous_fields:
        value["accounting_owner"] = RETAINED_STORAGE_ACCOUNT_ADDITIONAL
    recorded_sha256 = value.get("recorded_sha256")
    recorded_ctime_ns = value.get("recorded_ctime_ns")
    recorded_mtime_ns = value.get("recorded_mtime_ns")
    retain_unchanged = value.get("retain_unchanged")
    accounting_owner = value.get("accounting_owner")
    if (
        value.get("schema") != RETIRED_QUARANTINE_SCHEMA
        or not isinstance(temporary, str)
        or not isinstance(target, str)
        or not isinstance(conflict, str)
        or marker_name != temporary + STREAM_TEMP_MARKER_SUFFIX
        or not _marker_temporary_matches(temporary, target, kind="retire")
        or any(isinstance(item, bool) or not isinstance(item, int) for item in numeric)
        or int(value["device_id"]) < 0
        or int(value["file_id"]) < 0
        or int(value["quarantined_at_ns"]) <= 0
        or not 0 <= int(value["recorded_size_bytes"]) <= MAX_STREAM_FILE_BYTES
        or (
            recorded_ctime_ns is not None
            and (
                isinstance(recorded_ctime_ns, bool)
                or not isinstance(recorded_ctime_ns, int)
                or recorded_ctime_ns < 0
            )
        )
        or (
            recorded_mtime_ns is not None
            and (
                isinstance(recorded_mtime_ns, bool)
                or not isinstance(recorded_mtime_ns, int)
                or recorded_mtime_ns < 0
            )
        )
        or not isinstance(retain_unchanged, bool)
        or accounting_owner not in _RETAINED_STORAGE_ACCOUNTS
        or (
            recorded_sha256 is not None
            and (
                not isinstance(recorded_sha256, str)
                or re.fullmatch(r"[0-9a-f]{64}", recorded_sha256) is None
            )
        )
        or (
            retain_unchanged
            and (
                recorded_ctime_ns is None
                or recorded_mtime_ns is None
                or recorded_sha256 is None
            )
        )
    ):
        return None
    try:
        if split_relative(target) != [target]:
            return None
        if (
            split_relative(conflict) != [conflict]
            or conflict
            != _bounded_retire_conflict_name(
                target, temporary, name_max=len(conflict.encode("utf-8"))
            )
        ):
            return None
    except (InvalidTask, UnsafePath):
        return None
    return value


def _pid_is_live(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _utf8_bytes(value: str) -> bytes:
    try:
        return value.encode("utf-8")
    except UnicodeEncodeError as error:
        raise UnsafePath("Workspace paths must contain valid Unicode text.") from error


def _utf16_units(value: str) -> int:
    """Return JavaScript ``String.length`` for manifest-contract parity."""

    try:
        return len(value.encode("utf-16-le")) // 2
    except UnicodeEncodeError as error:
        raise UnsafePath("Workspace paths must contain valid Unicode text.") from error


def _split_relative(
    path: str,
    *,
    allow_root: bool,
    allow_owned_temporary: bool,
) -> list[str]:
    if not isinstance(path, str):
        raise UnsafePath("Task paths must be strings.")
    if "\0" in path:
        raise UnsafePath("Task paths cannot contain NUL bytes.")
    if (
        _utf16_units(path) > MAX_PATH_UTF16_UNITS
        or len(_utf8_bytes(path)) > MAX_PATH_BYTES
    ):
        raise UnsafePath(
            "Task paths must be at most 1024 UTF-16 units and 4096 UTF-8 bytes."
        )
    if allow_root and path in ("", "."):
        return []
    if path.startswith("/") or path.startswith("~") or "\\" in path:
        raise UnsafePath("Task paths must be relative to the mounted workspace.")
    if len(path) > 1 and path[1] == ":" and path[0].isalpha():
        raise UnsafePath("Task paths must be relative to the mounted workspace.")
    parts = path.split("/")
    if not parts or any(part in ("", ".", "..") for part in parts):
        raise UnsafePath("Task paths cannot contain empty, dot, or parent components.")
    for part in parts:
        if unicodedata.normalize("NFC", part) != part:
            raise UnsafePath("Workspace path components must use NFC Unicode spelling.")
        if len(_utf8_bytes(part)) > 255:
            raise UnsafePath("Workspace path components must be at most 255 UTF-8 bytes.")
        if part[-1] in (" ", "."):
            raise UnsafePath("Workspace path components cannot end in a space or dot.")
        if any(
            character in _PORTABLE_FORBIDDEN_CHARS
            or ord(character) < 32
            or ord(character) == 127
            for character in part
        ):
            raise UnsafePath("Workspace paths contain characters unsupported on Windows.")
        if part.lower() == ".meshia":
            raise UnsafePath("Workspace paths cannot use Meshia's reserved metadata directory.")
        if (
            not allow_owned_temporary
            and _MESHIA_RESERVED_TEMP_SEGMENT_RE.fullmatch(part) is not None
        ):
            raise UnsafePath("Workspace paths cannot use Meshia-owned temporary names.")
        if part.split(".", 1)[0].upper() in _PORTABLE_RESERVED_STEMS:
            raise UnsafePath("Workspace paths cannot use Windows reserved device names.")
    return parts


def split_relative(path: str, allow_root: bool = False) -> list[str]:
    """Return one public Fabric path under the portable namespace contract.

    Decomposed Unicode is rejected in place. It is never normalized here:
    normalizing would silently alias two local names on decomposing filesystems.
    """

    return _split_relative(
        path,
        allow_root=allow_root,
        allow_owned_temporary=False,
    )


def _split_owned_relative(path: str) -> list[str]:
    """Validate a Meshia-generated sibling temp after its ownership proof.

    This is deliberately private. Callers must first authenticate the exact
    generated name/owner marker; user-supplied paths always use
    :func:`split_relative` and cannot opt into the exception.
    """

    parts = _split_relative(
        path,
        allow_root=False,
        allow_owned_temporary=True,
    )
    if _MESHIA_RESERVED_TEMP_SEGMENT_RE.fullmatch(parts[-1]) is None:
        raise UnsafePath("The path is not a Meshia-owned temporary name.")
    return parts


def _same_file_identity(left: os.stat_result, right: os.stat_result) -> bool:
    return left.st_dev == right.st_dev and left.st_ino == right.st_ino


def _open_posix_workspace_root(
    root: Path | str, *, create: bool
) -> tuple[Path, str, int, bool]:
    """Open the literal root without following its final component."""

    path = _workspace_root_input_path(root)
    created = False
    try:
        before = os.lstat(path)
    except FileNotFoundError:
        if not create:
            raise
        try:
            path.mkdir(mode=0o700, parents=True)
            created = True
        except FileExistsError:
            pass
        try:
            before = os.lstat(path)
        except OSError as error:
            raise UnsafePath("The workspace root could not be created safely.") from error
    except OSError as error:
        raise UnsafePath("The workspace root could not be inspected safely.") from error
    if stat_module.S_ISLNK(before.st_mode):
        raise UnsafePath("The workspace root must not be a symbolic link.")
    if not stat_module.S_ISDIR(before.st_mode):
        raise UnsafePath("The workspace root must be a directory.")
    try:
        descriptor = os.open(str(path), _DIR_FLAGS)
    except OSError as error:
        raise UnsafePath(
            "The workspace root could not be opened without following links."
        ) from error
    try:
        opened = os.fstat(descriptor)
        current = os.lstat(path)
        if (
            not stat_module.S_ISDIR(opened.st_mode)
            or stat_module.S_ISLNK(current.st_mode)
            or not _same_file_identity(opened, before)
            or not _same_file_identity(opened, current)
        ):
            raise WorkspaceClaimInvalid(
                "The workspace root changed while it was being opened."
            )
        canonical_root = _canonical_workspace_root(path)
        current = os.lstat(path)
        if not _same_file_identity(opened, current):
            raise WorkspaceClaimInvalid(
                "The workspace root changed while it was being canonicalized."
            )
        return path, canonical_root, descriptor, created
    except BaseException:
        os.close(descriptor)
        raise


def _assert_posix_workspace_root_current(path: Path, descriptor: int) -> None:
    try:
        current = os.lstat(path)
        opened = os.fstat(descriptor)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The claimed workspace root is no longer available."
        ) from error
    if (
        stat_module.S_ISLNK(current.st_mode)
        or not stat_module.S_ISDIR(current.st_mode)
        or not _same_file_identity(current, opened)
    ):
        raise WorkspaceClaimInvalid(
            "The claimed workspace root was replaced after validation."
        )


def _inspect_workspace_root_entries(
    directory: int | Path,
) -> tuple[str | None, bool]:
    """Find the private marker directory with O(1) namespace memory.

    Enrollment and status may inspect an arbitrary preexisting root.  Loading
    every name merely to answer "empty?" and "does .meshia exist exactly?"
    would let a large local directory create a first-use memory spike.
    """

    metadata_name: str | None = None
    has_public_entries = False
    with os.scandir(directory) as entries:
        for entry in entries:
            name = entry.name
            if name.casefold() == WORKSPACE_METADATA_DIRECTORY.casefold():
                if name != WORKSPACE_METADATA_DIRECTORY or metadata_name is not None:
                    raise WorkspaceClaimInvalid(
                        "The workspace contains a case-conflicting Meshia metadata path."
                    )
                metadata_name = name
            else:
                has_public_entries = True
    return metadata_name, has_public_entries


def _directory_has_entries(directory: int | Path) -> bool:
    with os.scandir(directory) as entries:
        return next(entries, None) is not None


def _open_posix_workspace_metadata(
    root_fd: int,
    *,
    create: bool,
    repair_privacy: bool,
) -> tuple[int, bool]:
    created = False
    try:
        before = os.stat(
            WORKSPACE_METADATA_DIRECTORY,
            dir_fd=root_fd,
            follow_symlinks=False,
        )
    except FileNotFoundError:
        if not create:
            raise
        try:
            os.mkdir(WORKSPACE_METADATA_DIRECTORY, 0o700, dir_fd=root_fd)
            created = True
            _fsync_directory_when_supported(root_fd)
        except FileExistsError:
            pass
        try:
            before = os.stat(
                WORKSPACE_METADATA_DIRECTORY,
                dir_fd=root_fd,
                follow_symlinks=False,
            )
        except OSError as error:
            raise WorkspaceClaimInvalid(
                "The private workspace metadata directory could not be created safely."
            ) from error
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The private workspace metadata directory could not be inspected safely."
        ) from error
    if stat_module.S_ISLNK(before.st_mode) or not stat_module.S_ISDIR(before.st_mode):
        raise WorkspaceClaimInvalid(
            "The private workspace metadata path must be a real directory."
        )
    try:
        descriptor = os.open(WORKSPACE_METADATA_DIRECTORY, _DIR_FLAGS, dir_fd=root_fd)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The private workspace metadata directory could not be opened safely."
        ) from error
    try:
        opened = os.fstat(descriptor)
        current = os.stat(
            WORKSPACE_METADATA_DIRECTORY,
            dir_fd=root_fd,
            follow_symlinks=False,
        )
        if not _same_file_identity(before, opened) or not _same_file_identity(
            opened, current
        ):
            raise WorkspaceClaimInvalid(
                "The private workspace metadata directory changed during validation."
            )
        if hasattr(os, "geteuid") and opened.st_uid != os.geteuid():
            raise WorkspaceClaimInvalid(
                "The private workspace metadata directory has a different owner."
            )
        if stat_module.S_IMODE(opened.st_mode) != 0o700:
            if not repair_privacy:
                raise WorkspaceClaimInvalid(
                    "The private workspace metadata directory must use mode 0700."
                )
            os.fchmod(descriptor, 0o700)
            _fsync_directory_when_supported(descriptor)
        return descriptor, created
    except BaseException:
        os.close(descriptor)
        raise


def _interrupted_posix_claim_stage(
    metadata_fd: int, marker_info: os.stat_result
) -> str | None:
    """Return the one private stage accounting for a marker's second link."""

    if marker_info.st_nlink != 2:
        return None
    matched: str | None = None
    with os.scandir(metadata_fd) as entries:
        for entry in entries:
            if _WORKSPACE_ROOT_CLAIM_STAGE_RE.fullmatch(entry.name) is None:
                continue
            try:
                info = entry.stat(follow_symlinks=False)
            except OSError as error:
                raise WorkspaceClaimInvalid(
                    "The interrupted workspace ownership stage is unsafe."
                ) from error
            if not _same_file_identity(info, marker_info):
                continue
            if (
                matched is not None
                or stat_module.S_ISLNK(info.st_mode)
                or not stat_module.S_ISREG(info.st_mode)
                or info.st_nlink != 2
                or stat_module.S_IMODE(info.st_mode) != 0o600
                or (hasattr(os, "geteuid") and info.st_uid != os.geteuid())
            ):
                raise WorkspaceClaimInvalid(
                    "The interrupted workspace ownership stage is invalid."
                )
            matched = entry.name
    if matched is None:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker has an unaccounted hard link."
        )
    return matched


def _read_posix_orphan_claim_stage(
    metadata_fd: int, *, canonical_root: str
) -> tuple[WorkspaceRootClaim, str] | None:
    """Read one fully-fsynced pre-publication stage after an abrupt exit."""

    stage: str | None = None
    with os.scandir(metadata_fd) as entries:
        for entry in entries:
            if _WORKSPACE_ROOT_CLAIM_STAGE_RE.fullmatch(entry.name) is None:
                raise WorkspaceClaimInvalid(
                    "The reserved metadata directory contains data but no ownership marker."
                )
            if stage is not None:
                raise WorkspaceClaimInvalid(
                    "Multiple interrupted workspace ownership stages were found."
                )
            stage = entry.name
    if stage is None:
        return None
    try:
        before = os.stat(stage, dir_fd=metadata_fd, follow_symlinks=False)
        descriptor = os.open(stage, _FILE_FLAGS, dir_fd=metadata_fd)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The interrupted workspace ownership stage could not be opened safely."
        ) from error
    try:
        opened = os.fstat(descriptor)
        if (
            stat_module.S_ISLNK(before.st_mode)
            or not _same_file_identity(before, opened)
            or not stat_module.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or stat_module.S_IMODE(opened.st_mode) != 0o600
            or (hasattr(os, "geteuid") and opened.st_uid != os.geteuid())
        ):
            raise WorkspaceClaimInvalid(
                "The interrupted workspace ownership stage is not a private file."
            )
        data = os.read(descriptor, _WORKSPACE_ROOT_CLAIM_MAX_BYTES + 1)
        current = os.stat(stage, dir_fd=metadata_fd, follow_symlinks=False)
        if not _same_file_identity(opened, current) or current.st_nlink != 1:
            raise WorkspaceClaimInvalid(
                "The interrupted workspace ownership stage changed while it was read."
            )
    finally:
        os.close(descriptor)
    claim = _parse_workspace_root_claim(data, canonical_root=canonical_root)
    if claim.is_bound:
        raise WorkspaceClaimInvalid(
            "A bound workspace claim cannot be recovered without its published marker."
        )
    return claim, stage


def _repair_interrupted_posix_claim_publish(
    metadata_fd: int,
    root_fd: int,
    *,
    canonical_root: str,
    expected_claim: WorkspaceRootClaim,
) -> bool:
    """Publish or remove an authenticated stage after its claim parsed cleanly."""

    try:
        marker_info = os.stat(
            WORKSPACE_ROOT_CLAIM_NAME,
            dir_fd=metadata_fd,
            follow_symlinks=False,
        )
    except FileNotFoundError:
        orphan = _read_posix_orphan_claim_stage(
            metadata_fd, canonical_root=canonical_root
        )
        if orphan is None or orphan[0] != expected_claim:
            raise WorkspaceClaimInvalid(
                "The interrupted workspace ownership stage changed before recovery."
            )
        stage = orphan[1]
        try:
            os.link(
                stage,
                WORKSPACE_ROOT_CLAIM_NAME,
                src_dir_fd=metadata_fd,
                dst_dir_fd=metadata_fd,
                follow_symlinks=False,
            )
            os.unlink(stage, dir_fd=metadata_fd)
        except OSError as error:
            raise WorkspaceClaimInvalid(
                "The interrupted workspace ownership stage could not be published."
            ) from error
        _fsync_directory_when_supported(metadata_fd)
        _fsync_directory_when_supported(root_fd)
        return True
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker changed before recovery."
        ) from error
    stage = _interrupted_posix_claim_stage(metadata_fd, marker_info)
    if stage is None:
        return False
    try:
        os.unlink(stage, dir_fd=metadata_fd)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The interrupted workspace ownership stage could not be recovered."
        ) from error
    _fsync_directory_when_supported(metadata_fd)
    _fsync_directory_when_supported(root_fd)
    return True


def _read_posix_workspace_root_claim(
    metadata_fd: int, *, canonical_root: str
) -> WorkspaceRootClaim | None:
    try:
        before = os.stat(
            WORKSPACE_ROOT_CLAIM_NAME,
            dir_fd=metadata_fd,
            follow_symlinks=False,
        )
    except FileNotFoundError:
        return None
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker could not be inspected safely."
        ) from error
    if stat_module.S_ISLNK(before.st_mode) or not stat_module.S_ISREG(before.st_mode):
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker must be a regular file."
        )
    try:
        descriptor = os.open(WORKSPACE_ROOT_CLAIM_NAME, _FILE_FLAGS, dir_fd=metadata_fd)
    except OSError as error:
        raise WorkspaceClaimInvalid(
            "The workspace ownership marker could not be opened without following links."
        ) from error
    try:
        opened = os.fstat(descriptor)
        interrupted_stage = (
            _interrupted_posix_claim_stage(metadata_fd, opened)
            if opened.st_nlink == 2
            else None
        )
        if (
            not _same_file_identity(before, opened)
            or not stat_module.S_ISREG(opened.st_mode)
            or opened.st_nlink not in (1, 2)
            or (opened.st_nlink == 2 and interrupted_stage is None)
            or stat_module.S_IMODE(opened.st_mode) != 0o600
            or (hasattr(os, "geteuid") and opened.st_uid != os.geteuid())
        ):
            raise WorkspaceClaimInvalid(
                "The workspace ownership marker is not a private single-link file."
            )
        data = os.read(descriptor, _WORKSPACE_ROOT_CLAIM_MAX_BYTES + 1)
        current = os.stat(
            WORKSPACE_ROOT_CLAIM_NAME,
            dir_fd=metadata_fd,
            follow_symlinks=False,
        )
        if (
            not _same_file_identity(opened, current)
            or current.st_nlink not in (1, opened.st_nlink)
            or (
                current.st_nlink == 2
                and _interrupted_posix_claim_stage(metadata_fd, current)
                != interrupted_stage
            )
        ):
            raise WorkspaceClaimInvalid(
                "The workspace ownership marker changed while it was being read."
            )
    finally:
        os.close(descriptor)
    return _parse_workspace_root_claim(data, canonical_root=canonical_root)


def _write_posix_workspace_root_claim(
    root_fd: int,
    metadata_fd: int,
    claim: WorkspaceRootClaim,
    *,
    replace: bool,
) -> None:
    stage = f".workspace-root.{uuid.uuid4().hex}.tmp"
    descriptor = os.open(
        stage,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_CLOEXEC,
        0o600,
        dir_fd=metadata_fd,
    )
    published = False
    try:
        try:
            os.fchmod(descriptor, 0o600)
            view = memoryview(_workspace_root_claim_bytes(claim))
            while view:
                written = os.write(descriptor, view)
                if written <= 0:
                    raise WorkspaceClaimInvalid(
                        "Writing the workspace ownership marker made no progress."
                    )
                view = view[written:]
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        if replace:
            os.replace(
                stage,
                WORKSPACE_ROOT_CLAIM_NAME,
                src_dir_fd=metadata_fd,
                dst_dir_fd=metadata_fd,
            )
        else:
            os.link(
                stage,
                WORKSPACE_ROOT_CLAIM_NAME,
                src_dir_fd=metadata_fd,
                dst_dir_fd=metadata_fd,
                follow_symlinks=False,
            )
            os.unlink(stage, dir_fd=metadata_fd)
        published = True
        _fsync_directory_when_supported(metadata_fd)
        _fsync_directory_when_supported(root_fd)
    finally:
        if not published:
            try:
                os.unlink(stage, dir_fd=metadata_fd)
            except OSError:
                pass


def _validated_workspace_root_claim_at(
    root_fd: int,
    *,
    canonical_root: str,
    installation_id: str | None,
    workspace_id: str | None,
    host_id: str | None,
    session_id: str | None,
    require_bound: bool,
) -> WorkspaceRootClaim:
    metadata_name, _ = _inspect_workspace_root_entries(root_fd)
    if metadata_name is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    metadata_fd, _ = _open_posix_workspace_metadata(
        root_fd, create=False, repair_privacy=False
    )
    try:
        claim = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if claim is None:
            orphan = _read_posix_orphan_claim_stage(
                metadata_fd, canonical_root=canonical_root
            )
            claim = orphan[0] if orphan is not None else None
    finally:
        os.close(metadata_fd)
    if claim is None:
        raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
    return _validate_workspace_root_claim_expectations(
        claim,
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
        require_bound=require_bound,
    )


def workspace_root_claim_status(
    root: Path | str,
    *,
    installation_id: str | None = None,
    workspace_id: str | None = None,
    host_id: str | None = None,
    session_id: str | None = None,
    require_bound: bool = False,
) -> WorkspaceRootClaimStatus:
    """Inspect ownership without creating, chmodding, or repairing anything."""

    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    ownership_expected = bool(
        workspace_id is not None
        or host_id is not None
        or session_id is not None
        or require_bound
    )
    path = _workspace_root_input_path(root)
    display_root = str(path)
    try:
        path, canonical_root, root_fd, _ = _open_posix_workspace_root(root, create=False)
    except FileNotFoundError:
        if ownership_expected:
            return WorkspaceRootClaimStatus(
                state="invalid",
                canonical_root=display_root,
                reason="The claimed workspace root is missing.",
            )
        return WorkspaceRootClaimStatus(state="missing", canonical_root=display_root)
    except (UnsafePath, WorkspaceClaimInvalid, OSError) as error:
        return WorkspaceRootClaimStatus(
            state="invalid", canonical_root=display_root, reason=str(error)
        )
    try:
        metadata_name, has_public_entries = _inspect_workspace_root_entries(root_fd)
        if metadata_name is None:
            if ownership_expected:
                return WorkspaceRootClaimStatus(
                    state="invalid",
                    canonical_root=canonical_root,
                    reason="The workspace ownership marker is missing.",
                )
            state = "adoption_required" if has_public_entries else "unclaimed_empty"
            return WorkspaceRootClaimStatus(state=state, canonical_root=canonical_root)
        metadata_fd, _ = _open_posix_workspace_metadata(
            root_fd, create=False, repair_privacy=False
        )
        try:
            claim = _read_posix_workspace_root_claim(
                metadata_fd, canonical_root=canonical_root
            )
            if claim is None:
                orphan = _read_posix_orphan_claim_stage(
                    metadata_fd, canonical_root=canonical_root
                )
                claim = orphan[0] if orphan is not None else None
            if claim is None:
                if ownership_expected:
                    raise WorkspaceClaimInvalid(
                        "The workspace ownership marker is missing."
                    )
                if _directory_has_entries(metadata_fd):
                    raise WorkspaceClaimInvalid(
                        "The reserved metadata directory contains data but no ownership marker."
                    )
                return WorkspaceRootClaimStatus(
                    state=(
                        "adoption_required" if has_public_entries else "unclaimed_empty"
                    ),
                    canonical_root=canonical_root,
                )
        finally:
            os.close(metadata_fd)
        claim = _validate_workspace_root_claim_expectations(
            claim,
            installation_id=installation_id,
            workspace_id=workspace_id,
            host_id=host_id,
            session_id=session_id,
            require_bound=require_bound,
        )
        _assert_posix_workspace_root_current(path, root_fd)
        return WorkspaceRootClaimStatus(
            state="bound" if claim.is_bound else "provisional",
            canonical_root=canonical_root,
            claim=claim,
        )
    except (UnsafePath, WorkspaceClaimInvalid, OSError) as error:
        return WorkspaceRootClaimStatus(
            state="invalid", canonical_root=canonical_root, reason=str(error)
        )
    finally:
        os.close(root_fd)


def claim_workspace_root(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str | None = None,
    adopt: bool = False,
    adoption_pending: bool | None = None,
) -> WorkspaceRootClaim:
    """Create an exclusive provisional claim, gating preexisting local bytes."""

    if not isinstance(adopt, bool):
        raise InvalidTask("adopt must be a boolean.")
    if adoption_pending is not None and not isinstance(adoption_pending, bool):
        raise InvalidTask("adoption_pending must be a boolean or None.")
    installation_id, requested_workspace_id, _, _ = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=None,
        session_id=None,
    )
    assert installation_id is not None
    claimed_workspace_id = requested_workspace_id or str(uuid.uuid4())
    path, canonical_root, root_fd, _ = _open_posix_workspace_root(root, create=True)
    metadata_fd = -1
    try:
        metadata_name, has_public_entries = _inspect_workspace_root_entries(root_fd)
        if metadata_name is not None:
            metadata_fd, _ = _open_posix_workspace_metadata(
                root_fd, create=False, repair_privacy=False
            )
            existing = _read_posix_workspace_root_claim(
                metadata_fd, canonical_root=canonical_root
            )
            if existing is None:
                orphan = _read_posix_orphan_claim_stage(
                    metadata_fd, canonical_root=canonical_root
                )
                existing = orphan[0] if orphan is not None else None
            if existing is not None:
                existing = _validate_workspace_root_claim_expectations(
                    existing,
                    installation_id=installation_id,
                    workspace_id=requested_workspace_id,
                    host_id=None,
                    session_id=None,
                    require_bound=False,
                )
                if (
                    adoption_pending is not None
                    and existing.adoption_pending != adoption_pending
                ):
                    raise WorkspaceClaimInvalid(
                        "adoption_pending does not match the existing ownership marker."
                    )
                _repair_interrupted_posix_claim_publish(
                    metadata_fd,
                    root_fd,
                    canonical_root=canonical_root,
                    expected_claim=existing,
                )
                _assert_posix_workspace_root_current(path, root_fd)
                return existing
            if _directory_has_entries(metadata_fd):
                raise WorkspaceClaimInvalid(
                    "The reserved metadata directory contains data but no ownership marker."
                )
            if has_public_entries and not adopt:
                raise WorkspaceAdoptionRequired(
                    "The non-empty workspace requires explicit adoption before Meshia can use it."
                )
            os.close(metadata_fd)
            metadata_fd, _ = _open_posix_workspace_metadata(
                root_fd, create=False, repair_privacy=True
            )
        else:
            if has_public_entries and not adopt:
                raise WorkspaceAdoptionRequired(
                    "The non-empty workspace requires explicit adoption before Meshia can use it."
                )
            metadata_fd, _ = _open_posix_workspace_metadata(
                root_fd, create=True, repair_privacy=True
            )
        pending = has_public_entries if adoption_pending is None else adoption_pending
        claim = WorkspaceRootClaim(
            schema=WORKSPACE_ROOT_CLAIM_SCHEMA,
            workspace_id=claimed_workspace_id,
            installation_id=installation_id,
            canonical_root=canonical_root,
            adoption_pending=pending,
        )
        try:
            _write_posix_workspace_root_claim(
                root_fd, metadata_fd, claim, replace=False
            )
        except FileExistsError as error:
            raise WorkspaceClaimInvalid(
                "Another process claimed the workspace concurrently; retry validation."
            ) from error
        stored = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if stored != claim:
            raise WorkspaceClaimInvalid(
                "The workspace ownership marker did not persist exactly."
            )
        _assert_posix_workspace_root_current(path, root_fd)
        return stored
    finally:
        if metadata_fd >= 0:
            os.close(metadata_fd)
        os.close(root_fd)


def validate_workspace_root_claim(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    host_id: str | None = None,
    session_id: str | None = None,
    require_bound: bool = False,
) -> WorkspaceRootClaim:
    """Fail closed unless the private marker exactly matches current ownership."""

    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    path, canonical_root, root_fd, _ = _open_posix_workspace_root(root, create=False)
    try:
        claim = _validated_workspace_root_claim_at(
            root_fd,
            canonical_root=canonical_root,
            installation_id=installation_id,
            workspace_id=workspace_id,
            host_id=host_id,
            session_id=session_id,
            require_bound=require_bound,
        )
        _assert_posix_workspace_root_current(path, root_fd)
        return claim
    finally:
        os.close(root_fd)


def bind_workspace_root_claim(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    host_id: str,
    session_id: str,
) -> WorkspaceRootClaim:
    """Atomically bind a provisional claim; a different binding is never stolen."""

    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    assert None not in (installation_id, workspace_id, host_id, session_id)
    path, canonical_root, root_fd, _ = _open_posix_workspace_root(root, create=False)
    metadata_fd = -1
    try:
        metadata_name, _ = _inspect_workspace_root_entries(root_fd)
        if metadata_name is None:
            raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
        metadata_fd, _ = _open_posix_workspace_metadata(
            root_fd, create=False, repair_privacy=False
        )
        current = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if current is None:
            orphan = _read_posix_orphan_claim_stage(
                metadata_fd, canonical_root=canonical_root
            )
            current = orphan[0] if orphan is not None else None
        if current is None:
            raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
        _validate_workspace_root_claim_expectations(
            current,
            installation_id=installation_id,
            workspace_id=workspace_id,
            host_id=None,
            session_id=None,
            require_bound=False,
        )
        _repair_interrupted_posix_claim_publish(
            metadata_fd,
            root_fd,
            canonical_root=canonical_root,
            expected_claim=current,
        )
        if current.is_bound:
            validated = _validate_workspace_root_claim_expectations(
                current,
                installation_id=installation_id,
                workspace_id=workspace_id,
                host_id=host_id,
                session_id=session_id,
                require_bound=True,
            )
            _assert_posix_workspace_root_current(path, root_fd)
            return validated
        bound = WorkspaceRootClaim(
            schema=current.schema,
            workspace_id=current.workspace_id,
            installation_id=current.installation_id,
            canonical_root=current.canonical_root,
            adoption_pending=current.adoption_pending,
            host_id=host_id,
            session_id=session_id,
        )
        _write_posix_workspace_root_claim(
            root_fd, metadata_fd, bound, replace=True
        )
        stored = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if stored != bound:
            raise WorkspaceClaimInvalid(
                "The bound workspace ownership marker did not persist exactly."
            )
        _assert_posix_workspace_root_current(path, root_fd)
        return stored
    finally:
        if metadata_fd >= 0:
            os.close(metadata_fd)
        os.close(root_fd)


def rebind_workspace_root_claim(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    expected_host_id: str,
    expected_session_id: str,
    host_id: str,
    session_id: str,
) -> WorkspaceRootClaim:
    """CAS an exact prior remote binding onto a proven replacement session.

    A fresh workspace pairing keeps the private installation/workspace identity
    but changes its remote session authority. This operation is deliberately
    separate from ``bind_workspace_root_claim``: ordinary binding can only move
    from provisional to bound, while re-pair must name the exact old binding it
    is replacing. A replay after config publication is idempotent when the new
    binding already landed.
    """

    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    _, _, expected_host_id, expected_session_id = _validated_claim_arguments(
        installation_id=None,
        workspace_id=None,
        host_id=expected_host_id,
        session_id=expected_session_id,
    )
    assert None not in (
        installation_id,
        workspace_id,
        expected_host_id,
        expected_session_id,
        host_id,
        session_id,
    )
    path, canonical_root, root_fd, _ = _open_posix_workspace_root(root, create=False)
    metadata_fd = -1
    try:
        metadata_name, _ = _inspect_workspace_root_entries(root_fd)
        if metadata_name is None:
            raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
        metadata_fd, _ = _open_posix_workspace_metadata(
            root_fd, create=False, repair_privacy=False
        )
        current = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if current is None:
            raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
        _validate_workspace_root_claim_expectations(
            current,
            installation_id=installation_id,
            workspace_id=workspace_id,
            host_id=None,
            session_id=None,
            require_bound=True,
        )
        if current.host_id == host_id and current.session_id == session_id:
            _assert_posix_workspace_root_current(path, root_fd)
            return current
        if (
            current.host_id != expected_host_id
            or current.session_id != expected_session_id
        ):
            raise WorkspaceClaimInvalid(
                "The workspace ownership marker no longer has the expected prior binding."
            )
        rebound = WorkspaceRootClaim(
            schema=current.schema,
            workspace_id=current.workspace_id,
            installation_id=current.installation_id,
            canonical_root=current.canonical_root,
            adoption_pending=current.adoption_pending,
            host_id=host_id,
            session_id=session_id,
        )
        _write_posix_workspace_root_claim(
            root_fd, metadata_fd, rebound, replace=True
        )
        stored = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if stored != rebound:
            raise WorkspaceClaimInvalid(
                "The rebound workspace ownership marker did not persist exactly."
            )
        _assert_posix_workspace_root_current(path, root_fd)
        return stored
    finally:
        if metadata_fd >= 0:
            os.close(metadata_fd)
        os.close(root_fd)


def complete_workspace_root_adoption(
    root: Path | str,
    *,
    installation_id: str,
    workspace_id: str,
    host_id: str,
    session_id: str,
) -> WorkspaceRootClaim:
    """Persist completion only after conflict-first adoption has succeeded."""

    installation_id, workspace_id, host_id, session_id = _validated_claim_arguments(
        installation_id=installation_id,
        workspace_id=workspace_id,
        host_id=host_id,
        session_id=session_id,
    )
    assert None not in (installation_id, workspace_id, host_id, session_id)
    path, canonical_root, root_fd, _ = _open_posix_workspace_root(root, create=False)
    metadata_fd = -1
    try:
        metadata_name, _ = _inspect_workspace_root_entries(root_fd)
        if metadata_name is None:
            raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
        metadata_fd, _ = _open_posix_workspace_metadata(
            root_fd, create=False, repair_privacy=False
        )
        current = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if current is None:
            orphan = _read_posix_orphan_claim_stage(
                metadata_fd, canonical_root=canonical_root
            )
            current = orphan[0] if orphan is not None else None
        if current is None:
            raise WorkspaceClaimInvalid("The workspace ownership marker is missing.")
        _validate_workspace_root_claim_expectations(
            current,
            installation_id=installation_id,
            workspace_id=workspace_id,
            host_id=host_id,
            session_id=session_id,
            require_bound=True,
        )
        _repair_interrupted_posix_claim_publish(
            metadata_fd,
            root_fd,
            canonical_root=canonical_root,
            expected_claim=current,
        )
        if not current.adoption_pending:
            _assert_posix_workspace_root_current(path, root_fd)
            return current
        completed = WorkspaceRootClaim(
            schema=current.schema,
            workspace_id=current.workspace_id,
            installation_id=current.installation_id,
            canonical_root=current.canonical_root,
            adoption_pending=False,
            host_id=current.host_id,
            session_id=current.session_id,
        )
        _write_posix_workspace_root_claim(
            root_fd, metadata_fd, completed, replace=True
        )
        stored = _read_posix_workspace_root_claim(
            metadata_fd, canonical_root=canonical_root
        )
        if stored != completed:
            raise WorkspaceClaimInvalid(
                "The completed workspace ownership marker did not persist exactly."
            )
        _assert_posix_workspace_root_current(path, root_fd)
        return stored
    finally:
        if metadata_fd >= 0:
            os.close(metadata_fd)
        os.close(root_fd)


class WorkspaceBoundary:
    """A pinned directory that writes can never leave."""

    def __init__(
        self,
        root: Path | str,
        *,
        recover_stream_temps: bool = True,
        retired_quarantine_max_bytes: int = RETIRED_QUARANTINE_MAX_BYTES,
        retired_quarantine_max_entries: int = RETIRED_QUARANTINE_MAX_ENTRIES,
        retired_quarantine_max_age_seconds: float = RETIRED_QUARANTINE_MAX_AGE_SECONDS,
    ) -> None:
        (
            self._retired_quarantine_max_bytes,
            self._retired_quarantine_max_entries,
            self._retired_quarantine_max_age_seconds,
        ) = _validate_retired_quarantine_bounds(
            retired_quarantine_max_bytes,
            retired_quarantine_max_entries,
            retired_quarantine_max_age_seconds,
        )
        try:
            self._root_path, canonical_root, self._root_fd, _ = (
                _open_posix_workspace_root(root, create=False)
            )
        except FileNotFoundError as error:
            path = _workspace_root_input_path(root)
            raise UnsafePath(f"The synchronized workspace {path} does not exist.") from error
        self.root = Path(canonical_root)
        self._stream_recovery_scan: Iterator[
            tuple[int, str, os.stat_result | None, bool, str]
        ] | None = None
        self._blocked_retire_targets: set[str] = set()
        self._ambiguous_retire_recovery = False
        self._stream_recovery_retry_required = False
        self._pending_fingerprint_removals: dict[
            str, _PendingFingerprintRemoval
        ] = {}
        self._fingerprint_marker_cleanup: set[str] = set()
        self._pending_fingerprint_removals_lock = threading.RLock()
        self._stream_recovery_quarantine_seen: dict[
            str, _RetiredQuarantineRecord
        ] = {}
        self._retired_quarantine: dict[str, _RetiredQuarantineRecord] = {}
        self._retired_quarantine_lock = threading.RLock()
        self._retained_retirement_reservations: set[str] = set()
        self._retired_quarantine_visible_promotions: list[
            RetiredQuarantinePromotion
        ] = []
        self._retired_quarantine_promotion_overflow = False
        self._retired_quarantine_maintenance_error = False
        self.stream_recovery_pending = True
        # Bounded and ownership-marker-gated: this never treats a filename
        # pattern alone as permission to delete user data.
        if recover_stream_temps:
            self.recover_stale_stream_temps()

    def close(self) -> None:
        if self._stream_recovery_scan is not None:
            self._stream_recovery_scan.close()
            self._stream_recovery_scan = None
        if self._root_fd >= 0:
            os.close(self._root_fd)
            self._root_fd = -1

    def __enter__(self) -> "WorkspaceBoundary":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def __del__(self) -> None:  # pragma: no cover - best effort
        try:
            self.close()
        except Exception:
            pass

    def recover_stale_stream_temps(
        self,
        *,
        min_age_seconds: float = STREAM_TEMP_STALE_SECONDS,
        max_entries: int = STREAM_TEMP_SCAVENGE_MAX_ENTRIES,
    ) -> tuple[int, bool]:
        """Recover owned crash remnants without scanning an unbounded workspace.

        Returns ``(removed, truncated)``. A matching private owner sidecar is
        mandatory; pattern-shaped user files without one are never touched.
        """
        if min_age_seconds < 0 or max_entries < 1:
            raise InvalidTask("Invalid stream-temp recovery bounds.")
        cutoff_ns = time.time_ns() - int(min_age_seconds * 1_000_000_000)
        visited = 0
        removed = 0
        if self._stream_recovery_scan is None:
            self._stream_recovery_retry_required = False
            self._stream_recovery_quarantine_seen = {}
            self._stream_recovery_scan = self._iter_stream_recovery_entries()
        while visited < max_entries:
            try:
                directory, name, info, is_directory, relative_directory = next(
                    self._stream_recovery_scan
                )
            except StopIteration:
                self._stream_recovery_scan = None
                if self._stream_recovery_retry_required:
                    self._stream_recovery_quarantine_seen = {}
                    self.stream_recovery_pending = True
                    return removed, True
                self._retired_quarantine = dict(
                    self._stream_recovery_quarantine_seen
                )
                self._stream_recovery_quarantine_seen = {}
                self.stream_recovery_pending = False
                try:
                    self.maintain_retired_quarantine()
                except (InvalidTask, OSError, UnsafePath):
                    # The marker and hidden inode remain durable. Surface a
                    # persistent fail-closed status instead of losing bytes or
                    # making constructor recovery non-deterministically fatal.
                    self._retired_quarantine_maintenance_error = True
                return removed, False
            visited += 1
            if not is_directory and name.endswith(STREAM_TEMP_MARKER_SUFFIX):
                temporary_name = name[: -len(STREAM_TEMP_MARKER_SUFFIX)]
                if _owned_temporary_kind(temporary_name) == "write":
                    recovered = bool(
                        info is not None
                        and self._recover_marker_stage_at(directory, name, info)
                    )
                    if recovered:
                        removed += 1
                        _fsync_directory_when_supported(directory)
                    elif info is None:
                        self._stream_recovery_retry_required = True
                    continue
                outcome = (
                    self._recover_stream_marker_at(
                        directory,
                        name,
                        info,
                        cutoff_ns,
                        relative_directory,
                    )
                    if info is not None
                    else "retry"
                )
                if outcome == "removed":
                    removed += 1
                    _fsync_directory_when_supported(directory)
                elif outcome == "blocked":
                    target = _retire_target_from_marker_name(name)
                    if (
                        target is None
                        and _owned_temporary_kind(temporary_name) == "retire"
                    ):
                        target = self._read_blocked_retire_target_at(
                            directory, name, info
                        )
                        if target is None:
                            # The target lives only in the private marker body.
                            # If that body is malformed or inaccessible, fail
                            # closed for every eviction until an operator repairs
                            # the owned sidecar; never bless hidden bytes absent.
                            self._ambiguous_retire_recovery = True
                    if target is not None:
                        self._blocked_retire_targets.add(
                            f"{relative_directory}/{target}"
                            if relative_directory
                            else target
                        )
        self.stream_recovery_pending = True
        return removed, True

    def _iter_stream_recovery_entries(
        self,
    ) -> Iterator[tuple[int, str, os.stat_result | None, bool, str]]:
        """Walk with one directory handle; failed subtrees force a fresh pass."""

        pending: list[tuple[str, ...]] = [()]
        discovered = 0
        while pending:
            parts = pending.pop()
            relative_directory = "/".join(parts)
            try:
                directory = self._open_directory(parts)
            except (OSError, UnsafePath):
                self._stream_recovery_retry_required = True
                continue
            try:
                try:
                    entries = os.scandir(directory)
                except OSError:
                    self._stream_recovery_retry_required = True
                    continue
                try:
                    for entry in entries:
                        discovered += 1
                        if discovered > MAX_LIST_ENTRIES:
                            self._stream_recovery_retry_required = True
                            return
                        try:
                            info = entry.stat(follow_symlinks=False)
                        except FileNotFoundError:
                            # Earlier recovery in this same directory may have
                            # removed a hard-linked marker stage already.
                            continue
                        except OSError:
                            self._stream_recovery_retry_required = True
                            yield directory, entry.name, None, False, relative_directory
                            continue
                        is_directory = stat_module.S_ISDIR(info.st_mode)
                        yield directory, entry.name, info, is_directory, relative_directory
                        if is_directory:
                            pending.append((*parts, entry.name))
                except OSError:
                    self._stream_recovery_retry_required = True
                finally:
                    entries.close()
            finally:
                os.close(directory)

    def retire_recovery_blocked(self, path: str) -> bool:
        """Whether startup found an owned-looking retire it could not recover.

        This is intentionally persistent for the lifetime of the boundary.
        PID reuse, a live writer, malformed metadata, or an inaccessible
        marker must never be reinterpreted later as proof that a missing path
        was safely evicted.
        """

        normalized = "/".join(split_relative(path))
        with self._pending_fingerprint_removals_lock:
            exact_delete_pending = any(
                pending.original_path == normalized
                for pending in self._pending_fingerprint_removals.values()
            )
        return (
            self.stream_recovery_pending
            or self._stream_recovery_retry_required
            or self._retired_quarantine_maintenance_error
            or self._ambiguous_retire_recovery
            or normalized in self._blocked_retire_targets
            or exact_delete_pending
        )

    def has_pending_fingerprint_removal(
        self, path: str, *, expected_fingerprint: FileFingerprint
    ) -> bool:
        """Whether exact delete-owned retirement evidence still needs cleanup."""

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        normalized = "/".join(split_relative(path))
        with self._pending_fingerprint_removals_lock:
            return any(
                pending.original_path == normalized
                and pending.expected_fingerprint == expected_fingerprint
                for pending in self._pending_fingerprint_removals.values()
            )

    def _remember_pending_fingerprint_removal(
        self, pending: _PendingFingerprintRemoval
    ) -> None:
        with self._pending_fingerprint_removals_lock:
            self._pending_fingerprint_removals[pending.marker_path] = pending

    def _forget_pending_fingerprint_removal(self, marker_path: str) -> None:
        with self._pending_fingerprint_removals_lock:
            self._pending_fingerprint_removals.pop(marker_path, None)

    def _matching_pending_fingerprint_removals(
        self, path: str, expected_fingerprint: FileFingerprint
    ) -> tuple[_PendingFingerprintRemoval, ...]:
        with self._pending_fingerprint_removals_lock:
            return tuple(
                pending
                for pending in self._pending_fingerprint_removals.values()
                if pending.original_path == path
                and pending.expected_fingerprint == expected_fingerprint
            )

    def _fingerprint_removal_pending(self) -> bool:
        with self._pending_fingerprint_removals_lock:
            return bool(self._pending_fingerprint_removals)

    @_serialize_retired_quarantine
    def retained_retirement_capacity_available(self) -> bool:
        """Whether one more hidden owner can be admitted without promotion."""

        with self._pending_fingerprint_removals_lock:
            pending = len(self._pending_fingerprint_removals)
        return (
            len(self._retired_quarantine)
            + pending
            + len(self._retained_retirement_reservations)
            < self._retired_quarantine_max_entries
        )

    @_serialize_retired_quarantine
    def retained_storage_usage(self) -> RetainedStorageUsage:
        """Account every authenticated retained inode exactly once.

        Quarantine promotion can move one inode from its private temporary to a
        conflict or recovery path while deliberately leaving the owner marker
        in place until Fabric durably accepts the bytes.  Accounting follows
        that marker-bound identity instead of a particular pathname.  The
        explicit owner class also separates allocations already represented by
        a still-live materialized row (eviction) from additional overwrite or
        delete survivors.
        """

        logical_bytes = 0
        allocated_bytes = 0
        additional_allocated_bytes = 0
        materialized_row_allocated_bytes = 0
        additional_logical_bytes = 0
        materialized_row_logical_bytes = 0
        owner_count = 0
        seen_identities: set[tuple[int, int]] = set()

        def charge(
            path: str,
            expected: FileFingerprint,
            *,
            accounting_owner: str,
            owned_path: bool,
        ) -> bool:
            nonlocal logical_bytes, allocated_bytes, owner_count
            nonlocal additional_allocated_bytes
            nonlocal materialized_row_allocated_bytes
            nonlocal additional_logical_bytes
            nonlocal materialized_row_logical_bytes
            parts = (
                _split_owned_relative(path)
                if owned_path
                else split_relative(path)
            )
            opened = self._open_parent_if_present(parts)
            if opened is None:
                return False
            parent, name = opened
            try:
                try:
                    info = os.stat(name, dir_fd=parent, follow_symlinks=False)
                except OSError:
                    return False
                if (
                    not stat_module.S_ISREG(info.st_mode)
                    or int(info.st_dev) != expected.device_id
                    or int(info.st_ino) != expected.file_id
                ):
                    return False
                identity = (int(info.st_dev), int(info.st_ino))
                if identity in seen_identities:
                    return True
                seen_identities.add(identity)
                charged = _allocated_file_bytes(info)
                owner_count += 1
                logical_bytes += int(info.st_size)
                allocated_bytes += charged
                if accounting_owner == RETAINED_STORAGE_ACCOUNT_MATERIALIZED_ROW:
                    materialized_row_logical_bytes += int(info.st_size)
                    materialized_row_allocated_bytes += charged
                else:
                    additional_logical_bytes += int(info.st_size)
                    additional_allocated_bytes += charged
                return True
            finally:
                os.close(parent)

        for record in self._retired_quarantine.values():
            marker_parts = _split_owned_relative(record.marker_path)
            marker_opened = self._open_parent_if_present(marker_parts)
            if marker_opened is None:
                continue
            marker_parent, marker_name = marker_opened
            try:
                self._validate_quarantine_marker_at(
                    marker_parent, marker_name, record
                )
            finally:
                os.close(marker_parent)
            expected = FileFingerprint(
                size_bytes=record.recorded_size_bytes,
                mtime_ns=record.recorded_mtime_ns or -1,
                ctime_ns=record.recorded_ctime_ns or -1,
                device_id=record.device_id,
                file_id=record.file_id,
            )
            candidates = (
                (record.temporary_path, True),
                (record.conflict_path, False),
                (retired_quarantine_recovery_path(record.conflict_path), False),
            )
            for candidate, owned_path in candidates:
                if charge(
                    candidate,
                    expected,
                    accounting_owner=record.accounting_owner,
                    owned_path=owned_path,
                ):
                    break
        with self._pending_fingerprint_removals_lock:
            pending = tuple(self._pending_fingerprint_removals.values())
        for item in pending:
            marker_parts = _split_owned_relative(item.marker_path)
            marker_opened = self._open_parent_if_present(marker_parts)
            if marker_opened is None:
                continue
            marker_parent, marker_name = marker_opened
            try:
                try:
                    descriptor = os.open(
                        marker_name, _FILE_FLAGS, dir_fd=marker_parent
                    )
                except OSError as error:
                    raise InvalidTask(
                        "The pending fingerprint-removal marker is unavailable."
                    ) from error
                try:
                    marker_info = os.fstat(descriptor)
                    marker_data = os.read(
                        descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1
                    )
                finally:
                    os.close(descriptor)
                marker = _parse_fingerprint_remove_temp_marker(
                    marker_name, marker_data
                )
                relative_directory = "/".join(marker_parts[:-1])
                authenticated = (
                    self._pending_fingerprint_removal_from_marker(
                        marker_name, marker, relative_directory
                    )
                    if marker is not None
                    else None
                )
                if (
                    not stat_module.S_ISREG(marker_info.st_mode)
                    or marker_info.st_nlink != 1
                    or stat_module.S_IMODE(marker_info.st_mode) != 0o600
                    or len(marker_data) > _STREAM_TEMP_MARKER_MAX_BYTES
                    or authenticated != item
                ):
                    raise InvalidTask(
                        "The pending fingerprint-removal marker is invalid."
                    )
            finally:
                os.close(marker_parent)
            for candidate, owned_path in (
                (item.temporary_path, True),
                (item.original_path, False),
            ):
                if charge(
                    candidate,
                    item.expected_fingerprint,
                    accounting_owner=RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
                    owned_path=owned_path,
                ):
                    break
        return RetainedStorageUsage(
            owner_count=owner_count,
            logical_bytes=logical_bytes,
            allocated_bytes=allocated_bytes,
            reservation_count=len(self._retained_retirement_reservations),
            additional_logical_bytes=additional_logical_bytes,
            materialized_row_logical_bytes=materialized_row_logical_bytes,
            additional_allocated_bytes=additional_allocated_bytes,
            materialized_row_allocated_bytes=materialized_row_allocated_bytes,
        )

    @_serialize_retired_quarantine
    def has_retained_retirement(self, path: str) -> bool:
        """Whether hidden cleanup evidence still owns bytes for ``path``."""

        normalized = "/".join(split_relative(path))
        if any(
            record.retain_unchanged and record.original_path == normalized
            for record in self._retired_quarantine.values()
        ):
            return True
        with self._pending_fingerprint_removals_lock:
            return any(
                pending.original_path == normalized
                for pending in self._pending_fingerprint_removals.values()
            )

    def allocated_file_bytes(self, path: str) -> int:
        """Return physical blocks for one safe public regular file."""

        opened = self._open_parent_if_present(split_relative(path))
        if opened is None:
            return 0
        parent, name = opened
        try:
            try:
                info = os.stat(name, dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError:
                return 0
            _regular_fingerprint(info, "The workspace path must be a regular file.")
            return _allocated_file_bytes(info)
        finally:
            os.close(parent)

    @_serialize_retired_quarantine
    def _reserve_retained_retirement_slot(self) -> str | None:
        """Reserve one hidden-owner slot before a remote stream is consumed."""

        with self._pending_fingerprint_removals_lock:
            pending = len(self._pending_fingerprint_removals)
        if (
            len(self._retired_quarantine)
            + pending
            + len(self._retained_retirement_reservations)
            >= self._retired_quarantine_max_entries
        ):
            return None
        token = uuid.uuid4().hex
        self._retained_retirement_reservations.add(token)
        return token

    @_serialize_retired_quarantine
    def _release_retained_retirement_slot(self, token: str | None) -> None:
        if token is not None:
            self._retained_retirement_reservations.discard(token)

    def _fingerprint_removal_retention_available(
        self, incoming_bytes: int
    ) -> bool:
        """Bound hidden remote-cleanup evidence without rejecting large files.

        Retirement renames an inode that is already charged to the local
        working set; it does not allocate a byte copy.  Count the durable
        owners, not logical file length (which also wildly overstates sparse
        files), so a 10--50 GiB cache entry remains safely retireable while the
        number of private survivors stays hard-bounded.
        """

        if isinstance(incoming_bytes, bool) or not isinstance(incoming_bytes, int):
            raise InvalidTask("incoming_bytes must be an integer.")
        if incoming_bytes < 0:
            raise InvalidTask("incoming_bytes must not be negative.")

        return self.retained_retirement_capacity_available()

    @staticmethod
    def _recover_marker_stage_at(
        parent: int, stage_name: str, stage_info: os.stat_result
    ) -> bool:
        """Remove only an authenticated private marker-publication stage."""

        temporary = stage_name[: -len(STREAM_TEMP_MARKER_SUFFIX)]
        if (
            _owned_temporary_kind(temporary) != "write"
            or not stat_module.S_ISREG(stage_info.st_mode)
            or stat_module.S_IMODE(stage_info.st_mode) != 0o600
            or stage_info.st_nlink not in (1, 2)
        ):
            return False
        try:
            descriptor = os.open(stage_name, _FILE_FLAGS, dir_fd=parent)
        except OSError:
            return False
        try:
            data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
            opened = os.fstat(descriptor)
        except OSError:
            return False
        finally:
            os.close(descriptor)
        if (
            len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
            or not stat_module.S_ISREG(opened.st_mode)
            or stat_module.S_IMODE(opened.st_mode) != 0o600
            or opened.st_dev != stage_info.st_dev
            or opened.st_ino != stage_info.st_ino
            or opened.st_nlink != stage_info.st_nlink
            or not _marker_stage_payload_is_bound(stage_name, data)
        ):
            return False
        token = temporary.rsplit("-", 1)[-1]
        published = False
        for kind in ("stream", "retire"):
            final_name = f".__{kind}__.meshia-{token}{STREAM_TEMP_MARKER_SUFFIX}"
            try:
                final_info = os.stat(final_name, dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError:
                continue
            except OSError:
                return False
            if (
                final_info.st_dev == stage_info.st_dev
                and final_info.st_ino == stage_info.st_ino
            ):
                published = True
                break
        if stage_info.st_nlink == 2 and not published:
            return False
        try:
            os.unlink(stage_name, dir_fd=parent)
            return True
        except OSError:
            return False

    def _queue_visible_quarantine_promotion(
        self,
        record: _RetiredQuarantineRecord,
        *,
        visible_path: str | None = None,
    ) -> None:
        promotion = RetiredQuarantinePromotion(
            original_path=record.original_path,
            visible_path=visible_path or record.conflict_path,
            temporary_path=record.temporary_path,
            marker_path=record.marker_path,
            conflict_path=record.conflict_path,
            quarantined_at_ns=record.quarantined_at_ns,
            recorded_size_bytes=record.recorded_size_bytes,
            device_id=record.device_id,
            file_id=record.file_id,
            recorded_sha256=record.recorded_sha256,
            recorded_mtime_ns=record.recorded_mtime_ns,
            recorded_ctime_ns=record.recorded_ctime_ns,
            retain_unchanged=record.retain_unchanged,
            accounting_owner=record.accounting_owner,
        )
        for index, item in enumerate(
            self._retired_quarantine_visible_promotions
        ):
            if item.marker_path != promotion.marker_path:
                continue
            if replace(item, visible_path=promotion.visible_path) != promotion:
                self._retired_quarantine_maintenance_error = True
                raise InvalidTask(
                    "A retired-inode marker cannot identify two promotions."
                )
            self._retired_quarantine_visible_promotions[index] = promotion
            return
        if (
            len(self._retired_quarantine_visible_promotions)
            >= RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX
        ):
            self._retired_quarantine_promotion_overflow = True
            return
        self._retired_quarantine_visible_promotions.append(promotion)

    @_serialize_retired_quarantine
    def drain_retired_quarantine_promotions(
        self, *, max_entries: int = RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX
    ) -> tuple[RetiredQuarantinePromotion, ...]:
        """Return visible retire evidence for a durable sync handoff."""

        if (
            isinstance(max_entries, bool)
            or not isinstance(max_entries, int)
            or not 1 <= max_entries <= RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX
        ):
            raise InvalidTask("Invalid retired-inode promotion drain bound.")
        drained = tuple(self._retired_quarantine_visible_promotions[:max_entries])
        del self._retired_quarantine_visible_promotions[:max_entries]
        if not self._retired_quarantine_visible_promotions:
            self._retired_quarantine_promotion_overflow = False
        return drained

    @_serialize_retired_quarantine
    def retained_retired_files(
        self, *, max_entries: int = RETIRED_QUARANTINE_MAX_ENTRIES
    ) -> tuple[RetiredRegularFile, ...]:
        """Snapshot unchanged hidden cleanup evidence for mount-fenced reclaim."""

        if (
            isinstance(max_entries, bool)
            or not isinstance(max_entries, int)
            or not 1 <= max_entries <= RETIRED_QUARANTINE_MAX_ENTRIES
        ):
            raise InvalidTask("Invalid retained retirement scan bound.")
        retained: list[RetiredRegularFile] = []
        for record in sorted(
            self._retired_quarantine.values(),
            key=lambda item: (item.quarantined_at_ns, item.marker_path),
        ):
            if not record.retain_unchanged or record.recorded_sha256 is None:
                continue
            _size, interrupted = self._inspect_quarantine_record(record)
            if interrupted:
                continue
            assert record.recorded_mtime_ns is not None
            assert record.recorded_ctime_ns is not None
            retained.append(
                RetiredRegularFile(
                    original_path=record.original_path,
                    temporary_path=record.temporary_path,
                    marker_path=record.marker_path,
                    initial=HashedRegularFile(
                        FileFingerprint(
                            size_bytes=record.recorded_size_bytes,
                            mtime_ns=record.recorded_mtime_ns,
                            ctime_ns=record.recorded_ctime_ns,
                            device_id=record.device_id,
                            file_id=record.file_id,
                        ),
                        record.recorded_sha256,
                    ),
                    accounting_owner=record.accounting_owner,
                )
            )
            if len(retained) >= max_entries:
                break
        return tuple(retained)

    @_serialize_retired_quarantine
    def defer_retired_quarantine_promotion(
        self, promotion: RetiredQuarantinePromotion
    ) -> None:
        """Return an unacknowledged promotion to the bounded in-memory queue."""

        if not isinstance(promotion, RetiredQuarantinePromotion):
            raise InvalidTask("promotion must be retired-inode evidence.")
        record = _RetiredQuarantineRecord(
            original_path=promotion.original_path,
            temporary_path=promotion.temporary_path,
            marker_path=promotion.marker_path,
            conflict_path=promotion.conflict_path,
            quarantined_at_ns=promotion.quarantined_at_ns,
            recorded_size_bytes=promotion.recorded_size_bytes,
            device_id=promotion.device_id,
            file_id=promotion.file_id,
            recorded_sha256=promotion.recorded_sha256,
            recorded_mtime_ns=promotion.recorded_mtime_ns,
            recorded_ctime_ns=promotion.recorded_ctime_ns,
            retain_unchanged=promotion.retain_unchanged,
            accounting_owner=promotion.accounting_owner,
        )
        self._queue_visible_quarantine_promotion(
            record, visible_path=promotion.visible_path
        )

    @_serialize_retired_quarantine
    def acknowledge_retired_quarantine_promotion(
        self,
        promotion: RetiredQuarantinePromotion,
        *,
        expected_fingerprint: FileFingerprint,
    ) -> None:
        """Retire the owner marker only after sync durably owns the visible bytes."""

        if not isinstance(promotion, RetiredQuarantinePromotion):
            raise InvalidTask("promotion must be retired-inode evidence.")
        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        if (
            expected_fingerprint.device_id != promotion.device_id
            or expected_fingerprint.file_id != promotion.file_id
        ):
            raise InvalidTask("The promoted retired inode changed identity.")
        current = self.stat_fingerprint(promotion.visible_path)
        if current != expected_fingerprint:
            raise InvalidTask("The promoted retired inode changed before handoff.")
        record = _RetiredQuarantineRecord(
            original_path=promotion.original_path,
            temporary_path=promotion.temporary_path,
            marker_path=promotion.marker_path,
            conflict_path=promotion.conflict_path,
            quarantined_at_ns=promotion.quarantined_at_ns,
            recorded_size_bytes=promotion.recorded_size_bytes,
            device_id=promotion.device_id,
            file_id=promotion.file_id,
            recorded_sha256=promotion.recorded_sha256,
            recorded_mtime_ns=promotion.recorded_mtime_ns,
            recorded_ctime_ns=promotion.recorded_ctime_ns,
            retain_unchanged=promotion.retain_unchanged,
            accounting_owner=promotion.accounting_owner,
        )
        marker_parts = _split_owned_relative(record.marker_path)
        opened = self._open_parent_if_present(marker_parts)
        if opened is None:
            raise InvalidTask("The retired-inode promotion marker disappeared.")
        parent, marker = opened
        try:
            self._validate_quarantine_marker_at(parent, marker, record)
            os.unlink(marker, dir_fd=parent)
            _fsync_directory_when_supported(parent)
        except (InvalidTask, OSError, UnsafePath):
            self._retired_quarantine_maintenance_error = True
            raise
        finally:
            os.close(parent)
        self._retired_quarantine.pop(record.marker_path, None)
        self._retired_quarantine_visible_promotions = [
            item
            for item in self._retired_quarantine_visible_promotions
            if item.marker_path != record.marker_path
        ]

    @staticmethod
    def _quarantine_promotion_candidates(
        items: list[tuple[_RetiredQuarantineRecord, int]],
        *,
        now_ns: int,
        max_entries: int,
        max_bytes: int,
        max_age_seconds: float,
        extra_entries: int = 0,
        extra_bytes: int = 0,
    ) -> list[_RetiredQuarantineRecord]:
        ordered = sorted(items, key=lambda item: (item[0].quarantined_at_ns, item[0].marker_path))
        selected: list[_RetiredQuarantineRecord] = []
        selected_paths: set[str] = set()
        age_ns = int(max_age_seconds * 1_000_000_000)
        for record, _size in ordered:
            if (
                not record.retain_unchanged
                and now_ns - record.quarantined_at_ns >= age_ns
            ):
                selected.append(record)
                selected_paths.add(record.marker_path)
        remaining_count = len(items) - len(selected) + extra_entries
        remaining_bytes = (
            sum(
                size
                for record, size in items
                if record.marker_path not in selected_paths
                and not record.retain_unchanged
            )
            + extra_bytes
        )
        for record, size in ordered:
            if remaining_count <= max_entries and remaining_bytes <= max_bytes:
                break
            if record.marker_path in selected_paths:
                continue
            if record.retain_unchanged:
                continue
            selected.append(record)
            selected_paths.add(record.marker_path)
            remaining_count -= 1
            if not record.retain_unchanged:
                remaining_bytes -= size
        return selected

    def _inspect_quarantine_record(
        self, record: _RetiredQuarantineRecord
    ) -> tuple[int, bool]:
        parts = _split_owned_relative(record.temporary_path)
        opened = self._open_parent_if_present(parts)
        if opened is None:
            raise InvalidTask("A retired-inode quarantine parent disappeared.")
        parent, temporary = opened
        try:
            try:
                info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError:
                conflict = split_relative(record.conflict_path)[-1]
                try:
                    info = os.stat(conflict, dir_fd=parent, follow_symlinks=False)
                except FileNotFoundError:
                    recovery = self.stat_fingerprint(
                        retired_quarantine_recovery_path(record.conflict_path)
                    )
                    if (
                        recovery is None
                        or recovery.device_id != record.device_id
                        or recovery.file_id != record.file_id
                    ):
                        raise InvalidTask(
                            "A retired-inode quarantine entry disappeared."
                        ) from None
                    return recovery.size_bytes, True
                except OSError as error:
                    raise InvalidTask(
                        "A retired-inode quarantine entry disappeared."
                    ) from error
                if (
                    not stat_module.S_ISREG(info.st_mode)
                    or info.st_nlink != 1
                    or info.st_dev != record.device_id
                    or info.st_ino != record.file_id
                ):
                    raise InvalidTask("A retired-inode promotion identity changed.")
                return (
                    _allocated_file_bytes(info)
                    if record.retain_unchanged
                    else int(info.st_size)
                ), True
            except OSError as error:
                raise InvalidTask(
                    "A retired-inode quarantine entry cannot be inspected."
                ) from error
            if (
                not stat_module.S_ISREG(info.st_mode)
                or info.st_dev != record.device_id
                or info.st_ino != record.file_id
                or info.st_nlink not in (1, 2)
            ):
                raise InvalidTask("A retired-inode quarantine identity changed.")
            if info.st_nlink == 2:
                conflict = split_relative(record.conflict_path)[-1]
                try:
                    conflict_info = os.stat(
                        conflict, dir_fd=parent, follow_symlinks=False
                    )
                except OSError as error:
                    raise InvalidTask(
                        "A retired-inode promotion cannot be verified."
                    ) from error
                if (
                    not stat_module.S_ISREG(conflict_info.st_mode)
                    or conflict_info.st_dev != info.st_dev
                    or conflict_info.st_ino != info.st_ino
                    or conflict_info.st_nlink != 2
                ):
                    raise InvalidTask("A retired-inode promotion identity changed.")
                return (
                    _allocated_file_bytes(info)
                    if record.retain_unchanged
                    else int(info.st_size)
                ), True
            if record.retain_unchanged:
                current = _fingerprint_from_stat(info)
                if (
                    record.recorded_mtime_ns is None
                    or record.recorded_ctime_ns is None
                    or current.size_bytes != record.recorded_size_bytes
                    or current.mtime_ns != record.recorded_mtime_ns
                    or current.ctime_ns != record.recorded_ctime_ns
                ):
                    # A direct/headless writer still holding the anonymous
                    # retired inode produced user data. Promote it immediately
                    # for durable conflict staging; unchanged remote-cleanup
                    # entries remain hidden and do not become false conflicts
                    # merely because a grace timer elapsed.
                    return _allocated_file_bytes(info), True
            return (
                _allocated_file_bytes(info)
                if record.retain_unchanged
                else int(info.st_size)
            ), False
        finally:
            os.close(parent)

    @classmethod
    def inspect_retired_quarantine(
        cls,
        root: Path | str,
        *,
        now_ns: int | None = None,
        max_scan_entries: int = MAX_LIST_ENTRIES,
        retired_quarantine_max_bytes: int = RETIRED_QUARANTINE_MAX_BYTES,
        retired_quarantine_max_entries: int = RETIRED_QUARANTINE_MAX_ENTRIES,
        retired_quarantine_max_age_seconds: float = RETIRED_QUARANTINE_MAX_AGE_SECONDS,
    ) -> RetiredQuarantineStatus:
        """Read quarantine metrics without constructing or recovering a boundary."""

        max_bytes, max_entries, max_age = _validate_retired_quarantine_bounds(
            retired_quarantine_max_bytes,
            retired_quarantine_max_entries,
            retired_quarantine_max_age_seconds,
        )
        observed_now = time.time_ns() if now_ns is None else now_ns
        if (
            isinstance(observed_now, bool)
            or not isinstance(observed_now, int)
            or isinstance(max_scan_entries, bool)
            or not isinstance(max_scan_entries, int)
            or not 1 <= max_scan_entries <= MAX_LIST_ENTRIES
        ):
            raise InvalidTask("Invalid retired-inode quarantine inspection bounds.")
        resolved = Path(os.path.realpath(str(Path(root).expanduser())))
        if not resolved.is_dir():
            raise UnsafePath(f"The synchronized workspace {resolved} does not exist.")
        root_fd = os.open(str(resolved), _DIR_FLAGS & ~_O_NOFOLLOW)
        pending: list[tuple[str, ...]] = [()]
        visited = 0
        scan_pending = False
        active_retire_pending = False
        blocked = False
        interrupted = 0
        items: list[tuple[_RetiredQuarantineRecord, int]] = []
        identities: set[tuple[int, int]] = set()

        def open_directory(parts: tuple[str, ...]) -> int:
            current = os.dup(root_fd)
            try:
                for part in parts:
                    nxt = os.open(part, _DIR_FLAGS, dir_fd=current)
                    os.close(current)
                    current = nxt
                return current
            except BaseException:
                os.close(current)
                raise

        try:
            while pending and not scan_pending:
                parts = pending.pop()
                try:
                    directory = open_directory(parts)
                except OSError:
                    scan_pending = True
                    break
                try:
                    try:
                        entries = os.scandir(directory)
                    except OSError:
                        scan_pending = True
                        break
                    try:
                        for entry in entries:
                            visited += 1
                            if visited > max_scan_entries:
                                scan_pending = True
                                break
                            try:
                                info = entry.stat(follow_symlinks=False)
                            except OSError:
                                scan_pending = True
                                break
                            if stat_module.S_ISDIR(info.st_mode):
                                pending.append((*parts, entry.name))
                                continue
                            if not entry.name.endswith(STREAM_TEMP_MARKER_SUFFIX):
                                continue
                            temporary_name = entry.name[
                                : -len(STREAM_TEMP_MARKER_SUFFIX)
                            ]
                            if _owned_temporary_kind(temporary_name) != "retire":
                                continue
                            try:
                                marker_fd = os.open(
                                    entry.name, _FILE_FLAGS, dir_fd=directory
                                )
                                try:
                                    data = os.read(
                                        marker_fd,
                                        _STREAM_TEMP_MARKER_MAX_BYTES + 1,
                                    )
                                    marker_info = os.fstat(marker_fd)
                                finally:
                                    os.close(marker_fd)
                            except OSError:
                                scan_pending = True
                                break
                            if (
                                len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
                                or not stat_module.S_ISREG(marker_info.st_mode)
                                or marker_info.st_nlink not in (1, 2)
                                or stat_module.S_IMODE(marker_info.st_mode) != 0o600
                            ):
                                blocked = True
                                continue
                            marker = _parse_retired_quarantine_marker(
                                entry.name, data
                            )
                            if marker is None:
                                if (
                                    _parse_retire_temp_marker(entry.name, data) is None
                                    and _parse_fingerprint_remove_temp_marker(
                                        entry.name, data
                                    )
                                    is None
                                ):
                                    blocked = True
                                else:
                                    active_retire_pending = True
                                continue
                            if marker_info.st_nlink != 1:
                                blocked = True
                                continue
                            try:
                                expected_conflict = _bounded_retire_conflict_name(
                                    str(marker["target"]),
                                    str(marker["temporary"]),
                                    name_max=cls._name_max_at(directory),
                                )
                            except InvalidTask:
                                blocked = True
                                continue
                            if str(marker["conflict"]) != expected_conflict:
                                blocked = True
                                continue
                            identity = (
                                int(marker["device_id"]),
                                int(marker["file_id"]),
                            )
                            if identity in identities:
                                blocked = True
                                continue
                            identities.add(identity)
                            prefix = "/".join(parts)
                            relative_prefix = f"{prefix}/" if prefix else ""
                            record = _RetiredQuarantineRecord(
                                original_path=f"{relative_prefix}{marker['target']}",
                                temporary_path=f"{relative_prefix}{marker['temporary']}",
                                marker_path=f"{relative_prefix}{entry.name}",
                                conflict_path=f"{relative_prefix}{marker['conflict']}",
                                quarantined_at_ns=int(
                                    marker["quarantined_at_ns"]
                                ),
                                recorded_size_bytes=int(
                                    marker["recorded_size_bytes"]
                                ),
                                device_id=identity[0],
                                file_id=identity[1],
                                recorded_sha256=marker["recorded_sha256"],
                                recorded_mtime_ns=marker["recorded_mtime_ns"],
                                recorded_ctime_ns=marker["recorded_ctime_ns"],
                                retain_unchanged=bool(marker["retain_unchanged"]),
                                accounting_owner=str(marker["accounting_owner"]),
                            )
                            try:
                                temp_info = os.stat(
                                    str(marker["temporary"]),
                                    dir_fd=directory,
                                    follow_symlinks=False,
                                )
                            except FileNotFoundError:
                                try:
                                    conflict_info = os.stat(
                                        str(marker["conflict"]),
                                        dir_fd=directory,
                                        follow_symlinks=False,
                                    )
                                except FileNotFoundError:
                                    recovery_path = resolved.joinpath(
                                        *split_relative(
                                            retired_quarantine_recovery_path(
                                                record.conflict_path
                                            )
                                        )
                                    )
                                    try:
                                        conflict_info = os.lstat(recovery_path)
                                    except OSError:
                                        blocked = True
                                        continue
                                except OSError:
                                    blocked = True
                                    continue
                                if (
                                    not stat_module.S_ISREG(conflict_info.st_mode)
                                    or conflict_info.st_dev != identity[0]
                                    or conflict_info.st_ino != identity[1]
                                ):
                                    blocked = True
                                    continue
                                interrupted += 1
                                continue
                            except OSError:
                                scan_pending = True
                                break
                            if (
                                not stat_module.S_ISREG(temp_info.st_mode)
                                or temp_info.st_dev != identity[0]
                                or temp_info.st_ino != identity[1]
                                or temp_info.st_nlink not in (1, 2)
                            ):
                                blocked = True
                                continue
                            if temp_info.st_nlink == 2:
                                interrupted += 1
                            elif record.retain_unchanged and (
                                record.recorded_mtime_ns is None
                                or record.recorded_ctime_ns is None
                                or int(temp_info.st_size)
                                != record.recorded_size_bytes
                                or _fingerprint_from_stat(temp_info).mtime_ns
                                != record.recorded_mtime_ns
                                or _fingerprint_from_stat(temp_info).ctime_ns
                                != record.recorded_ctime_ns
                            ):
                                interrupted += 1
                            else:
                                items.append(
                                    (
                                        record,
                                        (
                                            _allocated_file_bytes(temp_info)
                                            if record.retain_unchanged
                                            else int(temp_info.st_size)
                                        ),
                                    )
                                )
                    except OSError:
                        scan_pending = True
                    finally:
                        entries.close()
                finally:
                    os.close(directory)
        finally:
            os.close(root_fd)
        candidates = cls._quarantine_promotion_candidates(
            items,
            now_ns=observed_now,
            max_entries=max_entries,
            max_bytes=max_bytes,
            max_age_seconds=max_age,
        )
        oldest = min(
            (record.quarantined_at_ns for record, _size in items), default=None
        )
        return RetiredQuarantineStatus(
            entry_count=len(items),
            bytes_on_disk=sum(size for _record, size in items),
            oldest_quarantined_at_ns=oldest,
            oldest_age_seconds=(
                max(0.0, (observed_now - oldest) / 1_000_000_000)
                if oldest is not None
                else 0.0
            ),
            promotion_backlog=len(candidates) + interrupted,
            visible_promotion_backlog=0,
            visible_promotion_overflow=False,
            max_entries=max_entries,
            max_bytes=max_bytes,
            max_age_seconds=max_age,
            recovery_pending=(
                scan_pending or bool(pending) or active_retire_pending
            ),
            recovery_blocked=blocked,
        )

    @_serialize_retired_quarantine
    def retired_quarantine_status(
        self, *, now_ns: int | None = None
    ) -> RetiredQuarantineStatus:
        """Return live byte/count/age accounting without mutating namespace state."""

        observed_now = time.time_ns() if now_ns is None else now_ns
        if isinstance(observed_now, bool) or not isinstance(observed_now, int):
            raise InvalidTask("now_ns must be an integer nanosecond timestamp.")
        items: list[tuple[_RetiredQuarantineRecord, int]] = []
        interrupted = 0
        blocked = (
            self._ambiguous_retire_recovery
            or self._retired_quarantine_maintenance_error
        )
        retained_usage: RetainedStorageUsage | None
        try:
            retained_usage = self.retained_storage_usage()
        except (InvalidTask, UnsafePath):
            # Status must stay observational when one malformed owner needs
            # recovery.  ``None`` explicitly withholds incomplete aggregates.
            retained_usage = None
            blocked = True
        for record in list(self._retired_quarantine.values()):
            try:
                size, is_interrupted = self._inspect_quarantine_record(record)
            except (InvalidTask, UnsafePath):
                blocked = True
                continue
            if is_interrupted:
                interrupted += 1
            else:
                items.append((record, size))
        candidates = self._quarantine_promotion_candidates(
            items,
            now_ns=observed_now,
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
        )
        oldest = min(
            (record.quarantined_at_ns for record, _size in items), default=None
        )
        return RetiredQuarantineStatus(
            entry_count=len(items),
            bytes_on_disk=sum(size for _record, size in items),
            oldest_quarantined_at_ns=oldest,
            oldest_age_seconds=(
                max(0.0, (observed_now - oldest) / 1_000_000_000)
                if oldest is not None
                else 0.0
            ),
            promotion_backlog=len(candidates) + interrupted,
            visible_promotion_backlog=len(
                self._retired_quarantine_visible_promotions
            ),
            visible_promotion_overflow=self._retired_quarantine_promotion_overflow,
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
            recovery_pending=(
                self.stream_recovery_pending
                or self._stream_recovery_retry_required
                or self._fingerprint_removal_pending()
            ),
            recovery_blocked=blocked,
            retained_owner_count=(
                retained_usage.owner_count if retained_usage is not None else None
            ),
            logical_retained_bytes=(
                retained_usage.logical_bytes if retained_usage is not None else None
            ),
            allocated_retained_bytes=(
                retained_usage.allocated_bytes if retained_usage is not None else None
            ),
            retention_reservation_count=(
                retained_usage.reservation_count
                if retained_usage is not None
                else None
            ),
        )

    @_serialize_retired_quarantine
    def maintain_retired_quarantine(
        self, *, now_ns: int | None = None
    ) -> tuple[str, ...]:
        """Promote expired/over-quota entries without ever unlinking last data."""

        observed_now = time.time_ns() if now_ns is None else now_ns
        if isinstance(observed_now, bool) or not isinstance(observed_now, int):
            raise InvalidTask("now_ns must be an integer nanosecond timestamp.")
        if (
            self.stream_recovery_pending
            or self._stream_recovery_retry_required
            or self._fingerprint_removal_pending()
        ):
            raise InvalidTask("Retired-inode quarantine recovery is incomplete.")
        if self._ambiguous_retire_recovery:
            raise InvalidTask("Retired-inode quarantine recovery is blocked.")
        self._retired_quarantine_maintenance_error = False
        promoted: list[str] = []
        items: list[tuple[_RetiredQuarantineRecord, int]] = []
        for record in list(self._retired_quarantine.values()):
            try:
                size, interrupted = self._inspect_quarantine_record(record)
            except (InvalidTask, OSError, UnsafePath):
                self._retired_quarantine_maintenance_error = True
                raise
            if interrupted:
                promoted.append(self._promote_quarantine_record(record))
            else:
                items.append((record, size))
        candidates = self._quarantine_promotion_candidates(
            items,
            now_ns=observed_now,
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
        )
        for record in candidates:
            if record.marker_path in self._retired_quarantine:
                promoted.append(self._promote_quarantine_record(record))
        return tuple(promoted)

    def _promote_quarantine_record(
        self, record: _RetiredQuarantineRecord
    ) -> str:
        marker_parts = _split_owned_relative(record.marker_path)
        opened = self._open_parent_if_present(marker_parts)
        if opened is None:
            raise InvalidTask("A retired-inode quarantine parent disappeared.")
        parent, marker = opened
        temporary = _split_owned_relative(record.temporary_path)[-1]
        conflict = split_relative(record.conflict_path)[-1]
        visible_path = record.conflict_path
        try:
            self._validate_quarantine_marker_at(parent, marker, record)
            try:
                temp_info = os.stat(
                    temporary, dir_fd=parent, follow_symlinks=False
                )
            except FileNotFoundError:
                temp_info = None
            except OSError as error:
                raise InvalidTask(
                    "A retired-inode quarantine entry cannot be inspected."
                ) from error
            if temp_info is not None:
                if (
                    not stat_module.S_ISREG(temp_info.st_mode)
                    or temp_info.st_dev != record.device_id
                    or temp_info.st_ino != record.file_id
                    or temp_info.st_nlink not in (1, 2)
                ):
                    raise InvalidTask("A retired-inode quarantine identity changed.")
                if temp_info.st_nlink == 1:
                    try:
                        os.link(
                            temporary,
                            conflict,
                            src_dir_fd=parent,
                            dst_dir_fd=parent,
                            follow_symlinks=False,
                        )
                    except FileExistsError:
                        conflict_info = os.stat(
                            conflict, dir_fd=parent, follow_symlinks=False
                        )
                        if (
                            conflict_info.st_dev != temp_info.st_dev
                            or conflict_info.st_ino != temp_info.st_ino
                        ):
                            raise InvalidTask(
                                "The deterministic retire conflict name is occupied."
                            ) from None
                    _fsync_directory_when_supported(parent)
                conflict_info = os.stat(
                    conflict, dir_fd=parent, follow_symlinks=False
                )
                if (
                    not stat_module.S_ISREG(conflict_info.st_mode)
                    or conflict_info.st_dev != record.device_id
                    or conflict_info.st_ino != record.file_id
                ):
                    raise InvalidTask("A retired-inode promotion identity changed.")
                os.unlink(temporary, dir_fd=parent)
                _fsync_directory_when_supported(parent)
            else:
                try:
                    conflict_info = os.stat(
                        conflict, dir_fd=parent, follow_symlinks=False
                    )
                except FileNotFoundError:
                    recovery_path = retired_quarantine_recovery_path(
                        record.conflict_path
                    )
                    recovery = self.stat_fingerprint(recovery_path)
                    if (
                        recovery is None
                        or recovery.device_id != record.device_id
                        or recovery.file_id != record.file_id
                    ):
                        raise InvalidTask(
                            "A retired-inode quarantine entry disappeared."
                        ) from None
                    visible_path = recovery_path
                    conflict_info = None
                except OSError as error:
                    raise InvalidTask(
                        "A retired-inode quarantine entry disappeared."
                    ) from error
                if conflict_info is not None and (
                    not stat_module.S_ISREG(conflict_info.st_mode)
                    or conflict_info.st_nlink != 1
                    or conflict_info.st_dev != record.device_id
                    or conflict_info.st_ino != record.file_id
                ):
                    raise InvalidTask("A retired-inode promotion identity changed.")
        except (InvalidTask, OSError, UnsafePath):
            self._retired_quarantine_maintenance_error = True
            raise
        finally:
            os.close(parent)
        # Keep the private owner marker until Fabric has durably journaled the
        # visible evidence. A process crash can therefore reconstruct this
        # handoff instead of silently treating the conflict as an ordinary edit.
        self._queue_visible_quarantine_promotion(
            record, visible_path=visible_path
        )
        return visible_path

    @staticmethod
    def _validate_quarantine_marker_at(
        parent: int, marker_name: str, record: _RetiredQuarantineRecord
    ) -> None:
        try:
            descriptor = os.open(marker_name, _FILE_FLAGS, dir_fd=parent)
        except OSError as error:
            raise InvalidTask(
                "The retired-inode quarantine marker is unavailable."
            ) from error
        try:
            info = os.fstat(descriptor)
            data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
            if (
                not stat_module.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or stat_module.S_IMODE(info.st_mode) != 0o600
                or len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
            ):
                raise InvalidTask("The retired-inode quarantine marker is invalid.")
        finally:
            os.close(descriptor)
        marker = _parse_retired_quarantine_marker(marker_name, data)
        expected_conflict = _bounded_retire_conflict_name(
            split_relative(record.original_path)[-1],
            _split_owned_relative(record.temporary_path)[-1],
            name_max=WorkspaceBoundary._name_max_at(parent),
        )
        if (
            marker is None
            or marker.get("temporary")
            != _split_owned_relative(record.temporary_path)[-1]
            or marker.get("target") != split_relative(record.original_path)[-1]
            or marker.get("conflict") != split_relative(record.conflict_path)[-1]
            or marker.get("conflict") != expected_conflict
            or marker.get("device_id") != record.device_id
            or marker.get("file_id") != record.file_id
            or marker.get("recorded_sha256") != record.recorded_sha256
            or marker.get("recorded_size_bytes") != record.recorded_size_bytes
            or marker.get("recorded_mtime_ns") != record.recorded_mtime_ns
            or marker.get("recorded_ctime_ns") != record.recorded_ctime_ns
            or marker.get("retain_unchanged") != record.retain_unchanged
            or marker.get("accounting_owner") != record.accounting_owner
        ):
            raise InvalidTask("The retired-inode quarantine marker is invalid.")

    @staticmethod
    def _read_blocked_retire_target_at(
        parent: int,
        marker_name: str,
        marker_info: os.stat_result | None,
    ) -> str | None:
        if marker_info is None:
            return None
        try:
            descriptor = os.open(marker_name, _FILE_FLAGS, dir_fd=parent)
        except OSError:
            return None
        try:
            data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
            opened = os.fstat(descriptor)
            if (
                len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
                or not stat_module.S_ISREG(opened.st_mode)
                or opened.st_nlink != 1
                or opened.st_dev != marker_info.st_dev
                or opened.st_ino != marker_info.st_ino
            ):
                return None
        finally:
            os.close(descriptor)
        marker = _parse_retire_temp_marker(marker_name, data)
        if marker is None:
            marker = _parse_fingerprint_remove_temp_marker(marker_name, data)
        return str(marker["target"]) if marker is not None else None

    @staticmethod
    def _pending_fingerprint_removal_from_marker(
        marker_name: str,
        marker: dict[str, object],
        relative_directory: str,
    ) -> _PendingFingerprintRemoval:
        prefix = f"{relative_directory}/" if relative_directory else ""
        return _PendingFingerprintRemoval(
            original_path=f"{prefix}{marker['target']}",
            temporary_path=f"{prefix}{marker['temporary']}",
            marker_path=f"{prefix}{marker_name}",
            expected_fingerprint=FileFingerprint(
                size_bytes=int(marker["expected_size_bytes"]),
                mtime_ns=int(marker["expected_mtime_ns"]),
                ctime_ns=int(marker["expected_ctime_ns"]),
                device_id=int(marker["expected_device_id"]),
                file_id=int(marker["expected_file_id"]),
            ),
            retired_ctime_ns=(
                int(marker["retired_ctime_ns"])
                if marker.get("retired_ctime_ns") is not None
                else None
            ),
        )

    def _recover_fingerprint_removal_at(
        self,
        parent: int,
        marker_name: str,
        marker: dict[str, object],
        *,
        allow_last_unlink: bool,
    ) -> str:
        """Finish one delete-owned retire or preserve a different raced inode."""

        if not isinstance(allow_last_unlink, bool):
            raise InvalidTask("allow_last_unlink must be a boolean.")

        temporary = str(marker["temporary"])
        target = str(marker["target"])
        pending = self._pending_fingerprint_removal_from_marker(
            marker_name, marker, ""
        )

        def finish_reclaimed_data() -> str:
            # The caller invokes this only after the last data link has been
            # removed. Persist that physical reclaim before retiring metadata;
            # marker cleanup failure is bounded recovery work, not a false
            # surviving-file result.
            _fsync_directory_when_supported(parent)
            try:
                os.unlink(marker_name, dir_fd=parent)
                _fsync_directory_when_supported(parent)
            except OSError:
                with self._pending_fingerprint_removals_lock:
                    self._fingerprint_marker_cleanup.update(
                        path
                        for path in self._pending_fingerprint_removals
                        if _split_owned_relative(path)[-1] == marker_name
                    )
                self._stream_recovery_scan = None
                self._stream_recovery_retry_required = True
                self.stream_recovery_pending = True
            return "removed"

        expected = pending.expected_fingerprint
        try:
            temp_info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            survivor = False
            try:
                missing_conflict = _bounded_retire_conflict_name(
                    target, temporary, name_max=self._name_max_at(parent)
                )
            except InvalidTask:
                missing_conflict = None
            for candidate in (target, missing_conflict):
                if candidate is None:
                    continue
                try:
                    candidate_info = os.stat(
                        candidate, dir_fd=parent, follow_symlinks=False
                    )
                except (FileNotFoundError, OSError):
                    continue
                if (
                    stat_module.S_ISREG(candidate_info.st_mode)
                    and candidate_info.st_dev == expected.device_id
                    and candidate_info.st_ino == expected.file_id
                ):
                    survivor = True
                    break
            try:
                os.unlink(marker_name, dir_fd=parent)
                _fsync_directory_when_supported(parent)
                return "restored" if survivor else "removed"
            except FileNotFoundError:
                return "restored" if survivor else "removed"
            except OSError:
                return "retry"
        except OSError:
            return "retry"
        if (
            not stat_module.S_ISREG(temp_info.st_mode)
            or temp_info.st_nlink not in (1, 2, 3)
        ):
            return "blocked"
        current = _fingerprint_from_stat(temp_info)
        if pending.retired_ctime_ns is None:
            # The process stopped after publishing the private retire name but
            # before recording its rename-induced ctime. It is impossible to
            # distinguish that ctime transition from a same-size open-writer
            # update, so recovery must preserve the inode conservatively.
            restored = self._recover_retired_file_at(parent, marker_name, marker)
            return "restored" if restored else "blocked"
        retired = replace(expected, ctime_ns=pending.retired_ctime_ns)
        if current != retired:
            restored = self._recover_retired_file_at(parent, marker_name, marker)
            return "restored" if restored else "blocked"

        # An interrupted no-clobber restore can have linked the exact retired
        # inode back to the target or its deterministic conflict name. Remove
        # only links proven to be this inode; unrelated winners are untouched.
        try:
            conflict = _bounded_retire_conflict_name(
                target, temporary, name_max=self._name_max_at(parent)
            )
        except InvalidTask:
            return "blocked"
        guard_candidate: str | None = None
        for candidate in (target, conflict):
            try:
                candidate_info = os.stat(
                    candidate, dir_fd=parent, follow_symlinks=False
                )
            except FileNotFoundError:
                # The caller's mount admission fence covers only the original
                # target. A visible conflict sibling can be opened or created
                # independently; using it as a disposable last-link guard
                # would let an untracked writer race our final unlink. Inspect
                # a pre-existing conflict only for interrupted restoration,
                # but never publish cleanup's transient guard there.
                if candidate == target:
                    guard_candidate = target
                continue
            except OSError:
                return "retry"
            if (
                stat_module.S_ISREG(candidate_info.st_mode)
                and candidate_info.st_dev == temp_info.st_dev
                and candidate_info.st_ino == temp_info.st_ino
            ):
                # A previous recovery already made these bytes visible. Do not
                # turn that preserved open-writer state back into a deletion.
                # Finish the interrupted no-clobber restore as one operation:
                # retain the visible link and remove only Meshia's private link
                # and owner marker.  Returning early here leaks both artifacts
                # on filesystems whose coarse ctime did not expose the link.
                restored = self._recover_retired_file_at(
                    parent, marker_name, marker
                )
                return "restored" if restored else "blocked"

        try:
            final_info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
        except OSError:
            return "retry"
        if not stat_module.S_ISREG(final_info.st_mode):
            return "blocked"
        final = _fingerprint_from_stat(final_info)
        if final != retired:
            restored = self._recover_retired_file_at(parent, marker_name, marker)
            return "restored" if restored else "blocked"
        if final_info.st_nlink != 1:
            return "blocked"
        if not allow_last_unlink:
            # A fresh WorkspaceBoundary has no authority to infer that an
            # external process's descriptor died with the prior Meshia
            # service. Restore the exact inode visibly so the reconciler can
            # classify/re-stage it; never turn a daemon restart into deletion
            # proof for an untracked writer.
            restored = self._recover_retired_file_at(parent, marker_name, marker)
            return "restored" if restored else "blocked"
        if guard_candidate is None:
            # A different inode legitimately owns the exact admitted target.
            # The mount fence excludes any new same-path description and has
            # already proved every tracked description of the retired inode
            # closed. Reclaim only its private link; never overwrite, link
            # through, or unlink the visible winner (nor an unfenced conflict).
            try:
                os.unlink(temporary, dir_fd=parent)
            except OSError:
                return "retry"
            return finish_reclaimed_data()

        # Never make the first unlink after the final identity check the last
        # link to these bytes. A writer can run inside that syscall after our
        # check. Publish a no-clobber survivor first, then compare that same
        # inode after the private link is gone. A changed survivor is user data
        # and remains visible; only a quiet survivor reaches last-link reclaim.
        try:
            os.link(
                temporary,
                guard_candidate,
                src_dir_fd=parent,
                dst_dir_fd=parent,
                follow_symlinks=False,
            )
            _fsync_directory_when_supported(parent)
            linked_info = os.stat(
                guard_candidate, dir_fd=parent, follow_symlinks=False
            )
            if (
                not stat_module.S_ISREG(linked_info.st_mode)
                or linked_info.st_nlink != 2
                or linked_info.st_dev != final_info.st_dev
                or linked_info.st_ino != final_info.st_ino
            ):
                return "blocked"
            linked = _fingerprint_from_stat(linked_info)
            os.unlink(temporary, dir_fd=parent)
            _fsync_directory_when_supported(parent)
            survivor_info = os.stat(
                guard_candidate, dir_fd=parent, follow_symlinks=False
            )
            if (
                not stat_module.S_ISREG(survivor_info.st_mode)
                or survivor_info.st_nlink != 1
                or survivor_info.st_dev != linked_info.st_dev
                or survivor_info.st_ino != linked_info.st_ino
            ):
                return "blocked"
            survivor = _fingerprint_from_stat(survivor_info)
            if not _same_regular_state_after_rename(linked, survivor):
                # The non-last unlink raced a writer. Retire only Meshia's
                # marker; the surviving target/conflict link is the durable,
                # visible recovery copy.
                os.unlink(marker_name, dir_fd=parent)
                _fsync_directory_when_supported(parent)
                return "restored"
            # This last-link unlink is permitted only after the public caller
            # supplied tracked_handles_closed=True while holding the same
            # path-scoped mount admission fence that excludes a new open.
            os.unlink(guard_candidate, dir_fd=parent)
            return finish_reclaimed_data()
        except (FileExistsError, OSError):
            return "retry"

    def _recover_stream_marker_at(
        self,
        parent: int,
        marker_name: str,
        marker_info: os.stat_result,
        cutoff_ns: int,
        relative_directory: str,
    ) -> str:
        if marker_info.st_nlink == 2:
            try:
                stage = _marker_staging_name(marker_name)
                stage_info = os.stat(stage, dir_fd=parent, follow_symlinks=False)
            except (InvalidTask, OSError):
                return "blocked"
            if (
                stage_info.st_dev != marker_info.st_dev
                or stage_info.st_ino != marker_info.st_ino
                or not self._recover_marker_stage_at(parent, stage, stage_info)
            ):
                return "blocked"
            try:
                marker_info = os.stat(
                    marker_name, dir_fd=parent, follow_symlinks=False
                )
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
        if (
            not stat_module.S_ISREG(marker_info.st_mode)
            or marker_info.st_nlink != 1
            or stat_module.S_IMODE(marker_info.st_mode) != 0o600
        ):
            return "blocked"
        try:
            descriptor = os.open(marker_name, _FILE_FLAGS, dir_fd=parent)
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"
        try:
            try:
                data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
                opened_info = os.fstat(descriptor)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if len(data) > _STREAM_TEMP_MARKER_MAX_BYTES:
                return "blocked"
            if (
                not stat_module.S_ISREG(opened_info.st_mode)
                or opened_info.st_nlink != 1
                or opened_info.st_dev != marker_info.st_dev
                or opened_info.st_ino != marker_info.st_ino
            ):
                return "blocked"
        finally:
            os.close(descriptor)
        quarantined = _parse_retired_quarantine_marker(marker_name, data)
        if quarantined is not None:
            return self._recover_quarantined_file_at(
                parent, marker_name, quarantined, relative_directory
            )
        fingerprint_removal = _parse_fingerprint_remove_temp_marker(
            marker_name, data
        )
        if fingerprint_removal is not None:
            pending = self._pending_fingerprint_removal_from_marker(
                marker_name, fingerprint_removal, relative_directory
            )
            self._remember_pending_fingerprint_removal(pending)
            with self._pending_fingerprint_removals_lock:
                marker_cleanup = (
                    pending.marker_path in self._fingerprint_marker_cleanup
                )
            if (
                _pid_is_live(int(fingerprint_removal["owner_pid"]))
                and not marker_cleanup
            ):
                return "blocked"
            outcome = self._recover_fingerprint_removal_at(
                parent,
                marker_name,
                fingerprint_removal,
                allow_last_unlink=False,
            )
            if outcome in {"removed", "restored"}:
                self._forget_pending_fingerprint_removal(pending.marker_path)
                with self._pending_fingerprint_removals_lock:
                    self._fingerprint_marker_cleanup.discard(
                        pending.marker_path
                    )
                return "removed"
            if outcome == "retry":
                self._stream_recovery_retry_required = True
                if marker_cleanup:
                    # The only remaining object is metadata. Keep it on the
                    # bounded cleanup schedule without presenting a false
                    # retained inode owner to eviction/recovery callers.
                    self._forget_pending_fingerprint_removal(
                        pending.marker_path
                    )
            return outcome
        retired = _parse_retire_temp_marker(marker_name, data)
        if retired is not None:
            if _pid_is_live(int(retired["owner_pid"])):
                return "blocked"
            return "removed" if WorkspaceBoundary._recover_retired_file_at(
                parent, marker_name, retired
            ) else "blocked"
        marker = _parse_stream_temp_marker(marker_name, data)
        if marker is None or marker_info.st_mtime_ns > cutoff_ns:
            return "blocked"
        if _pid_is_live(int(marker["owner_pid"])):
            return "blocked"
        temporary = str(marker["temporary"])
        target = str(marker["target"])
        try:
            temp_info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            try:
                os.unlink(marker_name, dir_fd=parent)
                return "removed"
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"
        if (
            not stat_module.S_ISREG(temp_info.st_mode)
            or stat_module.S_IMODE(temp_info.st_mode) != 0o600
            or temp_info.st_nlink not in (1, 2)
        ):
            return "blocked"
        if temp_info.st_nlink == 2:
            try:
                target_info = os.stat(target, dir_fd=parent, follow_symlinks=False)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if (
                not stat_module.S_ISREG(target_info.st_mode)
                or target_info.st_dev != temp_info.st_dev
                or target_info.st_ino != temp_info.st_ino
                or target_info.st_nlink != 2
            ):
                return "blocked"
        try:
            os.unlink(temporary, dir_fd=parent)
            os.unlink(marker_name, dir_fd=parent)
            return "removed"
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"

    def _recover_quarantined_file_at(
        self,
        parent: int,
        marker_name: str,
        marker: dict[str, object],
        relative_directory: str,
    ) -> str:
        temporary = str(marker["temporary"])
        target = str(marker["target"])
        conflict = str(marker["conflict"])
        try:
            expected_conflict = _bounded_retire_conflict_name(
                target, temporary, name_max=self._name_max_at(parent)
            )
        except InvalidTask:
            return "blocked"
        if conflict != expected_conflict:
            return "blocked"
        prefix = f"{relative_directory}/" if relative_directory else ""
        record = _RetiredQuarantineRecord(
            original_path=f"{prefix}{target}",
            temporary_path=f"{prefix}{temporary}",
            marker_path=f"{prefix}{marker_name}",
            conflict_path=f"{prefix}{conflict}",
            quarantined_at_ns=int(marker["quarantined_at_ns"]),
            recorded_size_bytes=int(marker["recorded_size_bytes"]),
            device_id=int(marker["device_id"]),
            file_id=int(marker["file_id"]),
            recorded_sha256=marker["recorded_sha256"],
            recorded_mtime_ns=marker["recorded_mtime_ns"],
            recorded_ctime_ns=marker["recorded_ctime_ns"],
            retain_unchanged=bool(marker["retain_unchanged"]),
            accounting_owner=str(marker["accounting_owner"]),
        )
        for existing in self._stream_recovery_quarantine_seen.values():
            if (
                existing.marker_path != record.marker_path
                and (existing.device_id, existing.file_id)
                == (record.device_id, record.file_id)
            ):
                return "blocked"
        try:
            temp_info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            try:
                conflict_info = os.stat(
                    conflict, dir_fd=parent, follow_symlinks=False
                )
            except FileNotFoundError:
                recovery_path = retired_quarantine_recovery_path(
                    record.conflict_path
                )
                try:
                    recovery = self.stat_fingerprint(recovery_path)
                except (InvalidTask, OSError, UnsafePath):
                    return "blocked"
                if recovery is None:
                    # The authenticated marker is the only artifact left. The
                    # retired inode was already reclaimed and no promoted link
                    # survived, so this is bounded metadata cleanup.
                    try:
                        os.unlink(marker_name, dir_fd=parent)
                        return "removed"
                    except OSError:
                        self._stream_recovery_retry_required = True
                        return "retry"
                if (
                    recovery.device_id != record.device_id
                    or recovery.file_id != record.file_id
                ):
                    return "blocked"
                self._stream_recovery_quarantine_seen[record.marker_path] = record
                self._queue_visible_quarantine_promotion(
                    record, visible_path=recovery_path
                )
                return "tracked"
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if (
                not stat_module.S_ISREG(conflict_info.st_mode)
                or conflict_info.st_nlink != 1
                or conflict_info.st_dev != record.device_id
                or conflict_info.st_ino != record.file_id
            ):
                return "blocked"
            self._stream_recovery_quarantine_seen[record.marker_path] = record
            self._queue_visible_quarantine_promotion(record)
            return "tracked"
        except OSError:
            self._stream_recovery_retry_required = True
            return "retry"
        if (
            not stat_module.S_ISREG(temp_info.st_mode)
            or temp_info.st_dev != record.device_id
            or temp_info.st_ino != record.file_id
            or temp_info.st_nlink not in (1, 2)
        ):
            return "blocked"
        if temp_info.st_nlink == 2:
            try:
                conflict_info = os.stat(
                    conflict, dir_fd=parent, follow_symlinks=False
                )
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            if (
                not stat_module.S_ISREG(conflict_info.st_mode)
                or conflict_info.st_dev != temp_info.st_dev
                or conflict_info.st_ino != temp_info.st_ino
                or conflict_info.st_nlink != 2
            ):
                return "blocked"
            try:
                os.unlink(temporary, dir_fd=parent)
                _fsync_directory_when_supported(parent)
            except OSError:
                self._stream_recovery_retry_required = True
                return "retry"
            self._stream_recovery_quarantine_seen[record.marker_path] = record
            self._queue_visible_quarantine_promotion(record)
            return "tracked"
        self._stream_recovery_quarantine_seen[record.marker_path] = record
        return "tracked"

    @staticmethod
    def _recover_retired_file_at(
        parent: int, marker_name: str, marker: dict[str, object]
    ) -> bool:
        """Restore a crash-retired file, never overwriting a newer local file."""

        temporary = str(marker["temporary"])
        target = str(marker["target"])
        try:
            temp_info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            try:
                os.unlink(marker_name, dir_fd=parent)
                return True
            except OSError:
                return False
        except OSError:
            return False
        if (
            not stat_module.S_ISREG(temp_info.st_mode)
            or temp_info.st_nlink not in (1, 2)
        ):
            return False
        try:
            conflict = _bounded_retire_conflict_name(
                target,
                temporary,
                name_max=WorkspaceBoundary._name_max_at(parent),
            )
        except InvalidTask:
            return False
        restored: str | None = None
        for candidate in (target, conflict):
            try:
                candidate_info = os.stat(
                    candidate, dir_fd=parent, follow_symlinks=False
                )
            except FileNotFoundError:
                if temp_info.st_nlink == 2:
                    continue
                try:
                    os.link(
                        temporary,
                        candidate,
                        src_dir_fd=parent,
                        dst_dir_fd=parent,
                        follow_symlinks=False,
                    )
                except FileExistsError:
                    continue
                except OSError:
                    return False
                restored = candidate
                break
            except OSError:
                return False
            if (
                stat_module.S_ISREG(candidate_info.st_mode)
                and candidate_info.st_dev == temp_info.st_dev
                and candidate_info.st_ino == temp_info.st_ino
            ):
                restored = candidate
                break
        if restored is None:
            return False
        try:
            linked = os.stat(restored, dir_fd=parent, follow_symlinks=False)
            if (
                not stat_module.S_ISREG(linked.st_mode)
                or linked.st_dev != temp_info.st_dev
                or linked.st_ino != temp_info.st_ino
                or linked.st_nlink != 2
            ):
                return False
            os.unlink(temporary, dir_fd=parent)
            os.unlink(marker_name, dir_fd=parent)
            _fsync_directory_when_supported(parent)
            return True
        except OSError:
            return False

    # ----------------------------------------------------------- path plumbing

    def _canonical_check(self, parts: Sequence[str]) -> None:
        """Third stage: realpath containment, independent of the fd walk."""
        _assert_posix_workspace_root_current(self._root_path, self._root_fd)
        candidate = os.path.realpath(os.path.join(str(self.root), *parts))
        root = str(self.root)
        if candidate != root and not candidate.startswith(root + os.sep):
            raise UnsafePath("The resolved path escapes the workspace root.")

    def _open_directory(self, parts: Sequence[str]) -> int:
        self._canonical_check(parts)
        current = os.dup(self._root_fd)
        try:
            for part in parts:
                nxt = os.open(part, _DIR_FLAGS, dir_fd=current)
                os.close(current)
                current = nxt
        except OSError as error:
            os.close(current)
            raise UnsafePath(
                "A workspace path component is missing, not a directory, or is a symbolic link."
            ) from error
        return current

    def _open_parent(self, parts: Sequence[str], create: bool = False) -> tuple[int, str]:
        if not parts:
            raise UnsafePath("A file path is required.")
        self._canonical_check(parts)
        current = os.dup(self._root_fd)
        try:
            for part in parts[:-1]:
                try:
                    nxt = os.open(part, _DIR_FLAGS, dir_fd=current)
                except FileNotFoundError:
                    if not create:
                        raise
                    try:
                        os.mkdir(part, 0o700, dir_fd=current)
                    except FileExistsError:
                        # Another watcher/apply worker won the mkdir race.  The
                        # O_NOFOLLOW directory open below validates the winner.
                        pass
                    nxt = os.open(part, _DIR_FLAGS, dir_fd=current)
                os.close(current)
                current = nxt
        except OSError as error:
            os.close(current)
            raise UnsafePath(
                "A workspace path component is missing, not a directory, or is a symbolic link."
            ) from error
        return current, parts[-1]

    def _open_parent_if_present(
        self, parts: Sequence[str]
    ) -> tuple[int, str] | None:
        """Open an existing parent, distinguishing absence from an unsafe link."""
        if not parts:
            raise UnsafePath("A file path is required.")
        self._canonical_check(parts)
        current = os.dup(self._root_fd)
        try:
            for part in parts[:-1]:
                try:
                    nxt = os.open(part, _DIR_FLAGS, dir_fd=current)
                except FileNotFoundError:
                    os.close(current)
                    return None
                os.close(current)
                current = nxt
        except OSError as error:
            os.close(current)
            raise UnsafePath(
                "A workspace path component is not a directory or is a symbolic link."
            ) from error
        return current, parts[-1]

    # ------------------------------------------------------------------- reads

    def exists(self, path: str) -> bool:
        try:
            parent, name = self._open_parent(split_relative(path))
        except UnsafePath:
            return False
        try:
            os.stat(name, dir_fd=parent, follow_symlinks=False)
            return True
        except OSError:
            return False
        finally:
            os.close(parent)

    def read_file(self, path: str, max_bytes: int = 262_144) -> tuple[bytes, bool]:
        if not 1 <= max_bytes <= MAX_READ_BYTES:
            raise InvalidTask("read_file max_bytes is outside the allowed range.")
        parent, name = self._open_parent(split_relative(path))
        try:
            descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
        except OSError as error:
            os.close(parent)
            raise UnsafePath("The source cannot be opened safely.") from error
        try:
            info = os.fstat(descriptor)
            if not stat_module.S_ISREG(info.st_mode):
                raise UnsafePath("read_file accepts regular files only.")
            data = os.read(descriptor, max_bytes + 1)
            while len(data) <= max_bytes:
                chunk = os.read(descriptor, max_bytes + 1 - len(data))
                if not chunk:
                    break
                data += chunk
            truncated = len(data) > max_bytes
            return data[:max_bytes], truncated
        finally:
            os.close(descriptor)
            os.close(parent)

    def stat_fingerprint(self, path: str) -> FileFingerprint | None:
        """Stat one regular file without following links or reading its contents."""
        opened_parent = self._open_parent_if_present(split_relative(path))
        if opened_parent is None:
            return None
        parent, name = opened_parent
        try:
            try:
                descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                return None
            except OSError as error:
                raise UnsafePath("The source cannot be opened safely.") from error
            try:
                fingerprint = _regular_fingerprint(
                    os.fstat(descriptor),
                    "The source must be a single-link regular file.",
                )
                current = self._path_fingerprint(parent, name)
                if current != fingerprint:
                    raise InvalidTask("The workspace file changed while it was being statted.")
                return fingerprint
            finally:
                os.close(descriptor)
        finally:
            os.close(parent)

    def with_regular_file_descriptor(
        self,
        path: str,
        operation: Callable[[int], _DescriptorResult],
        *,
        allow_mtime_change: bool = False,
    ) -> _DescriptorResult:
        """Apply a bounded metadata operation to one exact visible inode.

        The callback never receives a path: it operates through the pinned,
        no-follow descriptor only.  Identity and byte-visible state are checked
        before and after the callback so a concurrent replace cannot redirect a
        metadata update to another file or make a stale-inode result look live.
        Metadata operations may legitimately advance ctime, so the final fence
        deliberately compares device, inode, size, and mtime. A caller whose
        operation is explicitly setting mtime may opt out of only that field;
        the pinned descriptor, path identity, and size fences remain mandatory.
        """

        if not callable(operation):
            raise InvalidTask("The workspace descriptor operation must be callable.")
        opened_parent = self._open_parent_if_present(split_relative(path))
        if opened_parent is None:
            raise FileNotFoundError(path)
        parent, name = opened_parent
        descriptor = -1
        try:
            try:
                descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                raise
            except OSError as error:
                raise UnsafePath("The source cannot be opened safely.") from error
            before = _regular_fingerprint(
                os.fstat(descriptor),
                "The source must be a single-link regular file.",
            )
            if self._path_fingerprint(parent, name) != before:
                raise InvalidTask(
                    "The workspace file changed before its metadata operation."
                )
            result = operation(descriptor)
            after = _regular_fingerprint(
                os.fstat(descriptor),
                "The source must remain a single-link regular file.",
            )
            unchanged = (
                before.size_bytes == after.size_bytes
                and before.device_id == after.device_id
                and before.file_id == after.file_id
                and (allow_mtime_change or before.mtime_ns == after.mtime_ns)
            )
            if not unchanged or self._path_fingerprint(parent, name) != after:
                raise InvalidTask(
                    "The workspace file changed during its metadata operation."
                )
            return result
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            os.close(parent)

    def read_regular_range(
        self,
        path: str,
        offset_bytes: int,
        size_bytes: int,
        expected: FileFingerprint,
    ) -> bytes:
        """Read one bounded block from the exact anchored regular file."""

        if (
            isinstance(offset_bytes, bool)
            or not isinstance(offset_bytes, int)
            or offset_bytes < 0
            or isinstance(size_bytes, bool)
            or not isinstance(size_bytes, int)
            or not 0 <= size_bytes <= MAX_ANCHORED_RANGE_BYTES
            or not isinstance(expected, FileFingerprint)
            or offset_bytes + size_bytes > expected.size_bytes
        ):
            raise InvalidTask("The anchored workspace range is invalid.")
        opened_parent = self._open_parent_if_present(split_relative(path))
        if opened_parent is None:
            raise InvalidTask("The anchored workspace source disappeared.")
        parent, name = opened_parent
        try:
            try:
                descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except OSError as error:
                raise UnsafePath("The source cannot be opened safely.") from error
            try:
                before = _regular_fingerprint(
                    os.fstat(descriptor),
                    "The source must remain a single-link regular file.",
                )
                if before != expected:
                    raise InvalidTask("The anchored workspace source changed.")
                data = bytearray()
                while len(data) < size_bytes:
                    chunk = os.pread(
                        descriptor,
                        size_bytes - len(data),
                        offset_bytes + len(data),
                    )
                    if not chunk:
                        break
                    data.extend(chunk)
                after = _regular_fingerprint(
                    os.fstat(descriptor),
                    "The source must remain a single-link regular file.",
                )
                if (
                    len(data) != size_bytes
                    or after != expected
                    or self._path_fingerprint(parent, name) != expected
                ):
                    raise InvalidTask("The anchored workspace source changed during read.")
                return bytes(data)
            finally:
                os.close(descriptor)
        finally:
            os.close(parent)

    def hash_regular_file(
        self, path: str, max_bytes: int = MAX_STREAM_FILE_BYTES
    ) -> HashedRegularFile | None:
        """Hash a stable regular file in bounded chunks, returning ``None`` if absent."""
        opened_parent = self._open_parent_if_present(split_relative(path))
        if opened_parent is None:
            return None
        parent, name = opened_parent
        try:
            try:
                descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                return None
            except OSError as error:
                raise UnsafePath("The source cannot be opened safely.") from error
            try:
                hashed = _hash_open_regular(descriptor, max_bytes)
                if self._path_fingerprint(parent, name) != hashed.fingerprint:
                    raise InvalidTask("The workspace file changed while it was being hashed.")
                return hashed
            finally:
                os.close(descriptor)
        finally:
            os.close(parent)

    def copy_regular_file_to_descriptor(
        self,
        path: str,
        destination_fd: int,
        *,
        max_bytes: int = MAX_STREAM_FILE_BYTES,
        chunk_bytes: int = STREAM_IO_BYTES,
        on_chunk: Callable[[bytes, int], None] | None = None,
        chunk_sizes: Sequence[int] | None = None,
    ) -> HashedRegularFile | None:
        """Confined one-pass stage+hash into a caller-owned descriptor.

        The caller owns descriptor positioning, fsync, truncation, and cleanup.
        Callback exceptions propagate before that chunk is copied.
        """
        opened_parent = self._open_parent_if_present(split_relative(path))
        if opened_parent is None:
            return None
        parent, name = opened_parent
        try:
            try:
                source_fd = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                return None
            except OSError as error:
                raise UnsafePath("The source cannot be opened safely.") from error
            try:
                hashed = _copy_hash_open_regular(
                    source_fd,
                    destination_fd,
                    max_bytes,
                    chunk_bytes,
                    on_chunk,
                    chunk_sizes,
                )
                if self._path_fingerprint(parent, name) != hashed.fingerprint:
                    raise InvalidTask("The workspace file changed while it was being copied.")
                return hashed
            finally:
                os.close(source_fd)
        finally:
            os.close(parent)

    def copy_regular_file_identity_to_descriptor(
        self,
        path: str,
        destination_fd: int,
        *,
        expected_fingerprint: FileFingerprint,
        max_bytes: int = MAX_STREAM_FILE_BYTES,
        chunk_bytes: int = STREAM_IO_BYTES,
    ) -> FileFingerprint | None:
        """Copy an exact stat identity in bounded memory without hashing it.

        This is intentionally not content authority. It exists for exporting a
        protocol-oversize local conflict whose bytes must remain recoverable but
        must not be hashed merely to fit the upload protocol. The complete stat
        tuple is checked on the open descriptor and at the visible path before
        and after the copy.
        """

        opened_parent = self._open_parent_if_present(split_relative(path))
        if opened_parent is None:
            return None
        parent, name = opened_parent
        try:
            try:
                source_fd = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                return None
            except OSError as error:
                raise UnsafePath("The source cannot be opened safely.") from error
            try:
                before = _regular_fingerprint(
                    os.fstat(source_fd),
                    "The source must be a single-link regular file.",
                )
                if before != expected_fingerprint or self._path_fingerprint(
                    parent, name
                ) != before:
                    raise InvalidTask(
                        "The workspace file no longer has the recorded identity."
                    )
                copied = _copy_open_regular_identity(
                    source_fd,
                    destination_fd,
                    expected_fingerprint,
                    max_bytes,
                    chunk_bytes,
                )
                if self._path_fingerprint(parent, name) != copied:
                    raise InvalidTask(
                        "The workspace file changed while it was being copied."
                    )
                return copied
            finally:
                os.close(source_fd)
        finally:
            os.close(parent)

    def sha256_if_present(self, path: str, max_bytes: int = 1_048_576) -> str | None:
        try:
            data, truncated = self.read_file(path, max_bytes)
        except (UnsafePath, OSError):
            return None
        if truncated:
            raise InvalidTask(f"Workspace file {path} exceeds the 1 MiB Fabric limit.")
        return sha256_hex(data)

    def snapshot(self, path: str, max_bytes: int = 1_048_576) -> bytes | None:
        try:
            data, truncated = self.read_file(path, max_bytes)
        except (UnsafePath, OSError):
            return None
        if truncated:
            raise InvalidTask(f"Workspace file {path} exceeds the 1 MiB Fabric limit.")
        return data

    def list(
        self, path: str = ".", max_entries: int = 1_000, recursive: bool = False
    ) -> tuple[list[str], bool]:
        if not 1 <= max_entries <= MAX_LIST_ENTRIES:
            raise InvalidTask("list max_entries is outside the allowed range.")
        parts = split_relative(path, allow_root=True)
        entries: list[str] = []
        truncated = False
        pending: deque[tuple[list[str], str]] = deque(((list(parts), ""),))
        while pending:
            branch, prefix = pending.popleft()
            descriptor = self._open_directory(branch)
            try:
                remaining = max_entries - len(entries)
                with os.scandir(descriptor) as directory_entries:
                    names, directory_truncated = _bounded_sorted_names(
                        (
                            item.name
                            for item in directory_entries
                            if item.name.casefold()
                            != WORKSPACE_METADATA_DIRECTORY.casefold()
                            and _MESHIA_RESERVED_TEMP_SEGMENT_RE.fullmatch(item.name)
                            is None
                        ),
                        remaining,
                    )
                for name in names:
                    relative = f"{prefix}{name}"
                    try:
                        info = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
                        is_dir = stat_module.S_ISDIR(info.st_mode)
                    except OSError:
                        is_dir = False
                    entries.append(f"{relative}/" if is_dir else relative)
                    if recursive and is_dir:
                        pending.append((branch + [name], f"{relative}/"))
                if directory_truncated:
                    truncated = True
            finally:
                os.close(descriptor)
            if truncated:
                break
        return entries, truncated

    def directory_exists(self, path: str = ".") -> bool:
        """Return whether a public path is a real directory below the root."""

        parts = split_relative(path, allow_root=True)
        try:
            descriptor = self._open_directory(parts)
        except (OSError, UnsafePath):
            return False
        os.close(descriptor)
        return True

    def create_directory(self, path: str, *, create_parents: bool = False) -> None:
        """Create one public directory without following an existing link."""

        parts = split_relative(path)
        parent, name = self._open_parent(parts, create=create_parents)
        try:
            try:
                os.mkdir(name, 0o700, dir_fd=parent)
            except FileExistsError as error:
                raise UnsafePath("The directory destination already exists.") from error
            _fsync_directory_when_supported(parent)
            opened = os.open(name, _DIR_FLAGS, dir_fd=parent)
            try:
                info = os.fstat(opened)
                if not stat_module.S_ISDIR(info.st_mode):
                    raise UnsafePath("The created workspace directory is unsafe.")
            finally:
                os.close(opened)
        finally:
            os.close(parent)

    def remove_empty_directory(self, path: str) -> None:
        """Remove one exact empty public directory without traversing links."""

        parts = split_relative(path)
        opened = self._open_parent_if_present(parts)
        if opened is None:
            raise InvalidTask("The directory does not exist.")
        parent, name = opened
        try:
            directory = os.open(name, _DIR_FLAGS, dir_fd=parent)
            try:
                # Darwin can treat AppleDouble-looking ``._*``/``.__*``
                # children as removable directory metadata and delete them as
                # part of rmdir(2). Meshia retire/quarantine evidence uses a
                # reserved ``.__*.meshia-*`` namespace and must never be lost
                # through that platform shortcut. Inspect the raw descriptor,
                # including reserved entries hidden from public list(), before
                # issuing the exact rmdir. A concurrent ordinary child remains
                # protected by the kernel's normal ENOTEMPTY result.
                with os.scandir(directory) as entries:
                    if next(entries, None) is not None:
                        raise OSError(
                            errno.ENOTEMPTY,
                            "The workspace directory is not physically empty.",
                        )
            finally:
                os.close(directory)
            os.rmdir(name, dir_fd=parent)
            _fsync_directory_when_supported(parent)
        finally:
            os.close(parent)

    def prune_empty_directories(self, path: str) -> int:
        """Remove empty directories below and including ``path`` bottom-up.

        Files, links, concurrent additions, and non-empty directories are never
        removed. Every final removal still goes through the descriptor-confined
        exact-directory primitive, so a namespace race can at worst leave an
        empty directory for the next idempotent pass.
        """

        split_relative(path)
        if not self.directory_exists(path):
            return 0
        entries, truncated = self.list(
            path,
            max_entries=MAX_LIST_ENTRIES,
            recursive=True,
        )
        if truncated:
            raise InvalidTask("The empty-directory prune exceeded its bounded scan.")
        directories = [
            f"{path}/{entry[:-1]}" for entry in entries if entry.endswith("/")
        ]
        removed = 0
        for candidate in sorted(
            (*directories, path),
            key=lambda value: value.count("/"),
            reverse=True,
        ):
            try:
                self.remove_empty_directory(candidate)
            except InvalidTask:
                continue
            except OSError as error:
                if error.errno in (
                    errno.ENOENT,
                    errno.ENOTEMPTY,
                    getattr(errno, "EEXIST", errno.ENOTEMPTY),
                ):
                    continue
                raise
            else:
                removed += 1
        return removed

    def open_mount_stage_descriptor(self, path: Path | str, *, create: bool = False) -> int:
        """Open the exact private mounted-write inode without following links."""
        candidate = Path(path)
        root = self.mount_staging_directory()
        if (candidate.parent.resolve(strict=True) != root.resolve(strict=True)
                or re.fullmatch(r"[0-9a-f]{32}\.data", candidate.name) is None):
            raise UnsafePath("The mounted-write stage is outside Meshia's private store.")
        flags = os.O_RDWR | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
        if create:
            flags |= os.O_CREAT | os.O_EXCL
        return os.open(candidate, flags, 0o600)

    def mount_staging_directory(self) -> Path:
        """Return a private, same-filesystem staging directory for mounted writes.

        A FUSE write must remain invisible to the ordinary workspace watcher
        until the writing process closes the file.  Keeping the temporary inode
        below the claimed ``.meshia`` directory both hides it from the public
        namespace and guarantees that publication into the workspace can be an
        atomic rename without making another full-size copy.
        """

        metadata, _created = _open_posix_workspace_metadata(
            self._root_fd, create=True, repair_privacy=True
        )
        try:
            try:
                os.mkdir(MOUNT_STAGE_DIRECTORY, 0o700, dir_fd=metadata)
                _fsync_directory_when_supported(metadata)
            except FileExistsError:
                pass
            try:
                staging = os.open(MOUNT_STAGE_DIRECTORY, _DIR_FLAGS, dir_fd=metadata)
            except OSError as error:
                raise UnsafePath(
                    "The private mounted-write staging directory is unsafe."
                ) from error
            try:
                info = os.fstat(staging)
                current = os.stat(
                    MOUNT_STAGE_DIRECTORY,
                    dir_fd=metadata,
                    follow_symlinks=False,
                )
                if (
                    not stat_module.S_ISDIR(info.st_mode)
                    or not _same_file_identity(info, current)
                    or (hasattr(os, "geteuid") and info.st_uid != os.geteuid())
                ):
                    raise UnsafePath(
                        "The private mounted-write staging directory is unsafe."
                    )
                if stat_module.S_IMODE(info.st_mode) != 0o700:
                    os.fchmod(staging, 0o700)
                    _fsync_directory_when_supported(staging)
            finally:
                os.close(staging)
        finally:
            os.close(metadata)
        return self.root / WORKSPACE_METADATA_DIRECTORY / MOUNT_STAGE_DIRECTORY

    def publish_mount_stage(
        self,
        path: str,
        stage_path: Path | str,
        *,
        expected_stage_fingerprint: FileFingerprint,
        expected_existing_fingerprint: FileFingerprint | None,
    ) -> FileFingerprint:
        """Atomically adopt one closed mounted-write inode without copying it.

        The stage must be a single-link regular file in Meshia's private mount
        staging directory.  Both the stage and any existing destination are
        fenced by their exact stat identities immediately before ``rename``.
        Remote generation/digest CAS remains the authority for cross-device
        conflicts after this local publication step.
        """

        if not isinstance(expected_stage_fingerprint, FileFingerprint):
            raise InvalidTask("expected_stage_fingerprint must be a FileFingerprint.")
        if expected_existing_fingerprint is not None and not isinstance(
            expected_existing_fingerprint, FileFingerprint
        ):
            raise InvalidTask(
                "expected_existing_fingerprint must be a FileFingerprint or null."
            )
        target_parts = split_relative(path)
        staging_root = self.mount_staging_directory()
        candidate = Path(stage_path)
        if not candidate.is_absolute():
            raise UnsafePath("The mounted-write stage path must be absolute.")
        try:
            candidate_parent = candidate.parent.resolve(strict=True)
            expected_parent = staging_root.resolve(strict=True)
        except OSError as error:
            raise UnsafePath("The mounted-write stage directory disappeared.") from error
        if candidate_parent != expected_parent or candidate.name in ("", ".", ".."):
            raise UnsafePath("The mounted-write stage is outside Meshia's private store.")

        stage_parent = os.open(str(expected_parent), _DIR_FLAGS)
        target_parent = -1
        source_fd = -1
        try:
            try:
                source_fd = os.open(candidate.name, _FILE_FLAGS, dir_fd=stage_parent)
            except OSError as error:
                raise UnsafePath("The mounted-write stage cannot be opened safely.") from error
            before = _regular_fingerprint(
                os.fstat(source_fd),
                "The mounted-write stage must be a single-link regular file.",
            )
            current_source = self._path_fingerprint(stage_parent, candidate.name)
            if before != expected_stage_fingerprint or current_source != before:
                raise InvalidTask("The mounted-write stage changed before publication.")

            target_parent, target_name = self._open_parent(
                target_parts, create=True
            )
            current_target = self._path_fingerprint(target_parent, target_name)
            if current_target != expected_existing_fingerprint:
                raise InvalidTask(
                    "The mounted-write destination changed before publication."
                )
            try:
                os.replace(
                    candidate.name,
                    target_name,
                    src_dir_fd=stage_parent,
                    dst_dir_fd=target_parent,
                )
            except OSError as error:
                if error.errno == errno.EXDEV:
                    raise InvalidTask(
                        "The mounted-write stage is not on the workspace filesystem."
                    ) from error
                raise
            _fsync_directory_when_supported(target_parent)
            _fsync_directory_when_supported(stage_parent)
            published = self._path_fingerprint(target_parent, target_name)
            if published is None or not _same_regular_state_after_rename(
                before, published
            ):
                raise InvalidTask("The mounted write changed during publication.")
            return published
        finally:
            if source_fd >= 0:
                os.close(source_fd)
            if target_parent >= 0:
                os.close(target_parent)
            os.close(stage_parent)

    # ------------------------------------------------------------------ writes

    def write_file(
        self,
        path: str,
        data: bytes,
        *,
        create_parents: bool = False,
        overwrite: bool = True,
        expected_sha256: str | None = None,
    ) -> None:
        """Atomically publish `data` at `path`, honouring an optional CAS guard."""
        if len(data) > MAX_WRITE_BYTES:
            raise InvalidTask("write_file exceeds the 8 MiB limit.")
        if expected_sha256 is not None and not TAGGED_SHA256_RE.match(expected_sha256):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        tagged = f"sha256:{hashlib.sha256(data).hexdigest()}"
        chunks: tuple[bytes, ...] = (data,) if data else ()
        self.write_stream(
            path,
            chunks,
            expected_size=len(data),
            expected_sha256=tagged,
            create_parents=create_parents,
            overwrite=overwrite,
            expected_existing_sha256=expected_sha256,
        )

    def write_stream(
        self,
        path: str,
        chunks: Iterable[bytes],
        *,
        expected_size: int,
        expected_sha256: str,
        create_parents: bool = False,
        overwrite: bool = True,
        expected_existing_sha256: str | None = None,
        expected_existing_fingerprint: FileFingerprint | None = None,
        retain_replaced: bool = False,
        require_retention_capacity: bool = False,
    ) -> RetiredRegularFile | None:
        """Verify and atomically publish a file from a bounded-memory byte stream.

        ``expected_existing_sha256`` is an optimistic compare-and-swap guard.
        It is hashed immediately before atomic replacement so an editor cannot
        hide a content change behind a restored timestamp.  Portable local
        filesystems cannot make the hash and rename one atomic operation;
        higher-level sync must still generation-CAS and preserve conflicts.
        """
        _validate_stream_contract(
            expected_size, expected_sha256, expected_existing_sha256
        )
        if not isinstance(retain_replaced, bool):
            raise InvalidTask("retain_replaced must be a boolean.")
        if not isinstance(require_retention_capacity, bool):
            raise InvalidTask("require_retention_capacity must be a boolean.")
        if require_retention_capacity and not retain_replaced:
            raise InvalidTask(
                "require_retention_capacity requires retain_replaced."
            )
        if retain_replaced and expected_existing_sha256 is None:
            raise InvalidTask(
                "retain_replaced requires expected_existing_sha256."
            )
        if expected_existing_sha256 is not None and not overwrite:
            raise InvalidTask(
                "expected_existing_sha256 cannot be combined with overwrite=false."
            )
        if expected_existing_fingerprint is not None and (
            not isinstance(expected_existing_fingerprint, FileFingerprint)
            or expected_existing_sha256 is None
        ):
            raise InvalidTask(
                "expected_existing_fingerprint requires an existing digest guard."
            )
        parts = split_relative(path)
        parent, name = self._open_parent(parts, create=create_parents)
        temporary = _owned_temporary_name("stream")
        marker = temporary + STREAM_TEMP_MARKER_SUFFIX
        descriptor = -1
        published = False
        marker_created = False
        retained_result: RetiredRegularFile | None = None
        retention_reservation: str | None = None
        try:
            # Refuse unsafe destinations before receiving a potentially large
            # stream.  The destination is inspected again at commit time.
            existing = self._path_fingerprint(parent, name)
            if existing is not None and not overwrite:
                raise UnsafePath("The destination exists and overwrite is false.")
            if require_retention_capacity:
                retention_reservation = self._reserve_retained_retirement_slot()
                if retention_reservation is None:
                    raise RetentionCapacityUnavailable()
            if expected_existing_sha256 is not None:
                if expected_existing_fingerprint is not None:
                    if (
                        self._path_fingerprint(parent, name)
                        != expected_existing_fingerprint
                    ):
                        raise InvalidTask(
                            "The destination fingerprint changed before streaming."
                        )
                else:
                    preflight = self._hash_existing_at(parent, name)
                    if preflight is None:
                        raise InvalidTask(
                            "expected_existing_sha256 requires an existing destination."
                        )
                    if preflight.tagged_sha256 != expected_existing_sha256:
                        raise InvalidTask(
                            "The destination digest does not match expected_existing_sha256."
                        )
            marker_data = _stream_temp_marker_bytes(
                temporary, name, expected_size, expected_sha256
            )
            _write_private_marker_at(parent, marker, marker_data)
            marker_created = True
            descriptor = os.open(
                temporary,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_CLOEXEC,
                0o600,
                dir_fd=parent,
            )
            try:
                os.fchmod(descriptor, 0o600)
                _stream_chunks_to_descriptor(
                    descriptor,
                    chunks,
                    expected_size=expected_size,
                    expected_sha256=expected_sha256,
                )
                # Invalid size/digest streams never pay a durability flush and
                # can never replace the visible destination.
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
                descriptor = -1

            retired: tuple[str, str, HashedRegularFile] | None = None
            if expected_existing_sha256 is not None:
                retired = self._retire_file_at(
                    parent,
                    name,
                    expected=(
                        HashedRegularFile(
                            expected_existing_fingerprint,
                            expected_existing_sha256.removeprefix("sha256:"),
                        )
                        if expected_existing_fingerprint is not None
                        else None
                    ),
                )
                if retired is None:
                    raise InvalidTask(
                        "expected_existing_sha256 requires an existing destination."
                    )
                if retired[2].tagged_sha256 != expected_existing_sha256:
                    self._restore_retired_file_at(parent, name, retired)
                    raise InvalidTask(
                        "The destination digest does not match expected_existing_sha256."
                    )
            else:
                # Reparse points, directories, and multiply-linked destinations
                # remain forbidden even if they appeared while the stream ran.
                self._path_fingerprint(parent, name)

            if retired is not None:
                try:
                    # The expected preimage is now safely retired. Publish only
                    # if an editor did not create a newer destination meanwhile.
                    os.link(
                        temporary,
                        name,
                        src_dir_fd=parent,
                        dst_dir_fd=parent,
                        follow_symlinks=False,
                    )
                    os.unlink(temporary, dir_fd=parent)
                except BaseException:
                    self._restore_retired_file_at(parent, name, retired)
                    raise
                published = True
                if retain_replaced:
                    prefix = "/".join(parts[:-1])
                    temporary_path = (
                        f"{prefix}/{retired[0]}" if prefix else retired[0]
                    )
                    marker_path = f"{temporary_path}{STREAM_TEMP_MARKER_SUFFIX}"
                    retained_result = RetiredRegularFile(
                        original_path=path,
                        temporary_path=temporary_path,
                        marker_path=marker_path,
                        initial=retired[2],
                        retention_reservation=retention_reservation,
                    )
                    retention_reservation = None
                else:
                    self._finish_internal_retired_file_at(
                        parent, name, retired, path
                    )
            elif overwrite:
                os.replace(temporary, name, src_dir_fd=parent, dst_dir_fd=parent)
            else:
                # linkat is an atomic create-if-absent on the same filesystem;
                # unlike rename it cannot clobber a file created concurrently.
                os.link(
                    temporary,
                    name,
                    src_dir_fd=parent,
                    dst_dir_fd=parent,
                    follow_symlinks=False,
                )
                os.unlink(temporary, dir_fd=parent)
            published = True
            try:
                os.unlink(marker, dir_fd=parent)
                marker_created = False
            except OSError:
                # A durable owner marker is safe to leave behind: startup
                # recovery removes marker-only remnants without touching target.
                pass
            _fsync_directory_when_supported(parent)
        finally:
            if descriptor >= 0:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
            if not published:
                try:
                    os.unlink(temporary, dir_fd=parent)
                except OSError:
                    pass
            if marker_created:
                try:
                    os.unlink(marker, dir_fd=parent)
                except OSError:
                    pass
            self._release_retained_retirement_slot(retention_reservation)
            os.close(parent)
        return retained_result

    def replace_stream_by_fingerprint(
        self,
        path: str,
        chunks: Iterable[bytes],
        *,
        expected_size: int,
        expected_sha256: str,
        expected_existing_fingerprint: FileFingerprint,
        create_parents: bool = False,
    ) -> FingerprintReplaceResult:
        """Replace only one exact local object identity, without hashing it.

        This is the narrow conflict-recovery counterpart to the digest CAS in
        :meth:`write_stream`. It proves the complete recorded stat identity on
        a no-follow descriptor immediately before and after retiring the entry.
        That identity is not presented as a content digest. If an already-open
        writer advances the retired inode, those bytes are restored at a
        collision-free visible conflict path instead of being discarded.
        """

        _validate_stream_contract(expected_size, expected_sha256, None)
        if not isinstance(expected_existing_fingerprint, FileFingerprint):
            raise InvalidTask(
                "expected_existing_fingerprint must be a FileFingerprint."
            )
        parts = split_relative(path)
        parent, name = self._open_parent(parts, create=create_parents)
        incoming = _owned_temporary_name("stream")
        incoming_marker = incoming + STREAM_TEMP_MARKER_SUFFIX
        retired = _owned_temporary_name("retire")
        retired_marker = retired + STREAM_TEMP_MARKER_SUFFIX
        incoming_fd = -1
        existing_fd = -1
        incoming_marker_created = False
        retired_marker_created = False
        published = False
        preserved_path: str | None = None
        try:
            marker_data = _stream_temp_marker_bytes(
                incoming, name, expected_size, expected_sha256
            )
            _write_private_marker_at(parent, incoming_marker, marker_data)
            incoming_marker_created = True
            incoming_fd = os.open(
                incoming,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_CLOEXEC,
                0o600,
                dir_fd=parent,
            )
            try:
                os.fchmod(incoming_fd, 0o600)
                _stream_chunks_to_descriptor(
                    incoming_fd,
                    chunks,
                    expected_size=expected_size,
                    expected_sha256=expected_sha256,
                )
                os.fsync(incoming_fd)
            finally:
                os.close(incoming_fd)
                incoming_fd = -1

            try:
                existing_fd = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except OSError as error:
                raise UnsafePath(
                    "The conflict loser cannot be opened safely for replacement."
                ) from error
            opened = _regular_fingerprint(
                os.fstat(existing_fd),
                "The conflict loser must be a single-link regular file.",
            )
            if (
                opened != expected_existing_fingerprint
                or self._path_fingerprint(parent, name) != opened
            ):
                raise InvalidTask(
                    "The conflict loser no longer has the recorded identity."
                )

            _write_private_marker_at(
                parent,
                retired_marker,
                _retire_temp_marker_bytes(retired, name),
            )
            retired_marker_created = True
            os.rename(name, retired, src_dir_fd=parent, dst_dir_fd=parent)
            _fsync_directory_when_supported(parent)
            retired_identity = _regular_fingerprint(
                os.fstat(existing_fd),
                "The retired conflict loser must remain a regular file.",
            )
            if (
                not _same_regular_state_after_rename(
                    expected_existing_fingerprint, retired_identity
                )
                or self._path_fingerprint(parent, retired) != retired_identity
            ):
                recovered = self._recover_retired_file_at(
                    parent,
                    retired_marker,
                    {"temporary": retired, "target": name, "owner_pid": os.getpid()},
                )
                retired_marker_created = not recovered
                raise InvalidTask(
                    "The conflict loser changed immediately before replacement."
                )

            # The retired entry owns the original inode and the destination is
            # absent. linkat is therefore an atomic create-if-absent publish.
            os.link(
                incoming,
                name,
                src_dir_fd=parent,
                dst_dir_fd=parent,
                follow_symlinks=False,
            )
            os.unlink(incoming, dir_fd=parent)
            published = True
            try:
                os.unlink(incoming_marker, dir_fd=parent)
                incoming_marker_created = False
            except OSError:
                pass
            _fsync_directory_when_supported(parent)

            written_fingerprint = self._path_fingerprint(parent, name)
            if written_fingerprint is None:
                raise InvalidTask("The replacement disappeared after publication.")
            # An unhashable loser may still have writers holding its inode.
            # Keep that inode visible under a recovery name instead of trying
            # to infer future content stability from a momentary stat tuple.
            conflict_name = _bounded_retire_conflict_name(
                name, retired, name_max=self._name_max_at(parent)
            )
            if not self._recover_retired_file_at(
                parent,
                retired_marker,
                {"temporary": retired, "target": name, "owner_pid": os.getpid()},
            ):
                raise InvalidTask(
                    "Conflict-loser bytes remain privately recoverable."
                )
            retired_marker_created = False
            prefix = "/".join(parts[:-1])
            preserved_path = f"{prefix}/{conflict_name}" if prefix else conflict_name
            return FingerprintReplaceResult(
                written=HashedRegularFile(
                    written_fingerprint, expected_sha256.removeprefix("sha256:")
                ),
                preserved_path=preserved_path,
            )
        finally:
            if incoming_fd >= 0:
                os.close(incoming_fd)
            if existing_fd >= 0:
                os.close(existing_fd)
            if not published:
                try:
                    os.unlink(incoming, dir_fd=parent)
                except OSError:
                    pass
            if incoming_marker_created:
                try:
                    os.unlink(incoming_marker, dir_fd=parent)
                except OSError:
                    pass
            # A retire marker is intentionally left for startup recovery after
            # any post-publish failure. Before publication, restore the loser.
            if retired_marker_created and not published:
                self._recover_retired_file_at(
                    parent,
                    retired_marker,
                    {"temporary": retired, "target": name, "owner_pid": os.getpid()},
                )
            os.close(parent)

    def preserve_file_by_fingerprint(
        self, path: str, *, expected_fingerprint: FileFingerprint
    ) -> str:
        """Move an exact unhashable loser to a visible recovery sibling.

        The no-follow descriptor is checked immediately before link/unlink.
        The hard link keeps the same inode visible, so writes through an
        already-open handle remain recoverable instead of disappearing after a
        keep-remote decision whose authoritative winner is absence/remote-only.
        """

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        parts = split_relative(path)
        opened_parent = self._open_parent_if_present(parts)
        if opened_parent is None:
            raise InvalidTask("The conflict loser disappeared before preservation.")
        parent, name = opened_parent
        descriptor = -1
        linked = False
        original_removed = False
        temporary = _owned_temporary_name("retire")
        conflict_name = _bounded_retire_conflict_name(
            name, temporary, name_max=self._name_max_at(parent)
        )
        try:
            descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            opened = _regular_fingerprint(
                os.fstat(descriptor),
                "The conflict loser must be a single-link regular file.",
            )
            if (
                opened != expected_fingerprint
                or self._path_fingerprint(parent, name) != opened
            ):
                raise InvalidTask(
                    "The conflict loser no longer has the recorded identity."
                )
            os.link(
                name,
                conflict_name,
                src_dir_fd=parent,
                dst_dir_fd=parent,
                follow_symlinks=False,
            )
            linked = True
            # The open descriptor proves which inode was linked. A replacement
            # racing after link wins the original path and is never unlinked.
            linked_info = os.stat(
                conflict_name, dir_fd=parent, follow_symlinks=False
            )
            opened_info = os.fstat(descriptor)
            if (
                linked_info.st_dev != opened_info.st_dev
                or linked_info.st_ino != opened_info.st_ino
            ):
                raise InvalidTask("The recovery sibling captured another file.")
            try:
                current_info = os.stat(name, dir_fd=parent, follow_symlinks=False)
            except OSError:
                current_info = None
            if (
                current_info is not None
                and stat_module.S_ISREG(current_info.st_mode)
                and current_info.st_nlink == 2
                and current_info.st_dev == opened_info.st_dev
                and current_info.st_ino == opened_info.st_ino
            ):
                os.unlink(name, dir_fd=parent)
                original_removed = True
            _fsync_directory_when_supported(parent)
            prefix = "/".join(parts[:-1])
            return f"{prefix}/{conflict_name}" if prefix else conflict_name
        except BaseException:
            # Once the original name is gone the sibling is the only visible
            # owner of these bytes. Never remove it merely because a later
            # directory durability call failed.
            if linked and not original_removed:
                try:
                    os.unlink(conflict_name, dir_fd=parent)
                except OSError:
                    pass
            raise
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            os.close(parent)

    def _retire_file_at(
        self,
        parent: int,
        name: str,
        *,
        expected: HashedRegularFile | None = None,
    ) -> tuple[str, str, HashedRegularFile] | None:
        """Atomically capture the current entry behind a crash-recovery marker."""

        if (
            self.stream_recovery_pending
            or self._stream_recovery_retry_required
            or self._fingerprint_removal_pending()
        ):
            raise InvalidTask("Retired-inode quarantine recovery is incomplete.")
        self.maintain_retired_quarantine()
        temporary = _owned_temporary_name("retire")
        marker = temporary + STREAM_TEMP_MARKER_SUFFIX
        _write_private_marker_at(
            parent, marker, _retire_temp_marker_bytes(temporary, name)
        )
        if expected is not None and self._path_fingerprint(parent, name) != expected.fingerprint:
            os.unlink(marker, dir_fd=parent)
            raise InvalidTask("The workspace file changed before retirement.")
        parent_before_rename = _directory_namespace_time_ns(os.fstat(parent))
        try:
            os.rename(name, temporary, src_dir_fd=parent, dst_dir_fd=parent)
        except FileNotFoundError:
            os.unlink(marker, dir_fd=parent)
            return None
        except BaseException:
            try:
                os.unlink(marker, dir_fd=parent)
            except OSError:
                pass
            raise
        parent_after_rename = _directory_namespace_time_ns(os.fstat(parent))
        _fsync_directory_when_supported(parent)
        try:
            if expected is not None:
                retired_fingerprint = self._path_fingerprint(parent, temporary)
                if retired_fingerprint is None or not _same_regular_state_after_rename(
                    expected.fingerprint, retired_fingerprint
                ):
                    raise InvalidTask(
                        "The workspace file changed during retirement."
                    )
                if (
                    retired_fingerprint.ctime_ns != expected.fingerprint.ctime_ns
                    and (
                        parent_after_rename <= parent_before_rename
                        or not (
                            parent_before_rename
                            <= retired_fingerprint.ctime_ns
                            <= parent_after_rename
                        )
                    )
                ):
                    raise InvalidTask(
                        "The workspace retirement lacked an exact namespace witness."
                    )
                return (
                    temporary,
                    marker,
                    HashedRegularFile(retired_fingerprint, expected.sha256),
                )
            captured = self._hash_existing_at(parent, temporary)
            if captured is None:
                raise InvalidTask("The workspace file disappeared while being retired.")
            return temporary, marker, captured
        except BaseException:
            # Best effort restores the captured namespace entry. The durable
            # marker lets startup finish this recovery if the process dies.
            self._recover_retired_file_at(
                parent,
                marker,
                {
                    "temporary": temporary,
                    "target": name,
                    "owner_pid": os.getpid(),
                },
            )
            raise

    def _restore_retired_file_at(
        self,
        parent: int,
        name: str,
        retired: tuple[str, str, HashedRegularFile],
    ) -> str:
        temporary, marker, _captured = retired
        try:
            temp_info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
        except OSError as error:
            raise InvalidTask("The retired workspace file is unavailable.") from error
        if (
            not stat_module.S_ISREG(temp_info.st_mode)
            or temp_info.st_nlink not in (1, 2)
        ):
            raise InvalidTask("The retired workspace file identity is invalid.")
        conflict = _bounded_retire_conflict_name(
            name, temporary, name_max=self._name_max_at(parent)
        )
        restored: str | None = None
        for candidate in (name, conflict):
            try:
                candidate_info = os.stat(
                    candidate, dir_fd=parent, follow_symlinks=False
                )
            except FileNotFoundError:
                if temp_info.st_nlink == 2:
                    continue
                try:
                    os.link(
                        temporary,
                        candidate,
                        src_dir_fd=parent,
                        dst_dir_fd=parent,
                        follow_symlinks=False,
                    )
                except FileExistsError:
                    continue
                restored = candidate
                break
            except OSError as error:
                raise InvalidTask(
                    "The retired workspace survivor cannot be inspected."
                ) from error
            if (
                stat_module.S_ISREG(candidate_info.st_mode)
                and candidate_info.st_dev == temp_info.st_dev
                and candidate_info.st_ino == temp_info.st_ino
            ):
                restored = candidate
                break
        if restored is None:
            raise InvalidTask(
                "The deterministic retired-file survivor name is occupied."
            )
        linked = os.stat(restored, dir_fd=parent, follow_symlinks=False)
        if (
            not stat_module.S_ISREG(linked.st_mode)
            or linked.st_dev != temp_info.st_dev
            or linked.st_ino != temp_info.st_ino
            or linked.st_nlink != 2
        ):
            raise InvalidTask("The retired workspace survivor identity changed.")
        try:
            os.unlink(temporary, dir_fd=parent)
            os.unlink(marker, dir_fd=parent)
        except OSError as error:
            raise InvalidTask(
                "The retired workspace survivor could not be finalized."
            ) from error
        _fsync_directory_when_supported(parent)
        return restored

    @staticmethod
    def _name_max_at(parent: int) -> int:
        try:
            value = int(os.pathconf(parent, "PC_NAME_MAX"))
        except (OSError, ValueError):
            value = 255
        if value < 1:
            raise InvalidTask("The workspace filesystem has an invalid NAME_MAX.")
        return min(255, value)

    @_serialize_retired_quarantine
    def _reserve_retired_quarantine(
        self,
        incoming_bytes: int,
        *,
        retain_unchanged: bool = False,
        retention_reservation: str | None = None,
    ) -> bool:
        if not isinstance(retain_unchanged, bool):
            raise InvalidTask("retain_unchanged must be a boolean.")
        if (
            retention_reservation is not None
            and retention_reservation not in self._retained_retirement_reservations
        ):
            raise InvalidTask("The retained retirement reservation is invalid.")
        reserved_elsewhere = len(self._retained_retirement_reservations) - (
            1 if retention_reservation is not None else 0
        )
        with self._pending_fingerprint_removals_lock:
            pending_removals = len(self._pending_fingerprint_removals)
        self.maintain_retired_quarantine()
        items: list[tuple[_RetiredQuarantineRecord, int]] = []
        for record in list(self._retired_quarantine.values()):
            size, interrupted = self._inspect_quarantine_record(record)
            if interrupted:
                self._promote_quarantine_record(record)
            else:
                items.append((record, size))
        candidates = self._quarantine_promotion_candidates(
            items,
            now_ns=time.time_ns(),
            max_entries=self._retired_quarantine_max_entries,
            max_bytes=self._retired_quarantine_max_bytes,
            max_age_seconds=self._retired_quarantine_max_age_seconds,
            extra_entries=1 + reserved_elsewhere + pending_removals,
            # A retained inode is the same allocation that was already charged
            # to the working set; rename does not create a byte copy. Logical
            # length is especially misleading for sparse 10--50 GiB files, so
            # remote-cleanup retention is bounded by owner count only.
            extra_bytes=0 if retain_unchanged else incoming_bytes,
        )
        for record in candidates:
            if record.marker_path in self._retired_quarantine:
                self._promote_quarantine_record(record)
        current_items: list[tuple[_RetiredQuarantineRecord, int]] = []
        for record in list(self._retired_quarantine.values()):
            size, interrupted = self._inspect_quarantine_record(record)
            if interrupted:
                self._promote_quarantine_record(record)
            else:
                current_items.append((record, size))
        current_bytes = sum(
            size for record, size in current_items if not record.retain_unchanged
        )
        return (
            len(current_items) + 1 + reserved_elsewhere + pending_removals
            <= self._retired_quarantine_max_entries
        ) and (
            retain_unchanged
            or current_bytes + incoming_bytes <= self._retired_quarantine_max_bytes
        )

    @_serialize_retired_quarantine
    def _quarantine_retired_file_at(
        self,
        parent: int,
        name: str,
        retired: tuple[str, str, HashedRegularFile],
        original_path: str,
        current: HashedRegularFile,
        *,
        retain_unchanged: bool = False,
        retention_reservation: str | None = None,
        accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
    ) -> str | None:
        if not isinstance(retain_unchanged, bool):
            raise InvalidTask("retain_unchanged must be a boolean.")
        if accounting_owner not in _RETAINED_STORAGE_ACCOUNTS:
            raise InvalidTask("Invalid retained storage accounting owner.")
        temporary, marker, _initial = retired
        self._validate_retire_marker_at(
            parent, marker, temporary=temporary, target=name
        )
        info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
        fingerprint = _regular_fingerprint(
            info, "The retired source must remain a single-link regular file."
        )
        if (
            fingerprint.device_id != current.fingerprint.device_id
            or fingerprint.file_id != current.fingerprint.file_id
        ):
            raise InvalidTask("The retired workspace file changed identity.")
        if fingerprint != current.fingerprint:
            restored = self._restore_retired_file_at(parent, name, retired)
            prefix = "/".join(split_relative(original_path)[:-1])
            return f"{prefix}/{restored}" if prefix else restored
        reserved = self._reserve_retired_quarantine(
            fingerprint.size_bytes,
            retain_unchanged=retain_unchanged,
            retention_reservation=retention_reservation,
        )
        if not reserved:
            if not retain_unchanged:
                restored = self._restore_retired_file_at(parent, name, retired)
                prefix = "/".join(split_relative(original_path)[:-1])
                return f"{prefix}/{restored}" if prefix else restored
            raise RetentionCapacityUnavailable()
        conflict = _bounded_retire_conflict_name(
            name, temporary, name_max=self._name_max_at(parent)
        )
        quarantined_at_ns = time.time_ns()
        marker_data = _retired_quarantine_marker_bytes(
            temporary,
            name,
            conflict,
            current,
            quarantined_at_ns,
            retain_unchanged=retain_unchanged,
            accounting_owner=accounting_owner,
        )
        try:
            _replace_private_marker_at(parent, marker, marker_data)
        except BaseException:
            self._retired_quarantine_maintenance_error = True
            raise
        prefix = "/".join(split_relative(original_path)[:-1])
        relative_prefix = f"{prefix}/" if prefix else ""
        record = _RetiredQuarantineRecord(
            original_path=original_path,
            temporary_path=f"{relative_prefix}{temporary}",
            marker_path=f"{relative_prefix}{marker}",
            conflict_path=f"{relative_prefix}{conflict}",
            quarantined_at_ns=quarantined_at_ns,
            recorded_size_bytes=fingerprint.size_bytes,
            device_id=fingerprint.device_id,
            file_id=fingerprint.file_id,
            recorded_sha256=current.sha256,
            recorded_mtime_ns=fingerprint.mtime_ns,
            recorded_ctime_ns=fingerprint.ctime_ns,
            retain_unchanged=retain_unchanged,
            accounting_owner=accounting_owner,
        )
        self._retired_quarantine[record.marker_path] = record
        self._release_retained_retirement_slot(retention_reservation)
        promoted = self.maintain_retired_quarantine()
        return record.conflict_path if record.conflict_path in promoted else None

    def _finish_internal_retired_file_at(
        self,
        parent: int,
        name: str,
        retired: tuple[str, str, HashedRegularFile],
        original_path: str,
    ) -> str | None:
        temporary, _marker, initial = retired
        current = self._hash_existing_at(parent, temporary)
        if current is None:
            raise InvalidTask("The retired workspace file disappeared before commit.")
        if current != initial:
            restored = self._restore_retired_file_at(parent, name, retired)
            prefix = "/".join(split_relative(original_path)[:-1])
            return f"{prefix}/{restored}" if prefix else restored
        return self._quarantine_retired_file_at(
            parent, name, retired, original_path, current
        )

    def retire_file(
        self,
        path: str,
        *,
        require_retention_capacity: bool = False,
        expected_file: HashedRegularFile | None = None,
        accounting_owner: str = RETAINED_STORAGE_ACCOUNT_ADDITIONAL,
    ) -> RetiredRegularFile | None:
        """Atomically hide one regular file while retaining its inode durably."""

        if not isinstance(require_retention_capacity, bool):
            raise InvalidTask("require_retention_capacity must be a boolean.")
        if expected_file is not None and not isinstance(expected_file, HashedRegularFile):
            raise InvalidTask("expected_file must be a HashedRegularFile.")
        if accounting_owner not in _RETAINED_STORAGE_ACCOUNTS:
            raise InvalidTask("Invalid retained storage accounting owner.")
        retention_reservation = (
            self._reserve_retained_retirement_slot()
            if require_retention_capacity
            else None
        )
        if require_retention_capacity and retention_reservation is None:
            raise RetentionCapacityUnavailable()
        try:
            parts = split_relative(path)
            opened = self._open_parent_if_present(parts)
            if opened is None:
                return None
            parent, name = opened
            try:
                retired = self._retire_file_at(parent, name, expected=expected_file)
                if retired is None:
                    return None
                prefix = "/".join(parts[:-1])
                temporary_path = f"{prefix}/{retired[0]}" if prefix else retired[0]
                result = RetiredRegularFile(
                    original_path=path,
                    temporary_path=temporary_path,
                    marker_path=f"{temporary_path}{STREAM_TEMP_MARKER_SUFFIX}",
                    initial=retired[2],
                    retention_reservation=retention_reservation,
                    accounting_owner=accounting_owner,
                )
                retention_reservation = None
                return result
            finally:
                os.close(parent)
        finally:
            self._release_retained_retirement_slot(retention_reservation)

    def hash_retired_file(self, retired: RetiredRegularFile) -> HashedRegularFile:
        self._validate_retired_file(retired)
        original = split_relative(retired.original_path)
        temporary_parts = _split_owned_relative(retired.temporary_path)
        marker_parts = _split_owned_relative(retired.marker_path)
        opened = self._open_parent_if_present(
            temporary_parts
        )
        if opened is None:
            raise InvalidTask("The retired workspace file disappeared before commit.")
        parent, name = opened
        try:
            self._validate_retire_marker_at(
                parent,
                marker_parts[-1],
                temporary=name,
                target=original[-1],
            )
            try:
                descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except OSError as error:
                raise UnsafePath("The retired source cannot be opened safely.") from error
            try:
                captured = _hash_open_regular(descriptor, MAX_STREAM_FILE_BYTES)
                if self._path_fingerprint(parent, name) != captured.fingerprint:
                    raise InvalidTask("The retired workspace file changed while hashing.")
                return captured
            finally:
                os.close(descriptor)
        finally:
            os.close(parent)

    @staticmethod
    def _validate_retire_marker_at(
        parent: int,
        marker_name: str,
        *,
        temporary: str,
        target: str,
    ) -> None:
        try:
            descriptor = os.open(marker_name, _FILE_FLAGS, dir_fd=parent)
        except OSError as error:
            raise InvalidTask("The retired workspace owner marker is unavailable.") from error
        try:
            info = os.fstat(descriptor)
            data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
            if (
                not stat_module.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or stat_module.S_IMODE(info.st_mode) != 0o600
                or len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
            ):
                raise InvalidTask("The retired workspace owner marker is invalid.")
        finally:
            os.close(descriptor)
        marker = _parse_retire_temp_marker(marker_name, data)
        if (
            marker is None
            or marker.get("temporary") != temporary
            or marker.get("target") != target
        ):
            raise InvalidTask("The retired workspace owner marker is invalid.")

    def finish_retired_file(
        self,
        retired: RetiredRegularFile,
        *,
        preserve: bool = False,
        quarantine_unchanged: bool = True,
        tracked_handles_closed: bool = False,
        retain_unchanged: bool = False,
    ) -> str | None:
        """Finalize a retire, preserving an observed concurrent write visibly.

        ``quarantine_unchanged`` is reserved for callers that intentionally
        want a grace window for writes that arrive *after* this check. A direct
        last-link reclaim additionally requires ``tracked_handles_closed``;
        the caller must hold the mount's path admission fence while supplying
        it, so no new tracked open can invalidate the proof.
        """

        self._validate_retired_file(retired)
        if (
            not isinstance(preserve, bool)
            or not isinstance(quarantine_unchanged, bool)
            or not isinstance(tracked_handles_closed, bool)
            or not isinstance(retain_unchanged, bool)
        ):
            raise InvalidTask("retire finalization flags must be booleans.")
        if retain_unchanged and (preserve or not quarantine_unchanged):
            raise InvalidTask(
                "retain_unchanged requires non-preserving quarantine finalization."
            )
        if (
            not preserve
            and not quarantine_unchanged
            and not tracked_handles_closed
        ):
            raise UnsafePath(
                "Last-link retirement requires a tracked-handle cleanup fence."
            )
        # Catalog lookup and promotion are one atomic transition, but hashing a
        # retired file can stream up to 1 TiB and must not stall unrelated
        # quarantine maintenance in this workspace.
        with self._retired_quarantine_lock:
            existing = self._retired_quarantine.get(retired.marker_path)
            if existing is None:
                existing = self._load_retired_quarantine_record(retired)
            if existing is not None:
                if preserve:
                    result = self._promote_quarantine_record(existing)
                    self._release_retained_retirement_slot(
                        retired.retention_reservation
                    )
                    return result
                promoted = self.maintain_retired_quarantine()
                result = (
                    existing.conflict_path
                    if existing.conflict_path in promoted
                    else None
                )
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return result
        if preserve:
            # Preservation is already the caller's chosen disposition. Linking
            # the exact retired inode back into a visible name is O(1); hashing
            # 10--50 GiB merely to make the same decision would duplicate the
            # source-backed upload lane's later read without adding authority.
            parts = split_relative(retired.original_path)
            parent, name = self._open_parent(parts)
            try:
                temporary = _split_owned_relative(retired.temporary_path)[-1]
                marker = _split_owned_relative(retired.marker_path)[-1]
                restored = self._restore_retired_file_at(
                    parent, name, (temporary, marker, retired.initial)
                )
                prefix = "/".join(parts[:-1])
                result = f"{prefix}/{restored}" if prefix else restored
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return result
            finally:
                os.close(parent)
        # A headless/untracked remote cleanup cannot prove that an external
        # descriptor has closed. If the exact captured fingerprint still owns
        # the private name, convert its marker to durable retained evidence in
        # O(1). A later ctime/mtime/size drift is promoted by the five-second
        # quarantine lane; no second 10--50 GiB hash is paid merely to hide a
        # clean cache preimage.
        current: HashedRegularFile
        if retain_unchanged:
            temporary_parts = _split_owned_relative(retired.temporary_path)
            opened = self._open_parent_if_present(temporary_parts)
            if opened is None:
                raise InvalidTask(
                    "The retired workspace file disappeared before commit."
                )
            internal_parent, internal_name = opened
            try:
                current_fingerprint = self._path_fingerprint(
                    internal_parent, internal_name
                )
            finally:
                os.close(internal_parent)
            if current_fingerprint != retired.initial.fingerprint:
                # Fingerprint drift already denies cleanup. Restore this exact
                # inode visibly in O(1); hashing 10--50 GiB cannot change the
                # preserve decision and the source-backed upload lane will own
                # the one required content pass after durable handoff.
                parts = split_relative(retired.original_path)
                parent, name = self._open_parent(parts)
                try:
                    temporary = _split_owned_relative(
                        retired.temporary_path
                    )[-1]
                    marker = _split_owned_relative(retired.marker_path)[-1]
                    restored = self._restore_retired_file_at(
                        parent, name, (temporary, marker, retired.initial)
                    )
                    prefix = "/".join(parts[:-1])
                    result = f"{prefix}/{restored}" if prefix else restored
                    self._release_retained_retirement_slot(
                        retired.retention_reservation
                    )
                    return result
                finally:
                    os.close(parent)
            current = retired.initial
        else:
            current = self.hash_retired_file(retired)
        if current != retired.initial:
            preserve = True
        parts = split_relative(retired.original_path)
        parent, name = self._open_parent(parts)
        try:
            temporary = _split_owned_relative(retired.temporary_path)[-1]
            marker = _split_owned_relative(retired.marker_path)[-1]
            internal = (temporary, marker, retired.initial)
            if preserve:
                restored = self._restore_retired_file_at(parent, name, internal)
                prefix = "/".join(parts[:-1])
                result = f"{prefix}/{restored}" if prefix else restored
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return result
            if not quarantine_unchanged:
                self._validate_retire_marker_at(
                    parent, marker, temporary=temporary, target=name
                )
                os.unlink(temporary, dir_fd=parent)
                os.unlink(marker, dir_fd=parent)
                _fsync_directory_when_supported(parent)
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return None
            return self._quarantine_retired_file_at(
                parent,
                name,
                internal,
                retired.original_path,
                current,
                retain_unchanged=retain_unchanged,
                retention_reservation=retired.retention_reservation,
                accounting_owner=retired.accounting_owner,
            )
        finally:
            os.close(parent)

    def finish_retired_file_by_fingerprint(
        self,
        retired: RetiredRegularFile,
        *,
        tracked_handles_closed: bool,
    ) -> bool:
        """Reclaim an unchanged retire in O(1) under a mount admission fence.

        The caller must hold the mount backend's open/create exclusion for this
        exact path. The full post-retire stat fingerprint is checked immediately
        before last-link unlink; a drift returns ``False`` without touching the
        evidence so the caller can release the fence and preserve/hash it.
        """

        self._validate_retired_file(retired)
        if tracked_handles_closed is not True:
            raise UnsafePath(
                "Fingerprint retirement requires a tracked-handle cleanup fence."
            )
        temporary_parts = _split_owned_relative(retired.temporary_path)
        marker_parts = _split_owned_relative(retired.marker_path)
        original_parts = split_relative(retired.original_path)
        opened = self._open_parent_if_present(temporary_parts)
        if opened is None:
            raise InvalidTask("The retired workspace file disappeared before commit.")
        parent, temporary = opened
        marker = marker_parts[-1]
        try:
            with self._retired_quarantine_lock:
                existing = self._retired_quarantine.get(retired.marker_path)
                if existing is None:
                    existing = self._load_retired_quarantine_record(retired)
                if existing is not None:
                    if not existing.retain_unchanged:
                        return False
                    self._validate_quarantine_marker_at(parent, marker, existing)
                    expected = FileFingerprint(
                        size_bytes=existing.recorded_size_bytes,
                        mtime_ns=(
                            existing.recorded_mtime_ns
                            if existing.recorded_mtime_ns is not None
                            else -1
                        ),
                        ctime_ns=(
                            existing.recorded_ctime_ns
                            if existing.recorded_ctime_ns is not None
                            else -1
                        ),
                        device_id=existing.device_id,
                        file_id=existing.file_id,
                    )
                else:
                    self._validate_retire_marker_at(
                        parent,
                        marker,
                        temporary=temporary,
                        target=original_parts[-1],
                    )
                    expected = retired.initial.fingerprint
                try:
                    info = os.stat(temporary, dir_fd=parent, follow_symlinks=False)
                except OSError as error:
                    raise InvalidTask(
                        "The retired workspace file disappeared before commit."
                    ) from error
                if (
                    not stat_module.S_ISREG(info.st_mode)
                    or info.st_nlink != 1
                    or _fingerprint_from_stat(info) != expected
                ):
                    return False
                try:
                    os.unlink(temporary, dir_fd=parent)
                except OSError as error:
                    raise InvalidTask(
                        "The retired workspace file could not be finalized."
                    ) from error
                # Make the data unlink durable before retiring its metadata.
                # From this boundary onward physical reclaim succeeded; a
                # marker-only remnant is cleanup work, never surviving bytes.
                _fsync_directory_when_supported(parent)
                try:
                    os.unlink(marker, dir_fd=parent)
                    _fsync_directory_when_supported(parent)
                except OSError:
                    # Retry authenticated marker-only cleanup in this process;
                    # do not fail the already-completed physical reclaim.
                    self._stream_recovery_scan = None
                    self._stream_recovery_retry_required = True
                    self.stream_recovery_pending = True
                if existing is not None:
                    self._retired_quarantine.pop(existing.marker_path, None)
                    self._retired_quarantine_visible_promotions = [
                        item
                        for item in self._retired_quarantine_visible_promotions
                        if item.marker_path != existing.marker_path
                    ]
                self._release_retained_retirement_slot(
                    retired.retention_reservation
                )
                return True
        finally:
            os.close(parent)

    def _load_retired_quarantine_record(
        self, retired: RetiredRegularFile
    ) -> _RetiredQuarantineRecord | None:
        marker_parts = _split_owned_relative(retired.marker_path)
        opened = self._open_parent_if_present(marker_parts)
        if opened is None:
            return None
        parent, marker_name = opened
        try:
            name_max = self._name_max_at(parent)
            try:
                descriptor = os.open(marker_name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                return None
            try:
                data = os.read(descriptor, _STREAM_TEMP_MARKER_MAX_BYTES + 1)
                info = os.fstat(descriptor)
                if (
                    len(data) > _STREAM_TEMP_MARKER_MAX_BYTES
                    or not stat_module.S_ISREG(info.st_mode)
                    or info.st_nlink != 1
                    or stat_module.S_IMODE(info.st_mode) != 0o600
                ):
                    return None
            finally:
                os.close(descriptor)
        finally:
            os.close(parent)
        marker = _parse_retired_quarantine_marker(marker_name, data)
        if marker is None:
            return None
        if str(marker["conflict"]) != _bounded_retire_conflict_name(
            str(marker["target"]), str(marker["temporary"]), name_max=name_max
        ):
            raise InvalidTask("The retired-inode quarantine marker is invalid.")
        prefix = "/".join(split_relative(retired.original_path)[:-1])
        relative_prefix = f"{prefix}/" if prefix else ""
        record = _RetiredQuarantineRecord(
            original_path=retired.original_path,
            temporary_path=f"{relative_prefix}{marker['temporary']}",
            marker_path=retired.marker_path,
            conflict_path=f"{relative_prefix}{marker['conflict']}",
            quarantined_at_ns=int(marker["quarantined_at_ns"]),
            recorded_size_bytes=int(marker["recorded_size_bytes"]),
            device_id=int(marker["device_id"]),
            file_id=int(marker["file_id"]),
            recorded_sha256=marker["recorded_sha256"],
            recorded_mtime_ns=marker["recorded_mtime_ns"],
            recorded_ctime_ns=marker["recorded_ctime_ns"],
            retain_unchanged=bool(marker["retain_unchanged"]),
            accounting_owner=str(marker["accounting_owner"]),
        )
        if (
            record.temporary_path != retired.temporary_path
            or record.accounting_owner != retired.accounting_owner
        ):
            raise InvalidTask("The retired-inode quarantine marker is invalid.")
        self._retired_quarantine[record.marker_path] = record
        return record

    @staticmethod
    def _validate_retired_file(retired: RetiredRegularFile) -> None:
        if not isinstance(retired, RetiredRegularFile):
            raise InvalidTask("retired must be a RetiredRegularFile.")
        if retired.accounting_owner not in _RETAINED_STORAGE_ACCOUNTS:
            raise InvalidTask("Invalid retained storage accounting owner.")
        original = split_relative(retired.original_path)
        temporary = _split_owned_relative(retired.temporary_path)
        marker = _split_owned_relative(retired.marker_path)
        if (
            temporary[:-1] != original[:-1]
            or marker[:-1] != original[:-1]
            or not (
                _owned_temporary_kind(temporary[-1]) == "retire"
                or _legacy_owned_temporary_for_target(
                    temporary[-1], original[-1]
                )
            )
            or marker[-1] != temporary[-1] + STREAM_TEMP_MARKER_SUFFIX
        ):
            raise InvalidTask("The retired workspace token is invalid.")

    def rename_file(
        self,
        source: str,
        destination: str,
        *,
        expected_sha256: str,
        create_parents: bool = False,
    ) -> None:
        """Rename a regular file without copying or overwriting another item.

        The digest is checked before work and again immediately before the
        namespace mutation. It is an optimistic local guard; durable remote
        generation CAS remains the authoritative conflict boundary.
        """
        if not isinstance(expected_sha256, str) or not TAGGED_SHA256_RE.fullmatch(
            expected_sha256
        ):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        source_parts = split_relative(source)
        destination_parts = split_relative(destination)
        source_parent_opened = self._open_parent_if_present(source_parts)
        if source_parent_opened is None:
            raise InvalidTask("The rename source does not exist.")
        source_parent, source_name = source_parent_opened
        destination_parent = -1
        try:
            preflight = self._hash_existing_at(source_parent, source_name)
            if preflight is None:
                raise InvalidTask("The rename source does not exist.")
            if preflight.tagged_sha256 != expected_sha256:
                raise InvalidTask("The rename source digest does not match expected_sha256.")
            if source_parts == destination_parts:
                return
            destination_parent, destination_name = self._open_parent(
                destination_parts, create=create_parents
            )
            destination_fingerprint = self._path_fingerprint(
                destination_parent, destination_name
            )
            same_file = destination_fingerprint == preflight.fingerprint
            same_parent = source_parts[:-1] == destination_parts[:-1]
            if destination_fingerprint is not None and not (same_file and same_parent):
                raise UnsafePath("The rename destination already exists.")

            current = self._hash_existing_at(source_parent, source_name)
            if current is None or current.tagged_sha256 != expected_sha256:
                raise InvalidTask("The rename source changed before commit.")
            if same_file:
                temporary = _owned_temporary_name("rename")
                moved = False
                try:
                    os.rename(
                        source_name,
                        temporary,
                        src_dir_fd=source_parent,
                        dst_dir_fd=source_parent,
                    )
                    moved = True
                    os.rename(
                        temporary,
                        destination_name,
                        src_dir_fd=source_parent,
                        dst_dir_fd=destination_parent,
                    )
                    moved = False
                finally:
                    if moved:
                        try:
                            os.rename(
                                temporary,
                                source_name,
                                src_dir_fd=source_parent,
                                dst_dir_fd=source_parent,
                            )
                        except OSError:
                            pass
            else:
                linked = False
                try:
                    os.link(
                        source_name,
                        destination_name,
                        src_dir_fd=source_parent,
                        dst_dir_fd=destination_parent,
                        follow_symlinks=False,
                    )
                    linked = True
                    os.unlink(source_name, dir_fd=source_parent)
                    linked = False
                finally:
                    if linked:
                        try:
                            os.unlink(destination_name, dir_fd=destination_parent)
                        except OSError:
                            pass
            _fsync_directory_when_supported(destination_parent)
            if source_parent != destination_parent:
                _fsync_directory_when_supported(source_parent)
        finally:
            if destination_parent >= 0:
                os.close(destination_parent)
            os.close(source_parent)

    def rename_file_by_fingerprint(
        self,
        source: str,
        destination: str,
        *,
        expected_fingerprint: FileFingerprint,
        expected_destination_fingerprint: FileFingerprint | None = None,
        expected_destination_sha256: str | None = None,
        create_parents: bool = False,
    ) -> FileFingerprint:
        """Rename an exact local inode without hashing its potentially huge bytes.

        This is the mounted-filesystem counterpart to :meth:`rename_file`.
        The caller already owns a remote content digest for generation CAS; the
        local namespace operation only needs to prove that the complete stat
        identity it observed is still the inode being moved.  Rename preserves
        rather than discards bytes, so an open writer remains attached to the
        same visible inode at the destination.
        """

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        if expected_destination_fingerprint is not None and not isinstance(
            expected_destination_fingerprint, FileFingerprint
        ):
            raise InvalidTask(
                "expected_destination_fingerprint must be a FileFingerprint or null."
            )
        if (expected_destination_fingerprint is None) != (
            expected_destination_sha256 is None
        ) or (
            expected_destination_sha256 is not None
            and TAGGED_SHA256_RE.fullmatch(expected_destination_sha256) is None
        ):
            raise InvalidTask(
                "A destination fingerprint requires its tagged SHA-256 digest."
            )
        source_parts = split_relative(source)
        destination_parts = split_relative(destination)
        source_opened = self._open_parent_if_present(source_parts)
        if source_opened is None:
            raise InvalidTask("The rename source does not exist.")
        source_parent, source_name = source_opened
        destination_parent = -1
        source_descriptor = -1
        destination_descriptor = -1
        source_retired: tuple[str, str, FileFingerprint] | None = None
        destination_retired: tuple[str, str, HashedRegularFile] | None = None
        destination_retired_active = False
        published = False
        try:
            try:
                source_descriptor = os.open(
                    source_name, _FILE_FLAGS, dir_fd=source_parent
                )
            except OSError as error:
                raise UnsafePath("The rename source cannot be opened safely.") from error
            before = _regular_fingerprint(
                os.fstat(source_descriptor),
                "The rename source must remain a single-link regular file.",
            )
            if (
                before != expected_fingerprint
                or self._path_fingerprint(source_parent, source_name) != before
            ):
                raise InvalidTask("The rename source changed before commit.")
            if source_parts == destination_parts:
                return before
            destination_parent, destination_name = self._open_parent(
                destination_parts, create=create_parents
            )
            current_destination = self._path_fingerprint(
                destination_parent, destination_name
            )
            if current_destination != expected_destination_fingerprint:
                raise UnsafePath("The rename destination changed before commit.")

            if expected_destination_fingerprint is not None:
                try:
                    destination_descriptor = os.open(
                        destination_name, _FILE_FLAGS, dir_fd=destination_parent
                    )
                except OSError as error:
                    raise UnsafePath(
                        "The rename destination cannot be opened safely."
                    ) from error
                opened_destination = _regular_fingerprint(
                    os.fstat(destination_descriptor),
                    "The rename destination must remain a single-link regular file.",
                )
                if (
                    opened_destination != expected_destination_fingerprint
                    or self._path_fingerprint(
                        destination_parent, destination_name
                    )
                    != opened_destination
                ):
                    raise UnsafePath("The rename destination changed before commit.")
                retired_name = _owned_temporary_name("retire")
                retired_marker = retired_name + STREAM_TEMP_MARKER_SUFFIX
                assert expected_destination_sha256 is not None
                destination_retired = (
                    retired_name,
                    retired_marker,
                    HashedRegularFile(
                        expected_destination_fingerprint,
                        expected_destination_sha256.removeprefix("sha256:"),
                    ),
                )
                _write_private_marker_at(
                    destination_parent,
                    retired_marker,
                    _retire_temp_marker_bytes(retired_name, destination_name),
                )
                destination_retired_active = True
                os.rename(
                    destination_name,
                    retired_name,
                    src_dir_fd=destination_parent,
                    dst_dir_fd=destination_parent,
                )
                _fsync_directory_when_supported(destination_parent)
                retired_fingerprint = _regular_fingerprint(
                    os.fstat(destination_descriptor),
                    "The retired rename destination must remain a regular file.",
                )
                if (
                    not _same_regular_state_after_rename(
                        expected_destination_fingerprint, retired_fingerprint
                    )
                    or self._path_fingerprint(destination_parent, retired_name)
                    != retired_fingerprint
                ):
                    recovered = self._recover_retired_file_at(
                        destination_parent,
                        retired_marker,
                        {
                            "temporary": retired_name,
                            "target": destination_name,
                            "owner_pid": os.getpid(),
                        },
                    )
                    destination_retired_active = not recovered
                    raise UnsafePath(
                        "The rename destination changed immediately before commit."
                    )
                destination_retired = (
                    retired_name,
                    retired_marker,
                    HashedRegularFile(
                        retired_fingerprint,
                        expected_destination_sha256.removeprefix("sha256:"),
                    ),
                )

            source_retired_name = _owned_temporary_name("retire")
            source_retired_marker = (
                source_retired_name + STREAM_TEMP_MARKER_SUFFIX
            )
            _write_private_marker_at(
                source_parent,
                source_retired_marker,
                _retire_temp_marker_bytes(source_retired_name, source_name),
            )
            source_retired = (
                source_retired_name,
                source_retired_marker,
                before,
            )
            os.rename(
                source_name,
                source_retired_name,
                src_dir_fd=source_parent,
                dst_dir_fd=source_parent,
            )
            source_after_retire = _regular_fingerprint(
                os.fstat(source_descriptor),
                "The retired rename source must remain a regular file.",
            )
            source_retired = (
                source_retired_name,
                source_retired_marker,
                source_after_retire,
            )
            if (
                not _same_regular_state_after_rename(before, source_after_retire)
                or self._path_fingerprint(source_parent, source_retired_name)
                != source_after_retire
            ):
                raise InvalidTask("The rename source changed immediately before commit.")

            linked = False
            try:
                os.link(
                    source_retired_name,
                    destination_name,
                    src_dir_fd=source_parent,
                    dst_dir_fd=destination_parent,
                    follow_symlinks=False,
                )
                linked = True
                linked_info = os.stat(
                    destination_name,
                    dir_fd=destination_parent,
                    follow_symlinks=False,
                )
                if (
                    not stat_module.S_ISREG(linked_info.st_mode)
                    or linked_info.st_nlink != 2
                    or not _same_regular_state_after_rename(
                        source_after_retire, _fingerprint_from_stat(linked_info)
                    )
                ):
                    raise InvalidTask("The rename source changed during publication.")
                os.unlink(source_retired_name, dir_fd=source_parent)
                linked = False
            except BaseException:
                if linked:
                    try:
                        linked_info = os.stat(
                            destination_name,
                            dir_fd=destination_parent,
                            follow_symlinks=False,
                        )
                        if (
                            stat_module.S_ISREG(linked_info.st_mode)
                            and (linked_info.st_dev, linked_info.st_ino)
                            == (
                                source_after_retire.device_id,
                                source_after_retire.file_id,
                            )
                        ):
                            os.unlink(destination_name, dir_fd=destination_parent)
                    except OSError:
                        pass
                raise
            published = True
            try:
                os.unlink(source_retired_marker, dir_fd=source_parent)
                source_retired = None
            except OSError:
                # Startup recovery removes a marker whose temporary is gone.
                pass
            _fsync_directory_when_supported(destination_parent)
            if source_parent != destination_parent:
                _fsync_directory_when_supported(source_parent)
            after = self._path_fingerprint(destination_parent, destination_name)
            if after is None or not _same_regular_state_after_rename(
                source_after_retire, after
            ):
                raise InvalidTask("The workspace file changed during rename.")

            if destination_retired is not None:
                current_retired_fingerprint = self._path_fingerprint(
                    destination_parent, destination_retired[0]
                )
                if current_retired_fingerprint is None:
                    raise InvalidTask(
                        "The retired rename destination disappeared before commit."
                    )
                if current_retired_fingerprint != destination_retired[2].fingerprint:
                    self._restore_retired_file_at(
                        destination_parent,
                        destination_name,
                        destination_retired,
                    )
                else:
                    self._quarantine_retired_file_at(
                        destination_parent,
                        destination_name,
                        destination_retired,
                        destination,
                        HashedRegularFile(
                            current_retired_fingerprint,
                            destination_retired[2].sha256,
                        ),
                    )
                destination_retired_active = False
            return after
        finally:
            if source_retired is not None:
                recovered = self._recover_retired_file_at(
                    source_parent,
                    source_retired[1],
                    {
                        "temporary": source_retired[0],
                        "target": source_name,
                        "owner_pid": os.getpid(),
                    },
                )
                if published and not recovered:
                    self._stream_recovery_retry_required = True
            if destination_retired_active and destination_retired is not None:
                recovered = self._recover_retired_file_at(
                    destination_parent,
                    destination_retired[1],
                    {
                        "temporary": destination_retired[0],
                        "target": destination_name,
                        "owner_pid": os.getpid(),
                    },
                )
                if not recovered:
                    self._stream_recovery_retry_required = True
            if source_descriptor >= 0:
                os.close(source_descriptor)
            if destination_descriptor >= 0:
                os.close(destination_descriptor)
            if destination_parent >= 0:
                os.close(destination_parent)
            os.close(source_parent)

    def remove_file(
        self,
        path: str,
        *,
        expected_sha256: str | None = None,
        expected_fingerprint: FileFingerprint | None = None,
    ) -> bool:
        """Remove one file, optionally guarded by its exact digest and identity.

        The guard is an optimistic local compare-and-swap used by cache
        eviction and remote tombstones.  Both content and the full stat
        fingerprint are checked immediately before unlink, so an editor's
        replacement or in-place update aborts instead of being discarded.
        Durable remote generation CAS remains the cross-node authority.
        """

        if (expected_sha256 is None) != (expected_fingerprint is None):
            raise InvalidTask(
                "expected_sha256 and expected_fingerprint must be supplied together."
            )
        if expected_sha256 is not None and not TAGGED_SHA256_RE.fullmatch(
            expected_sha256
        ):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        if expected_fingerprint is not None and not isinstance(
            expected_fingerprint, FileFingerprint
        ):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        parent, name = self._open_parent(split_relative(path))
        try:
            if expected_sha256 is not None:
                retired = self._retire_file_at(parent, name)
                if retired is None:
                    return False
                if (
                    retired[2].tagged_sha256 != expected_sha256
                    or retired[2].fingerprint.device_id
                    != expected_fingerprint.device_id
                    or retired[2].fingerprint.file_id != expected_fingerprint.file_id
                ):
                    self._restore_retired_file_at(parent, name, retired)
                    raise InvalidTask("The workspace file changed before removal.")
                self._finish_internal_retired_file_at(
                    parent, name, retired, path
                )
                return True
            try:
                os.unlink(name, dir_fd=parent)
            except FileNotFoundError:
                return False
            except OSError as error:
                raise UnsafePath("The workspace file could not be removed safely.") from error
            os.fsync(parent)
            return True
        finally:
            os.close(parent)

    def remove_file_by_fingerprint(
        self,
        path: str,
        *,
        expected_fingerprint: FileFingerprint,
        tracked_handles_closed: bool = False,
    ) -> bool:
        """Retire one exact inode, reclaiming only after tracked handles close.

        The visible name is renamed to a private crash-recoverable sibling
        before its identity is accepted.  This closes the check-then-unlink
        race where a writer could replace ``path`` after validation and have
        its replacement unlinked.  A raced replacement is restored without
        overwriting a newer winner; when the original name is occupied it is
        preserved at the deterministic retired-file conflict name instead.

        Without ``tracked_handles_closed`` the visible name is hidden behind a
        bounded durable marker, but its last link is deliberately retained.
        The mount/session layer supplies the flag only after every Meshia-owned
        file description has closed. This makes the final unlink's quiet
        assumption explicit instead of pretending a stat/unlink pair is atomic.
        """

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        if not isinstance(tracked_handles_closed, bool):
            raise InvalidTask("tracked_handles_closed must be a boolean.")
        parts = split_relative(path)
        normalized_path = "/".join(parts)
        opened = self._open_parent_if_present(parts)
        if opened is None:
            if self.has_pending_fingerprint_removal(
                normalized_path, expected_fingerprint=expected_fingerprint
            ):
                raise UnsafePath(
                    "The pending fingerprint removal parent is unavailable."
                )
            return False
        parent, name = opened
        descriptor = -1
        change_watch = -1
        pending: _PendingFingerprintRemoval | None = None
        retired_active = False

        def marker_document(record: _PendingFingerprintRemoval) -> dict[str, object]:
            expected = record.expected_fingerprint
            return {
                "expected_ctime_ns": expected.ctime_ns,
                "expected_device_id": expected.device_id,
                "expected_file_id": expected.file_id,
                "expected_mtime_ns": expected.mtime_ns,
                "expected_size_bytes": expected.size_bytes,
                "retired_ctime_ns": record.retired_ctime_ns,
                "temporary": _split_owned_relative(record.temporary_path)[-1],
                "target": name,
            }

        def finish_pending(record: _PendingFingerprintRemoval) -> str:
            outcome = self._recover_fingerprint_removal_at(
                parent,
                _split_owned_relative(record.marker_path)[-1],
                marker_document(record),
                allow_last_unlink=True,
            )
            if outcome in {"removed", "restored"}:
                self._forget_pending_fingerprint_removal(record.marker_path)
            return outcome

        try:
            resumed = self._matching_pending_fingerprint_removals(
                normalized_path, expected_fingerprint
            )
            if resumed:
                if not tracked_handles_closed:
                    # The exact hidden inode remains durable and bounded until
                    # the owner can prove its tracked descriptions are closed.
                    return True
                outcomes = tuple(finish_pending(item) for item in resumed)
                if any(outcome == "restored" for outcome in outcomes):
                    raise InvalidTask("The file changed before removal.")
                if any(outcome not in {"removed", "restored"} for outcome in outcomes):
                    raise UnsafePath(
                        "The pending fingerprint removal could not be finalized safely."
                    )
                return True

            try:
                descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                return False
            except OSError as error:
                raise UnsafePath("The file cannot be opened safely.") from error
            opened_fingerprint = _regular_fingerprint(
                os.fstat(descriptor),
                "The file must remain a single-link regular file.",
            )
            if (
                opened_fingerprint != expected_fingerprint
                or self._path_fingerprint(parent, name) != opened_fingerprint
            ):
                raise InvalidTask("The file changed before removal.")
            change_watch = _open_linux_file_change_watch(descriptor)
            if (
                not tracked_handles_closed
                and not self._fingerprint_removal_retention_available(
                    opened_fingerprint.size_bytes
                )
            ):
                raise UnsafePath(
                    "The bounded remote-cleanup retention budget is full."
                )

            temporary = _owned_temporary_name("retire")
            marker = temporary + STREAM_TEMP_MARKER_SUFFIX
            _write_private_marker_at(
                parent,
                marker,
                _fingerprint_remove_temp_marker_bytes(
                    temporary, name, expected_fingerprint
                ),
            )
            prefix = "/".join(parts[:-1])
            relative_prefix = f"{prefix}/" if prefix else ""
            pending = _PendingFingerprintRemoval(
                original_path=normalized_path,
                temporary_path=f"{relative_prefix}{temporary}",
                marker_path=f"{relative_prefix}{marker}",
                expected_fingerprint=expected_fingerprint,
            )
            self._remember_pending_fingerprint_removal(pending)
            retired_active = True
            parent_before_rename = _directory_namespace_time_ns(os.fstat(parent))
            try:
                os.rename(
                    name,
                    temporary,
                    src_dir_fd=parent,
                    dst_dir_fd=parent,
                )
            except FileNotFoundError:
                outcome = finish_pending(pending)
                retired_active = outcome not in {"removed", "restored"}
                if retired_active:
                    raise UnsafePath(
                        "The missing file's retirement marker could not be recovered."
                    )
                return False
            except OSError as error:
                outcome = finish_pending(pending)
                retired_active = outcome not in {"removed", "restored"}
                raise UnsafePath("The file could not be retired safely.") from error
            parent_after_rename = _directory_namespace_time_ns(os.fstat(parent))
            _fsync_directory_when_supported(parent)

            retired_fingerprint = self._path_fingerprint(parent, temporary)
            if (
                retired_fingerprint is None
                or not _same_regular_state_after_rename(
                    expected_fingerprint, retired_fingerprint
                )
                # Treat the new ctime as rename-only only when the parent
                # directory gives a strictly advancing namespace witness and
                # the inode ctime falls within its exact pre/post interval.
                # A later writer advances the inode beyond that witness;
                # coarse filesystems fail closed instead of adopting an
                # ambiguous delete baseline.
                or parent_after_rename <= parent_before_rename
                or not (
                    parent_before_rename
                    < retired_fingerprint.ctime_ns
                    <= parent_after_rename
                )
                or _linux_file_change_watch_detected(change_watch)
            ):
                outcome = finish_pending(pending)
                retired_active = outcome not in {"removed", "restored"}
                raise InvalidTask("The file changed before removal.")

            # The rename itself may advance ctime. Persist that exact
            # post-rename value before permitting deletion so recovery can
            # distinguish it from a same-size open-writer update whose mtime
            # was restored. A crash before this replacement is conservative:
            # the incomplete marker restores the inode instead of deleting it.
            stabilized_pending = replace(
                pending, retired_ctime_ns=retired_fingerprint.ctime_ns
            )
            _replace_private_marker_at(
                parent,
                marker,
                _fingerprint_remove_temp_marker_bytes(
                    temporary,
                    name,
                    expected_fingerprint,
                    retired_ctime_ns=retired_fingerprint.ctime_ns,
                ),
            )
            pending = stabilized_pending
            self._remember_pending_fingerprint_removal(pending)

            if not tracked_handles_closed:
                # Keep one private durable link. A later call after the mount
                # session closes (or startup after the prior mount process
                # ended) can perform guarded reclamation without losing bytes.
                retired_active = False
                return True

            # Recheck the hidden name immediately before unlink. An existing
            # writer may still hold the retired inode and mutate it after the
            # namespace rename; that update must be restored, not discarded.
            if (
                self._path_fingerprint(parent, temporary) != retired_fingerprint
                or _linux_file_change_watch_detected(change_watch)
            ):
                outcome = finish_pending(pending)
                retired_active = outcome not in {"removed", "restored"}
                raise InvalidTask("The file changed before removal.")
            outcome = finish_pending(pending)
            retired_active = outcome not in {"removed", "restored"}
            if outcome == "removed":
                return True
            if outcome == "restored":
                raise InvalidTask("The file changed before removal.")
            raise UnsafePath("The retired file could not be removed safely.")
        finally:
            if retired_active and pending is not None:
                outcome = finish_pending(pending)
                retired_active = outcome not in {"removed", "restored"}
            if change_watch >= 0:
                os.close(change_watch)
            if descriptor >= 0:
                os.close(descriptor)
            os.close(parent)

    def native_unlink_file_by_fingerprint(
        self, path: str, *, expected_fingerprint: FileFingerprint
    ) -> bool:
        """Apply explicit user unlink with native anonymous-handle semantics."""

        if not isinstance(expected_fingerprint, FileFingerprint):
            raise InvalidTask("expected_fingerprint must be a FileFingerprint.")
        opened = self._open_parent_if_present(split_relative(path))
        if opened is None:
            return False
        parent, name = opened
        descriptor = -1
        try:
            try:
                descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
            except FileNotFoundError:
                return False
            except OSError as error:
                raise UnsafePath("The file cannot be opened safely.") from error
            current = _regular_fingerprint(
                os.fstat(descriptor),
                "The file must remain a single-link regular file.",
            )
            if (
                current != expected_fingerprint
                or self._path_fingerprint(parent, name) != current
            ):
                raise InvalidTask("The file changed before removal.")
            try:
                os.unlink(name, dir_fd=parent)
            except FileNotFoundError:
                return False
            except OSError as error:
                raise UnsafePath("The workspace file could not be removed safely.") from error
            _fsync_directory_when_supported(parent)
            return True
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            os.close(parent)

    def remove_tree(self, path: str) -> None:
        """Remove a workspace subtree (used for internal scratch directories)."""
        parts = split_relative(path)
        try:
            descriptor = self._open_directory(parts)
        except UnsafePath:
            return
        children: list[tuple[str, bool]] = []
        try:
            for name in os.listdir(descriptor):
                try:
                    info = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
                except OSError:
                    continue
                children.append((name, stat_module.S_ISDIR(info.st_mode)))
        finally:
            os.close(descriptor)
        for name, is_directory in children:
            child = f"{'/'.join(parts)}/{name}"
            self.remove_tree(child) if is_directory else self.remove_file(child)
        parent, name = self._open_parent(parts)
        try:
            try:
                os.rmdir(name, dir_fd=parent)
            except OSError:
                pass
        finally:
            os.close(parent)

    def make_directory(self, path: str) -> None:
        parts = split_relative(path)
        parent, name = self._open_parent(parts, create=True)
        try:
            try:
                os.mkdir(name, 0o700, dir_fd=parent)
            except FileExistsError:
                pass
        finally:
            os.close(parent)

    def absolute(self, path: str, allow_root: bool = False) -> Path:
        """Absolute path for a *validated* workspace-relative path."""
        parts = split_relative(path, allow_root=allow_root)
        self._canonical_check(parts)
        return Path(os.path.join(str(self.root), *parts))

    @staticmethod
    def _existing_regular_file(parent: int, name: str) -> bytes | None:
        try:
            descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
        except FileNotFoundError:
            return None
        except OSError as error:
            raise UnsafePath("The destination cannot be inspected safely.") from error
        try:
            info = os.fstat(descriptor)
            if not stat_module.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise UnsafePath("The destination must be a single-link regular file.")
            chunks: list[bytes] = []
            while True:
                chunk = os.read(descriptor, 262_144)
                if not chunk:
                    break
                chunks.append(chunk)
                if sum(len(part) for part in chunks) > MAX_WRITE_BYTES:
                    raise InvalidTask("The destination exceeds the 8 MiB inspection limit.")
            return b"".join(chunks)
        finally:
            os.close(descriptor)

    @staticmethod
    def _path_fingerprint(parent: int, name: str) -> FileFingerprint | None:
        try:
            info = os.stat(name, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            return None
        except OSError as error:
            raise UnsafePath("The destination cannot be inspected safely.") from error
        return _regular_fingerprint(
            info, "The destination must be a single-link regular file."
        )

    @classmethod
    def _hash_existing_at(cls, parent: int, name: str) -> HashedRegularFile | None:
        try:
            descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
        except FileNotFoundError:
            return None
        except OSError as error:
            raise UnsafePath("The destination cannot be inspected safely.") from error
        try:
            hashed = _hash_open_regular(descriptor, MAX_STREAM_FILE_BYTES)
            if cls._path_fingerprint(parent, name) != hashed.fingerprint:
                raise InvalidTask("The destination changed during compare-and-swap.")
            return hashed
        finally:
            os.close(descriptor)


# ------------------------------------------------------------------ host scope


def _reject_denied(resolved: str, denied_prefixes: Iterable[str], message: str) -> None:
    for prefix in denied_prefixes:
        canonical = os.path.realpath(prefix) if os.path.exists(prefix) else prefix
        if resolved == canonical or resolved.startswith(canonical.rstrip("/") + "/"):
            raise UnsafePath(message)


def _host_target(path: str, denied_prefixes: Iterable[str]) -> str:
    if not isinstance(path, str) or "\0" in path:
        raise UnsafePath("Host-scope paths must be NUL-free strings.")
    if not path.startswith("/"):
        raise UnsafePath("Host-scope paths must be absolute.")
    if len(path.encode("utf-8")) > MAX_PATH_BYTES:
        raise UnsafePath("Host-scope paths must be at most 4096 bytes.")
    resolved = os.path.realpath(path)
    _reject_denied(
        resolved, denied_prefixes, "That host path is not readable by the Meshia node."
    )
    return resolved


def host_denied_prefixes(meshia_home: Path | str) -> tuple[str, ...]:
    """The node's own state is never readable through host scope."""
    return (str(Path(meshia_home).expanduser()),) + DEFAULT_DENIED_PREFIXES


def host_read_file(
    path: str, max_bytes: int, denied_prefixes: Iterable[str] = ()
) -> tuple[bytes, bool]:
    """Read-only, symlink-final-hop-safe read of an absolute host path."""
    if not 1 <= max_bytes <= MAX_READ_BYTES:
        raise InvalidTask("read_file max_bytes is outside the allowed range.")
    target = _host_target(path, denied_prefixes)
    try:
        descriptor = os.open(target, _FILE_FLAGS)
    except OSError as error:
        raise UnsafePath("The host file cannot be opened safely.") from error
    try:
        info = os.fstat(descriptor)
        if not stat_module.S_ISREG(info.st_mode):
            raise UnsafePath("Host-scope read_file accepts regular files only.")
        data = b""
        while len(data) <= max_bytes:
            chunk = os.read(descriptor, max_bytes + 1 - len(data))
            if not chunk:
                break
            data += chunk
        return data[:max_bytes], len(data) > max_bytes
    finally:
        os.close(descriptor)


def host_list(
    path: str, max_entries: int, denied_prefixes: Iterable[str] = ()
) -> tuple[list[str], bool]:
    """Read-only directory listing of an absolute host path."""
    if not 1 <= max_entries <= MAX_LIST_ENTRIES:
        raise InvalidTask("list max_entries is outside the allowed range.")
    target = _host_target(path, denied_prefixes)
    try:
        descriptor = os.open(target, os.O_RDONLY | _O_DIRECTORY | _O_NOFOLLOW)
    except OSError as error:
        raise UnsafePath("The host directory cannot be opened safely.") from error
    try:
        names = sorted(os.listdir(descriptor))
    finally:
        os.close(descriptor)
    truncated = len(names) > max_entries
    return names[:max_entries], truncated


def host_write_file(
    path: str,
    data: bytes,
    denied_prefixes: Iterable[str] = (),
    *,
    expected_sha256: str | None = None,
) -> str:
    """Atomically write an absolute host path. **`full` access mode only.**

    The caller is responsible for the access-mode gate; this function is the
    mechanism, not the policy. Mechanically it mirrors
    :meth:`WorkspaceBoundary.write_file`:

    * the parent directory is ``realpath``'d and reopened ``O_DIRECTORY |
      O_NOFOLLOW``, so no symlink in the chain can redirect the write;
    * the destination is opened ``O_NOFOLLOW`` for inspection, so a symlink or a
      hard-linked file at the final hop is refused rather than followed;
    * an optional ``expected_sha256`` compare-and-swap guards blind overwrites;
    * bytes land in a sibling temporary file that is fsync'd and only then
      renamed over the destination, so a failed write never truncates the
      original.

    Returns the resolved absolute path that was written.
    """
    if not isinstance(data, bytes):  # pragma: no cover - callers encode first
        raise InvalidTask("Host-scope write_file content must be bytes.")
    if len(data) > MAX_HOST_WRITE_BYTES:
        raise InvalidTask("Host-scope write_file content must be at most 1 MiB.")
    if expected_sha256 is not None and not TAGGED_SHA256_RE.match(expected_sha256):
        raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
    if not isinstance(path, str) or "\0" in path:
        raise UnsafePath("Host-scope paths must be NUL-free strings.")
    if not path.startswith("/"):
        raise UnsafePath("Host-scope paths must be absolute.")
    if len(path.encode("utf-8")) > MAX_PATH_BYTES:
        raise UnsafePath("Host-scope paths must be at most 4096 bytes.")

    directory, _, name = path.rstrip("/").rpartition("/")
    if not name or name in (".", ".."):
        raise UnsafePath("Host-scope write_file needs a file name, not a directory.")
    parent_path = os.path.realpath(directory or "/")
    target = os.path.join(parent_path, name)
    _reject_denied(
        target, denied_prefixes, "That host path is not writable by the Meshia node."
    )

    try:
        parent = os.open(parent_path, _DIR_FLAGS)
    except OSError as error:
        raise UnsafePath("The host directory cannot be opened safely.") from error
    try:
        existing = _existing_host_file(parent, name)
        if existing is None:
            if expected_sha256 is not None:
                raise InvalidTask("expected_sha256 requires an existing destination.")
        elif expected_sha256 is not None and f"sha256:{sha256_hex(existing)}" != expected_sha256.lower():
            raise InvalidTask("The destination digest does not match expected_sha256.")

        temporary = _owned_temporary_name("write")
        try:
            descriptor = os.open(
                temporary,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_CLOEXEC,
                # A fresh host file is owner-only; an overwrite keeps the mode of
                # the file the rename replaces only insofar as the caller re-sets
                # it, which is deliberate — we never widen a mode.
                0o600,
                dir_fd=parent,
            )
        except OSError as error:
            raise UnsafePath("The host destination is not writable.") from error
        published = False
        try:
            try:
                view = memoryview(data)
                while view:
                    written = os.write(descriptor, view)
                    if written <= 0:
                        raise InvalidTask("Writing the host file made no progress.")
                    view = view[written:]
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            os.rename(temporary, name, src_dir_fd=parent, dst_dir_fd=parent)
            published = True
        finally:
            if not published:
                try:
                    os.unlink(temporary, dir_fd=parent)
                except OSError:
                    pass
        try:
            os.fsync(parent)
        except OSError:  # pragma: no cover - some filesystems refuse dir fsync
            pass
    finally:
        os.close(parent)
    return target


def _existing_host_file(parent: int, name: str) -> bytes | None:
    """Read the current destination, refusing symlinks and multiply-linked files."""
    try:
        descriptor = os.open(name, _FILE_FLAGS, dir_fd=parent)
    except FileNotFoundError:
        return None
    except OSError as error:
        # ELOOP here means the destination is a symlink: refuse rather than
        # follow it out of whatever the operator believed they were touching.
        raise UnsafePath("The host destination cannot be inspected safely.") from error
    try:
        info = os.fstat(descriptor)
        if not stat_module.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise UnsafePath("The host destination must be a single-link regular file.")
        chunks: list[bytes] = []
        while True:
            chunk = os.read(descriptor, 262_144)
            if not chunk:
                break
            chunks.append(chunk)
            if sum(len(part) for part in chunks) > MAX_HOST_WRITE_BYTES:
                raise InvalidTask("The host destination exceeds the 1 MiB inspection limit.")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


# ------------------------------------------------------------------- dispatch
# The implementations above are the POSIX boundary (dir_fd walks, O_NOFOLLOW).
# Windows has neither, so meshia_node.workspace_win keeps the same three-stage
# discipline with NTFS mechanics (reparse-point refusal, os.replace publish,
# case-folded containment) behind the very same public names. Callers import
# from this module on every platform and never know the difference.
if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
    from .workspace_win import (  # noqa: E402,F811
        WindowsWorkspaceBoundary as WorkspaceBoundary,
        bind_workspace_root_claim,
        claim_workspace_root,
        complete_workspace_root_adoption,
        host_denied_prefixes,
        host_list,
        host_read_file,
        host_write_file,
        rebind_workspace_root_claim,
        validate_workspace_root_claim,
        workspace_root_claim_status,
    )
