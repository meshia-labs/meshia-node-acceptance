"""Run the Windows user service without allocating a console window."""

from __future__ import annotations

from contextlib import ExitStack
import os
from pathlib import Path
import sys
from typing import Sequence


def main(argv: Sequence[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if (len(arguments) != 5 or arguments[1] != "--home"
            or arguments[3:] != ["service", "run"]):
        return 2
    executable = Path(arguments[0])
    python_directory = Path(sys.executable).resolve().parent
    console_directory = executable.resolve().parent
    if (not executable.is_absolute() or not executable.is_file()
            or executable.name.lower() not in ("meshia-node.exe", "meshia.exe")
            or not (console_directory == python_directory
                or (console_directory.name.lower() == "scripts"
                    and console_directory.parent == python_directory))):
        return 2

    # Pythonw has no console streams. Libraries may still write to them; the
    # existing private, redacting NodeLogger remains the diagnostic authority.
    from .cli import main as run_cli
    from .config import Paths
    from .log import NodeLogger

    previous_argv = sys.argv
    previous_streams = {name: getattr(sys, name) for name in ("stdin", "stdout", "stderr")}
    logger = NodeLogger(path=Paths.resolve(arguments[2]).log_path, quiet=True)
    with ExitStack() as stack:
        try:
            sys.argv = arguments
            for name, previous in previous_streams.items():
                if previous is None:
                    setattr(sys, name, stack.enter_context(open(os.devnull, "r" if name == "stdin" else "w")))
            result = run_cli(arguments[1:])
            if result:
                logger.record("windowless_service_exited", exit_code=result)
            return result
        except Exception as error:
            logger.record("windowless_service_failed", error=type(error).__name__)
            return 1
        finally:
            sys.argv = previous_argv
            for name, previous in previous_streams.items():
                setattr(sys, name, previous)


if __name__ == "__main__":
    raise SystemExit(main())
