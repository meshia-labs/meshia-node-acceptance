"""Private, bounded IPC bridge for the macOS File Provider extension.

The native extension never receives Fabric credentials. It talks to this
same-user Unix socket for remote metadata, verified ranges, and local mutation
handoffs. MeshiaFabric remains the only namespace authority and
``FabricSyncCoordinator`` remains the only reconciliation engine.
"""

from __future__ import annotations

import array
import hashlib
import json
import os
import select
import secrets
import sqlite3
import socket
import stat
import struct
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Mapping

try:  # macOS-only descriptor validation; keep Windows imports functional.
    import fcntl
except ImportError:  # pragma: no cover - File Provider is unavailable on Windows
    fcntl = None  # type: ignore[assignment]

from .fabric_mount import tune_interpreter_for_mount_callbacks
from .errors import InvalidTask, StateError, UnsafePath
from .fabric_db import FabricDatabase, RemoteChild, RemoteEntry
from .fabric_sync import (
    FabricSyncCoordinator,
    MAX_LOCAL_UPLOAD_FILE_BYTES,
    _normalized_modified_at,
)
from .log import NULL_LOGGER, NodeLogger
from .util import RAW_SHA256_RE, ensure_private_dir, write_private_file
from .workspace import FileFingerprint, WorkspaceBoundary, split_relative

BRIDGE_SCHEMA = "meshia.file_provider.bridge.v1"
MAX_REQUEST_BYTES = 64 * 1024
MAX_RESPONSE_METADATA_BYTES = 1024 * 1024
MAX_FETCH_BYTES = 64 * 1024 * 1024
MAX_WRITE_BYTES = MAX_LOCAL_UPLOAD_FILE_BYTES
MAX_CONNECTIONS = 8
STREAM_CHUNK_BYTES = 1024 * 1024
_IDENTITY_SCHEMA_VERSION = 3
_MAX_IDENTITY_ROWS = 500_000
_MAX_RECURSIVE_DELETE_ITEMS = 99_999


class FileProviderBridgeError(RuntimeError):
    """A safe, user-visible File Provider request rejection."""


class FileProviderConflict(FileProviderBridgeError):
    """The requested item version no longer owns the remote/local path."""


class FileProviderNotFound(FileProviderBridgeError):
    """The requested durable File Provider item no longer exists."""


class FileProviderCollision(FileProviderBridgeError):
    """A different item already owns the requested File Provider name."""


@dataclass(frozen=True)
class FileProviderBridgeAddress:
    socket_path: Path
    token_path: Path


@dataclass(frozen=True)
class _CompoundWriteReplay:
    identifier: str
    source_path: str
    destination_path: str
    base_digest: str
    base_metadata_version: str | None
    result_digest: str
    result_size: int
    result_modified_at: str | None
    put_mutation_id: str
    delete_mutation_id: str


class _FileProviderIdentityStore:
    """Private durable opaque identities, separate from Fabric authority state.

    The remote namespace currently exposes paths and content digests, neither of
    which is an object identity: paths change on rename and equal bytes can name
    distinct files.  This purpose-scoped database therefore assigns one random
    identifier per authority/object incarnation and retains retired identifiers
    as tombstones so a deleted path is never mistaken for its recreation.
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        ensure_private_dir(path.parent)
        if not path.exists():
            descriptor = os.open(
                str(path), os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600
            )
            os.close(descriptor)
        info = path.lstat()
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_nlink != 1
            or info.st_uid != os.getuid()
        ):
            raise FileProviderBridgeError(
                "the File Provider identity database is unsafe"
            )
        os.chmod(path, 0o600)
        self._lock = threading.RLock()
        self._connection = sqlite3.connect(
            str(path), isolation_level=None, check_same_thread=False
        )
        self._closed = False
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA busy_timeout = 5000")
        self._connection.execute("PRAGMA journal_mode = DELETE")
        self._connection.execute("PRAGMA synchronous = FULL")
        version = int(
            self._connection.execute("PRAGMA user_version").fetchone()[0]
        )
        if version > _IDENTITY_SCHEMA_VERSION:
            self._connection.close()
            raise FileProviderBridgeError(
                "the File Provider identity database is newer than this node"
            )
        self._connection.executescript(
            """
            BEGIN IMMEDIATE;
            CREATE TABLE IF NOT EXISTS item_identities (
                authority_key TEXT NOT NULL,
                identifier TEXT NOT NULL,
                path TEXT NOT NULL,
                kind TEXT NOT NULL CHECK(kind IN ('file', 'directory')),
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                created_at_ns INTEGER NOT NULL,
                updated_at_ns INTEGER NOT NULL,
                PRIMARY KEY(authority_key, identifier)
            ) WITHOUT ROWID;
            CREATE UNIQUE INDEX IF NOT EXISTS item_identity_active_path
                ON item_identities(authority_key, path) WHERE active = 1;
            CREATE TABLE IF NOT EXISTS identity_transitions (
                transition_id TEXT PRIMARY KEY,
                authority_key TEXT NOT NULL,
                identifier TEXT NOT NULL,
                source_path TEXT NOT NULL,
                destination_path TEXT NOT NULL,
                recursive INTEGER NOT NULL CHECK(recursive IN (0, 1)),
                created_at_ns INTEGER NOT NULL,
                UNIQUE(authority_key, source_path)
            ) WITHOUT ROWID;
            CREATE TABLE IF NOT EXISTS identity_deletions (
                deletion_id TEXT PRIMARY KEY,
                authority_key TEXT NOT NULL,
                identifier TEXT NOT NULL,
                path TEXT NOT NULL,
                recursive INTEGER NOT NULL CHECK(recursive IN (0, 1)),
                mutation_id TEXT,
                completed INTEGER NOT NULL DEFAULT 0 CHECK(completed IN (0, 1)),
                created_at_ns INTEGER NOT NULL,
                completed_at_ns INTEGER
            ) WITHOUT ROWID;
            CREATE UNIQUE INDEX IF NOT EXISTS identity_deletion_pending_path
                ON identity_deletions(authority_key, path) WHERE completed = 0;
            CREATE UNIQUE INDEX IF NOT EXISTS identity_deletion_identifier
                ON identity_deletions(authority_key, identifier);
            CREATE TABLE IF NOT EXISTS compound_write_replays (
                authority_key TEXT NOT NULL,
                identifier TEXT NOT NULL,
                source_path TEXT NOT NULL,
                destination_path TEXT NOT NULL,
                base_digest TEXT NOT NULL,
                base_metadata_version TEXT,
                result_digest TEXT NOT NULL,
                result_size INTEGER NOT NULL CHECK(result_size >= 0),
                result_modified_at TEXT,
                put_mutation_id TEXT NOT NULL,
                delete_mutation_id TEXT NOT NULL,
                completed_at_ns INTEGER NOT NULL,
                PRIMARY KEY(authority_key, identifier)
            ) WITHOUT ROWID;
            PRAGMA user_version = 3;
            COMMIT;
            """
        )

    def close(self) -> None:
        with self._lock:
            if not self._closed:
                self._connection.close()
                self._closed = True

    def identity_for(self, authority_key: str, path: str, kind: str) -> str:
        with self._transaction():
            row = self._connection.execute(
                """SELECT identifier, kind FROM item_identities
                   WHERE authority_key = ? AND path = ? AND active = 1""",
                (authority_key, path),
            ).fetchone()
            if row is not None and row["kind"] == kind:
                return str(row["identifier"])
            now = time.time_ns()
            if row is not None:
                self._connection.execute(
                    """UPDATE item_identities SET active = 0, updated_at_ns = ?
                       WHERE authority_key = ? AND identifier = ?""",
                    (now, authority_key, row["identifier"]),
                )
            count = int(
                self._connection.execute(
                    "SELECT COUNT(*) FROM item_identities WHERE authority_key = ?",
                    (authority_key,),
                ).fetchone()[0]
            )
            if count >= _MAX_IDENTITY_ROWS:
                raise FileProviderBridgeError(
                    "the File Provider identity history reached its safety bound"
                )
            while True:
                identifier = "item-" + secrets.token_hex(16)
                try:
                    self._connection.execute(
                        """INSERT INTO item_identities(
                               authority_key, identifier, path, kind, active,
                               created_at_ns, updated_at_ns
                           ) VALUES (?, ?, ?, ?, 1, ?, ?)""",
                        (authority_key, identifier, path, kind, now, now),
                    )
                except sqlite3.IntegrityError:
                    continue
                return identifier

    def resolve(self, authority_key: str, identifier: str) -> tuple[str, str] | None:
        with self._lock:
            row = self._connection.execute(
                """SELECT path, kind FROM item_identities
                   WHERE authority_key = ? AND identifier = ? AND active = 1""",
                (authority_key, identifier),
            ).fetchone()
        if row is None:
            return None
        return str(row["path"]), str(row["kind"])

    def retire(self, authority_key: str, path: str, *, recursive: bool = False) -> None:
        now = time.time_ns()
        with self._transaction():
            if recursive:
                self._connection.execute(
                    """UPDATE item_identities SET active = 0, updated_at_ns = ?
                       WHERE authority_key = ? AND active = 1
                         AND (path = ? OR substr(path, 1, ?) = ?)""",
                    (now, authority_key, path, len(path) + 1, path + "/"),
                )
            else:
                self._connection.execute(
                    """UPDATE item_identities SET active = 0, updated_at_ns = ?
                       WHERE authority_key = ? AND path = ? AND active = 1""",
                    (now, authority_key, path),
                )

    def move(
        self,
        authority_key: str,
        source: str,
        destination: str,
        *,
        recursive: bool = False,
        transition_id: str | None = None,
        compound_replay: _CompoundWriteReplay | None = None,
    ) -> str:
        """Move one active identity (and a directory's descendants) atomically."""

        now = time.time_ns()
        with self._transaction():
            source_row = self._connection.execute(
                """SELECT identifier, kind FROM item_identities
                   WHERE authority_key = ? AND path = ? AND active = 1""",
                (authority_key, source),
            ).fetchone()
            if source_row is None:
                raise FileProviderBridgeError(
                    "the File Provider rename source identity is missing"
                )
            if recursive:
                self._connection.execute(
                    """UPDATE item_identities SET active = 0, updated_at_ns = ?
                       WHERE authority_key = ? AND active = 1
                         AND (path = ? OR substr(path, 1, ?) = ?)""",
                    (
                        now,
                        authority_key,
                        destination,
                        len(destination) + 1,
                        destination + "/",
                    ),
                )
                rows = self._connection.execute(
                    """SELECT identifier, path FROM item_identities
                       WHERE authority_key = ? AND active = 1
                         AND (path = ? OR substr(path, 1, ?) = ?)
                       ORDER BY length(path), path""",
                    (authority_key, source, len(source) + 1, source + "/"),
                ).fetchall()
            else:
                self._connection.execute(
                    """UPDATE item_identities SET active = 0, updated_at_ns = ?
                       WHERE authority_key = ? AND path = ? AND active = 1""",
                    (now, authority_key, destination),
                )
                rows = [source_row]
            for row in rows:
                old_path = source if not recursive else str(row["path"])
                new_path = destination + old_path[len(source) :]
                self._connection.execute(
                    """UPDATE item_identities SET path = ?, updated_at_ns = ?
                       WHERE authority_key = ? AND identifier = ?""",
                    (new_path, now, authority_key, row["identifier"]),
                )
                self._connection.execute(
                    """DELETE FROM compound_write_replays
                       WHERE authority_key = ? AND identifier = ?""",
                    (authority_key, row["identifier"]),
                )
            if compound_replay is not None:
                if (
                    recursive
                    or compound_replay.identifier != str(source_row["identifier"])
                    or compound_replay.source_path != source
                    or compound_replay.destination_path != destination
                ):
                    raise FileProviderBridgeError(
                        "the compound write replay does not match its identity move"
                    )
                self._connection.execute(
                    """INSERT INTO compound_write_replays(
                           authority_key, identifier, source_path, destination_path,
                           base_digest, base_metadata_version, result_digest,
                           result_size, result_modified_at, put_mutation_id,
                           delete_mutation_id, completed_at_ns
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(authority_key, identifier) DO UPDATE SET
                           source_path = excluded.source_path,
                           destination_path = excluded.destination_path,
                           base_digest = excluded.base_digest,
                           base_metadata_version = excluded.base_metadata_version,
                           result_digest = excluded.result_digest,
                           result_size = excluded.result_size,
                           result_modified_at = excluded.result_modified_at,
                           put_mutation_id = excluded.put_mutation_id,
                           delete_mutation_id = excluded.delete_mutation_id,
                           completed_at_ns = excluded.completed_at_ns""",
                    (
                        authority_key,
                        compound_replay.identifier,
                        source,
                        destination,
                        compound_replay.base_digest,
                        compound_replay.base_metadata_version,
                        compound_replay.result_digest,
                        compound_replay.result_size,
                        compound_replay.result_modified_at,
                        compound_replay.put_mutation_id,
                        compound_replay.delete_mutation_id,
                        now,
                    ),
                )
            if transition_id is not None:
                self._connection.execute(
                    "DELETE FROM identity_transitions WHERE transition_id = ?",
                    (transition_id,),
                )
            return str(source_row["identifier"])

    def begin_move(
        self,
        authority_key: str,
        source: str,
        destination: str,
        *,
        recursive: bool,
    ) -> str:
        """Durably record a cross-database identity transition before enqueue."""

        with self._transaction():
            source_row = self._connection.execute(
                """SELECT identifier FROM item_identities
                   WHERE authority_key = ? AND path = ? AND active = 1""",
                (authority_key, source),
            ).fetchone()
            if source_row is None:
                raise FileProviderBridgeError(
                    "the File Provider rename source identity is missing"
                )
            existing = self._connection.execute(
                """SELECT transition_id, destination_path, recursive
                   FROM identity_transitions
                   WHERE authority_key = ? AND source_path = ?""",
                (authority_key, source),
            ).fetchone()
            if existing is not None:
                if (
                    existing["destination_path"] != destination
                    or bool(existing["recursive"]) != recursive
                ):
                    raise FileProviderConflict(
                        "the File Provider item already has a pending move"
                    )
                return str(existing["transition_id"])
            transition_id = secrets.token_hex(16)
            self._connection.execute(
                """INSERT INTO identity_transitions(
                       transition_id, authority_key, identifier, source_path,
                       destination_path, recursive, created_at_ns
                   ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    transition_id,
                    authority_key,
                    source_row["identifier"],
                    source,
                    destination,
                    int(recursive),
                    time.time_ns(),
                ),
            )
            return transition_id

    def complete_move(
        self,
        transition_id: str,
        *,
        compound_replay: _CompoundWriteReplay | None = None,
    ) -> str:
        with self._lock:
            row = self._connection.execute(
                "SELECT * FROM identity_transitions WHERE transition_id = ?",
                (transition_id,),
            ).fetchone()
        if row is None:
            raise FileProviderBridgeError(
                "the File Provider identity transition does not exist"
            )
        identifier = self.move(
            str(row["authority_key"]),
            str(row["source_path"]),
            str(row["destination_path"]),
            recursive=bool(row["recursive"]),
            transition_id=transition_id,
            compound_replay=compound_replay,
        )
        return identifier

    def compound_write_replay(
        self,
        authority_key: str,
        identifier: str,
        destination_path: str,
        base_digest: str,
        base_metadata_version: str | None,
    ) -> _CompoundWriteReplay | None:
        with self._lock:
            row = self._connection.execute(
                """SELECT replay.* FROM compound_write_replays AS replay
                   JOIN item_identities AS item
                     ON item.authority_key = replay.authority_key
                    AND item.identifier = replay.identifier
                   WHERE replay.authority_key = ? AND replay.identifier = ?
                     AND replay.destination_path = ? AND replay.base_digest = ?
                     AND replay.base_metadata_version IS ?
                     AND item.active = 1 AND item.path = replay.destination_path""",
                (
                    authority_key,
                    identifier,
                    destination_path,
                    base_digest,
                    base_metadata_version,
                ),
            ).fetchone()
        if row is None:
            return None
        return _CompoundWriteReplay(
            identifier=str(row["identifier"]),
            source_path=str(row["source_path"]),
            destination_path=str(row["destination_path"]),
            base_digest=str(row["base_digest"]),
            base_metadata_version=(
                None
                if row["base_metadata_version"] is None
                else str(row["base_metadata_version"])
            ),
            result_digest=str(row["result_digest"]),
            result_size=int(row["result_size"]),
            result_modified_at=(
                None
                if row["result_modified_at"] is None
                else str(row["result_modified_at"])
            ),
            put_mutation_id=str(row["put_mutation_id"]),
            delete_mutation_id=str(row["delete_mutation_id"]),
        )

    def cancel_move(self, transition_id: str) -> None:
        with self._transaction():
            self._connection.execute(
                "DELETE FROM identity_transitions WHERE transition_id = ?",
                (transition_id,),
            )

    def pending_moves(
        self, authority_key: str
    ) -> tuple[tuple[str, str, str, bool], ...]:
        with self._lock:
            rows = self._connection.execute(
                """SELECT transition_id, source_path, destination_path, recursive
                   FROM identity_transitions WHERE authority_key = ?
                   ORDER BY created_at_ns, transition_id""",
                (authority_key,),
            ).fetchall()
        return tuple(
            (
                str(row["transition_id"]),
                str(row["source_path"]),
                str(row["destination_path"]),
                bool(row["recursive"]),
            )
            for row in rows
        )

    def begin_delete(
        self, authority_key: str, path: str, *, kind: str, recursive: bool
    ) -> tuple[str, str, str | None]:
        """Persist delete identity before the Fabric namespace transaction."""

        with self._transaction():
            source = self._connection.execute(
                """SELECT identifier, kind FROM item_identities
                   WHERE authority_key = ? AND path = ? AND active = 1""",
                (authority_key, path),
            ).fetchone()
            if source is None:
                raise FileProviderNotFound(
                    "the File Provider delete identity does not exist"
                )
            if str(source["kind"]) != kind:
                raise FileProviderConflict("the File Provider item kind changed")
            existing = self._connection.execute(
                """SELECT deletion_id, identifier, recursive, mutation_id
                   FROM identity_deletions
                   WHERE authority_key = ? AND path = ? AND completed = 0""",
                (authority_key, path),
            ).fetchone()
            if existing is not None:
                if (
                    str(existing["identifier"]) != str(source["identifier"])
                    or bool(existing["recursive"]) != recursive
                ):
                    raise FileProviderConflict(
                        "the File Provider item already has a pending delete"
                    )
                return (
                    str(existing["deletion_id"]),
                    str(existing["identifier"]),
                    None
                    if existing["mutation_id"] is None
                    else str(existing["mutation_id"]),
                )
            count = int(
                self._connection.execute(
                    """SELECT COUNT(*) FROM identity_deletions
                       WHERE authority_key = ?""",
                    (authority_key,),
                ).fetchone()[0]
            )
            if count >= _MAX_IDENTITY_ROWS:
                raise FileProviderBridgeError(
                    "the File Provider delete identity history reached its safety bound"
                )
            deletion_id = secrets.token_hex(16)
            self._connection.execute(
                """INSERT INTO identity_deletions(
                       deletion_id, authority_key, identifier, path, recursive,
                       created_at_ns
                   ) VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    deletion_id,
                    authority_key,
                    source["identifier"],
                    path,
                    int(recursive),
                    time.time_ns(),
                ),
            )
            return deletion_id, str(source["identifier"]), None

    def bind_delete_mutation(self, deletion_id: str, mutation_id: str) -> None:
        with self._transaction():
            row = self._connection.execute(
                """SELECT mutation_id, completed FROM identity_deletions
                   WHERE deletion_id = ?""",
                (deletion_id,),
            ).fetchone()
            if row is None or bool(row["completed"]):
                raise FileProviderBridgeError(
                    "the File Provider delete identity transition does not exist"
                )
            if row["mutation_id"] not in (None, mutation_id):
                raise FileProviderConflict(
                    "the File Provider delete journal identity changed"
                )
            self._connection.execute(
                """UPDATE identity_deletions SET mutation_id = ?
                   WHERE deletion_id = ?""",
                (mutation_id, deletion_id),
            )

    def complete_delete(self, deletion_id: str) -> str:
        now = time.time_ns()
        with self._transaction():
            row = self._connection.execute(
                "SELECT * FROM identity_deletions WHERE deletion_id = ?",
                (deletion_id,),
            ).fetchone()
            if row is None:
                raise FileProviderBridgeError(
                    "the File Provider delete identity transition does not exist"
                )
            identifier = str(row["identifier"])
            if not bool(row["completed"]):
                path = str(row["path"])
                if bool(row["recursive"]):
                    self._connection.execute(
                        """UPDATE item_identities SET active = 0, updated_at_ns = ?
                           WHERE authority_key = ? AND active = 1
                             AND (path = ? OR substr(path, 1, ?) = ?)""",
                        (
                            now,
                            row["authority_key"],
                            path,
                            len(path) + 1,
                            path + "/",
                        ),
                    )
                else:
                    self._connection.execute(
                        """UPDATE item_identities SET active = 0, updated_at_ns = ?
                           WHERE authority_key = ? AND identifier = ? AND active = 1""",
                        (now, row["authority_key"], identifier),
                    )
                self._connection.execute(
                    """UPDATE identity_deletions
                       SET completed = 1, completed_at_ns = ?
                       WHERE deletion_id = ?""",
                    (now, deletion_id),
                )
            return identifier

    def cancel_delete(self, deletion_id: str) -> None:
        with self._transaction():
            self._connection.execute(
                """DELETE FROM identity_deletions
                   WHERE deletion_id = ? AND completed = 0""",
                (deletion_id,),
            )

    def pending_deletes(
        self, authority_key: str
    ) -> tuple[tuple[str, str, str, bool, str | None], ...]:
        with self._lock:
            rows = self._connection.execute(
                """SELECT d.deletion_id, d.path, i.kind, d.recursive, d.mutation_id
                   FROM identity_deletions AS d
                   JOIN item_identities AS i
                     ON i.authority_key = d.authority_key
                    AND i.identifier = d.identifier
                   WHERE d.authority_key = ? AND d.completed = 0
                   ORDER BY d.created_at_ns, d.deletion_id""",
                (authority_key,),
            ).fetchall()
        return tuple(
            (
                str(row["deletion_id"]),
                str(row["path"]),
                str(row["kind"]),
                bool(row["recursive"]),
                None if row["mutation_id"] is None else str(row["mutation_id"]),
            )
            for row in rows
        )

    def completed_delete(
        self, authority_key: str, identifier: str
    ) -> tuple[str, str, bool] | None:
        with self._lock:
            row = self._connection.execute(
                """SELECT path, mutation_id, recursive FROM identity_deletions
                   WHERE authority_key = ? AND identifier = ? AND completed = 1""",
                (authority_key, identifier),
            ).fetchone()
        if row is None or row["mutation_id"] is None:
            return None
        return str(row["path"]), str(row["mutation_id"]), bool(row["recursive"])

    @contextmanager
    def _transaction(self) -> Iterator[None]:
        with self._lock:
            if self._closed:
                raise FileProviderBridgeError(
                    "the File Provider identity database is closed"
                )
            connection = self._connection
            connection.execute("BEGIN IMMEDIATE")
            try:
                yield
            except BaseException:
                connection.execute("ROLLBACK")
                raise
            else:
                connection.execute("COMMIT")


def file_provider_address_for_container(
    container_path: Path | str,
) -> FileProviderBridgeAddress:
    """Return socket paths inside an already verified signed app container.

    The Apple team identifier is a signing-time capability and cannot be
    guessed safely by the Python process.  Runtime cutover obtains and verifies
    this path from the signed host before constructing the bridge.
    """

    root = Path(container_path).expanduser()
    if not root.is_absolute():
        raise ValueError("the File Provider container path must be absolute")
    # Darwin's sockaddr_un path is only 104 bytes including the terminator.
    # Keep these names at the app-group root so normal user names fit safely.
    return FileProviderBridgeAddress(root / "fp.sock", root / "fp.token")


class FabricFileProviderBridge:
    """Same-user Unix socket facade over one live Fabric coordinator."""

    def __init__(
        self,
        database: FabricDatabase,
        coordinator: FabricSyncCoordinator,
        workspace: WorkspaceBoundary,
        workspace_name: str,
        address: FileProviderBridgeAddress,
        *,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        parts = split_relative(workspace_name)
        if len(parts) != 1:
            raise ValueError("workspace_name must be one portable path component")
        if address.socket_path.parent != address.token_path.parent:
            raise ValueError("the File Provider socket and token must share one directory")
        self.database = database
        self.coordinator = coordinator
        self.workspace = workspace
        self.workspace_name = parts[0]
        self.address = address
        self.logger = logger
        self._identities = _FileProviderIdentityStore(
            database.path.with_name(database.path.name + ".file-provider-identities.sqlite3")
        )
        self._listener: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stopped = threading.Event()
        self._connections = threading.BoundedSemaphore(MAX_CONNECTIONS)
        self._token = ""
        self._socket_identity: tuple[int, int] | None = None
        self._reconcile_identity_transitions()
        self._reconcile_identity_deletions()

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        if not hasattr(socket, "AF_UNIX"):
            raise FileProviderBridgeError("Unix sockets are unavailable")
        root = ensure_private_dir(self.address.socket_path.parent)
        self._token = self._load_or_create_token()
        self._remove_stale_socket(root)
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            listener.bind(str(self.address.socket_path))
            os.chmod(self.address.socket_path, 0o600)
            socket_info = self.address.socket_path.lstat()
            self._socket_identity = (socket_info.st_dev, socket_info.st_ino)
            listener.listen(MAX_CONNECTIONS)
            listener.settimeout(0.5)
        except BaseException:
            listener.close()
            raise
        self._listener = listener
        self._stopped.clear()
        # Same interpreter-switch starvation exposure as the FUSE and FSKit
        # callback loops (2026-08-30): tune before serving callbacks.
        applied_interval = tune_interpreter_for_mount_callbacks()
        if applied_interval is not None:
            self.logger.record(
                "file_provider_bridge_gil_interval_tuned", interval=applied_interval
            )
        self._thread = threading.Thread(
            target=self._serve,
            name="meshia-file-provider-bridge",
            daemon=True,
        )
        self._thread.start()
        self.logger.record(
            "file_provider_bridge_started", socket_path=str(self.address.socket_path)
        )

    def close(self) -> None:
        self._stopped.set()
        listener, self._listener = self._listener, None
        if listener is not None:
            listener.close()
        thread, self._thread = self._thread, None
        if thread is not None:
            thread.join(timeout=2.0)
        try:
            info = self.address.socket_path.lstat()
            identity = self._socket_identity
            if (
                identity is not None
                and stat.S_ISSOCK(info.st_mode)
                and info.st_uid == os.getuid()
                and (info.st_dev, info.st_ino) == identity
            ):
                self.address.socket_path.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            pass
        self._socket_identity = None
        self._identities.close()

    def _authority_key(self) -> str:
        authority = self.database.current_authority()
        if authority is None:
            raise FileProviderBridgeError("the workspace authority is unavailable")
        document = {
            "host_id": authority.host_id,
            "session_id": authority.session_id,
            "host_generation": authority.host_generation,
            "workspace_root": authority.workspace_root,
            "workspace_id": authority.workspace_id,
        }
        return hashlib.sha256(
            json.dumps(document, sort_keys=True, separators=(",", ":")).encode(
                "utf-8"
            )
        ).hexdigest()

    def _reconcile_identity_transitions(self) -> None:
        """Finish only moves backed by a durable Fabric/local namespace intent."""

        authority_key = self._authority_key()
        operations = self.database.list_operations(limit=100_000)
        directory_operations = self.database.list_directory_puts(limit=1_000)
        for transition_id, source_virtual, destination_virtual, recursive in (
            self._identities.pending_moves(authority_key)
        ):
            source = self._remote_path(source_virtual)
            destination = self._remote_path(destination_virtual)
            backed = any(
                operation.state in {"queued", "inflight", "retry", "acked"}
                and operation.kind == "rename"
                and operation.path == source
                and operation.destination_path == destination
                for operation in operations
            ) or any(
                operation.kind == "rename"
                and operation.path == source
                and operation.destination_path == destination
                for operation in directory_operations
            )
            compound_replay: _CompoundWriteReplay | None = None
            transfer = None
            if not backed:
                transfer = self.database.get_local_transfer_intent(destination)
                backed = bool(
                    transfer is not None
                    and transfer.delete_after_ack_path == source
                )
            compound_puts = tuple(
                operation
                for operation in operations
                if operation.state in {"queued", "inflight", "retry", "acked"}
                and operation.kind == "put"
                and operation.path == destination
            )
            compound_delete = next((
                operation
                for operation in operations
                if operation.state in {"queued", "inflight", "retry", "acked"}
                and operation.kind == "delete"
                and operation.path == source
            ), None)
            if not backed:
                # A promoted compound save is a destination PUT ordered with
                # a source DELETE. Requiring both paths avoids adopting an
                # unrelated destination upload after a crash between the
                # identity transition and the intended Fabric enqueue.
                backed = bool(compound_puts) and compound_delete is not None
            if compound_puts and not recursive:
                identifier = self._identities.identity_for(
                    authority_key, source_virtual, "file"
                )
                for compound_put in reversed(compound_puts):
                    replay = self.coordinator.file_provider_compound_replay(
                        compound_put,
                        item_identifier=identifier,
                        source_path=source,
                    )
                    if replay is None:
                        continue
                    compound_replay = _CompoundWriteReplay(
                        identifier=identifier,
                        source_path=source_virtual,
                        destination_path=destination_virtual,
                        base_digest=str(replay["base_content_version"]),
                        base_metadata_version=(
                            None
                            if replay.get("base_metadata_version") is None
                            else str(replay["base_metadata_version"])
                        ),
                        result_digest=str(replay["sha256"]),
                        result_size=int(replay["size_bytes"]),
                        result_modified_at=(
                            None
                            if replay.get("modified_at") is None
                            else str(replay["modified_at"])
                        ),
                        put_mutation_id=compound_put.mutation_id,
                        delete_mutation_id=str(
                            replay["delete_after_ack_mutation_id"]
                        ),
                    )
                    break
            if backed:
                self._identities.complete_move(
                    transition_id, compound_replay=compound_replay
                )
            else:
                self._identities.cancel_move(transition_id)

    def _reconcile_identity_deletions(self) -> None:
        """Finish or cancel identity retirement from durable Fabric evidence."""

        authority_key = self._authority_key()
        _head, tombstones = self.database.local_directory_tombstone_snapshot()
        tombstoned = set(tombstones)
        for deletion_id, remote_path, kind, _recursive, mutation_id in (
            self._identities.pending_deletes(authority_key)
        ):
            if kind == "file":
                if mutation_id is None:
                    self._identities.cancel_delete(deletion_id)
                    continue
                operation = self.database.get_operation(mutation_id)
                if self.database.get_receipt(mutation_id) is not None:
                    self._identities.complete_delete(deletion_id)
                elif operation is not None and operation.state in {
                    "conflict",
                    "quarantined",
                }:
                    self._identities.cancel_delete(deletion_id)
                # A queued/inflight/retry operation remains an authenticated
                # pending delete. Never infer success from path absence.
                continue
            if mutation_id is None:
                candidate = self.database.directory_delete_mutation_id(remote_path)
                if candidate is None or remote_path not in tombstoned:
                    self._identities.cancel_delete(deletion_id)
                    continue
                self._identities.bind_delete_mutation(deletion_id, candidate)
                mutation_id = candidate
            if self.database.has_queued_directory_delete(remote_path):
                continue
            conflict = self.database.get_conflict_by_evidence_key(
                f"directory-operation:{mutation_id}"
            )
            if conflict is not None:
                self._identities.cancel_delete(deletion_id)
                continue
            # A bound namespace mutation disappears from the queue only after
            # an acknowledged commit or a durable conflict. The latter was
            # excluded above, so retire even if a later head already rebased
            # the path tombstone because another incarnation was recreated.
            self._identities.complete_delete(deletion_id)

    def _completed_compound_write_replay(
        self,
        identifier: str,
        destination_path: str,
        base_digest: str,
        base_metadata_version: str | None,
    ) -> _CompoundWriteReplay | None:
        replay = self._identities.compound_write_replay(
            self._authority_key(),
            identifier,
            destination_path,
            base_digest,
            base_metadata_version,
        )
        if replay is None:
            return None
        operation = self.database.get_operation(replay.put_mutation_id)
        if operation is None:
            return None
        marker = self.coordinator.file_provider_compound_replay(
            operation,
            item_identifier=identifier,
            source_path=self._remote_path(replay.source_path),
        )
        if (
            marker is None
            or marker.get("delete_after_ack_mutation_id")
            != replay.delete_mutation_id
            or marker.get("base_content_version") != replay.base_digest
            or marker.get("base_metadata_version")
            != replay.base_metadata_version
            or marker.get("sha256") != replay.result_digest
            or marker.get("size_bytes") != replay.result_size
            or marker.get("modified_at") != replay.result_modified_at
        ):
            return None
        return replay

    def _load_or_create_token(self) -> str:
        path = self.address.token_path
        try:
            info = path.lstat()
            token = path.read_text(encoding="ascii").strip()
            if (
                not stat.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or info.st_uid != os.getuid()
                or info.st_mode & 0o077
                or len(token) != 64
                or any(character not in "0123456789abcdef" for character in token)
            ):
                raise FileProviderBridgeError("the File Provider token is unsafe")
            return token
        except FileNotFoundError:
            token = secrets.token_hex(32)
            write_private_file(path, (token + "\n").encode("ascii"))
            return token

    def _remove_stale_socket(self, root: Path) -> None:
        path = self.address.socket_path
        try:
            info = path.lstat()
        except FileNotFoundError:
            return
        if (
            path.parent.resolve(strict=True) != root.resolve(strict=True)
            or not stat.S_ISSOCK(info.st_mode)
            or info.st_uid != os.getuid()
        ):
            raise FileProviderBridgeError("the File Provider socket path is unsafe")
        probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            probe.settimeout(0.25)
            probe.connect(str(path))
        except (ConnectionRefusedError, FileNotFoundError):
            pass
        except OSError as error:
            raise FileProviderBridgeError(
                "the existing File Provider socket could not be verified"
            ) from error
        else:
            raise FileProviderBridgeError("the File Provider bridge is already active")
        finally:
            probe.close()
        path.unlink()

    def _serve(self) -> None:
        while not self._stopped.is_set():
            listener = self._listener
            if listener is None:
                return
            try:
                connection, _address = listener.accept()
            except TimeoutError:
                continue
            except OSError:
                if self._stopped.is_set():
                    return
                continue
            if not self._connections.acquire(blocking=False):
                connection.close()
                continue
            threading.Thread(
                target=self._handle_connection,
                args=(connection,),
                name="meshia-file-provider-request",
                daemon=True,
            ).start()

    def _handle_connection(self, connection: socket.socket) -> None:
        try:
            connection.settimeout(120.0)
            self._require_same_user(connection)
            request = _receive_json_frame(connection)
            if not secrets.compare_digest(str(request.get("token", "")), self._token):
                raise FileProviderBridgeError("authentication failed")
            self._dispatch(connection, request)
        except (FileProviderBridgeError, InvalidTask, StateError, UnsafePath, ValueError) as error:
            try:
                _send_json_frame(
                    connection,
                    {
                        "schema": BRIDGE_SCHEMA,
                        "ok": False,
                        "error": type(error).__name__,
                        "message": str(error)[:1_000],
                    },
                )
            except OSError:
                pass
        except (OSError, json.JSONDecodeError):
            pass
        finally:
            connection.close()
            self._connections.release()

    @staticmethod
    def _require_same_user(connection: socket.socket) -> None:
        getpeereid = getattr(connection, "getpeereid", None)
        if callable(getpeereid):
            peer_uid, _peer_gid = getpeereid()
            if peer_uid != os.getuid():
                raise FileProviderBridgeError("the File Provider peer user is invalid")
            return
        so_peercred = getattr(socket, "SO_PEERCRED", None)
        if so_peercred is not None:
            credentials = connection.getsockopt(socket.SOL_SOCKET, so_peercred, 12)
            _pid, peer_uid, _peer_gid = struct.unpack("3i", credentials)
            if peer_uid != os.getuid():
                raise FileProviderBridgeError("the File Provider peer user is invalid")

    def _dispatch(self, connection: socket.socket, request: Mapping[str, Any]) -> None:
        operation = request.get("operation")
        if operation == "status":
            head = self.database.get_remote_manifest_head()
            self._reply(
                connection,
                workspace=self.workspace_name,
                generation=head.generation if head is not None else None,
                manifest_digest=head.digest if head is not None else None,
            )
            return
        if operation == "enumerate":
            self._enumerate(connection, request)
            return
        if operation == "resolve":
            identifier = _opaque_identifier(request.get("identifier"))
            self._reply(connection, item=self._resolve_item(identifier))
            return
        if operation == "lookup_child":
            self._lookup_child(connection, request)
            return
        if operation == "item":
            virtual_path = _virtual_path(request.get("path"))
            self._reply(connection, item=self._item(virtual_path))
            return
        if operation == "fetch":
            self._fetch(connection, request)
            return
        if operation == "write":
            self._write(connection, request)
            return
        if operation == "write_fd":
            self._write_file_provider_descriptor(connection, request)
            return
        if operation == "create_directory":
            self._create_directory(connection, request)
            return
        if operation == "delete":
            self._delete(connection, request)
            return
        if operation == "completed_delete":
            self._completed_delete(connection, request)
            return
        if operation == "move":
            self._move(connection, request)
            return
        raise FileProviderBridgeError("the File Provider operation is unsupported")

    def _reply(self, connection: socket.socket, **fields: Any) -> None:
        _send_json_frame(connection, {"schema": BRIDGE_SCHEMA, "ok": True, **fields})

    def _enumerate(self, connection: socket.socket, request: Mapping[str, Any]) -> None:
        container_identifier = request.get("container_identifier")
        if container_identifier is None:
            container = _virtual_path(request.get("container", ""), allow_root=True)
        else:
            container = self._path_for_identifier(
                _opaque_identifier(container_identifier), require_kind="directory"
            )
        limit = _bounded_integer(request.get("limit", 200), 1, 999, "limit")
        after = request.get("after_name")
        if after is not None and not isinstance(after, str):
            raise FileProviderBridgeError("after_name must be a string or null")
        head = self.database.get_remote_manifest_head()
        generation = head.generation if head is not None else None
        manifest_digest = head.digest if head is not None else None
        requested_generation = _optional_generation(request.get("generation"))
        if requested_generation is not None and requested_generation != generation:
            raise FileProviderConflict(
                "the File Provider enumeration generation advanced"
            )
        if container == "":
            items = [self._workspace_item()] if after in (None, "") else []
            self._reply(
                connection,
                items=items,
                next_after_name=None,
                has_more=False,
                generation=generation,
                manifest_digest=manifest_digest,
            )
            return
        remote_parent = self._remote_path(container, allow_workspace_root=True)
        children = self.database.list_remote_children(
            remote_parent, after_name=after, limit=limit + 1
        )
        page = children[:limit]
        _send_json_frame(
            connection,
            _fit_enumeration_response(
                {
                    "schema": BRIDGE_SCHEMA,
                    "ok": True,
                    "items": [self._child_item(child) for child in page],
                    "next_after_name": (
                        page[-1].name if len(children) > limit and page else None
                    ),
                    "has_more": len(children) > limit,
                    "generation": generation,
                    "manifest_digest": manifest_digest,
                }
            ),
        )

    def _resolve_item(self, identifier: str) -> dict[str, Any]:
        path = self._path_for_identifier(identifier)
        item = self._item(path)
        if item["identifier"] != identifier:
            raise FileProviderNotFound("the File Provider item identity is stale")
        return item

    def _path_for_identifier(
        self, identifier: str, *, require_kind: str | None = None
    ) -> str:
        if identifier == "root":
            if require_kind not in (None, "directory"):
                raise FileProviderBridgeError("the File Provider item kind changed")
            return ""
        resolved = self._identities.resolve(self._authority_key(), identifier)
        if resolved is None:
            raise FileProviderNotFound("the File Provider item does not exist")
        path, kind = resolved
        if require_kind is not None and kind != require_kind:
            raise FileProviderBridgeError("the File Provider item kind changed")
        return path

    def _item(self, virtual_path: str) -> dict[str, Any]:
        if virtual_path == "":
            return self._root_item()
        if virtual_path == self.workspace_name:
            return self._workspace_item()
        remote_path = self._remote_path(virtual_path)
        receipted = self.database.get_receipted_entry(remote_path)
        entry = (
            receipted.entry
            if receipted is not None
            else self.database.get_remote_entry(remote_path)
        )
        if entry is not None:
            return self._file_item(entry)
        if self._directory_exists(remote_path):
            return self._directory_item(remote_path)
        pending = self.database.get_latest_nonterminal_operation(remote_path)
        if (
            pending is not None
            and pending.kind == "rename"
            and pending.destination_path == remote_path
            and not pending.directory_rename
        ):
            source = self.database.get_remote_entry(pending.path)
            if source is not None and source.digest is not None:
                return self._file_item_values(
                    remote_path,
                    size_bytes=source.size_bytes,
                    digest=source.digest,
                    modified=source.modified,
                    pending=True,
                )
        local = self.workspace.hash_regular_file(remote_path)
        if pending is not None and pending.kind == "put" and local is not None:
            return self._file_item_values(
                remote_path,
                size_bytes=local.fingerprint.size_bytes,
                digest=local.sha256,
                modified=None,
                pending=True,
            )
        self._identities.retire(self._authority_key(), virtual_path)
        raise FileProviderNotFound("the File Provider item does not exist")

    def _lookup_child(
        self, connection: socket.socket, request: Mapping[str, Any]
    ) -> None:
        """Resolve an exact durable child for File Provider create replay.

        ``.mayAlreadyExist`` is not permission to invent an item from a cached
        path.  The parent identity must still resolve and the child must exist
        in the receipted/remote Fabric namespace with the requested kind.
        """

        parent_identifier = _opaque_identifier(request.get("parent_identifier"))
        parent = self._resolve_item(parent_identifier)
        if parent["kind"] != "directory":
            raise FileProviderNotFound("the File Provider parent does not exist")
        filename = request.get("filename")
        if not isinstance(filename, str) or len(split_relative(filename)) != 1:
            raise FileProviderBridgeError(
                "filename must be one portable path component"
            )
        requested_kind = request.get("kind")
        if requested_kind not in ("file", "directory"):
            raise FileProviderBridgeError("kind must be file or directory")
        parent_path = str(parent["path"])
        virtual_path = f"{parent_path}/{filename}" if parent_path else filename
        remote_path = self._remote_path(virtual_path)
        receipted = self.database.get_receipted_entry(remote_path)
        entry = (
            receipted.entry
            if receipted is not None
            else self.database.get_remote_entry(remote_path)
        )
        file_exists = entry is not None
        directory_exists = self._durable_directory_exists(remote_path)
        if requested_kind == "file" and file_exists:
            self._reply(connection, item=self._file_item(entry))
            return
        if requested_kind == "directory" and directory_exists:
            self._reply(connection, item=self._directory_item(remote_path))
            return
        if file_exists or directory_exists:
            raise FileProviderCollision(
                "a different item kind already owns the File Provider name"
            )
        raise FileProviderNotFound("the File Provider child does not exist")

    def _durable_directory_exists(self, remote_path: str) -> bool:
        _head, tombstones = self.database.local_directory_tombstone_snapshot()
        if any(
            remote_path == removed or remote_path.startswith(removed + "/")
            for removed in tombstones
        ):
            return False
        return self.database.is_remote_directory(remote_path) or bool(
            self.database.list_remote_children(remote_path, limit=1)
        )

    def _directory_exists(self, remote_path: str) -> bool:
        _head, tombstones = self.database.local_directory_tombstone_snapshot()
        if any(
            remote_path == removed or remote_path.startswith(removed + "/")
            for removed in tombstones
        ) and not self.workspace.directory_exists(remote_path):
            return False
        if (
            self.database.is_remote_directory(remote_path)
            or bool(self.database.list_remote_children(remote_path, limit=1))
            or self.workspace.directory_exists(remote_path)
        ):
            return True
        pending = self.database.get_latest_nonterminal_operation(remote_path)
        if (
            pending is not None
            and pending.kind == "rename"
            and pending.destination_path == remote_path
            and pending.directory_rename
        ):
            return True
        for queued in reversed(self.database.list_directory_puts(limit=1_000)):
            if queued.path == remote_path:
                return queued.kind != "delete"
            if queued.destination_path == remote_path:
                return queued.kind == "rename"
        return False

    def _fetch(self, connection: socket.socket, request: Mapping[str, Any]) -> None:
        virtual_path = self._request_virtual_path(
            request, path_field="path", require_kind="file"
        )
        remote_path = self._remote_path(virtual_path)
        receipted = self.database.get_receipted_entry(remote_path)
        entry = (
            receipted.entry
            if receipted is not None
            else self.database.get_remote_entry(remote_path)
        )
        if entry is None:
            raise FileProviderNotFound("the remote file does not exist")
        offset = _bounded_integer(request.get("offset"), 0, entry.size_bytes, "offset")
        length = _bounded_integer(request.get("length"), 0, MAX_FETCH_BYTES, "length")
        if offset + length > entry.size_bytes:
            raise FileProviderBridgeError("the requested range exceeds the remote file")
        stream = iter(self.coordinator.stream(
            remote_path, offset=offset, length=length, expected_digest=entry.digest,
        ))
        received = 0
        stream_closed = False

        def close_stream() -> None:
            nonlocal stream_closed
            if not stream_closed:
                stream_closed = True
                close = getattr(stream, "close", None)
                if close is not None:
                    close()

        def validate(chunk: bytes) -> bytes:
            nonlocal received
            if not isinstance(chunk, bytes) or received + len(chunk) > length:
                raise StateError("the Fabric range stream violated its byte bound")
            received += len(chunk)
            return chunk

        payload_started = False
        try:
            try:
                # Surface preflight failures as metadata before declaring a payload.
                pending = validate(next(stream, b""))
                if not pending and length:
                    raise StateError("the Fabric range stream ended early")
                if length == 0:
                    # A zero-byte reader cannot detect EOF as failure. Complete
                    # every generator validation before acknowledging it.
                    for chunk in stream:
                        validate(chunk)
                    close_stream()
                payload_started = True
                _send_json_frame(
                    connection,
                    {
                        "schema": BRIDGE_SCHEMA,
                        "ok": True,
                        "payload_bytes": length,
                        "content_version": entry.digest,
                    },
                )
                for chunk in stream:
                    chunk = validate(chunk)
                    if not chunk:
                        continue
                    connection.sendall(pending)
                    pending = chunk
                if received != length:
                    raise StateError("the Fabric range stream ended early")
                close_stream()
                # Retain the final bounded chunk until exhaustion has executed
                # the coordinator's trailing identity fence. Otherwise a reader
                # could accept all declared bytes before a late failure.
                connection.sendall(pending)
            finally:
                close_stream()
        except Exception as error:
            if payload_started:
                # After success metadata, EOF is the only valid failure signal.
                # Let the handler close instead of appending a JSON error frame
                # that the native client would interpret as document contents.
                raise ConnectionAbortedError("the Fabric payload stream failed") from error
            raise

    def _write(self, connection: socket.socket, request: Mapping[str, Any]) -> None:
        if request.get("identifier") is not None:
            virtual_path = self._request_virtual_path(
                request, path_field="path", require_kind="file"
            )
        elif request.get("parent_identifier") is not None:
            virtual_path = self._destination_virtual_path(request)
        else:
            virtual_path = _virtual_path(request.get("path"))
        remote_path = self._remote_path(virtual_path)
        size = _bounded_integer(request.get("payload_bytes"), 0, MAX_WRITE_BYTES, "payload_bytes")
        digest = request.get("content_sha256")
        if not isinstance(digest, str) or RAW_SHA256_RE.fullmatch(digest) is None:
            raise FileProviderBridgeError("content_sha256 is invalid")
        base = _optional_digest(request.get("base_digest"), "base_digest")
        replaces_path_value = request.get("replaces_path")
        replaces_identifier_value = request.get("replaces_identifier")
        replaces_digest_value = request.get("replaces_digest")
        if replaces_path_value is not None and replaces_identifier_value is not None:
            raise FileProviderBridgeError(
                "replaces_path and replaces_identifier are mutually exclusive"
            )
        if (
            (replaces_path_value is None and replaces_identifier_value is None)
            != (replaces_digest_value is None)
        ):
            raise FileProviderBridgeError(
                "a replacement item and replaces_digest must be supplied together"
            )
        replaces: tuple[str, str] | None = None
        if replaces_path_value is not None or replaces_identifier_value is not None:
            replaces_virtual = (
                self._path_for_identifier(
                    _opaque_identifier(replaces_identifier_value),
                    require_kind="file",
                )
                if replaces_identifier_value is not None
                else _virtual_path(replaces_path_value)
            )
            replaces_path = self._remote_path(replaces_virtual)
            replaces_digest = _required_digest(
                replaces_digest_value, "replaces_digest"
            )
            if replaces_path == remote_path:
                raise FileProviderBridgeError("a write cannot replace its own path")
            replaces = (replaces_path, replaces_digest)
        remote = self.database.get_remote_entry(remote_path)
        authority_key = self._authority_key()
        self._identities.identity_for(authority_key, virtual_path, "file")
        observed = remote.digest if remote is not None else None
        if observed != base:
            if base is None and remote is not None:
                raise FileProviderCollision(
                    "the File Provider file destination already exists"
                )
            raise FileProviderConflict("the remote file advanced before write")
        if self.database.get_latest_nonterminal_operation(remote_path) is not None:
            raise FileProviderConflict("the local file already has a pending mutation")
        replace_fingerprint: FileFingerprint | None = None
        if replaces is not None:
            replaces_path, replaces_digest = replaces
            source_remote = self.database.get_remote_entry(replaces_path)
            if source_remote is None or source_remote.digest != replaces_digest:
                raise FileProviderConflict("the replaced remote file advanced")
            if self.database.get_latest_nonterminal_operation(replaces_path) is not None:
                raise FileProviderConflict("the replaced file already has a pending mutation")
            replace_fingerprint = self.workspace.stat_fingerprint(replaces_path)
            if replace_fingerprint is not None:
                replace_materialized = self.database.get_materialized(replaces_path)
                if (
                    replace_materialized is None
                    or replace_materialized.state != "clean"
                    or replace_materialized.clean_digest != replaces_digest
                ):
                    raise FileProviderConflict("the replaced local file advanced")
        existing = self.workspace.stat_fingerprint(remote_path)
        materialized = self.database.get_materialized(remote_path)
        expected_existing: str | None = None
        if existing is not None:
            if (
                remote is None
                or materialized is None
                or materialized.state != "clean"
                or materialized.clean_digest != remote.digest
            ):
                raise FileProviderConflict("the local working-set file advanced")
            expected_existing = f"sha256:{remote.digest}"
        chunks = _socket_payload(connection, size)
        self.workspace.write_stream(
            remote_path,
            chunks,
            expected_size=size,
            expected_sha256=f"sha256:{digest}",
            create_parents=True,
            overwrite=True,
            expected_existing_sha256=expected_existing,
        )
        if replaces is not None and replace_fingerprint is not None:
            self.workspace.remove_file(
                replaces[0],
                expected_sha256=f"sha256:{replaces[1]}",
                expected_fingerprint=replace_fingerprint,
            )
        transition_id: str | None = None
        if replaces is not None:
            replaced_virtual = f"{self.workspace_name}/{replaces[0]}"
            self._identities.identity_for(authority_key, replaced_virtual, "file")
            transition_id = self._identities.begin_move(
                authority_key,
                replaced_virtual,
                virtual_path,
                recursive=False,
            )
        try:
            queued = self.coordinator.stage_file_provider_write(
                remote_path,
                expected_source_digest=base,
                delete_after_ack=replaces,
            )
        except BaseException:
            if transition_id is not None:
                self._identities.cancel_move(transition_id)
            raise
        if transition_id is not None:
            self._identities.complete_move(transition_id)
        item = self._file_item_values(
            remote_path,
            size_bytes=size,
            digest=digest,
            modified=None,
            pending=True,
        )
        self._reply(
            connection,
            queued=True,
            mutation_id=(queued.mutation_id if queued is not None else None),
            content_version=digest,
            item=item,
        )

    def _write_file_provider_descriptor(
        self, connection: socket.socket, request: Mapping[str, Any]
    ) -> None:
        """Upload the system-owned contents inode without a working-set copy."""

        descriptor = _receive_file_descriptor(connection)
        held_receipts: tuple[str, ...] = ()
        try:
            if request.get("identifier") is not None:
                identifier = _opaque_identifier(request.get("identifier"))
                virtual_path = self._path_for_identifier(
                    identifier, require_kind="file"
                )
            elif request.get("parent_identifier") is not None:
                virtual_path = self._destination_virtual_path(request)
                identifier = self._identities.identity_for(
                    self._authority_key(), virtual_path, "file"
                )
            else:
                raise FileProviderBridgeError(
                    "the File Provider write target is missing"
                )
            remote_path = self._remote_path(virtual_path)
            size = _bounded_integer(
                request.get("payload_bytes"), 0, MAX_WRITE_BYTES, "payload_bytes"
            )
            base = _optional_digest(request.get("base_digest"), "base_digest")
            metadata_version = _optional_metadata_version(
                request.get("base_metadata_version")
            )
            modified_at = _optional_modified_at(request.get("modified_at"))

            replaces_identifier_value = request.get("replaces_identifier")
            replaces_digest_value = request.get("replaces_digest")
            if (replaces_identifier_value is None) != (replaces_digest_value is None):
                raise FileProviderBridgeError(
                    "replaces_identifier and replaces_digest must be supplied together"
                )
            replaces: tuple[str, str] | None = None
            replaced_virtual: str | None = None
            completed_replay: _CompoundWriteReplay | None = None
            if replaces_identifier_value is not None:
                replaces_identifier = _opaque_identifier(replaces_identifier_value)
                replaced_virtual = self._path_for_identifier(
                    replaces_identifier, require_kind="file"
                )
                replaces_path = self._remote_path(replaced_virtual)
                replaces_digest = _required_digest(
                    replaces_digest_value, "replaces_digest"
                )
                if replaces_path == remote_path:
                    completed_replay = self._completed_compound_write_replay(
                        replaces_identifier,
                        virtual_path,
                        replaces_digest,
                        metadata_version,
                    )
                    if completed_replay is None:
                        raise FileProviderBridgeError(
                            "a write cannot replace its own path"
                        )
                    replaced_virtual = completed_replay.source_path
                    replaces_path = self._remote_path(replaced_virtual)
                replaces = (replaces_path, replaces_digest)
                identifier = replaces_identifier
            elif request.get("identifier") is not None and base is not None:
                completed_replay = self._completed_compound_write_replay(
                    identifier,
                    virtual_path,
                    base,
                    metadata_version,
                )
                if completed_replay is not None:
                    replaced_virtual = completed_replay.source_path
                    replaces = (
                        self._remote_path(completed_replay.source_path),
                        completed_replay.base_digest,
                    )

            if completed_replay is not None:
                current_receipt = self.database.get_receipted_entry(remote_path)
                current = (
                    current_receipt.entry
                    if current_receipt is not None
                    else self.database.get_remote_entry(remote_path)
                )
                put_replay = self.database.get_operation(
                    completed_replay.put_mutation_id
                )
                still_committing = (
                    put_replay is not None
                    and put_replay.kind == "put"
                    and put_replay.path == remote_path
                    and put_replay.state in {"queued", "inflight", "retry"}
                )
                if not still_committing and (
                    current is None
                    or current.digest != completed_replay.result_digest
                    or current.size_bytes != completed_replay.result_size
                    or _optional_modified_at(current.modified)
                    != completed_replay.result_modified_at
                ):
                    raise FileProviderConflict(
                        "the completed File Provider write was superseded"
                    )

            def validate_new_write() -> None:
                target_receipt = self.database.get_receipted_entry(remote_path)
                target_entry = (
                    target_receipt.entry
                    if target_receipt is not None
                    else self.database.get_remote_entry(remote_path)
                )
                if base is None and target_entry is not None:
                    raise FileProviderCollision(
                        "the File Provider file destination already exists"
                    )
                if (target_entry.digest if target_entry is not None else None) != base:
                    raise FileProviderConflict(
                        "the remote file advanced before write"
                    )
                replaced_entry: RemoteEntry | None = None
                if replaces is not None:
                    replaced_receipt = self.database.get_receipted_entry(replaces[0])
                    replaced_entry = (
                        replaced_receipt.entry
                        if replaced_receipt is not None
                        else self.database.get_remote_entry(replaces[0])
                    )
                    if replaced_entry is None or replaced_entry.digest != replaces[1]:
                        raise FileProviderConflict("the replaced remote file advanced")
                metadata_entry = (
                    replaced_entry if replaces is not None else target_entry
                )
                if metadata_version is not None and (
                    metadata_entry is None
                    or self._file_item(metadata_entry)["metadata_version"]
                    != metadata_version
                ):
                    raise FileProviderConflict(
                        "the remote file metadata advanced before write"
                    )

                invalidated: dict[str, None] = {}
                cached_paths = (
                    ((remote_path, target_entry.digest),)
                    if target_entry is not None
                    else ()
                ) + (((replaces[0], replaces[1]),) if replaces is not None else ())
                for cache_path, expected_digest in cached_paths:
                    fingerprint = self.workspace.stat_fingerprint(cache_path)
                    if fingerprint is None:
                        continue
                    materialized = self.database.get_materialized(cache_path)
                    if (
                        materialized is None
                        or materialized.state != "clean"
                        or materialized.clean_digest != expected_digest
                    ):
                        raise FileProviderConflict(
                            "the local working-set file advanced"
                        )
                    self.workspace.remove_file(
                        cache_path,
                        expected_sha256=f"sha256:{expected_digest}",
                        expected_fingerprint=fingerprint,
                    )
                    invalidated[cache_path] = None
                if invalidated:
                    self.coordinator.watch.acknowledge_local_state(invalidated)

            idempotency_document = {
                "authority": self._authority_key(),
                "identifier": identifier,
                "base_content_version": base,
                "base_metadata_version": metadata_version,
                "destination": virtual_path,
                "replaces_identifier": replaces_identifier_value,
                "replaces_digest": replaces_digest_value,
                "modified_at": modified_at,
            }
            idempotency_key = hashlib.sha256(
                json.dumps(
                    idempotency_document,
                    sort_keys=True,
                    separators=(",", ":"),
                    allow_nan=False,
                ).encode("utf-8")
            ).hexdigest()

            transition_id: str | None = None
            if replaces is not None and replaced_virtual is not None:
                if completed_replay is None:
                    transition_id = self._identities.begin_move(
                        self._authority_key(),
                        replaced_virtual,
                        virtual_path,
                        recursive=False,
                    )
            try:
                operation, plan = self.coordinator.stage_file_provider_descriptor(
                    remote_path,
                    descriptor,
                    idempotency_key=idempotency_key,
                    expected_source_digest=base,
                    expected_size=size,
                    delete_after_ack=replaces,
                    validate_new=validate_new_write,
                    is_cancelled=lambda: self._stopped.is_set()
                    or _connection_closed(connection),
                    modified_at=modified_at,
                    item_identifier=identifier,
                    base_metadata_version=metadata_version,
                    replay_base_digest=(replaces[1] if replaces is not None else base),
                    replay_mutation_ids=(
                        (
                            completed_replay.put_mutation_id,
                            completed_replay.delete_mutation_id,
                        )
                        if completed_replay is not None
                        else None
                    ),
                )
            except BaseException:
                if transition_id is not None:
                    self._identities.cancel_move(transition_id)
                raise

            delete_mutation_id = plan.delete_after_ack_mutation_id
            held_receipts = tuple(
                value
                for value in (operation.mutation_id, delete_mutation_id)
                if value is not None
            )
            try:
                self._wait_for_file_provider_receipt(
                    connection,
                    operation.mutation_id,
                    delete_mutation_id=delete_mutation_id,
                    # Before journaling, EOF cancels hashing.  After the
                    # durable mutation exists, abandoning this worker would
                    # strand compound identity transitions and permit later
                    # cleanup to diverge from an eventually committed write.
                    # Finish the exact receipt(s); the dead socket only means
                    # the result must be replayed on Apple's next callback.
                    cancel_on_disconnect=False,
                )
            except BaseException:
                self.coordinator.release_file_provider_source(
                    operation.mutation_id
                )
                raise
            receipted = self.database.get_receipted_entry(remote_path)
            receipted_modified = (
                receipted.entry.modified
                if receipted is not None
                and receipted.mutation_id == operation.mutation_id
                and receipted.entry is not None
                else modified_at
            )
            if transition_id is not None:
                assert replaces is not None and replaced_virtual is not None
                assert delete_mutation_id is not None
                self._identities.complete_move(
                    transition_id,
                    compound_replay=_CompoundWriteReplay(
                        identifier=identifier,
                        source_path=replaced_virtual,
                        destination_path=virtual_path,
                        base_digest=replaces[1],
                        base_metadata_version=metadata_version,
                        result_digest=plan.sha256,
                        result_size=plan.size_bytes,
                        result_modified_at=receipted_modified,
                        put_mutation_id=operation.mutation_id,
                        delete_mutation_id=delete_mutation_id,
                    ),
                )
            item = self._file_item_values(
                remote_path,
                size_bytes=plan.size_bytes,
                digest=plan.sha256,
                modified=receipted_modified,
                pending=False,
            )
            self._reply(
                connection,
                queued=False,
                mutation_id=operation.mutation_id,
                content_version=plan.sha256,
                item=item,
            )
        finally:
            if held_receipts:
                # The socket cannot prove Apple's completion callback ran. Keep
                # compact deterministic replay evidence until a newer remote
                # item version supersedes this result.
                self.coordinator.detach_file_provider_receipts(*held_receipts)
            os.close(descriptor)

    def _wait_for_file_provider_receipt(
        self,
        connection: socket.socket,
        mutation_id: str,
        *,
        delete_mutation_id: str | None,
        cancel_on_disconnect: bool = True,
    ) -> None:
        """Hold Apple's callback source until all remote effects are receipted."""

        connection_open = True
        while not self._stopped.wait(0.05):
            readable = (
                select.select([connection], [], [], 0)[0]
                if connection_open
                else []
            )
            if readable:
                try:
                    if not connection.recv(1, socket.MSG_PEEK | socket.MSG_DONTWAIT):
                        if cancel_on_disconnect:
                            raise FileProviderBridgeError(
                                "the File Provider write was cancelled"
                            )
                        connection_open = False
                except BlockingIOError:
                    pass
            operation = self.database.get_operation(mutation_id)
            if operation is None:
                raise StateError("the File Provider mutation disappeared")
            if operation.state in ("conflict", "quarantined"):
                raise FileProviderConflict(
                    operation.last_error
                    or "the File Provider write could not be committed"
                )
            if self.database.get_receipt(mutation_id) is None:
                continue
            if delete_mutation_id is not None:
                deletion = self.database.get_operation(delete_mutation_id)
                if deletion is None or self.database.get_receipt(delete_mutation_id) is None:
                    if deletion is not None and deletion.state in (
                        "conflict",
                        "quarantined",
                    ):
                        raise FileProviderConflict(
                            deletion.last_error
                            or "the File Provider rename delete could not be committed"
                        )
                    continue
            return
        raise FileProviderBridgeError("the File Provider bridge stopped during write")

    def _wait_for_file_provider_namespace_receipt(
        self,
        connection: socket.socket,
        mutation_id: str,
        *,
        cancel_on_disconnect: bool = False,
        durable_delete_path: str | None = None,
    ) -> None:
        """Wait for the exact v2 directory receipt, never mere queueing."""

        connection_open = True
        while not self._stopped.wait(0.05):
            readable = (
                select.select([connection], [], [], 0)[0]
                if connection_open
                else []
            )
            if readable:
                try:
                    if not connection.recv(
                        1, socket.MSG_PEEK | socket.MSG_DONTWAIT
                    ):
                        if cancel_on_disconnect:
                            raise FileProviderBridgeError(
                                "the File Provider namespace mutation was cancelled"
                            )
                        connection_open = False
                except BlockingIOError:
                    pass
            result = self.coordinator.file_provider_namespace_receipt(
                mutation_id
            )
            if result is None:
                if durable_delete_path is not None:
                    if self.database.has_queued_directory_delete(
                        durable_delete_path
                    ):
                        # Another identical callback may have released the
                        # process-local waiter while this durable row remains.
                        self.coordinator.retain_file_provider_namespace_receipt(
                            mutation_id
                        )
                        continue
                    conflict = self.database.get_conflict_by_evidence_key(
                        f"directory-operation:{mutation_id}"
                    )
                    if conflict is not None:
                        raise FileProviderConflict(conflict.reason)
                    # The exact row left the queue without conflict evidence:
                    # only the acknowledged directory commit does that.
                    return
                raise StateError(
                    "the File Provider namespace receipt waiter disappeared"
                )
            state, error = result
            if state == "acked":
                return
            if state == "conflict":
                raise FileProviderConflict(
                    error or "the File Provider namespace mutation was rejected"
                )
        raise FileProviderBridgeError(
            "the File Provider bridge stopped during namespace mutation"
        )

    def _create_directory(
        self, connection: socket.socket, request: Mapping[str, Any]
    ) -> None:
        virtual_path = self._destination_virtual_path(request)
        remote_path = self._remote_path(virtual_path)
        parent = remote_path.rpartition("/")[0]
        if parent and not self._directory_exists(parent):
            raise FileProviderNotFound(
                "the File Provider directory parent does not exist"
            )
        if self.database.get_remote_entry(remote_path) is not None or self._directory_exists(
            remote_path
        ):
            raise FileProviderCollision(
                "the File Provider directory destination already exists"
            )
        self.workspace.create_directory(remote_path, create_parents=True)
        queued: Any | None = None
        try:
            queued = self.coordinator.stage_local_directory(
                remote_path, retain_file_provider_receipt=True
            )
            if queued is None:
                raise FileProviderBridgeError(
                    "durable directory publication is unavailable"
                )
        except BaseException:
            try:
                self.workspace.remove_empty_directory(remote_path)
            except (InvalidTask, OSError, UnsafePath):
                pass
            raise
        try:
            self._wait_for_file_provider_namespace_receipt(
                connection, queued.mutation_id
            )
        except BaseException:
            self.coordinator.release_file_provider_namespace_receipt(
                queued.mutation_id
            )
            raise
        item = self._directory_item(remote_path)
        item["pending"] = False
        try:
            self._reply(
                connection,
                queued=False,
                mutation_id=queued.mutation_id,
                item=item,
            )
        finally:
            self.coordinator.release_file_provider_namespace_receipt(
                queued.mutation_id
            )

    def _completed_delete(
        self, connection: socket.socket, request: Mapping[str, Any]
    ) -> None:
        """Replay only an exact, durably completed delete for one retired ID."""

        self._reconcile_identity_deletions()
        identifier = _opaque_identifier(request.get("identifier"))
        recursive = request.get("recursive", False)
        if not isinstance(recursive, bool):
            raise FileProviderBridgeError("recursive must be a boolean")
        completed = self._identities.completed_delete(
            self._authority_key(), identifier
        )
        if completed is None:
            raise FileProviderNotFound(
                "the completed File Provider delete does not exist"
            )
        _path, mutation_id, completed_recursive = completed
        if completed_recursive != recursive:
            raise FileProviderConflict(
                "the completed File Provider delete recursion mode changed"
            )
        self._reply(
            connection,
            queued=False,
            mutation_id=mutation_id,
            deleted_identifier=identifier,
        )

    def _delete(self, connection: socket.socket, request: Mapping[str, Any]) -> None:
        self._reconcile_identity_deletions()
        recursive = request.get("recursive", False)
        if not isinstance(recursive, bool):
            raise FileProviderBridgeError("recursive must be a boolean")
        request_identifier = request.get("identifier")
        if request_identifier is not None:
            identifier = _opaque_identifier(request_identifier)
            completed = self._identities.completed_delete(
                self._authority_key(), identifier
            )
            if completed is not None:
                _path, mutation_id, completed_recursive = completed
                if completed_recursive != recursive:
                    raise FileProviderConflict(
                        "the completed File Provider delete recursion mode changed"
                    )
                self._reply(
                    connection,
                    queued=False,
                    mutation_id=mutation_id,
                    deleted_identifier=identifier,
                )
                return
        virtual_path = self._request_virtual_path(request, path_field="path")
        remote_path = self._remote_path(virtual_path)
        requested_kind = request.get("kind")
        base_metadata_version = _optional_metadata_version(
            request.get("base_metadata_version")
        )
        if requested_kind not in (None, "file", "directory"):
            raise FileProviderBridgeError("kind must be file or directory")
        remote = self.database.get_remote_entry(remote_path)
        is_directory = remote is None and self._directory_exists(remote_path)
        if requested_kind == "directory" or is_directory:
            if requested_kind == "file":
                raise FileProviderConflict("the File Provider item kind changed")
            self._delete_directory(
                connection,
                remote_path,
                virtual_path,
                base_metadata_version=base_metadata_version,
                recursive=recursive,
            )
            return
        if requested_kind == "directory":
            raise FileProviderConflict("the File Provider item kind changed")
        base = _required_digest(request.get("base_digest"), "base_digest")
        deletion_id, identifier, existing_mutation = self._identities.begin_delete(
            self._authority_key(), virtual_path, kind="file", recursive=False
        )
        if existing_mutation is not None:
            self.coordinator.retain_file_provider_receipts(existing_mutation)
            try:
                self._wait_for_file_provider_receipt(
                    connection,
                    existing_mutation,
                    delete_mutation_id=None,
                    cancel_on_disconnect=False,
                )
                self._identities.complete_delete(deletion_id)
                self._reply(
                    connection,
                    queued=False,
                    mutation_id=existing_mutation,
                    deleted_identifier=identifier,
                )
            except FileProviderConflict:
                self._identities.cancel_delete(deletion_id)
                raise
            finally:
                self.coordinator.release_file_provider_receipts(existing_mutation)
            return

        try:
            if remote is None:
                raise FileProviderNotFound("the remote file does not exist")
            if remote.digest != base:
                raise FileProviderConflict("the remote file advanced before delete")
            if (
                base_metadata_version is not None
                and self._file_item(remote)["metadata_version"]
                != base_metadata_version
            ):
                raise FileProviderConflict(
                    "the remote file metadata advanced before delete"
                )
            if self.database.get_latest_nonterminal_operation(remote_path) is not None:
                raise FileProviderConflict(
                    "the local file already has a pending mutation"
                )
            fingerprint = self.workspace.stat_fingerprint(remote_path)
            if fingerprint is not None:
                materialized = self.database.get_materialized(remote_path)
                if (
                    materialized is None
                    or materialized.state != "clean"
                    or materialized.clean_digest != base
                ):
                    raise FileProviderConflict("the local working-set file advanced")
                self.workspace.remove_file(
                    remote_path,
                    expected_sha256=f"sha256:{base}",
                    expected_fingerprint=fingerprint,
                )
            queued = self.coordinator.stage_local_state(
                remote_path, retain_file_provider_receipt=True
            )
            if queued is None:
                raise FileProviderBridgeError(
                    "the File Provider delete was not journaled"
                )
            self._identities.bind_delete_mutation(deletion_id, queued.mutation_id)
        except BaseException:
            self._identities.cancel_delete(deletion_id)
            raise
        try:
            self._wait_for_file_provider_receipt(
                connection,
                queued.mutation_id,
                delete_mutation_id=None,
                cancel_on_disconnect=False,
            )
            self._identities.complete_delete(deletion_id)
            self._reply(
                connection,
                queued=False,
                mutation_id=queued.mutation_id,
                deleted_identifier=identifier,
            )
        except FileProviderConflict:
            self._identities.cancel_delete(deletion_id)
            raise
        finally:
            self.coordinator.release_file_provider_receipts(queued.mutation_id)

    def _delete_directory(
        self,
        connection: socket.socket,
        remote_path: str,
        virtual_path: str,
        *,
        base_metadata_version: str | None,
        recursive: bool,
    ) -> None:
        replay = self._replayed_directory_delete_mutation(
            remote_path, virtual_path, recursive=recursive
        )
        if replay is not None:
            deletion_id, replay_mutation_id, identifier = replay
            self._finish_replayed_directory_delete(
                connection,
                remote_path,
                virtual_path,
                deletion_id,
                replay_mutation_id,
                identifier,
            )
            return
        if not self._directory_exists(remote_path):
            raise FileProviderNotFound("the File Provider directory does not exist")
        if not recursive and self.database.list_remote_children(remote_path, limit=1):
            raise FileProviderConflict("the File Provider directory is not empty")
        if (
            base_metadata_version is not None
            and self._directory_item(remote_path)["metadata_version"]
            != base_metadata_version
        ):
            raise FileProviderConflict(
                "the remote directory metadata advanced before delete"
            )
        if recursive:
            self._delete_directory_recursive(
                connection,
                remote_path,
                virtual_path,
            )
            return
        if self.workspace.directory_exists(remote_path):
            try:
                local_entries, truncated = self.workspace.list(
                    remote_path, max_entries=1, recursive=False
                )
            except (InvalidTask, OSError, UnsafePath) as error:
                raise FileProviderBridgeError(
                    "the File Provider directory could not be verified empty"
                ) from error
            if local_entries or truncated:
                raise FileProviderConflict("the File Provider directory is not empty")
        authority = self.database.current_authority()
        if authority is None:
            raise FileProviderBridgeError("the workspace authority is unavailable")
        head = self.database.get_remote_manifest_head()
        deletion_id, identity, _existing_mutation = self._identities.begin_delete(
            self._authority_key(), virtual_path, kind="directory", recursive=False
        )
        removed_local = False
        if self.workspace.directory_exists(remote_path):
            try:
                self.workspace.remove_empty_directory(remote_path)
            except BaseException:
                self._identities.cancel_delete(deletion_id)
                raise
            removed_local = True
        stored = self.database.mark_local_directory_removed(
            remote_path,
            expected_generation=(head.generation if head is not None else None),
            expected_manifest_digest=(head.digest if head is not None else None),
            expected_scope_id=authority.scope_id,
        )
        if not stored:
            self._identities.cancel_delete(deletion_id)
            if removed_local:
                try:
                    self.workspace.create_directory(remote_path, create_parents=True)
                except (OSError, UnsafePath):
                    pass
            raise FileProviderConflict(
                "the File Provider directory advanced before delete"
            )
        mutation_id = self.database.directory_delete_mutation_id(remote_path)
        if mutation_id is None or not self.database.has_queued_directory_delete(
            remote_path
        ):
            self._identities.cancel_delete(deletion_id)
            self.database.forget_local_directory_tombstone(remote_path)
            if removed_local:
                self.workspace.create_directory(remote_path, create_parents=True)
            raise StateError("the File Provider directory delete was not journaled")
        self._identities.bind_delete_mutation(deletion_id, mutation_id)
        self.coordinator.retain_file_provider_namespace_receipt(mutation_id)
        wake = getattr(self.coordinator, "wake", None)
        if callable(wake):
            wake()
        try:
            self._wait_for_file_provider_namespace_receipt(
                connection,
                mutation_id,
                durable_delete_path=remote_path,
            )
            self._identities.complete_delete(deletion_id)
            self._reply(
                connection,
                queued=False,
                mutation_id=mutation_id,
                deleted_identifier=identity,
            )
        except FileProviderConflict:
            self._identities.cancel_delete(deletion_id)
            if removed_local and not self.workspace.directory_exists(remote_path):
                try:
                    self.workspace.create_directory(remote_path, create_parents=True)
                except (OSError, UnsafePath):
                    pass
            raise
        finally:
            self.coordinator.release_file_provider_namespace_receipt(mutation_id)

    def _replayed_directory_delete_mutation(
        self,
        remote_path: str,
        virtual_path: str,
        *,
        recursive: bool,
    ) -> tuple[str, str, str] | None:
        """Return only the exact durable delete journal for this directory.

        A process restart loses the coordinator's in-memory waiter map, but the
        exact-head tombstone and its deterministic mutation identifier remain
        in SQLite.  An arbitrary missing path is never accepted as a replay.
        """

        _head, tombstones = self.database.local_directory_tombstone_snapshot()
        if remote_path not in tombstones:
            return None
        mutation_id = self.database.directory_delete_mutation_id(remote_path)
        if mutation_id is None:
            raise StateError("the File Provider directory tombstone lost its journal")
        self._raise_directory_delete_conflict(mutation_id)
        deletion_id, identifier, existing_mutation = self._identities.begin_delete(
            self._authority_key(), virtual_path,
            kind="directory", recursive=recursive
        )
        if existing_mutation not in (None, mutation_id):
            raise FileProviderConflict(
                "the File Provider delete journal identity changed"
            )
        self._identities.bind_delete_mutation(deletion_id, mutation_id)
        return deletion_id, mutation_id, identifier

    def _finish_replayed_directory_delete(
        self,
        connection: socket.socket,
        remote_path: str,
        virtual_path: str,
        deletion_id: str,
        mutation_id: str,
        identifier: str,
    ) -> None:
        try:
            self._raise_directory_delete_conflict(mutation_id)
            if self.database.has_queued_directory_delete(remote_path):
                self.coordinator.retain_file_provider_namespace_receipt(mutation_id)
                wake = getattr(self.coordinator, "wake", None)
                if callable(wake):
                    wake()
                try:
                    self._wait_for_file_provider_namespace_receipt(
                        connection,
                        mutation_id,
                        durable_delete_path=remote_path,
                    )
                finally:
                    self.coordinator.release_file_provider_namespace_receipt(
                        mutation_id
                    )
            # Close the race where a queued replay reached terminal conflict
            # between its waiter completing and identity retirement.
            self._raise_directory_delete_conflict(mutation_id)
        except FileProviderConflict:
            self._identities.cancel_delete(deletion_id)
            raise
        self._identities.complete_delete(deletion_id)
        self._reply(
            connection,
            queued=False,
            mutation_id=mutation_id,
            deleted_identifier=identifier,
        )

    def _raise_directory_delete_conflict(self, mutation_id: str) -> None:
        conflict = self.database.get_conflict_by_evidence_key(
            f"directory-operation:{mutation_id}"
        )
        if conflict is not None:
            raise FileProviderConflict(conflict.reason)

    def _delete_directory_recursive(
        self,
        connection: socket.socket,
        remote_path: str,
        virtual_path: str,
    ) -> None:
        """Delete one exact remote subtree without materializing its contents."""

        if self.database.list_nonterminal_operations_touching_prefix(
            remote_path, limit=1
        ):
            raise FileProviderConflict(
                "the File Provider directory has pending file mutations"
            )
        authority = self.database.current_authority()
        if authority is None:
            raise FileProviderBridgeError("the workspace authority is unavailable")
        head = self.database.get_remote_manifest_head()
        if head is None or head.digest is not None:
            raise FileProviderBridgeError(
                "durable recursive directory publication is unavailable"
            )
        remote_entries = self.database.list_remote_entries(
            prefix=remote_path, limit=_MAX_RECURSIVE_DELETE_ITEMS + 1
        )
        receipted_entries = self.database.list_receipted_entries(
            remote_path, limit=_MAX_RECURSIVE_DELETE_ITEMS
        )
        explicit_directories = self.database.list_remote_directories(
            prefix=remote_path, limit=_MAX_RECURSIVE_DELETE_ITEMS + 1
        )
        if (
            len(remote_entries) > _MAX_RECURSIVE_DELETE_ITEMS
            or len(explicit_directories) > _MAX_RECURSIVE_DELETE_ITEMS
        ):
            raise FileProviderBridgeError(
                "the File Provider recursive delete exceeds its item bound"
            )
        entries_by_path = {entry.path: entry for entry in remote_entries}
        for receipted in receipted_entries:
            if receipted.entry is None:
                entries_by_path.pop(receipted.path, None)
            else:
                entries_by_path[receipted.path] = receipted.entry
        entries = tuple(entries_by_path.values())
        files = tuple(entry for entry in entries if entry.digest is not None)
        directories = {remote_path, *explicit_directories}
        for entry in entries:
            cursor = entry.path.rpartition("/")[0]
            while cursor == remote_path or cursor.startswith(remote_path + "/"):
                directories.add(cursor)
                if cursor == remote_path:
                    break
                cursor = cursor.rpartition("/")[0]
        if len(files) + len(directories) > _MAX_RECURSIVE_DELETE_ITEMS:
            raise FileProviderBridgeError(
                "the File Provider recursive delete exceeds its item bound"
            )

        local_directories: set[str] = set()
        local_fingerprints: dict[str, FileFingerprint] = {}
        if self.workspace.directory_exists(remote_path):
            try:
                local_entries, truncated = self.workspace.list(
                    remote_path,
                    max_entries=_MAX_RECURSIVE_DELETE_ITEMS + 1,
                    recursive=True,
                )
            except (InvalidTask, OSError, UnsafePath) as error:
                raise FileProviderBridgeError(
                    "the File Provider directory could not be verified"
                ) from error
            if truncated or len(local_entries) > _MAX_RECURSIVE_DELETE_ITEMS:
                raise FileProviderBridgeError(
                    "the File Provider recursive delete exceeds its item bound"
                )
            files_by_path = {entry.path: entry for entry in files}
            for relative in local_entries:
                local_path = f"{remote_path}/{relative.rstrip('/')}"
                if relative.endswith("/"):
                    local_directories.add(local_path)
                    continue
                remote = files_by_path.get(local_path)
                fingerprint = self.workspace.stat_fingerprint(local_path)
                materialized = self.database.get_materialized(local_path)
                if (
                    remote is None
                    or fingerprint is None
                    or materialized is None
                    or materialized.state != "clean"
                    or materialized.clean_digest != remote.digest
                ):
                    raise FileProviderConflict(
                        "the File Provider directory contains unsynchronized local items"
                    )
                local_fingerprints[local_path] = fingerprint
            local_directories.add(remote_path)

        ordered_directories = sorted(
            directories,
            key=lambda path: (-path.count("/"), path),
        )
        deletion_id, identifier, _existing_mutation = self._identities.begin_delete(
            self._authority_key(), virtual_path, kind="directory", recursive=True
        )
        file_mutations: list[str] = []
        directory_mutations: list[tuple[str, str]] = []
        root_mutation_bound = False
        root_mutation_id: str | None = None
        try:
            # Fence the namespace first. The coordinator does not wake until
            # every exact child delete has been journaled, and its directory
            # FIFO refuses to publish a parent while file deletes remain.
            for directory in ordered_directories:
                stored = self.database.mark_local_directory_removed(
                    directory,
                    expected_generation=(head.generation if head is not None else None),
                    expected_manifest_digest=(head.digest if head is not None else None),
                    expected_scope_id=authority.scope_id,
                )
                if not stored:
                    raise FileProviderConflict(
                        "the File Provider directory advanced before recursive delete"
                    )
                mutation_id = self.database.directory_delete_mutation_id(directory)
                if mutation_id is None or not self.database.has_queued_directory_delete(
                    directory
                ):
                    raise StateError(
                        "the File Provider directory delete was not journaled"
                    )
                self.coordinator.retain_file_provider_namespace_receipt(mutation_id)
                directory_mutations.append((directory, mutation_id))
                if directory == remote_path:
                    self._identities.bind_delete_mutation(
                        deletion_id, mutation_id
                    )
                    root_mutation_bound = True
                    root_mutation_id = mutation_id

            for remote in sorted(files, key=lambda item: item.path):
                fingerprint = local_fingerprints.get(remote.path)
                if fingerprint is not None:
                    try:
                        self.workspace.remove_file(
                            remote.path,
                            expected_sha256=f"sha256:{remote.digest}",
                            expected_fingerprint=fingerprint,
                        )
                    except (InvalidTask, OSError, UnsafePath) as error:
                        raise FileProviderConflict(
                            "the local working-set file advanced"
                        ) from error
                queued = self.coordinator.stage_local_state(
                    remote.path, retain_file_provider_receipt=True
                )
                if queued is None:
                    raise FileProviderBridgeError(
                        "the File Provider child delete was not journaled"
                    )
                file_mutations.append(queued.mutation_id)

            for directory in sorted(
                local_directories,
                key=lambda path: (-path.count("/"), path),
            ):
                if not self.workspace.directory_exists(directory):
                    continue
                try:
                    self.workspace.remove_empty_directory(directory)
                except (InvalidTask, OSError, UnsafePath) as error:
                    raise FileProviderConflict(
                        "the local directory advanced during recursive delete"
                    ) from error

            wake = getattr(self.coordinator, "wake", None)
            if callable(wake):
                wake()
            for mutation_id in file_mutations:
                self._wait_for_file_provider_receipt(
                    connection,
                    mutation_id,
                    delete_mutation_id=None,
                    cancel_on_disconnect=False,
                )
            for _directory, mutation_id in directory_mutations:
                self._wait_for_file_provider_namespace_receipt(
                    connection,
                    mutation_id,
                    durable_delete_path=_directory,
                )
            self._identities.complete_delete(deletion_id)
            self._reply(
                connection,
                queued=False,
                mutation_id=directory_mutations[-1][1],
                deleted_identifier=identifier,
            )
        except FileProviderConflict:
            if (
                root_mutation_id is not None
                and self.database.get_conflict_by_evidence_key(
                    f"directory-operation:{root_mutation_id}"
                )
                is not None
            ):
                self._identities.cancel_delete(deletion_id)
            raise
        finally:
            if not root_mutation_bound:
                self._identities.cancel_delete(deletion_id)
            if file_mutations or directory_mutations:
                wake = getattr(self.coordinator, "wake", None)
                if callable(wake):
                    wake()
            for mutation_id in file_mutations:
                self.coordinator.release_file_provider_receipts(mutation_id)
            for _directory, mutation_id in directory_mutations:
                self.coordinator.release_file_provider_namespace_receipt(mutation_id)

    def _move(self, connection: socket.socket, request: Mapping[str, Any]) -> None:
        source_virtual = self._request_virtual_path(
            request,
            path_field="source_path",
            identifier_field="identifier",
        )
        destination_virtual = self._destination_virtual_path(
            request, path_field="destination_path"
        )
        source = self._remote_path(source_virtual)
        destination = self._remote_path(destination_virtual)
        requested_kind = request.get("kind")
        base_metadata_version = _optional_metadata_version(
            request.get("base_metadata_version")
        )
        if requested_kind not in (None, "file", "directory"):
            raise FileProviderBridgeError("kind must be file or directory")
        if requested_kind == "directory" or (
            requested_kind is None
            and self.database.get_remote_entry(source) is None
            and self._directory_exists(source)
        ):
            self._move_directory(
                connection,
                source,
                destination,
                source_virtual,
                destination_virtual,
                base_metadata_version=base_metadata_version,
            )
            return
        source_digest = _required_digest(request.get("source_digest"), "source_digest")
        destination_digest = _optional_digest(
            request.get("destination_digest"), "destination_digest"
        )
        source_entry = self.database.get_remote_entry(source)
        destination_entry = self.database.get_remote_entry(destination)
        if source_entry is None:
            raise FileProviderNotFound("the remote rename source does not exist")
        if source_entry.digest != source_digest:
            raise FileProviderConflict("the remote rename source advanced")
        if (
            base_metadata_version is not None
            and self._file_item(source_entry)["metadata_version"]
            != base_metadata_version
        ):
            raise FileProviderConflict(
                "the remote file metadata advanced before rename"
            )
        observed_destination = (
            destination_entry.digest if destination_entry is not None else None
        )
        if observed_destination != destination_digest:
            if destination_digest is None and destination_entry is not None:
                raise FileProviderCollision(
                    "the File Provider rename destination already exists"
                )
            raise FileProviderConflict("the remote rename destination advanced")
        authority_key = self._authority_key()
        self._identities.identity_for(authority_key, source_virtual, "file")
        transition_id = self._identities.begin_move(
            authority_key,
            source_virtual,
            destination_virtual,
            recursive=False,
        )
        queued: Any | None = None
        try:
            source_fingerprint = self.workspace.stat_fingerprint(source)
            if source_fingerprint is not None:
                materialized = self.database.get_materialized(source)
                if (
                    materialized is None
                    or materialized.state != "clean"
                    or materialized.clean_digest != source_digest
                    or self.workspace.stat_fingerprint(destination) is not None
                ):
                    raise FileProviderConflict("the local rename paths advanced")
                self.workspace.rename_file(
                    source,
                    destination,
                    expected_sha256=f"sha256:{source_digest}",
                    create_parents=True,
                )
                self.coordinator.stage_local_rename(source, destination)
                queued = self.database.get_latest_nonterminal_operation(source)
                if queued is not None:
                    self.coordinator.retain_file_provider_receipts(
                        queued.mutation_id
                    )
            else:
                queued = self.coordinator.stage_metadata_rename(
                    source,
                    destination,
                    expected_source_digest=source_digest,
                    expected_destination_digest=destination_digest,
                    retain_file_provider_receipt=True,
                )
        except BaseException:
            if queued is not None:
                self.coordinator.release_file_provider_receipts(
                    queued.mutation_id
                )
            self._identities.cancel_move(transition_id)
            raise
        if queued is None:
            self._identities.cancel_move(transition_id)
            raise FileProviderBridgeError("the File Provider rename was not journaled")
        try:
            self._wait_for_file_provider_receipt(
                connection,
                queued.mutation_id,
                delete_mutation_id=None,
                cancel_on_disconnect=False,
            )
        except FileProviderConflict:
            self.coordinator.release_file_provider_receipts(queued.mutation_id)
            self._identities.cancel_move(transition_id)
            raise
        except BaseException:
            self.coordinator.release_file_provider_receipts(queued.mutation_id)
            raise
        self._identities.complete_move(transition_id)
        item = self._file_item_values(
            destination,
            size_bytes=source_entry.size_bytes,
            digest=str(source_entry.digest),
            modified=source_entry.modified,
            pending=False,
        )
        try:
            self._reply(
                connection,
                queued=False,
                mutation_id=queued.mutation_id,
                item=item,
            )
        finally:
            self.coordinator.release_file_provider_receipts(queued.mutation_id)

    def _move_directory(
        self,
        connection: socket.socket,
        source: str,
        destination: str,
        source_virtual: str,
        destination_virtual: str,
        *,
        base_metadata_version: str | None,
    ) -> None:
        if destination == source or destination.startswith(source + "/"):
            raise FileProviderBridgeError("a directory cannot be moved inside itself")
        if not self._directory_exists(source):
            raise FileProviderNotFound("the File Provider directory does not exist")
        if (
            base_metadata_version is not None
            and self._directory_item(source)["metadata_version"]
            != base_metadata_version
        ):
            raise FileProviderConflict(
                "the remote directory metadata advanced before rename"
            )
        if self.database.get_remote_entry(destination) is not None or self._directory_exists(
            destination
        ):
            raise FileProviderCollision(
                "the File Provider directory destination already exists"
            )
        parent = destination.rpartition("/")[0]
        if parent and not self._directory_exists(parent):
            raise FileProviderNotFound(
                "the File Provider directory parent does not exist"
            )
        authority_key = self._authority_key()
        self._identities.identity_for(authority_key, source_virtual, "directory")
        transition_id = self._identities.begin_move(
            authority_key,
            source_virtual,
            destination_virtual,
            recursive=True,
        )
        queued: Any | None = None
        namespace_receipt = False
        try:
            try:
                queued = self.coordinator.stage_metadata_directory_rename(
                    source,
                    destination,
                    retain_file_provider_receipt=True,
                )
            except InvalidTask as error:
                if "source is missing" not in str(error):
                    raise
                self.workspace.create_directory(destination, create_parents=True)
                try:
                    queued = self.coordinator.stage_local_directory_rename(
                        source,
                        destination,
                        retain_file_provider_receipt=True,
                    )
                    namespace_receipt = True
                    if self.workspace.directory_exists(source):
                        self.workspace.remove_empty_directory(source)
                except BaseException:
                    try:
                        self.workspace.remove_empty_directory(destination)
                    except (InvalidTask, OSError, UnsafePath):
                        pass
                    raise
        except BaseException:
            if queued is not None:
                if namespace_receipt:
                    self.coordinator.release_file_provider_namespace_receipt(
                        queued.mutation_id
                    )
                else:
                    self.coordinator.release_file_provider_receipts(
                        queued.mutation_id
                    )
            self._identities.cancel_move(transition_id)
            raise
        if queued is None:
            self._identities.cancel_move(transition_id)
            raise FileProviderBridgeError(
                "the File Provider directory rename was not journaled"
            )
        try:
            if namespace_receipt:
                self._wait_for_file_provider_namespace_receipt(
                    connection, queued.mutation_id
                )
            else:
                self._wait_for_file_provider_receipt(
                    connection,
                    queued.mutation_id,
                    delete_mutation_id=None,
                    cancel_on_disconnect=False,
                )
        except FileProviderConflict:
            if namespace_receipt:
                self.coordinator.release_file_provider_namespace_receipt(
                    queued.mutation_id
                )
            else:
                self.coordinator.release_file_provider_receipts(queued.mutation_id)
            self._identities.cancel_move(transition_id)
            raise
        except BaseException:
            if namespace_receipt:
                self.coordinator.release_file_provider_namespace_receipt(
                    queued.mutation_id
                )
            else:
                self.coordinator.release_file_provider_receipts(queued.mutation_id)
            raise
        self._identities.complete_move(transition_id)
        item = self._directory_item(destination)
        item["pending"] = False
        try:
            self._reply(
                connection,
                queued=False,
                mutation_id=queued.mutation_id,
                item=item,
            )
        finally:
            if namespace_receipt:
                self.coordinator.release_file_provider_namespace_receipt(
                    queued.mutation_id
                )
            else:
                self.coordinator.release_file_provider_receipts(queued.mutation_id)

    def _remote_path(
        self, virtual_path: str, *, allow_workspace_root: bool = False
    ) -> str | None:
        if virtual_path == self.workspace_name:
            if allow_workspace_root:
                return None
            raise FileProviderBridgeError("the workspace root is not a file")
        prefix = self.workspace_name + "/"
        if not virtual_path.startswith(prefix):
            raise FileProviderBridgeError("the item belongs to another workspace")
        remote = virtual_path[len(prefix) :]
        split_relative(remote)
        return remote

    def _request_virtual_path(
        self,
        request: Mapping[str, Any],
        *,
        path_field: str,
        identifier_field: str = "identifier",
        require_kind: str | None = None,
    ) -> str:
        identifier = request.get(identifier_field)
        if identifier is not None:
            return self._path_for_identifier(
                _opaque_identifier(identifier), require_kind=require_kind
            )
        return _virtual_path(request.get(path_field))

    def _destination_virtual_path(
        self,
        request: Mapping[str, Any],
        *,
        path_field: str = "path",
    ) -> str:
        parent_identifier = request.get("destination_parent_identifier")
        if parent_identifier is None:
            parent_identifier = request.get("parent_identifier")
        if parent_identifier is None:
            return _virtual_path(request.get(path_field))
        parent = self._path_for_identifier(
            _opaque_identifier(parent_identifier), require_kind="directory"
        )
        filename = request.get("filename")
        if not isinstance(filename, str) or len(split_relative(filename)) != 1:
            raise FileProviderBridgeError(
                "filename must be one portable path component"
            )
        return f"{parent}/{filename}" if parent else filename

    def _root_item(self) -> dict[str, Any]:
        return {
            "identifier": "root",
            "parent_identifier": None,
            "filename": "Meshia",
            "path": "",
            "kind": "directory",
            "size_bytes": 0,
            "content_version": "root",
            "metadata_version": "root-v1",
            "pending": False,
        }

    def _workspace_item(self) -> dict[str, Any]:
        identifier = self._identities.identity_for(
            self._authority_key(), self.workspace_name, "directory"
        )
        return {
            "identifier": identifier,
            "parent_identifier": "root",
            "filename": self.workspace_name,
            "path": self.workspace_name,
            "kind": "directory",
            "size_bytes": 0,
            "content_version": identifier,
            "metadata_version": _metadata_version(
                identifier, "root", self.workspace_name, "directory", 0, None
            ),
            "pending": False,
        }

    def _child_item(self, child: RemoteChild) -> dict[str, Any]:
        return (
            self._directory_item(child.path)
            if child.is_directory
            else self._file_item(
                RemoteEntry(
                    child.path,
                    child.size_bytes,
                    str(child.digest),
                    child.modified,
                )
            )
        )

    def _directory_item(self, remote_path: str) -> dict[str, Any]:
        virtual = f"{self.workspace_name}/{remote_path}"
        authority_key = self._authority_key()
        identifier = self._identities.identity_for(
            authority_key, virtual, "directory"
        )
        parent_path = _parent_virtual_path(virtual)
        parent_identifier = self._identities.identity_for(
            authority_key, parent_path, "directory"
        )
        filename = remote_path.rsplit("/", 1)[-1]
        pending = any(
            queued.path == remote_path or queued.destination_path == remote_path
            for queued in self.database.list_directory_puts(limit=1_000)
        ) or self.database.get_latest_nonterminal_operation(remote_path) is not None
        return {
            "identifier": identifier,
            "parent_identifier": parent_identifier,
            "filename": filename,
            "path": virtual,
            "kind": "directory",
            "size_bytes": 0,
            "content_version": identifier,
            "metadata_version": _metadata_version(
                identifier,
                parent_identifier,
                filename,
                "directory",
                0,
                None,
            ),
            "pending": pending,
        }

    def _file_item(self, entry: RemoteEntry) -> dict[str, Any]:
        if entry.digest is None:
            raise StateError("the File Provider file has no content digest")
        return self._file_item_values(
            entry.path,
            size_bytes=entry.size_bytes,
            digest=entry.digest,
            modified=entry.modified,
            pending=(
                self.database.get_latest_nonterminal_operation(entry.path) is not None
            ),
        )

    def _file_item_values(
        self,
        remote_path: str,
        *,
        size_bytes: int,
        digest: str,
        modified: str | None,
        pending: bool,
    ) -> dict[str, Any]:
        modified = _optional_modified_at(modified)
        virtual = f"{self.workspace_name}/{remote_path}"
        authority_key = self._authority_key()
        identifier = self._identities.identity_for(authority_key, virtual, "file")
        parent_path = _parent_virtual_path(virtual)
        parent_identifier = self._identities.identity_for(
            authority_key, parent_path, "directory"
        )
        filename = remote_path.rsplit("/", 1)[-1]
        materialized = self.database.get_materialized(remote_path)
        return {
            "identifier": identifier,
            "parent_identifier": parent_identifier,
            "filename": filename,
            "path": virtual,
            "kind": "file",
            "size_bytes": size_bytes,
            "content_version": digest,
            "metadata_version": _metadata_version(
                identifier,
                parent_identifier,
                filename,
                "file",
                size_bytes,
                modified,
            ),
            "modified_at": modified,
            "locally_materialized": bool(
                materialized is not None and materialized.bytes_on_disk > 0
            ),
            "pending": pending,
        }


def _virtual_path(value: object, *, allow_root: bool = False) -> str:
    if value == "" and allow_root:
        return ""
    if not isinstance(value, str):
        raise FileProviderBridgeError("path must be a string")
    return "/".join(split_relative(value))


def _parent_virtual_path(path: str) -> str:
    parts = split_relative(path)
    return "/".join(parts[:-1])


def _metadata_version(
    identifier: str,
    parent_identifier: str,
    filename: str,
    kind: str,
    size: int,
    modified: str | None,
) -> str:
    return hashlib.sha256(
        f"{identifier}\0{parent_identifier}\0{filename}\0{kind}\0{size}\0{modified or ''}".encode(
            "utf-8"
        )
    ).hexdigest()


def _opaque_identifier(value: object) -> str:
    if (
        not isinstance(value, str)
        or len(value) > 128
        or (value != "root" and not value.startswith("item-"))
        or any(not character.isascii() or not character.isprintable() for character in value)
    ):
        raise FileProviderBridgeError("the File Provider identifier is invalid")
    return value


def _bounded_integer(value: object, minimum: int, maximum: int, field: str) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not minimum <= value <= maximum
    ):
        raise FileProviderBridgeError(
            f"{field} must be between {minimum} and {maximum}"
        )
    return value


def _optional_generation(value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise FileProviderBridgeError("generation must be a non-negative integer or null")
    return value


def _required_digest(value: object, field: str) -> str:
    if not isinstance(value, str) or RAW_SHA256_RE.fullmatch(value) is None:
        raise FileProviderBridgeError(f"{field} is invalid")
    return value


def _optional_digest(value: object, field: str) -> str | None:
    return None if value is None else _required_digest(value, field)


def _optional_metadata_version(value: object) -> str | None:
    if value is None:
        return None
    if (
        not isinstance(value, str)
        or not value
        or len(value.encode("utf-8")) > 1_024
    ):
        raise FileProviderBridgeError("base_metadata_version is invalid")
    return value


def _optional_modified_at(value: object) -> str | None:
    try:
        return _normalized_modified_at(value)
    except ValueError as error:
        raise FileProviderBridgeError(str(error)) from None


def _receive_json_frame(connection: socket.socket) -> Mapping[str, Any]:
    length = struct.unpack(">I", _receive_exact(connection, 4))[0]
    if not 2 <= length <= MAX_REQUEST_BYTES:
        raise FileProviderBridgeError("the File Provider request is too large")
    document = json.loads(_receive_exact(connection, length).decode("utf-8"))
    if not isinstance(document, Mapping):
        raise FileProviderBridgeError("the File Provider request is not an object")
    return document


def _receive_file_descriptor(connection: socket.socket) -> int:
    """Receive exactly one system-owned contents FD after a write request."""

    if fcntl is None or not hasattr(connection, "recvmsg"):
        raise FileProviderBridgeError(
            "native File Provider descriptor transfer is unavailable"
        )
    integer_bytes = array.array("i").itemsize
    payload, ancillary, flags, _address = connection.recvmsg(
        1, socket.CMSG_SPACE(integer_bytes)
    )
    descriptors: list[int] = []
    selected: int | None = None
    try:
        if payload != b"F" or flags & getattr(socket, "MSG_CTRUNC", 0):
            raise FileProviderBridgeError(
                "the File Provider descriptor frame is invalid"
            )
        for level, kind, data in ancillary:
            if level != socket.SOL_SOCKET or kind != socket.SCM_RIGHTS:
                continue
            values = array.array("i")
            values.frombytes(data[: len(data) - (len(data) % integer_bytes)])
            descriptors.extend(int(value) for value in values)
        if len(descriptors) != 1:
            raise FileProviderBridgeError(
                "the File Provider must supply exactly one descriptor"
            )
        selected = descriptors.pop()
        info = os.fstat(selected)
        if not stat.S_ISREG(info.st_mode):
            raise FileProviderBridgeError(
                "the File Provider descriptor is not a regular file"
            )
        access = fcntl.fcntl(selected, fcntl.F_GETFL) & os.O_ACCMODE
        if access != os.O_RDONLY:
            raise FileProviderBridgeError(
                "the File Provider descriptor must be read-only"
            )
        os.set_inheritable(selected, False)
        descriptor = selected
        selected = None
        return descriptor
    finally:
        if selected is not None:
            descriptors.append(selected)
        for descriptor in descriptors:
            try:
                os.close(descriptor)
            except OSError:
                pass


def _connection_closed(connection: socket.socket) -> bool:
    """Non-destructively detect File Provider cancellation during FD planning."""

    try:
        if not select.select([connection], [], [], 0)[0]:
            return False
        return not connection.recv(1, socket.MSG_PEEK | socket.MSG_DONTWAIT)
    except BlockingIOError:
        return False
    except OSError:
        return True


def _json_document_bytes(document: Mapping[str, Any]) -> bytes:
    return json.dumps(
        document, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _fit_enumeration_response(document: Mapping[str, Any]) -> dict[str, Any]:
    """Fit one ordered enumeration prefix inside the metadata frame budget."""

    result = dict(document)
    if len(_json_document_bytes(result)) <= MAX_RESPONSE_METADATA_BYTES:
        return result

    items = result.get("items")
    if not isinstance(items, list) or not items:
        raise FileProviderBridgeError("the File Provider response is too large")

    original_has_more = result.get("has_more") is True
    original_next_after_name = result.get("next_after_name")
    for item in items:
        if not isinstance(item, Mapping) or not isinstance(item.get("filename"), str):
            raise FileProviderBridgeError(
                "the File Provider enumeration item is invalid"
            )
    item_sizes = tuple(len(_json_document_bytes(item)) for item in items)
    selected_count = 0
    selected_items_bytes = 0
    for index, item in enumerate(items):
        candidate_count = index + 1
        candidate_has_more = original_has_more or candidate_count < len(items)
        candidate_next_after_name = (
            item["filename"] if candidate_has_more else original_next_after_name
        )
        base = {
            **result,
            "items": [],
            "has_more": candidate_has_more,
            "next_after_name": candidate_next_after_name,
        }
        selected_items_bytes += item_sizes[index]
        if candidate_count > 1:
            selected_items_bytes += 1  # JSON comma between adjacent items.
        candidate_size = len(_json_document_bytes(base)) + selected_items_bytes
        if candidate_size > MAX_RESPONSE_METADATA_BYTES:
            break
        selected_count = candidate_count

    if selected_count == 0:
        raise FileProviderBridgeError("the File Provider response is too large")
    selected = items[:selected_count]
    result["items"] = selected
    result["has_more"] = original_has_more or selected_count < len(items)
    result["next_after_name"] = (
        selected[-1]["filename"]
        if result["has_more"]
        else original_next_after_name
    )
    if len(_json_document_bytes(result)) > MAX_RESPONSE_METADATA_BYTES:
        raise FileProviderBridgeError("the File Provider response is too large")
    return result


def _send_json_frame(connection: socket.socket, document: Mapping[str, Any]) -> None:
    payload = _json_document_bytes(document)
    if len(payload) > MAX_RESPONSE_METADATA_BYTES:
        raise FileProviderBridgeError("the File Provider response is too large")
    connection.sendall(struct.pack(">I", len(payload)) + payload)


def _receive_exact(connection: socket.socket, size: int) -> bytes:
    result = bytearray()
    while len(result) < size:
        chunk = connection.recv(size - len(result))
        if not chunk:
            raise FileProviderBridgeError("the File Provider request ended early")
        result.extend(chunk)
    return bytes(result)


def _socket_payload(connection: socket.socket, size: int) -> Iterator[bytes]:
    remaining = size
    while remaining:
        chunk = connection.recv(min(STREAM_CHUNK_BYTES, remaining))
        if not chunk:
            raise FileProviderBridgeError("the File Provider content ended early")
        remaining -= len(chunk)
        yield chunk
