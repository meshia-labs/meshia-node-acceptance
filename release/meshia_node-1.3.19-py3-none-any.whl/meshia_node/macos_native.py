"""Own native macOS commands in separate launchd coalitions.

Sessions and process groups do not survive ordinary double-fork/setsid as an
ownership boundary. A transient launchd job supplies an isolated kernel
coalition. Its signed Meshia host preserves TCC responsibility; a private Unix
socket transfers command streams without putting environment values in a plist.
This changes no command permissions. Only limited mode installs Seatbelt.

The small libproc adapter uses Apple's published XNU proc_info_private.h layouts
(flavors 17 and 20), and the public proc_signal_with_audittoken function. The
kernel validates the PID version when signaling, including across PID reuse.
An unavailable API or unexpected layout prevents execution, never a fallback.
"""
from __future__ import annotations

import array
import ctypes
from dataclasses import dataclass
import errno
import json
import os
from pathlib import Path
import plistlib
import re
import select
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import uuid


class OwnershipUnavailable(RuntimeError):
    pass


class _Unique(ctypes.Structure):
    _fields_ = [("uuid", ctypes.c_ubyte * 16), ("unique", ctypes.c_uint64),
                ("parent_unique", ctypes.c_uint64), ("version", ctypes.c_int32),
                ("parent_version", ctypes.c_int32), ("reserved", ctypes.c_uint64 * 2)]


class _Coalition(ctypes.Structure):
    _fields_ = [("ids", ctypes.c_uint64 * 2), ("reserved", ctypes.c_uint64 * 3)]


@dataclass(frozen=True)
class Identity:
    pid: int
    unique: int
    version: int
    coalition: tuple[int, int]


class Kernel:
    def __init__(self):
        if sys.platform != "darwin":
            raise OwnershipUnavailable("macOS command ownership is unavailable on this OS")
        try:
            self.library = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
            self.info = self.library.proc_pidinfo
            self.info.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64,
                                  ctypes.c_void_p, ctypes.c_int]
            self.info.restype = ctypes.c_int
            self.list = self.library.proc_listpids
            self.list.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_int]
            self.list.restype = ctypes.c_int
            self.send = self.library.proc_signal_with_audittoken
            self.send.argtypes = [ctypes.c_void_p, ctypes.c_int]
            self.send.restype = ctypes.c_int
        except (AttributeError, OSError) as error:
            raise OwnershipUnavailable("Native compute requires macOS 14.2 or later with kernel process identity signaling") from error
        if ctypes.sizeof(_Unique) != 56 or ctypes.sizeof(_Coalition) != 40:
            raise OwnershipUnavailable("Unsupported macOS process identity layout")
        self.own = self.identity(os.getpid())
        if self.own is None or not all(self.own.coalition):
            raise OwnershipUnavailable("macOS did not provide kernel command ownership")

    def _read(self, pid, flavor, shape):
        result = shape()
        ctypes.set_errno(0)
        size = self.info(pid, flavor, 0, ctypes.byref(result), ctypes.sizeof(result))
        if size == 0 and ctypes.get_errno() == errno.ESRCH:
            return None
        if size != ctypes.sizeof(result):
            raise OwnershipUnavailable("macOS process ownership information is unavailable or has an unsupported shape")
        return result

    def identity(self, pid: int) -> Identity | None:
        before = self._read(pid, 17, _Unique)
        coalition = self._read(pid, 20, _Coalition)
        after = self._read(pid, 17, _Unique)
        if before is None or coalition is None or after is None:
            return None
        if (before.unique, before.version) != (after.unique, after.version):
            return None
        return Identity(pid, after.unique, after.version, tuple(coalition.ids))

    def members(self, coalition: tuple[int, int]) -> list[Identity]:
        # Same-user compute cannot acquire authority to signal another account.
        needed = self.list(4, os.getuid(), None, 0)
        if needed <= 0:
            raise OwnershipUnavailable("macOS could not enumerate owned command processes")
        while True:
            buffer = (ctypes.c_int * (needed // 4 + 128))()
            used = self.list(4, os.getuid(), buffer, ctypes.sizeof(buffer))
            if used < 0 or used % 4:
                raise OwnershipUnavailable("macOS returned invalid process membership")
            if used < ctypes.sizeof(buffer):
                break
            needed = used * 2
        members = []
        for pid in buffer[:used // 4]:
            if pid <= 1:
                continue
            identity = self.identity(pid)
            if identity is not None and identity.coalition == coalition:
                members.append(identity)
        return members

    def signal(self, identity: Identity, number: int) -> bool:
        # XNU's signal API resolves PID+pidversion from the audit token, then
        # checks the actual caller's signal permission. No synthetic UID grants.
        token = (ctypes.c_uint32 * 8)()
        token[5], token[7] = identity.pid, identity.version
        ctypes.set_errno(0)
        if self.send(ctypes.byref(token), number) != 0:
            if ctypes.get_errno() == errno.ESRCH:
                return False  # Exited or execed; the next membership read sees it.
            raise OwnershipUnavailable("macOS refused to stop an owned command process")
        return True

    def stop(self, coalition: tuple[int, int], *, exclude: set[int] = frozenset()) -> None:
        if coalition == self.own.coalition and os.getpid() not in exclude:
            raise OwnershipUnavailable("Refusing to stop the caller's process coalition")
        frozen: dict[tuple[int, int, int], Identity] = {}
        # Freeze all members before killing any ancestor. Once a pass discovers
        # no new identities, no member can fork or exec; daemonization and fast
        # reparenting cannot escape this kernel membership boundary.
        try:
            for _ in range(64):
                new = [item for item in self.members(coalition)
                       if item.pid not in exclude and (item.pid, item.unique, item.version) not in frozen]
                if not new:
                    break
                for item in new:
                    if self.signal(item, signal.SIGSTOP):
                        frozen[(item.pid, item.unique, item.version)] = item
            else:
                raise OwnershipUnavailable("macOS command processes could not be stopped")
        finally:
            # A failed later membership read must not leave already frozen
            # descendants behind. Attempt every pinned identity even if one
            # process has changed its OS signal permissions.
            failure = None
            for item in frozen.values():
                try:
                    self.signal(item, signal.SIGKILL)
                except OwnershipUnavailable as error:
                    failure = error
            if failure is not None:
                raise failure


def host_command(path: Path) -> list[str]:
    from .native_host import account_home, discover_host
    # Python3.12 preserves the installer's runtime selector in sys.prefix.
    # Verify the selected immutable runtime, retaining all ownership, mode and
    # Apple distribution checks; the selector itself is deliberately a symlink.
    runtime = Path(sys.prefix).resolve(strict=True)
    executable = discover_host(runtime / "bin" / "meshia", account_home() / ".meshia")
    if executable is None:
        raise OwnershipUnavailable("Native compute requires the verified Meshia Node app installed by the terminal installer")
    return [str(executable), "--command", str(path)]


def readiness() -> tuple[bool, str]:
    try:
        Kernel()
        host_command(Path("/private/tmp/meshia-ownership-readiness.sock"))
    except (OwnershipUnavailable, OSError, ValueError) as error:
        return False, str(error)
    return True, "Native macOS compute with verified command process ownership"


def _frame(connection: socket.socket, value: dict) -> None:
    data = json.dumps(value).encode()
    if len(data) > 1_048_576:
        raise OwnershipUnavailable("Native command setup exceeds its bound")
    connection.sendall(len(data).to_bytes(4, "big") + data)


def _receive(connection: socket.socket) -> dict:
    def exact(size):
        data = bytearray()
        while len(data) < size:
            chunk = connection.recv(size - len(data))
            if not chunk:
                raise EOFError("Native command owner disconnected")
            data.extend(chunk)
        return bytes(data)
    size = int.from_bytes(exact(4), "big")
    if not 2 <= size <= 1_048_576:
        raise OwnershipUnavailable("Invalid native command setup size")
    result = json.loads(exact(size))
    if not isinstance(result, dict):
        raise OwnershipUnavailable("Invalid native command setup")
    return result


def _launchctl(*arguments: str) -> str:
    result = subprocess.run(["/bin/launchctl", *arguments], stdin=subprocess.DEVNULL,
                            capture_output=True, timeout=3, check=False)
    if result.returncode:
        raise OwnershipUnavailable("macOS could not establish or retire the command's launchd job")
    return result.stdout.decode("utf-8", "replace")


def supervise(argv: list[str], setup: dict, *, observer_fd: int | None = None) -> int:
    kernel = Kernel()
    stopped = False
    def cancel(_number, _frame):
        nonlocal stopped
        stopped = True
    for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(number, cancel)
    label = "io.meshia.command." + uuid.uuid4().hex
    domain = f"gui/{os.getuid()}"
    # A user launchd domain is available in headless login sessions too.
    try:
        _launchctl("print", domain)
    except OwnershipUnavailable:
        domain = f"user/{os.getuid()}"
    target = f"{domain}/{label}"
    coalition = None
    bootstrapped = False
    with tempfile.TemporaryDirectory(prefix="meshia-cmd-", dir="/private/tmp") as temporary:
        directory = Path(temporary).resolve()
        path = directory / "socket"
        with socket.socket(socket.AF_UNIX) as listener:
            listener.bind(str(path))
            os.chmod(path, 0o600)
            listener.listen(1)
            listener.settimeout(0.05)
            document = {"Label": label, "ProgramArguments": host_command(path),
                        "RunAtLoad": True, "AbandonProcessGroup": False,
                        "ProcessType": "Background"}
            plist = directory / "job.plist"
            plist.write_bytes(plistlib.dumps(document))
            os.chmod(plist, 0o600)
            try:
                _launchctl("bootstrap", domain, str(plist))
                bootstrapped = True
                match = re.search(r"^\s*pid = (\d+)\s*$", _launchctl("print", target), re.M)
                if match is None:
                    raise OwnershipUnavailable("macOS did not identify the command's launchd process")
                leader = kernel.identity(int(match.group(1)))
                if leader is None or not all(leader.coalition) or leader.coalition == kernel.own.coalition:
                    raise OwnershipUnavailable("macOS did not isolate command ownership")
                coalition = leader.coalition
                deadline = time.monotonic() + 10
                while not stopped and time.monotonic() < deadline:
                    try:
                        connection, _ = listener.accept()
                        break
                    except socket.timeout:
                        continue
                else:
                    return 143 if stopped else 70
                with connection:
                    connection.settimeout(3)
                    peer = kernel.identity(connection.getsockopt(0, 2))  # LOCAL_PEERPID
                    if peer is None or peer.coalition != coalition:
                        raise OwnershipUnavailable("Native command worker is not owned by its launchd job")
                    if observer_fd is not None:
                        # Private inherited pipe back to the executor. launchctl
                        # does not inherit it and it never enters workload setup.
                        # The initial launchd PID may still exec during startup.
                        # Its authenticated worker has completed exec and stays
                        # alive through command cleanup, pinning this coalition.
                        report = json.dumps({"pid": peer.pid, "unique": peer.unique,
                                             "version": peer.version, "coalition": coalition}).encode() + b"\n"
                        if len(report) > 1024 or os.write(observer_fd, report) != len(report):
                            raise OwnershipUnavailable("Native app ownership report was incomplete")
                        os.close(observer_fd)
                        observer_fd = None
                    descriptors = array.array("i", [0, 1, 2])
                    connection.sendmsg([b"F"], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, descriptors)])
                    _frame(connection, {"argv": argv, "setup": setup, "environment": dict(os.environ),
                                        "job": target})
                    while not stopped:
                        if select.select([connection], [], [], 0.05)[0]:
                            result = _receive(connection)
                            return int(result["status"])
                    return 143
            finally:
                if observer_fd is not None:
                    os.close(observer_fd)
                try:
                    if coalition is not None:
                        kernel.stop(coalition)
                finally:
                    if bootstrapped:
                        try:
                            _launchctl("bootout", target)
                        except OwnershipUnavailable:
                            # The worker also retires its job if our connection
                            # closes; removal is complete only if readback agrees.
                            try:
                                _launchctl("print", target)
                            except OwnershipUnavailable:
                                pass
                            else:
                                raise


def worker(path: Path) -> int:
    if not path.is_absolute() or path.resolve() != path:
        raise OwnershipUnavailable("Native command socket path is not canonical")
    parent = path.parent.lstat()
    endpoint = path.lstat()
    if (not stat.S_ISDIR(parent.st_mode) or stat.S_IMODE(parent.st_mode) != 0o700
            or parent.st_uid != os.getuid() or not stat.S_ISSOCK(endpoint.st_mode)
            or stat.S_IMODE(endpoint.st_mode) != 0o600 or endpoint.st_uid != os.getuid()):
        raise OwnershipUnavailable("Native command socket is not privately owned")
    kernel = Kernel()
    stopped = False
    def cancel(_number, _frame):
        nonlocal stopped
        stopped = True
    for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(number, cancel)
    with socket.socket(socket.AF_UNIX) as connection:
        connection.settimeout(10)
        connection.connect(str(path))
        data, ancillary, flags, _address = connection.recvmsg(1, socket.CMSG_SPACE(3 * array.array("i").itemsize))
        descriptors = array.array("i")
        for level, kind, values in ancillary:
            if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                descriptors.frombytes(values[:len(values) - len(values) % descriptors.itemsize])
        try:
            if data != b"F" or flags & socket.MSG_CTRUNC or len(descriptors) != 3:
                raise OwnershipUnavailable("Native command streams are incomplete")
            settings = _receive(connection)
            if not re.fullmatch(rf"(?:gui|user)/{os.getuid()}/io\.meshia\.command\.[0-9a-f]{{32}}", settings.get("job", "")):
                raise OwnershipUnavailable("Native command job identity is invalid")
            for destination, source in enumerate(descriptors):
                os.dup2(source, destination, inheritable=True)
        finally:
            for descriptor in descriptors:
                os.close(descriptor)
        child = os.fork()
        if child == 0:
            connection.close()
            for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
                signal.signal(number, signal.SIG_DFL)
            try:
                from meshia_node.native_command import launch
                os.environ.clear()
                os.environ.update(settings["environment"])
                launch(settings["argv"], **settings["setup"])
            except BaseException as error:
                print(f"Native command startup failed: {error}", file=sys.stderr, flush=True)
            os._exit(70)
        # Keep the worker and native host alive until the broker has received
        # status. They pin coalition ownership during final descendant cleanup.
        try:
            status = None
            while not stopped:
                if status is None:
                    waited, result = os.waitpid(child, os.WNOHANG)
                    if waited:
                        status = os.waitstatus_to_exitcode(result)
                        _frame(connection, {"status": status})
                if select.select([connection], [], [], 0.01)[0]:
                    if not connection.recv(1):
                        break
        finally:
            # Parent crash/cancel closes this credential-free control socket.
            # Freeze and kill command descendants before the native host; an
            # exiting host otherwise lets launchd kill this worker prematurely.
            host = os.getppid()
            kernel.stop(kernel.own.coalition, exclude={os.getpid(), host})
            # These are the only two files created by this command's broker.
            # An abrupt broker death must not leave one directory per command.
            for owned in (path, path.parent / "job.plist"):
                try:
                    owned.unlink()
                except FileNotFoundError:
                    pass
            try:
                path.parent.rmdir()
            except (FileNotFoundError, OSError):
                pass
            # A killed broker cannot retire the job. Remove only our exact
            # private job after stopping descendants; bootout may stop us too.
            try:
                _launchctl("bootout", settings["job"])
            except OwnershipUnavailable:
                pass  # The broker may already have removed this same job.
        return 143 if status is None else status


if __name__ == "__main__":
    if not __package__:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    if len(sys.argv) != 3 or sys.argv[1] != "--worker":
        raise SystemExit(64)
    raise SystemExit(worker(Path(sys.argv[2])))
