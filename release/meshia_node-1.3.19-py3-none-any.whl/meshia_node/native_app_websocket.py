"""Finite WebSocket state for one already-owned native app socket.

NativeApps remains the authority and four-connection admission owner. This
transport never discovers a port, reconnects, follows redirects, or renews a
grant. Queue sequences acknowledge pieces, not separate upstream messages.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import re
import socket
import threading
import time
from urllib.parse import urlsplit

from websockets.exceptions import ConnectionClosed
from websockets.frames import Close
from websockets.sync.client import connect

from .native_app_http import AppError

MAX_MESSAGE_BYTES = 8 * 1024 * 1024
MAX_CHUNK_BYTES = 256 * 1024
MAX_CONNECTIONS = 4
OPEN_SECONDS = 10
LIFETIME_SECONDS = 240
IDLE_SECONDS = 30
READ_SECONDS = 1
TOMBSTONE_SECONDS = 60
TOKEN = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+\Z")
# Session authentication is never forwarded. Cookie is the app-origin cookie
# jar, filtered by the web/native owner before this transport is called.
REQUEST_HEADERS = frozenset({"accept", "accept-language", "cache-control", "cookie", "user-agent",
    "host", "origin", "referer", "x-forwarded-host", "x-forwarded-proto",
    "x-csrftoken", "x-csrf-token", "x-xsrf-token", "x-requested-with"})


def invalid(message):
    return AppError("APP_REQUEST_INVALID", message, 400)


class AppWebSocket:
    def __init__(self, stream_id, app, fingerprint):
        self.stream_id, self.app, self.fingerprint = stream_id, app, fingerprint
        self.fence, self.instance_id = app.fence, app.instance_id
        self.created = self.touched = time.monotonic()
        self.deadline = self.created + LIFETIME_SECONDS
        self.io_deadline = None
        self.closed = False
        self.closed_at = None
        self.error = None
        self.socket = self.connection = None
        self.protocol = None
        self.set_cookies = []
        self.lock = threading.RLock()
        self.read_lock, self.send_lock = threading.Lock(), threading.Lock()
        self.read_sequence = self.send_sequence = 0
        self.last_read = self.last_read_size = self.last_send = self.last_send_digest = None
        self.incoming = b""
        self.incoming_type = None
        self.incoming_offset = 0
        self.outgoing = bytearray()
        self.outgoing_type = None
        self.peer_closed = False
        self.close_code = self.close_reason = None
        self.stop_watch = threading.Event()
        self.watch = threading.Thread(target=self._watch, name="meshia-app-websocket-authority", daemon=True)
        self.watch.start()

    def _identity(self, operation):
        return {"schema": "meshia.connected_host_app_http_result.v1", "operation": operation,
                "stream_id": self.stream_id, "instance_id": self.instance_id}

    def _check(self, *, allow_closed=False):
        if (self.app.stopped.is_set() or self.app.done.is_set()
                or self.app.fence != self.fence or self.app.instance_id != self.instance_id
                or time.monotonic() >= self.app.deadline):
            raise AppError("APP_AUTHORITY_CHANGED", "App WebSocket authority expired or changed.", 403)
        if self.error is not None:
            raise self.error
        if self.closed and not allow_closed:
            raise AppError("APP_WEBSOCKET_CLOSED", "This app WebSocket is closed.", 410)

    def open(self, owned_socket, path, query="", headers=None, subprotocols=()):
        """Consume a connected IPv4 socket; verify ownership before any bytes."""
        connection, published = None, False
        try:
            with self.lock:
                if self.closed:
                    owned_socket.close()
                    self._check()
                if self.socket is not None:
                    owned_socket.close()
                    raise invalid("This WebSocket already has a connection.")
                self.socket = owned_socket
                self._check()
            if (not isinstance(path, str) or not path.startswith("/") or path.startswith("//")
                    or not isinstance(query, str) or len(path) + len(query) > 16384
                    or any(c in path + query for c in "\r\n\x00#\\")):
                raise invalid("Invalid app WebSocket path.")
            if (not isinstance(subprotocols, (list, tuple)) or len(subprotocols) > 16
                    or any(not isinstance(p, str) or not TOKEN.fullmatch(p) for p in subprotocols)
                    or sum(len(p.encode()) for p in subprotocols) > 2048
                    or len(set(subprotocols)) != len(subprotocols)):
                raise invalid("Invalid app WebSocket subprotocols.")
            headers = {} if headers is None else headers
            if (not isinstance(headers, dict) or len(headers) > 32
                    or any(not isinstance(k, str) or k.lower() not in REQUEST_HEADERS
                           or not isinstance(v, str) or any(c in v for c in "\r\n\x00")
                           for k, v in headers.items())
                    or sum(len(k.encode()) + len(v.encode()) for k, v in headers.items()) > 16384):
                raise invalid("Invalid app WebSocket headers.")
            normalized = {k.lower(): v for k, v in headers.items()}
            if len(normalized) != len(headers):
                raise invalid("Duplicate app WebSocket header names.")
            host = normalized.pop("host", f"127.0.0.1:{self.app.port}")
            if (host != f"127.0.0.1:{self.app.port}" and
                    (not re.fullmatch(r"[a-z0-9.-]+(?::[0-9]{1,5})?", host)
                     or not host.startswith(self.instance_id + "."))):
                raise invalid("The app Host must identify this exact app instance.")
            origin = normalized.pop("origin", None)
            if origin is not None:
                parsed = urlsplit(origin)
                if (parsed.scheme not in ("http", "https") or parsed.netloc != host
                        or parsed.path or parsed.query or parsed.fragment):
                    raise invalid("The app Origin must match its exact public Host.")
            if normalized.get("x-forwarded-host", host) != host or normalized.get("x-forwarded-proto", "https") not in ("http", "https"):
                raise invalid("The app forwarded origin does not match its Host.")
            self.app.owner.verify_connection(owned_socket, self.app.port)
            with self.lock:
                self._check()
            # A supplied socket bypasses websockets' own blocking-mode setup.
            # Its connect timeout must not become an idle receive timeout;
            # handshake, authority, read and lifetime deadlines remain bounded
            # independently by the library and our owner watcher.
            owned_socket.settimeout(None)
            # Supplying sock prevents library redirects. There is no implicit
            # proxy, compression, reconnection, alternate address, or tunnel.
            connection = connect(f"ws://{host}{path}" + ("?" + query if query else ""),
                sock=owned_socket, origin=origin, subprotocols=list(subprotocols) or None, additional_headers=normalized,
                proxy=None, compression=None, open_timeout=OPEN_SECONDS, close_timeout=1,
                # Modern websockets uses >high, so (0,0) pauses at the first
                # queued frame rather than retaining two maximum-size frames.
                ping_interval=None, max_size=MAX_MESSAGE_BYTES, max_queue=(0, 0),
                user_agent_header=None, legacy=True)
            response_headers = list(connection.response.headers.raw_items())
            cookies = connection.response.headers.get_all("Set-Cookie")
            if (len(response_headers) > 64 or len(cookies) > 32
                    or sum(len(k.encode()) + len(v.encode()) for k, v in response_headers) > 16384
                    or any(not TOKEN.fullmatch(k) or any(ord(c) < 32 or ord(c) == 127 for c in v)
                           for k, v in response_headers)):
                raise AppError("APP_WEBSOCKET_UNAVAILABLE", "App handshake headers exceed their bound.", 502)
            with self.lock:
                self._check()
                self.connection, self.protocol = connection, connection.subprotocol
                self.set_cookies = cookies
                self.touched = time.monotonic()
            result = self.metadata()
            published = True
            return result
        except AppError as error:
            self.close(error)
            raise
        except Exception:
            error = AppError("APP_WEBSOCKET_UNAVAILABLE", "The owned app WebSocket could not be opened.", 502)
            self.close(error)
            raise error from None
        finally:
            # Revocation can win after the library returns but before the
            # connection is published. Retire that detached receiver too.
            if connection is not None and not published:
                self._disconnect()
                try:
                    connection.close_socket()
                    connection.close()
                except Exception:
                    pass

    def metadata(self):
        with self.lock:
            self._check()
            if self.connection is None:
                raise AppError("APP_WEBSOCKET_NOT_READY", "Wait for the app WebSocket handshake.")
            return {**self._identity("ws_open"), "protocol": self.protocol,
                    "set_cookies": list(self.set_cookies)}

    def send(self, sequence, message_type, body_base64, end_of_message):
        if (type(sequence) is not int or sequence < 0 or message_type not in ("text", "binary")
                or type(end_of_message) is not bool or not isinstance(body_base64, str)
                or len(body_base64) > 4 * ((MAX_CHUNK_BYTES + 2) // 3)):
            raise invalid("Invalid app WebSocket message chunk.")
        try:
            data = base64.b64decode(body_base64, validate=True)
        except (ValueError, binascii.Error):
            raise invalid("App WebSocket data must be standard base64.") from None
        if len(data) > MAX_CHUNK_BYTES:
            raise invalid("App WebSocket chunks cannot exceed 256 KiB.")
        digest = hashlib.sha256(message_type.encode() + bytes([end_of_message]) + data).digest()
        with self.send_lock:
            with self.lock:
                self._check(allow_closed=True)
                if sequence == self.send_sequence - 1 and self.last_send is not None:
                    if digest != self.last_send_digest:
                        raise AppError("APP_WEBSOCKET_SEQUENCE_INVALID", "A retried send must preserve its payload.")
                    return dict(self.last_send)
                self._check()
                if sequence != self.send_sequence:
                    raise AppError("APP_WEBSOCKET_SEQUENCE_INVALID", "Send the next sequence or replay the last send.")
                if self.connection is None or self.peer_closed:
                    raise AppError("APP_WEBSOCKET_CLOSED", "The app WebSocket is not open.", 410)
                if self.outgoing_type not in (None, message_type):
                    raise invalid("A continued message must keep its message type.")
                if len(self.outgoing) + len(data) > MAX_MESSAGE_BYTES:
                    raise AppError("APP_MESSAGE_TOO_LARGE", "App WebSocket messages cannot exceed 8 MiB.", 413)
                self.outgoing.extend(data)
                self.outgoing_type = message_type
                self.touched = time.monotonic()
                connection = self.connection
                if end_of_message and message_type == "text":
                    try:
                        self.outgoing.decode("utf-8", errors="strict")
                    except UnicodeDecodeError:
                        self.close(AppError("APP_REQUEST_INVALID", "Text messages must be valid UTF-8.", 400))
                        raise self.error from None
            if end_of_message:
                try:
                    # One upstream message, even when queue chunks split UTF-8.
                    self.io_deadline = time.monotonic() + OPEN_SECONDS
                    connection.send(self.outgoing, text=message_type == "text")
                except Exception:
                    error = AppError("APP_WEBSOCKET_SEND_UNKNOWN", "App WebSocket send failed; do not replay this message.", 502)
                    self.close(error)
                    raise error from None
                finally:
                    self.io_deadline = None
            with self.lock:
                self._check()
                if end_of_message:
                    self.outgoing = bytearray()
                    self.outgoing_type = None
                result = {**self._identity("ws_send"), "sequence": sequence,
                          "next_sequence": sequence + 1, "accepted_bytes": len(data),
                          "message_complete": end_of_message}
                self.send_sequence += 1
                self.last_send, self.last_send_digest = result, digest
                return dict(result)

    def read(self, sequence, max_bytes):
        if (type(sequence) is not int or sequence < 0 or type(max_bytes) is not int
                or not 1 <= max_bytes <= MAX_CHUNK_BYTES):
            raise invalid("Invalid app WebSocket read sequence or byte bound.")
        with self.read_lock:
            with self.lock:
                self._check(allow_closed=True)
                if sequence == self.read_sequence - 1 and self.last_read is not None:
                    if max_bytes != self.last_read_size:
                        raise AppError("APP_WEBSOCKET_SEQUENCE_INVALID", "A retried read must preserve its byte bound.")
                    return dict(self.last_read)
                if sequence != self.read_sequence:
                    raise AppError("APP_WEBSOCKET_SEQUENCE_INVALID", "Read the next sequence or replay the last chunk.")
                self.touched = time.monotonic()
                connection = self.connection
                receive = self.incoming_type is None and not self.peer_closed and not self.closed
                if receive and connection is None:
                    raise AppError("APP_WEBSOCKET_NOT_READY", "Wait for the app WebSocket handshake.")
            if receive:
                try:
                    message = connection.recv(timeout=READ_SECONDS)
                    with self.lock:
                        self._check()
                        self.incoming_type = "text" if isinstance(message, str) else "binary"
                        self.incoming = message.encode("utf-8") if isinstance(message, str) else message
                        self.incoming_offset = 0
                except TimeoutError:
                    pass
                except ConnectionClosed as error:
                    with self.lock:
                        self._check(allow_closed=True)
                        self.peer_closed = True
                        close = error.rcvd or error.sent
                        self.close_code = close.code if close else 1006
                        self.close_reason = close.reason if close else ""
                except AppError:
                    raise
                except Exception:
                    error = AppError("APP_WEBSOCKET_UNAVAILABLE", "The app WebSocket read failed.", 502)
                    self.close(error)
                    raise error from None
            with self.lock:
                self._check(allow_closed=True)
                data = self.incoming[self.incoming_offset:self.incoming_offset + max_bytes]
                message_type = self.incoming_type
                self.incoming_offset += len(data)
                end = message_type is not None and self.incoming_offset == len(self.incoming)
                if end:
                    self.incoming, self.incoming_type, self.incoming_offset = b"", None, 0
                result = {**self._identity("ws_read"), "sequence": sequence, "next_sequence": sequence + 1,
                          "body_base64": base64.b64encode(data).decode("ascii"),
                          "message_type": message_type, "end_of_message": end,
                          "closed": self.peer_closed or self.closed}
                if result["closed"]:
                    result.update(close_code=self.close_code or 1000, close_reason=self.close_reason or "")
                self.read_sequence += 1
                self.last_read, self.last_read_size = result, max_bytes
                return dict(result)

    def _disconnect(self):
        # Interrupt both the library receive thread and a blocked upstream send.
        candidate = self.socket
        if candidate is not None:
            try:
                candidate.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            candidate.close()

    def close(self, error=None, *, close_code=1000, close_reason=""):
        if error is None:
            if type(close_code) is not int or not isinstance(close_reason, str):
                raise invalid("Invalid app WebSocket close code or reason.")
            try:
                encoded = Close(close_code, close_reason).serialize()
                if len(encoded) > 125:
                    raise ValueError("reason too long")
            except Exception:
                # websockets raises ProtocolError for forbidden wire codes.
                raise invalid("Invalid app WebSocket close code or reason.") from None
        with self.lock:
            if self.closed:
                return {**self._identity("ws_close"), "closed": True}
            self.closed, self.closed_at, self.error = True, time.monotonic(), error
            self.close_code, self.close_reason = close_code, close_reason
            self.incoming, self.outgoing = b"", bytearray()
            self.incoming_type = self.outgoing_type = None
            self.set_cookies = []
            connection = self.connection
            # Keep only the small retry receipts in a tombstone, not the
            # library's last queued maximum-size frame.
            self.connection = None
            self.stop_watch.set()
        try:
            if error is None and connection is not None:
                # A concurrent slow send can hold the library write lock.
                # Shutdown independently; close must never wait behind it.
                timer = threading.Timer(1, self._disconnect)
                timer.daemon = True
                timer.start()
                try:
                    connection.close(close_code, close_reason)
                finally:
                    timer.cancel()
        finally:
            self._disconnect()
            if connection is not None:
                # The pinned sync client can be paused on queue flow control.
                # TCP shutdown alone won't wake that receiver. Its teardown
                # also closes the assembler and resumes the paused thread.
                connection.close_socket()
        return {**self._identity("ws_close"), "closed": True}

    def expire(self, now):
        if self.closed:
            return
        try:
            self._check()
            if (now >= self.deadline or now - self.touched >= IDLE_SECONDS
                    or self.io_deadline is not None and now >= self.io_deadline):
                raise AppError("APP_WEBSOCKET_TIMEOUT", "App WebSocket reached its lifetime or idle deadline.", 504)
        except AppError as error:
            self.close(error)

    def _watch(self):
        while not self.stop_watch.wait(.05):
            self.expire(time.monotonic())
