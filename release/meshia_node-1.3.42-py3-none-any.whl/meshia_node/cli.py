"""`meshia-node` command line: connection, diagnostics, and conflict recovery."""

from __future__ import annotations

import argparse
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
import errno
import getpass
import hashlib
import json
import math
import os
import random
import shutil
import signal
import sqlite3
import stat
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
import urllib.parse
import uuid
from dataclasses import replace
from pathlib import Path
from typing import Any, Callable, Iterator, Sequence

from . import __version__
from .attach import (
    NodeRunner, WORKSPACE_STORAGE_TERMINAL_CODES, attach, can_recover_account_storage,
    disconnect, forget_remote, rename_workspace,
)
from .client import LOOPBACK_HOSTS, SignedClient, validate_api_url
from .config import MOUNT_BACKENDS
from .control import ControlClient, ControlError
from .control_cli import CONTROL_COMMANDS, add_commands as add_control_commands, command_control
from .config import (
    CONNECT_ACCESS_MODES,
    DEFAULT_ACCESS_MODE,
    ConfigStore,
    NodeConfig,
    Paths,
    WorkspaceStatePaths,
    file_lock,
)
from .doctor import run as run_doctor
from . import native_host
from .enroll import enroll
from .errors import (
    Disconnected,
    InvalidArgument,
    InvalidTask,
    MeshiaNodeError,
    NetworkError,
    RemoteError,
    StateError,
    UnsafePath,
    WorkspaceAdoptionRequired,
    WorkspaceClaimInvalid,
)
from .executor import CommandExecutor, CommandLoop, scrubbed_environment
from .fabric import FabricAuthority, SignedFabricTransport
from .fabric_cache import (
    DEFAULT_CHUNK_BYTES,
    DEFAULT_MAX_CACHE_BYTES,
    DEFAULT_MAX_METADATA_BYTES,
    DEFAULT_MAX_RANGE_RECORDS,
    FabricRangeCache,
)
from .fabric_db import FabricDatabase, LegacyAuthoritySnapshot
from .fabric_mount import (
    FabricFuseMount,
    FabricMountBackend,
    FabricMountError,
    MultiWorkspaceMountBackend,
    _exact_fuse_t_helper_command,
    detect_fuse_runtime,
    mount_discards_appledouble_sidecars,
    mount_registration_state,
    mount_runtime_help,
    mount_state_path_present,
    read_mount_state,
    select_macos_fuse_backend,
    select_mount_point,
)
from .fskit_bridge import VolumeSpec
from .fskit_mount import (
    FSKitMount,
    default_fskit_address,
    fskit_app_group,
    fskit_approval_notice,
    read_fskit_mount_state,
    select_mount_backend,
)
from .file_provider_account_bridge import AccountFileProviderBridge
from .file_provider_bridge import FabricFileProviderBridge
from .file_provider_runtime import (
    NativeFileProviderStatus,
    file_provider_bridge_health,
    native_file_provider_status,
)
from .fabric_sync import (
    LOCAL_FILE_UNSUPPORTED_REMEDIATION,
    FabricSyncCoordinator,
)
from .fabric_watch import FabricWatch
from .identity import DeviceIdentity
from .log import NodeLogger
from .sync_engine_split import (
    EngineMountTopology,
    EngineWorkspaceHandle,
    MultiWorkspaceEngineServer,
    SyncEngineServer,
    multi_workspace_split_enabled,
    sync_engine_process_enabled,
)
from .sync_engine_worker import MountWorkerSpec, MountWorkerSupervisor
from .object_edge import (
    ObjectEdgeSession,
    default_registry,
    format_object_edge_status,
    object_edge_status_path,
    read_object_edge_status,
)
from .presentation import wordmark
from .sealed_env import TaskEnvironmentFetcher
from .service import (
    MOUNT_RELEASE_TIMEOUT_SECONDS,
    AlreadyRunning,
    ConnectionLease,
    MountHeldError,
    runner_holds_lease,
    SERVICE_SHUTDOWN_REQUEST_NAME,
    ServiceAction,
    ServiceController,
    ServiceError,
    assert_safe_node_account,
    process_is_alive,
    preserve_service_stderr,
    release_native_mount,
)
from .util import (
    PAIRING_CODE_RE,
    POSTGRES_UUID_RE,
    UUID_RE,
    ensure_private_dir,
    iso8601,
    raise_file_descriptor_limit,
    write_private_file,
)
from .workspace import (
    WorkspaceBoundary,
    WorkspaceRootClaim,
    bind_workspace_root_claim,
    claim_workspace_root,
    complete_workspace_root_adoption,
    rebind_workspace_root_claim,
    split_relative,
    validate_workspace_root_claim,
    workspace_root_claim_status,
)
from .workspace_catalog import (
    MAX_SAFE_INTEGER,
    WorkspaceCatalogClient,
    WorkspaceCatalogEntry,
    WorkspaceCatalogStore,
)
from .push_client import PushClient, PushRuntimeBridge, read_push_status
from .workspace_runtime import (
    StartupRecoveryScan,
    WorkspaceRuntime,
    WorkspaceRuntimeManager,
)

SERVICE_START_DELAY_SECONDS = 1.0
SERVICE_START_MAX_DELAY_SECONDS = 30.0
DISCONNECT_LEASE_WAIT_SECONDS = 8.0
# A runner whose native mount stays attached at shutdown keeps serving it and
# retries the detach at this cadence. It never exits under an attached mount:
# on macOS that leaves the kernel NFS/SMB client waiting on a dead server and
# only a reboot clears it. Once released it exits with EX_TEMPFAIL so launchd
# (KeepAlive on failure) and systemd (Restart=on-failure) bring the node back
# when the stop that started the hold was abandoned by a refusing controller.
MOUNT_RELEASE_RETRY_SECONDS = 2.0
MOUNT_RELEASE_HOLD_EXIT_CODE = 75
SERVICE_READY_TIMEOUT_SECONDS = 45.0
SERVICE_READY_POLL_SECONDS = 0.1
SERVICE_RUNTIME_STATUS_NAME = "service-runtime.json"
PAIR_STDIN_MAX_CHARS = 256
WORKSPACE_STATE_LOCATIONS_SCHEMA = "meshia.workspace-state-locations.v1"
WORKSPACE_STATE_LOCATIONS_MAX_BYTES = 4 * 1024
STATUS_CONFIG_MAX_BYTES = 64 * 1024
STATUS_ERROR_MAX_CHARS = 256
STATUS_DEGRADED_OPERATION_LIMIT = 8
STATUS_WATCHER_ISSUE_SAMPLE_MAX = 8
STARTUP_RECOVERY_DATABASE_SCAN_LIMIT = 256
STARTUP_RECOVERY_SCAN_SECONDS = 2.0
STATUS_VISIBLE_WORKSPACE_SCAN_LIMIT = 256
STATUS_VISIBLE_WORKSPACE_SCAN_SECONDS = 2.0
DOCTOR_COMMIT_UNKNOWN_ATTENTION_SECONDS = 300.0
_STORAGE_TERMINAL_DISCONNECT_REASONS = WORKSPACE_STORAGE_TERMINAL_CODES
CONFLICT_LIST_DEFAULT_LIMIT = 50
CONFLICT_LIST_MAX_LIMIT = 200
# FabricRangeCache's default budget reserves two SQLite-sized metadata files,
# filesystem accounting slack, and 64 one-MiB allocation-overhead units. Keep
# this read-only projection alongside the imported public defaults so `status`
# never has to construct (and therefore repair/evict) the live cache.
_DEFAULT_CACHE_DISK_BYTES = (
    (2 * DEFAULT_MAX_METADATA_BYTES)
    + (64 * 1024)
    + DEFAULT_MAX_CACHE_BYTES
    + (64 * DEFAULT_CHUNK_BYTES)
)


class AuthoritativeStateUnavailable(StateError):
    """The durable Fabric journal must be preserved and repaired in place."""

    def __init__(self, journal_state: str) -> None:
        self.journal_state = journal_state
        super().__init__(
            f"Fabric authoritative state is {journal_state}; it was preserved "
            "and command claims are parked."
        )


def _uses_insecure_loopback_development_origin(api_url: str) -> bool:
    """Permit loopback direct tickets only for an explicitly local dev origin."""

    try:
        parsed = urllib.parse.urlsplit(api_url)
    except ValueError:
        return False
    return parsed.scheme.lower() == "http" and (parsed.hostname or "").lower() in LOOPBACK_HOSTS


def _emit(document: Any, as_json: bool) -> None:
    if as_json:
        print(json.dumps(document, indent=2, sort_keys=True))
        return
    if isinstance(document, dict):
        for key, value in document.items():
            print(f"{key}: {value if not isinstance(value, (dict, list)) else json.dumps(value)}")
    else:  # pragma: no cover - defensive
        print(document)


def _positive_conflict_id(value: str) -> int:
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("conflict ID must be a positive integer") from None
    if parsed < 1:
        raise argparse.ArgumentTypeError("conflict ID must be a positive integer")
    return parsed


def _conflict_list_limit(value: str) -> int:
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"limit must be between 1 and {CONFLICT_LIST_MAX_LIMIT}"
        ) from None
    if not 1 <= parsed <= CONFLICT_LIST_MAX_LIMIT:
        raise argparse.ArgumentTypeError(
            f"limit must be between 1 and {CONFLICT_LIST_MAX_LIMIT}"
        )
    return parsed


def _conflict_list_cursor(value: str) -> int:
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("after must be a non-negative conflict ID") from None
    if parsed < 0:
        raise argparse.ArgumentTypeError("after must be a non-negative conflict ID")
    return parsed


def _conflict_session_id(value: str) -> str:
    if UUID_RE.fullmatch(value) is None:
        raise argparse.ArgumentTypeError("session must be a UUID")
    return value.lower()


def _default_program_name() -> str:
    invoked = Path(sys.argv[0]).name.lower()
    if invoked in {"meshia", "meshia.exe", "meshia.cmd", "meshia.ps1"}:
        return "meshia"
    return "meshia-node"


def build_parser(*, prog: str | None = None) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog=prog or _default_program_name(),
        description="Meshia projects, agents, conversations and native files in one command.",
    )
    parser.add_argument("--version", action="version", version=f"{parser.prog} {__version__}")
    parser.add_argument("--home", help="Override the Meshia state directory (default ~/.meshia).")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON.")
    sub = parser.add_subparsers(dest="command", required=True)
    add_control_commands(sub)

    help_command = sub.add_parser(
        "help", help="Show every command, or detailed help for one command."
    )
    help_command.add_argument(
        "path",
        nargs="*",
        metavar="COMMAND",
        help="Command path, for example `conflicts resolve`.",
    )

    connect = sub.add_parser("connect", help="Enroll (or re-attach) and run the node.")
    pairing_source = connect.add_mutually_exclusive_group()
    pairing_source.add_argument("pairing_code", nargs="?", help="One-time mesh_… pairing code.")
    pairing_source.add_argument(
        "--pair-stdin",
        action="store_true",
        help="Read exactly one one-time pairing code line from standard input.",
    )
    connect.add_argument("--api-url", help="Control-plane origin, e.g. https://meshia.example.")
    connect.add_argument(
        "--tier",
        choices=("personal", "compute"),
        default=None,
        help="Node tier (default compute for a new enrollment; preserved on reconnect).",
    )
    connect.add_argument(
        "--access",
        choices=CONNECT_ACCESS_MODES,
        default=None,
        help=(
            "Connection mode: files for account workspace mounts without compute; "
            "limited for native compute restricted to workspace data; "
            "full for native compute with your OS account's file access."
        ),
    )
    connect.add_argument(
        "--workspace",
        help=(
            "Private write-back directory (default ~/.meshia/workspace for a normal install, or "
            "<custom-home>/workspace with --home)."
        ),
    )
    connect.add_argument(
        "--adopt-existing-workspace",
        action="store_true",
        help=(
            "Explicitly claim a non-empty workspace directory that has no matching "
            "private Meshia ownership marker. Existing same-path remote content is "
            "preserved as a conflict during the first reconciliation."
        ),
    )
    mount_mode = connect.add_mutually_exclusive_group()
    mount_mode.add_argument(
        "--native-mount",
        dest="native_mount_enabled",
        action="store_true",
        default=None,
        help="Enable the native Meshia filesystem mount (default on first connect).",
    )
    mount_mode.add_argument(
        "--no-native-mount",
        dest="native_mount_enabled",
        action="store_false",
        help="Keep remote sync active without mounting a native filesystem volume.",
    )
    connect.add_argument(
        "--mount-backend",
        choices=MOUNT_BACKENDS,
        default=None,
        help=(
            "Native mount backend: auto (FSKit volumes on macOS 26 when Meshia.app "
            "is installed and enabled, else FUSE-T), fskit, or fuse-t."
        ),
    )
    connect.add_argument("--name", help="Display name shown in the workspace.")
    connect.add_argument(
        "--foreground",
        dest="foreground",
        action="store_true",
        default=True,
        help="Run the supervision loop in the foreground (default).",
    )
    connect.add_argument(
        "--enroll-only",
        action="store_true",
        help="Enroll and persist identity, then exit without creating an attachment.",
    )
    connect.add_argument("--max-iterations", type=int, help="Stop after N loop passes (testing).")

    status = sub.add_parser("status", help="Show local enrollment and lifecycle state.")
    status.add_argument(
        "--deep",
        action="store_true",
        help="Run explicit SQLite integrity and aggregate diagnostics.",
    )
    sub.add_parser("open", help="Open the mounted Meshia files in the native file browser.")
    compute = sub.add_parser("compute", help="Show native computer execution readiness.")
    compute.add_argument("action", choices=("status",), nargs="?", default="status")
    compute.add_argument("--json", action="store_true", default=argparse.SUPPRESS)
    mount = sub.add_parser(
        "mount", help="Show or choose the native mount backend (FSKit volumes or FUSE-T)."
    )
    mount.add_argument("workspace_id", nargs="?", help="Enroll and mount a project using the account from meshia login.")
    mount.add_argument("--json", action="store_true", default=argparse.SUPPRESS)
    mount_preference = mount.add_mutually_exclusive_group()
    mount_preference.add_argument("--enable", dest="mount_enabled", action="store_true", default=None,
        help="Enable native mounts on the next service start without changing enrollment.")
    mount_preference.add_argument("--disable", dest="mount_enabled", action="store_false",
        help="Disable native mounts on the next service start without changing enrollment.")
    mount.add_argument(
        "--backend",
        choices=MOUNT_BACKENDS,
        default=None,
        help="Persist a backend choice; the running service applies it on restart.",
    )
    mount.add_argument(
        "--release",
        action="store_true",
        help=(
            "Ask the running node to detach its native mount and wait for the OS "
            "to confirm; exits non-zero and leaves the node running if it stays "
            "attached (used before a stop, restart, or upgrade)."
        ),
    )
    mount.add_argument(
        "--probe",
        action="store_true",
        help="Print only the bounded mount state (receipt + OS registry); never touches the mount.",
    )
    mount.add_argument(
        "--timeout-seconds",
        type=float,
        default=MOUNT_RELEASE_TIMEOUT_SECONDS,
        help="How long --release waits for the OS to confirm the detach (default: %(default)s).",
    )
    mount.add_argument(
        "--retry-command",
        default="meshia-node mount --release",
        help="The command named in the refusal message when --release cannot detach the mount.",
    )
    # Internal: the mount worker the engine spawns when the process split is
    # enabled. Hidden because it is never invoked by a person.
    mount_worker = sub.add_parser("_mount-worker", help=argparse.SUPPRESS)
    mount_worker.add_argument("--spec", required=True, help=argparse.SUPPRESS)

    sub.add_parser("disconnect", help="Release the remote attachment and park this node.")
    forget = sub.add_parser("forget", help="Erase local identity and configuration.")
    forget.add_argument("--keep-remote", action="store_true", help="Skip the remote revocation.")

    doctor = sub.add_parser("doctor", help="Environment, permission, network and machine probe.")
    doctor.add_argument("--api-url", help="Origin to probe when this node is not enrolled yet.")
    doctor.add_argument("--offline", action="store_true", help="Skip the network probe.")

    mcp = sub.add_parser(
        "mcp", help="Connect any AI agent to Meshia's remote workspace control plane."
    )
    mcp.add_argument("action", nargs="?", choices=("serve", "config"), help="Serve stdio MCP or print a credential-free local client configuration.")
    mcp.add_argument(
        "--client",
        choices=("agent", "claude", "codex"),
        default="agent",
        help="Print a universal agent prompt or an exact Claude Code/Codex CLI command.",
    )
    mcp.add_argument(
        "--api-url",
        default="https://meshia.io",
        help="Meshia control-plane origin (default https://meshia.io).",
    )
    mcp.add_argument(
        "--json",
        dest="json",
        action="store_true",
        default=argparse.SUPPRESS,
        help="Emit machine-readable JSON (accepted before or after `mcp`).",
    )

    conflicts = sub.add_parser(
        "conflicts", help="Inspect, export, or safely resolve active workspace conflicts."
    )
    conflicts.add_argument(
        "--session",
        dest="conflict_session_id",
        type=_conflict_session_id,
        metavar="SESSION_ID",
        help=(
            "Target an exact workspace from the authenticated account catalog "
            "without changing the selected workspace."
        ),
    )
    conflict_sub = conflicts.add_subparsers(dest="conflict_action", required=True)
    conflict_list = conflict_sub.add_parser(
        "list", help="List a bounded page of active workspace conflicts."
    )
    conflict_list.add_argument(
        "--limit",
        type=_conflict_list_limit,
        default=CONFLICT_LIST_DEFAULT_LIMIT,
        help=(
            "Maximum conflicts to return "
            f"(default {CONFLICT_LIST_DEFAULT_LIMIT}, max {CONFLICT_LIST_MAX_LIMIT})."
        ),
    )
    conflict_list.add_argument(
        "--after",
        type=_conflict_list_cursor,
        default=0,
        metavar="ID",
        help="Continue after this conflict ID.",
    )
    conflict_list.add_argument(
        "--all", action="store_true", help="Include resolved conflict history."
    )

    conflict_show = conflict_sub.add_parser(
        "show", help="Show one active workspace conflict."
    )
    conflict_show.add_argument("conflict_id", type=_positive_conflict_id, metavar="ID")

    conflict_export = conflict_sub.add_parser(
        "export", help="Export exact verified local evidence without resolving it."
    )
    conflict_export.add_argument("conflict_id", type=_positive_conflict_id, metavar="ID")
    conflict_export.add_argument(
        "destination",
        type=Path,
        metavar="DESTINATION",
        help="New destination file; existing paths are never overwritten.",
    )

    conflict_resolve = conflict_sub.add_parser(
        "resolve", help="Queue a coordinator-owned conflict decision."
    )
    conflict_resolve.add_argument("conflict_id", type=_positive_conflict_id, metavar="ID")
    resolution = conflict_resolve.add_mutually_exclusive_group(required=True)
    resolution.add_argument(
        "--keep-local", action="store_const", const="keep_local", dest="decision"
    )
    resolution.add_argument(
        "--keep-remote", action="store_const", const="keep_remote", dest="decision"
    )
    resolution.add_argument("--keep-both", action="store_const", const="keep_both", dest="decision")

    conflict_retry = conflict_sub.add_parser(
        "retry", help="Safely rebase a side-effect-free blocked decision."
    )
    conflict_retry.add_argument("conflict_id", type=_positive_conflict_id, metavar="ID")

    conflict_rearm = conflict_sub.add_parser(
        "rearm",
        help=(
            "Retire a provably no-effect blocked attempt so a new decision can be made."
        ),
    )
    conflict_rearm.add_argument("conflict_id", type=_positive_conflict_id, metavar="ID")

    service = sub.add_parser(
        "service", help="Install or control the current-user background service."
    )
    service_sub = service.add_subparsers(dest="service_action", required=True)
    service_sub.add_parser(
        "install", help="Install a credential-free current-user service definition."
    )
    service_sub.add_parser("start", help="Start the installed service.")
    restart = service_sub.add_parser("restart", help="Replace the active service process.")
    restart.add_argument(
        "--wait",
        action="store_true",
        help="Wait for a new runner and fresh connected heartbeat.",
    )
    restart.add_argument(
        "--timeout-seconds",
        type=float,
        default=SERVICE_READY_TIMEOUT_SECONDS,
        help=f"Readiness deadline when --wait is set (default {SERVICE_READY_TIMEOUT_SECONDS:g}).",
    )
    restart.add_argument(
        "--expected-version",
        help="Require the restarted runner to report this package version.",
    )
    service_sub.add_parser("stop", help="Stop the service but keep it installed.")
    service_sub.add_parser("status", help="Show service-manager and local lifecycle state.")
    service_sub.add_parser("uninstall", help="Stop and remove the service definition.")
    service_sub.add_parser("run", help=argparse.SUPPRESS)

    # Installer-owned recovery seam. It is intentionally absent from normal
    # help: users choose an account with the one-line installer, while these
    # bounded phases let that script prepare and recover the cutover without
    # exposing the old and new account through one live mount.
    cutover = sub.add_parser("account-cutover", help=argparse.SUPPRESS)
    cutover_sub = cutover.add_subparsers(dest="cutover_action", required=True)
    cutover_prepare = cutover_sub.add_parser("prepare", help=argparse.SUPPRESS)
    cutover_prepare.add_argument("--pair-stdin", action="store_true", required=True)
    cutover_prepare.add_argument("--api-url", required=True)
    cutover_prepare.add_argument("--tier", choices=("personal", "compute"), required=True)
    cutover_prepare.add_argument("--access", choices=CONNECT_ACCESS_MODES, required=True)
    cutover_prepare.add_argument("--workspace")
    cutover_prepare.add_argument("--adopt-existing-workspace", action="store_true")
    cutover_mount = cutover_prepare.add_mutually_exclusive_group()
    cutover_mount.add_argument(
        "--native-mount", dest="native_mount_enabled", action="store_true", default=True
    )
    cutover_mount.add_argument(
        "--no-native-mount", dest="native_mount_enabled", action="store_false"
    )
    for action in (
        "activate",
        "publish",
        "rollback",
        "commit",
        "finalize",
        "inspect",
        "abort",
        "retry-retirement",
    ):
        cutover_sub.add_parser(action, help=argparse.SUPPRESS)
    cutover_runtime = cutover_sub.add_parser("set-prior-runtime", help=argparse.SUPPRESS)
    cutover_runtime.add_argument("--runtime", required=True)
    return parser


def _subcommands(
    parser: argparse.ArgumentParser,
) -> tuple[argparse._SubParsersAction[argparse.ArgumentParser] | None, dict[str, str]]:
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            descriptions = {
                choice.dest: choice.help
                for choice in action._choices_actions
                if choice.help != argparse.SUPPRESS
            }
            return action, descriptions
    return None, {}


def _visible_command_catalog(
    parser: argparse.ArgumentParser,
    prefix: tuple[str, ...] = (),
) -> list[tuple[str, str]]:
    action, descriptions = _subcommands(parser)
    if action is None:
        return []
    entries: list[tuple[str, str]] = []
    for name, child in action.choices.items():
        description = descriptions.get(name)
        if description is None:
            continue
        path = (*prefix, name)
        entries.append((" ".join(path), description))
        entries.extend(_visible_command_catalog(child, path))
    return entries


def _parser_for_command_path(
    parser: argparse.ArgumentParser, path: Sequence[str]
) -> argparse.ArgumentParser | None:
    current = parser
    for component in path:
        action, _descriptions = _subcommands(current)
        if action is None or component not in action.choices:
            return None
        current = action.choices[component]
    return current


def command_help(
    args: argparse.Namespace,
    parser: argparse.ArgumentParser,
) -> int:
    """Render exhaustive, agent-readable command discovery without touching state."""

    if args.path:
        selected = _parser_for_command_path(parser, args.path)
        if selected is None:
            print(
                f"{parser.prog}: unknown command path: {' '.join(args.path)}",
                file=sys.stderr,
            )
            print(f"Run `{parser.prog} help` to list every command.", file=sys.stderr)
            return 2
        selected.print_help()
        return 0

    catalog = _visible_command_catalog(parser)
    if args.json:
        print(
            json.dumps(
                {
                    "schema": "meshia.cli_help.v1",
                    "program": parser.prog,
                    "version": __version__,
                    "commands": [
                        {"command": command, "description": description}
                        for command, description in catalog
                    ],
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    print(wordmark(stream=sys.stdout, subtitle=f"NODE {__version__}"))
    print()
    print(f"Usage: {parser.prog} <command> [options]")
    print(f"       {parser.prog} help <command>")
    print()
    print("Commands")
    width = max(len(command) for command, _description in catalog)
    for command, description in catalog:
        print(f"  {command:<{width}}  {description}")
    print()
    print("Global options")
    print("  --home PATH  Use a different private Meshia state directory.")
    print("  --json       Emit stable machine-readable output when supported.")
    print("  --version    Print the installed Meshia Node version.")
    print()
    print(f"Start with `{parser.prog} doctor`, then connect from your Meshia workspace.")
    return 0


# ------------------------------------------------------------------- commands


def command_connect(args: argparse.Namespace, paths: Paths) -> int:
    """Explicitly enroll/re-enable and run under the singleton connection lease."""
    # A connected node inherits this process's host permissions. Reject a
    # privileged account before consuming a grant or mutating enrollment state.
    assert_safe_node_account()
    with ConnectionLease(paths.connection_lock) as lease:
        return _command_connect_owned(args, paths, lease)


def command_account_cutover(args: argparse.Namespace, paths: Paths) -> int:
    """Run one installer-owned, crash-described account replacement phase."""

    from .account_cutover import (
        abort_prepared,
        activate,
        commit,
        finalize,
        inspect,
        prepare,
        publish,
        relocate_prior_runtime,
        retry_remote_retirement,
        rollback,
    )

    action = args.cutover_action
    if action == "prepare":
        pairing_code = _pairing_code_from_stdin()
        config = prepare(
            paths,
            pairing_code=pairing_code,
            api_url=args.api_url,
            tier=args.tier,
            access=args.access,
            native_mount_enabled=bool(args.native_mount_enabled),
            workspace=Path(args.workspace).expanduser() if args.workspace else None,
            adopt_existing_workspace=bool(args.adopt_existing_workspace),
        )
        document: object = {
            "phase": "prepared",
            "account_id": config.account_id,
            "account_email": config.account_email,
            "session_id": config.session_id,
        }
    elif action == "activate":
        activate(paths)
        document = {"phase": "activating"}
    elif action == "publish":
        config = publish(paths)
        document = {"phase": "published", "account_id": config.account_id}
    elif action == "set-prior-runtime":
        relocate_prior_runtime(paths, Path(args.runtime))
        document = {"phase": "activating"}
    elif action == "rollback":
        config = rollback(paths)
        document = {
            "phase": "rolled_back",
            "account_id": None if config is None else config.account_id,
        }
    elif action == "commit":
        config = commit(paths)
        document = {"phase": "committed", "account_id": config.account_id}
    elif action == "finalize":
        config = finalize(paths)
        document = {"phase": "absent", "account_id": config.account_id}
    elif action == "abort":
        retired = abort_prepared(paths)
        document = {
            "phase": "aborted" if retired else "rolled_back",
            "remote_retired": retired,
        }
    elif action == "retry-retirement":
        retired = retry_remote_retirement(paths)
        document = {
            "phase": "absent" if retired else "rolled_back",
            "remote_retired": retired,
        }
    else:
        document = inspect(paths)
        if document is None:
            document = {"phase": "absent"}
    _emit(document, True)
    return 0


def _close_workspace_runtime(
    backend: FabricMountBackend | EngineWorkspaceHandle,
    coordinator: FabricSyncCoordinator,
    database: FabricDatabase,
    workspace: WorkspaceBoundary | None,
) -> None:
    """Close one runtime completely while preserving its durable journal."""

    try:
        backend.close()
    finally:
        try:
            coordinator.close()
        finally:
            try:
                database.close()
            finally:
                if workspace is not None:
                    workspace.close()


def _hold_native_mount_until_released(
    fuse_mount: "FabricFuseMount | FSKitMount",
    logger: NodeLogger,
    *,
    sleep: Callable[[float], None] | None = None,
) -> int:
    """Keep serving an attached mount and retry its detach until the OS agrees.

    Returns the number of retries it took. This loop is deliberately unbounded:
    the only alternative to waiting is exiting under a live kernel mount, which
    is the one outcome the stop protocol exists to prevent.
    """

    pause = sleep or time.sleep
    mount_point = str(getattr(fuse_mount, "mount_point", ""))
    logger.record("fabric_mount_release_held", mount_point=mount_point, attempts=0)
    attempts = 0
    while True:
        pause(MOUNT_RELEASE_RETRY_SECONDS)
        attempts += 1
        try:
            released = bool(fuse_mount.close())
        except BaseException as error:  # noqa: BLE001 - keep serving, keep retrying
            released = False
            logger.record(
                "fabric_mount_release_retry_failed",
                mount_point=mount_point,
                error_type=type(error).__name__,
                error=str(error)[:200],
            )
        if released or bool(getattr(fuse_mount, "detached_for_process_exit", False)):
            logger.record(
                "fabric_mount_released_after_hold",
                mount_point=mount_point,
                attempts=attempts,
            )
            return attempts
        if attempts in (1, 5) or attempts % 30 == 0:
            logger.record(
                "fabric_mount_release_held", mount_point=mount_point, attempts=attempts
            )


def _teardown_connection_resources(
    *,
    logger: NodeLogger,
    executor: CommandExecutor | None,
    file_provider: FabricFileProviderBridge | AccountFileProviderBridge | None,
    runtime_manager: WorkspaceRuntimeManager | None,
    fuse_mount: FabricFuseMount | FSKitMount | None,
    mount_backend: (
        FabricMountBackend | MultiWorkspaceMountBackend | EngineMountTopology | None
    ),
    fabric: FabricSyncCoordinator,
    database: FabricDatabase,
) -> bool:
    """Attempt every teardown edge; one broken close must not strand the mount."""

    def attempt(component: str, function: Callable[[], Any]) -> tuple[bool, Any]:
        try:
            return True, function()
        except BaseException as error:
            logger.record(
                "connection_resource_close_failed",
                component=component,
                error_type=type(error).__name__,
                error=str(error),
            )
            return False, None

    if executor is not None:
        attempt("executor", executor.close)
    if file_provider is not None:
        attempt("file_provider", file_provider.close)

    # Fence new account routes before asking the native dispatcher to drain.
    # A second manager close after a successful unmount picks up any runtime
    # whose final open handle was released during that drain.
    if runtime_manager is not None:
        attempt("workspace_runtime_manager_pre_unmount", runtime_manager.close)
    mount_stopped = True
    if fuse_mount is not None:
        mount_closed, result = attempt("native_mount", fuse_mount.close)
        mount_stopped = bool(mount_closed and result)
    if not mount_stopped:
        if bool(getattr(fuse_mount, "detached_for_process_exit", False)):
            # The OS volume and exact FUSE-T helper are gone, but fusepy's
            # blocking callback has not returned yet. Do not close manager,
            # SQLite, or staged-write state beneath that callback. The process
            # is already exiting and will release those descriptors safely.
            logger.record("fabric_shutdown_draining_until_process_exit")
            return True
        logger.record("fabric_shutdown_deferred_for_mount")
        return False

    if runtime_manager is not None:
        attempt("workspace_runtime_manager", runtime_manager.close)
    if mount_backend is not None:
        attempt("mount_backend", mount_backend.close)

    # Manager-owned primary runtime closure is idempotent. These final direct
    # closes are a fallback when manager teardown itself failed partway through;
    # without a manager, this connection still constructed and owns Fabric even
    # when a caller supplied a different maintenance poller.
    attempt("fabric_coordinator", fabric.close)
    attempt("fabric_database", database.close)
    return True


def _fabric_runtime_has_runnable_work(
    database: FabricDatabase, coordinator: FabricSyncCoordinator,
) -> bool:
    """Keep retained work bound to its original workspace storage authority."""
    health = coordinator.health_snapshot()
    return bool(
        database.get_runnable_local_transfer_intent() is not None
        or health.pending_operations
        or health.commit_unknown
        or health.pending_remote_work
    )


def _create_workspace_runtime_manager(
    *,
    paths: Paths,
    config: NodeConfig,
    client: SignedClient,
    installation_id: str,
    mount_backend: MultiWorkspaceMountBackend | EngineMountTopology,
    runtime_factory: Callable[[WorkspaceCatalogEntry, str], WorkspaceRuntime],
    primary_runtime: WorkspaceRuntime,
    logger: NodeLogger,
    primary_storage_error: Disconnected | None = None,
) -> WorkspaceRuntimeManager:
    """Share catalog authority, quota, and recovery across every account route.

    The caller retains preparation and teardown ordering, including the File
    Provider candidate's fallback-safe primary close and split worker binding.
    No backend or coordinator is constructed or owned by this factory.
    """

    if config.account_id is None:
        raise StateError("An account workspace manager requires an account identity.")

    def scan_startup_recovery(
        visible_session_ids: frozenset[str], limit: int
    ) -> StartupRecoveryScan:
        return _scan_account_pending_workspace_journals(
            paths,
            config,
            visible_session_ids,
            installation_id=installation_id,
            limit=limit,
        )

    return WorkspaceRuntimeManager(
        config=config,
        catalog_client=WorkspaceCatalogClient(
            client, config.host_id, access_mode=config.access
        ),
        catalog_store=WorkspaceCatalogStore(
            paths.account_workspace_catalog(config.account_id)
        ),
        mount_backend=mount_backend,  # type: ignore[arg-type] - split projection
        runtime_factory=runtime_factory,
        primary_session_id=config.session_id,
        primary_runtime=primary_runtime,
        primary_storage_error=primary_storage_error,
        batch_heartbeat_primary=False,
        startup_recovery_scanner=scan_startup_recovery,
        logger=logger,
    )


def _create_catalog_workspace_runtime(
    entry: WorkspaceCatalogEntry,
    label: str,
    *,
    paths: Paths,
    config: NodeConfig,
    client: SignedClient,
    installation_id: str,
    logger: NodeLogger,
    fuse_t_transport_backend: str | None = None,
    split_server: MultiWorkspaceEngineServer | None = None,
) -> WorkspaceRuntime:
    """Build one lazy, independently fenced Fabric workspace runtime.

    With ``split_server`` the FUSE loop lives in the mount worker: the runtime
    gets an ``EngineWorkspaceHandle`` (state paths + close safety over the
    link) instead of a ``FabricMountBackend``, so stage recovery and write
    sessions exist exactly once, in the process that serves the namespace.
    """

    if config.account_id is None or entry.attachment is None:
        raise StateError("The workspace catalog entry has no active account attachment.")
    state = _catalog_workspace_state(
        paths,
        account_id=config.account_id,
        session_id=entry.session_id,
        installation_id=installation_id,
    )
    _preflight_authoritative_journal(state.database)
    claim = claim_workspace_root(
        state.workspace,
        installation_id=installation_id,
    )
    if claim.is_bound and (
        claim.host_id != config.host_id or claim.session_id != entry.session_id
    ):
        # Re-pairing the same signed-in account can rotate the connected host
        # while retaining the same workspace. Rebind only the exact local
        # installation/workspace marker and exact remote session; never steal a
        # copied marker or cross-account materialized root.
        if claim.host_id is None or claim.session_id != entry.session_id:
            raise WorkspaceClaimInvalid(
                "The cached workspace belongs to a different Meshia authority."
            )
        claim = rebind_workspace_root_claim(
            state.workspace,
            installation_id=installation_id,
            workspace_id=claim.workspace_id,
            expected_host_id=claim.host_id,
            expected_session_id=claim.session_id,
            host_id=config.host_id,
            session_id=entry.session_id,
        )
    claim = bind_workspace_root_claim(
        claim.canonical_root,
        installation_id=installation_id,
        workspace_id=claim.workspace_id,
        host_id=config.host_id,
        session_id=entry.session_id,
    )

    workspace: WorkspaceBoundary | None = None
    database: FabricDatabase | None = None
    coordinator: FabricSyncCoordinator | None = None
    backend: FabricMountBackend | EngineWorkspaceHandle | None = None
    try:
        workspace = WorkspaceBoundary(claim.canonical_root)
        database = FabricDatabase(state.database)
        cache = FabricRangeCache(state.cache)
        watch = FabricWatch(Path(claim.canonical_root))
        coordinator = FabricSyncCoordinator(
            SignedFabricTransport(
                client,
                config.host_id,
                allow_insecure_loopback=_uses_insecure_loopback_development_origin(
                    config.api_url
                ),
                object_edge=ObjectEdgeSession(default_registry(), entry.session_id),
            ),
            database,
            cache,
            watch,
            workspace,
            FabricAuthority(
                host_id=config.host_id,
                session_id=entry.session_id,
                host_generation=config.generation,
                attachment_id=entry.attachment.id,
                workspace_id=claim.workspace_id,
            ),
            state.staging,
            staging_admission_path=state.staging / "admission.sqlite3",
            adoption_pending=claim.adoption_pending,
            logger=logger,
        )
        coordinator.prepare_mount_namespace()
        if split_server is not None:
            session_id = entry.session_id
            backend = EngineWorkspaceHandle(
                workspace_name=label,
                database_path=state.database,
                cache_path=state.cache,
                workspace_root=claim.canonical_root,
                can_close=lambda: split_server.workspace_can_close(session_id),
            )
            # The engine asks the mount whether a path can be reclaimed; in
            # split mode that question crosses the link, and an unreachable
            # mount answers "unknown" (do not reclaim).
            coordinator.set_mount_cleanup_fence(split_server.cleanup_fence_for(session_id))
        else:
            backend = FabricMountBackend(
                database,
                coordinator,
                workspace,
                label,
                logger=logger,
                fuse_t_transport_backend=fuse_t_transport_backend,
            )
    except BaseException:
        if backend is not None and coordinator is not None and database is not None:
            _close_workspace_runtime(backend, coordinator, database, workspace)
        else:
            if coordinator is not None:
                coordinator.close()
            if database is not None:
                database.close()
            if workspace is not None:
                workspace.close()
        raise

    assert workspace is not None
    assert database is not None
    assert coordinator is not None
    assert backend is not None
    close_lock = threading.Lock()
    closed = False

    def close_runtime() -> None:
        nonlocal closed
        with close_lock:
            if closed:
                return
            closed = True
        _close_workspace_runtime(backend, coordinator, database, workspace)

    return WorkspaceRuntime(
        backend=backend,
        coordinator=coordinator,
        # Backend safety fences a just-closed native write until its private
        # stage reaches the journal. The manager separately fences runnable
        # durable work during capacity eviction, but may still retire revoked
        # authority while preserving its journal.
        safe_to_close=backend.can_close,
        close_runtime=close_runtime,
        attachment_id=entry.attachment.id,
        has_runnable_work=lambda: _fabric_runtime_has_runnable_work(database, coordinator),
    )


def _pairing_code_from_stdin() -> str:
    """Read one bounded secret line without prompting, echoing, or retaining it."""

    try:
        payload = sys.stdin.read(PAIR_STDIN_MAX_CHARS + 1)
    except (OSError, UnicodeError):
        raise InvalidArgument("Could not read the one-time pairing code from stdin.") from None
    if len(payload) > PAIR_STDIN_MAX_CHARS:
        raise InvalidArgument("The stdin pairing-code line is too long.")
    lines = payload.splitlines()
    if len(lines) != 1:
        raise InvalidArgument("Provide exactly one pairing-code line on stdin.")
    pairing_code = lines[0].strip()
    if not pairing_code:
        raise InvalidArgument("The stdin pairing-code line is empty.")
    return pairing_code


def _normalized_absolute_path(value: Path | str) -> str:
    return os.path.normcase(os.path.abspath(os.fspath(Path(value).expanduser())))


def _load_workspace_state_locations_unlocked(paths: Paths) -> dict[str, str] | None:
    """Read the one legacy-state binding without following a replacement link."""

    location = paths.workspace_state_locations
    flags = (
        os.O_RDONLY
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOINHERIT", 0)
    )
    try:
        descriptor = os.open(location, flags)
    except FileNotFoundError:
        return None
    except OSError as error:
        raise StateError("The workspace state-location registry is unreadable.") from error
    try:
        info = os.fstat(descriptor)
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_size < 2
            or info.st_size > WORKSPACE_STATE_LOCATIONS_MAX_BYTES
            or (os.name != "nt" and info.st_nlink != 1)
            or (os.name != "nt" and stat.S_IMODE(info.st_mode) & 0o077)
        ):
            raise StateError("The workspace state-location registry is not private and bounded.")
        raw = os.read(descriptor, WORKSPACE_STATE_LOCATIONS_MAX_BYTES + 1)
        if len(raw) != info.st_size:
            raise StateError("The workspace state-location registry changed while being read.")
    except OSError as error:
        raise StateError("The workspace state-location registry is unreadable.") from error
    finally:
        os.close(descriptor)
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeError, ValueError) as error:
        raise StateError("The workspace state-location registry is invalid.") from error
    if not isinstance(document, dict) or set(document) != {"schema", "legacy"}:
        raise StateError("The workspace state-location registry has an unsupported shape.")
    legacy = document.get("legacy")
    if (
        document.get("schema") != WORKSPACE_STATE_LOCATIONS_SCHEMA
        or not isinstance(legacy, dict)
        or set(legacy)
        != {"account_id", "session_id", "workspace_id", "workspace_root"}
    ):
        raise StateError("The workspace state-location registry has an unsupported schema.")
    values = {key: legacy.get(key) for key in legacy}
    for key, pattern in (
        ("account_id", POSTGRES_UUID_RE),
        ("session_id", UUID_RE),
        ("workspace_id", UUID_RE),
    ):
        if not isinstance(values[key], str) or pattern.fullmatch(values[key]) is None:
            raise StateError("The workspace state-location registry has invalid authority.")
    root = values["workspace_root"]
    if (
        not isinstance(root, str)
        or not root
        or "\x00" in root
        or not Path(root).is_absolute()
    ):
        raise StateError("The workspace state-location registry has an invalid root.")
    return values  # type: ignore[return-value]


def _register_authenticated_legacy_workspace_state(
    paths: Paths,
    config: NodeConfig,
    claim: WorkspaceRootClaim,
    state: WorkspaceStatePaths,
) -> None:
    """Bind the retained singleton state to its exact authenticated authority."""

    legacy = paths.legacy_workspace_state
    if _normalized_absolute_path(state.database) != _normalized_absolute_path(
        legacy.database
    ):
        return
    if config.account_id is None or config.workspace_id is None:
        # Older private control planes cannot authenticate an account-scoped map.
        return
    if (
        not claim.is_bound
        or claim.workspace_id != config.workspace_id
        or claim.host_id != config.host_id
        or claim.session_id != config.session_id
        or _normalized_absolute_path(claim.canonical_root)
        != _normalized_absolute_path(config.workspace)
    ):
        raise WorkspaceClaimInvalid(
            "The retained workspace state does not match the authenticated attachment."
        )
    expected = {
        "account_id": config.account_id,
        "session_id": config.session_id,
        "workspace_id": config.workspace_id,
        "workspace_root": claim.canonical_root,
    }
    with file_lock(paths.workspace_state_locations_lock):
        current = _load_workspace_state_locations_unlocked(paths)
        if current is not None:
            if current != expected:
                raise WorkspaceClaimInvalid(
                    "The retained workspace state is already bound to different Meshia authority."
                )
            return
        write_private_file(
            paths.workspace_state_locations,
            json.dumps(
                {"schema": WORKSPACE_STATE_LOCATIONS_SCHEMA, "legacy": expected},
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8"),
        )


def _catalog_workspace_state(
    paths: Paths,
    *,
    account_id: str,
    session_id: str,
    installation_id: str,
) -> WorkspaceStatePaths:
    """Resolve one catalog runtime to its sole authenticated local state tree."""

    with file_lock(paths.workspace_state_locations_lock):
        legacy_binding = _load_workspace_state_locations_unlocked(paths)
    return _catalog_workspace_state_from_binding(
        paths,
        account_id=account_id,
        session_id=session_id,
        installation_id=installation_id,
        legacy_binding=legacy_binding,
    )


def _catalog_workspace_state_from_binding(
    paths: Paths,
    *,
    account_id: str,
    session_id: str,
    installation_id: str,
    legacy_binding: dict[str, str] | None,
) -> WorkspaceStatePaths:
    """Resolve a state tree from one already pinned legacy binding snapshot."""

    if legacy_binding is None:
        return paths.account_workspace_state(account_id, session_id)
    if legacy_binding["session_id"] == session_id:
        if legacy_binding["account_id"] != account_id:
            raise WorkspaceClaimInvalid(
                "The retained workspace state belongs to a different Meshia account."
            )
        claim = validate_workspace_root_claim(
            legacy_binding["workspace_root"],
            installation_id=installation_id,
            workspace_id=legacy_binding["workspace_id"],
            require_bound=True,
        )
        if (
            claim.session_id != session_id
            or _normalized_absolute_path(claim.canonical_root)
            != _normalized_absolute_path(legacy_binding["workspace_root"])
        ):
            raise WorkspaceClaimInvalid(
                "The retained workspace root no longer matches its registered authority."
            )
        legacy = paths.legacy_workspace_state
        return WorkspaceStatePaths(
            root=legacy.root,
            workspace=Path(claim.canonical_root),
            database=legacy.database,
            cache=legacy.cache,
            staging=legacy.staging,
        )
    return paths.account_workspace_state(account_id, session_id)


def _restore_registered_legacy_workspace_state(
    store: ConfigStore,
    paths: Paths,
    config: NodeConfig,
    *,
    installation_id: str,
) -> NodeConfig:
    """Recover the exact pre-catalog primary after a same-session re-pair."""

    if config.account_id is None:
        return config
    with file_lock(paths.workspace_state_locations_lock):
        legacy_binding = _load_workspace_state_locations_unlocked(paths)
    if legacy_binding is None or (
        legacy_binding["account_id"] != config.account_id
        or legacy_binding["session_id"] != config.session_id
    ):
        return config

    registered_root = legacy_binding["workspace_root"]
    already_registered = (
        _normalized_absolute_path(config.workspace)
        == _normalized_absolute_path(registered_root)
        and config.workspace_id == legacy_binding["workspace_id"]
    )
    if not already_registered:
        scoped = paths.account_workspace_state(config.account_id, config.session_id)
        if _normalized_absolute_path(config.workspace) != _normalized_absolute_path(
            scoped.workspace
        ):
            raise WorkspaceClaimInvalid(
                "This Meshia session is already bound to a different retained workspace root."
            )
        if scoped.database.exists():
            raise WorkspaceClaimInvalid(
                "Both retained and account-scoped Fabric journals exist for this Meshia "
                "session; repair the duplicate authority before reconnecting."
            )

    claim = validate_workspace_root_claim(
        registered_root,
        installation_id=installation_id,
        workspace_id=legacy_binding["workspace_id"],
        require_bound=True,
    )
    if claim.session_id != config.session_id or claim.host_id is None:
        raise WorkspaceClaimInvalid(
            "The retained workspace marker belongs to a different Meshia authority."
        )
    if claim.host_id != config.host_id:
        claim = rebind_workspace_root_claim(
            claim.canonical_root,
            installation_id=installation_id,
            workspace_id=claim.workspace_id,
            expected_host_id=claim.host_id,
            expected_session_id=config.session_id,
            host_id=config.host_id,
            session_id=config.session_id,
        )
    if already_registered:
        return config

    expected_authority = (
        config.account_id,
        config.host_id,
        config.session_id,
        config.generation,
    )

    def restore(current: NodeConfig) -> None:
        if (
            current.account_id,
            current.host_id,
            current.session_id,
            current.generation,
        ) != expected_authority:
            raise WorkspaceClaimInvalid(
                "The Meshia authority changed while retained state was restored."
            )
        current.workspace = claim.canonical_root
        current.workspace_id = claim.workspace_id
        current.workspace_adoption_pending = claim.adoption_pending

    restored, _ = store.update(restore)
    return restored


def _configured_workspace_state(
    paths: Paths, config: NodeConfig
) -> WorkspaceStatePaths:
    """Select one authority's state without moving legacy pending evidence."""

    if config.account_id is not None:
        scoped = paths.account_workspace_state(config.account_id, config.session_id)
        if _normalized_absolute_path(config.workspace) == _normalized_absolute_path(
            scoped.workspace
        ):
            return scoped
    return paths.legacy_workspace_state


def _exact_legacy_workspace_authority(
    paths: Paths,
    config: NodeConfig,
    canonical_root: str,
) -> LegacyAuthoritySnapshot | None:
    """Prove a pre-marker install already owned this non-empty namespace."""

    if config.workspace_id is not None or not paths.fabric_db_path.is_file():
        return None
    try:
        with FabricDatabase(paths.fabric_db_path) as database:
            return database.get_exact_legacy_authority(
                host_id=config.host_id,
                session_id=config.session_id,
                host_generation=config.generation,
                workspace_root=canonical_root,
            )
    except (OSError, MeshiaNodeError, ValueError):
        return None


def _claim_exact_legacy_workspace_database(
    paths: Paths,
    config: NodeConfig,
    claim: WorkspaceRootClaim,
    snapshot: LegacyAuthoritySnapshot | None,
    *,
    explicit_adoption: bool = False,
) -> None:
    """CAS a genuine pre-marker DB epoch onto its newly written marker UUID."""

    if (
        config.workspace_id is not None
        or claim.adoption_pending
        or (explicit_adoption and snapshot is None)
    ):
        return
    try:
        with FabricDatabase(paths.fabric_db_path) as database:
            if snapshot is None:
                # Crash replay after the NULL->UUID DB CAS but before config
                # publication: recover only the exact same marker UUID, scope,
                # authority, root and still-published head.
                current = database.current_authority()
                head = database.get_remote_manifest_head()
                if (
                    current is None
                    or head is None
                    or current.host_id != config.host_id
                    or current.session_id != config.session_id
                    or current.host_generation != config.generation
                    or current.workspace_id != claim.workspace_id
                    or _normalized_absolute_path(current.workspace_root)
                    != _normalized_absolute_path(claim.canonical_root)
                ):
                    raise WorkspaceClaimInvalid(
                        "The legacy Fabric authority no longer matches this workspace."
                    )
                expected_scope_id = current.scope_id
                expected_generation = head.generation
                expected_manifest_digest = head.digest
            else:
                expected_scope_id = snapshot.scope_id
                expected_generation = snapshot.head_generation
                expected_manifest_digest = snapshot.head_digest
            claimed = database.claim_legacy_workspace(
                expected_scope_id=expected_scope_id,
                expected_generation=expected_generation,
                expected_manifest_digest=expected_manifest_digest,
                workspace_id=claim.workspace_id,
            )
            if claimed is None or claimed.workspace_id != claim.workspace_id:
                raise WorkspaceClaimInvalid(
                    "The legacy Fabric head changed while workspace ownership was claimed."
                )
    except WorkspaceClaimInvalid:
        raise
    except (OSError, MeshiaNodeError, ValueError) as error:
        raise WorkspaceClaimInvalid(
            "The legacy Fabric authority could not be claimed safely."
        ) from error


def _prepare_workspace_root_claim(
    paths: Paths,
    existing: NodeConfig | None,
    requested_root: Path,
    *,
    adopt_existing: bool,
) -> tuple[WorkspaceRootClaim, LegacyAuthoritySnapshot | None]:
    """Claim/validate the root before any grant can reach the network."""

    # Inspect the caller-selected root before creating even the local device
    # identity. A missing adoption decision must not consume the one-time grant,
    # write configuration, chmod the root, or otherwise turn a rejected connect
    # into a partially installed node.
    initial = workspace_root_claim_status(requested_root)
    if initial.state == "invalid":
        raise WorkspaceClaimInvalid(
            initial.reason or "The workspace ownership marker is invalid or mismatched."
        )
    same_configured_root = bool(
        existing is not None
        and _normalized_absolute_path(existing.workspace)
        == _normalized_absolute_path(initial.canonical_root)
    )
    pending_rebind: WorkspaceRootClaim | None = None
    if (
        existing is not None
        and same_configured_root
        and existing.installation_id is not None
        and existing.workspace_id is not None
    ):
        current_claim = initial.claim
        if (
            current_claim is not None
            and current_claim.is_bound
            and current_claim.installation_id == existing.installation_id
            and current_claim.workspace_id == existing.workspace_id
            and existing.host_id
            and existing.session_id
            and (
                current_claim.host_id != existing.host_id
                or current_claim.session_id != existing.session_id
            )
        ):
            assert current_claim.host_id is not None
            assert current_claim.session_id is not None
            # Recover the sole cross-file crash window in explicit re-pair:
            # config is published only after proof succeeds, so its new remote
            # binding may safely complete an exact old-marker CAS on restart.
            pending_rebind = current_claim
        # A configured path is an identity-bearing authority, not a fresh
        # adoption candidate. Replacing its directory at the same spelling
        # must fail before a new public file can downgrade the diagnosis to an
        # opt-in adoption prompt.
        if pending_rebind is None:
            claimed = workspace_root_claim_status(
                requested_root,
                installation_id=existing.installation_id,
                workspace_id=existing.workspace_id,
                host_id=existing.host_id,
                session_id=existing.session_id,
                require_bound=True,
            )
            if claimed.state == "invalid":
                raise WorkspaceClaimInvalid(
                    claimed.reason or "The configured workspace ownership marker is invalid."
                )
            initial = claimed
    expected_workspace_id = (
        existing.workspace_id if existing is not None and same_configured_root else None
    )
    expected_host_id = (
        existing.host_id
        if existing is not None
        and same_configured_root
        and expected_workspace_id is not None
        and initial.state == "bound"
        else None
    )
    legacy_snapshot = (
        _exact_legacy_workspace_authority(paths, existing, initial.canonical_root)
        if existing is not None
        and same_configured_root
        and existing.workspace_id is None
        else None
    )
    exact_legacy_migration = legacy_snapshot is not None
    legacy_marker_missing = bool(
        existing is not None
        and same_configured_root
        and existing.workspace_id is None
        and initial.state in {"missing", "adoption_required"}
    )
    if legacy_marker_missing and not (adopt_existing or exact_legacy_migration):
        raise WorkspaceClaimInvalid(
            "The pre-marker workspace has no exact active Fabric authority and published head."
        )
    if initial.requires_adoption and not (adopt_existing or exact_legacy_migration):
        raise WorkspaceAdoptionRequired(
            "The selected workspace is non-empty and has no matching Meshia ownership "
            "marker. Re-run with --adopt-existing-workspace to claim it explicitly."
        )

    if existing is not None and not all(
        (paths.identity_dir / name).is_file()
        for name in ("device-key.pem", "installation-id")
    ):
        # Never generate a fresh key under an already-enrolled host/session and
        # then bless its old DB baseline. That new key has no remote authority;
        # treating it as the old installation would turn copied config+DB files
        # into workspace ownership proof.
        raise WorkspaceClaimInvalid(
            "The enrolled device identity is missing; forget and re-enroll before "
            "claiming this workspace."
        )

    identity = DeviceIdentity.load_or_create(paths.identity_dir)
    installation_id = identity.describe().installation_id
    if (
        existing is not None
        and existing.installation_id is not None
        and existing.installation_id != installation_id
    ):
        raise WorkspaceClaimInvalid(
            "The persisted workspace belongs to a different Meshia installation."
        )

    if pending_rebind is not None:
        assert existing is not None
        assert existing.installation_id is not None
        assert existing.workspace_id is not None
        assert pending_rebind.host_id is not None
        assert pending_rebind.session_id is not None
        rebind_workspace_root_claim(
            requested_root,
            installation_id=existing.installation_id,
            workspace_id=existing.workspace_id,
            expected_host_id=pending_rebind.host_id,
            expected_session_id=pending_rebind.session_id,
            host_id=existing.host_id,
            session_id=existing.session_id,
        )
        initial = workspace_root_claim_status(
            requested_root,
            installation_id=existing.installation_id,
            workspace_id=existing.workspace_id,
            host_id=existing.host_id,
            session_id=existing.session_id,
            require_bound=True,
        )
        if initial.state == "invalid":
            raise WorkspaceClaimInvalid(
                initial.reason or "The repaired workspace ownership marker is invalid."
            )

    expected_session_id = (
        existing.session_id
        if existing is not None
        and same_configured_root
        and expected_workspace_id is not None
        and initial.state == "bound"
        else None
    )
    status = workspace_root_claim_status(
        requested_root,
        installation_id=installation_id,
        workspace_id=expected_workspace_id,
        host_id=expected_host_id,
        session_id=expected_session_id,
        require_bound=False,
    )
    if status.state == "invalid":
        raise WorkspaceClaimInvalid(
            status.reason or "The workspace ownership marker is invalid or mismatched."
        )
    if status.state in {"provisional", "bound"}:
        if existing is None and status.state == "bound":
            raise WorkspaceClaimInvalid(
                "The workspace is bound to an enrollment whose local configuration is missing."
            )
        return (
            validate_workspace_root_claim(
                requested_root,
                installation_id=installation_id,
                workspace_id=(
                    expected_workspace_id
                    or (status.claim.workspace_id if status.claim is not None else None)
                ),
                host_id=expected_host_id,
                session_id=expected_session_id,
                require_bound=False,
            ),
            legacy_snapshot,
        )

    # The early check above established the adoption decision before identity
    # creation. Repeating the state predicate here would reopen the legacy DB
    # proof and provide no stronger race fence; claim_workspace_root performs
    # the anchored final check immediately before marker publication.
    if (
        existing is not None
        and same_configured_root
        and existing.workspace_id is not None
        and not adopt_existing
    ):
        # A claimed root losing its marker is root replacement/tampering, even
        # when the replacement happens to be empty. Never silently recreate the
        # prior workspace id and thereby reuse its clean DB baselines.
        raise WorkspaceClaimInvalid(
            "The claimed workspace ownership marker is missing."
        )

    return (
        claim_workspace_root(
            requested_root,
            installation_id=installation_id,
            # Explicit re-adoption after a missing marker creates a new identity so
            # the DB authority fence cannot reuse state from the replaced root.
            workspace_id=(
                expected_workspace_id
                if expected_workspace_id is not None and not adopt_existing
                else None
            ),
            adopt=bool(adopt_existing or exact_legacy_migration),
            adoption_pending=(False if exact_legacy_migration else None),
        ),
        legacy_snapshot,
    )


def _command_connect_owned(
    args: argparse.Namespace, paths: Paths, lease: ConnectionLease
) -> int:
    store = ConfigStore(paths)
    existing = store.load()
    _preflight_authoritative_journal(
        _configured_workspace_state(paths, existing).database
        if existing is not None
        else paths.fabric_db_path
    )
    if args.pair_stdin and args.pairing_code is not None:
        raise InvalidArgument("Choose either a positional pairing code or --pair-stdin.")
    workspace_path = Path(args.workspace).expanduser() if args.workspace else None
    # An explicit --access always wins; otherwise keep whatever this node is
    # already enrolled with, and fall back to the safe default on a first connect.
    # A silent reconnect must not widen access, and must not undo the owner's
    # earlier choice either.
    access = args.access or (existing.access if existing else DEFAULT_ACCESS_MODE)
    tier = args.tier or (existing.tier if existing else "compute")
    native_mount_enabled = (
        args.native_mount_enabled
        if args.native_mount_enabled is not None
        else existing.native_mount_enabled
        if existing is not None
        else True
    )
    mount_backend_choice = (
        args.mount_backend
        if getattr(args, "mount_backend", None) is not None
        else existing.mount_backend
        if existing is not None
        else "auto"
    )
    requested_workspace = workspace_path or (
        Path(existing.workspace).expanduser() if existing else paths.default_workspace
    )
    workspace_claim, legacy_snapshot = _prepare_workspace_root_claim(
        paths,
        existing,
        requested_workspace,
        adopt_existing=bool(args.adopt_existing_workspace),
    )
    workspace_path = Path(workspace_claim.canonical_root)

    # Do not consume a one-time grant from stdin (or even prompt for it) until
    # the caller-selected root has passed the ownership/adoption gate above.
    # A rejected non-empty or tampered root must leave the grant available for
    # a corrected invocation.
    pairing_code = _pairing_code_from_stdin() if args.pair_stdin else args.pairing_code
    if pairing_code is None and existing is None:
        if sys.stdin.isatty():
            pairing_code = getpass.getpass("One-time pairing code: ").strip()
        if not pairing_code:
            raise InvalidArgument("A one-time pairing code is required for the first connect.")
    enrollment_api_url: str | None = None
    if pairing_code:
        if PAIRING_CODE_RE.fullmatch(pairing_code) is None:
            raise InvalidArgument("The pairing code is invalid or expired.")
        enrollment_api_url = args.api_url or (existing.api_url if existing else None)
        if not enrollment_api_url:
            raise InvalidArgument("--api-url is required when enrolling.")
        enrollment_api_url = validate_api_url(enrollment_api_url)
        if existing and args.api_url and enrollment_api_url != existing.api_url:
            raise InvalidArgument(
                "The enrolled control-plane origin cannot change. Run `meshia-node forget` first."
            )
    if args.enroll_only and existing is not None and existing.attachment_id is not None:
        # A stale prior foreground run can leave a live 90-second lease. Release
        # it while we still have the old authority, then persist the requested
        # attachment-free enrolled state below.
        identity = DeviceIdentity.load_or_create(paths.identity_dir)
        try:
            disconnect(SignedClient(store, identity), store)
        except Disconnected as error:
            _mark_disconnected(store, reason_code=error.reason_code)
        existing = store.require()
        access = args.access or existing.access
        tier = args.tier or existing.tier
    if pairing_code:
        assert enrollment_api_url is not None
        config = enroll(
            paths=paths,
            api_url=enrollment_api_url,
            pairing_code=pairing_code,
            tier=tier,
            access=access,
            workspace=workspace_path,
            workspace_claim=workspace_claim,
            native_mount_enabled=native_mount_enabled,
            display_name=args.name,
        )
        assert config.installation_id is not None
        config = _restore_registered_legacy_workspace_state(
            store,
            paths,
            config,
            installation_id=config.installation_id,
        )
        if mount_backend_choice != config.mount_backend:

            def _persist_mount_backend(current: NodeConfig) -> None:
                current.mount_backend = mount_backend_choice

            config, _ = store.update(_persist_mount_backend)
    else:
        assert existing is not None
        installation_id = DeviceIdentity.load_or_create(
            paths.identity_dir
        ).describe().installation_id
        workspace_claim = bind_workspace_root_claim(
            workspace_claim.canonical_root,
            installation_id=installation_id,
            workspace_id=workspace_claim.workspace_id,
            host_id=existing.host_id,
            session_id=existing.session_id,
        )
        _claim_exact_legacy_workspace_database(
            paths,
            existing,
            workspace_claim,
            legacy_snapshot,
            explicit_adoption=bool(args.adopt_existing_workspace),
        )

        def _rebind(current: NodeConfig) -> None:
            current.workspace = workspace_claim.canonical_root
            current.installation_id = installation_id
            current.workspace_id = workspace_claim.workspace_id
            current.workspace_adoption_pending = workspace_claim.adoption_pending
            current.native_mount_enabled = native_mount_enabled
            current.mount_backend = mount_backend_choice
            current.tier = tier
            current.access = access
            # `connect` is the one explicit action that may clear the sticky
            # disconnected state. `service run` never performs this step.
            current.lifecycle = "enrolled"
            current.attachment_id = None
            current.last_heartbeat_at = None
            current.disconnect_reason = None

        config, _ = store.update(_rebind)

    workspace_root = Path(config.workspace).expanduser()
    logger = NodeLogger(path=paths.log_path, quiet=args.json)
    if not config.native_mount_enabled and _retire_disabled_dead_mount_receipt(paths):
        logger.record("fabric_mount_disabled_receipt_retired")

    if args.enroll_only:
        # Enrollment has created no remote attachment and there is no runner PID
        # to advertise. This state is now safe for `service install && start`.
        _emit(_status_document(store), args.json)
        return 0

    if os.name == "nt" and config.tier == "compute":  # pragma: no cover - Windows hosts
        # Confined (`limited`) exec children run at Low integrity; the workspace
        # needs an inheritable Low label to be their one writable tree. Labeled
        # on every connect — not only in limited mode — because the dashboard
        # can flip a `full` node to `limited` live, mid-attachment. A labeling
        # failure is safe-but-broken (confined children cannot write anywhere),
        # so it is surfaced rather than fatal.
        from .winsec import WinsecUnavailable, set_workspace_low_label

        try:
            set_workspace_low_label(workspace_root)
        except WinsecUnavailable as error:
            logger.record("workspace_label_failed", error_code="WORKSPACE_LABEL_FAILED",
                          detail=str(error)[:200])

    _set_owned_pid(store, lease.pid)
    try:
        return _run_connection(
            store,
            paths,
            logger,
            max_iterations=args.max_iterations,
            disconnect_on_exit=True,
        )
    except Disconnected as error:
        _mark_disconnected(store, reason_code=error.reason_code)
        logger.record(
            "connection_disconnected",
            reason_code=error.reason_code or "REMOTE_AUTHORITY_REVOKED",
        )
        return 2
    finally:
        _clear_owned_pid(store, lease.pid)


def _run_connection(
    store: ConfigStore,
    paths: Paths,
    logger: NodeLogger,
    *,
    max_iterations: int | None,
    disconnect_on_exit: bool,
    maintenance: Any | None = None,
    shutdown_event: threading.Event | None = None,
    runtime_status_required: bool = False,
) -> int:
    """Attach and supervise one authority while the caller owns the lease."""
    config = store.require()
    identity = DeviceIdentity.load_or_create(paths.identity_dir)
    installation_id = identity.describe().installation_id
    config = _restore_registered_legacy_workspace_state(
        store,
        paths,
        config,
        installation_id=installation_id,
    )
    workspace_claim, legacy_snapshot = _prepare_workspace_root_claim(
        paths,
        config,
        Path(config.workspace).expanduser(),
        adopt_existing=False,
    )
    workspace_claim = bind_workspace_root_claim(
        workspace_claim.canonical_root,
        installation_id=installation_id,
        workspace_id=workspace_claim.workspace_id,
        host_id=config.host_id,
        session_id=config.session_id,
    )
    _claim_exact_legacy_workspace_database(
        paths, config, workspace_claim, legacy_snapshot
    )

    def persist_claim(current: NodeConfig) -> None:
        current.workspace = workspace_claim.canonical_root
        current.installation_id = installation_id
        current.workspace_id = workspace_claim.workspace_id
        current.workspace_adoption_pending = workspace_claim.adoption_pending

    config, _ = store.update(persist_claim)
    workspace_root = Path(workspace_claim.canonical_root)
    workspace_state = _configured_workspace_state(paths, config)
    _preflight_authoritative_journal(workspace_state.database)
    client = SignedClient(store, identity)
    # Enrollment proof already authenticated the immutable account/session.
    # Persist the local state binding before creating a remote attachment so a
    # conflicting retained journal fails without leaking a live remote lease.
    _register_authenticated_legacy_workspace_state(
        paths, config, workspace_claim, workspace_state
    )
    # Meshia object edge grants arrive with attach/heartbeat receipts; the
    # registry publishes a token-free status snapshot for `meshia-node status`.
    default_registry().configure(
        status_path=object_edge_status_path(paths.home),
        allow_insecure_loopback=_uses_insecure_loopback_development_origin(config.api_url),
        logger=logger,
    )
    primary_storage_error: Disconnected | None = None

    def observe_primary_storage(error: Disconnected) -> None:
        nonlocal primary_storage_error
        primary_storage_error = error

    attachment_id = attach(
        client, store, on_workspace_storage_unavailable=observe_primary_storage,
    )
    config = store.require()
    logger.record(
        "attached",
        host_id=config.host_id,
        attachment_id=attachment_id,
        tier=config.tier,
        access=config.access,
    )

    mount_shutdown_failed = False
    mount_release_held = False
    frontend_close_error: Exception | None = None
    with WorkspaceBoundary(workspace_root) as workspace:
        authority = FabricAuthority(
            host_id=config.host_id,
            session_id=config.session_id,
            host_generation=config.generation,
            attachment_id=attachment_id,
            workspace_id=config.workspace_id,
        )
        transport = SignedFabricTransport(
            client,
            config.host_id,
            allow_insecure_loopback=_uses_insecure_loopback_development_origin(
                config.api_url
            ),
            object_edge=ObjectEdgeSession(default_registry(), config.session_id),
        )
        database = FabricDatabase(workspace_state.database)
        cache = FabricRangeCache(workspace_state.cache)
        watch = FabricWatch(workspace_root)
        fabric = FabricSyncCoordinator(
            transport,
            database,
            cache,
            watch,
            workspace,
            authority,
            workspace_state.staging,
            staging_admission_path=(
                workspace_state.staging / "admission.sqlite3"
            ),
            adoption_pending=config.workspace_adoption_pending,
            logger=logger,
        )
        # Resolve crash-recovered retire evidence before Finder/Explorer can
        # observe the mounted namespace. In particular, a deleted-directory
        # tombstone must never be invalidated by its own aged open-handle bytes.
        fabric.prepare_mount_namespace()
        file_provider: (
            FabricFileProviderBridge | AccountFileProviderBridge | None
        ) = None
        fuse_mount: FabricFuseMount | FSKitMount | None = None
        mount_backend: (
            FabricMountBackend | MultiWorkspaceMountBackend | EngineMountTopology | None
        ) = None
        workspace_runtime_manager: WorkspaceRuntimeManager | None = None
        engine_server: SyncEngineServer | None = None
        mount_supervisor: MountWorkerSupervisor | None = None
        command_mount_point: Path | None = None
        file_provider_status = NativeFileProviderStatus(
            supported=sys.platform == "darwin",
            enabled=False,
            ready=False,
            state="native_files_disabled",
        )
        if config.native_mount_enabled:
            file_provider_status = native_file_provider_status()
            address = file_provider_status.bridge_address
            if address is not None:
                if config.account_id is not None:
                    candidate_backend: MultiWorkspaceMountBackend | None = None
                    candidate_manager: WorkspaceRuntimeManager | None = None
                    candidate_bridge: AccountFileProviderBridge | None = None
                    try:
                        primary_backend = FabricMountBackend(
                            database,
                            fabric,
                            workspace,
                            _file_provider_workspace_name(config),
                            logger=logger,
                            # File Provider is not transported through SMB/NFS;
                            # its native metadata must not inherit either mount's
                            # AppleDouble compatibility behavior.
                            fuse_t_transport_backend=None,
                        )
                        candidate_backend = MultiWorkspaceMountBackend(
                            paths.home, logger=logger
                        )

                        def create_file_provider_workspace_runtime(
                            entry: WorkspaceCatalogEntry,
                            label: str,
                        ) -> WorkspaceRuntime:
                            return _create_catalog_workspace_runtime(
                                entry,
                                label,
                                paths=paths,
                                config=config,
                                client=client,
                                installation_id=installation_id,
                                logger=logger,
                                fuse_t_transport_backend=None,
                            )

                        candidate_manager = _create_workspace_runtime_manager(
                            primary_storage_error=primary_storage_error,
                            paths=paths,
                            config=config,
                            client=client,
                            installation_id=installation_id,
                            mount_backend=candidate_backend,
                            runtime_factory=create_file_provider_workspace_runtime,
                            primary_runtime=WorkspaceRuntime(
                                has_runnable_work=lambda: _fabric_runtime_has_runnable_work(database, fabric),
                                backend=primary_backend,
                                coordinator=fabric,
                                safe_to_close=primary_backend.can_close,
                                # A rejected File Provider candidate must leave
                                # the primary coordinator/database reusable by
                                # the fallback mount. Final direct teardown owns
                                # those resources after a successful cutover.
                                close_runtime=primary_backend.close,
                                attachment_id=attachment_id,
                            ),
                            logger=logger,
                        )
                        candidate_manager.prepare_mount()
                        projection = (
                            candidate_manager.file_provider_catalog_projection()
                        )
                        eligibility = _file_provider_runtime_eligibility(
                            paths,
                            config,
                            account_wide=candidate_manager.file_provider_account_wide,
                            account_wide_workspace_count=len(projection.workspaces),
                        )
                        if not eligibility["eligible"]:
                            raise StateError(
                                "The complete account File Provider catalog is unavailable."
                            )
                        candidate_bridge = AccountFileProviderBridge(
                            candidate_manager, address, logger=logger
                        )
                        candidate_bridge.start()
                        if not candidate_bridge.running:
                            raise RuntimeError(
                                "the account File Provider bridge did not start"
                            )
                    except Exception as error:  # noqa: BLE001 - fallback boundary
                        for component, candidate in (
                            ("account_file_provider", candidate_bridge),
                            ("workspace_runtime_manager", candidate_manager),
                            ("account_mount_backend", candidate_backend),
                        ):
                            if candidate is None:
                                continue
                            try:
                                candidate.close()
                            except BaseException as close_error:
                                logger.record(
                                    "connection_resource_close_failed",
                                    component=component,
                                    error_type=type(close_error).__name__,
                                    error=str(close_error),
                                )
                        logger.record(
                            "file_provider_account_bridge_unavailable",
                            state=file_provider_status.state,
                            error=str(error),
                        )
                    else:
                        file_provider = candidate_bridge
                        workspace_runtime_manager = candidate_manager
                        mount_backend = candidate_backend
                else:
                    eligibility = _file_provider_runtime_eligibility(paths, config)
                    if eligibility["eligible"]:
                        try:
                            file_provider = FabricFileProviderBridge(
                                database,
                                fabric,
                                workspace,
                                _file_provider_workspace_name(config),
                                address,
                                logger=logger,
                            )
                            file_provider.start()
                            if not file_provider.running:
                                raise RuntimeError(
                                    "the File Provider bridge did not start"
                                )
                        except Exception as error:  # noqa: BLE001 - fallback boundary
                            if file_provider is not None:
                                try:
                                    file_provider.close()
                                except BaseException as close_error:
                                    logger.record(
                                        "connection_resource_close_failed",
                                        component="file_provider_startup",
                                        error_type=type(close_error).__name__,
                                        error=str(close_error),
                                    )
                            file_provider = None
                            logger.record(
                                "file_provider_bridge_unavailable",
                                state=file_provider_status.state,
                                error=str(error),
                            )
            if file_provider is not None:
                logger.record(
                    "native_files_presentation_selected",
                    backend="file-provider",
                    account_wide=bool(workspace_runtime_manager is not None),
                    domain_identifier="io.meshia.files",
                    user_visible_url=file_provider_status.user_visible_url,
                )
            elif address is None:
                logger.record(
                    "native_files_presentation_fallback",
                    backend="mount",
                    file_provider_state=file_provider_status.state,
                )
        mount_runtime = (
            detect_fuse_runtime()
            if file_provider is None
            and config.native_mount_enabled
            and sys.platform in ("darwin", "linux", "win32")
            else None
        )
        if (
            file_provider is None
            and config.account_id is None
            and sync_engine_process_enabled()
            and config.native_mount_enabled
            and sys.platform in ("darwin", "linux", "win32")
            and mount_runtime is not None
        ):
            # Split mode: this process stays the engine and the FUSE loop moves
            # to a supervised child, so filesystem callbacks never share an
            # interpreter with polling. Measured on the real backend, that is
            # worth 273x on getattr and 43x on a write cycle.
            engine_server = SyncEngineServer(fabric, paths.home)
            # The engine asks the mount whether a path can be reclaimed. In
            # split mode that question crosses the boundary, and an unreachable
            # mount answers "unknown", which set_mount_cleanup_fence already
            # defines as do-not-reclaim.
            fabric.set_mount_cleanup_fence(engine_server.cleanup_fence)
            command_mount_point = _native_mount_point(paths, workspace_root)
            mount_supervisor = MountWorkerSupervisor(
                MountWorkerSpec(
                    home=str(paths.home),
                    session_id=config.session_id,
                    database_path=str(workspace_state.database),
                    cache_path=str(workspace_state.cache),
                    workspace_root=str(workspace_root),
                    workspace_name=_file_provider_workspace_name(config),
                    mount_point=str(command_mount_point),
                    mount_state_path=str(paths.fabric_mount_state_path),
                    fuse_t_transport_backend=select_macos_fuse_backend(mount_runtime),
                ),
                logger=logger,
            )
            mount_supervisor.start()
            logger.record("sync_engine_process_split_started")
        elif (
            file_provider is None
            and config.native_mount_enabled
            and sys.platform in ("darwin", "linux", "win32")
            and config.account_id is not None
            and select_mount_backend(config.mount_backend).backend != "fskit"
            and multi_workspace_split_enabled()
            and mount_runtime is not None
        ):
            # Split mode for the account-wide mount: this process stays the
            # engine (catalog, attachments, coordinators, uploads, hydration)
            # and the whole FUSE namespace -- MultiWorkspaceMountBackend with
            # one FabricMountBackend per activated workspace -- moves to a
            # supervised worker, so no filesystem callback ever shares an
            # interpreter with the sync engine. Measured on the owner's mount
            # (2026-09-02): create+write+close 159 ms -> single digits.
            fuse_t_transport_backend = select_macos_fuse_backend(mount_runtime)
            mount_point = _native_mount_point(paths, workspace_root)
            command_mount_point = mount_point
            selection = select_mount_backend(config.mount_backend)
            logger.record(
                "fabric_mount_backend_selected",
                requested=selection.requested,
                backend=selection.backend,
                reason=selection.reason,
                process="split",
            )
            multi_engine_server = MultiWorkspaceEngineServer(paths.home, logger=logger)
            engine_server = multi_engine_server
            primary_session_id = config.session_id
            fabric.set_mount_cleanup_fence(
                multi_engine_server.cleanup_fence_for(primary_session_id)
            )
            primary_handle = EngineWorkspaceHandle(
                workspace_name=_file_provider_workspace_name(config),
                database_path=workspace_state.database,
                cache_path=workspace_state.cache,
                workspace_root=workspace_root,
                can_close=lambda: multi_engine_server.workspace_can_close(
                    primary_session_id
                ),
            )
            mount_backend = EngineMountTopology(multi_engine_server)

            def create_split_workspace_runtime(
                entry: WorkspaceCatalogEntry,
                label: str,
            ) -> WorkspaceRuntime:
                return _create_catalog_workspace_runtime(
                    entry,
                    label,
                    paths=paths,
                    config=config,
                    client=client,
                    installation_id=installation_id,
                    logger=logger,
                    fuse_t_transport_backend=fuse_t_transport_backend,
                    split_server=multi_engine_server,
                )

            workspace_runtime_manager = _create_workspace_runtime_manager(
                primary_storage_error=primary_storage_error,
                paths=paths,
                config=config,
                client=client,
                installation_id=installation_id,
                mount_backend=mount_backend,
                runtime_factory=create_split_workspace_runtime,
                primary_runtime=WorkspaceRuntime(
                    has_runnable_work=lambda: _fabric_runtime_has_runnable_work(database, fabric),
                    backend=primary_handle,
                    coordinator=fabric,
                    safe_to_close=primary_handle.can_close,
                    close_runtime=lambda: _close_workspace_runtime(
                        primary_handle,
                        fabric,
                        database,
                        None,
                    ),
                    attachment_id=attachment_id,
                ),
                logger=logger,
            )
            multi_engine_server.bind_manager(workspace_runtime_manager)
            try:
                workspace_runtime_manager.prepare_mount()
            except BaseException:
                workspace_runtime_manager.close()
                mount_backend.close()
                multi_engine_server.close()
                raise
            mount_supervisor = MountWorkerSupervisor(
                MountWorkerSpec(
                    mode="multi",
                    home=str(paths.home),
                    storage_root=str(paths.home),
                    mount_point=str(mount_point),
                    mount_state_path=str(paths.fabric_mount_state_path),
                    fuse_t_transport_backend=fuse_t_transport_backend,
                ),
                logger=logger,
            )
            mount_supervisor.start()
            logger.record("sync_engine_process_split_started", topology="multi")
        elif (
            file_provider is None
            and config.native_mount_enabled
            and sys.platform in ("darwin", "linux", "win32")
        ):
            fuse_t_transport_backend = (
                select_macos_fuse_backend(mount_runtime)
                if mount_runtime is not None
                else None
            )
            primary_mount_backend = FabricMountBackend(
                database,
                fabric,
                workspace,
                _file_provider_workspace_name(config),
                rename_workspace=(
                    _workspace_rename_callback(client, store)
                    if config.account_id is None
                    else None
                ),
                logger=logger,
                fuse_t_transport_backend=fuse_t_transport_backend,
            )
            if config.account_id is None:
                # M725 attach responses always carry the immutable account UUID.
                # Keep a narrow legacy fallback for an older private control plane,
                # but never invent an account catalog or expose unauthenticated roots.
                mount_backend = primary_mount_backend
            else:
                mount_backend = MultiWorkspaceMountBackend(paths.home, logger=logger)

                def create_workspace_runtime(
                    entry: WorkspaceCatalogEntry,
                    label: str,
                ) -> WorkspaceRuntime:
                    return _create_catalog_workspace_runtime(
                        entry,
                        label,
                        paths=paths,
                        config=config,
                        client=client,
                        installation_id=installation_id,
                        logger=logger,
                        fuse_t_transport_backend=fuse_t_transport_backend,
                    )

                workspace_runtime_manager = _create_workspace_runtime_manager(
                    primary_storage_error=primary_storage_error,
                    paths=paths,
                    config=config,
                    client=client,
                    installation_id=installation_id,
                    mount_backend=mount_backend,
                    runtime_factory=create_workspace_runtime,
                    primary_runtime=WorkspaceRuntime(
                        has_runnable_work=lambda: _fabric_runtime_has_runnable_work(database, fabric),
                        backend=primary_mount_backend,
                        coordinator=fabric,
                        # Command writes are durable before ACK; native writes
                        # also retain a private stage until journal admission.
                        safe_to_close=primary_mount_backend.can_close,
                        close_runtime=lambda: _close_workspace_runtime(
                            primary_mount_backend,
                            fabric,
                            database,
                            None,
                        ),
                        attachment_id=attachment_id,
                    ),
                    logger=logger,
                )
                try:
                    workspace_runtime_manager.prepare_mount()
                except BaseException:
                    workspace_runtime_manager.close()
                    mount_backend.close()
                    raise
            mount_point = _native_mount_point(paths, workspace_root)
            candidate_mount: FabricFuseMount | FSKitMount
            selection = select_mount_backend(config.mount_backend)
            logger.record(
                "fabric_mount_backend_selected",
                requested=selection.requested,
                backend=selection.backend,
                reason=selection.reason,
            )
            if selection.backend == "fskit":
                if workspace_runtime_manager is not None:
                    volume_catalog = workspace_runtime_manager.volume_specs
                else:
                    legacy_backend = primary_mount_backend

                    def volume_catalog() -> tuple[VolumeSpec, ...]:
                        return (VolumeSpec(config.session_id, legacy_backend.workspace_name),)

                candidate_mount = FSKitMount(
                    mount_backend,
                    volumes=volume_catalog,
                    address=default_fskit_address(fskit_app_group(selection.app_path)),
                    mount_root=mount_point,
                    state_path=paths.fskit_mount_state_path,
                    logger=logger,
                )
            else:
                candidate_mount = FabricFuseMount(
                    mount_backend,
                    mount_point,
                    state_path=paths.fabric_mount_state_path,
                    logger=logger,
                )
            try:
                try:
                    started = candidate_mount.start()
                except FabricMountError as error:
                    if not (
                        isinstance(candidate_mount, FSKitMount)
                        and selection.requested == "auto"
                    ):
                        raise
                    # ``auto`` promised a working mount, not FSKit specifically.
                    # The bridge/volumes are already torn down by the failed start.
                    logger.record(
                        "fabric_mount_backend_fallback",
                        backend="fuse-t",
                        error=str(error),
                    )
                    candidate_mount = FabricFuseMount(
                        mount_backend,
                        mount_point,
                        state_path=paths.fabric_mount_state_path,
                        logger=logger,
                    )
                    started = candidate_mount.start()
                if started:
                    fuse_mount = candidate_mount
                    command_mount_point = Path(mount_point)
                elif workspace_runtime_manager is None:
                    candidate_mount.close()
            except (OSError, ValueError, MeshiaNodeError, RuntimeError) as error:
                candidate_mount.close()
                logger.record("fabric_mount_unavailable", error=str(error))
                if workspace_runtime_manager is not None:
                    workspace_runtime_manager.close()
                    workspace_runtime_manager = None
                raise
        executor: CommandExecutor | None = None
        workspace_readiness: _WorkspaceExecutionReadiness | None = None
        app_loop = None
        try:
            if mount_backend is None and engine_server is None:
                # Headless commands and a legacy single-workspace File
                # Provider still need the shared namespace/stage owner. Never
                # create a second owner alongside a native or split backend.
                mount_backend = FabricMountBackend(
                    database,
                    fabric,
                    workspace,
                    _file_provider_workspace_name(config),
                    logger=logger,
                    fuse_t_transport_backend=None,
                )
                if config.account_id is not None:
                    # Headless commands use the same authenticated catalog,
                    # quota reservations, and authority lease as native IO.
                    # A bare backend intentionally has unknown remote capacity
                    # and cannot admit growth. Do not bypass that fence or
                    # invent capacity from the private staging filesystem.
                    primary_backend = mount_backend
                    mount_backend = MultiWorkspaceMountBackend(paths.home, logger=logger)
                    workspace_runtime_manager = _create_workspace_runtime_manager(
                        primary_storage_error=primary_storage_error,
                        paths=paths,
                        config=config,
                        client=client,
                        installation_id=installation_id,
                        mount_backend=mount_backend,
                        runtime_factory=lambda entry, label: _create_catalog_workspace_runtime(
                            entry,
                            label,
                            paths=paths,
                            config=config,
                            client=client,
                            installation_id=installation_id,
                            logger=logger,
                            fuse_t_transport_backend=None,
                        ),
                        primary_runtime=WorkspaceRuntime(
                            has_runnable_work=lambda: _fabric_runtime_has_runnable_work(database, fabric),
                            backend=primary_backend,
                            coordinator=fabric,
                            safe_to_close=primary_backend.can_close,
                            close_runtime=lambda: _close_workspace_runtime(
                                primary_backend, fabric, database, None
                            ),
                            attachment_id=attachment_id,
                        ),
                        logger=logger,
                    )
                    workspace_runtime_manager.prepare_mount()
            coordinator_owned = maintenance is None
            if primary_storage_error is not None and workspace_runtime_manager is None:
                # A control lease cannot make the legacy selected-workspace
                # synchronizer safe. Only the catalog manager owns account Files.
                raise primary_storage_error
            owned_maintenance = workspace_runtime_manager or fabric
            active_maintenance = (
                _MountGuardedMaintenance(
                    owned_maintenance,
                    fuse_mount,
                    mount_backend if workspace_runtime_manager is None else None,
                    store if workspace_runtime_manager is None else None,
                    command_mount_point=command_mount_point,
                )
                if coordinator_owned
                and fuse_mount is not None
                and mount_backend is not None
                else _MountGuardedMaintenance(
                    owned_maintenance, mount_supervisor,
                    command_mount_point=command_mount_point,
                )
                if coordinator_owned and mount_supervisor is not None
                else owned_maintenance
                if coordinator_owned
                else maintenance
            )

            try:
                ControlClient(paths).link_device_if_present()
            except Disconnected:
                raise
            except Exception as error:
                # Linking the separate CLI login is optional adoption work.
                # An unavailable response or local credential-store problem
                # must not tear down an authenticated workspace mount. Actual
                # device revocation still takes the terminal branch above.
                logger.record("account_connection_link_pending",
                    code=getattr(error, "code", "ACCOUNT_AUTH_UNAVAILABLE"),
                    error_type=type(error).__name__)

            executor = CommandExecutor(
                workspace,
                tier=config.tier,
                paths=paths,
                access=config.access,
                # Workspace variables are fetched per command, sealed, and dropped
                # when the command ends — the executor gets a callable, not the
                # signing client, so it still cannot reach the control plane itself.
                environment_provider=TaskEnvironmentFetcher(client, store, logger),
                command_filesystem=lambda: _command_filesystem_lease(
                    store,
                    config,
                    paths,
                    runtime_manager=workspace_runtime_manager,
                    backend=mount_backend,
                    engine_server=engine_server,
                    file_provider=file_provider,
                    owned_mount_point=command_mount_point,
                ),
            )
            command_executor_factory = lambda command: _workspace_command_executor(
                command, store=store, enrollment=config, workspace=workspace,
                paths=paths, client=client, logger=logger,
                runtime_manager=workspace_runtime_manager, backend=mount_backend,
                engine_server=engine_server, file_provider=file_provider,
                owned_mount_point=command_mount_point,
            )
            loop = CommandLoop(
                store,
                client,
                executor,
                logger=logger,
                on_write=_coordinator_publisher(fabric),
                executor_factory=command_executor_factory,
            )
            from .native_apps import AppCommandLane, AppLoop
            app_loop = AppLoop(store, client, command_executor_factory, logger=logger)
            loop = AppCommandLane(loop, app_loop)
            # The heartbeat is the live channel for a dashboard Limited/Full toggle:
            # it hands the reported mode straight to the enforcement point.
            workspace_readiness = _WorkspaceExecutionReadiness(
                paths, store, command_mount_point, file_provider=file_provider,
            )

            def retire_primary_storage(error: Disconnected) -> None:
                if workspace_runtime_manager is None:
                    raise error
                workspace_runtime_manager.retire_workspace_storage(config.session_id, error)

            runner = NodeRunner(
                store,
                client,
                loop,
                logger=logger,
                traffic=transport.traffic,
                on_access_mode=lambda access: _apply_compute_access(executor, app_loop, access),
                workspace_execution=workspace_readiness,
                on_workspace_storage_unavailable=retire_primary_storage,
                account_command_claim_ready=(
                    workspace_runtime_manager.can_claim_workspace_commands
                    if workspace_runtime_manager is not None else None
                ),
                metrics_attachment_id=(
                    workspace_runtime_manager.metrics_attachment_id
                    if workspace_runtime_manager is not None else None
                ),
                on_lease_renewed=(
                    workspace_runtime_manager.observe_primary_lease
                    if workspace_runtime_manager is not None else None
                ),
                maintenance=active_maintenance,
                on_command_readiness=lambda ready, reason, head_generation: (
                    _publish_command_readiness(
                        store,
                        paths,
                        pid=os.getpid(),
                        ready=ready,
                        reason=reason,
                        head_generation=head_generation,
                        runtime_status_required=runtime_status_required,
                    )
                ),
                on_runtime_health=(
                    lambda health: _publish_runtime_health(
                        paths,
                        pid=os.getpid(),
                        node_health=health,
                        fabric=fabric,
                        runtime_manager=workspace_runtime_manager,
                        workspace_execution=workspace_readiness.snapshot(),
                    )
                    if runtime_status_required
                    else None
                ),
                independent_heartbeat=coordinator_owned,
            )
            _install_signal_handlers(runner, logger, shutdown_event=shutdown_event)
            if shutdown_event is not None:
                _stop_runner_when_shutdown_requested(runner, shutdown_event)
            if shutdown_event is not None and shutdown_event.is_set():
                runner.stop()
            # Push invalidation rides alongside the runner: events wake the
            # named workspace, stream health stretches the polling cadence,
            # and any failure simply leaves today's polling in place.
            push_bridge = PushRuntimeBridge(
                runtime_manager=workspace_runtime_manager,
                coordinator=fabric,
                primary_session_id=config.session_id,
            )
            push_client = PushClient(
                client,
                host_id=config.host_id,
                on_event=push_bridge.on_event,
                on_connection=push_bridge.on_connection,
                status_path=paths.push_status_path,
                logger=logger,
            )
            try:
                push_client.start()
            except (OSError, MeshiaNodeError, RuntimeError) as error:
                logger.record("push_stream_unavailable", error=str(error)[:256])
            try:
                runner.run(max_iterations=max_iterations)
            finally:
                push_client.close()
        finally:
            for component, resource in (("app_loop", app_loop), ("workspace_readiness", workspace_readiness)):
                if resource is None:
                    continue
                try:
                    resource.close()
                except Exception as error:
                    # A broken app/readiness close must not skip native mount
                    # cleanup. Preserve failure after all resources are tried;
                    # an already-propagating runner exception retains priority.
                    if frontend_close_error is None:
                        frontend_close_error = error
                    logger.record("connection_resource_close_failed",
                        component=component, error_type=type(error).__name__)
            # Stop the split-mode mount worker before the engine's own
            # teardown: the worker unmounts on exit, and leaving it running
            # would keep a namespace alive whose engine is going away.
            if mount_supervisor is not None:
                try:
                    if mount_supervisor.stop() is False:
                        mount_shutdown_failed = True
                except Exception as error:  # noqa: BLE001 - never mask shutdown
                    mount_shutdown_failed = True
                    logger.record("mount_worker_stop_failed", error=str(error)[:200])
            if engine_server is not None:
                try:
                    engine_server.close()
                except Exception as error:  # noqa: BLE001
                    logger.record("sync_engine_server_close_failed", error=str(error)[:200])
            # The guard begins immediately after mount setup. Constructor and
            # signal-install failures therefore take the same exhaustive path
            # as a normal runner exit, and no broken close skips the next one.
            mount_stopped = _teardown_connection_resources(
                logger=logger,
                executor=executor,
                file_provider=file_provider,
                runtime_manager=workspace_runtime_manager,
                fuse_mount=fuse_mount,
                mount_backend=mount_backend,
                fabric=fabric,
                database=database,
            )
            if not mount_stopped and fuse_mount is not None:
                # The OS still has the native mount attached. Exiting now would
                # strand the kernel client on a dead server. Keep serving it,
                # retry the detach until the registry proves it gone, then
                # finish the teardown that the deferred close skipped.
                mount_release_held = True
                _hold_native_mount_until_released(fuse_mount, logger)
                mount_stopped = _teardown_connection_resources(
                    logger=logger,
                    executor=None,
                    file_provider=None,
                    runtime_manager=workspace_runtime_manager,
                    fuse_mount=fuse_mount,
                    mount_backend=mount_backend,
                    fabric=fabric,
                    database=database,
                )
            if not mount_stopped:
                mount_shutdown_failed = True
            if disconnect_on_exit:
                try:
                    disconnect(client, store)
                except MeshiaNodeError as error:
                    logger.record("disconnect_deferred", error_code=error.code)
    if frontend_close_error is not None:
        raise frontend_close_error
    if mount_shutdown_failed:
        raise StateError(
            "The native Meshia mount did not stop cleanly. Restart the host "
            "before reconnecting if the mount cannot be detached."
        )
    if mount_release_held:
        return MOUNT_RELEASE_HOLD_EXIT_CODE
    return 0


class _MountGuardedMaintenance:
    """Add native-mount liveness to the existing Fabric maintenance loop.

    FUSE-T's local SMB helper can remain alive after Finder disconnects the
    share.  The coordinator would otherwise keep syncing happily while the
    user sees an empty ordinary directory.  One bounded registry check per
    maintenance tick turns that split-brain state into a service restart; all
    reconciliation continues to come from the wrapped coordinator. Commands
    using the authoritative mount can run during ordinary remote hydration;
    private-cache execution still requires full coordinator readiness.
    """

    def __init__(
        self,
        coordinator: Any,
        mount: "FabricFuseMount | FSKitMount | MountWorkerSupervisor",
        backend: FabricMountBackend | MultiWorkspaceMountBackend | None = None,
        store: ConfigStore | None = None,
        *,
        command_mount_point: Path | None = None,
    ) -> None:
        self._coordinator = coordinator
        self._mount = mount
        self._backend = backend
        self._store = store
        self._config_mtime_ns: int | None = None
        self._command_mount_point = command_mount_point

    @property
    def command_readiness(self) -> tuple[bool, str | None, int | None]:
        candidate = self._coordinator.command_readiness
        readiness = candidate() if callable(candidate) else candidate
        if not (
            isinstance(readiness, tuple) and len(readiness) == 3
            and readiness[0] is False and readiness[1] == "apply_pending"
            and type(readiness[2]) is int and readiness[2] >= 0
            and self._command_mount_point is not None
        ):
            return readiness
        # apply_pending means an authenticated manifest is already published.
        # The owned mount hydrates that namespace on demand, so draining every
        # private-cache apply first would stall native commands on large/new
        # workspaces. Keep all startup, adoption, repair and authority fences.
        running = getattr(self._mount, "running", False)
        worker_pid = getattr(self._mount, "worker_pid", None)
        if running is not True and not (type(worker_pid) is int and worker_pid > 0):
            return readiness
        for name in ("require_registered", "require_mounted"):
            check = getattr(self._mount, name, None)
            if callable(check):
                check()
        if mount_registration_state(self._command_mount_point) is not True:
            return readiness
        # This is command admission, not a claim of synchronization. The
        # coordinator's health/readiness remain unchanged for convergence.
        return True, None, readiness[2]

    def _refresh_workspace_name(self) -> None:
        if self._backend is None or self._store is None:
            return
        try:
            mtime_ns = self._store.paths.config_path.stat().st_mtime_ns
        except OSError:
            return
        if mtime_ns == self._config_mtime_ns:
            return
        config = self._store.require()
        self._backend.set_workspace_name(_file_provider_workspace_name(config))
        self._config_mtime_ns = mtime_ns

    def poll_once(self) -> bool:
        require_registered = getattr(self._mount, "require_registered", None)
        if callable(require_registered):
            require_registered()
        # Split mode: the worker reports an operator-released mount through
        # its supervisor instead of the registry probe (which would stall on a
        # mount this process does not serve).
        require_mounted = getattr(self._mount, "require_mounted", None)
        if callable(require_mounted):
            require_mounted()
        self._refresh_workspace_name()
        return bool(self._coordinator.poll_once())

    def __getattr__(self, name: str) -> Any:
        return getattr(self._coordinator, name)


def _command_execution_root(
    paths: Paths,
    config: NodeConfig,
    workspace_name: str,
    *,
    file_provider: Any | None,
    owned_mount_point: Path | None = None,
    account_namespace: bool = False,
) -> Path | None:
    """Resolve only an owned public presentation, never the private cache.

    A missing public route still permits typed shared filesystem operations;
    process cwd/confinement requires this independently verified root.
    Only the device readiness probe requests the account namespace: the initial
    workspace can be deleted while other account workspaces remain usable.
    """

    if len(split_relative(workspace_name)) != 1:
        raise StateError("The command workspace label is invalid.")
    if account_namespace and config.account_id is None:
        raise StateError("The account mount has no enrolled account identity.")
    if not config.native_mount_enabled:
        return None
    if file_provider is not None:
        status = native_file_provider_status()
        if (
            not file_provider.running
            or not status.ready
            or status.bridge_address is None
            or status.bridge_address != file_provider.address
            or not status.user_visible_url
        ):
            return None
        parsed = urllib.parse.urlsplit(status.user_visible_url)
        if (
            parsed.scheme != "file"
            or parsed.netloc not in ("", "localhost")
            or parsed.query
            or parsed.fragment
        ):
            raise StateError("The native command workspace URL is invalid.")
        decoded = urllib.parse.unquote(parsed.path)
        if (
            "\0" in decoded
            or not Path(decoded).is_absolute()
            or ".." in Path(decoded).parts
        ):
            raise StateError("The native command workspace path is invalid.")
        root = Path(decoded) if account_namespace else Path(decoded) / workspace_name
    else:
        if owned_mount_point is None:
            return None
        status = _fabric_mount_status_document(paths, enabled=True)
        if status.get("backend") == "fskit":
            matching = [
                volume
                for volume in status.get("volumes", ())
                if (account_namespace or (volume.get("volume_id") == config.session_id
                    and volume.get("name") == workspace_name))
                and volume.get("mounted") is True
            ]
            if not matching or (not account_namespace and len(matching) != 1):
                return None
            root = Path(str(matching[0]["mount_point"]))
            label = matching[0].get("name") if account_namespace else workspace_name
            if not isinstance(label, str) or len(split_relative(label)) != 1:
                raise StateError("The native volume label is invalid.")
            expected = owned_mount_point / label
            if os.path.normpath(str(root)) != os.path.normpath(str(expected)):
                raise StateError("The native volume does not match the command workspace.")
        else:
            if status.get("mounted") is not True:
                return None
            mounted = Path(str(status.get("mount_point") or ""))
            expected = owned_mount_point
            if os.path.normpath(str(mounted)) != os.path.normpath(str(expected)):
                raise StateError("The owned mount does not match the command workspace.")
            root = mounted if account_namespace else mounted / workspace_name
    # This comparison is lexical: never touch a dead OS mount while deciding
    # whether it is an eligible execution route.
    if not root.is_absolute():
        raise StateError("A command cannot use the private working set as its public root.")
    for private in (config.workspace, str(paths.home)):
        if private == str(paths.home) and file_provider is None and (
            not account_namespace or owned_mount_point == paths.fabric_mount_dir
        ):
            # Portable installations deliberately keep the verified mount
            # under home/mounts. Only this exact owned presentation is exempt;
            # a File Provider URL cannot turn private node data into a route.
            continue
        try:
            inside = os.path.commonpath((str(root), private)) == os.path.normpath(private)
        except ValueError:  # Different Windows volumes cannot contain each other.
            inside = False
        if inside:
            raise StateError("A command cannot use private node storage as its public root.")
    return root


class _LazyCommandExecutionBoundary:
    """Open a public root only when a command actually needs a process path."""

    def __init__(self, acquire: Callable[[], Path]) -> None:
        self._acquire = acquire
        self._boundary: WorkspaceBoundary | None = None
        self._closed = False

    def close(self) -> None:
        self._closed = True
        if self._boundary is not None:
            self._boundary.close()

    @property
    def root(self) -> Path:
        if self._closed:
            raise StateError("The command filesystem lease has ended.")
        # Native commands open this route inside their timed process, never on
        # the service worker where a blocked kernel mount call cannot cancel.
        return self._acquire()

    def absolute(self, path: str, allow_root: bool = False) -> Path:
        if self._closed:
            raise StateError("The command filesystem lease has ended.")
        if self._boundary is None:
            self._boundary = WorkspaceBoundary(self.root, recover_stream_temps=False)
        return self._boundary.absolute(path, allow_root=allow_root)


class _WorkspaceExecutionReadiness:
    """Cache bounded mount reads performed by this node, not its CLI observer.

    OS policy support is necessary but cannot prove that this background
    executable has permission to open its native mount. All filesystem opens
    happen inside the existing cancellable process owner, never a heartbeat
    thread or the status command's possibly more privileged parent context.
    """

    def __init__(self, paths: Paths, store: ConfigStore, mount_point: Path | None,
                 *, file_provider: Any | None = None) -> None:
        self.paths, self.store, self.mount_point = paths, store, mount_point
        self.file_provider = file_provider
        self._key: tuple | None = None
        self._expires = 0.0
        self._snapshot: dict[str, Any] | None = None
        self._cancel = threading.Event()
        self._lock = threading.Lock()

    def close(self) -> None:
        self._cancel.set()

    def snapshot(self) -> dict[str, Any] | None:
        # Replacing a complete snapshot is atomic; observers never wait on a
        # mount open or attempt their own permission probe.
        value = self._snapshot
        return dict(value) if value is not None else None

    def __call__(self) -> bool:
        from .native_execution import available
        from .native_command import workspace_read_argv, workspace_read_phase
        from .executor import native_environment, run_bounded_subprocess

        with self._lock:
            config = self.store.require()
            supported = available()
            root = None
            mount_identity = None
            reason = "policy_unavailable" if not supported else "mount_unavailable"
            if config.pid != os.getpid():
                reason = "daemon_not_owned"
            elif config.lifecycle != "connected" or self._cancel.is_set():
                reason = "not_connected"
            elif supported:
                try:
                    root = _command_execution_root(
                        self.paths, config, _file_provider_workspace_name(config),
                        file_provider=self.file_provider, owned_mount_point=self.mount_point,
                        account_namespace=config.account_id is not None,
                    )
                    mount = _fabric_mount_status_document(self.paths)
                    mount_identity = _workspace_mount_identity(self.paths, mount)
                except (OSError, MeshiaNodeError):
                    root = None
            identity_fields = ("host_id", "generation", "session_id", "attachment_id", "lifecycle", "pid",
                               "account_id", "native_mount_enabled", "workspace", "mount_backend")
            identity = tuple(getattr(config, field) for field in identity_fields)
            key = (*identity, supported, str(root) if root is not None else None,
                   mount_identity, reason)
            if key == self._key and time.monotonic() < self._expires:
                return bool(self._snapshot and self._snapshot["ready"])
            ready = False
            probe_phase = None
            if root is not None and not self._cancel.is_set():
                probe_phase = "before_child_entry"
                try:
                    output, code, _truncated, timed_out = run_bounded_subprocess(
                        workspace_read_argv(str(root)), cwd=os.path.abspath(os.sep),
                        env=native_environment(), timeout_seconds=2,
                        max_output_bytes=512, cancel_event=self._cancel,
                    )
                    ready = code == 0 and not timed_out
                    probe_phase = None if ready else workspace_read_phase(output)
                    reason = ("ready" if ready else "workspace_access_timeout" if timed_out
                              else "workspace_access_denied" if b"MESHIA_READ_ERROR:denied" in output.splitlines()
                              else "workspace_access_unavailable")
                except (OSError, MeshiaNodeError):
                    reason = "workspace_access_unavailable"
                current = self.store.require()
                if tuple(getattr(current, field) for field in identity_fields) != identity:
                    ready, reason = False, "identity_changed"
                    probe_phase = None
            ttl = 30 if ready else 10
            self._snapshot = {
                "ready": ready, "policy_supported": supported, "reason": reason,
                # Heartbeats run every 30s; retain one missed-interval margin
                # in the read-only receipt without skipping scheduled probes.
                "checked_at": iso8601(), "valid_for_seconds": 60,
                "host_id": config.host_id, "generation": config.generation,
                "session_id": config.session_id, "attachment_id": config.attachment_id,
                "mount_identity": mount_identity,
            }
            if probe_phase is not None:
                self._snapshot["probe_phase"] = probe_phase
            self._key, self._expires = key, time.monotonic() + ttl
            return ready


def _workspace_mount_identity(paths: Paths, mount: dict[str, Any]) -> str:
    # Only receipt/OS registry fields; no stat of the mounted namespace. Owner
    # replacement, unmount and FSKit per-volume changes invalidate a cached read.
    projection = {key: mount.get(key) for key in
                  ("mounted", "mount_point", "owner_pid", "backend", "volumes")}
    receipt = read_mount_state(paths.fabric_mount_state_path)
    projection["receipt_owner"] = receipt.get("owner_pid") if receipt is not None else None
    if mount.get("backend") == "fskit":
        fskit_receipt = read_fskit_mount_state(paths.fskit_mount_state_path)
        projection["receipt_owner"] = fskit_receipt.get("owner_pid") if fskit_receipt is not None else None
    return hashlib.sha256(json.dumps(projection, sort_keys=True).encode()).hexdigest()


def _workspace_execution_evidence(value: object) -> dict[str, Any] | None:
    """Validate the optional addition to the existing runtime health receipt."""
    from .native_command import WORKSPACE_READ_PHASES

    if not isinstance(value, dict):
        return None
    fields = {"ready", "policy_supported", "reason", "checked_at", "valid_for_seconds",
              "host_id", "generation", "session_id", "attachment_id", "mount_identity"}
    if (set(value) not in (fields, fields | {"probe_phase"}) or type(value.get("ready")) is not bool
        or ("probe_phase" in value and (not isinstance(value["probe_phase"], str)
            or value["probe_phase"] not in WORKSPACE_READ_PHASES or value.get("ready") is not False))
        or type(value.get("policy_supported")) is not bool
        or value.get("reason") not in {"ready", "policy_unavailable", "mount_unavailable", "not_connected",
            "daemon_not_owned", "identity_changed",
            "workspace_access_timeout", "workspace_access_denied", "workspace_access_unavailable"}
        or _parse_utc_timestamp(value.get("checked_at")) is None
        or type(value.get("valid_for_seconds")) is not int or not 1 <= value["valid_for_seconds"] <= 60
        or type(value.get("generation")) is not int or value["generation"] <= 0
        or any(not isinstance(value.get(key), str) or not 0 < len(value[key]) <= 128
               for key in ("host_id", "session_id"))
        or (value.get("attachment_id") is not None and
            (not isinstance(value["attachment_id"], str) or not 0 < len(value["attachment_id"]) <= 128))
        or (value.get("mount_identity") is not None and
            (not isinstance(value["mount_identity"], str) or len(value["mount_identity"]) != 64))
        or (value["ready"] and (not value["policy_supported"] or value["reason"] != "ready"))):
        return None
    return dict(value)


def _apply_compute_access(executor: CommandExecutor, app_loop: Any, access: str) -> None:
    if access != executor.access:
        app_loop.set_access(access)
    executor.set_access(access)


def _workspace_command_executor(
    command: dict[str, Any], *, store: ConfigStore, enrollment: NodeConfig,
    workspace: WorkspaceBoundary, paths: Paths, client: SignedClient, logger: NodeLogger,
    runtime_manager: WorkspaceRuntimeManager | None, backend: Any,
    engine_server: SyncEngineServer | None, file_provider: Any | None,
    owned_mount_point: Path | None,
) -> CommandExecutor:
    """Create one executor from a server-claimed workspace, never a UI hint."""
    current = store.require()
    for field in ("host_id", "generation", "account_id"):
        if getattr(current, field) != getattr(enrollment, field):
            raise StateError("The command's enrolled device changed.")
    if command.get("host_id") != current.host_id or command.get("host_generation") != current.generation:
        raise StateError("The command belongs to another device generation.")
    session_id = command.get("session_id")
    attachment_id = command.get("attachment_id")
    if any(not isinstance(value, str) or POSTGRES_UUID_RE.fullmatch(value) is None
           for value in (session_id, attachment_id)):
        raise StateError("The command has no exact workspace attachment.")
    access = command.get("access_mode")
    if access not in ("files", "limited", "full"):
        raise StateError("The command has no workspace permission receipt.")
    native_access = ((access == "full" and command.get("execution_scope") == "host")
                     or (access == "limited" and command.get("execution_scope") == "workspace"))
    if command.get("command_type") in ("exec", "mcp_call", "app_control", "app_http") and access != "files" and not native_access:
        raise StateError("The command has no native execution permission receipt.")
    if session_id != current.session_id and runtime_manager is None:
        raise StateError("This device has no account workspace runtime.")
    def filesystem(**options):
        return _command_filesystem_lease(
            store, enrollment, paths, runtime_manager=runtime_manager, backend=backend,
            engine_server=engine_server, file_provider=file_provider,
            owned_mount_point=owned_mount_point, session_id=session_id, attachment_id=attachment_id,
            windows_workspace_execution=(native_access and access == "limited"), **options,
        )

    def native_execution_readiness() -> bool:
        with filesystem(execution_readiness_only=True) as ready:
            return ready

    return CommandExecutor(
        workspace, tier="compute", paths=paths, access=access,
        environment_provider=TaskEnvironmentFetcher(
            client, store, logger,
            command_authority=(current.host_id, current.generation, attachment_id),
        ),
        command_filesystem=filesystem,
        native_access=native_access,
        native_execution_readiness=native_execution_readiness,
    )


@contextmanager
def _command_filesystem_lease(
    store: ConfigStore,
    enrollment: NodeConfig,
    paths: Paths,
    *,
    runtime_manager: WorkspaceRuntimeManager | None,
    backend: Any,
    engine_server: SyncEngineServer | None,
    file_provider: Any | None,
    owned_mount_point: Path | None = None,
    session_id: str | None = None,
    attachment_id: str | None = None,
    windows_workspace_execution: bool = False,
    execution_readiness_only: bool = False,
) -> Iterator[Any]:
    from .command_filesystem import BackendCommandFilesystem, RPCCommandFilesystem

    current = store.require()
    identity_fields = ("host_id", "session_id", "generation", "workspace_id", "account_id")
    if any(getattr(current, name) != getattr(enrollment, name) for name in identity_fields):
        raise StateError("The command workspace authority changed; reconnect before retrying.")
    target_session = session_id or current.session_id
    if target_session != current.session_id and runtime_manager is None:
        raise StateError("Another command workspace requires the authenticated account catalog.")
    with ExitStack() as stack:
        if runtime_manager is not None:
            runtime = stack.enter_context(
                runtime_manager.lease_runtime(
                    target_session, require_mutation_ready=True,
                    **({"wait_for_mutation_ready": False} if execution_readiness_only else {}),
                )
            )
            assert runtime is not None
            if attachment_id is not None and runtime.attachment_id != attachment_id:
                raise StateError("The command attachment changed before execution.")
            projection = runtime_manager.file_provider_catalog_projection()
            selected = [
                item for item in projection.workspaces
                if item.session_id == target_session
            ]
            if projection.account_id != current.account_id or len(selected) != 1:
                raise StateError("The command workspace is absent from the authenticated catalog.")
            workspace_name = selected[0].name
            owner = runtime.backend
        else:
            if attachment_id is not None and current.attachment_id != attachment_id:
                raise StateError("The command attachment changed before execution.")
            workspace_name = _file_provider_workspace_name(current)
            owner = backend
            # Legacy single-workspace owners have no catalog projection loop.
            # Refresh only their display label from the same verified session
            # configuration before passing a public path to the shared owner.
            set_name = getattr(owner, "set_workspace_name", None)
            if callable(set_name):
                set_name(workspace_name)
        def execution_state() -> tuple[NodeConfig, str, bool]:
            latest = store.require()
            if any(
                getattr(latest, name) != getattr(enrollment, name)
                for name in identity_fields
            ):
                raise StateError("The command workspace authority changed before execution.")
            label = _file_provider_workspace_name(latest)
            if runtime_manager is not None:
                latest_projection = runtime_manager.file_provider_catalog_projection()
                matches = [
                    item for item in latest_projection.workspaces
                    if item.session_id == target_session
                ]
                if latest_projection.account_id != latest.account_id or len(matches) != 1:
                    raise StateError("The command workspace is no longer visible.")
                label = matches[0].name
            ready = True
            if runtime_manager is not None:
                # Account queue admission does not prove this target is ready.
                # Only publication of already-journaled local work may wait.
                readiness = runtime.coordinator.command_readiness
                if not (isinstance(readiness, tuple) and len(readiness) == 3
                        and type(readiness[0]) is bool
                        and type(readiness[2]) is int and readiness[2] >= 0):
                    raise StateError("The command workspace returned invalid execution readiness.")
                ready = readiness[0] or readiness[1] == "apply_pending"
                if not ready and readiness[1] not in (
                    "directory_publish_pending", "local_transfer_pending", "receipt_readback_pending",
                ):
                    raise StateError("The command workspace is not ready for native execution.")
            return latest, label, ready

        if execution_readiness_only:
            if not current.native_mount_enabled or (owner is None and engine_server is None):
                raise StateError("The shared command filesystem is unavailable.")
            yield execution_state()[2]
            return

        def acquire_execution() -> Path:
            latest, label, ready = execution_state()
            if not ready:
                raise StateError("The command workspace is not ready for native execution.")
            root = _command_execution_root(
                paths, replace(latest, session_id=target_session), label, file_provider=file_provider,
                owned_mount_point=owned_mount_point,
            )
            if root is None:
                raise StateError("The shared workspace is not mounted for command execution.")
            if not execution_state()[2]:
                raise StateError("The command workspace is not ready for native execution.")
            if sys.platform == "win32" and windows_workspace_execution:
                from .windows_workspace_view import lease
                if owner is None:
                    raise StateError("The Windows workspace view has no live filesystem owner.")
                return stack.enter_context(lease(owner, workspace_name=label,
                    session_id=target_session, state_home=paths.home))
            return root

        execution = (
            _LazyCommandExecutionBoundary(acquire_execution)
            if current.native_mount_enabled
            else None
        )
        if execution is not None:
            stack.callback(execution.close)
        if engine_server is not None:
            yield RPCCommandFilesystem(
                engine_server, target_session, execution_workspace=execution,
            )
        elif owner is not None:
            yield BackendCommandFilesystem(
                owner, workspace_name, execution_workspace=execution,
            )
        else:
            raise StateError("The shared command filesystem is unavailable.")


def _file_provider_workspace_name(config: NodeConfig) -> str:
    """Map a server display name to one safe native-filesystem component."""

    return _file_provider_workspace_component(config.workspace_name)


def _file_provider_workspace_component(workspace_name: str | None) -> str:
    """Map one server display label to the portable mounted root component."""

    value = unicodedata.normalize(
        "NFC", (workspace_name or "Workspace").strip()
    )
    sanitized = "".join(
        "-" if ord(character) < 32 or character in '<>:"/\\|?*' else character
        for character in value
    )
    sanitized = " ".join(sanitized.split()).rstrip(" .")
    if sanitized in ("", ".", ".."):
        sanitized = "Workspace"
    encoded = sanitized.encode("utf-8")
    while len(encoded) > 240 and sanitized:
        sanitized = sanitized[:-1]
        encoded = sanitized.encode("utf-8")
    sanitized = sanitized.rstrip(" .") or "Workspace"
    try:
        if len(split_relative(sanitized)) == 1:
            return sanitized
    except (InvalidTask, UnsafePath):
        pass
    # Reserved Windows device names and Meshia's own metadata/stage names are
    # unsuitable even on macOS because virtual paths share the portable Fabric
    # contract. Keep the fallback readable and deterministic.
    suffix = hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]
    return f"Workspace {suffix}"


def _workspace_rename_callback(
    client: SignedClient,
    store: ConfigStore,
) -> Callable[[str, str], str]:
    """Translate native root renames into one optimistic control-plane rename."""

    def rename(source: str, destination: str) -> str:
        config = store.require()
        if _file_provider_workspace_name(config) != source:
            raise OSError(errno.ESTALE, "Workspace name changed; refresh the mount and retry.")
        expected = config.workspace_name or source
        try:
            accepted = rename_workspace(client, store, expected, destination)
        except Disconnected as error:
            raise OSError(errno.EACCES, str(error)) from error
        except NetworkError as error:
            raise OSError(errno.EHOSTUNREACH, str(error)) from error
        except RemoteError as error:
            code = errno.EAGAIN if error.status == 409 else errno.EIO
            raise OSError(code, str(error)) from error
        except StateError as error:
            raise OSError(errno.EAGAIN, str(error)) from error
        return _file_provider_workspace_component(accepted)

    return rename


def _native_mount_point(paths: Paths, workspace_root: Path) -> Path:
    """Select the public mount without hiding a legacy local working root."""

    selected = select_mount_point(paths.fabric_mount_dir)
    if sys.platform == "win32" or _normalized_absolute_path(selected) != _normalized_absolute_path(workspace_root):
        return selected
    if os.environ.get("MESHIA_MOUNT_POINT"):
        raise StateError("MESHIA_MOUNT_POINT cannot be the private Meshia working directory.")
    # Older installs used ~/Meshia as their eager-sync working set. A private
    # fallback here leaves Finder pointed at an ordinary local directory while
    # the actual remote mount is hidden under ~/.meshia. Never cover or move
    # local data implicitly; the installer detects this before service turnover
    # and gives the user an explicit, recoverable migration action.
    raise StateError(
        "The configured private workspace is also the public Meshia mount. "
        "Every local file was left untouched. Move that legacy directory to a "
        "backup outside the mount path, then reconnect with a private workspace "
        f"such as {paths.default_workspace}."
    )


def _coordinator_publisher(fabric: FabricSyncCoordinator):
    """Durably stage a command-origin write before acknowledging the command."""

    def publish(path: str) -> None:
        if not path:
            return
        # Arm an exact post-state token before staging. A time-based suppression
        # window here could consume a real user edit made immediately after the
        # command write's durable snapshot.
        token = fabric.watch.arm_remote_apply(path)
        try:
            operation = fabric.stage_local_put(path)
            staged = fabric.staged_post_state(operation)
            if not fabric.watch.commit_remote_apply(token, {path: staged}):
                # A user edit won while the command snapshot was being staged.
                # Commit the newer exact state to the same coalescing journal
                # before command acknowledgement rather than relying on timing.
                fabric.stage_local_state(path)
        except BaseException:
            fabric.watch.abort_remote_apply(token)
            raise
        fabric.wake()

    return publish


def _install_signal_handlers(
    runner: NodeRunner,
    logger: NodeLogger,
    *,
    shutdown_event: threading.Event | None = None,
) -> None:
    def handler(signum: int, _frame: Any) -> None:
        logger.record("shutdown_requested", signal=signum)
        if shutdown_event is not None:
            shutdown_event.set()
        runner.stop()

    # SIGBREAK is Windows-only and is what GenerateConsoleCtrlEvent sends, so
    # without it a Ctrl-Break or a console-driven stop skips the clean disconnect.
    # Windows never *delivers* SIGTERM. The Scheduled Task controller therefore
    # uses the private cooperative shutdown request watched by `service run`;
    # a truly external TerminateProcess still falls back to the server lease.
    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        try:
            signal.signal(getattr(signal, name), handler)
        except (ValueError, AttributeError, OSError):  # pragma: no cover - non-main thread
            pass


def _install_shutdown_event_handlers(
    shutdown_event: threading.Event,
    logger: NodeLogger,
) -> None:
    """Make pre-attach retry waits interruptible before a NodeRunner exists."""

    def handler(signum: int, _frame: Any) -> None:
        logger.record("shutdown_requested", signal=signum, phase="initial_attach")
        shutdown_event.set()

    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        try:
            signal.signal(getattr(signal, name), handler)
        except (ValueError, AttributeError, OSError):  # pragma: no cover - non-main thread
            pass


def _service_runner_is_live(paths: Paths) -> bool:
    """Whether a runner holds this home's connection lease right now."""

    return runner_holds_lease(paths.home)


def _service_shutdown_request_path(paths: Paths) -> Path:
    return paths.locks_dir / SERVICE_SHUTDOWN_REQUEST_NAME


def _clear_service_shutdown_request(paths: Paths) -> None:
    try:
        _service_shutdown_request_path(paths).unlink()
    except FileNotFoundError:
        pass


def _consume_service_shutdown_request(paths: Paths, pid: int) -> bool:
    """Consume only the small regular-file request addressed to this exact runner."""

    path = _service_shutdown_request_path(paths)
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    try:
        descriptor = os.open(path, flags)
    except (FileNotFoundError, OSError):
        return False
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or not 1 <= info.st_size <= 32:
            return False
        raw = os.read(descriptor, 33)
        if len(raw) != info.st_size:
            return False
        target_pid = int(raw.decode("ascii").strip())
    except (OSError, UnicodeError, ValueError):
        return False
    finally:
        os.close(descriptor)
    if target_pid != pid:
        return False
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    return True


def _start_service_shutdown_watch(
    paths: Paths,
    pid: int,
    shutdown: threading.Event,
    logger: NodeLogger,
) -> threading.Thread:
    def watch() -> None:
        while not shutdown.wait(0.1):
            if _consume_service_shutdown_request(paths, pid):
                logger.record("shutdown_requested", source="service_controller")
                shutdown.set()
                return

    thread = threading.Thread(
        target=watch,
        name="meshia-service-shutdown",
        daemon=True,
    )
    thread.start()
    return thread


def _stop_runner_when_shutdown_requested(
    runner: NodeRunner, shutdown: threading.Event
) -> None:
    if shutdown.is_set():
        runner.stop()
        return

    def stop() -> None:
        shutdown.wait()
        runner.stop()

    threading.Thread(
        target=stop,
        name="meshia-runner-shutdown",
        daemon=True,
    ).start()


def _set_owned_pid(store: ConfigStore, pid: int) -> None:
    """Publish a diagnostic PID only after the caller owns connection.lock."""
    store.update(lambda current: setattr(current, "pid", pid))


def _clear_owned_pid(store: ConfigStore, pid: int) -> None:
    """Never let a stale process clear the PID of a newer lease owner."""
    def clear(current: NodeConfig) -> None:
        if current.pid == pid:
            current.pid = None

    try:
        store.update(clear)
    except MeshiaNodeError:
        # `forget` deliberately removes the config while still holding the
        # lease. There is then no persisted PID left to clear.
        pass


def _request_sticky_disconnect(store: ConfigStore) -> None:
    """Fence a runner locally before asking the service manager to stop it."""
    def park(current: NodeConfig) -> None:
        current.lifecycle = "disconnected"
        current.disconnect_reason = "USER_DISCONNECTED"

    store.update(park)


def _mark_disconnected(store: ConfigStore, *, reason_code: str | None = None) -> None:
    def park(current: NodeConfig) -> None:
        current.lifecycle = "disconnected"
        current.attachment_id = None
        current.last_heartbeat_at = None
        current.disconnect_reason = reason_code or "REMOTE_AUTHORITY_REVOKED"

    try:
        store.update(park)
    except MeshiaNodeError:
        return
    try:
        if reason_code in ("HOST_REVOKED", "DEVICE_REVOKED"):
            ControlClient(store.paths).forget_device_credentials(store.require().host_id)
    except (MeshiaNodeError, OSError):
        # Remote credentials are already revoked. A locked or unreadable local
        # OAuth file must never prevent the durable, sticky runner fence.
        pass


def _acquire_connection_lease(paths: Paths, timeout: float) -> ConnectionLease:
    """Wait briefly for a fenced service runner to release its OS lease."""
    lease = ConnectionLease(paths.connection_lock)
    deadline = time.monotonic() + max(0.0, timeout)
    while True:
        try:
            return lease.acquire()
        except AlreadyRunning:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise
            time.sleep(min(0.1, remaining))


def _current_executable() -> Path:
    raw = sys.argv[0]
    if Path(raw).name == "__main__.py":
        installed = shutil.which("meshia-node")
        if installed is None:
            raise ServiceError(
                "Install the meshia-node console executable before installing its service."
            )
        raw = installed
    executable = Path(raw).expanduser()
    explicit_path = executable.is_absolute() or bool(os.path.dirname(raw))
    if sys.platform == "win32" and executable.name.lower() in ("meshia-node", "meshia"):
        # Windows console wrappers strip .exe from argv[0]. Restore the same
        # launcher for the service definition and its runtime-status receipt.
        executable = executable.with_name(executable.name + ".exe")
        if explicit_path and not executable.is_file():
            raise ServiceError(f"The invoked Meshia console executable is missing: {executable}")
    # An explicitly invoked runtime must never resolve to another version on PATH.
    located = shutil.which(str(executable)) if not explicit_path else None
    return Path(located or executable).resolve()


def _service_executable() -> Path:
    """Use Meshia's product name for the macOS background-item identity.

    macOS derives the user-visible Background Items name from the executable
    registered in the LaunchAgent.  The release therefore ships a second
    console entry point named ``Meshia`` for launchd while retaining
    ``meshia-node`` as the CLI and the stable ``io.meshia.node`` service label.
    Older/source-tree runtimes do not have that entry point, so they keep their
    existing executable until a packaged upgrade installs it.
    """

    executable = _current_executable()
    if sys.platform != "darwin":
        return executable
    display_executable = executable.with_name("Meshia")
    try:
        metadata = display_executable.lstat()
        executable_metadata = executable.stat()
    except OSError:
        return executable
    if (
        stat.S_ISLNK(metadata.st_mode)
        or not stat.S_ISREG(metadata.st_mode)
        or not metadata.st_mode & stat.S_IXUSR
        or metadata.st_uid != executable_metadata.st_uid
    ):
        return executable
    return display_executable


def _service_controller(paths: Paths) -> ServiceController:
    home = paths.home.expanduser().resolve()
    executable = _service_executable()
    try:
        host = native_host.expected_host(executable, home)
    except (native_host.NativeHostError, OSError) as error:
        raise ServiceError(f"Cannot use the installed Meshia Node native host: {error}") from error
    if host is not None:
        def verify_activation() -> None:
            try:
                if native_host.discover_host(executable, home) != host:
                    raise native_host.NativeHostError("The registered native app is missing.")
                native_host.register_verified_host(host)
            except (native_host.NativeHostError, OSError) as error:
                raise ServiceError(f"Cannot use the installed Meshia Node native host: {error}") from error

        controller = ServiceController(
            host, home, user_home=native_host.account_home(),
            native_bundle_identifier=native_host.BUNDLE_IDENTIFIER,
            activation_verifier=verify_activation,
        )
        # An absent/damaged app must still be stoppable by its exact owner.
        # Presence selects an identity, never permission to execute that app.
        if os.path.lexists(host.parents[2]) or controller.owns_home():
            return controller
    return ServiceController(executable, home)


def _runtime_status_path(paths: Paths) -> Path:
    return paths.home / SERVICE_RUNTIME_STATUS_NAME


def _runtime_launch_identity(paths: Paths) -> tuple[str, int | None]:
    console = _current_executable()
    try:
        identity = native_host.running_host_identity(console, paths.home.expanduser().resolve())
    except (native_host.NativeHostError, OSError) as error:
        raise ServiceError(f"Cannot verify the Meshia Node service launch identity: {error}") from error
    return (str(identity[0]), identity[1]) if identity else (str(console), None)


def _clear_runtime_status(paths: Paths, logger: NodeLogger) -> None:
    """Remove a stopped runner's diagnostic receipt without blocking parking."""

    try:
        _runtime_status_path(paths).unlink(missing_ok=True)
    except OSError as error:
        # Runtime status is diagnostic, not connection authority. A damaged or
        # unexpectedly locked receipt must not turn a sticky disconnect into a
        # service-manager restart loop, but the bounded event keeps the local
        # cleanup failure visible to doctor/log inspection.
        logger.record(
            "service_runtime_status_cleanup_deferred",
            error=type(error).__name__,
        )


def _parse_utc_timestamp(value: object) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(timezone.utc)


def _write_runtime_status(
    paths: Paths,
    *,
    start_nonce: str,
    pid: int,
    executable: str | None = None,
    native_host_pid: int | None = None,
    package_version: str | None = None,
    started_at: str | None = None,
    fabric_ready: bool = False,
    fabric_readiness_reason: str = "initializing",
    fabric_head_generation: int | None = None,
    runtime_ready: bool | None = None,
    runtime_readiness_reason: str | None = None,
    command_safe: bool | None = None,
    command_safety_reason: str | None = None,
    sync_converged: bool | None = None,
    sync_convergence_reason: str | None = None,
    watcher_health: dict[str, Any] | None = None,
    staging_health: dict[str, Any] | None = None,
    workspace_execution: dict[str, Any] | None = None,
    last_error: dict[str, str] | None = None,
    degraded_operations: Sequence[str] = (),
) -> dict[str, Any]:
    # `fabric_ready` remains a wire-compatible alias for command safety while
    # 1.1.x runtime files age out. New callers use the three explicit states:
    # process/lease readiness, command-claim safety, and full sync convergence.
    command_safe = fabric_ready if command_safe is None else command_safe
    runtime_ready = fabric_ready if runtime_ready is None else runtime_ready
    sync_converged = command_safe if sync_converged is None else sync_converged
    runtime_readiness_reason = runtime_readiness_reason or (
        "ready" if runtime_ready else "initializing"
    )
    command_safety_reason = command_safety_reason or fabric_readiness_reason
    sync_convergence_reason = sync_convergence_reason or (
        "converged" if sync_converged else command_safety_reason
    )
    watcher_health = watcher_health or {"available": False}
    staging_health = staging_health or {"available": False}
    if workspace_execution is not None and _workspace_execution_evidence(workspace_execution) is None:
        raise ValueError("workspace_execution must be bounded daemon evidence")
    if not isinstance(fabric_ready, bool):
        raise ValueError("fabric_ready must be a boolean")
    for name, value in (
        ("runtime_ready", runtime_ready),
        ("command_safe", command_safe),
        ("sync_converged", sync_converged),
    ):
        if not isinstance(value, bool):
            raise ValueError(f"{name} must be a boolean")
    for name, value in (
        ("fabric_readiness_reason", fabric_readiness_reason),
        ("runtime_readiness_reason", runtime_readiness_reason),
        ("command_safety_reason", command_safety_reason),
        ("sync_convergence_reason", sync_convergence_reason),
    ):
        if not isinstance(value, str) or not value or len(value) > 128:
            raise ValueError(f"{name} must be a bounded string")
    if (
        fabric_head_generation is not None
        and (
            isinstance(fabric_head_generation, bool)
            or not isinstance(fabric_head_generation, int)
            or not 0 <= fabric_head_generation <= 2_147_483_647
        )
    ):
        raise ValueError("fabric_head_generation must be a non-negative generation")
    # Fabric v2 sequence zero is the settled head of an unwritten workspace;
    # only None means no authoritative head has been published locally.
    if command_safe and fabric_head_generation is None:
        raise ValueError("a command-safe runtime must identify its manifest head")
    if not isinstance(watcher_health, dict) or not isinstance(staging_health, dict):
        raise ValueError("runtime watcher/staging health must be objects")
    if len(degraded_operations) > STATUS_DEGRADED_OPERATION_LIMIT or any(
        not isinstance(item, str) or not item or len(item) > 64
        for item in degraded_operations
    ):
        raise ValueError("degraded_operations is outside its bounded contract")
    if last_error is not None and (
        not isinstance(last_error, dict)
        or any(not isinstance(key, str) or not isinstance(value, str)
               for key, value in last_error.items())
        or len(last_error) > 4
        or any(len(key) > 64 or len(value) > STATUS_ERROR_MAX_CHARS
               for key, value in last_error.items())
    ):
        raise ValueError("last_error is outside its bounded contract")
    if executable is None:
        executable, native_host_pid = _runtime_launch_identity(paths)
    if native_host_pid is not None and (
        not isinstance(native_host_pid, int) or isinstance(native_host_pid, bool) or native_host_pid <= 1
    ):
        raise ValueError("native_host_pid must be a valid process id")
    document = {
        "start_nonce": start_nonce,
        "pid": pid,
        "executable": executable,
        "native_host_pid": native_host_pid,
        "package_version": package_version or __version__,
        "started_at": started_at or iso8601(),
        "runtime_ready": runtime_ready,
        "runtime_readiness_reason": runtime_readiness_reason,
        "command_safe": command_safe,
        "command_safety_reason": command_safety_reason,
        "sync_converged": sync_converged,
        "sync_convergence_reason": sync_convergence_reason,
        # Compatibility aliases consumed by the 1.1.x installer/status UI.
        "fabric_ready": command_safe,
        "fabric_readiness_reason": command_safety_reason,
        "fabric_head_generation": fabric_head_generation,
        "watcher": watcher_health,
        "staging": staging_health,
        "workspace_execution": workspace_execution,
        "last_error": last_error,
        "degraded_operations": list(degraded_operations),
    }
    write_private_file(
        _runtime_status_path(paths),
        json.dumps(document, indent=2, sort_keys=True).encode("utf-8"),
    )
    return document


def _read_runtime_status(paths: Paths) -> dict[str, Any] | None:
    path = _runtime_status_path(paths)
    try:
        if path.stat().st_size > 16 * 1024:
            return None
        document = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, ValueError):
        return None
    if not isinstance(document, dict):
        return None
    nonce = document.get("start_nonce")
    pid = document.get("pid")
    executable = document.get("executable")
    native_host_pid = document.get("native_host_pid")
    version = document.get("package_version")
    started_at = document.get("started_at")
    fabric_ready = document.get("fabric_ready")
    fabric_readiness_reason = document.get("fabric_readiness_reason")
    fabric_head_generation = document.get("fabric_head_generation")
    runtime_ready = document.get("runtime_ready", fabric_ready)
    runtime_readiness_reason = document.get(
        "runtime_readiness_reason", "ready" if runtime_ready else "initializing"
    )
    command_safe = document.get("command_safe", fabric_ready)
    command_safety_reason = document.get(
        "command_safety_reason", fabric_readiness_reason
    )
    sync_converged = document.get("sync_converged", command_safe)
    sync_convergence_reason = document.get(
        "sync_convergence_reason",
        "converged" if sync_converged else command_safety_reason,
    )
    watcher_health = document.get("watcher", {"available": False})
    staging_health = document.get("staging", {"available": False})
    workspace_execution = _workspace_execution_evidence(document.get("workspace_execution"))
    last_error = document.get("last_error")
    degraded_operations = document.get("degraded_operations", [])
    if (
        not isinstance(nonce, str)
        or UUID_RE.fullmatch(nonce) is None
        or not isinstance(pid, int)
        or isinstance(pid, bool)
        or pid <= 0
        or not isinstance(executable, str)
        or not executable
        or not Path(executable).is_absolute()
        or (native_host_pid is not None and (
            not isinstance(native_host_pid, int) or isinstance(native_host_pid, bool)
            or native_host_pid <= 1
        ))
        or not isinstance(version, str)
        or not version
        or len(version) > 128
        or _parse_utc_timestamp(started_at) is None
        or not isinstance(fabric_ready, bool)
        or not isinstance(fabric_readiness_reason, str)
        or not fabric_readiness_reason
        or len(fabric_readiness_reason) > 128
        or (
            fabric_head_generation is not None
            and (
                isinstance(fabric_head_generation, bool)
                or not isinstance(fabric_head_generation, int)
                or not 0 <= fabric_head_generation <= 2_147_483_647
            )
        )
        or (command_safe and fabric_head_generation is None)
        or not isinstance(runtime_ready, bool)
        or not isinstance(command_safe, bool)
        or not isinstance(sync_converged, bool)
        or any(
            not isinstance(value, str) or not value or len(value) > 128
            for value in (
                runtime_readiness_reason,
                command_safety_reason,
                sync_convergence_reason,
            )
        )
        or not isinstance(watcher_health, dict)
        or not isinstance(staging_health, dict)
        or (
            last_error is not None
            and (
                not isinstance(last_error, dict)
                or len(last_error) > 4
                or any(
                    not isinstance(key, str)
                    or not isinstance(value, str)
                    or len(key) > 64
                    or len(value) > STATUS_ERROR_MAX_CHARS
                    for key, value in last_error.items()
                )
            )
        )
        or not isinstance(degraded_operations, list)
        or len(degraded_operations) > STATUS_DEGRADED_OPERATION_LIMIT
        or any(
            not isinstance(item, str) or not item or len(item) > 64
            for item in degraded_operations
        )
    ):
        return None
    return {
        "start_nonce": nonce,
        "pid": pid,
        "executable": executable,
        "native_host_pid": native_host_pid,
        "package_version": version,
        "started_at": started_at,
        "runtime_ready": runtime_ready,
        "runtime_readiness_reason": runtime_readiness_reason,
        "command_safe": command_safe,
        "command_safety_reason": command_safety_reason,
        "sync_converged": sync_converged,
        "sync_convergence_reason": sync_convergence_reason,
        "fabric_ready": command_safe,
        "fabric_readiness_reason": command_safety_reason,
        "fabric_head_generation": fabric_head_generation,
        "watcher": watcher_health,
        "staging": staging_health,
        "workspace_execution": workspace_execution,
        "last_error": last_error,
        "degraded_operations": degraded_operations,
    }


def _update_runtime_fabric_readiness(
    paths: Paths,
    *,
    pid: int,
    ready: bool,
    reason: str | None,
    head_generation: int | None,
) -> bool:
    """Persist a transition only for the exact live runtime that owns ``pid``."""

    runtime = _read_runtime_status(paths)
    if runtime is None or runtime["pid"] != pid:
        return False
    _write_runtime_status(
        paths,
        start_nonce=runtime["start_nonce"],
        pid=runtime["pid"],
        executable=runtime["executable"],
        native_host_pid=runtime["native_host_pid"],
        package_version=runtime["package_version"],
        started_at=runtime["started_at"],
        fabric_ready=ready,
        fabric_readiness_reason=reason or ("ready" if ready else "not_ready"),
        fabric_head_generation=head_generation,
        runtime_ready=runtime["runtime_ready"],
        runtime_readiness_reason=runtime["runtime_readiness_reason"],
        command_safe=ready,
        command_safety_reason=reason or ("ready" if ready else "not_ready"),
        sync_converged=runtime["sync_converged"] if ready else False,
        sync_convergence_reason=(
            runtime["sync_convergence_reason"]
            if ready
            else reason or "command_not_safe"
        ),
        watcher_health=runtime["watcher"],
        staging_health=runtime["staging"],
        workspace_execution=runtime["workspace_execution"],
        last_error=runtime["last_error"],
        degraded_operations=runtime["degraded_operations"],
    )
    return True


def _bounded_last_error(
    operation: object,
    code: object,
    detail: object,
) -> dict[str, str] | None:
    if not isinstance(operation, str) or not operation:
        return None
    return {
        "operation": operation[:64],
        "code": (code if isinstance(code, str) and code else "UNKNOWN")[:64],
        "detail": (detail if isinstance(detail, str) else str(detail))[
            :STATUS_ERROR_MAX_CHARS
        ],
    }


def _coordinator_runtime_health(
    fabric: FabricSyncCoordinator,
    *,
    command_safe: bool,
    command_reason: str | None,
    head_generation: int | None,
) -> dict[str, Any]:
    """Project cheap, bounded live health without enumerating the namespace."""

    local_file_candidate = getattr(
        fabric.database, "list_local_transfer_issues", None
    )
    local_file_rows = (
        local_file_candidate(limit=5) if callable(local_file_candidate) else ()
    )
    local_file_issues = {
        "sample": [
            {
                "code": str(item.issue_code),
                "path": item.path[:STATUS_ERROR_MAX_CHARS],
                "size_bytes": int(item.issue_size_bytes or 0),
                "remediation": LOCAL_FILE_UNSUPPORTED_REMEDIATION,
            }
            for item in local_file_rows[:4]
        ],
        "saturated": len(local_file_rows) > 4,
    }

    watch_candidate = getattr(fabric.watch, "health_snapshot", None)
    watch_health = watch_candidate() if callable(watch_candidate) else None
    if watch_health is not None:
        local_issues = tuple(getattr(watch_health, "local_issues", ()))
        watcher = {
            "available": True,
            "backend": str(watch_health.backend)[:32],
            "healthy": bool(watch_health.collector_healthy),
            "using_native": bool(watch_health.using_native),
            "overflow": bool(watch_health.reconciliation_needed),
            "ingress_queue_depth": int(watch_health.ingress_queue_depth),
            "ingress_queue_capacity": int(watch_health.ingress_queue_capacity),
            "last_loss_or_error": (
                str(watch_health.last_loss_or_error)[:STATUS_ERROR_MAX_CHARS]
                if watch_health.last_loss_or_error
                else None
            ),
            "local_issue_count": len(local_issues),
            "local_issues_saturated": bool(
                getattr(watch_health, "local_issues_saturated", False)
            ),
            "local_issue_sample": [
                {
                    "code": str(getattr(issue, "code", "UNKNOWN"))[:64],
                    "path": str(getattr(issue, "path", ""))[
                        :STATUS_ERROR_MAX_CHARS
                    ],
                }
                for issue in local_issues[:STATUS_WATCHER_ISSUE_SAMPLE_MAX]
            ],
        }
    else:
        watcher = {
            "available": True,
            "healthy": bool(fabric.watch.healthy),
            "using_native": bool(fabric.watch.using_native),
            "overflow": bool(fabric.watch.overflow),
            "recovery_generation": int(fabric.watch.recovery_generation),
            "local_issue_count": 0,
            "local_issues_saturated": False,
            "local_issue_sample": [],
        }
    ledger = getattr(fabric, "_staging_ledger", None)
    if ledger is None:
        staging: dict[str, Any] = {"available": False}
        staging_ready = True
    else:
        status = ledger.status()
        staging = {
            "available": True,
            "reserved_bytes": int(status.reserved_bytes),
            "reservation_count": int(status.reservation_count),
            "max_bytes": int(status.max_bytes),
            "max_entries": int(status.max_entries),
            "repair_required": bool(status.repair_required),
            "repair_phase": str(status.repair_phase)[:32],
            "over_capacity": bool(status.over_capacity),
        }
        staging_ready = not status.repair_required and not status.over_capacity

    # Prefer an engine-owned O(1) convergence snapshot when available. The
    # fallback checks only indexed queue heads and the one-unknown invariant;
    # it deliberately reports `health_snapshot_unavailable` instead of doing a
    # namespace-sized COUNT/LIST in the supervision loop.
    health_candidate = getattr(fabric.database, "readiness_snapshot", None)
    health = health_candidate() if callable(health_candidate) else None
    if health is not None:
        pending = int(bool(health.pending_operations))
        commit_unknown = int(bool(health.commit_unknown))
        unresolved = int(bool(health.unresolved_conflicts))
        health_complete = True
    else:
        pending = int(fabric.database.next_operation_attempt_ns() is not None)
        commit_unknown = int(fabric.database.get_commit_unknown_operation() is not None)
        unresolved = 0
        health_complete = False

    sync_converged = bool(
        command_safe
        and health_complete
        and pending == 0
        and commit_unknown == 0
        and unresolved == 0
        and watcher["healthy"]
        and not watcher["overflow"]
        and watcher["local_issue_count"] == 0
        and not watcher["local_issues_saturated"]
        and staging_ready
        and fabric.last_error is None
    )
    if sync_converged:
        sync_reason = "converged"
    elif not command_safe:
        sync_reason = command_reason or "command_not_safe"
    elif not health_complete:
        sync_reason = "health_snapshot_unavailable"
    elif commit_unknown:
        sync_reason = "commit_unknown"
    elif pending:
        sync_reason = "pending_operations"
    elif unresolved:
        sync_reason = "unresolved_conflicts"
    elif watcher["overflow"] or not watcher["healthy"]:
        sync_reason = "watcher_recovery"
    elif watcher["local_issue_count"] or watcher["local_issues_saturated"]:
        sync_reason = "watcher_local_issues"
    elif not staging_ready:
        sync_reason = "staging_repair"
    else:
        sync_reason = "sync_error"
    return {
        "command_safe": command_safe,
        "command_safety_reason": command_reason or (
            "ready" if command_safe else "not_ready"
        ),
        "sync_converged": sync_converged,
        "sync_convergence_reason": sync_reason,
        "fabric_head_generation": head_generation,
        "watcher": watcher,
        "staging": staging,
        "local_file_issues": local_file_issues,
        "fabric_last_error": (
            _bounded_last_error("fabric_sync", "FABRIC_SYNC_RETRY", fabric.last_error)
            if fabric.last_error
            else None
        ),
    }


def _publish_runtime_health(
    paths: Paths,
    *,
    pid: int,
    node_health: dict[str, Any],
    fabric: FabricSyncCoordinator,
    runtime_manager: WorkspaceRuntimeManager | None = None,
    workspace_execution: dict[str, Any] | None = None,
) -> bool:
    """Persist live health only when its bounded semantic snapshot changed."""

    runtime = _read_runtime_status(paths)
    if runtime is None or runtime["pid"] != pid:
        return False
    command_safe = bool(node_health.get("command_safe"))
    command_reason = node_health.get("command_safety_reason")
    head_generation = node_health.get("fabric_head_generation")
    coordinator = _coordinator_runtime_health(
        fabric,
        command_safe=command_safe,
        command_reason=command_reason if isinstance(command_reason, str) else None,
        head_generation=head_generation if isinstance(head_generation, int) else None,
    )
    if runtime_manager is not None:
        workspace_staging = runtime_manager.staging_readiness_snapshot()
        coordinator["staging"] = {
            **coordinator["staging"],
            **workspace_staging,
        }
        if not workspace_staging["all_active_workspaces_ready"]:
            coordinator["sync_converged"] = False
            coordinator["sync_convergence_reason"] = (
                "workspace_startup_recovery_saturated"
                if workspace_staging["startup_recovery_scan_saturated"]
                else "workspace_startup_recovery_unavailable"
                if workspace_staging["health_unavailable_workspace_count"]
                else "workspace_attachment_rebind"
                if workspace_staging.get("attachment_rebind_workspace_count", 0)
                else "workspace_startup_recovery"
                if workspace_staging["startup_recovery_active_workspace_count"]
                else "workspace_staging_repair"
            )
    node_last_error = node_health.get("last_error")
    last_error = (
        node_last_error
        if isinstance(node_last_error, dict)
        else coordinator["fabric_last_error"]
    )
    degraded = tuple(
        str(item)[:64]
        for item in node_health.get("degraded_operations", ())
        if isinstance(item, str)
    )[:STATUS_DEGRADED_OPERATION_LIMIT]
    updated = {
        **runtime,
        "runtime_ready": bool(node_health.get("runtime_ready")),
        "runtime_readiness_reason": str(
            node_health.get("runtime_readiness_reason") or "not_ready"
        )[:128],
        **{key: value for key, value in coordinator.items() if key != "fabric_last_error"},
        "last_error": last_error,
        "degraded_operations": list(degraded),
        "workspace_execution": workspace_execution,
    }
    comparable = (
        "runtime_ready",
        "runtime_readiness_reason",
        "command_safe",
        "command_safety_reason",
        "sync_converged",
        "sync_convergence_reason",
        "fabric_head_generation",
        "watcher",
        "staging",
        "last_error",
        "degraded_operations",
        "workspace_execution",
    )
    if all(runtime.get(key) == updated.get(key) for key in comparable):
        return True
    _write_runtime_status(
        paths,
        start_nonce=runtime["start_nonce"],
        pid=runtime["pid"],
        executable=runtime["executable"],
        native_host_pid=runtime["native_host_pid"],
        package_version=runtime["package_version"],
        started_at=runtime["started_at"],
        fabric_head_generation=updated["fabric_head_generation"],
        runtime_ready=updated["runtime_ready"],
        runtime_readiness_reason=updated["runtime_readiness_reason"],
        command_safe=updated["command_safe"],
        command_safety_reason=updated["command_safety_reason"],
        sync_converged=updated["sync_converged"],
        sync_convergence_reason=updated["sync_convergence_reason"],
        watcher_health=updated["watcher"],
        staging_health=updated["staging"],
        workspace_execution=updated["workspace_execution"],
        last_error=updated["last_error"],
        degraded_operations=updated["degraded_operations"],
    )
    return True


def _publish_command_readiness(
    store: ConfigStore,
    paths: Paths,
    *,
    pid: int,
    ready: bool,
    reason: str | None,
    head_generation: int | None,
    runtime_status_required: bool = False,
) -> bool:
    """Complete a first-use root adoption before advertising command safety.

    The on-root marker is committed first and the config flag second. A crash
    between them is recoverable because completion is idempotent and startup
    validates the exact marker before copying its state back into config. The
    caller treats any exception or ``False`` return as a retryable command-claim
    veto, so neither a runtime-status write failure nor a partial adoption can
    authorize work in an unreconciled namespace.
    """

    if ready:
        config = store.require()
        if config.workspace_adoption_pending:
            if config.installation_id is None or config.workspace_id is None:
                raise WorkspaceClaimInvalid(
                    "The pending workspace adoption is missing its durable identity."
                )
            completed = complete_workspace_root_adoption(
                config.workspace,
                installation_id=config.installation_id,
                workspace_id=config.workspace_id,
                host_id=config.host_id,
                session_id=config.session_id,
            )

            def persist_completion(current: NodeConfig) -> None:
                if (
                    current.workspace != config.workspace
                    or current.installation_id != config.installation_id
                    or current.workspace_id != config.workspace_id
                    or current.host_id != config.host_id
                    or current.session_id != config.session_id
                ):
                    raise WorkspaceClaimInvalid(
                        "The workspace authority changed while adoption was completing."
                    )
                if completed.adoption_pending:
                    raise WorkspaceClaimInvalid(
                        "The workspace ownership marker is still pending adoption."
                    )
                current.workspace_adoption_pending = False

            store.update(persist_completion)

    updated = _update_runtime_fabric_readiness(
        paths,
        pid=pid,
        ready=ready,
        reason=reason,
        head_generation=head_generation,
    )
    if updated:
        return True
    # Foreground `meshia connect` intentionally has no service runtime file.
    # The service path opts into the stricter PID-owned diagnostic fence.
    return not runtime_status_required and _read_runtime_status(paths) is None


def _read_config_for_status(paths: Paths) -> NodeConfig | None:
    """Read the atomically replaced config without creating the state lock."""

    path = paths.config_path
    try:
        if path.stat().st_size > STATUS_CONFIG_MAX_BYTES:
            raise OSError("configuration exceeds the status read bound")
        document = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as error:
        raise OSError("node configuration is unreadable") from error
    if not isinstance(document, dict):
        raise OSError("node configuration is not an object")
    try:
        return NodeConfig.from_json(document)
    except (TypeError, ValueError, MeshiaNodeError) as error:
        raise OSError("node configuration is invalid") from error


def _runtime_status_document(paths: Paths) -> dict[str, Any]:
    runtime = _read_runtime_status(paths)
    if runtime is None:
        return {"present": False, "live": False}
    try:
        config = _read_config_for_status(paths)
    except (OSError, MeshiaNodeError):
        config = None
    owned_pid = config is not None and config.pid == runtime["pid"]
    if config is not None and config.lifecycle != "connected":
        lifecycle_reason = f"lifecycle_{config.lifecycle}"[:128]
        runtime = {
            **runtime,
            "runtime_ready": False,
            "runtime_readiness_reason": lifecycle_reason,
            "command_safe": False,
            "command_safety_reason": lifecycle_reason,
            "sync_converged": False,
            "sync_convergence_reason": lifecycle_reason,
            "fabric_ready": False,
            "fabric_readiness_reason": lifecycle_reason,
        }
    adoption_pending = bool(
        config is not None and config.workspace_adoption_pending
    )
    if adoption_pending:
        runtime = {
            **runtime,
            "command_safe": False,
            "command_safety_reason": "workspace_adoption_pending",
            "sync_converged": False,
            "sync_convergence_reason": "workspace_adoption_pending",
            "fabric_ready": False,
            "fabric_readiness_reason": "workspace_adoption_pending",
        }
    live = owned_pid and process_is_alive(runtime["pid"])
    evidence = runtime.get("workspace_execution")
    if evidence is not None:
        checked = _parse_utc_timestamp(evidence["checked_at"])
        age = (datetime.now(timezone.utc) - checked).total_seconds()
        current_identity = config is not None and all(
            evidence[key] == getattr(config, key)
            for key in ("host_id", "generation", "session_id", "attachment_id")
        )
        reason = ("daemon_not_live" if not live else "not_connected"
                  if config is None or config.lifecycle != "connected" else "identity_changed"
                  if not current_identity else "workspace_adoption_pending" if adoption_pending
                  else "probe_stale" if not 0 <= age <= evidence["valid_for_seconds"]
                  else None)
        if reason is None and evidence["ready"] and evidence["mount_identity"] is not None:
            current_mount = _fabric_mount_status_document(paths)
            if evidence["mount_identity"] != _workspace_mount_identity(paths, current_mount):
                reason = "mount_changed"
        if reason is not None:
            runtime = {**runtime, "workspace_execution": {**evidence, "ready": False, "reason": reason}}
    return {
        **runtime,
        "present": True,
        "live": live,
    }


def _same_executable(left: str, right: str) -> bool:
    return os.path.normcase(os.path.realpath(left)) == os.path.normcase(os.path.realpath(right))


def _native_service_owned(
    controller: ServiceController, runtime: dict[str, Any], action: ServiceAction,
) -> bool:
    """Bind the live daemon to this exact owned LaunchAgent's native process."""
    parent = runtime.get("native_host_pid")
    expected = Path(controller.definition.run_command[0])
    return bool(
        controller.owns_home()
        and runtime.get("executable") == str(expected)
        and parent is not None and controller.registered_pid(action) == parent
        and native_host.owns_runner(runtime.get("pid", 0), parent, expected)
    )


def _evaluate_service_readiness(
    store: ConfigStore,
    paths: Paths,
    *,
    baseline: dict[str, Any] | None,
    restart_started_at: datetime,
    expected_executable: str,
    expected_version: str,
    pid_is_alive: Callable[[int], bool] = process_is_alive,
    controller: ServiceController | None = None,
) -> tuple[dict[str, Any] | None, str]:
    runtime = _read_runtime_status(paths)
    if runtime is None:
        return None, "runtime_status_missing"
    started_at = _parse_utc_timestamp(runtime["started_at"])
    assert started_at is not None
    if baseline is not None:
        prior_started_at = _parse_utc_timestamp(baseline.get("started_at"))
        if runtime["start_nonce"] == baseline.get("start_nonce") or (
            prior_started_at is not None and started_at <= prior_started_at
        ):
            return None, "runner_not_replaced"
    if started_at <= restart_started_at:
        return None, "runner_not_newer_than_restart"
    if not _same_executable(runtime["executable"], expected_executable):
        return None, "runtime_executable_mismatch"
    if runtime["package_version"] != expected_version:
        return None, "runtime_version_mismatch"

    config = store.require()
    if config.pid != runtime["pid"]:
        return None, "runner_pid_not_owned"
    if not pid_is_alive(runtime["pid"]):
        return None, "runner_not_live"
    if controller is not None and getattr(controller, "native_bundle_identifier", None) is not None:
        if not _native_service_owned(controller, runtime, controller.status()):
            return None, "native_host_not_owned_by_service"
    if config.lifecycle != "connected":
        return None, "lifecycle_not_connected"
    heartbeat_at = _parse_utc_timestamp(config.last_heartbeat_at)
    if heartbeat_at is None or heartbeat_at <= restart_started_at:
        return None, "heartbeat_not_fresh"
    if runtime["runtime_ready"] is not True:
        return None, f"runtime_not_ready:{runtime['runtime_readiness_reason']}"
    command_safe = bool(runtime["command_safe"] and not config.workspace_adoption_pending)
    command_reason = (
        "workspace_adoption_pending"
        if config.workspace_adoption_pending
        else runtime["command_safety_reason"]
    )
    sync_converged = bool(runtime["sync_converged"] and command_safe)
    sync_reason = (
        command_reason if not command_safe else runtime["sync_convergence_reason"]
    )
    return (
        {
            **runtime,
            "ready": True,
            "lifecycle": config.lifecycle,
            "last_heartbeat_at": config.last_heartbeat_at,
            "runtime_ready": True,
            "runtime_readiness_reason": runtime["runtime_readiness_reason"],
            "command_safe": command_safe,
            "command_safety_reason": command_reason,
            "sync_converged": sync_converged,
            "sync_convergence_reason": sync_reason,
            "fabric_ready": command_safe,
            "fabric_readiness_reason": command_reason,
            "fabric_head_generation": runtime["fabric_head_generation"],
        },
        "ready",
    )


def _wait_for_service_ready(
    store: ConfigStore,
    paths: Paths,
    *,
    baseline: dict[str, Any] | None,
    restart_started_at: datetime,
    expected_executable: str,
    expected_version: str,
    timeout_seconds: float,
    monotonic: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], None] = time.sleep,
    pid_is_alive: Callable[[int], bool] = process_is_alive,
    controller: ServiceController | None = None,
) -> dict[str, Any]:
    if not math.isfinite(timeout_seconds) or timeout_seconds <= 0 or timeout_seconds > 300:
        raise InvalidArgument("--timeout-seconds must be greater than 0 and at most 300.")
    deadline = monotonic() + timeout_seconds
    last_reason = "runtime_status_missing"
    while True:
        ready, last_reason = _evaluate_service_readiness(
            store,
            paths,
            baseline=baseline,
            restart_started_at=restart_started_at,
            expected_executable=expected_executable,
            expected_version=expected_version,
            pid_is_alive=pid_is_alive,
            controller=controller,
        )
        if ready is not None:
            return ready
        if last_reason in ("runtime_executable_mismatch", "runtime_version_mismatch"):
            raise ServiceError(f"Service readiness failed ({last_reason}).")
        remaining = deadline - monotonic()
        if remaining <= 0:
            raise ServiceError(f"Service readiness timed out ({last_reason}).")
        sleep(min(SERVICE_READY_POLL_SECONDS, remaining))


def _definition_belongs_to_home(controller: ServiceController, paths: Paths) -> bool:
    return controller.owns_home()


def _workspace_claim_status_document(config: NodeConfig | None) -> dict[str, Any]:
    if config is None:
        return {"available": False, "state": "not_enrolled", "valid": False}
    try:
        status = workspace_root_claim_status(
            config.workspace,
            installation_id=config.installation_id,
            workspace_id=config.workspace_id,
            host_id=(config.host_id if config.workspace_id is not None else None),
            session_id=(config.session_id if config.workspace_id is not None else None),
            require_bound=config.workspace_id is not None,
        )
        claim = status.claim
        return {
            "available": True,
            "state": status.state,
            "valid": status.state == "bound",
            "reason": status.reason,
            "canonical_root": status.canonical_root,
            "workspace_id": claim.workspace_id if claim is not None else None,
            "installation_id": claim.installation_id if claim is not None else None,
            "bound": bool(claim is not None and claim.is_bound),
            "adoption_pending": (
                config.workspace_adoption_pending
                if claim is not None and claim.workspace_id == config.workspace_id
                else (claim.adoption_pending if claim is not None else False)
            ),
        }
    except Exception as error:
        return {
            "available": False,
            "state": "invalid",
            "valid": False,
            "detail": type(error).__name__,
        }


def _service_status_document(paths: Paths) -> dict[str, Any]:
    runtime = _runtime_status_document(paths)
    runner_active = bool(runtime["live"])
    try:
        workspace_claim = _workspace_claim_status_document(_read_config_for_status(paths))
    except (OSError, MeshiaNodeError):
        workspace_claim = {
            "available": False,
            "state": "config_unreadable",
            "valid": False,
        }
    try:
        controller = _service_controller(paths)
        action = controller.status()
        codes = [result.returncode for result in action.results]
        manager_registered = bool(codes) and codes[-1] == 0
        belongs = _definition_belongs_to_home(controller, paths)
        native_owned = (
            runner_active and _native_service_owned(controller, runtime, action)
            if getattr(controller, "native_bundle_identifier", None) is not None else None
        )
        return {
            "supported": True,
            "platform": controller.definition.platform,
            "name": controller.definition.name,
            "installed_for_home": belongs,
            "manager_registered": manager_registered,
            "manager_active": runner_active and belongs and manager_registered and native_owned is not False,
            "native_host_owned": native_owned,
            "runner_active": runner_active,
            "status_codes": codes,
            "runtime": runtime,
            "workspace_claim": workspace_claim,
        }
    except (OSError, ServiceError) as error:
        return {
            "supported": False,
            "manager_registered": False,
            "manager_active": False,
            "native_host_owned": False,
            "runner_active": runner_active,
            "detail": type(error).__name__,
            "runtime": runtime,
            "workspace_claim": workspace_claim,
        }


def _fabric_mount_status_document(
    paths: Paths, *, enabled: bool = True
) -> dict[str, Any]:
    """Return an O(1) mount view without touching the mounted namespace.

    A dead FUSE/SMB/NFS mount can leave every ``stat`` of the mount point in an
    uninterruptible kernel wait.  Status must remain the recovery surface in
    exactly that failure mode, so status combines the private mount receipt,
    its owner PID, and the bounded OS mount registry; it never stats the mounted
    path. The mount process writes the receipt only after successful attachment
    and removes it after normal teardown.
    """

    supported = sys.platform in ("darwin", "linux", "win32")
    runtime = detect_fuse_runtime() if supported and enabled else None
    receipt = read_mount_state(paths.fabric_mount_state_path) if supported else None
    receipt_present = bool(
        supported and mount_state_path_present(paths.fabric_mount_state_path)
    )
    invalid_receipt = bool(receipt_present and receipt is None)
    if receipt is not None:
        mount_point = str(receipt["mount_point"])
        owner_pid = int(receipt["owner_pid"])
    else:
        mount_point = "M:\\" if sys.platform == "win32" else str(paths.fabric_mount_dir)
        owner_pid = None
    owner_live = bool(owner_pid is not None and process_is_alive(owner_pid))
    # POSIX has a dedicated mount path even before a receipt exists. Windows
    # selects a free drive dynamically; without its receipt the M: display
    # default could belong to another application and is not our authority.
    registry_backed = bool(
        supported and (sys.platform != "win32" or receipt is not None)
    )
    registration = mount_registration_state(mount_point) if registry_backed else None
    mounted = bool(
        supported
        and receipt is not None
        and owner_live
        and registration is True
    )
    detached = bool(
        supported
        and receipt is not None
        and owner_live
        and registration is False
    )
    # A receipt whose owner died while the OS registry proves nothing is mounted
    # at the path is the ordinary "service stopped" shape (the next service
    # start retires it and remounts). Only a dead owner with a still-registered
    # mount needs host-level recovery.
    stopped = bool(
        supported
        and receipt is not None
        and not owner_live
        and registration is False
        and _native_mount_helper_registration_state(mount_point) is False
    )
    orphaned = bool(
        supported and receipt is not None and not owner_live and not stopped
    )
    unowned = bool(
        supported
        and receipt is None
        and not invalid_receipt
        and registration is True
    )
    # The mount process writes its receipt only once the OS registry names
    # the path, so a live runner plus a registered, receipt-less mount is the
    # few seconds of startup, not a mount that needs host-level recovery.
    starting = bool(unowned and _service_runner_is_live(paths))
    unowned = bool(unowned and not starting)
    registry_unavailable = bool(
        registry_backed
        and enabled
        and not orphaned
        and not invalid_receipt
        and registration is None
    )
    receipt_backend = (
        receipt.get("transport_backend") if receipt is not None else None
    )
    transport_backend = (
        receipt_backend
        if isinstance(receipt_backend, str)
        else select_macos_fuse_backend(runtime)
        if runtime is not None
        else None
    )
    fskit = _fskit_volumes_status(paths) if supported and sys.platform == "darwin" else None
    if fskit is not None:
        # The FSKit backend owns per-volume receipts instead of one share.
        # Its owner liveness and OS registration replace the FUSE receipt view.
        mounted = fskit["mounted"]
        detached = fskit["detached"]
        orphaned = fskit["orphaned"]
        stopped = fskit["stopped"]
        unowned = False
        starting = False
        registry_unavailable = fskit["registry_unavailable"]
        invalid_receipt = False
        mount_point = fskit["mount_root"]
        transport_backend = "fskit"
    if not supported:
        state = "platform_not_enabled"
    elif mounted:
        state = "mounted"
    elif detached:
        state = "detached"
    elif orphaned:
        state = "orphaned"
    elif stopped:
        state = "stopped"
    elif starting:
        state = "starting"
    elif unowned:
        state = "unowned"
    elif registry_unavailable:
        state = "registry_unavailable"
    elif invalid_receipt:
        state = "invalid_receipt"
    elif not enabled:
        state = "disabled"
    elif runtime is None:
        state = "runtime_missing"
    else:
        state = "idle"
    return {
        "supported": supported,
        "state": state,
        "mounted": bool(mounted),
        "mount_point": mount_point,
        "backend": "fskit" if fskit is not None else "fuse-t" if supported else None,
        "volumes": fskit["volumes"] if fskit is not None else [],
        "volume_name": "Meshia",
        "runtime": runtime.kind if runtime is not None else None,
        "runtime_library": (
            str(runtime.library_path) if runtime is not None else None
        ),
        "transport_backend": transport_backend,
        # Owner decision 2026-09-03: SMB mirrors xattrs into ``._`` sidecars
        # that the mount discards instead of storing; tooling can read the
        # trade-off here instead of parsing the notice line.
        "appledouble_sidecars": (
            "discarded"
            if transport_backend == "smb" and mount_discards_appledouble_sidecars()
            else "stored"
        ),
        "status_source": (
            "registry_unavailable"
            if registry_unavailable
            else "registry_and_receipt"
            if receipt is not None and registration is not None
            else "receipt_owner"
            if receipt is not None
            else "registry_without_receipt"
            if unowned
            else "invalid_receipt"
            if invalid_receipt
            else "no_receipt"
        ),
        "attention_required": bool(
            detached or orphaned or unowned or registry_unavailable or invalid_receipt
        ),
        "detail": (
            "mount_disconnected"
            if detached
            else "mount_owner_not_live"
            if orphaned
            else "mount_owner_stopped"
            if stopped
            else "mount_registered_without_receipt"
            if unowned
            else "mount_starting"
            if starting
            else "mount_registry_unavailable"
            if registry_unavailable
            else "mount_receipt_invalid"
            if invalid_receipt
            else None
        ),
        "recovery": (
            "Meshia is recreating the native mount"
            if detached
            else "start the Meshia service; it recreates the native mount"
            if stopped
            else "restart macOS before retrying if Finder or unmount is stuck"
            if orphaned and sys.platform == "darwin"
            else "restart the host before retrying if the mount cannot be detached"
            if orphaned
            else "restart macOS before retrying if the unowned mount cannot be detached"
            if unowned and sys.platform == "darwin"
            else "restart the host before retrying if the unowned mount cannot be detached"
            if unowned
            else "retry after the OS mount registry becomes available"
            if registry_unavailable
            else "restart macOS, then repair the private mount receipt before retrying"
            if invalid_receipt and sys.platform == "darwin"
            else "restart the host, then repair the private mount receipt before retrying"
            if invalid_receipt
            else None
        ),
        "install_hint": (
            mount_runtime_help() if supported and enabled and runtime is None else None
        ),
    }


def _native_file_provider_status_document(
    paths: Paths | None = None,
    *,
    enabled: bool = True,
    config: NodeConfig | None = None,
) -> dict[str, Any]:
    """Return bounded File Provider app/domain/bridge health without mutation."""

    if not enabled:
        status = NativeFileProviderStatus(
            supported=sys.platform == "darwin",
            enabled=False,
            ready=False,
            state="native_files_disabled",
        )
    else:
        status = native_file_provider_status()
    eligibility = (
        _file_provider_runtime_eligibility(paths, config)
        if paths is not None and config is not None
        else {
            "eligible": True,
            "reason": "account_scope_unknown",
            "visible_workspace_count": None,
            "account_wide": False,
        }
    )
    bridge_health = file_provider_bridge_health(status.bridge_address)
    if (
        bridge_health.account_wide
        and paths is not None
        and config is not None
    ):
        eligibility = _file_provider_runtime_eligibility(
            paths,
            config,
            account_wide=True,
            account_wide_workspace_count=bridge_health.workspace_count,
        )
    bridge_running = bridge_health.running
    document = status.document(bridge_running=bridge_running)
    document.update(
        {
            "eligible": eligibility["eligible"],
            "eligibility_reason": eligibility["reason"],
            "visible_workspace_count": eligibility["visible_workspace_count"],
            "account_wide": eligibility["account_wide"],
        }
    )
    document["active"] = bool(
        status.ready and eligibility["eligible"] and bridge_running
    )
    document["attention_required"] = bool(
        status.ready
        and eligibility["eligible"]
        and paths is not None
        and bool(_runtime_status_document(paths).get("live"))
        and not bridge_running
    )
    return document


def _file_provider_runtime_eligibility(
    paths: Paths,
    config: NodeConfig,
    *,
    account_wide: bool = False,
    account_wide_workspace_count: int | None = None,
) -> dict[str, Any]:
    """Fail closed before a primary-only bridge can hide account workspaces."""

    if account_wide:
        complete = (
            isinstance(account_wide_workspace_count, int)
            and not isinstance(account_wide_workspace_count, bool)
            and account_wide_workspace_count >= 1
        )
        return {
            "eligible": complete,
            "reason": (
                "bridge_account_wide"
                if complete
                else "account_catalog_not_ready"
            ),
            "visible_workspace_count": account_wide_workspace_count,
            "account_wide": True,
        }
    if config.account_id is None:
        return {
            "eligible": True,
            "reason": "legacy_single_workspace",
            "visible_workspace_count": 1,
            "account_wide": False,
        }
    try:
        snapshot = WorkspaceCatalogStore(
            paths.account_workspace_catalog(config.account_id)
        ).load_readonly()
    except (OSError, MeshiaNodeError):
        return {
            "eligible": False,
            "reason": "catalog_unreadable",
            "visible_workspace_count": None,
            "account_wide": False,
        }
    if snapshot is None:
        return {
            "eligible": False,
            "reason": "catalog_missing",
            "visible_workspace_count": None,
            "account_wide": False,
        }
    count = len(snapshot.workspaces)
    if snapshot.account.id != config.account_id:
        return {
            "eligible": False,
            "reason": "catalog_account_mismatch",
            "visible_workspace_count": count,
            "account_wide": False,
        }
    selected_present = any(
        workspace.session_id == config.session_id
        for workspace in snapshot.workspaces
    )
    if not selected_present:
        return {
            "eligible": False,
            "reason": "selected_workspace_missing",
            "visible_workspace_count": count,
            "account_wide": False,
        }
    return {
        "eligible": count == 1,
        "reason": (
            "catalog_single_workspace"
            if count == 1
            else "catalog_multiple_workspaces"
        ),
        "visible_workspace_count": count,
        "account_wide": False,
    }


def _fskit_volumes_status(paths: Paths) -> dict[str, Any] | None:
    """Summarize the FSKit per-volume receipts without touching any volume."""

    receipts = read_fskit_mount_state(paths.fskit_mount_state_path)
    if receipts is None:
        return None
    owner_pid = receipts.get("owner_pid")
    owner_live = bool(
        isinstance(owner_pid, int)
        and not isinstance(owner_pid, bool)
        and process_is_alive(owner_pid)
    )
    volumes: list[dict[str, Any]] = []
    registered_states: list[bool | None] = []
    for volume_id, entry in sorted(
        receipts.get("volumes", {}).items(), key=lambda item: str(item[1].get("name", "")).casefold()
    ):
        if not isinstance(entry, dict):
            continue
        volume_point = str(entry.get("mount_point", ""))
        registration = mount_registration_state(volume_point) if volume_point else None
        registered_states.append(registration)
        volumes.append(
            {
                "volume_id": volume_id,
                "name": str(entry.get("name", volume_id)),
                "mount_point": volume_point,
                "mounted": bool(owner_live and registration is True),
            }
        )
    any_registered = any(state is True for state in registered_states)
    all_registered = bool(volumes) and all(state is True for state in registered_states)
    registry_unavailable = any(state is None for state in registered_states)
    return {
        "mount_root": str(receipts.get("mount_root") or paths.fabric_mount_dir),
        "volumes": volumes,
        "mounted": bool(owner_live and all_registered),
        "detached": bool(owner_live and volumes and not all_registered and not registry_unavailable),
        "orphaned": bool(not owner_live and any_registered),
        "stopped": bool(not owner_live and not any_registered and not registry_unavailable),
        "registry_unavailable": registry_unavailable,
    }


def _native_mount_helper_registration_state(mount_point: str) -> bool | None:
    """Return whether an exact persistent mount helper names ``mount_point``.

    Only FUSE-T on macOS has a persistent transport helper outside the owning
    Python process. ``None`` means the bounded process registry could not prove
    absence, so receipt retirement must remain fail-closed.
    """

    if sys.platform.startswith("linux") or sys.platform == "win32":
        return False
    if sys.platform != "darwin":
        return None
    try:
        result = subprocess.run(
            ["/bin/ps", "-axo", "pid=,ppid=,command="],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0 or len(result.stdout) > 8 * 1024 * 1024:
        return None
    target = Path(mount_point)
    for line in result.stdout.splitlines():
        fields = line.strip().split(None, 2)
        if len(fields) != 3:
            continue
        try:
            pid = int(fields[0])
            int(fields[1])
        except ValueError:
            continue
        if pid > 1 and _exact_fuse_t_helper_command(fields[2], target):
            return True
    return False


def _retire_disabled_dead_mount_receipt(paths: Paths) -> bool:
    """Retire one proven-dead receipt while the connection lease is held.

    Callers own ``connection.lock``, which prevents another Meshia runner from
    replacing the receipt between the repeated evidence checks and unlink. A
    live/reused owner PID, registered mount, exact helper, invalid receipt, or
    unavailable registry leaves the receipt untouched.
    """

    if sys.platform != "darwin" and not sys.platform.startswith("linux"):
        return False
    receipt = read_mount_state(paths.fabric_mount_state_path)
    if receipt is None:
        return False
    owner_pid = int(receipt["owner_pid"])
    mount_point = str(receipt["mount_point"])

    def proven_absent() -> bool:
        return bool(
            not process_is_alive(owner_pid)
            and mount_registration_state(mount_point) is False
            and _native_mount_helper_registration_state(mount_point) is False
        )

    if not proven_absent():
        return False
    # Re-read the bounded receipt and every external authority immediately
    # before deletion. Invalid or replaced bytes are never adopted or removed.
    if read_mount_state(paths.fabric_mount_state_path) != receipt or not proven_absent():
        return False
    try:
        paths.fabric_mount_state_path.unlink()
    except (FileNotFoundError, OSError):
        return False
    # Make the retirement survive a crash before the disabled service starts.
    # Some filesystems reject directory fsync; the absence is still safe and a
    # later status can conservatively rediscover an old directory entry.
    try:
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
        descriptor = os.open(str(paths.fabric_mount_state_path.parent), flags)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    except OSError:
        pass
    return True


def _retired_quarantine_status_document(workspace: str | None) -> dict[str, Any]:
    if not workspace:
        return {"available": False, "detail": "workspace_unknown"}
    # The retired tree can contain the full 250k-entry workspace bound.
    # Walking it during `status`, `doctor`, or Windows service-stop
    # verification makes a read-only health query scale with user data and can
    # delay shutdown. Runtime owns recovery; diagnostics consume only durable
    # O(1) metadata until that worker publishes an aggregate snapshot.
    return {"available": False, "detail": "runtime_metadata_unavailable"}


class _ReadonlySQLite:
    """Connection owner that also releases an optional private WAL snapshot."""

    def __init__(
        self,
        connection: sqlite3.Connection,
        snapshot: tempfile.TemporaryDirectory[str] | None = None,
    ) -> None:
        self.connection = connection
        self.snapshot = snapshot

    def execute(self, *args: Any, **kwargs: Any) -> sqlite3.Cursor:
        return self.connection.execute(*args, **kwargs)

    def close(self) -> None:
        try:
            self.connection.close()
        finally:
            if self.snapshot is not None:
                self.snapshot.cleanup()


def _open_readonly_sqlite(
    path: Path, *, snapshot_wal: bool = True
) -> _ReadonlySQLite:
    """Open an existing SQLite database without schema repair or file creation."""

    if not path.is_file():
        raise FileNotFoundError(path)
    wal_path = Path(str(path) + "-wal")
    shm_path = Path(str(path) + "-shm")
    snapshot: tempfile.TemporaryDirectory[str] | None = None
    target = path.resolve()
    uri = True
    if snapshot_wal and (wal_path.exists() or shm_path.exists()):
        # A SQLite WAL reader normally updates read marks inside the source
        # `-shm` file. Explicit deep status, doctor, and startup preflight must
        # be byte-for-byte observational, so read a private file snapshot and
        # let SQLite touch only its temporary WAL index. Normal status never
        # enters this path.
        snapshot = tempfile.TemporaryDirectory(prefix="meshia-status-")
        target = Path(snapshot.name) / path.name
        try:
            shutil.copyfile(path, target)
            if wal_path.is_file():
                shutil.copyfile(wal_path, Path(str(target) + "-wal"))
        except BaseException:
            snapshot.cleanup()
            raise
        uri = False
    connection = sqlite3.connect(
        str(target) if not uri else f"{target.as_uri()}?mode=ro",
        uri=uri,
        timeout=0.25,
    )
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only = ON")
    return _ReadonlySQLite(connection, snapshot)


def _scan_account_pending_workspace_journals(
    paths: Paths,
    config: NodeConfig,
    visible_session_ids: frozenset[str],
    *,
    installation_id: str,
    limit: int,
) -> StartupRecoveryScan:
    """Find exact-account journals that need a lazy runtime after restart."""

    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
        raise ValueError("limit must be a positive integer")
    if config.account_id is None:
        return StartupRecoveryScan()
    with file_lock(paths.workspace_state_locations_lock):
        legacy = _load_workspace_state_locations_unlocked(paths)
    legacy_session_id = (
        legacy["session_id"]
        if legacy is not None and legacy["account_id"] == config.account_id
        else None
    )

    probes = 0
    unavailable = 0
    pending: list[str] = []
    saturated = False
    deadline = time.monotonic() + STARTUP_RECOVERY_SCAN_SECONDS
    for session_id in sorted(visible_session_ids):
        if session_id == config.session_id:
            # The primary runtime is already active before this scan.
            continue
        if time.monotonic() >= deadline:
            saturated = True
            break
        try:
            state = (
                _catalog_workspace_state(
                    paths,
                    account_id=config.account_id,
                    session_id=session_id,
                    installation_id=installation_id,
                )
                if session_id == legacy_session_id
                else paths.account_workspace_state(config.account_id, session_id)
            )
            root_info = state.root.lstat()
            database_info = state.database.lstat()
        except FileNotFoundError:
            continue
        except (OSError, StateError):
            unavailable += 1
            continue
        if (
            not stat.S_ISDIR(root_info.st_mode)
            or not stat.S_ISREG(database_info.st_mode)
            or (os.name != "nt" and stat.S_IMODE(root_info.st_mode) & 0o077)
            or (os.name != "nt" and database_info.st_nlink != 1)
            or (os.name != "nt" and stat.S_IMODE(database_info.st_mode) & 0o077)
        ):
            unavailable += 1
            continue
        probes += 1
        if probes > STARTUP_RECOVERY_DATABASE_SCAN_LIMIT:
            saturated = True
            break
        try:
            if not _journal_has_owned_startup_work(
                state,
                host_id=config.host_id,
                session_id=session_id,
                host_generation=config.generation,
                installation_id=installation_id,
            ):
                continue
            if len(pending) >= limit:
                saturated = True
                break
            pending.append(session_id)
        except (OSError, sqlite3.Error, StateError, ValueError):
            unavailable += 1
    return StartupRecoveryScan(
        session_ids=tuple(pending),
        unavailable_workspace_count=unavailable,
        saturated=saturated,
    )


def _journal_has_owned_startup_work(
    state: WorkspaceStatePaths,
    *,
    host_id: str,
    session_id: str,
    host_generation: int,
    installation_id: str,
) -> bool:
    """Probe one dormant journal through indexed active-scope lookups."""

    # Startup owns dormant journals, so the read-only connection may consume
    # the existing WAL directly instead of copying an arbitrarily large DB.
    connection = _open_readonly_sqlite(state.database, snapshot_wal=False)
    try:
        tables = {
            str(row[0])
            for row in connection.execute(
                """SELECT name FROM sqlite_master WHERE type = 'table'
                   AND name IN (
                     'authority_scopes', 'local_transfer_intents',
                     'pending_operations'
                   )"""
            )
        }
        if "authority_scopes" not in tables:
            return False
        authority_columns = {
            str(row[1])
            for row in connection.execute("PRAGMA table_info(authority_scopes)")
        }
        required_authority = {
            "scope_id", "host_id", "session_id", "host_generation",
            "workspace_root", "active",
        }
        if not required_authority.issubset(authority_columns):
            raise StateError("The dormant journal authority schema is incomplete.")
        adoption = (
            "adoption_required" if "adoption_required" in authority_columns else "0"
        )
        workspace_id = "workspace_id" if "workspace_id" in authority_columns else "NULL"
        authorities = connection.execute(
            f"""SELECT scope_id, host_id, session_id, host_generation,
                       workspace_root, {workspace_id} AS workspace_id,
                       {adoption} AS adoption_required
                FROM authority_scopes WHERE active = 1 LIMIT 2"""
        ).fetchall()
        if not authorities:
            return False
        if len(authorities) != 1:
            raise StateError("The dormant journal has ambiguous active authority.")
        authority = authorities[0]
        scope_id = int(authority["scope_id"])
        has_transfer = False
        if "local_transfer_intents" in tables:
            transfer_columns = {
                str(row[1])
                for row in connection.execute(
                    "PRAGMA table_info(local_transfer_intents)"
                )
            }
            issue_filter = (
                " AND issue_code IS NULL" if "issue_code" in transfer_columns else ""
            )
            has_transfer = connection.execute(
                "SELECT 1 FROM local_transfer_intents WHERE scope_id = ?"
                f"{issue_filter} LIMIT 1",
                (scope_id,),
            ).fetchone() is not None
        has_operation = False
        if "pending_operations" in tables:
            operation_columns = {
                str(row[1])
                for row in connection.execute("PRAGMA table_info(pending_operations)")
            }
            commit_unknown = (
                " OR commit_unknown = 1"
                if "commit_unknown" in operation_columns
                else ""
            )
            has_operation = connection.execute(
                "SELECT 1 FROM pending_operations WHERE scope_id = ? AND ("
                "state IN ('queued', 'inflight', 'retry')"
                f"{commit_unknown}) LIMIT 1",
                (scope_id,),
            ).fetchone() is not None
        if not has_transfer and not has_operation:
            return False
        root_status = workspace_root_claim_status(
            state.workspace,
            installation_id=installation_id,
            host_id=host_id,
            session_id=session_id,
            require_bound=True,
        )
        claim = root_status.claim
        if root_status.state != "bound" or claim is None:
            raise StateError("The dormant journal root marker is not current.")
        if (
            authority["host_id"] != host_id
            or authority["session_id"] != session_id
            or int(authority["host_generation"]) != host_generation
            or authority["workspace_root"] != claim.canonical_root
            or (
                authority["workspace_id"] is not None
                and authority["workspace_id"] != claim.workspace_id
            )
            or bool(authority["adoption_required"])
        ):
            raise StateError("The dormant journal has pending work under stale authority.")
        return True
    finally:
        connection.close()


def _preflight_authoritative_journal(path: Path) -> None:
    """Fail closed on unreadable/corrupt state without migrating or repairing it."""

    if not path.exists():
        return
    try:
        connection = _open_readonly_sqlite(path)
        try:
            checked = connection.execute("PRAGMA quick_check(1)").fetchone()
            if checked is None or str(checked[0]).lower() != "ok":
                raise sqlite3.DatabaseError("Fabric journal quick-check failed")
        finally:
            connection.close()
    except (OSError, sqlite3.Error, ValueError) as error:
        state, _detail = _authoritative_state_error(error)
        raise AuthoritativeStateUnavailable(state) from None


def _allocated_bytes(path: Path) -> int:
    try:
        info = path.stat()
    except OSError:
        return 0
    blocks = getattr(info, "st_blocks", None)
    return int(blocks) * 512 if isinstance(blocks, int) else int(info.st_size)


def _readonly_cache_status(state: WorkspaceStatePaths) -> dict[str, Any]:
    database_path = state.cache / "ranges.sqlite3"
    if not database_path.is_file():
        return {"available": False}
    connection = _open_readonly_sqlite(database_path)
    try:
        content_count, content_bytes, content_disk_bytes = connection.execute(
            "SELECT COUNT(*), COALESCE(SUM(size_bytes), 0), "
            "COALESCE(SUM(disk_bytes), 0) FROM contents"
        ).fetchone()
        range_count = int(connection.execute("SELECT COUNT(*) FROM ranges").fetchone()[0])
        now_ns = time.time_ns()
        pinned_count, dirty_count = connection.execute(
            "SELECT COUNT(*), COALESCE(SUM(dirty), 0) "
            "FROM owners WHERE expires_ns > ?",
            (now_ns,),
        ).fetchone()
    finally:
        connection.close()
    metadata_bytes = _allocated_bytes(database_path)
    sidecar_bytes = sum(
        _allocated_bytes(candidate)
        for candidate in (
            Path(str(database_path) + "-wal"),
            Path(str(database_path) + "-shm"),
            state.cache / "cache.lock",
        )
    )
    disk_bytes = int(content_disk_bytes) + metadata_bytes + sidecar_bytes
    over_capacity = bool(
        int(content_bytes) > DEFAULT_MAX_CACHE_BYTES
        or metadata_bytes > DEFAULT_MAX_METADATA_BYTES
        or disk_bytes > _DEFAULT_CACHE_DISK_BYTES
        or range_count > DEFAULT_MAX_RANGE_RECORDS
    )
    return {
        "available": True,
        "max_bytes": DEFAULT_MAX_CACHE_BYTES,
        "max_disk_bytes": _DEFAULT_CACHE_DISK_BYTES,
        "max_metadata_bytes": DEFAULT_MAX_METADATA_BYTES,
        "max_range_records": DEFAULT_MAX_RANGE_RECORDS,
        "content_bytes": int(content_bytes),
        "content_disk_bytes": int(content_disk_bytes),
        "metadata_bytes": metadata_bytes,
        "disk_bytes": disk_bytes,
        "content_count": int(content_count),
        "range_count": range_count,
        "pinned_owner_count": int(pinned_count),
        "dirty_owner_count": int(dirty_count),
        "over_capacity": over_capacity,
    }


def _readonly_staging_status(state: WorkspaceStatePaths) -> dict[str, Any]:
    path = state.staging / "admission.sqlite3"
    if not path.is_file():
        return {"available": False}
    connection = _open_readonly_sqlite(path)
    try:
        row = connection.execute(
            "SELECT reserved_bytes, reservation_count, max_bytes, max_entries, "
            "repair_phase FROM staging_meta WHERE singleton = 1"
        ).fetchone()
    finally:
        connection.close()
    if row is None:
        raise sqlite3.DatabaseError("staging metadata is missing")
    reserved_bytes = int(row["reserved_bytes"])
    reservation_count = int(row["reservation_count"])
    max_bytes = int(row["max_bytes"])
    max_entries = int(row["max_entries"])
    phase = str(row["repair_phase"])
    return {
        "available": True,
        "reserved_bytes": reserved_bytes,
        "reservation_count": reservation_count,
        "max_bytes": max_bytes,
        "max_entries": max_entries,
        "repair_required": phase != "ready",
        "repair_phase": phase[:32],
        "over_capacity": reserved_bytes > max_bytes or reservation_count > max_entries,
    }


def _readonly_fabric_database_status(
    state: WorkspaceStatePaths,
) -> dict[str, Any]:
    connection = _open_readonly_sqlite(state.database)
    try:
        quick_check = connection.execute("PRAGMA quick_check(1)").fetchone()
        if quick_check is None or str(quick_check[0]).lower() != "ok":
            raise sqlite3.DatabaseError("Fabric journal quick-check failed")
        scope = connection.execute(
            "SELECT scope_id FROM authority_scopes WHERE active = 1"
        ).fetchone()
        if scope is None:
            raise sqlite3.DatabaseError("active Fabric authority is missing")
        scope_id = int(scope["scope_id"])
        head = connection.execute(
            "SELECT generation FROM remote_manifest_heads WHERE scope_id = ?",
            (scope_id,),
        ).fetchone()
        remote = connection.execute(
            "SELECT COUNT(*) AS count, COALESCE(SUM(size_bytes), 0) AS bytes "
            "FROM remote_entries WHERE scope_id = ?",
            (scope_id,),
        ).fetchone()
        local = connection.execute(
            "SELECT COUNT(*) AS count, COALESCE(SUM(bytes_on_disk), 0) AS bytes, "
            "COALESCE(SUM(state = 'dirty'), 0) AS dirty, "
            "COALESCE(SUM(pinned), 0) AS pinned "
            "FROM materialized_entries WHERE scope_id = ?",
            (scope_id,),
        ).fetchone()
        operation_rows = connection.execute(
            "SELECT state, COUNT(*) AS count FROM pending_operations "
            "WHERE scope_id = ? GROUP BY state",
            (scope_id,),
        ).fetchall()
        operations = {str(row["state"]): int(row["count"]) for row in operation_rows}
        unresolved = int(
            connection.execute(
                "SELECT COUNT(*) FROM conflicts "
                "WHERE scope_id = ? AND resolved_at_ns IS NULL",
                (scope_id,),
            ).fetchone()[0]
        )
        commit_unknown = int(
            connection.execute(
                "SELECT COUNT(*) FROM pending_operations "
                "WHERE scope_id = ? AND commit_unknown = 1",
                (scope_id,),
            ).fetchone()[0]
        )
        oldest_unknown = connection.execute(
            "SELECT MIN(updated_at_ns) FROM pending_operations "
            "WHERE scope_id = ? AND commit_unknown = 1",
            (scope_id,),
        ).fetchone()[0]
        last = connection.execute(
            "SELECT mutation_id, state, last_error FROM pending_operations "
            "WHERE scope_id = ? AND last_error IS NOT NULL "
            "ORDER BY updated_at_ns DESC, mutation_id DESC LIMIT 1",
            (scope_id,),
        ).fetchone()
        quarantined = int(
            connection.execute(
                "SELECT COUNT(*) FROM pending_operations WHERE state = 'quarantined'"
            ).fetchone()[0]
        )
        local_transfer_columns = {
            str(row["name"])
            for row in connection.execute(
                "PRAGMA table_info(local_transfer_intents)"
            ).fetchall()
        }
        if {"issue_code", "issue_size_bytes"}.issubset(local_transfer_columns):
            issue_rows = connection.execute(
                """SELECT path, issue_code, issue_size_bytes
                   FROM local_transfer_intents
                   WHERE scope_id = ? AND issue_code IS NOT NULL
                   ORDER BY created_at_ns, transfer_id LIMIT 5""",
                (scope_id,),
            ).fetchall()
        else:
            issue_rows = []
    finally:
        connection.close()
    pending = sum(operations.get(state, 0) for state in ("queued", "inflight", "retry"))
    return {
        "manifest_generation": int(head["generation"]) if head else None,
        "remote_entries": int(remote["count"]),
        "remote_bytes": int(remote["bytes"]),
        "materialized_entries": int(local["count"]),
        "materialized_bytes": int(local["bytes"]),
        "dirty_entries": int(local["dirty"]),
        "pinned_entries": int(local["pinned"]),
        "pending_operations": pending,
        "commit_unknown_operations": commit_unknown,
        "oldest_commit_unknown_age_seconds": (
            round(max(0, time.time_ns() - int(oldest_unknown)) / 1_000_000_000, 3)
            if oldest_unknown is not None
            else None
        ),
        "unresolved_conflicts": unresolved,
        "quarantined_operations": quarantined,
        "local_file_issues": {
            "sample": [
                {
                    "code": str(row["issue_code"])[:64],
                    "path": str(row["path"])[:STATUS_ERROR_MAX_CHARS],
                    "size_bytes": int(row["issue_size_bytes"] or 0),
                    "remediation": LOCAL_FILE_UNSUPPORTED_REMEDIATION,
                }
                for row in issue_rows[:4]
            ],
            "saturated": len(issue_rows) > 4,
        },
        "last_operation_error": (
            {
                "mutation_id": str(last["mutation_id"])[:64],
                "state": str(last["state"])[:32],
                "detail": str(last["last_error"])[:STATUS_ERROR_MAX_CHARS],
            }
            if last is not None
            else None
        ),
    }


def _authoritative_state_error(error: BaseException) -> tuple[str, str]:
    detail = str(error).lower()
    corrupt_markers = (
        "malformed",
        "not a database",
        "database disk image is malformed",
        "quick-check failed",
        "file is encrypted",
        "sqlite_corrupt",
    )
    state = (
        "journal_corrupt"
        if any(marker in detail for marker in corrupt_markers)
        else "authoritative_state_unreadable"
    )
    return state, type(error).__name__


def _bounded_fabric_journal_status(path: Path) -> dict[str, Any]:
    """Inspect fixed-size journal metadata without opening SQLite or its WAL."""

    try:
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode):
            raise OSError("Fabric journal is not a regular file")
        with path.open("rb", buffering=0) as stream:
            header = stream.read(16)
    except FileNotFoundError:
        return {"available": False, "journal_state": "absent"}
    except OSError as error:
        return {
            "available": False,
            "journal_state": "authoritative_state_unreadable",
            "detail": type(error).__name__,
        }
    if header != b"SQLite format 3\x00":
        return {
            "available": False,
            "journal_state": "journal_corrupt",
            "detail": "invalid_sqlite_header",
        }
    return {
        "available": True,
        # A bounded status query can prove the file's identity, not integrity.
        # Doctor/`status --deep` owns quick_check and aggregate table reads.
        "journal_state": "present_unverified",
        "journal_bytes": int(info.st_size),
        "wal_bytes": _allocated_bytes(Path(str(path) + "-wal")),
        "shm_bytes": _allocated_bytes(Path(str(path) + "-shm")),
    }


def _fabric_status_document(
    paths: Paths,
    workspace: str | None = None,
    *,
    deep: bool = False,
    workspace_state: WorkspaceStatePaths | None = None,
) -> dict[str, Any]:
    selected_state = workspace_state or paths.legacy_workspace_state
    quarantine = _retired_quarantine_status_document(workspace)
    runtime = _runtime_status_document(paths)
    runtime_live = bool(runtime.get("live"))
    readiness = {
        "runtime_ready": bool(runtime_live and runtime.get("runtime_ready") is True),
        "runtime_readiness_reason": (
            runtime.get("runtime_readiness_reason")
            if runtime_live
            else "runner_not_live"
        ),
        "command_safe": bool(runtime_live and runtime.get("command_safe") is True),
        "command_safety_reason": (
            runtime.get("command_safety_reason")
            if runtime_live
            else "runner_not_live"
        ),
        "sync_converged": bool(
            runtime_live and runtime.get("sync_converged") is True
        ),
        "sync_convergence_reason": (
            runtime.get("sync_convergence_reason")
            if runtime_live
            else "runner_not_live"
        ),
        "fabric_ready": bool(runtime_live and runtime.get("fabric_ready") is True),
        "fabric_readiness_reason": (
            runtime.get("fabric_readiness_reason")
            if runtime_live
            else "runner_not_live"
        ),
        "fabric_head_generation": (
            runtime.get("fabric_head_generation") if runtime_live else None
        ),
        "watcher": (
            runtime.get("watcher", {"available": False})
            if runtime_live
            else {"available": False, "detail": "runner_not_live"}
        ),
        "local_file_issues": (
            runtime.get("local_file_issues", {"sample": [], "saturated": False})
            if runtime_live
            else {"sample": [], "saturated": False}
        ),
        "last_error": runtime.get("last_error") if runtime_live else None,
        "degraded_operations": (
            runtime.get("degraded_operations", []) if runtime_live else []
        ),
    }
    bounded_journal = _bounded_fabric_journal_status(selected_state.database)
    journal_state = str(bounded_journal["journal_state"])
    if journal_state == "absent":
        return {
            "available": False,
            "journal_state": "absent",
            "status_mode": "deep" if deep else "bounded",
            **readiness,
            "command_safe": False,
            "command_safety_reason": "journal_absent",
            "sync_converged": False,
            "sync_convergence_reason": "journal_absent",
            "fabric_ready": False,
            "fabric_readiness_reason": "journal_absent",
            "retired_quarantine": quarantine,
            "staging": {"available": False},
            "cache": {"available": False},
        }
    if not deep:
        journal_safe = journal_state == "present_unverified"
        runtime_staging = (
            runtime.get("staging")
            if runtime_live and isinstance(runtime.get("staging"), dict)
            else {
                "available": False,
                "detail": "runtime_metadata_unavailable",
            }
        )
        return {
            **bounded_journal,
            "status_mode": "bounded",
            **readiness,
            "command_safe": bool(journal_safe and readiness["command_safe"]),
            "command_safety_reason": (
                readiness["command_safety_reason"] if journal_safe else journal_state
            ),
            "sync_converged": bool(journal_safe and readiness["sync_converged"]),
            "sync_convergence_reason": (
                readiness["sync_convergence_reason"] if journal_safe else journal_state
            ),
            "fabric_ready": bool(journal_safe and readiness["fabric_ready"]),
            "fabric_readiness_reason": (
                readiness["fabric_readiness_reason"] if journal_safe else journal_state
            ),
            "retired_quarantine": quarantine,
            "staging": runtime_staging,
            "cache": {
                "available": False,
                "detail": "deep_diagnostics_required",
            },
        }
    try:
        status = _readonly_fabric_database_status(selected_state)
    except (OSError, sqlite3.Error, ValueError) as error:
        state, detail = _authoritative_state_error(error)
        # Status must remain usable when a prior process crashed mid-migration
        # or the journal belongs to an old, not-yet-bound authority.
        return {
            "available": False,
            "journal_state": state,
            "status_mode": "deep",
            **readiness,
            "command_safe": False,
            "command_safety_reason": state,
            "sync_converged": False,
            "sync_convergence_reason": state,
            "fabric_ready": False,
            "fabric_readiness_reason": state,
            "detail": detail,
            "retired_quarantine": quarantine,
            "staging": {"available": False},
            "cache": {"available": False},
        }
    try:
        cache = _readonly_cache_status(selected_state)
    except (OSError, sqlite3.Error, ValueError) as error:
        cache = {
            "available": False,
            "state": "disposable_cache_unreadable",
            "detail": type(error).__name__,
        }
    try:
        staging = _readonly_staging_status(selected_state)
    except (OSError, sqlite3.Error, ValueError) as error:
        staging = {
            "available": False,
            "state": "authoritative_state_unreadable",
            "blocked": True,
            "detail": type(error).__name__,
        }
    if staging.get("available"):
        staging["blocked"] = bool(
            staging.get("repair_required") or staging.get("over_capacity")
        )
    return {
        "available": True,
        "journal_state": "healthy",
        "status_mode": "deep",
        **readiness,
        **status,
        "retired_quarantine": quarantine,
        "staging": staging,
        "cache": cache,
    }


_VISIBLE_WORKSPACE_HEALTH_COUNTS = (
    "pending_operations",
    "commit_unknown_operations",
    "dirty_entries",
    "unresolved_conflicts",
)


def _workspace_journal_sync_state(
    document: dict[str, Any],
    *,
    selected: bool,
) -> tuple[bool, str]:
    """Project one journal into namespace convergence without starting a runtime."""

    journal_state = str(document.get("journal_state") or "authoritative_state_unreadable")
    if journal_state == "absent" and not selected:
        # A catalog-only workspace has no local bytes or mutation journal to
        # reconcile. Its namespace remains lazily backed by remote authority.
        return True, "no_local_journal"
    if journal_state != "healthy":
        return False, journal_state
    for field, reason in (
        ("commit_unknown_operations", "commit_unknown"),
        ("unresolved_conflicts", "unresolved_conflicts"),
        ("pending_operations", "pending_operations"),
        ("dirty_entries", "dirty_entries"),
    ):
        value = document.get(field)
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            return False, "journal_health_unknown"
        if value:
            return False, reason
    local_issues = document.get("local_file_issues")
    if isinstance(local_issues, dict) and local_issues.get("sample"):
        return False, "local_file_issues"
    if selected and document.get("sync_converged") is not True:
        return False, str(document.get("sync_convergence_reason") or "runtime_not_converged")
    return True, "converged"


def _visible_workspace_summary(
    *,
    session_id: str,
    label: str,
    selected: bool,
    document: dict[str, Any],
) -> dict[str, Any]:
    converged, reason = _workspace_journal_sync_state(document, selected=selected)
    summary: dict[str, Any] = {
        "session_id": session_id,
        "label": label,
        "selected": selected,
        "available": document.get("available") is True,
        "journal_state": str(
            document.get("journal_state") or "authoritative_state_unreadable"
        ),
        "sync_converged": converged,
        "sync_convergence_reason": reason,
    }
    for field in (
        "manifest_generation",
        "remote_entries",
        "remote_bytes",
        "materialized_entries",
        "materialized_bytes",
        "dirty_entries",
        "pending_operations",
        "commit_unknown_operations",
        "oldest_commit_unknown_age_seconds",
        "unresolved_conflicts",
        "quarantined_operations",
        "local_file_issues",
        "last_operation_error",
        "detail",
    ):
        if field in document:
            summary[field] = document[field]
    return summary


def _aggregate_visible_workspace_fabric_status(
    paths: Paths,
    config: NodeConfig,
    selected_fabric: dict[str, Any],
    remote_quota: dict[str, Any],
) -> dict[str, Any]:
    """Fail closed over every catalog-visible workspace's bounded local state.

    The authenticated catalog already caps the namespace at 10,000 entries.
    Every entry receives a detail row, but explicit deep SQLite inspection is
    additionally capped by count and wall time. Any deferred or unreadable
    journal is reported as unknown and can never produce an "up to date" result.
    """

    catalog_state = str(remote_quota.get("state") or "catalog_unavailable")
    raw_workspaces = remote_quota.get("workspaces")
    if remote_quota.get("available") is not True or not isinstance(raw_workspaces, list):
        workspace_health = {
            "available": False,
            "scope": "visible_catalog",
            "source": "cached_authenticated_catalog",
            "catalog_state": catalog_state,
            "workspace_count": 0,
            "local_journal_count": 0,
            "inspected_journal_count": 0,
            "scan_saturated": False,
            "aggregate": None,
            "workspaces": [],
        }
        return {
            **selected_fabric,
            "sync_converged": False,
            "sync_convergence_reason": f"visible_workspace_{catalog_state}",
            "sync_scope": "visible_catalog",
            "workspace_health": workspace_health,
        }

    try:
        legacy_binding = _load_workspace_state_locations_unlocked(paths)
    except (OSError, MeshiaNodeError, ValueError) as error:
        state = "authoritative_state_unreadable"
        workspace_health = {
            "available": False,
            "scope": "visible_catalog",
            "source": "cached_authenticated_catalog",
            "catalog_state": catalog_state,
            "workspace_count": len(raw_workspaces),
            "local_journal_count": 0,
            "inspected_journal_count": 0,
            "scan_saturated": False,
            "aggregate": None,
            "workspaces": [],
            "detail": type(error).__name__,
        }
        return {
            **selected_fabric,
            "sync_converged": False,
            "sync_convergence_reason": f"visible_workspace_{state}",
            "sync_scope": "visible_catalog",
            "workspace_health": workspace_health,
        }

    local_journal_count = 0
    inspected_journal_count = 0
    scan_saturated = False
    summaries: list[dict[str, Any]] = []
    totals = {field: 0 for field in _VISIBLE_WORKSPACE_HEALTH_COUNTS}
    deadline = time.monotonic() + STATUS_VISIBLE_WORKSPACE_SCAN_SECONDS

    for raw_workspace in raw_workspaces:
        if not isinstance(raw_workspace, dict):
            scan_saturated = True
            continue
        session_id = raw_workspace.get("session_id")
        label = raw_workspace.get("label")
        if not isinstance(session_id, str) or not isinstance(label, str):
            scan_saturated = True
            continue
        selected = session_id == config.session_id

        if selected:
            if selected_fabric.get("journal_state") != "absent":
                local_journal_count += 1
                inspected_journal_count += 1
            document = selected_fabric
        else:
            try:
                if legacy_binding is not None and legacy_binding["session_id"] == session_id:
                    if config.installation_id is None:
                        raise WorkspaceClaimInvalid(
                            "The retained workspace state is missing its installation identity."
                        )
                    state = _catalog_workspace_state_from_binding(
                        paths,
                        account_id=str(config.account_id),
                        session_id=session_id,
                        installation_id=config.installation_id,
                        legacy_binding=legacy_binding,
                    )
                else:
                    state = paths.account_workspace_state(str(config.account_id), session_id)
                bounded = _bounded_fabric_journal_status(state.database)
            except (OSError, MeshiaNodeError, ValueError) as error:
                document = {
                    "available": False,
                    "journal_state": "authoritative_state_unreadable",
                    "detail": type(error).__name__,
                }
            else:
                journal_state = str(bounded.get("journal_state"))
                if journal_state == "absent":
                    document = bounded
                elif journal_state != "present_unverified":
                    local_journal_count += 1
                    document = bounded
                elif (
                    inspected_journal_count >= STATUS_VISIBLE_WORKSPACE_SCAN_LIMIT
                    or time.monotonic() >= deadline
                ):
                    local_journal_count += 1
                    scan_saturated = True
                    document = {
                        **bounded,
                        "available": False,
                        "journal_state": "deep_scan_deferred",
                        "detail": "bounded_workspace_scan",
                    }
                else:
                    local_journal_count += 1
                    inspected_journal_count += 1
                    try:
                        document = {
                            "available": True,
                            "journal_state": "healthy",
                            **_readonly_fabric_database_status(state),
                        }
                    except (OSError, sqlite3.Error, ValueError) as error:
                        journal_state, detail = _authoritative_state_error(error)
                        document = {
                            "available": False,
                            "journal_state": journal_state,
                            "detail": detail,
                        }

        summary = _visible_workspace_summary(
            session_id=session_id,
            label=label,
            selected=selected,
            document=document,
        )
        for field in _VISIBLE_WORKSPACE_HEALTH_COUNTS:
            value = summary.get(field)
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                totals[field] += value
        summaries.append(summary)

    complete = bool(
        len(summaries) == len(raw_workspaces)
        and not scan_saturated
        and all(
            summary.get("journal_state") in ("healthy", "absent")
            for summary in summaries
        )
    )
    all_converged = complete and all(
        summary.get("sync_converged") is True for summary in summaries
    )
    known_unhealthy = next(
        (
            summary
            for summary in summaries
            if summary.get("sync_converged") is not True
            and summary.get("sync_convergence_reason") != "deep_scan_deferred"
        ),
        None,
    )
    aggregate_reason = "converged"
    if len(summaries) != len(raw_workspaces):
        aggregate_reason = "catalog_projection_invalid"
    elif known_unhealthy is not None:
        aggregate_reason = str(known_unhealthy["sync_convergence_reason"])
    elif scan_saturated:
        aggregate_reason = "deep_scan_deferred"
    elif not all_converged:
        first_unhealthy = next(
            summary for summary in summaries if summary.get("sync_converged") is not True
        )
        aggregate_reason = str(first_unhealthy["sync_convergence_reason"])

    workspace_health = {
        "available": complete,
        "scope": "visible_catalog",
        "source": "cached_authenticated_catalog",
        "catalog_state": catalog_state,
        "workspace_count": len(raw_workspaces),
        "local_journal_count": local_journal_count,
        "inspected_journal_count": inspected_journal_count,
        "scan_saturated": scan_saturated,
        "aggregate": {**totals, "complete": complete},
        "sync_converged": all_converged,
        "sync_convergence_reason": aggregate_reason,
        "workspaces": summaries,
    }
    if selected_fabric.get("sync_converged") is True and not all_converged:
        selected_fabric = {
            **selected_fabric,
            "sync_converged": False,
            "sync_convergence_reason": f"visible_workspace_{aggregate_reason}",
        }
    return {
        **selected_fabric,
        "sync_scope": "visible_catalog",
        "workspace_health": workspace_health,
    }


def _disable_service_if_owned(paths: Paths) -> bool:
    """Disable only the service definition that targets this exact state home."""
    try:
        controller = _service_controller(paths)
        if not _definition_belongs_to_home(controller, paths):
            return False
        controller.uninstall()
        return True
    except MountHeldError:
        # The runner was deliberately left running under its attached mount.
        # This is the one service failure the user must see verbatim.
        raise
    except (OSError, ServiceError):
        # Sticky lifecycle fencing remains authoritative even when the manager
        # is unavailable; the caller still waits for the connection lease.
        return False


def _status_document(
    store: ConfigStore,
    *,
    deep_fabric: bool = False,
) -> dict[str, Any]:
    try:
        config = _read_config_for_status(store.paths)
    except OSError as error:
        return {
            "enrolled": None,
            "state": "authoritative_state_unreadable",
            "attention_required": True,
            "detail": type(error).__name__,
            "home": str(store.paths.home),
            "workspace_claim": {
                "available": False,
                "state": "config_unreadable",
                "valid": False,
            },
            "remote_quota": _remote_quota_unavailable("config_unreadable"),
            "service": _service_status_document(store.paths),
            "file_provider": _native_file_provider_status_document(store.paths),
            "mount": _fabric_mount_status_document(store.paths),
            "fabric": _fabric_status_document(store.paths, deep=deep_fabric),
        }
    if config is None:
        return {
            "enrolled": False,
            "home": str(store.paths.home),
            "workspace_claim": _workspace_claim_status_document(None),
            "remote_quota": _remote_quota_unavailable("not_enrolled"),
            "service": _service_status_document(store.paths),
            "file_provider": _native_file_provider_status_document(store.paths),
            "mount": _fabric_mount_status_document(store.paths),
            "fabric": _fabric_status_document(store.paths, deep=deep_fabric),
        }
    remote_quota = _remote_quota_status_document(config, store.paths)
    file_provider = _native_file_provider_status_document(
        store.paths, enabled=config.native_mount_enabled, config=config
    )
    selected_state = _configured_workspace_state(store.paths, config)
    fabric = _fabric_status_document(
        store.paths,
        workspace=config.workspace,
        deep=deep_fabric,
        workspace_state=selected_state,
    )
    if deep_fabric:
        if (
            config.native_mount_enabled
            and config.account_id is not None
            and (
                not file_provider.get("active")
                or file_provider.get("account_wide") is True
            )
        ):
            fabric = _aggregate_visible_workspace_fabric_status(
                store.paths,
                config,
                fabric,
                remote_quota,
            )
        else:
            # With no native mount there is no account-wide projected
            # namespace. The explicitly enrolled workspace remains the sole
            # sync authority, even when modern enrollment supplied an account
            # id but no catalog cache was ever needed.
            fabric = {**fabric, "sync_scope": "selected_explicit"}
    return {
        "enrolled": True,
        "host_id": config.host_id,
        "generation": config.generation,
        "session_id": config.session_id,
        "attachment_id": config.attachment_id,
        "lifecycle": config.lifecycle,
        "disconnect_reason": config.disconnect_reason,
        "tier": config.tier,
        "access": config.access,
        "api_url": config.api_url,
        "deployment_audience": config.deployment_audience,
        "workspace": config.workspace,
        "workspace_id": config.workspace_id,
        "workspace_name": config.workspace_name,
        "account_id": config.account_id,
        "account_email": config.account_email,
        "installation_id": config.installation_id,
        "workspace_adoption_pending": config.workspace_adoption_pending,
        "native_mount_enabled": config.native_mount_enabled,
        "mount_backend": config.mount_backend,
        "workspace_claim": _workspace_claim_status_document(config),
        "remote_quota": remote_quota,
        "display_name": config.display_name,
        "enrolled_at": config.enrolled_at,
        "last_heartbeat_at": config.last_heartbeat_at,
        "next_sequence": config.next_sequence,
        "pid": config.pid,
        "service": _service_status_document(store.paths),
        "file_provider": file_provider,
        "mount": _fabric_mount_status_document(
            store.paths, enabled=config.native_mount_enabled
        ),
        "object_edge": read_object_edge_status(store.paths.home),
        "fabric": fabric,
        "push": _push_status_document(store.paths),
    }


def _push_status_document(paths: Paths) -> dict[str, Any]:
    """Project the daemon's push-stream file; never opens a network client."""

    document = read_push_status(paths.push_status_path)
    runtime = _runtime_status_document(paths)
    if not runtime.get("live") or (
        document.get("pid") is not None and document.get("pid") != runtime.get("pid")
    ):
        return {**document, "state": "polling", "connected": False, "last_frame_age_seconds": None}
    return document


def _remote_quota_unavailable(state: str, *, detail: str | None = None) -> dict[str, Any]:
    document: dict[str, Any] = {
        "available": False,
        "state": state,
        "scope": "remote_quota",
        "source": "cached_authenticated_catalog",
        "catalog_generation": None,
        "cache_file_age_seconds": None,
        "workspace_count": 0,
        "capacity_reported_workspace_count": 0,
        "capacity_state": "unavailable",
        "aggregate": {
            "safe_integer": None,
            "used_bytes": None,
            "quota_bytes": None,
            "remaining_bytes": None,
        },
        "workspaces": [],
    }
    if detail is not None:
        document["detail"] = detail
    return document


def _remote_quota_status_document(
    config: NodeConfig,
    paths: Paths,
) -> dict[str, Any]:
    """Project remote quotas from the last authenticated catalog only.

    ``status`` must stay useful when the network, mount, or workspace runtime
    is unhealthy.  It therefore reads the bounded atomic catalog snapshot and
    never constructs a signed client or activates a workspace runtime.
    """

    if config.account_id is None:
        return _remote_quota_unavailable("account_catalog_unavailable")
    catalog_path = paths.account_workspace_catalog(config.account_id)
    try:
        metadata = catalog_path.stat(follow_symlinks=False)
        if not stat.S_ISREG(metadata.st_mode):
            return _remote_quota_unavailable("catalog_unreadable", detail="not_regular")
        snapshot = WorkspaceCatalogStore(catalog_path).load_readonly()
    except (OSError, MeshiaNodeError) as error:
        state = "catalog_missing" if isinstance(error, FileNotFoundError) else "catalog_unreadable"
        return _remote_quota_unavailable(state, detail=type(error).__name__)
    if snapshot is None:
        return _remote_quota_unavailable("catalog_missing")
    if snapshot.account.id != config.account_id:
        return _remote_quota_unavailable("catalog_authority_mismatch")

    cache_file_age_seconds = max(
        0,
        (time.time_ns() - metadata.st_mtime_ns) // 1_000_000_000,
    )
    workspaces: list[dict[str, Any]] = []
    used_total = 0
    quota_total = 0
    remaining_total = 0
    reported_count = 0
    for projected in snapshot.projected:
        storage = projected.workspace.storage
        quota_bytes = storage.quota_bytes
        used_bytes = storage.used_bytes
        remaining_bytes = (
            None
            if quota_bytes is None or used_bytes is None
            else max(0, quota_bytes - used_bytes)
        )
        if quota_bytes is not None and used_bytes is not None:
            reported_count += 1
            used_total += used_bytes
            quota_total += quota_bytes
            assert remaining_bytes is not None
            remaining_total += remaining_bytes
        workspaces.append(
            {
                "session_id": projected.workspace.session_id,
                "label": projected.component_name,
                "used_bytes": used_bytes,
                "quota_bytes": quota_bytes,
                "remaining_bytes": remaining_bytes,
            }
        )

    complete = reported_count == len(workspaces)
    aggregate_safe_integer = complete and all(
        total <= MAX_SAFE_INTEGER
        for total in (used_total, quota_total, remaining_total)
    )
    return {
        "available": True,
        "state": "cached",
        "scope": "remote_quota",
        "source": "cached_authenticated_catalog",
        "catalog_generation": snapshot.snapshot_generation,
        # Snapshot writes are atomic. This describes only the local cache file;
        # unchanged authoritative refreshes need not rewrite it.
        "cache_file_age_seconds": cache_file_age_seconds,
        "workspace_count": len(workspaces),
        "capacity_reported_workspace_count": reported_count,
        "capacity_state": "complete" if complete else "partial",
        "aggregate": {
            # Every workspace field is independently bounded to a JSON safe
            # integer by the catalog parser. The sum of many valid workspaces
            # can still exceed that bound, so never publish a lossy aggregate
            # number to JavaScript consumers.
            "safe_integer": aggregate_safe_integer if complete else None,
            "used_bytes": used_total if aggregate_safe_integer else None,
            "quota_bytes": quota_total if aggregate_safe_integer else None,
            "remaining_bytes": remaining_total if aggregate_safe_integer else None,
        },
        "workspaces": workspaces,
    }


def _format_status_bytes(value: int) -> str:
    units = ((1024**4, "TiB"), (1024**3, "GiB"), (1024**2, "MiB"), (1024, "KiB"))
    for divisor, label in units:
        if value >= divisor:
            amount = value / divisor
            if amount < 10 and amount % 1:
                return f"{amount:.1f} {label}"
            return f"{amount:.0f} {label}"
    return f"{value} B"


def command_status(args: argparse.Namespace, paths: Paths) -> int:
    document = _status_document(ConfigStore(paths), deep_fabric=bool(args.deep))
    document["control"] = ControlClient(paths).status()
    if args.json:
        _emit(document, True)
        return 0
    print("Meshia")
    print(f"  projects    {document['control']['state']} (run meshia account to verify live)")
    if document.get("enrolled") is not True:
        print("  connection  not connected")
        print("  next        run the connect command from your Meshia workspace")
        return 0
    service = document.get("service") if isinstance(document.get("service"), dict) else {}
    file_provider = (
        document.get("file_provider")
        if isinstance(document.get("file_provider"), dict)
        else {}
    )
    mount = document.get("mount") if isinstance(document.get("mount"), dict) else {}
    fabric = document.get("fabric") if isinstance(document.get("fabric"), dict) else {}
    remote_quota = (
        document.get("remote_quota")
        if isinstance(document.get("remote_quota"), dict)
        else {}
    )
    connected = bool(service.get("runner_active")) and document.get("lifecycle") == "connected"
    print(f"  connection  {'connected' if connected else document.get('lifecycle', 'offline')}")
    if document.get("account_email"):
        print(f"  account     {document['account_email']}")
    print(f"  workspace   {document.get('workspace_name') or 'Workspace'}")
    disconnect_reason = document.get("disconnect_reason")
    if (
        document.get("lifecycle") == "disconnected"
        and disconnect_reason in _STORAGE_TERMINAL_DISCONNECT_REASONS
    ):
        detail = {
            "WORKSPACE_STORAGE_DELETED": "remote storage was deleted",
            "WORKSPACE_STORAGE_DISABLED": "remote Files storage is not enabled",
            "WORKSPACE_STORAGE_SUPERSEDED": "remote storage moved to a resumed workspace",
        }[disconnect_reason]
        print(f"  files       unavailable ({detail})")
        if document.get("account_id") is not None:
            print("  next        run meshia service restart to restore your account's available Files")
        else:
            print("  next        run the connect command from a workspace with available Files")
        return 0
    if file_provider.get("active"):
        visible_url = str(file_provider.get("user_visible_url") or "")
        parsed_visible = urllib.parse.urlparse(visible_url)
        visible_path = (
            urllib.parse.unquote(parsed_visible.path)
            if parsed_visible.scheme == "file" and parsed_visible.path
            else "Finder"
        )
        print(f"  files       available at {visible_path} (File Provider, on demand)")
    elif mount.get("mounted") and mount.get("backend") == "fskit":
        volumes = mount.get("volumes") if isinstance(mount.get("volumes"), list) else []
        noun = "volume" if len(volumes) == 1 else "volumes"
        print(f"  files       mounted at {mount.get('mount_point')} (FSKit, {len(volumes)} {noun})")
        for volume in volumes:
            print(f"              {volume.get('name')}  {volume.get('mount_point')}")
    elif mount.get("mounted"):
        print(f"  files       mounted at {mount.get('mount_point')} (FUSE-T)")
        if mount.get("appledouble_sidecars") == "discarded":
            print(
                "  notice      Finder tags, comments and quarantine flags are not "
                "stored on Meshia files over this mount (SMB AppleDouble sidecars "
                "are discarded); set MESHIA_MOUNT_KEEP_APPLEDOUBLE_SIDECARS=1 to "
                "keep them as files."
            )
        _state, notice = _fskit_pending_approval(_read_config_for_status(paths))
        if notice:
            print(f"  notice      {notice}")
    elif mount.get("state") == "detached":
        print("  files       reconnecting after an external Finder disconnect")
        print(f"  next        {mount.get('recovery') or 'Meshia is recreating the native mount'}")
    elif mount.get("state") == "orphaned":
        print("  files       mount recovery required (the previous mount owner stopped)")
        print(f"  next        {mount.get('recovery') or 'restart the host before retrying'}")
    elif mount.get("state") == "stopped":
        print("  files       not mounted (the Meshia service is stopped)")
        print(f"  next        {mount.get('recovery') or 'start the Meshia service'}")
    elif mount.get("state") == "starting":
        print(f"  files       mounting at {mount.get('mount_point')} (the Meshia service is starting the native mount)")
    elif mount.get("state") == "unowned":
        print("  files       mount recovery required (registered without an owner receipt)")
        print(f"  next        {mount.get('recovery') or 'restart the host before retrying'}")
    elif mount.get("state") == "registry_unavailable":
        print("  files       mount verification unavailable (OS registry could not be read)")
        print(f"  next        {mount.get('recovery') or 'retry status'}")
    elif mount.get("state") == "invalid_receipt":
        print("  files       mount recovery required (private receipt is invalid)")
        print(f"  next        {mount.get('recovery') or 'restart the host before retrying'}")
    elif mount.get("state") == "disabled":
        print("  files       native mount disabled (remote sync remains active)")
    elif mount.get("state") == "runtime_missing":
        print(f"  files       mount helper needed ({mount.get('install_hint')})")
    else:
        print(f"  files       waiting for the Meshia service ({mount.get('state', 'idle')})")
    object_edge = document.get("object_edge") if isinstance(document.get("object_edge"), dict) else None
    print(
        "  object edge "
        + format_object_edge_status(
            object_edge,
            document.get("session_id") if isinstance(document.get("session_id"), str) else None,
        )
    )
    aggregate = (
        remote_quota.get("aggregate")
        if isinstance(remote_quota.get("aggregate"), dict)
        else {}
    )
    if remote_quota.get("available") is True:
        workspace_count = int(remote_quota.get("workspace_count") or 0)
        used_bytes = aggregate.get("used_bytes")
        quota_bytes = aggregate.get("quota_bytes")
        if isinstance(used_bytes, int) and isinstance(quota_bytes, int):
            noun = "workspace" if workspace_count == 1 else "workspaces"
            print(
                "  quota       "
                f"{_format_status_bytes(used_bytes)} of {_format_status_bytes(quota_bytes)} "
                f"remote used ({workspace_count} {noun}, cached)"
            )
        elif remote_quota.get("capacity_state") == "complete":
            print(
                "  quota       remote aggregate exceeds JSON's safe-integer range "
                f"({workspace_count} workspaces, cached)"
            )
        else:
            print(f"  quota       remote usage pending ({workspace_count} workspaces)")
    if fabric.get("sync_converged") is True:
        print("  sync        up to date")
    elif fabric.get("command_safe") is True:
        print(f"  sync        reconciling ({fabric.get('sync_convergence_reason') or 'pending'})")
    else:
        print(f"  sync        attention ({fabric.get('command_safety_reason') or 'offline'})")
    push = document.get("push") if isinstance(document.get("push"), dict) else {}
    if push.get("connected") is True:
        age = push.get("last_frame_age_seconds")
        print(
            "  push        connected"
            + (f" ({int(age)}s ago)" if isinstance(age, int) else "")
        )
    else:
        print("  push        polling")
    return 0


def command_open(args: argparse.Namespace, paths: Paths) -> int:
    config = _read_config_for_status(paths)
    file_provider = _native_file_provider_status_document(
        paths,
        enabled=config.native_mount_enabled if config is not None else True,
        config=config,
    )
    mount = _fabric_mount_status_document(
        paths,
        enabled=config.native_mount_enabled if config is not None else True,
    )
    file_provider_url = (
        str(file_provider.get("user_visible_url"))
        if file_provider.get("active") and file_provider.get("user_visible_url")
        else None
    )
    if file_provider_url is None and not mount["mounted"]:
        detail = (
            mount.get("recovery")
            or mount.get("install_hint")
            or "start or repair the Meshia service"
        )
        raise StateError(f"Meshia files are not available; {detail}.")
    target = file_provider_url or str(mount["mount_point"])
    if sys.platform == "darwin":
        command = ["/usr/bin/open", target]
    elif sys.platform == "win32":
        command = ["explorer.exe", target]
    else:
        browser = shutil.which("xdg-open") or shutil.which("gio")
        if browser is None:
            raise StateError("No Linux file browser opener is available (install xdg-utils).")
        command = (
            [browser, "open", target]
            if Path(browser).name == "gio"
            else [browser, target]
        )
    try:
        subprocess.Popen(
            command,
            env=_native_browser_environment(),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
    except OSError as error:
        raise StateError("The native file browser could not be opened.") from error
    _emit(
        {
            "opened": True,
            "presentation": (
                "file-provider" if file_provider_url is not None else "mount"
            ),
            "target": target,
            "mount_point": None if file_provider_url is not None else target,
        },
        args.json,
    )
    return 0


def _native_browser_environment() -> dict[str, str]:
    """Keep desktop-session plumbing while withholding tokens and node config."""

    environment = scrubbed_environment(str(Path.home()))
    if sys.platform != "win32":
        for name in (
            "DISPLAY",
            "WAYLAND_DISPLAY",
            "DBUS_SESSION_BUS_ADDRESS",
            "XDG_RUNTIME_DIR",
            "XDG_CURRENT_DESKTOP",
            "XDG_SESSION_TYPE",
        ):
            value = os.environ.get(name)
            if value is not None and "\x00" not in value:
                environment[name] = value
    return environment


def _conflict_timestamp(timestamp_ns: int | None) -> str | None:
    if timestamp_ns is None:
        return None
    return iso8601(datetime.fromtimestamp(timestamp_ns / 1_000_000_000, tz=timezone.utc))


def _conflict_view_document(
    view: Any, *, include_resolution_error: bool = False
) -> dict[str, Any]:
    """Return an operator-safe projection without private staging paths."""

    conflict = view.conflict
    operation = view.operation
    resolution = view.resolution
    return {
        "conflict_id": conflict.conflict_id,
        "path": conflict.path,
        "reason": conflict.reason,
        "state": "resolved" if conflict.resolved_at_ns is not None else "unresolved",
        "recorded_at": _conflict_timestamp(conflict.recorded_at_ns),
        "resolved_at": _conflict_timestamp(conflict.resolved_at_ns),
        "base_digest": conflict.base_digest,
        "local_digest": conflict.local_digest,
        "local_fingerprint": conflict.local_fingerprint,
        "remote_digest": conflict.remote_digest,
        "remote_generation": conflict.remote_generation,
        "local_evidence": (
            "recorded_stage"
            if conflict.staged_path is not None
            else (
                "workspace_identity_unhashed"
                if conflict.local_fingerprint is not None
                else (
                    "local_absence"
                    if conflict.local_digest is None
                    else "workspace_unverified"
                )
            )
        ),
        "operation": (
            {
                "kind": operation.kind,
                "path": operation.path,
                "destination_path": operation.destination_path,
                "state": operation.state,
            }
            if operation is not None
            else None
        ),
        "resolution": (
            {
                "decision": resolution.decision,
                "phase": resolution.phase,
                **(
                    {
                        "retry_available": resolution.phase == "blocked"
                        and resolution.retry_safe,
                        "retry_requested": resolution.retry_safe
                        and resolution.retry_requested_at_ns is not None,
                        "rearm_available": resolution.phase == "blocked"
                        and not resolution.retry_safe,
                        "rearm_requested": not resolution.retry_safe
                        and resolution.retry_requested_at_ns is not None,
                        **(
                            {"error": resolution.last_error}
                            if resolution.last_error is not None
                            else {}
                        ),
                    }
                    if include_resolution_error
                    else {}
                ),
            }
            if resolution is not None
            else None
        ),
    }


def _require_active_conflict_database(
    paths: Paths,
    *,
    session_id: str | None = None,
) -> tuple[NodeConfig, WorkspaceStatePaths, Path, FabricDatabase]:
    """Open one catalog-proven workspace authority, never a stale journal."""

    config = ConfigStore(paths).require()
    selected_session_id = config.session_id
    if session_id is None:
        workspace_state = _configured_workspace_state(paths, config)
        workspace_root = Path(config.workspace)
    else:
        if config.account_id is None or config.installation_id is None:
            raise StateError(
                "An exact workspace session requires an authenticated account catalog."
            )
        catalog = WorkspaceCatalogStore(
            paths.account_workspace_catalog(config.account_id)
        ).load_readonly()
        if catalog is None or catalog.account.id != config.account_id:
            raise StateError(
                "The authenticated workspace catalog is unavailable or has changed authority."
            )
        if not any(entry.session_id == session_id for entry in catalog.workspaces):
            raise StateError(
                "The requested session is not in the authenticated workspace catalog."
            )
        selected_session_id = session_id
        if session_id == config.session_id:
            workspace_state = _configured_workspace_state(paths, config)
            workspace_root = Path(config.workspace)
        else:
            workspace_state = _catalog_workspace_state(
                paths,
                account_id=config.account_id,
                session_id=session_id,
                installation_id=config.installation_id,
            )
            workspace_root = workspace_state.workspace
    if not workspace_state.database.is_file():
        raise StateError("The Fabric journal is not initialized for this workspace session.")
    _preflight_authoritative_journal(workspace_state.database)
    database = FabricDatabase(workspace_state.database)
    try:
        authority = database.current_authority()
        if authority is None:
            raise StateError("The Fabric journal has no active workspace authority.")
        selected_config_workspace = selected_session_id == config.session_id
        if (
            authority.host_id != config.host_id
            or authority.session_id != selected_session_id
            or authority.host_generation != config.generation
            or _normalized_absolute_path(authority.workspace_root)
            != _normalized_absolute_path(workspace_root)
            or (
                (session_id is None or selected_config_workspace)
                and authority.workspace_id != config.workspace_id
            )
            or (
                session_id is not None
                and authority.workspace_id is None
            )
        ):
            raise StateError(
                "The Fabric journal authority does not match this workspace session; "
                "start the node to reconcile it before managing conflicts."
            )
        if session_id is not None:
            assert authority.workspace_id is not None
            claim = validate_workspace_root_claim(
                workspace_root,
                installation_id=config.installation_id,
                workspace_id=authority.workspace_id,
                host_id=config.host_id,
                session_id=selected_session_id,
                require_bound=True,
            )
            if (
                claim.session_id != selected_session_id
                or _normalized_absolute_path(claim.canonical_root)
                != _normalized_absolute_path(workspace_root)
            ):
                raise StateError(
                    "The workspace ownership marker does not match this session."
                )
        return config, workspace_state, workspace_root, database
    except BaseException:
        database.close()
        raise


def _emit_conflict_list(
    views: Sequence[Any],
    *,
    limit: int,
    after: int,
    unresolved_only: bool,
    as_json: bool,
) -> None:
    documents = [_conflict_view_document(view) for view in views]
    next_after = documents[-1]["conflict_id"] if len(documents) == limit else None
    if as_json:
        _emit(
            {
                "scope": "active",
                "state": "unresolved" if unresolved_only else "all",
                "after": after,
                "limit": limit,
                "count": len(documents),
                "next_after": next_after,
                "conflicts": documents,
            },
            True,
        )
        return
    if not documents:
        qualifier = "unresolved " if unresolved_only else ""
        print(f"No {qualifier}conflicts in the active workspace.")
        return
    for document in documents:
        resolution = document["resolution"]
        state = (
            f"{resolution['decision']}:{resolution['phase']}"
            if resolution is not None
            else document["state"]
        )
        safe_path = json.dumps(document["path"], ensure_ascii=False)
        safe_reason = json.dumps(document["reason"], ensure_ascii=False)
        print(f"{document['conflict_id']}  {state}  {safe_path}  {safe_reason}")
    if next_after is not None:
        print(f"More may be available: meshia-node conflicts list --after {next_after}")


def command_conflicts(args: argparse.Namespace, paths: Paths) -> int:
    config, workspace_state, workspace_root, database = _require_active_conflict_database(
        paths,
        session_id=args.conflict_session_id,
    )
    try:
        if args.conflict_action == "list":
            unresolved_only = not args.all
            views = database.list_conflict_views(
                limit=args.limit,
                after_conflict_id=args.after,
                unresolved_only=unresolved_only,
            )
            _emit_conflict_list(
                views,
                limit=args.limit,
                after=args.after,
                unresolved_only=unresolved_only,
                as_json=args.json,
            )
            return 0

        view = database.get_conflict_view(args.conflict_id)
        if view is None:
            raise StateError(
                f"Conflict {args.conflict_id} is not in the active workspace authority."
            )
        if args.conflict_action == "show":
            document = _conflict_view_document(
                view, include_resolution_error=True
            )
            if args.json:
                _emit(document, True)
            else:
                safe_path = json.dumps(document["path"], ensure_ascii=False)
                print(f"Conflict {document['conflict_id']}: {safe_path}")
                print(f"  state: {document['state']}")
                print(f"  reason: {json.dumps(document['reason'], ensure_ascii=False)}")
                print(f"  detected: {document['recorded_at']}")
                print(f"  local evidence: {document['local_evidence']}")
                print(
                    "  local digest: "
                    + (
                        "unavailable (protocol-oversize file)"
                        if document["local_fingerprint"] is not None
                        else (document["local_digest"] or "absent")
                    )
                )
                print(f"  remote digest: {document['remote_digest'] or 'absent'}")
                if document["operation"] is not None:
                    operation = document["operation"]
                    print(f"  operation: {operation['kind']}")
                    if operation["destination_path"] is not None:
                        print(
                            "  destination: "
                            f"{json.dumps(operation['destination_path'], ensure_ascii=False)}"
                        )
                if document["resolution"] is not None:
                    resolution = document["resolution"]
                    print(f"  resolution: {resolution['decision']} ({resolution['phase']})")
                    if resolution.get("error") is not None:
                        print(
                            "  resolution error: "
                            f"{json.dumps(resolution['error'], ensure_ascii=False)}"
                        )
            return 0

        if args.conflict_action == "resolve":
            resolution = database.request_conflict_resolution(
                args.conflict_id,
                args.decision,
            )
            document = {
                "conflict_id": args.conflict_id,
                "decision": resolution.decision,
                "phase": resolution.phase,
                "queued": resolution.phase != "completed",
                "completed": resolution.phase == "completed",
            }
            if args.json:
                _emit(document, True)
            else:
                print(
                    f"Conflict {args.conflict_id}: {resolution.decision.replace('_', '-')} "
                    f"is {resolution.phase.replace('_', ' ')}."
                )
            return 0

        if args.conflict_action == "retry":
            resolution = database.request_conflict_resolution_retry(
                args.conflict_id
            )
            document = {
                "conflict_id": args.conflict_id,
                "decision": resolution.decision,
                "phase": resolution.phase,
                "retry_requested": resolution.retry_requested_at_ns is not None,
            }
            if args.json:
                _emit(document, True)
            else:
                print(
                    f"Conflict {args.conflict_id}: retry requested for "
                    f"{resolution.decision.replace('_', '-')} against fresh state."
                )
            return 0

        if args.conflict_action == "rearm":
            resolution = database.request_conflict_resolution_rearm(
                args.conflict_id
            )
            document = {
                "conflict_id": args.conflict_id,
                "decision": resolution.decision,
                "phase": resolution.phase,
                "rearm_requested": resolution.retry_requested_at_ns is not None,
            }
            if args.json:
                _emit(document, True)
            else:
                print(
                    f"Conflict {args.conflict_id}: rearm requested for the blocked "
                    f"{resolution.decision.replace('_', '-')} attempt. The node will "
                    "re-prove no remote effect before allowing a new decision."
                )
            return 0

        if args.conflict_action == "export":
            # Import lazily so the connection/status CLI remains independent of
            # the byte-recovery implementation and its platform-specific I/O.
            from .conflict_io import export_active_conflict_local

            conflict = view.conflict
            if (
                conflict.local_digest is None
                and conflict.local_fingerprint is None
            ):
                raise StateError(
                    "This conflict records local absence, so there are no local bytes to export."
                )
            destination = Path(args.destination).expanduser().absolute()
            normalized_destination = _normalized_absolute_path(destination)
            for protected in (workspace_root, paths.home):
                try:
                    inside = os.path.commonpath(
                        (
                            _normalized_absolute_path(protected),
                            normalized_destination,
                        )
                    ) == _normalized_absolute_path(protected)
                except ValueError:
                    inside = False
                if inside:
                    raise InvalidArgument(
                        "Export conflicts to a new file outside the workspace and Meshia state."
                    )
            operation = view.operation
            expected_size = (
                operation.staged_size
                if operation is not None
                and operation.staged_digest == conflict.local_digest
                else None
            )
            try:
                with WorkspaceBoundary(workspace_root) as workspace:
                    copied = export_active_conflict_local(
                        workspace,
                        conflict.path,
                        destination,
                        staging_root=workspace_state.staging,
                        staged_path=conflict.staged_path,
                        expected_sha256=conflict.local_digest,
                        expected_fingerprint=conflict.local_fingerprint,
                        expected_size=expected_size,
                    )
            except FileExistsError:
                raise StateError(
                    "The export destination already exists; nothing was overwritten."
                ) from None
            except OSError as error:
                raise StateError(
                    f"The conflict export could not be published safely "
                    f"({type(error).__name__}); nothing was overwritten."
                ) from error
            document = {
                "conflict_id": args.conflict_id,
                "destination": str(destination),
                "digest": copied.sha256,
                "verification": (
                    "sha256" if copied.sha256 is not None else "recorded_file_identity"
                ),
                "size_bytes": copied.size_bytes,
                "source": copied.source,
            }
            if args.json:
                _emit(document, True)
            else:
                print(
                    f"Exported conflict {args.conflict_id} to "
                    f"{json.dumps(str(destination), ensure_ascii=False)} "
                    f"({copied.size_bytes} bytes, "
                    + (
                        f"sha256 {copied.sha256})."
                        if copied.sha256 is not None
                        else "recorded file identity; content was not hashed)."
                    )
                )
            return 0
        raise InvalidArgument("Unknown conflicts action.")  # pragma: no cover
    finally:
        database.close()


def command_disconnect(args: argparse.Namespace, paths: Paths) -> int:
    store = ConfigStore(paths)
    store.require()
    _request_sticky_disconnect(store)
    service_disabled = _disable_service_if_owned(paths)
    lease = _acquire_connection_lease(paths, DISCONNECT_LEASE_WAIT_SECONDS)
    try:
        _set_owned_pid(store, lease.pid)
        identity = DeviceIdentity.load_or_create(paths.identity_dir)
        disconnect(SignedClient(store, identity), store)
    finally:
        _clear_owned_pid(store, lease.pid)
        lease.release()
    _emit({"disconnected": True, "service_disabled": service_disabled}, args.json)
    return 0


def command_forget(args: argparse.Namespace, paths: Paths) -> int:
    """Fence all runners, revoke best-effort, then erase identity but retain pending bytes."""
    store = ConfigStore(paths)
    revoked = False
    detail = None
    if store.exists():
        _request_sticky_disconnect(store)
    service_disabled = _disable_service_if_owned(paths)
    lease = _acquire_connection_lease(paths, DISCONNECT_LEASE_WAIT_SECONDS)
    try:
        if store.exists():
            _set_owned_pid(store, lease.pid)
        if not args.keep_remote and store.exists():
            try:
                identity = DeviceIdentity.load_or_create(paths.identity_dir)
                forget_remote(SignedClient(store, identity), store)
                revoked = True
            except MeshiaNodeError as error:
                detail = error.code
        store.erase()
        DeviceIdentity.erase(paths.identity_dir)
    finally:
        _clear_owned_pid(store, lease.pid)
        lease.release()
    _emit(
        {
            "forgotten": True,
            "remote_revoked": revoked,
            "remote_detail": detail,
            "service_disabled": service_disabled,
            "fabric_state_retained": paths.fabric_db_path.exists() or paths.fabric_state.exists(),
        },
        args.json,
    )
    return 0


def _service_action_document(
    controller: ServiceController, action: ServiceAction
) -> dict[str, Any]:
    return {
        "service": controller.definition.name,
        "platform": controller.definition.platform,
        "changed": action.changed,
        "status_codes": [result.returncode for result in action.results],
    }


def command_service(args: argparse.Namespace, paths: Paths) -> int:
    action_name = args.service_action
    if action_name == "run":
        return _command_service_run(args, paths)

    store = ConfigStore(paths)
    if action_name == "status":
        _emit(_status_document(store), args.json)
        return 0
    controller = _service_controller(paths)
    if action_name in ("install", "start", "restart"):
        config = store.require()
        if action_name == "restart" and config.lifecycle == "disconnected" and not can_recover_account_storage(config):
            if bool(args.wait):
                raise InvalidArgument(
                    "This node is safely parked and cannot become ready. "
                    "Reconnect it from a workspace with available Files before using "
                    "`service restart --wait`."
                )
            _emit(
                {
                    "service": controller.definition.name,
                    "platform": controller.definition.platform,
                    "changed": False,
                    "status_codes": [],
                    "parked": True,
                    "detail": (
                        "The remote connection is safely parked; no service process or "
                        "native mount was restarted. Reconnect it from a workspace with "
                        "available Files when you are ready."
                    ),
                },
                args.json,
            )
            return 0
    readiness: dict[str, Any] | None = None
    if action_name == "install":
        action = controller.install()
    elif action_name == "start":
        action = controller.start()
    elif action_name == "restart":
        wait = bool(args.wait)
        expected_version = args.expected_version
        timeout_seconds = args.timeout_seconds
        if wait and not expected_version:
            raise InvalidArgument("--expected-version is required with service restart --wait.")
        if wait and (
            not math.isfinite(timeout_seconds) or timeout_seconds <= 0 or timeout_seconds > 300
        ):
            raise InvalidArgument("--timeout-seconds must be greater than 0 and at most 300.")
        baseline = _read_runtime_status(paths)
        restart_stamp = iso8601()
        restart_started_at = _parse_utc_timestamp(restart_stamp)
        assert restart_started_at is not None
        action = controller.restart()
        if wait:
            readiness = _wait_for_service_ready(
                store,
                paths,
                baseline=baseline,
                restart_started_at=restart_started_at,
                expected_executable=controller.definition.run_command[0],
                expected_version=expected_version,
                timeout_seconds=timeout_seconds,
                controller=controller,
            )
    elif action_name == "stop":
        action = controller.stop()
    elif action_name == "uninstall":
        action = controller.uninstall()
    else:  # pragma: no cover - argparse enforces the choices
        raise InvalidArgument("Unknown service action.")
    document = _service_action_document(controller, action)
    if readiness is not None:
        document["readiness"] = readiness
    _emit(document, args.json)
    return 0


def _command_service_run(args: argparse.Namespace, paths: Paths) -> int:
    """Restart an enrolled node without ever persisting enrollment secrets."""
    assert_safe_node_account()
    store = ConfigStore(paths)
    logger = NodeLogger(path=paths.log_path, quiet=True)
    config = store.load()
    if config is None:
        _clear_runtime_status(paths, logger)
        logger.record("service_parked", reason="not_enrolled")
        return 0
    if config.lifecycle == "disconnected" and not can_recover_account_storage(config):
        _clear_runtime_status(paths, logger)
        logger.record("service_parked", reason="sticky_disconnect")
        return 0

    shutdown = threading.Event()
    _install_shutdown_event_handlers(shutdown, logger)
    _clear_service_shutdown_request(paths)
    with ConnectionLease(paths.connection_lock) as lease:
        preserve_service_stderr(paths.home)
        shutdown_watcher = _start_service_shutdown_watch(
            paths, lease.pid, shutdown, logger
        )
        _set_owned_pid(store, lease.pid)
        try:
            current = store.require()
            if (
                not current.native_mount_enabled
                and _retire_disabled_dead_mount_receipt(paths)
            ):
                logger.record("fabric_mount_disabled_receipt_retired")
            _write_runtime_status(
                paths,
                start_nonce=str(uuid.uuid4()),
                pid=lease.pid,
            )
            attempt = 0
            retry_ceiling = max(0.0, SERVICE_START_DELAY_SECONDS)
            while not shutdown.is_set():
                attempt += 1
                if shutdown.is_set():
                    return 0
                current = store.require()
                if current.lifecycle == "disconnected" and not can_recover_account_storage(current):
                    logger.record("service_parked", reason="sticky_disconnect")
                    return 0
                try:
                    return _run_connection(
                        store,
                        paths,
                        logger,
                        max_iterations=None,
                        disconnect_on_exit=False,
                        shutdown_event=shutdown,
                        runtime_status_required=True,
                    )
                except Disconnected as error:
                    _mark_disconnected(store, reason_code=error.reason_code)
                    logger.record(
                        "connection_disconnected",
                        reason_code=error.reason_code or "REMOTE_AUTHORITY_REVOKED",
                    )
                    return 2
                except AuthoritativeStateUnavailable as error:
                    journal_state = error.journal_state
                    runtime = _read_runtime_status(paths)
                    if runtime is not None and runtime["pid"] == lease.pid:
                        _write_runtime_status(
                            paths,
                            start_nonce=runtime["start_nonce"],
                            pid=runtime["pid"],
                            executable=runtime["executable"],
                            native_host_pid=runtime["native_host_pid"],
                            package_version=runtime["package_version"],
                            started_at=runtime["started_at"],
                            runtime_ready=False,
                            runtime_readiness_reason=journal_state,
                            command_safe=False,
                            command_safety_reason=journal_state,
                            sync_converged=False,
                            sync_convergence_reason=journal_state,
                            watcher_health=runtime["watcher"],
                            staging_health=runtime["staging"],
                            last_error=_bounded_last_error(
                                "fabric_journal", error.code, str(error)
                            ),
                            degraded_operations=("fabric_journal",),
                        )
                    delay = SERVICE_START_MAX_DELAY_SECONDS
                    logger.record(
                        "service_state_parked",
                        error_code=error.code,
                        journal_state=journal_state,
                        retry_in_seconds=delay,
                    )
                    if shutdown.wait(delay):
                        return 0
                except (NetworkError, RemoteError) as error:
                    if isinstance(error, RemoteError) and not error.retryable:
                        raise
                    runtime = _read_runtime_status(paths)
                    if runtime is not None and runtime["pid"] == lease.pid:
                        _write_runtime_status(
                            paths,
                            start_nonce=runtime["start_nonce"],
                            pid=runtime["pid"],
                            executable=runtime["executable"],
                            native_host_pid=runtime["native_host_pid"],
                            package_version=runtime["package_version"],
                            started_at=runtime["started_at"],
                            runtime_ready=False,
                            runtime_readiness_reason="initial_attach_retry",
                            command_safe=False,
                            command_safety_reason="runtime_not_ready",
                            sync_converged=False,
                            sync_convergence_reason="runtime_not_ready",
                            watcher_health=runtime["watcher"],
                            staging_health=runtime["staging"],
                            last_error=_bounded_last_error(
                                "initial_attach", error.code, str(error)
                            ),
                            degraded_operations=("initial_attach",),
                        )
                    delay = min(
                        SERVICE_START_MAX_DELAY_SECONDS,
                        retry_ceiling,
                    )
                    # Equal jitter prevents a recovered control plane from
                    # receiving a synchronized fleet burst, while retaining a
                    # positive lower bound and a hard 30-second ceiling.
                    delay *= 0.5 + (0.5 * random.random())
                    logger.record(
                        "service_start_deferred",
                        error_code=error.code,
                        attempt=attempt,
                        retry_in_seconds=delay,
                    )
                    if shutdown.wait(delay):
                        return 0
                    retry_ceiling = min(
                        SERVICE_START_MAX_DELAY_SECONDS,
                        max(SERVICE_START_DELAY_SECONDS, retry_ceiling * 2),
                    )
            return 0
        finally:
            shutdown.set()
            shutdown_watcher.join(timeout=1.0)
            _clear_service_shutdown_request(paths)
            _clear_owned_pid(store, lease.pid)


def _doctor_check(name: str, ok: bool, detail: str) -> dict[str, Any]:
    return {"check": name, "ok": bool(ok), "detail": detail[:512]}


def _augment_doctor_with_node_health(
    report: dict[str, Any],
    paths: Paths,
) -> dict[str, Any]:
    """Add enrolled runtime/Fabric gates without mutating authoritative state."""

    status = _status_document(ConfigStore(paths), deep_fabric=True)
    report["node_health"] = status
    checks = list(report.get("checks", ()))
    native = report.get("native_execution")
    if isinstance(native, dict):
        service = status.get("service") or {}
        evidence = (service.get("runtime") or {}).get("workspace_execution") or {
            "ready": False, "policy_supported": None, "reason": "daemon_probe_unavailable",
        }
        ready = evidence.get("ready") is True
        selected = native.get("selected_scope")
        selected_ready = ready if selected == "workspace" else bool(native.get("selected_scope_available"))
        detail = ("Workspace only: the running node read its owned mount" if ready else
                  "Workspace only needs workspace access: the running node could not read its mount"
                  if str(evidence["reason"]).startswith("workspace_access_") else
                  "Workspace only is unavailable: " + str(evidence["reason"]))
        report["native_execution"] = {
            **native, "workspace_policy_supported": native.get("workspace_available"),
            "workspace_policy_detail": native.get("workspace_detail"), "workspace_detail": detail,
            "workspace_available": ready, "workspace_execution_status": evidence,
            "selected_scope_available": selected_ready,
        }
        checks = [
            _doctor_check("native_execution", selected_ready,
                f"{detail}; native full access {'available' if native.get('full_available') else 'unavailable'}")
            if check.get("check") == "native_execution" else check for check in checks
        ]
    if status.get("state") == "authoritative_state_unreadable":
        checks.append(
            _doctor_check(
                "authoritative_state",
                False,
                "node configuration is unreadable; preserved for operator recovery",
            )
        )
    elif status.get("enrolled") is True:
        service = status.get("service") if isinstance(status.get("service"), dict) else {}
        runtime = service.get("runtime") if isinstance(service.get("runtime"), dict) else {}
        runner_active = bool(service.get("runner_active"))
        disconnect_reason = str(status.get("disconnect_reason") or "")
        safely_parked = (
            status.get("lifecycle") == "disconnected"
            and disconnect_reason in _STORAGE_TERMINAL_DISCONNECT_REASONS
            and status.get("account_id") is None
            and not runner_active
        )
        account_storage_recovery = (
            status.get("lifecycle") == "disconnected"
            and disconnect_reason in _STORAGE_TERMINAL_DISCONNECT_REASONS
            and status.get("account_id") is not None
            and not runner_active
        )
        runtime_ready = bool(runtime.get("runtime_ready")) if runner_active else False
        runtime_reason = (
            str(runtime.get("runtime_readiness_reason") or "attention")
            if runner_active
            else (
                f"safely parked ({disconnect_reason.lower()})"
                if safely_parked
                else "account Files need recovery; run meshia service restart"
                if account_storage_recovery else "stopped"
            )
        )
        checks.append(
            _doctor_check(
                "node_runtime",
                safely_parked or (runner_active and runtime_ready),
                runtime_reason,
            )
        )
        if runner_active:
            command_safe = bool(runtime.get("command_safe"))
            checks.append(
                _doctor_check(
                    "command_safety",
                    command_safe,
                    str(runtime.get("command_safety_reason") or "not_ready"),
                )
            )
            degraded = runtime.get("degraded_operations")
            last_error = runtime.get("last_error")
            clean_runtime = not degraded and last_error is None
            checks.append(
                _doctor_check(
                    "runtime_health",
                    clean_runtime,
                    (
                        "healthy"
                        if clean_runtime
                        else f"degraded={degraded or []} last_error={last_error or 'none'}"
                    ),
                )
            )

        fabric = status.get("fabric") if isinstance(status.get("fabric"), dict) else {}
        journal_state = str(fabric.get("journal_state") or "absent")
        checks.append(
            _doctor_check(
                "fabric_journal",
                journal_state in ("healthy", "absent"),
                journal_state,
            )
        )
        pending = int(fabric.get("pending_operations") or 0)
        checks.append(
            _doctor_check(
                "fabric_queue",
                True,
                f"{pending} ordinary queued operation(s); offline backlog is informational",
            )
        )
        unknown = int(fabric.get("commit_unknown_operations") or 0)
        unknown_age = fabric.get("oldest_commit_unknown_age_seconds")
        unknown_aged = bool(
            unknown
            and isinstance(unknown_age, (int, float))
            and not isinstance(unknown_age, bool)
            and float(unknown_age) >= DOCTOR_COMMIT_UNKNOWN_ATTENTION_SECONDS
        )
        checks.append(
            _doctor_check(
                "commit_unknown",
                not unknown_aged,
                (
                    f"{unknown} fenced mutation(s), oldest age={unknown_age}s"
                    if unknown
                    else "none"
                ),
            )
        )
        staging = fabric.get("staging") if isinstance(fabric.get("staging"), dict) else {}
        staging_blocked = bool(staging.get("blocked"))
        checks.append(
            _doctor_check(
                "fabric_staging",
                not staging_blocked,
                (
                    str(staging.get("state") or staging.get("repair_phase") or "ready")
                    if staging
                    else "not initialized"
                ),
            )
        )
        conflicts = int(fabric.get("unresolved_conflicts") or 0)
        quarantined = int(fabric.get("quarantined_operations") or 0)
        checks.append(
            _doctor_check(
                "fabric_conflicts",
                conflicts == 0 and quarantined == 0,
                f"unresolved={conflicts} quarantined={quarantined}",
            )
        )
        local_file_issues = (
            fabric.get("local_file_issues")
            if isinstance(fabric.get("local_file_issues"), dict)
            else {"sample": [], "saturated": False}
        )
        local_file_sample = local_file_issues.get("sample")
        issue_count = len(local_file_sample) if isinstance(local_file_sample, list) else 0
        issue_saturated = bool(local_file_issues.get("saturated"))
        checks.append(
            _doctor_check(
                "fabric_local_files",
                issue_count == 0 and not issue_saturated,
                (
                    f"{issue_count} unsupported local file(s)"
                    + ("; more not shown" if issue_saturated else "")
                    + (
                        f"; {LOCAL_FILE_UNSUPPORTED_REMEDIATION}"
                        if issue_count or issue_saturated
                        else ""
                    )
                ),
            )
        )
        mount_enabled = status.get("native_mount_enabled")
        if isinstance(mount_enabled, bool):
            file_provider = (
                status.get("file_provider")
                if isinstance(status.get("file_provider"), dict)
                else {}
            )
            file_provider_active = bool(file_provider.get("active"))
            mount = (
                status.get("mount")
                if isinstance(status.get("mount"), dict)
                else {}
            )
            mounted = bool(mount.get("mounted"))
            mount_state = str(mount.get("state") or "unknown")
            mount_point = str(mount.get("mount_point") or "Meshia")
            mount_detail = str(mount.get("detail") or "")
            if not mount_enabled:
                detail = "intentionally disabled; workspace sync remains active"
            elif file_provider_active:
                detail = "File Provider active; content hydrates on demand"
            elif mounted:
                detail = f"mounted at {mount_point}"
            else:
                detail = mount_state + (
                    f" ({mount_detail})" if mount_detail else ""
                )
            checks.append(
                _doctor_check(
                    "native_mount",
                    not mount_enabled or file_provider_active or mounted,
                    detail,
                )
            )
    if sys.platform == "darwin":
        file_provider = (
            status.get("file_provider")
            if isinstance(status.get("file_provider"), dict)
            else {}
        )
        extension_state, notice = (
            (None, None)
            if file_provider.get("active")
            else _fskit_pending_approval(_read_config_for_status(paths))
        )
        report["fskit"] = {"extension_state": extension_state, "notice": notice}
        if notice:
            # Informational: FUSE-T still joins the workspace, so the overall
            # verdict stays "ok"; the detail carries the exact one-time action.
            checks.append(_doctor_check("fskit_extension", True, f"action needed: {notice}"))
        elif extension_state is not None:
            checks.append(
                _doctor_check(
                    "fskit_extension",
                    True,
                    (
                        "enabled; per-workspace FSKit volumes are in use (no kernel NFS client)"
                        if extension_state == "enabled"
                        else f"{extension_state}; FUSE-T stays in use"
                    ),
                )
            )
    report["checks"] = checks
    report["ok"] = all(bool(item.get("ok")) for item in checks)
    return report


def command_doctor(args: argparse.Namespace, paths: Paths) -> int:
    report = run_doctor(
        paths,
        api_url=args.api_url,
        network=not args.offline,
        config_loader=_read_config_for_status,
    )
    report = _augment_doctor_with_node_health(report, paths)
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        machine = report["machine"]
        print(f"meshia-node {report['version']} on {machine['os']}/{machine['arch']}")
        print(
            f"  python {machine['python']} · {machine['cpu_logical']} vCPU · "
            f"{machine['memory_bytes'] // (1024 ** 3)} GiB RAM · "
            f"gpu {machine['gpu']['family']} x{machine['gpu']['count']}"
        )
        enrollment = report["enrollment"]
        if enrollment.get("enrolled"):
            print(f"  tier {enrollment['tier']} · access {enrollment['access']}")
        else:
            print(f"  not enrolled · access defaults to {DEFAULT_ACCESS_MODE}")
        for check in report["checks"]:
            print(f"  [{'ok ' if check['ok'] else 'FAIL'}] {check['check']}: {check['detail']}")
        print(f"  overall: {'ok' if report['ok'] else 'attention required'}")
    return 0 if report["ok"] else 1


def command_mcp(args: argparse.Namespace, _paths: Paths) -> int:
    """Print a paste-ready remote MCP connection without touching node state."""

    if args.action == "serve":
        from .mcp_bridge import Bridge
        return Bridge(ControlClient(_paths)).serve()
    if args.action == "config":
        # An absolute executable and explicit private home avoid GUI PATH and
        # multi-install ambiguity. No credential ever enters client config.
        # Preserve venv symlinks: resolving python to its base interpreter loses
        # the installed package. Prefer the installer's stable runtime pointer
        # so a client config also survives transactional runtime upgrades.
        # Isolate module discovery from the agent's workspace and PYTHONPATH.
        stable_python = _paths.home / "runtime" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        executable = str(stable_python.absolute() if stable_python.is_file() else Path(sys.executable).absolute())
        print(json.dumps({"mcpServers": {"meshia": {"command": executable, "args": ["-I", "-m", "meshia_node", "--home", str(_paths.home.absolute()), "mcp", "serve"]}}}, indent=2))
        return 0
    origin = validate_api_url(args.api_url).rstrip("/")
    endpoint = f"{origin}/api/mcp"
    instructions_url = f"{origin}/agent-setup.md"
    claude = (
        "claude mcp add --scope user --transport http "
        f'meshia "{endpoint}"'
    )
    codex = f'codex mcp add meshia --url "{endpoint}"'
    client_commands = {
        "claude": claude,
        "codex": codex,
    }
    client_command = client_commands.get(args.client)
    prompt = f"Set up Meshia for me: fetch {instructions_url} and follow it."
    document = {
        "schema": "meshia.mcp_setup.v1",
        "name": "meshia",
        "transport": "streamable_http",
        "url": endpoint,
        "instructions_url": instructions_url,
        "oauth": True,
        "client": args.client,
        "command": client_command,
        "prompt": prompt,
    }
    if args.json:
        print(json.dumps(document, indent=2, sort_keys=True))
    elif client_command is not None:
        print(client_command)
    else:
        print(prompt)
    return 0


def _fskit_pending_approval(config: NodeConfig | None) -> tuple[str | None, str | None]:
    """Return ``(extension_state, notice)`` when FSKit is installed but unapproved.

    Only an explicit ``fskit`` preference requires extension approval. Auto
    installs are complete with FUSE-T. Every probe behind ``select_mount_backend``
    is bounded and short-circuits before touching pluginkit or mount(8) unless
    macOS 26 and Meshia.app are both present.
    """

    if sys.platform != "darwin":
        return None, None
    requested = config.mount_backend if config is not None else "auto"
    if requested != "fskit":
        return None, None
    try:
        selection = select_mount_backend(requested)
    except StateError:
        # An explicit `fskit` choice that cannot be honoured already fails the
        # service start loudly; the notice belongs to the silent fallback.
        return "disabled", fskit_approval_notice("disabled")
    return selection.extension_state, fskit_approval_notice(selection.extension_state)


def _command_mount_probe(args: argparse.Namespace, paths: Paths) -> int:
    """Bounded mount state only: receipt, owner liveness, and OS registry."""

    config = _read_config_for_status(paths)
    mount = _fabric_mount_status_document(
        paths, enabled=config.native_mount_enabled if config is not None else True
    )
    if args.json:
        _emit({"mount": mount}, True)
    else:
        print("Meshia")
        print(f"  mount       {mount.get('state')} at {mount.get('mount_point')}")
    return 0


def _command_mount_release(args: argparse.Namespace, paths: Paths) -> int:
    """Unmount first, through the runner's own teardown, and prove it with the OS."""

    timeout_seconds = float(args.timeout_seconds)
    if not math.isfinite(timeout_seconds) or timeout_seconds < 0 or timeout_seconds > 300:
        raise InvalidArgument("--timeout-seconds must be between 0 and 300.")
    controller = _service_controller(paths)
    try:
        outcome = release_native_mount(
            paths.home,
            request_shutdown=controller._request_runner_shutdown,
            retry_command=str(args.retry_command),
            timeout_seconds=timeout_seconds,
        )
    except MountHeldError as error:
        # The refusal is structured on stdout so an installer can name the
        # mount point and holders itself; the exact sentence is `error`.
        restored = False
        restore_error: str | None = None
        if error.requested:
            # The runner's shutdown request was consumed: it exits as soon as
            # its teardown finishes. Leaving it at that stranded the owner's
            # node (2026-09-03: installer refused, service stopped, ~/Meshia
            # empty for 3 minutes). Bring the service back before reporting.
            restore = getattr(controller, "restore_after_release", None)
            try:
                if callable(restore):
                    restore()
                    restored = True
                else:
                    restore_error = "the service controller cannot restore the node"
            except (ServiceError, MeshiaNodeError, OSError) as failure:
                restore_error = str(failure)
        document = {
            "mount_point": error.mount_point,
            "released": False,
            "requested": error.requested,
            "restored": restored,
            "restore_error": restore_error,
            "reason": "held",
            "holders": list(error.holders) if error.holders is not None else None,
            "retry_command": error.retry_command,
            "error": str(error),
        }
        if args.json:
            _emit(document, True)
        else:
            print(f"meshia-node: {error}", file=sys.stderr)
            if error.requested and not restored:
                print(
                    "meshia-node: CRITICAL: the node was asked to stop and could not "
                    f"be restarted ({restore_error}); run: meshia-node service restart",
                    file=sys.stderr,
                )
        return 1
    document = {
        "mount_point": outcome.mount_point,
        "released": outcome.released,
        "requested": outcome.requested,
        "reason": outcome.reason,
        "holders": list(outcome.holders) if outcome.holders is not None else None,
    }
    if args.json:
        _emit(document, True)
        return 0
    print("Meshia")
    if outcome.reason == "no_mount":
        print("  mount       no native mount receipt; nothing to release")
    elif outcome.released:
        print(f"  mount       released {outcome.mount_point} ({outcome.reason})")
    else:
        print(
            f"  mount       {outcome.mount_point} is registered but no Meshia node owns it "
            "(stale or foreign); the next service start refuses to stack on it"
        )
    return 0


def command_mount(args: argparse.Namespace, paths: Paths) -> int:
    """Show the resolved native mount backend, optionally persisting a choice."""

    mount_enabled = getattr(args, "mount_enabled", None)
    if getattr(args, "workspace_id", None):
        if args.release or args.probe or args.backend or mount_enabled is not None:
            raise InvalidArgument("Choose project enrollment or mount backend/release/probe controls, not both.")
        from .control_cli import command_mount as connect_project_mount
        return connect_project_mount(args, paths, ControlClient(paths))
    if args.release and args.probe:
        raise InvalidArgument("--release and --probe are mutually exclusive.")
    if (args.release or args.probe) and mount_enabled is not None:
        raise InvalidArgument("Choose mount preferences or release/probe controls, not both.")
    if args.release:
        return _command_mount_release(args, paths)
    if args.probe:
        return _command_mount_probe(args, paths)
    store = ConfigStore(paths)
    config = _read_config_for_status(paths)
    requested = args.backend or (config.mount_backend if config is not None else "auto")
    try:
        selection = select_mount_backend(requested)
        error: str | None = None
    except StateError as failure:
        selection = None
        error = str(failure)
    changed = False
    if args.backend is not None or mount_enabled is not None:
        if config is None:
            raise StateError("Connect this node before choosing a mount preference.")
        if args.backend is not None and error is not None:
            raise StateError(error)
        changed = ((args.backend is not None and config.mount_backend != args.backend)
                   or (mount_enabled is not None and config.native_mount_enabled != mount_enabled))
        if changed:
            def _persist(current: NodeConfig) -> None:
                if args.backend is not None:
                    current.mount_backend = args.backend
                if mount_enabled is not None:
                    current.native_mount_enabled = mount_enabled
            config, _ = store.update(_persist)
    mount = _fabric_mount_status_document(
        paths, enabled=config.native_mount_enabled if config is not None else True
    )
    document = {
        "requested": requested,
        "backend": selection.backend if selection is not None else None,
        "reason": selection.reason if selection is not None else error,
        "app": str(selection.app_path) if selection is not None and selection.app_path else None,
        "extension_state": selection.extension_state if selection is not None else None,
        "approval_notice": fskit_approval_notice(
            selection.extension_state if selection is not None else "disabled"
            if error is not None and "System Settings" in error
            else None
        ) if requested == "fskit" else None,
        "native_mount_enabled": config.native_mount_enabled if config is not None else None,
        "changed": changed,
        "restart_required": bool(changed and mount.get("mounted")),
        "mount": mount,
    }
    if args.json:
        _emit(document, True)
        return 0
    print("Meshia")
    if selection is not None:
        print(f"  backend     {selection.backend} (requested {requested}; {selection.reason})")
    else:
        print(f"  backend     unavailable ({error})")
    if mount.get("mounted"):
        volumes = mount.get("volumes") or []
        if mount.get("backend") == "fskit":
            print(f"  files       {len(volumes)} FSKit volume(s) under {mount.get('mount_point')}")
            for volume in volumes:
                print(f"              {volume.get('name')}  {volume.get('mount_point')}")
        else:
            print(f"  files       mounted at {mount.get('mount_point')} (FUSE-T)")
    if document["restart_required"]:
        print("  next        run `meshia-node service restart` to apply the new backend")
    elif changed:
        print("  next        the service applies the backend on its next start")
    if document["approval_notice"]:
        print(f"  notice      {document['approval_notice']}")
    return 0


def command_compute(args: argparse.Namespace, paths: Paths) -> int:
    from .native_execution import full_available, full_detail
    runtime = _runtime_status_document(paths)
    evidence = runtime.get("workspace_execution") or {
        "ready": False, "policy_supported": None, "reason": "daemon_probe_unavailable",
    }
    ready = full_available()
    report = {"ready": ready, "executor": "native-host" if ready else "unavailable",
              "detail": full_detail(),
              "workspace_execution": evidence["ready"], "workspace_execution_status": evidence,
              "platform": sys.platform, "home": str(Path.home()), "cpu_count": os.cpu_count(),
              "next": "Choose Workspace only or Full computer access when attaching this computer to a workspace."}
    if args.json:
        print(json.dumps(report))
    elif report["ready"]:
        print("Ready: native commands as your OS account, using your installed tools, network and hardware.")
        if evidence["ready"]:
            print("Workspace only: the running node can read its owned workspace mount.")
        elif evidence["reason"] in {"workspace_access_denied", "workspace_access_timeout", "workspace_access_unavailable"}:
            print("Workspace only needs workspace access: the running node could not read its mounted workspace.")
        elif evidence["reason"] == "policy_unavailable":
            print("Workspace only: this OS cannot enforce the required filesystem boundary.")
        else:
            print("Workspace only: waiting for a current read probe from the running node.")
        print(report["next"])
    else:
        print(report["detail"])
        print(report["next"])
    return 0 if report["ready"] else 1


def command_mount_worker(args: argparse.Namespace, paths: Paths) -> int:
    """Run the FUSE mount in this process, driven by an engine over IPC.

    Spawned by ``MountWorkerSupervisor``; not a user-facing command. Keeping it
    a subcommand rather than a separate entry point means the worker inherits
    the same interpreter, packaging and import surface as the engine.
    """

    from .sync_engine_worker import MountWorkerSpec, run_mount_worker

    logger = NodeLogger(path=paths.log_path, quiet=True)
    return run_mount_worker(MountWorkerSpec.from_json(args.spec), logger=logger)


COMMANDS = {
    **{command: command_control for command in CONTROL_COMMANDS},
    "_mount-worker": command_mount_worker,
    "account-cutover": command_account_cutover,
    "mount": command_mount,
    "connect": command_connect,
    "compute": command_compute,
    "status": command_status,
    "open": command_open,
    "conflicts": command_conflicts,
    "disconnect": command_disconnect,
    "forget": command_forget,
    "doctor": command_doctor,
    "mcp": command_mcp,
    "service": command_service,
}


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    if args.command == "help":
        return command_help(args, parser)
    paths = Paths.resolve(args.home)
    # The mount holds one descriptor per in-flight write session; launchd's
    # 256 soft limit is below the session bound. Every command lifts it (a
    # no-op when already high) so the service never hits EMFILE mid-copy.
    raise_file_descriptor_limit()
    try:
        # Reject unsafe host-wide authority before even creating or chmodding
        # the caller-selected state directory. Command-specific checks remain
        # defense in depth for direct Python callers that bypass ``main``.
        assert_safe_node_account()
        if args.command in ("status", "doctor", "open", "mcp", "mount"):
            return COMMANDS[args.command](args, paths)
        ensure_private_dir(paths.home)
        return COMMANDS[args.command](args, paths)
    except KeyboardInterrupt:  # pragma: no cover - interactive
        return 130
    except MeshiaNodeError as error:
        message = {"error": str(error), "code": error.code}
        if args.json:
            print(json.dumps(message, indent=2, sort_keys=True), file=sys.stderr)
        else:
            print(f"{parser.prog}: {error}", file=sys.stderr)
        return 1
    except ServiceError as error:
        message = {"error": str(error), "code": "SERVICE_ERROR"}
        if args.json:
            print(json.dumps(message, indent=2, sort_keys=True), file=sys.stderr)
        else:
            print(f"{parser.prog}: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


__all__ = ["main", "build_parser", "command_help"]
