"""Signed commands run as the node's OS user after an explicit full-access grant.

Files-only attachments accept typed workspace operations. Full attachments also
run native argv commands, with normal host paths, networking and hardware.
Command deadlines and output bounds control lifecycle, not machine access.
"""

from __future__ import annotations

import json
import os
import re
import selectors
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from contextlib import ExitStack
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable, ContextManager, Sequence

from . import confinement, landlock, terminal
from .client import SignedClient
from .command_filesystem import CommandFilesystem
from .config import ACCESS_MODES, DEFAULT_ACCESS_MODE, ConfigStore, Paths
from .errors import (
    AccessRefused,
    Disconnected,
    InvalidTask,
    MeshiaNodeError,
    RemoteError,
    TierRefused,
    UnsafePath,
)
from .log import NULL_LOGGER, NodeLogger
from .sealed_env import check_delivered_subset
from .task_env import (
    EnvironmentRefused,
    apply_workspace_environment,
    requested_names,
    vet_workspace_environment,
)
from .util import (
    UUID_RE,
    b64_standard,
    bounded_int,
    clean,
    ensure_private_dir,
    iso8601,
    json_bytes,
    write_private_file,
)
from .workspace import (
    MAX_HOST_WRITE_BYTES,
    WorkspaceBoundary,
    host_denied_prefixes,
    host_list,
    host_read_file,
    host_write_file,
)

SUPPORTED_COMMANDS = (
    "write_file",
    "read_file",
    "list",
    "python_compile",
    "exec",
    "mcp_call",
    *terminal.TERMINAL_COMMANDS,
)
REMOTE_WORKSPACE_COMMANDS = (
    "write_file", "read_file", "list", "python_compile", "exec", "mcp_call",
)
# A PTY-backed shell is strictly more capable than one argv exec, so everything
# that refuses exec refuses a terminal too — never the other way round.
COMPUTE_ONLY_COMMANDS = ("exec", "mcp_call", *terminal.TERMINAL_COMMANDS)
HOST_SCOPE_COMMANDS = ("read_file", "list", "write_file")
# Interactive terminal primitives remain local-only. A one-shot local stdio MCP
# exchange uses the same signed, bounded native execution lane as exec.
FULL_ACCESS_HOST_COMMANDS = ("write_file",)
CONFINEMENT_UNAVAILABLE = (
    "exec confinement unavailable; use full access, a Landlock-capable Linux kernel, "
    "or Windows integrity-level confinement"
)
MAX_WORKSPACE_WRITE_BYTES = 1_000_000
DEFAULT_MAX_OUTPUT_BYTES = 262_144
MAX_OUTPUT_BYTES_CAP = 1_048_576
DEFAULT_EXEC_TIMEOUT_SECONDS = 60
MAX_EXEC_TIMEOUT_SECONDS = 900
MAX_ARGV_ITEMS = 64
MAX_ARGV_ITEM_BYTES = 4096
MAX_STDIN_BYTES = 1_048_576
# Delivered values at least this long are stripped from a result before it is
# persisted. Matches MIN_SECRET_VALUE_LENGTH in customer-runtime-env-policy.ts.
MIN_REDACTABLE_VALUE_BYTES = 8
REDACTION_PLACEHOLDER = b"[redacted]"
KILL_GRACE_SECONDS = 0.5
# One command may occupy the local worker for the full 15-minute command cap,
# but the signed supervision lane only gives a newly-started worker this small
# handoff window. That preserves the historically synchronous fast-command
# path without letting a slow command delay heartbeat or Fabric maintenance.
COMMAND_WORKER_HANDOFF_SECONDS = 0.1
COMMAND_WORKER_REAP_SECONDS = 8.0
COMMAND_CANCEL_POLL_SECONDS = 0.1
COMMAND_SUPERVISION_SECONDS = 15
COMMAND_SUPERVISION_POLL_SECONDS = 2.0
# How long a terminal command waits for the shell to say something before
# returning. Short enough to stay inside the claim lease, long enough that a
# keystroke and its echo make one round trip instead of two.
TERMINAL_DEFAULT_WAIT_MS = 250
TERMINAL_MAX_WAIT_MS = 10_000
TERMINAL_SETTLE_POLL_SECONDS = 0.01
TERMINAL_COALESCE_SECONDS = 0.03
# Anything not on this list is dropped before a child process starts. Windows
# children additionally need the system plumbing variables without which most
# programs cannot start at all (SystemRoot, ComSpec, PATHEXT).
ENV_ALLOWLIST = ("PATH", "HOME", "LANG", "TERM")
ENV_DEFAULTS = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TERM": "dumb"}
WINDOWS_ENV_ALLOWLIST = (
    "PATH",
    "SYSTEMROOT",
    "WINDIR",
    "COMSPEC",
    "PATHEXT",
    "TEMP",
    "TMP",
    "NUMBER_OF_PROCESSORS",
    "PROCESSOR_ARCHITECTURE",
    "OS",
)
WINDOWS_ENV_DEFAULTS = {
    "PATHEXT": ".COM;.EXE;.BAT;.CMD",
    "OS": "Windows_NT",
}


@dataclass
class CommandOutcome:
    status: str  # "succeeded" | "failed"
    output: bytes | None = None
    exit_code: int | None = None
    truncated: bool = False
    message: str | None = None
    extra: dict[str, Any] | None = None

    def result_payload(self, started_at: str, finished_at: str) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "truncated": self.truncated,
            "started_at": started_at,
            "finished_at": finished_at,
        }
        if self.output is not None:
            payload["output_base64"] = b64_standard(self.output)
        if self.exit_code is not None:
            payload["exit_code"] = self.exit_code
        if self.message:
            payload["message"] = clean(self.message)
        if self.extra:
            payload.update(self.extra)
        return payload


@dataclass(frozen=True)
class PreparedCommand:
    """A command whose credential-bearing preparation is already complete.

    Workspace environment values are fetched on the runner's serial signed
    lane. The local worker receives only this value object and the executor; it
    never receives a :class:`SignedClient` or a transport callback.
    """

    command_type: str
    payload: dict[str, Any]
    scope: str
    environment: tuple[dict[str, str], tuple[str, ...]] | None = None
    remote: bool = False


def scrubbed_environment(home: str) -> dict[str, str]:
    """Minimal allowlisted environment — no tokens, no node configuration."""
    if sys.platform == "win32":
        return _scrubbed_environment_windows(home)
    env = {"HOME": home}
    for name in ENV_ALLOWLIST:
        value = os.environ.get(name)
        if value is not None and "\0" not in value:
            env[name] = value
    for name, fallback in ENV_DEFAULTS.items():
        env.setdefault(name, fallback)
    env["HOME"] = home
    return env


def native_environment() -> dict[str, str]:
    """Use the owner's home and tool paths without copying service credentials."""
    home = str(Path.home())
    env = scrubbed_environment(home)
    if sys.platform == "win32":
        # Full native commands need the ordinary user's application/profile
        # and installed tool locations. Keep service credentials excluded;
        # limited execution redirects writable profile locations afterward.
        for name in ("APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "PROGRAMFILES",
                     "PROGRAMFILES(X86)", "COMMONPROGRAMFILES", "COMMONPROGRAMFILES(X86)",
                     "USERNAME", "USERDOMAIN", "HOMEDRIVE", "HOMEPATH", "ALLUSERSPROFILE",
                     "CUDA_HOME", "CUDA_PATH", "HIP_PATH", "ROCM_PATH", "ONEAPI_ROOT",
                     "CONDA_PREFIX", "VIRTUAL_ENV"):
            value = os.environ.get(name)
            if value and "\0" not in value:
                env[name] = value
    else:
        paths = env["PATH"].split(os.pathsep)
        paths += [str(Path(home) / ".local/bin"), "/opt/homebrew/bin", "/opt/homebrew/sbin",
                  "/usr/local/bin", "/usr/local/sbin", "/usr/bin", "/bin", "/usr/sbin", "/sbin"]
        env["PATH"] = os.pathsep.join(dict.fromkeys(paths))
        for name in ("USER", "LOGNAME", "SHELL", "TMPDIR", "DISPLAY", "WAYLAND_DISPLAY",
                     "XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS", "CUDA_HOME", "CUDA_PATH"):
            value = os.environ.get(name)
            if value and "\0" not in value:
                env[name] = value
    return env


def _scrubbed_environment_windows(home: str) -> dict[str, str]:
    """The Windows allowlist: system plumbing in, node configuration out.

    ``os.environ`` lookups are case-insensitive on Windows, so the allowlist's
    canonical casing is what the child sees. HOME and USERPROFILE are both
    pinned to `home` — programs disagree about which one to honour.
    """
    env: dict[str, str] = {}
    for name in WINDOWS_ENV_ALLOWLIST:
        value = os.environ.get(name)
        if value is not None and "\0" not in value:
            env[name] = value
    system_root = env.get("SYSTEMROOT") or r"C:\Windows"
    env.setdefault("SYSTEMROOT", system_root)
    env.setdefault("WINDIR", system_root)
    env.setdefault("COMSPEC", os.path.join(system_root, "System32", "cmd.exe"))
    env.setdefault("PATH", os.path.join(system_root, "System32") + os.pathsep + system_root)
    for name, fallback in WINDOWS_ENV_DEFAULTS.items():
        env.setdefault(name, fallback)
    env["HOME"] = home
    env["USERPROFILE"] = home
    return env


def run_bounded_subprocess(
    argv: list[str],
    *,
    cwd: str,
    env: dict[str, str],
    timeout_seconds: int | None,
    max_output_bytes: int,
    stdin: bytes | None = None,
    confine: Callable[[], None] | None = None,
    confined_root: str | None = None,
    denied_roots: Sequence[str] = (),
    cancel_event: threading.Event | None = None,
    pass_fds: tuple[int, ...] = (),
    process_owner: Any = None,
) -> tuple[bytes, int, bool, bool]:
    """Run `argv` detached in its own session; return (output, code, truncated, timed_out).

    Output is stdout followed by stderr, capped at `max_output_bytes` in total.
    On timeout the whole process **group** (POSIX) or **Job Object** (Windows)
    is killed, so orphaned children die with the parent.

    Confinement is platform-shaped. `confined_root` names the only writable
    tree and picks the platform mechanism: Landlock in the forked child on
    Linux, a low-integrity token on Windows (:mod:`meshia_node.winexec`).
    `denied_roots` names trees the child must not even *read* — the node's own
    state directory, so a task cannot exfiltrate the device key that
    authenticates this host. Under the stated model the owner already has that
    key; what this stops is a hostile or prompt-injected task sending it
    somewhere else. Landlock-only: the Windows low-integrity token is a
    no-write-up control and does not restrict reads (see the caveat on
    :meth:`CommandExecutor._node_state_roots`).
    `confine` remains the POSIX-only escape hatch — a callable run between
    ``fork`` and ``exec`` — for callers and tests that need a custom step.
    Either way it is **not** best effort: a confinement failure means the child
    never runs, which is what makes `limited` access fail closed.
    """
    if cancel_event is not None and cancel_event.is_set():
        raise InvalidTask("The command was cancelled because the node is shutting down.")
    if timeout_seconds is None and (process_owner is None or cancel_event is None):
        raise InvalidTask("A renewable app requires retained process ownership and cancellation.")
    if sys.platform == "win32":
        if pass_fds:
            raise InvalidTask("Passing trusted kernel policy descriptors is POSIX-only.")
        if confine is not None:
            raise InvalidTask("A preexec confinement callable is POSIX-only.")
        from . import winexec  # imported here so POSIX never loads the Win32 FFI

        return winexec.run_bounded_subprocess(
            argv,
            cwd=cwd,
            env=env,
            timeout_seconds=timeout_seconds,
            max_output_bytes=max_output_bytes,
            stdin=stdin,
            confined_root=confined_root,
            cancel_event=cancel_event,
            **({"process_owner": process_owner} if process_owner is not None else {}),
        )
    if confine is None and confined_root is not None:
        confine = landlock.confiner(confined_root, denied_roots)
    # CPython flattens any preexec_fn exception into a bare "Exception occurred in
    # preexec_fn.", so the child reports *why* confinement failed over its own
    # pipe. This also tells the two failure kinds apart: a message means the
    # confinement step failed, silence means the spawn failed for other reasons.
    # The write end survives long enough because CPython runs preexec_fn before
    # it closes the child's inherited descriptors.
    status_read, status_write = os.pipe() if confine is not None else (-1, -1)

    def _child_setup() -> None:  # pragma: no cover - runs in the forked child
        # Native compute uses the OS account's resource limits.
        if confine is not None:
            try:
                confine()
            except BaseException as error:
                try:
                    os.write(status_write, str(error).encode("utf-8", "replace")[:512])
                except OSError:
                    pass
                raise

    process: subprocess.Popen[bytes] | None = None
    spawn_error: BaseException | None = None
    try:
        try:
            process = subprocess.Popen(  # noqa: S603 - argv list, never a shell
                argv,
                cwd=cwd,
                env=env,
                stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                start_new_session=True,
                preexec_fn=_child_setup if confine is not None else None,
                close_fds=True,
                **({"pass_fds": pass_fds} if pass_fds else {}),
            )
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            spawn_error = error
        if status_write >= 0:
            # Drop the parent's write end before reading, or a child that failed
            # without reporting anything would leave the read blocking forever.
            os.close(status_write)
            status_write = -1
        if spawn_error is not None:
            reason = _status_reason(status_read)
            if reason:
                raise AccessRefused(
                    f"{CONFINEMENT_UNAVAILABLE} ({clean(reason)})"
                ) from spawn_error
            raise InvalidTask(
                f"The command could not be started: {clean(str(spawn_error))}"
            ) from spawn_error
    finally:
        for descriptor in (status_read, status_write):
            if descriptor >= 0:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
    assert process is not None  # narrowed: spawn_error would have raised
    if process_owner is not None:
        try:
            process_owner.on_started(process)
        except BaseException:
            process_owner.close()
            _terminate_group(process)
            for stream in (process.stdin, process.stdout, process.stderr):
                if stream is not None:
                    stream.close()
            raise

    timed_out = False
    cancelled = False
    deadline = float("inf") if timeout_seconds is None else time.monotonic() + timeout_seconds
    buffers = {"out": bytearray(), "err": bytearray()}
    overflow = False
    input_offset = 0
    # Nonblocking pipes keep cancellation bounded even when a deliberately
    # detached program retains stdout or never consumes its stdin.
    with selectors.DefaultSelector() as selector:
        for stream, name in ((process.stdout, "out"), (process.stderr, "err")):
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, name)
        if stdin and process.stdin is not None:
            os.set_blocking(process.stdin.fileno(), False)
            selector.register(process.stdin, selectors.EVENT_WRITE, "in")
        elif process.stdin is not None:
            process.stdin.close()
        drain_deadline = None
        try:
            while selector.get_map() or process.poll() is None:
                now = time.monotonic()
                if cancel_event is not None and cancel_event.is_set():
                    cancelled = True
                    _terminate_group(process)
                    break
                if now >= deadline:
                    timed_out = True
                    _terminate_group(process)
                    break
                if process.poll() is not None:
                    if drain_deadline is None:
                        drain_deadline = min(deadline, now + 1.0)
                    elif now >= drain_deadline:
                        _terminate_group(process)
                        break
                for key, _events in selector.select(min(COMMAND_CANCEL_POLL_SECONDS, deadline - now)):
                    stream, name = key.fileobj, key.data
                    try:
                        if name == "in":
                            input_offset += os.write(stream.fileno(), stdin[input_offset:input_offset + 65536])
                            if input_offset >= len(stdin):
                                selector.unregister(stream)
                                stream.close()
                        else:
                            chunk = os.read(stream.fileno(), 65536)
                            if not chunk:
                                selector.unregister(stream)
                                stream.close()
                            else:
                                remaining = max_output_bytes - len(buffers[name])
                                buffers[name].extend(chunk[:remaining])
                                overflow |= len(chunk) > remaining
                    except BlockingIOError:
                        continue
                    except (BrokenPipeError, OSError):
                        selector.unregister(stream)
                        stream.close()
        finally:
            if process_owner is not None:
                process_owner.close()
            for key in list(selector.get_map().values()):
                selector.unregister(key.fileobj)
                key.fileobj.close()
            # Commands own their session's foreground and job-control groups.
            # Full-access owners can explicitly create independent OS services;
            # revoking a command cannot undo those machine-wide side effects.
            _terminate_group(process)
    out, err = bytes(buffers["out"]), bytes(buffers["err"])
    if cancelled:
        raise InvalidTask("The command was cancelled because the node is shutting down.")
    combined = (out + err)[:max_output_bytes]
    truncated = overflow or len(out) + len(err) > max_output_bytes
    return combined, int(process.returncode if process.returncode is not None else -1), truncated, timed_out


def _status_reason(read_fd: int) -> str:
    """The child's confinement failure reason, or "" if it never sent one."""
    if read_fd < 0:
        return ""
    try:
        return os.read(read_fd, 512).decode("utf-8", "replace").strip()
    except OSError:  # pragma: no cover - defensive
        return ""


def _terminate_group(process: subprocess.Popen[bytes]) -> None:
    # start_new_session makes the child's PID its group ID. Keep that identity
    # after the leader exits: getpgid(pid) then fails even if descendants live.
    group_id = process.pid
    for send in (signal.SIGTERM, signal.SIGKILL):
        terminal._signal_session(group_id, send)
        try:
            os.killpg(group_id, send)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                process.send_signal(send)
            except OSError:
                pass
        if send == signal.SIGTERM:
            deadline = time.monotonic() + KILL_GRACE_SECONDS
            while time.monotonic() < deadline:
                process.poll()
                try:
                    os.killpg(group_id, 0)
                except ProcessLookupError:
                    break
                except PermissionError:
                    break
                time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
        else:
            try:
                process.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                pass


class CommandExecutor:
    """Executes one command envelope. Holds no credentials and no node config.

    ``access`` is the live enforcement copy of the owner's access mode. It is
    mutable on purpose: :meth:`set_access` is what the heartbeat loop calls when
    the control plane reports a dashboard toggle, so the very next command is
    judged against the new mode without a reconnect.

    ``environment_provider`` is how workspace environment variables reach a
    task, and it is deliberately a bare callable: ``names -> values``. The
    executor can ask for a named set and receives values back, but it holds no
    signing key, no config and no transport, so the "no credentials" property
    above still holds literally. Absent a provider the node simply cannot
    deliver workspace variables, and any command that asks for them is refused
    rather than silently run without them — a task that quietly loses its
    credentials is worse than one that fails loudly.
    """

    def __init__(
        self,
        workspace: WorkspaceBoundary,
        tier: str = "compute",
        paths: Paths | None = None,
        python: str | None = None,
        access: str = DEFAULT_ACCESS_MODE,
        environment_provider: Callable[[list[str]], dict[str, str]] | None = None,
        command_filesystem: Callable[[], ContextManager[CommandFilesystem]] | None = None,
        native_access: bool = False,
        native_execution_readiness: Callable[[], bool] | None = None,
    ) -> None:
        self.workspace = workspace
        self.tier = tier
        self.paths = paths
        self.python = python or _default_python()
        self._denied = host_denied_prefixes(paths.home) if paths else ()
        self.access = DEFAULT_ACCESS_MODE
        self.set_access(access)
        self.environment_provider = environment_provider
        self.command_filesystem = command_filesystem
        self.native_access = native_access
        # False means only a known transient publication fence. Authority and
        # other recovery failures raise; this probe never opens an OS root.
        self.native_execution_readiness = native_execution_readiness
        self._command_filesystem: CommandFilesystem | None = None
        self.terminals = terminal.TerminalRegistry()
        self._execution_lock = threading.Lock()
        self._active_cancel: threading.Event | None = None
        self._closed = False
        # The shell argv, overridable so tests can drive a deterministic program
        # through the same PTY plumbing a real shell uses.
        self.shell: list[str] = terminal.default_shell()

    def close(self) -> None:
        """Cancel the local command and tear down every PTY, idempotently."""
        with self._execution_lock:
            self._closed = True
            active_cancel = self._active_cancel
        if active_cancel is not None:
            active_cancel.set()
        self.terminals.close_all()

    def cancel_current(self) -> None:
        """Signal an active command without waiting in a signal handler."""
        with self._execution_lock:
            active_cancel = self._active_cancel
        if active_cancel is not None:
            active_cancel.set()

    def set_access(self, access: str) -> None:
        """Adopt an access mode; anything unrecognised falls back to files."""
        self.access = access if access in ACCESS_MODES else DEFAULT_ACCESS_MODE

    # ---------------------------------------------------------------- dispatch

    def prepare(self, command_type: str, payload: dict[str, Any]) -> PreparedCommand:
        """Validate a command and fetch any signed environment on the caller lane."""
        if command_type not in SUPPORTED_COMMANDS:
            raise InvalidTask(f"The command type {clean(str(command_type), 32)!r} is not supported by this node.")
        if not isinstance(payload, dict):
            raise InvalidTask("Command payload must be a JSON object.")
        scope = payload.get("scope", "workspace")
        if scope not in ("workspace", "host"):
            raise InvalidTask("scope must be 'workspace' or 'host'.")
        if self.tier != "compute":
            if command_type in COMPUTE_ONLY_COMMANDS:
                raise TierRefused(
                    f"This node runs in the personal tier and refuses {command_type} locally."
                )
            if scope == "host":
                raise TierRefused("This node runs in the personal tier and refuses host-scope reads.")
        if scope == "host":
            if command_type not in HOST_SCOPE_COMMANDS:
                raise TierRefused(
                    "Host scope supports read_file, list and write_file only."
                )
            if command_type in FULL_ACCESS_HOST_COMMANDS and self.access != "full":
                raise AccessRefused(
                    "This node runs in limited access: host-scope writes require full access."
                )

        if command_type == "mcp_call":
            # Refuse remote/auth-shaped argv before fetching any named value.
            from .mcp_local import build_request
            build_request(payload)
        environment = (
            self._prepare_task_environment(payload)
            if command_type in ("exec", "mcp_call")
            else None
        )
        return PreparedCommand(
            command_type=command_type,
            payload=dict(payload),
            scope=scope,
            environment=environment,
        )

    def prepare_remote(self, command_type: str, payload: dict[str, Any]) -> PreparedCommand:
        """Apply the attachment mode before local dispatch."""
        if command_type not in REMOTE_WORKSPACE_COMMANDS:
            raise TierRefused("Connected hosts accept workspace-file and workspace-compute commands only.")
        if not isinstance(payload, dict):
            raise InvalidTask("Command payload must be a JSON object.")
        if "scope" in payload:
            raise TierRefused("Connected-host paths are always inside the mounted workspace; scope is not accepted.")
        if command_type in ("exec", "mcp_call"):
            if self.tier != "compute":
                raise TierRefused("This node tier does not permit workspace compute.")
            if self.access not in ("limited", "full"):
                raise AccessRefused("This attachment is connected for workspace files only.")
            if not self.native_access:
                raise AccessRefused("The owner must grant Workspace only or Full access before native execution.")
            if self.access == "limited":
                from .native_execution import available, detail
                if not available():
                    raise AccessRefused(detail())
            else:
                from .native_execution import full_available, full_detail
                if not full_available():
                    raise AccessRefused(full_detail())
        return replace(self.prepare(command_type, payload), remote=True)

    def execute(self, command_type: str, payload: dict[str, Any]) -> CommandOutcome:
        return self.execute_prepared(self.prepare(command_type, payload))

    def execute_prepared(self, command: PreparedCommand) -> CommandOutcome:
        """Execute a prepared command with one shutdown-cancellable local slot."""
        cancel_event = threading.Event()
        with self._execution_lock:
            if self._closed:
                raise InvalidTask("The node is shutting down and cannot start another command.")
            if self._active_cancel is not None:
                raise InvalidTask("Another local command is already running.")
            self._active_cancel = cancel_event

        handler = {
            "write_file": self._write_file,
            "read_file": self._read_file,
            "list": self._list,
            "python_compile": self._python_compile,
            "exec": self._exec,
            "mcp_call": self._mcp_call,
            "terminal_open": self._terminal_open,
            "terminal_input": self._terminal_input,
            "terminal_poll": self._terminal_poll,
            "terminal_resize": self._terminal_resize,
            "terminal_close": self._terminal_close,
        }[command.command_type]
        lease = ExitStack()
        try:
            if cancel_event.is_set():
                raise InvalidTask("The command was cancelled because the node is shutting down.")
            if (command.scope == "workspace" and self.command_filesystem is not None
                    and command.command_type not in (
                        "terminal_input", "terminal_poll", "terminal_resize", "terminal_close"
                    )):
                self._command_filesystem = lease.enter_context(self.command_filesystem())
                if self._command_filesystem is None:
                    raise InvalidTask("The shared command filesystem is unavailable.")
            if command.command_type in ("write_file", "read_file", "list"):
                return handler(command.payload, command.scope)  # type: ignore[call-arg]
            if command.command_type == "python_compile":
                return handler(command.payload, cancel_event)  # type: ignore[call-arg]
            if command.command_type in ("exec", "mcp_call"):
                assert command.environment is not None
                if command.remote:
                    if command.command_type == "exec":
                        return self._exec(command.payload, command.environment, cancel_event, native=True)
                    return self._mcp_call(
                        command.payload, command.environment, cancel_event, native=True
                    )
                return handler(command.payload, command.environment, cancel_event)  # type: ignore[call-arg]
            return handler(command.payload)  # type: ignore[call-arg]
        finally:
            try:
                lease.close()
            finally:
                self._command_filesystem = None
                with self._execution_lock:
                    if self._active_cancel is cancel_event:
                        self._active_cancel = None

    @property
    def _files(self) -> CommandFilesystem | WorkspaceBoundary:
        """The task's leased shared namespace, or legacy standalone boundary."""
        return self._command_filesystem if self._command_filesystem is not None else self.workspace

    # -------------------------------------------------------------- operations

    def _write_file(self, payload: dict[str, Any], scope: str = "workspace") -> CommandOutcome:
        content = payload.get("content")
        if not isinstance(content, str):
            raise InvalidTask("write_file content must be a string.")
        data = content.encode("utf-8")
        limit = MAX_HOST_WRITE_BYTES if scope == "host" else MAX_WORKSPACE_WRITE_BYTES
        if len(data) > limit:
            raise InvalidTask(f"write_file content must be at most {limit} bytes.")
        expected = payload.get("expected_sha256")
        if expected is not None and not isinstance(expected, str):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        if scope == "host":
            # Reachable only in `full` access — `execute` has already refused it
            # for `limited` and for the personal tier.
            host_write_file(
                str(payload.get("path", "")),
                data,
                self._denied,
                expected_sha256=expected,
            )
            return CommandOutcome(
                status="succeeded", extra={"bytes_written": len(data), "scope": "host"}
            )
        receipt = self._files.write_file(
            str(payload.get("path", "")),
            data,
            create_parents=payload.get("create_parents") is True,
            overwrite=True,
            expected_sha256=expected,
        )
        return CommandOutcome(
            status="succeeded", extra={
                "bytes_written": len(data), "scope": "workspace",
                **(receipt or {}),
                **({"filesystem_journaled": True} if self._command_filesystem is not None else {}),
            }
        )

    def _read_file(self, payload: dict[str, Any], scope: str) -> CommandOutcome:
        max_bytes = bounded_int(payload.get("max_bytes"), 1, 1_000_000, DEFAULT_MAX_OUTPUT_BYTES)
        path = str(payload.get("path", ""))
        if scope == "host":
            data, truncated = host_read_file(path, max_bytes, self._denied)
        else:
            data, truncated = self._files.read_file(path, max_bytes)
        return CommandOutcome(
            status="succeeded", output=data, truncated=truncated, extra={"scope": scope}
        )

    def _list(self, payload: dict[str, Any], scope: str) -> CommandOutcome:
        max_entries = bounded_int(payload.get("max_entries"), 1, 10_000, 1_000)
        raw_path = payload.get("path")
        path = "." if raw_path in (None, "") else str(raw_path)
        if scope == "host":
            entries, truncated = host_list(path, max_entries, self._denied)
        else:
            entries, truncated = self._files.list(
                path, max_entries, recursive=payload.get("recursive") is True
            )
        return CommandOutcome(
            status="succeeded",
            output=json.dumps(entries).encode("utf-8"),
            truncated=truncated,
            extra={"scope": scope, "entry_count": len(entries)},
        )

    def _python_compile(
        self, payload: dict[str, Any], cancel_event: threading.Event
    ) -> CommandOutcome:
        path = str(payload.get("path", ""))
        if not path.endswith(".py"):
            raise InvalidTask("python_compile.path must name a Python file.")
        timeout_seconds = bounded_int(payload.get("timeout_seconds"), 1, 30, 30)
        max_output_bytes = bounded_int(
            payload.get("max_output_bytes"), 1, DEFAULT_MAX_OUTPUT_BYTES, DEFAULT_MAX_OUTPUT_BYTES
        )
        source, truncated = self._files.read_file(path, 1_000_000)
        if truncated:
            raise InvalidTask("python_compile source exceeds the 1 MB limit.")
        # One top-level scratch directory per compile: `remove_tree` then leaves
        # the workspace exactly as it found it, even with compiles in flight.
        scratch = f".meshia-compile-{uuid.uuid4().hex}"
        self.workspace.write_file(f"{scratch}/source.py", source, create_parents=True)
        try:
            output, exit_code, output_truncated, timed_out = run_bounded_subprocess(
                [self.python, "-I", "-B", "-m", "py_compile", "source.py"],
                cwd=str(self.workspace.absolute(scratch)),
                env=scrubbed_environment(str(self.workspace.absolute(scratch))),
                timeout_seconds=timeout_seconds,
                max_output_bytes=max_output_bytes,
                cancel_event=cancel_event,
            )
        finally:
            self.workspace.remove_tree(scratch)
        if timed_out:
            raise InvalidTask("The task exceeded its execution deadline.")
        return CommandOutcome(
            status="succeeded" if exit_code == 0 else "failed",
            output=output,
            exit_code=exit_code,
            truncated=output_truncated,
            message=None if exit_code == 0 else "python_compile reported a non-zero exit status.",
        )

    def _exec(
        self,
        payload: dict[str, Any],
        prepared_environment: tuple[dict[str, str], tuple[str, ...]],
        cancel_event: threading.Event,
        *,
        native: bool = False,
    ) -> CommandOutcome:
        argv = payload.get("argv")
        if not isinstance(argv, list) or not argv or len(argv) > MAX_ARGV_ITEMS:
            raise InvalidTask("exec.argv must be a non-empty list of at most 64 strings.")
        for item in argv:
            if not isinstance(item, str) or "\0" in item or len(item.encode("utf-8")) > MAX_ARGV_ITEM_BYTES:
                raise InvalidTask("exec.argv entries must be NUL-free strings under 4 KiB.")
        raw_cwd = payload.get("cwd")
        if raw_cwd is not None and (not isinstance(raw_cwd, str) or "\0" in raw_cwd):
            raise InvalidTask("exec.cwd must be a NUL-free path.")
        timeout_seconds = bounded_int(
            payload.get("timeout_seconds"), 1, MAX_EXEC_TIMEOUT_SECONDS, DEFAULT_EXEC_TIMEOUT_SECONDS
        )
        max_output_bytes = bounded_int(
            payload.get("max_output_bytes"), 1, MAX_OUTPUT_BYTES_CAP, DEFAULT_MAX_OUTPUT_BYTES
        )
        raw_stdin = payload.get("stdin")
        if raw_stdin is not None and not isinstance(raw_stdin, str):
            raise InvalidTask("exec.stdin must be a string when present.")
        stdin = raw_stdin.encode("utf-8") if isinstance(raw_stdin, str) else None
        if stdin is not None and len(stdin) > MAX_STDIN_BYTES:
            raise InvalidTask("exec.stdin must be at most 1 MiB.")

        delivered, secrets = prepared_environment
        if native:
            if not self.native_access or self.access not in ("limited", "full"):
                raise AccessRefused("Native execution requires an owner compute grant.")
            from .native_command import command_argv, command_stdin
            root = None
            if self.access != "full" or not Path(raw_cwd or ".").expanduser().is_absolute():
                # Shared adapters return a verified lexical route. A standalone
                # boundary was already pinned before this command was admitted.
                root = str(self._files.native_execution_root
                           if self._command_filesystem is not None else self.workspace.root)
            owner = getattr(self, "process_owner", None)
            try:
                observer = owner.prepare_native(root=root, access=self.access) if owner is not None else None
                output, exit_code, truncated, timed_out = run_bounded_subprocess(
                    command_argv(argv, root=root, cwd=raw_cwd or ".", access=self.access,
                                 **({"observer_fd": observer} if observer is not None else {})),
                    # Delivered variables can control dyld/ld and therefore must
                    # not affect the trusted helper before it installs OS policy.
                    cwd=os.path.abspath(os.sep), env=native_environment(),
                    # Only the in-memory app owner may select a renewable
                    # lifetime. User exec payloads retain their finite cap.
                    timeout_seconds=None if owner is not None else timeout_seconds, max_output_bytes=max_output_bytes,
                    stdin=command_stdin(delivered, stdin), cancel_event=cancel_event,
                    **({"process_owner": owner} if owner is not None else {}),
                    **({"pass_fds": (observer,)} if observer is not None else {}),
                )
            finally:
                if owner is not None:
                    owner.close()
        else:
            cwd = self._files.absolute(raw_cwd or ".", allow_root=True)
            if not cwd.is_dir():
                raise UnsafePath("exec.cwd must be an existing directory.")
            environment = apply_workspace_environment(
                scrubbed_environment(str(self._files.root)), delivered
            )
            output, exit_code, truncated, timed_out = run_bounded_subprocess(
                argv, cwd=str(cwd), env=environment, timeout_seconds=timeout_seconds,
                max_output_bytes=max_output_bytes, stdin=stdin,
                confined_root=None if native else self._confined_root(),
                denied_roots=() if native else self._node_state_roots(), cancel_event=cancel_event,
            )
        if timed_out:
            return self._redacted(CommandOutcome(
                status="failed",
                output=output,
                exit_code=exit_code,
                truncated=truncated,
                message="The command exceeded its timeout and its process session was stopped.",
                extra={"timed_out": True},
            ), secrets)
        return self._redacted(CommandOutcome(
            status="succeeded" if exit_code == 0 else "failed",
            output=output,
            exit_code=exit_code,
            truncated=truncated,
            message=None if exit_code == 0 else f"The command exited with status {exit_code}.",
            extra={"timed_out": False, **({"execution_scope": "host" if self.access == "full" else "workspace", "filesystem_publication": "not_checked"}
                if native else {})},
        ), secrets)

    # ------------------------------------------------------------ environment

    def task_environment(self, payload: dict[str, Any]) -> dict[str, str]:
        """The scrub baseline, plus exactly the workspace variables asked for."""
        delivered, _secrets = self._prepare_task_environment(payload)
        return apply_workspace_environment(
            scrubbed_environment(str(self._files.root)), delivered
        )

    def _prepare_task_environment(
        self, payload: dict[str, Any]
    ) -> tuple[dict[str, str], tuple[str, ...]]:
        """Fetch vetted additions and values that must not persist.

        A command opts in by listing names in ``payload["env"]``. No list means
        no delivery and no round trip — the overwhelmingly common case stays
        exactly as it was, on the scrubbed allowlist alone.

        The second element is what :meth:`_redacted` needs: a value that reached
        a child is a value the child can print, and anything a child prints is
        persisted by :class:`CompletionOutbox`.
        """
        names = requested_names(payload.get("env"))
        if not names:
            return {}, ()
        if self.environment_provider is None:
            raise EnvironmentRefused(
                "This node cannot deliver workspace environment variables "
                "(no authenticated provider is configured)."
            )
        delivered = self.environment_provider(names)
        # Both checks run at the unsealing boundary too. Repeating them here is
        # what makes them properties of *injection* rather than of one provider:
        # a caller that supplies its own provider still cannot inject a reserved
        # name, nor more names than the command declared.
        vetted = vet_workspace_environment(delivered)
        check_delivered_subset(vetted, names)
        return vetted, tuple(vetted.values())

    @staticmethod
    def _redacted(outcome: CommandOutcome, secrets: tuple[str, ...]) -> CommandOutcome:
        """Strip delivered values out of a result before anything persists it.

        A task's output is written to ``~/.meshia/outbox`` before it is sent, and
        it stays there until the control plane acknowledges it — indefinitely if
        the flush keeps failing. So a task that echoes its own environment (a
        verbose client, a stack trace, plain ``env``) turns a value that was
        meant to live in memory for one command into durable at-rest state on a
        machine we do not control. Removing the literal here is what keeps the
        "never persisted" property true rather than aspirational.

        Deliberately literal and best-effort. It catches the value as delivered;
        it cannot catch one the task transformed first (base64, a hash, split
        across lines). Values under :data:`MIN_REDACTABLE_VALUE_BYTES` are left
        alone — redacting a two-character value would shred unrelated output for
        no security gain, and a value that short is not a secret.
        """
        if not secrets or outcome.output is None and not outcome.message:
            return outcome
        # Longest first, so a value that contains another is replaced whole.
        targets = sorted(
            {value for value in secrets if len(value.encode("utf-8")) >= MIN_REDACTABLE_VALUE_BYTES},
            key=len,
            reverse=True,
        )
        if not targets:
            return outcome
        output = outcome.output
        if output is not None:
            for value in targets:
                output = output.replace(value.encode("utf-8"), REDACTION_PLACEHOLDER)
        message = outcome.message
        if message:
            for value in targets:
                message = message.replace(value, REDACTION_PLACEHOLDER.decode("ascii"))
        return replace(outcome, output=output, message=message)

    # -------------------------------------------------------------- local MCP

    def _mcp_call(
        self,
        payload: dict[str, Any],
        prepared_environment: tuple[dict[str, str], tuple[str, ...]],
        cancel_event: threading.Event,
        *,
        native: bool = False,
    ) -> CommandOutcome:
        """One JSON-RPC exchange with a **local stdio** MCP server.

        The manager stays on the control plane. This is the transport half and
        nothing more: it launches the argv the server side chose, speaks one
        initialize/call exchange, and hands back the response frame. It cannot
        reach a remote MCP server or carry a credential value in argv. Named
        workspace variables use the same sealed task-environment path as exec;
        see :mod:`meshia_node.mcp_local` for the boundary.
        """
        from . import mcp_local

        request = mcp_local.build_request(payload)
        delivered, secrets = prepared_environment
        if native:
            if not self.native_access or self.access not in ("limited", "full"):
                raise AccessRefused("Native MCP execution requires an owner compute grant.")
            from .native_command import command_argv, command_stdin
            raw_cwd = request.cwd or "."
            root = None
            if self.access != "full" or not Path(raw_cwd).expanduser().is_absolute():
                root = str(self._files.native_execution_root
                           if self._command_filesystem is not None else self.workspace.root)
            output, exit_code, truncated, timed_out = run_bounded_subprocess(
                command_argv(request.client_argv(), root=root, cwd=raw_cwd, access=self.access),
                cwd=os.path.abspath(os.sep),
                env=native_environment(),
                timeout_seconds=request.timeout_seconds,
                max_output_bytes=request.max_output_bytes,
                stdin=command_stdin(delivered, request.client_stdin()),
                cancel_event=cancel_event,
            )
        else:
            environment = apply_workspace_environment(
                scrubbed_environment(str(self._files.root)), delivered
            )
            cwd = self._files.absolute(request.cwd or ".", allow_root=True)
            if not cwd.is_dir():
                raise UnsafePath("mcp_call.cwd must be an existing directory inside the workspace.")
            output, exit_code, truncated, timed_out = run_bounded_subprocess(
                request.client_argv(),
                cwd=str(cwd),
                env=environment,
                timeout_seconds=request.timeout_seconds,
                max_output_bytes=request.max_output_bytes,
                stdin=request.client_stdin(),
                confined_root=self._confined_root(),
                cancel_event=cancel_event,
            )
        if timed_out:
            return self._redacted(CommandOutcome(
                status="failed",
                output=output,
                exit_code=exit_code,
                truncated=truncated,
                message="The MCP server exceeded its timeout and its process group was killed.",
                extra={"timed_out": True, "mcp_method": request.method},
            ), secrets)
        return self._redacted(
            mcp_local.interpret_response(
                output, exit_code=exit_code, truncated=truncated, method=request.method
            ),
            secrets,
        )

    # ---------------------------------------------------------------- terminal

    def _terminal_environment(self) -> dict[str, str]:
        """The exec allowlist, with a terminfo entry a PTY can actually use.

        Everything :func:`scrubbed_environment` withholds from an exec'd child —
        tokens, node configuration, the owner's own secrets — is withheld here
        too. ``TERM`` is the single deliberate difference: an argv exec gets
        ``dumb`` because it has no terminal, and a PTY needs a real one.
        """
        env = scrubbed_environment(str(self._files.root))
        env["TERM"] = "xterm-256color"
        return env

    def _node_state_roots(self) -> tuple[str, ...]:
        """Trees a confined child must not read: the node's own state.

        This is where the device private key lives. Nothing in the environment
        carries the node's credential, and this keeps the *filesystem* route
        shut as well, so neither a shell nor an argv exec can read the key that
        authenticates this host to the control plane.

        **Linux only.** It is enforced by a Landlock rule, so it applies wherever
        `limited` access is actually enforceable. Windows confinement is a
        low-integrity token, which is a no-write-*up* control: a Low child still
        reads Medium-labeled files, and it runs as the same user, so the state
        directory's owner-only DACL does not stop it either. Closing that would
        need a deny ACE for the Low mandatory-label SID on the state directory —
        real, but new Windows code, and not what this deny list does today.
        """
        return (str(self.paths.home),) if self.paths else ()

    def _terminal_confine(self) -> tuple[Callable[[], None] | None, str | None]:
        """(preexec confiner, confined root) for a PTY in the current access mode.

        Same rule as ``exec``: `full` runs unconfined because the owner said the
        machine is theirs; `limited` confines to the workspace or refuses to
        start a shell at all. A promise we cannot keep is not a promise.
        """
        if self.access == "full":
            return None, None
        if not confinement.available():
            raise AccessRefused(f"{CONFINEMENT_UNAVAILABLE} ({confinement.detail()})")
        root = str(self._files.root)
        if sys.platform == "win32":
            # winpty applies the low-integrity token itself, the same way
            # winexec does for a one-shot exec.
            return None, root
        return landlock.confiner(root, self._node_state_roots()), root

    def _terminal_session(self, payload: dict[str, Any]) -> terminal.TerminalSession:
        terminal_id = terminal.normalize_terminal_id(payload.get("terminal_id"))
        return self.terminals.require(terminal_id)

    def _terminal_result(
        self,
        session: terminal.TerminalSession,
        terminal_id: str,
        *,
        include_history: bool = False,
    ) -> CommandOutcome:
        """Drain buffered output into pod-shaped frames.

        Each frame is exactly what the pod would have pushed over its
        WebSocket, so a relay forwards them without reshaping anything.
        """
        frames: list[dict[str, Any]] = []
        if include_history:
            history = session.history()
            if history:
                frames.append(terminal.history_frame(terminal_id, history))
        data, dropped = session.drain()
        if data:
            frames.append(terminal.output_frame(terminal_id, data))
        return CommandOutcome(
            status="succeeded",
            extra={
                "terminal_id": terminal_id,
                "frames": frames,
                "running": session.is_running(),
                "exit_code": session.exit_code(),
                "dropped_bytes": dropped,
            },
        )

    def _terminal_open(self, payload: dict[str, Any]) -> CommandOutcome:
        terminal_id = terminal.normalize_terminal_id(payload.get("terminal_id"))
        if not terminal.available():
            raise InvalidTask(f"This host cannot open a terminal ({terminal.detail()}).")
        cols = bounded_int(payload.get("cols"), 1, terminal.MAX_DIMENSION, terminal.DEFAULT_COLS)
        rows = bounded_int(payload.get("rows"), 1, terminal.MAX_DIMENSION, terminal.DEFAULT_ROWS)
        raw_cwd = payload.get("cwd")
        # A payload cwd is resolved INSIDE the workspace by the same containment
        # checks as any write; a shell cannot be started outside it.
        cwd = self._files.absolute("." if raw_cwd in (None, "") else str(raw_cwd), allow_root=True)
        if not cwd.is_dir():
            raise UnsafePath("terminal cwd must be an existing directory inside the workspace.")
        confine, confined_root = self._terminal_confine()

        def build() -> terminal.TerminalSession:
            return terminal.TerminalSession(
                terminal_id=terminal_id,
                cwd=str(cwd),
                env=self._terminal_environment(),
                argv=list(self.shell),
                confine=confine,
                confined_root=confined_root,
                cols=cols,
                rows=rows,
            )

        session = self.terminals.open(terminal_id, build)
        return self._terminal_result(session, terminal_id, include_history=True)

    def _terminal_input(self, payload: dict[str, Any]) -> CommandOutcome:
        data = payload.get("data")
        if data is None:
            data = ""
        if not isinstance(data, str):
            raise InvalidTask("terminal_input.data must be a string.")
        terminal_id = terminal.normalize_terminal_id(payload.get("terminal_id"))
        session = self.terminals.require(terminal_id)
        session.write(data)
        # A shell needs a moment to echo and respond; without it every input
        # would return empty and the caller would have to poll for its own echo.
        self._terminal_settle(session, payload)
        return self._terminal_result(session, terminal_id)

    def _terminal_poll(self, payload: dict[str, Any]) -> CommandOutcome:
        terminal_id = terminal.normalize_terminal_id(payload.get("terminal_id"))
        session = self.terminals.require(terminal_id)
        self._terminal_settle(session, payload)
        return self._terminal_result(session, terminal_id)

    def _terminal_resize(self, payload: dict[str, Any]) -> CommandOutcome:
        terminal_id = terminal.normalize_terminal_id(payload.get("terminal_id"))
        session = self.terminals.require(terminal_id)
        session.resize(
            bounded_int(payload.get("cols"), 1, terminal.MAX_DIMENSION, session.cols),
            bounded_int(payload.get("rows"), 1, terminal.MAX_DIMENSION, session.rows),
        )
        return self._terminal_result(session, terminal_id)

    def _terminal_close(self, payload: dict[str, Any]) -> CommandOutcome:
        terminal_id = terminal.normalize_terminal_id(payload.get("terminal_id"))
        session = self.terminals.get(terminal_id)
        # Drain before tearing down, so the shell's final output still reaches
        # the client instead of dying with the PTY.
        outcome = (
            self._terminal_result(session, terminal_id)
            if session is not None
            else CommandOutcome(status="succeeded", extra={"terminal_id": terminal_id, "frames": []})
        )
        extra = outcome.extra
        assert extra is not None  # both branches above set it
        extra["closed"] = self.terminals.close(terminal_id)
        extra["running"] = False
        return outcome

    @staticmethod
    def _terminal_settle(session: terminal.TerminalSession, payload: dict[str, Any]) -> None:
        """Wait briefly for output, returning as soon as any arrives.

        This is the buffered transport's stand-in for the pod's push: one
        round trip should carry back whatever the shell produced, rather than
        forcing a second poll to collect an echo that was already on its way.
        """
        wait_ms = bounded_int(payload.get("wait_ms"), 0, TERMINAL_MAX_WAIT_MS, TERMINAL_DEFAULT_WAIT_MS)
        deadline = time.monotonic() + (wait_ms / 1000.0)
        while time.monotonic() < deadline:
            if session.has_pending():
                # Let a burst coalesce instead of returning the first byte alone.
                time.sleep(TERMINAL_COALESCE_SECONDS)
                return
            if not session.is_running():
                return
            time.sleep(TERMINAL_SETTLE_POLL_SECONDS)

    def _confined_root(self) -> str | None:
        """The only-writable tree for `limited` access, or None in `full`.

        `full` access is the owner saying "this machine is yours", so the child
        runs unconfined. `limited` access is a promise that nothing outside the
        workspace can be modified, and a promise we cannot keep is not a promise:
        if the platform mechanism is missing (macOS, Linux kernel < 5.13, LSM
        disabled, a broken Windows token dance) we refuse the exec instead of
        running it unconfined.
        """
        if self.access == "full":
            return None
        if not confinement.available():
            raise AccessRefused(f"{CONFINEMENT_UNAVAILABLE} ({confinement.detail()})")
        return str(self._files.root)


def _default_python() -> str:
    from .util import console_python

    return console_python()


class CompletionOutbox:
    """Durable completions so a lost response never loses a command result."""

    def __init__(self, directory: Path) -> None:
        self.directory = directory

    def _path(self, command_id: str) -> Path:
        return self.directory / f"{command_id.lower()}.json"

    def save(
        self, command_id: str, path: str, body: dict[str, Any], *,
        app_command_type: str | None = None,
    ) -> None:
        if not UUID_RE.match(command_id):
            raise InvalidTask("Completion command id is invalid.")
        if app_command_type not in (None, "app_control", "app_http"):
            raise InvalidTask("Completion app command type is invalid.")
        ensure_private_dir(self.directory)
        record = {"command_id": command_id, "path": path, "body": body, "created_at": iso8601()}
        if app_command_type is not None:
            record["app_command_type"] = app_command_type
        write_private_file(self._path(command_id), json.dumps(record, sort_keys=True).encode("utf-8"))

    def load(self, command_id: str) -> dict[str, Any] | None:
        target = self._path(command_id)
        if not target.exists():
            return None
        try:
            return json.loads(target.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def list(self) -> list[dict[str, Any]]:
        if not self.directory.exists():
            return []
        records = []
        for entry in sorted(self.directory.glob("*.json")):
            try:
                records.append(json.loads(entry.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                continue
        return records

    def delete(self, command_id: str) -> None:
        target = self._path(command_id)
        if target.exists():
            target.unlink()


@dataclass
class _LocalCommandTask:
    """The closed command envelope shared with the single local worker."""

    command_id: str
    claim_token: str
    path: str
    command_type: str
    payload: dict[str, Any]
    started_at: str
    prepared: Any = None
    executor: Any = None
    uses_prepared_executor: bool = False
    outcome: CommandOutcome | None = None
    error_code: str | None = None
    body: dict[str, Any] | None = None
    done: threading.Event = field(default_factory=threading.Event)
    thread: threading.Thread | None = None
    supervision_timer: threading.Timer | None = None
    next_supervision: float = 0.0


def _execute_local_command(
    executor: Any, task: _LocalCommandTask, wake: Callable[[], None] | None = None,
) -> None:
    """Execute locally; completion only wakes the owning signed-request lane."""

    try:
        if task.uses_prepared_executor:
            outcome = executor.execute_prepared(task.prepared)
        else:
            outcome = executor.execute(task.command_type, task.payload)
    except MeshiaNodeError as error:
        task.outcome = CommandOutcome(
            status="failed", message=str(error), extra={"error_code": error.code}
        )
        task.error_code = error.code
    except Exception as error:  # pragma: no cover - defensive
        task.outcome = CommandOutcome(
            status="failed", message=f"Local execution failed: {error!s}"
        )
        task.error_code = "LOCAL_TASK_REJECTED"
    else:
        task.outcome = outcome
        task.error_code = None if outcome.status == "succeeded" else "LOCAL_TASK_REJECTED"
    finally:
        task.done.set()
        if wake is not None:
            try:
                wake()
            except Exception:
                # Notification is an acceleration. The ordinary command poll
                # still observes done and retains/publishes this same result.
                pass


class CommandLoop:
    """One signed claim/completion lane plus one bounded local worker."""

    def __init__(
        self,
        store: ConfigStore,
        client: SignedClient,
        executor: CommandExecutor,
        outbox: CompletionOutbox | None = None,
        logger: NodeLogger = NULL_LOGGER,
        on_write: Callable[[str], None] | None = None,
        clock: Callable[[], float] = time.time,
        executor_factory: Callable[[dict[str, Any]], CommandExecutor] | None = None,
    ) -> None:
        self.store = store
        self.client = client
        self.executor = executor
        self.executor_factory = executor_factory
        self.outbox = outbox or CompletionOutbox(store.paths.outbox_dir)
        self.logger = logger
        self.on_write = on_write
        self._clock = clock
        self._active: _LocalCommandTask | None = None
        self._closed = False
        self._completion_wakeup: Callable[[], None] | None = None
        self._last_flush_app_batch = False
        self._app_completion_reconcile: set[str] = set()

    # ------------------------------------------------------------------- claim

    def poll_once(self) -> bool:
        """Flush/reap first, then claim at most one command when no worker is active."""
        if self._closed:
            return False
        reaped = self._drain_active(send=False) if self._active is not None else False
        flushed = self.flush_outbox()
        if flushed and not self._last_flush_app_batch:
            # Ordinary completions share the research request budget. App
            # batches have an independent budget and must not starve claims.
            return True
        if self._active is not None:
            self._supervise_active()
            return True
        if reaped:
            return True
        config = self.store.require()
        claim_path = f"api/connected-hosts/{config.host_id}/commands/claim"
        authority_started = time.monotonic()
        response = (
            self.client.request("POST", claim_path, b'{"workspace_commands":true,"native_execution":true}')
            if self.executor_factory is not None else self.client.post_empty(claim_path)
        )
        if response.status == 204 or not response.body:
            return flushed
        document = response.json()
        command = document.get("command") if isinstance(document, dict) else None
        if not isinstance(command, dict):
            return flushed
        self.handle(command, authority_started=authority_started)
        return True

    def poll_without_claim(self) -> bool:
        """Flush/reap an existing command while Fabric readiness gates new claims."""
        if self._closed:
            return False
        reaped = self._drain_active(send=False) if self._active is not None else False
        flushed = self.flush_outbox()
        if not flushed or self._last_flush_app_batch:
            self._supervise_active()
        return reaped or flushed or self._active is not None

    @property
    def has_active_command(self) -> bool:
        return self._active is not None

    @property
    def has_completed_command(self) -> bool:
        return self._active is not None and self._active.done.is_set()

    def set_completion_wakeup(self, wake: Callable[[], None] | None) -> None:
        """Set a local wake notification, never a completion/network callback."""
        self._completion_wakeup = wake

    def handle(self, command: dict[str, Any], *, authority_started: float | None = None) -> None:
        authority_started = time.monotonic() if authority_started is None else authority_started
        if self._closed:
            return
        if self._active is not None:
            self.logger.record("task_claim_deferred", reason="local_worker_busy")
            return
        command_id = str(command.get("id", ""))
        claim_token = str(command.get("claim_token", ""))
        if not UUID_RE.match(command_id) or not UUID_RE.match(claim_token):
            self.logger.record("task_rejected", error_code="COMMAND_ENVELOPE_INVALID")
            return
        config = self.store.require()
        path = f"api/connected-hosts/{config.host_id}/commands/{command_id}/complete"

        pending = self.outbox.load(command_id)
        if pending is not None:
            # Re-completion after a lost response: same result, refreshed lease.
            body = dict(pending["body"])
            body["claim_token"] = claim_token
            self.outbox.save(command_id, path, body)
            self._flush_record({"command_id": command_id, "path": path, "body": body})
            return

        command_type = str(command.get("command_type", ""))
        raw_payload = command.get("payload") or {}
        payload = dict(raw_payload) if isinstance(raw_payload, dict) else raw_payload
        self.logger.record("task_claimed", task_id=command_id, command_type=command_type)
        task = _LocalCommandTask(
            command_id=command_id,
            claim_token=claim_token,
            path=path,
            command_type=command_type,
            payload=payload,
            started_at=iso8601(),
        )
        try:
            if self.executor_factory is None and command.get("session_id", config.session_id) != config.session_id:
                raise AccessRefused("This runner cannot execute another workspace's command.")
            if command_type not in REMOTE_WORKSPACE_COMMANDS:
                raise TierRefused("Connected hosts accept workspace-file and workspace-compute commands only.")
            if not isinstance(payload, dict) or "scope" in payload:
                raise TierRefused("Connected-host paths are always inside the mounted workspace; scope is not accepted.")
            task.executor = self.executor_factory(command) if self.executor_factory is not None else self.executor
            if self.executor_factory is not None and command_type in ("exec", "mcp_call"):
                seconds = command.get("supervision_seconds")
                if type(seconds) is not int or seconds != COMMAND_SUPERVISION_SECONDS:
                    raise AccessRefused("The command has no bounded execution authority.")
                self._arm_supervision(task, authority_started + seconds)
            prepare = getattr(task.executor, "prepare_remote", None)
            if not callable(prepare):
                prepare = getattr(task.executor, "prepare", None)
            if callable(prepare):
                task.prepared = prepare(command_type, payload)
                task.uses_prepared_executor = True
        except MeshiaNodeError as error:
            task.outcome = CommandOutcome(
                status="failed", message=str(error), extra={"error_code": error.code}
            )
            task.error_code = error.code
            task.done.set()
        except Exception as error:  # pragma: no cover - defensive
            task.outcome = CommandOutcome(
                status="failed", message=f"Local execution failed: {error!s}"
            )
            task.error_code = "LOCAL_TASK_REJECTED"
            task.done.set()
        else:
            task.thread = threading.Thread(
                target=_execute_local_command,
                args=(task.executor, task, self._completion_wakeup),
                name=f"meshia-command-{command_id[:8]}",
                daemon=True,
            )
            task.thread.start()
        self._active = task
        self._drain_active(wait_seconds=COMMAND_WORKER_HANDOFF_SECONDS)

    def _arm_supervision(self, task: _LocalCommandTask, deadline: float) -> None:
        if deadline <= time.monotonic():
            task.executor.close()
            raise AccessRefused("The command execution authority expired before it could be renewed.")
        if task.supervision_timer is not None:
            task.supervision_timer.cancel()
        # Each remote command owns its executor. Closing it also blocks a start
        # that has not happened yet, so an expiry cannot lose a race with spawn.
        task.supervision_timer = threading.Timer(max(0.0, deadline-time.monotonic()), task.executor.close)
        task.supervision_timer.daemon = True
        task.supervision_timer.start()
        task.next_supervision = time.monotonic() + COMMAND_SUPERVISION_POLL_SECONDS

    def _supervise_active(self) -> None:
        task = self._active
        if task is None or task.done.is_set() or task.supervision_timer is None:
            return
        started = time.monotonic()
        if started < task.next_supervision:
            return
        task.next_supervision = started + COMMAND_SUPERVISION_POLL_SECONDS
        config = self.store.require()
        try:
            document = self.client.post_json(f"api/connected-hosts/{config.host_id}/commands/claim", {
                "workspace_commands": True,
                "native_execution": True,
                "active_command": {"id": task.command_id, "claim_token": task.claim_token},
            })
            receipt = document.get("supervision") if isinstance(document, dict) else None
            if not isinstance(receipt, dict) or receipt.get("continue") is not True:
                task.executor.close()
                return
            seconds = receipt.get("supervision_seconds")
            if type(seconds) is not int or seconds != COMMAND_SUPERVISION_SECONDS:
                task.executor.close()
                return
            # Charge request time against the grant. A slow/late response can
            # never revive an executor already closed by its previous timer.
            if not task.done.is_set():
                self._arm_supervision(task, started + seconds)
        except Disconnected:
            task.executor.close()
            raise
        except MeshiaNodeError as error:
            self.logger.record("task_supervision_deferred", task_id=task.command_id, error_code=error.code)
            # The independent timer continues while this signed lane recovers.

    def _completion_body(self, task: _LocalCommandTask) -> dict[str, Any]:
        if task.body is not None:
            return task.body
        assert task.outcome is not None
        outcome = task.outcome
        published_scope = (
            task.payload.get("scope", "workspace")
            if isinstance(task.payload, dict)
            else None
        )
        if (
            outcome.status == "succeeded"
            and self.on_write
            and task.command_type == "write_file"
            # Host-scope writes are not workspace files; publishing one to Fabric
            # would push an absolute host path into the synchronized manifest.
            and published_scope == "workspace"
            # Shared owner writes already have a durable local journal. The
            # legacy hook reads the private cache and must not restage them.
            and (outcome.extra or {}).get("filesystem_journaled") is not True
        ):
            try:
                self.on_write(str(task.payload.get("path", "")))
            except MeshiaNodeError as error:
                outcome = CommandOutcome(status="failed", message=str(error), extra={"error_code": error.code})
                task.error_code = "LOCAL_TASK_REJECTED"
                self.logger.record(
                    "task_publication_failed",
                    task_id=task.command_id,
                    error_code=error.code,
                )
            except (OSError, RuntimeError, ValueError) as error:
                outcome = CommandOutcome(
                    status="failed",
                    message=f"Local write publication failed: {error!s}",
                )
                task.error_code = "LOCAL_TASK_REJECTED"
                self.logger.record(
                    "task_publication_failed",
                    task_id=task.command_id,
                    error_type=type(error).__name__,
                )

        task.outcome = outcome

        task.body = {
            "claim_token": task.claim_token,
            "status": "succeeded" if outcome.status == "succeeded" else "failed",
            "result": outcome.result_payload(task.started_at, iso8601()),
            "error_code": task.error_code,
        }
        return task.body

    def _drain_active(self, *, wait_seconds: float = 0.0, send: bool = True) -> bool:
        task = self._active
        if task is None:
            return False
        if wait_seconds > 0:
            task.done.wait(wait_seconds)
        if not task.done.is_set():
            return False
        if task.supervision_timer is not None:
            task.supervision_timer.cancel()
        body = self._completion_body(task)
        self.outbox.save(task.command_id, task.path, body)
        if task.executor is not None and task.executor is not self.executor:
            task.executor.close()
        self._active = None
        if send:
            self._flush_record(
                {"command_id": task.command_id, "path": task.path, "body": body}
            )
        return True

    def cancel(self) -> None:
        """Signal an active local command; joining belongs to :meth:`close`."""
        target = self._active.executor if self._active is not None and self._active.executor is not None else self.executor
        cancel = getattr(target, "cancel_current", None)
        if callable(cancel):
            cancel()

    def close(self, timeout_seconds: float = COMMAND_WORKER_REAP_SECONDS) -> None:
        """Cancel and reap the one worker, durably retaining any finished result."""
        if self._closed:
            return
        self._closed = True
        self.cancel()
        if self._active is not None and self._active.executor is not None and self._active.executor is not self.executor:
            self._active.executor.close()
        close_executor = getattr(self.executor, "close", None)
        if callable(close_executor):
            close_executor()
        task = self._active
        if task is None:
            return
        task.done.wait(max(0.0, timeout_seconds))
        if task.done.is_set():
            self._drain_active(send=False)
            return
        self.logger.record(
            "task_worker_reap_deferred",
            task_id=task.command_id,
            timeout_seconds=max(0.0, timeout_seconds),
        )

    # ------------------------------------------------------------------ outbox

    def flush_outbox(self) -> bool:
        """Send one ordinary receipt or up to four app receipts, serially."""
        self._last_flush_app_batch = False
        records = self.outbox.list()
        if not records:
            return False
        config = self.store.require()
        candidates = []
        for record in records:
            item = self._app_completion(record, config.host_id)
            if item is None:
                # A browser burst cannot postpone a completed research task.
                self._flush_record(record)
                return True
            candidates.append((record, item))
        for record, _item in candidates:
            if record["command_id"] in self._app_completion_reconcile:
                # Resolve a rejected envelope one receipt at a time. Keep
                # valid siblings moving without replaying any local work.
                self._last_flush_app_batch = True
                self._flush_record(record)
                self._app_completion_reconcile.discard(record["command_id"])
                return True
        selected = []
        items = []
        for record, item in candidates:
            if len(items) == 4:
                break
            if len(json_bytes({"completions": [*items, item]})) > 1_500_000:
                if not items:
                    # Keep the existing individual completion behavior for an
                    # oversized legacy record; never raise the signed limit.
                    self._flush_record(record)
                    return True
                break
            selected.append(record)
            items.append(item)
        self._last_flush_app_batch = True
        self._flush_app_batch(config.host_id, selected, items)
        return True

    @staticmethod
    def _app_completion(record: dict[str, Any], host_id: str) -> dict[str, Any] | None:
        """Local classification only; the server verifies stored command kinds."""
        command_id = record.get("command_id")
        body = record.get("body")
        if (
            record.get("app_command_type") not in ("app_control", "app_http")
            or not isinstance(command_id, str) or not UUID_RE.fullmatch(command_id)
            or record.get("path") != f"api/connected-hosts/{host_id}/commands/{command_id}/complete"
            or not isinstance(body, dict)
            or set(body) - {"claim_token", "status", "result", "error_code"}
            or not isinstance(body.get("claim_token"), str) or not UUID_RE.fullmatch(body["claim_token"])
            or body.get("status") not in ("succeeded", "failed", "canceled")
            or not isinstance(body.get("result"), dict)
        ):
            return None
        error_code = body.get("error_code")
        if error_code is not None and (
            not isinstance(error_code, str) or not re.fullmatch(r"[A-Z][A-Z0-9_]{1,63}", error_code)
        ):
            return None
        return {"command_id": command_id, **body, "error_code": error_code}

    def _flush_app_batch(
        self, host_id: str, records: list[dict[str, Any]], items: list[dict[str, Any]],
    ) -> None:
        try:
            response = self.client.post_json(
                f"api/connected-hosts/{host_id}/commands/complete-app-batch", {"completions": items},
            )
        except Disconnected:
            raise
        except RemoteError as error:
            if error.status in (400, 403):
                self._app_completion_reconcile.update(record["command_id"] for record in records)
            self.logger.record("app_completion_batch_deferred", error_code=error.code)
            return
        except MeshiaNodeError as error:
            self.logger.record("app_completion_batch_deferred", error_code=error.code)
            return
        # A truncated or mixed response is ambiguous. Validate every item and
        # exact ID coverage before deleting even the first durable receipt.
        outcomes = response.get("completions") if isinstance(response, dict) else None
        expected = {record["command_id"] for record in records}
        seen = set()
        valid = (
            isinstance(response, dict) and set(response) == {"completions"}
            and isinstance(outcomes, list) and len(outcomes) == len(records)
        )
        if valid:
            for item in outcomes:
                if not isinstance(item, dict):
                    valid = False
                    break
                command_id = item.get("command_id")
                status = item.get("status")
                http_status = item.get("http_status")
                if (
                    not isinstance(command_id, str) or command_id not in expected or command_id in seen
                    or type(http_status) is not int
                    or (status == "acknowledged" and (
                        http_status != 200 or set(item) != {"command_id", "status", "http_status"}
                    ))
                    or (status == "rejected" and (
                        not 400 <= http_status <= 599
                        or set(item) != {"command_id", "status", "http_status", "code"}
                        or not isinstance(item.get("code"), str)
                        or not re.fullmatch(r"[A-Z][A-Z0-9_]{1,63}", item["code"])
                    ))
                    or status not in ("acknowledged", "rejected")
                ):
                    valid = False
                    break
                seen.add(command_id)
        if not valid or seen != expected:
            self.logger.record("app_completion_batch_deferred", error_code="APP_COMPLETION_RECEIPT_INVALID")
            return
        for item in outcomes:
            command_id = item["command_id"]
            if item["status"] == "acknowledged":
                self.outbox.delete(command_id)
                self.logger.record("task_completed", task_id=command_id)
            elif item["http_status"] == 409 and item["code"] == "COMMAND_LEASE_LOST":
                self.outbox.delete(command_id)
                self.logger.record("task_completion_superseded", task_id=command_id)
            else:
                self.logger.record("task_completion_deferred", task_id=command_id, error_code=item["code"])

    def _flush_record(self, record: dict[str, Any]) -> None:
        try:
            self.client.post_json(record["path"], record["body"])
        except Disconnected:
            raise
        except RemoteError as error:
            if error.status == 409 and error.remote_code == "COMMAND_LEASE_LOST":
                # This claim can no longer mutate the durable command. Keeping
                # it at the head of the outbox would block every later result.
                self.outbox.delete(record["command_id"])
                self.logger.record("task_completion_superseded", task_id=record["command_id"])
                return
            self.logger.record("task_completion_deferred", task_id=record["command_id"], error_code=error.code)
            return
        except MeshiaNodeError as error:
            self.logger.record(
                "task_completion_deferred", task_id=record["command_id"], error_code=error.code
            )
            return
        self.outbox.delete(record["command_id"])
        self.logger.record(
            "task_completed", task_id=record["command_id"], status=record["body"]["status"]
        )


def temporary_workspace() -> tempfile.TemporaryDirectory[str]:  # pragma: no cover - helper
    return tempfile.TemporaryDirectory(prefix="meshia-workspace-")
