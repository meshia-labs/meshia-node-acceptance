"""Per-user background-service definitions and a single-runner process lease.

The service layer deliberately stores *only* how to restart an already-enrolled
node.  Pairing codes, private keys, API credentials, and environment snapshots
never belong in a launch definition.  Every platform invokes the exact
``meshia-node`` executable with an explicit state directory and the credential-
free ``service run`` command::

    /absolute/path/to/meshia-node --home /absolute/path/to/.meshia service run

Installations are current-user only:

* macOS: a LaunchAgent (never a LaunchDaemon),
* Linux: a ``systemd --user`` unit (never a system unit or sudo), and
* Windows: a LIMITED, AtLogOn Scheduled Task (never SYSTEM or AtStartup).

Command execution is injectable so rendering and lifecycle behavior can be
tested without registering a real service.  Definition writes are atomic,
private, and content-idempotent. Manager calls have a fixed deadline, and
installation and connected runtimes refuse POSIX root, built-in Windows
service identities, and elevated Windows tokens.
"""

from __future__ import annotations

import errno
import os
import plistlib
import re
import stat
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import xml.etree.ElementTree as ElementTree
from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Callable, Literal, Protocol, Sequence

from .util import ensure_private_dir, run_bounded_capture, write_private_file

if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
    import msvcrt
else:
    import fcntl

PlatformName = Literal["darwin", "linux", "win32"]
Command = tuple[str, ...]

LAUNCHD_LABEL = "io.meshia.node"
SYSTEMD_UNIT = "meshia-node.service"
WINDOWS_TASK = "Meshia Node"
WINDOWS_LOCAL_SYSTEM_SID = "S-1-5-18"
WINDOWS_LOCAL_SERVICE_SID = "S-1-5-19"
WINDOWS_NETWORK_SERVICE_SID = "S-1-5-20"
WINDOWS_TASK_NAMESPACE = "http://schemas.microsoft.com/windows/2004/02/mit/task"
WINDOWS_TASK_XML_PLACEHOLDER = "{MESHIA_PRIVATE_TASK_XML}"
WINDOWS_TASK_RESTART_INTERVAL = "PT1M"
WINDOWS_TASK_RESTART_COUNT = 5
WINDOWS_TASK_START_GRACE_SECONDS = 2.0
WINDOWS_DETACHED_START_GRACE_SECONDS = 15.0
# launchd keeps this inode open across service startup. Preserve a bounded
# previous crash before truncating it, rather than losing the only traceback.
SERVICE_STDERR_FILENAME = "node.stderr.log"
SERVICE_STDERR_PREVIOUS_FILENAME = "node.stderr.previous.log"
SERVICE_STDERR_MAX_BYTES = 1024 * 1024
CONNECTION_LOCK_NAME = "connection.lock"
SERVICE_SHUTDOWN_REQUEST_NAME = "service-shutdown.request"
SERVICE_MANAGER_TIMEOUT_SECONDS = 15.0
SERVICE_STOP_GRACE_SECONDS = 30.0
WINDOWS_TASK_SETTLE_SECONDS = 10
MACOS_SERVICE_STOP_MANAGER_TIMEOUT_SECONDS = SERVICE_STOP_GRACE_SECONDS + 5.0
# Unmount-first stop protocol. A stop/restart/upgrade must never terminate the
# runner while the OS still has its native mount attached: on macOS the kernel
# NFS/SMB client then waits forever on a dead local server and only a reboot
# clears it. The controller asks the runner to release the mount, waits this
# long for the OS registry to prove the detach, and otherwise refuses.
MOUNT_RELEASE_TIMEOUT_SECONDS = 20.0
MOUNT_RELEASE_POLL_SECONDS = 0.25
# How long a release keeps waiting AFTER the registry bound while the runner
# still holds the connection lease, i.e. while a consumed shutdown request is
# draining. Derived from the runner's real worst case, not the registry: the
# runner honours the request only between polls (29-35 s measured live under
# hydration, 2026-09-02/03), then the mount worker's unmount budget
# (WORKER_UNMOUNT_DEADLINE 20 s) and the supervisor's kill grace (25 s). A
# runner still alive past this is wedged on the mount, which is the held case.
MOUNT_RELEASE_DRAIN_SECONDS = 90.0
MOUNT_HOLDERS_PROBE_TIMEOUT_SECONDS = 5.0
MOUNT_STATE_FILENAME = "mount-state.json"
_PID_PAYLOAD_BYTES = 63
_WINDOWS_LOCK_OFFSET = _PID_PAYLOAD_BYTES
_MAX_DEFINITION_BYTES = 1024 * 1024

OwnershipState = Literal["absent", "owned", "foreign"]

# A real advisory lock is the cross-process authority.  This registry also
# gives deterministic non-blocking behavior for two independently opened
# handles in the same process on every BSD/POSIX flock implementation.
_PROCESS_LEASES: dict[Path, int] = {}
_PROCESS_LEASES_LOCK = threading.Lock()


class CommandResult(Protocol):
    """The small part of ``subprocess.CompletedProcess`` the controller uses."""

    returncode: int
    stdout: str | None
    stderr: str | None


CommandRunner = Callable[[Sequence[str]], CommandResult]
WindowsSidDetector = Callable[[], str]
WindowsElevationDetector = Callable[[], bool]
WindowsDetachedLauncher = Callable[[Command], None]


class ServiceError(RuntimeError):
    """A service definition or lifecycle operation is invalid."""


class ServiceCommandError(ServiceError):
    """A platform service-manager command failed.

    Manager output is intentionally retained on ``result`` rather than copied
    into the exception text.  That keeps accidental manager diagnostics out of
    logs while still making them available to an interactive caller.
    """

    def __init__(self, action: str, command: Command, result: CommandResult) -> None:
        self.action = action
        self.command = command
        self.result = result
        super().__init__(f"Service {action} failed with exit code {result.returncode}.")


class ServiceTimeoutError(ServiceError):
    """A local service manager did not answer within the fixed deadline."""

    def __init__(self, action: str, command: Command) -> None:
        self.action = action
        self.command = command
        self.timeout_seconds = _manager_timeout_seconds(command)
        super().__init__(
            f"Service {action} timed out after {self.timeout_seconds:g} seconds."
        )


class ServiceOwnershipError(ServiceError):
    """A fixed-name service belongs to a different executable or state home."""

    def __init__(self, action: str, state: OwnershipState = "foreign") -> None:
        self.action = action
        self.state = state
        detail = (
            "its exact executable and state home are owned by another installation"
            if state == "foreign"
            else "no exact owned definition is installed"
        )
        super().__init__(f"Refusing to {action} the fixed-name service because {detail}.")


class AlreadyRunning(ServiceError):
    """Another process owns the node's connection lease."""

    def __init__(self, pid: int | None) -> None:
        self.pid = pid
        suffix = f" (pid {pid})" if pid is not None else ""
        super().__init__(f"Another Meshia Node process is already running{suffix}.")


def mount_held_message(
    mount_point: str,
    holders: Sequence[str] | None,
    retry_command: str,
    *,
    requested: bool = False,
) -> str:
    """The exact refusal shown when a native mount will not release in time.

    ``requested`` is the difference between two very different states. Before
    the runner was asked to stop, refusing changes nothing. Once the shutdown
    request has been consumed the runner WILL exit as soon as its current
    poll and mount teardown finish (a busy sync engine took 29-35 s live on
    2026-09-02/03, past the 20 s bound), so "the current node is still
    running" would be false and an installer acting on it left the node
    stopped. The caller restores the service in that case and the message
    says so.
    """

    if holders is None:
        holding = "unknown (the open-file probe did not answer in time)"
    elif not holders:
        holding = "nothing reported by lsof; a file may still be mid-write"
    else:
        holding = ", ".join(holders)
    if requested:
        return (
            f"Meshia asked the node to stop, but its files were still mounted at "
            f"{mount_point} when the wait ended. The node exits as soon as the "
            "mount detaches and the Meshia service is restarted so the files stay "
            "available; nothing was replaced. "
            f"Likely holding the mount open: {holding}. "
            f"Close that, then retry with: {retry_command}"
        )
    return (
        f"Meshia refused to stop the node because its files are still mounted at "
        f"{mount_point}. Stopping now would leave the operating system waiting "
        "on a dead file server and only a reboot would clear it, so nothing was "
        "changed and the current node is still running. "
        f"Likely holding the mount open: {holding}. "
        f"Close that, then retry with: {retry_command}"
    )


class MountHeldError(ServiceError):
    """The native mount stayed attached within the bound.

    ``requested`` records whether the runner's cooperative shutdown was
    already requested (and therefore consumed): the runner is then exiting,
    not "still running", and whoever refused must restore the service.
    """

    def __init__(
        self,
        mount_point: str,
        *,
        holders: Sequence[str] | None,
        retry_command: str,
        requested: bool = False,
    ) -> None:
        self.mount_point = mount_point
        self.holders = tuple(holders) if holders is not None else None
        self.retry_command = retry_command
        self.requested = bool(requested)
        super().__init__(
            mount_held_message(
                mount_point, holders, retry_command, requested=self.requested
            )
        )


def runner_holds_lease(home: Path | str) -> bool:
    """Whether a runner currently holds this home's connection lease.

    The lease is released at the very end of the runner's teardown, after the
    mount worker has unmounted, so "held" means the node is still running or
    still draining a consumed shutdown request.
    """

    lease = ConnectionLease.for_home(home)
    try:
        lease.acquire()
    except AlreadyRunning:
        return True
    except OSError:
        return False
    lease.release()
    return False


@dataclass(frozen=True)
class MountReleaseOutcome:
    """What the unmount-first protocol observed before a service stop."""

    mount_point: str | None
    released: bool
    requested: bool
    reason: Literal["no_mount", "already_released", "released", "unowned"]
    holders: tuple[str, ...] | None = None


def _read_receipt_mount_point(home: Path) -> str | None:
    """Return the mount point named by the runner's private mount receipt."""

    from .fabric_mount import read_mount_state

    receipt = read_mount_state(home / MOUNT_STATE_FILENAME)
    if receipt is None:
        return None
    mount_point = receipt.get("mount_point")
    return mount_point if isinstance(mount_point, str) and mount_point else None


def _default_registry_probe(mount_point: str) -> bool | None:
    from .fabric_mount import mount_registration_state

    return mount_registration_state(mount_point)


def mount_holders(
    mount_point: str, *, timeout_seconds: float = MOUNT_HOLDERS_PROBE_TIMEOUT_SECONDS
) -> tuple[str, ...] | None:
    """Best-effort ``lsof`` of processes with files open under ``mount_point``.

    ``None`` means the probe did not answer (lsof absent, or it blocked on the
    mount and was abandoned at the deadline) — never a claim that nothing holds
    the mount.
    """

    if sys.platform not in ("darwin",) and not sys.platform.startswith("linux"):
        return None
    lsof = "/usr/sbin/lsof" if os.path.exists("/usr/sbin/lsof") else "/usr/bin/lsof"
    if not os.path.exists(lsof):
        return None
    output = run_bounded_capture(
        [lsof, "-n", "-P", "-F", "pc", "+D", mount_point],
        timeout_seconds=timeout_seconds,
    )
    if output is None:
        return None
    holders: list[str] = []
    seen: set[str] = set()
    pid: str | None = None
    for line in output.splitlines():
        if line.startswith("p"):
            pid = line[1:].strip()
        elif line.startswith("c") and pid is not None:
            label = f"{line[1:].strip()} (pid {pid})"
            if label not in seen:
                seen.add(label)
                holders.append(label)
    return tuple(holders[:12])


def release_native_mount(
    home: Path,
    *,
    request_shutdown: Callable[[], bool],
    retry_command: str,
    timeout_seconds: float = MOUNT_RELEASE_TIMEOUT_SECONDS,
    registry_probe: Callable[[str], bool | None] | None = None,
    holders_probe: Callable[[str], tuple[str, ...] | None] | None = None,
    receipt_mount_point: Callable[[Path], str | None] = _read_receipt_mount_point,
    runner_live: Callable[[], bool] | None = None,
    drain_seconds: float = MOUNT_RELEASE_DRAIN_SECONDS,
    sleep: Callable[[float], None] = time.sleep,
    monotonic: Callable[[], float] = time.monotonic,
) -> MountReleaseOutcome:
    """Ask the runner to detach its native mount and wait for the OS to agree.

    This is the one unmount path: the runner's own bounded teardown, triggered
    through the cooperative shutdown request it already watches. The OS mount
    registry is the only accepted proof of release; a probe that does not
    answer counts as *not released*.

    Two bounds, because they answer two different questions. ``timeout_seconds``
    is how long an idle runner needs to detach. Once the shutdown request has
    been consumed the runner is committed to exit, so while it still holds the
    connection lease (``runner_live``) the release keeps waiting -- a busy
    engine needs 29-35 s just to reach its stop check -- up to ``drain_seconds``.
    Only a runner that has exited with the mount still registered, or one still
    alive past the drain bound (wedged on the mount), is *held*.
    :class:`MountHeldError` then names the mount point, the likely holders, the
    exact retry command, and whether the stop was already requested.
    """

    probe = registry_probe or _default_registry_probe
    holders = holders_probe or mount_holders
    mount_point = receipt_mount_point(home)
    if mount_point is None:
        return MountReleaseOutcome(None, True, False, "no_mount")
    if probe(mount_point) is False:
        return MountReleaseOutcome(mount_point, True, False, "already_released")
    requested = request_shutdown()
    if not requested:
        # No runner owns the connection lease, so there is no file server to
        # protect: the registered mount is stale or foreign. Stopping the
        # service cannot wedge anything; the next start refuses to stack on it
        # and surfaces the recovery notice.
        return MountReleaseOutcome(mount_point, False, False, "unowned")
    live = runner_live or (lambda: runner_holds_lease(home))
    started = monotonic()
    deadline = started + max(0.0, timeout_seconds)
    drain_deadline = started + max(max(0.0, timeout_seconds), max(0.0, drain_seconds))
    while True:
        registration = probe(mount_point)
        if registration is False:
            return MountReleaseOutcome(mount_point, True, requested, "released")
        now = monotonic()
        if now >= deadline:
            # Past the idle bound: keep waiting only while the runner is still
            # draining its consumed request, never past the drain bound.
            if now >= drain_deadline or not live():
                break
        sleep(min(MOUNT_RELEASE_POLL_SECONDS, max(0.0, drain_deadline - now)))
    raise MountHeldError(
        mount_point,
        holders=holders(mount_point),
        retry_command=retry_command,
        requested=requested,
    )


@dataclass(frozen=True)
class ServiceDefinition:
    """Rendered, side-effect-free description of one platform service."""

    platform: PlatformName
    name: str
    run_command: Command
    definition_path: Path | None
    definition_bytes: bytes | None
    install_commands: tuple[Command, ...]
    start_commands: tuple[Command, ...]
    restart_commands: tuple[Command, ...]
    stop_commands: tuple[Command, ...]
    status_commands: tuple[Command, ...]
    uninstall_commands: tuple[Command, ...]


@dataclass(frozen=True)
class ServiceAction:
    """Observable result of a controller action."""

    changed: bool
    results: tuple[CommandResult, ...] = ()


def _manager_timeout_seconds(command: Sequence[str]) -> float:
    """Keep ordinary manager calls short while allowing launchd graceful teardown."""

    if tuple(command[:2]) == ("/bin/launchctl", "bootout"):
        return MACOS_SERVICE_STOP_MANAGER_TIMEOUT_SECONDS
    return SERVICE_MANAGER_TIMEOUT_SECONDS


def _default_runner(command: Sequence[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(command),
        check=False,
        capture_output=True,
        text=True,
        timeout=_manager_timeout_seconds(command),
    )


def _current_windows_user_sid() -> str:
    """Return the SID on the process token, without trusting environment names."""

    if sys.platform != "win32":  # keeps non-Windows imports and calls side-effect free
        raise ServiceError("Windows token inspection is only available on Windows.")

    import ctypes
    from ctypes import wintypes

    token_query = 0x0008
    token_user_information = 1

    class SidAndAttributes(ctypes.Structure):
        _fields_ = [("Sid", ctypes.c_void_p), ("Attributes", wintypes.DWORD)]

    class TokenUser(ctypes.Structure):
        _fields_ = [("User", SidAndAttributes)]

    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    kernel32.GetCurrentProcess.argtypes = []
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    advapi32.OpenProcessToken.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.HANDLE),
    ]
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.GetTokenInformation.argtypes = [
        wintypes.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    ]
    advapi32.GetTokenInformation.restype = wintypes.BOOL
    advapi32.ConvertSidToStringSidW.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(wintypes.LPWSTR),
    ]
    advapi32.ConvertSidToStringSidW.restype = wintypes.BOOL

    def failure(operation: str) -> ServiceError:
        code = ctypes.get_last_error()
        return ServiceError(
            f"Cannot verify the Windows service account ({operation}, Windows error {code})."
        )

    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(
        kernel32.GetCurrentProcess(), token_query, ctypes.byref(token)
    ):
        raise failure("OpenProcessToken")
    try:
        required = wintypes.DWORD()
        advapi32.GetTokenInformation(
            token, token_user_information, None, 0, ctypes.byref(required)
        )
        if required.value == 0:
            raise failure("GetTokenInformation size")
        buffer = ctypes.create_string_buffer(required.value)
        if not advapi32.GetTokenInformation(
            token,
            token_user_information,
            buffer,
            required,
            ctypes.byref(required),
        ):
            raise failure("GetTokenInformation")
        user = ctypes.cast(buffer, ctypes.POINTER(TokenUser)).contents
        sid_string = wintypes.LPWSTR()
        if not advapi32.ConvertSidToStringSidW(user.User.Sid, ctypes.byref(sid_string)):
            raise failure("ConvertSidToStringSidW")
        try:
            sid = sid_string.value
            if not sid:
                raise ServiceError("Cannot verify the Windows service account (empty SID).")
            return sid
        finally:
            kernel32.LocalFree(ctypes.cast(sid_string, ctypes.c_void_p))
    finally:
        kernel32.CloseHandle(token)


def _current_windows_token_is_elevated() -> bool:
    """Read TokenElevation from the process token, failing closed on errors."""

    if sys.platform != "win32":  # keeps non-Windows imports and calls side-effect free
        raise ServiceError("Windows token inspection is only available on Windows.")

    import ctypes
    from ctypes import wintypes

    token_query = 0x0008
    token_elevation_information = 20

    class TokenElevation(ctypes.Structure):
        _fields_ = [("TokenIsElevated", wintypes.DWORD)]

    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetCurrentProcess.argtypes = []
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    advapi32.OpenProcessToken.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.HANDLE),
    ]
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.GetTokenInformation.argtypes = [
        wintypes.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    ]
    advapi32.GetTokenInformation.restype = wintypes.BOOL

    def failure(operation: str) -> ServiceError:
        code = ctypes.get_last_error()
        return ServiceError(
            f"Cannot verify the Windows node account ({operation}, Windows error {code})."
        )

    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(
        kernel32.GetCurrentProcess(), token_query, ctypes.byref(token)
    ):
        raise failure("OpenProcessToken")
    try:
        elevation = TokenElevation()
        returned = wintypes.DWORD()
        if not advapi32.GetTokenInformation(
            token,
            token_elevation_information,
            ctypes.byref(elevation),
            ctypes.sizeof(elevation),
            ctypes.byref(returned),
        ):
            raise failure("GetTokenInformation(TokenElevation)")
        if returned.value < ctypes.sizeof(elevation):
            raise failure("GetTokenInformation(TokenElevation) size")
        return elevation.TokenIsElevated != 0
    finally:
        kernel32.CloseHandle(token)


def _validated_windows_user_sid(value: object) -> str:
    """Return one ordinary-user SID, rejecting service identities fail-closed."""

    if not isinstance(value, str):
        raise ServiceError("Cannot verify the Windows node account; refusing to continue.")
    sid = value.upper()
    parts = sid.split("-")
    if (
        len(parts) < 3
        or parts[0] != "S"
        or any(not part.isdigit() for part in parts[1:])
    ):
        raise ServiceError("Cannot verify the Windows node account; refusing to continue.")
    service_identity = {
        WINDOWS_LOCAL_SYSTEM_SID: "LocalSystem",
        WINDOWS_LOCAL_SERVICE_SID: "LocalService",
        WINDOWS_NETWORK_SERVICE_SID: "NetworkService",
    }.get(sid)
    if service_identity is not None:
        raise ServiceError(f"Refusing to run Meshia Node as Windows {service_identity}.")
    return sid


def _detect_windows_user_sid(detector: WindowsSidDetector | None) -> str:
    if detector is None:
        raise ServiceError("Cannot verify the Windows node account; refusing to continue.")
    try:
        return _validated_windows_user_sid(detector())
    except ServiceError:
        raise
    except Exception as error:
        raise ServiceError(
            "Cannot verify the Windows node account; refusing to continue."
        ) from error


def _platform_name(value: str | None) -> PlatformName:
    candidate = value or sys.platform
    if candidate == "darwin":
        return "darwin"
    if candidate.startswith("linux"):
        return "linux"
    if candidate in ("win32", "cygwin", "msys"):
        return "win32"
    raise ServiceError(f"Per-user services are not supported on platform {candidate!r}.")


def assert_safe_node_account(
    *,
    platform: str | None = None,
    effective_uid: int | None = None,
    windows_sid_detector: WindowsSidDetector | None = None,
    windows_elevation_detector: WindowsElevationDetector | None = None,
) -> None:
    """Reject privileged node runtimes before enrollment or service execution.

    A connected node inherits the host permissions of this process. Account
    inspection is therefore fail-closed: a caller that cannot prove it is an
    ordinary current-user process must not enroll, attach, or install a service.
    """

    target = _platform_name(platform)
    if target in ("darwin", "linux"):
        uid = effective_uid
        if uid is None:
            get_effective_uid = getattr(os, "geteuid", None)
            if get_effective_uid is None:
                raise ServiceError("Cannot verify the effective user for Meshia Node.")
            uid = get_effective_uid()
        if not isinstance(uid, int) or uid < 0:
            raise ServiceError("Cannot verify the effective user for Meshia Node.")
        if uid == 0:
            raise ServiceError("Refusing to run Meshia Node as root (uid 0).")
        return

    sid_detector = windows_sid_detector
    elevation_detector = windows_elevation_detector
    if sys.platform == "win32":  # pragma: no branch - platform-specific default
        sid_detector = sid_detector or _current_windows_user_sid
        elevation_detector = elevation_detector or _current_windows_token_is_elevated
    if sid_detector is None or elevation_detector is None:
        raise ServiceError("Cannot verify the Windows node account; refusing to continue.")
    _detect_windows_user_sid(sid_detector)
    try:
        elevated = elevation_detector()
    except ServiceError:
        raise
    except Exception as error:
        raise ServiceError(
            "Cannot verify the Windows node account; refusing to continue."
        ) from error
    if not isinstance(elevated, bool):
        raise ServiceError("Cannot verify the Windows node account; refusing to continue.")
    if elevated:
        raise ServiceError("Refusing to run Meshia Node from an elevated Windows token.")


def _absolute_path(value: str | os.PathLike[str], platform: PlatformName, label: str) -> str:
    raw = os.fspath(value)
    if not raw or any(character in raw for character in ("\x00", "\r", "\n")):
        raise ServiceError(f"{label} must be a non-empty absolute path without control characters.")
    pure = PureWindowsPath(raw) if platform == "win32" else PurePosixPath(raw)
    if not pure.is_absolute():
        raise ServiceError(f"{label} must be an absolute path.")
    return str(pure)


def _systemd_quote(argument: str) -> str:
    """Quote one systemd ExecStart argument without invoking a shell.

    Percent and dollar signs have meaning to systemd even inside quotes, so
    both are doubled in addition to the regular quoted-string escaping.
    """

    escaped: list[str] = []
    for character in argument:
        if character == "\\":
            escaped.append("\\\\")
        elif character == '"':
            escaped.append('\\"')
        elif character == "%":
            escaped.append("%%")
        elif character == "$":
            escaped.append("$$")
        elif ord(character) < 32 or ord(character) == 127:
            escaped.append(f"\\x{ord(character):02x}")
        else:
            escaped.append(character)
    return f'"{"".join(escaped)}"'


def _render_systemd(run_command: Command) -> bytes:
    command = " ".join(_systemd_quote(argument) for argument in run_command)
    return (
        "[Unit]\n"
        "Description=Meshia Node connected-host service\n"
        "Wants=network-online.target\n"
        "After=network-online.target\n"
        "StartLimitIntervalSec=60\n"
        "StartLimitBurst=5\n"
        "\n"
        "[Service]\n"
        "Type=simple\n"
        f"ExecStart={command}\n"
        "Restart=on-failure\n"
        "RestartSec=5\n"
        "TimeoutStopSec=30\n"
        "KillMode=control-group\n"
        "UMask=0077\n"
        "\n"
        "[Install]\n"
        "WantedBy=default.target\n"
    ).encode("utf-8")


def _windows_service_python(executable: str) -> str:
    console = PureWindowsPath(executable)
    sibling = console.with_name("pythonw.exe")
    # venv: Scripts/pythonw.exe; a complete Python prefix: pythonw.exe next
    # to Scripts/. Both are the console launcher's exact installed prefix.
    if sys.platform == "win32" and not Path(str(sibling)).is_file() and console.parent.name.lower() == "scripts":
        prefix = console.parent.parent / "pythonw.exe"
        if Path(str(prefix)).is_file():
            return str(prefix)
    return str(sibling)


def _launch_windows_detached(run_command: Command) -> None:
    """Start the current-user runner outside a terminal session's job object.

    InteractiveToken tasks persist safely without storing the user's password,
    but Task Scheduler cannot start one from a headless SSH/network logon. The
    installer is already running as the intended limited user in that case, so
    launch the exact owned command directly and break away from the session job.
    The scheduled task remains the durable AtLogOn restart path.
    """

    if sys.platform != "win32":
        raise ServiceError("Detached Windows service launch is unavailable on this platform.")
    if not _run_command_matches_definition(
        run_command, run_command[0], run_command[2], "win32"
    ):
        raise ServiceError("Detached Windows service launch requires the exact owned command.")
    flags = (
        getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
        | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
        | getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0x01000000)
    )
    command = (
        _windows_service_python(run_command[0]),
        "-I",
        "-m",
        "meshia_node.windowless",
        *run_command,
    )
    try:
        subprocess.Popen(
            command,
            cwd=run_command[2],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=flags,
        )
    except OSError:
        raise ServiceError("The detached Windows service could not be started.") from None


def _render_windows_task(run_command: Command, user_sid: str) -> bytes:
    """Render the complete Task Scheduler policy instead of inheriting defaults."""

    sid = _validated_windows_user_sid(user_sid)
    namespace = WINDOWS_TASK_NAMESPACE
    ElementTree.register_namespace("", namespace)

    def child(
        parent: ElementTree.Element, name: str, text: str | None = None
    ) -> ElementTree.Element:
        element = ElementTree.SubElement(parent, f"{{{namespace}}}{name}")
        element.text = text
        return element

    task = ElementTree.Element(f"{{{namespace}}}Task", {"version": "1.4"})
    registration = child(task, "RegistrationInfo")
    child(registration, "Author", "Meshia")
    child(registration, "Description", "Meshia Node current-user connected-host service")

    triggers = child(task, "Triggers")
    logon = child(triggers, "LogonTrigger")
    child(logon, "Enabled", "true")
    child(logon, "UserId", sid)

    principals = child(task, "Principals")
    principal = child(principals, "Principal")
    principal.set("id", "CurrentUser")
    child(principal, "UserId", sid)
    child(principal, "LogonType", "InteractiveToken")
    child(principal, "RunLevel", "LeastPrivilege")

    settings = child(task, "Settings")
    child(settings, "MultipleInstancesPolicy", "IgnoreNew")
    child(settings, "DisallowStartIfOnBatteries", "false")
    child(settings, "StopIfGoingOnBatteries", "false")
    child(settings, "AllowHardTerminate", "true")
    child(settings, "StartWhenAvailable", "true")
    child(settings, "RunOnlyIfNetworkAvailable", "false")
    child(settings, "AllowStartOnDemand", "true")
    child(settings, "Enabled", "true")
    child(settings, "Hidden", "false")
    child(settings, "RunOnlyIfIdle", "false")
    child(settings, "WakeToRun", "false")
    child(settings, "ExecutionTimeLimit", "PT0S")
    child(settings, "Priority", "7")
    restart = child(settings, "RestartOnFailure")
    child(restart, "Interval", WINDOWS_TASK_RESTART_INTERVAL)
    child(restart, "Count", str(WINDOWS_TASK_RESTART_COUNT))

    actions = child(task, "Actions")
    actions.set("Context", "CurrentUser")
    execute = child(actions, "Exec")
    # Keep the logical console identity for ownership/version receipts, while
    # the ordinary-user task runs through its own venv's windowless Python.
    child(execute, "Command", _windows_service_python(run_command[0]))
    child(execute, "Arguments", subprocess.list2cmdline((
        "-I", "-m", "meshia_node.windowless", *run_command,
    )))
    # schtasks imports its XML through the scheduler's Unicode interface.
    # A UTF-8 declaration reaches that parser as wide text and is rejected
    # with "unable to switch the encoding". Match its native UTF-16 format.
    return ElementTree.tostring(
        task,
        encoding="utf-16",
        xml_declaration=True,
        short_empty_elements=False,
    )


def render_service(
    executable: str | os.PathLike[str],
    home: str | os.PathLike[str],
    *,
    platform: str | None = None,
    user_home: str | os.PathLike[str] | None = None,
    uid: int | None = None,
    windows_user_sid: str | None = None,
    native_bundle_identifier: str | None = None,
) -> ServiceDefinition:
    """Render a current-user service without touching disk or running commands."""

    target = _platform_name(platform)
    executable_path = _absolute_path(executable, target, "Meshia executable")
    meshia_home = _absolute_path(home, target, "Meshia home")
    run_command: Command = (executable_path, "--home", meshia_home, "service", "run")
    if native_bundle_identifier is not None and (
        target != "darwin" or native_bundle_identifier != LAUNCHD_LABEL
        or PurePosixPath(executable_path).parts[-5:] != (
            "native", "Meshia Node.app", "Contents", "MacOS", "MeshiaNode"
        )
    ):
        raise ServiceError("Native service association requires the verified Meshia Node app.")

    if target == "darwin":
        account_home = Path(
            _absolute_path(user_home or Path.home(), target, "User home")
        )
        if native_bundle_identifier is not None and Path(meshia_home) != account_home / ".meshia":
            raise ServiceError("Meshia Node native service requires the standard account home.")
        definition_path = account_home / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
        domain_uid = uid if uid is not None else os.getuid()
        if domain_uid < 0:
            raise ServiceError("User id must be non-negative.")
        domain = f"gui/{domain_uid}"
        target_name = f"{domain}/{LAUNCHD_LABEL}"
        start_command = ("/bin/launchctl", "bootstrap", domain, str(definition_path))
        stop_command = ("/bin/launchctl", "bootout", domain, str(definition_path))
        document = {
            "Label": LAUNCHD_LABEL,
            "ProgramArguments": list(run_command),
            "RunAtLoad": True,
            # A clean `service run` exit includes the sticky, owner-requested
            # disconnected state and must stay stopped. Unexpected non-zero
            # exits are relaunched after launchd's throttle interval.
            "KeepAlive": {"SuccessfulExit": False},
            "ProcessType": "Background",
            "ThrottleInterval": 5,
            # Meshia's bounded native teardown can spend up to ten seconds in
            # the OS unmount helper and then drain the exact FUSE-T helper and
            # callback thread. launchd's five-second default would SIGKILL the
            # runner midway through that sequence and strand its private mount
            # receipt. Keep this aligned with SERVICE_STOP_GRACE_SECONDS.
            "ExitTimeOut": int(SERVICE_STOP_GRACE_SECONDS),
            # NodeLogger is the bounded, redacted diagnostic authority, and
            # `service run` routes Python logging into it. But stderr also
            # carries what logging cannot: a pre-logging crash, or a library
            # (e.g. fusepy) that writes a traceback to the process's real
            # stderr. Discarding it to /dev/null is how the FUSE readdir
            # traceback was lost. The lease-owning runner preserves a bounded
            # last nonempty run before truncating the same inode on startup;
            # launchd itself never rotates this sink.
            "StandardOutPath": "/dev/null",
            "StandardErrorPath": str(Path(meshia_home) / SERVICE_STDERR_FILENAME),
        }
        if native_bundle_identifier is not None:
            document["AssociatedBundleIdentifiers"] = [native_bundle_identifier]
        return ServiceDefinition(
            platform=target,
            name=LAUNCHD_LABEL,
            run_command=run_command,
            definition_path=definition_path,
            definition_bytes=plistlib.dumps(document, fmt=plistlib.FMT_XML, sort_keys=True),
            # Installing a LaunchAgent is a private, atomic file write.  `start`
            # bootstraps it into the current GUI domain immediately.
            install_commands=(),
            start_commands=(start_command,),
            # A restart intentionally unloads and reloads the LaunchAgent. The
            # controller waits between these commands for connection.lock to
            # be released, which proves that the old runner finished its mount
            # teardown. `kickstart -k` would SIGKILL the runner and bypass that
            # cleanup, leaving Finder to report an interrupted SMB connection.
            restart_commands=(stop_command, start_command),
            stop_commands=(stop_command,),
            status_commands=(("/bin/launchctl", "print", target_name),),
            uninstall_commands=(),
        )

    if target == "linux":
        account_home = Path(
            _absolute_path(user_home or Path.home(), target, "User home")
        )
        definition_path = account_home / ".config" / "systemd" / "user" / SYSTEMD_UNIT
        return ServiceDefinition(
            platform=target,
            name=SYSTEMD_UNIT,
            run_command=run_command,
            definition_path=definition_path,
            definition_bytes=_render_systemd(run_command),
            install_commands=(
                ("systemctl", "--user", "daemon-reload"),
                ("systemctl", "--user", "enable", SYSTEMD_UNIT),
            ),
            start_commands=(("systemctl", "--user", "start", SYSTEMD_UNIT),),
            restart_commands=(("systemctl", "--user", "restart", SYSTEMD_UNIT),),
            stop_commands=(("systemctl", "--user", "stop", SYSTEMD_UNIT),),
            status_commands=(
                ("systemctl", "--user", "is-active", SYSTEMD_UNIT),
            ),
            uninstall_commands=(
                ("systemctl", "--user", "disable", SYSTEMD_UNIT),
                ("systemctl", "--user", "daemon-reload"),
            ),
        )

    if windows_user_sid is None:
        raise ServiceError("A verified current-user SID is required for a Windows task.")
    task_xml = _render_windows_task(run_command, windows_user_sid)
    return ServiceDefinition(
        platform=target,
        name=WINDOWS_TASK,
        run_command=run_command,
        definition_path=None,
        definition_bytes=task_xml,
        install_commands=(
            (
                "schtasks.exe",
                "/Create",
                "/TN",
                WINDOWS_TASK,
                "/XML",
                WINDOWS_TASK_XML_PLACEHOLDER,
                "/F",
            ),
        ),
        start_commands=(("schtasks.exe", "/Run", "/TN", WINDOWS_TASK),),
        restart_commands=(("schtasks.exe", "/Run", "/TN", WINDOWS_TASK),),
        stop_commands=(("schtasks.exe", "/End", "/TN", WINDOWS_TASK),),
        status_commands=(("schtasks.exe", "/Query", "/TN", WINDOWS_TASK, "/FO", "LIST"),),
        uninstall_commands=(("schtasks.exe", "/Delete", "/TN", WINDOWS_TASK, "/F"),),
    )


def _manager_text(result: CommandResult) -> str:
    return f"{result.stdout or ''}\n{result.stderr or ''}".lower()


def _is_benign_manager_failure(
    platform: PlatformName, action: str, command: Command, result: CommandResult
) -> bool:
    """Recognize only documented/idempotent absent or already-stopped outcomes."""

    if result.returncode == 0:
        return True
    text = _manager_text(result)
    if platform == "darwin":
        return len(command) > 1 and command[1] == "print" and any(
            marker in text for marker in ("could not find service", "service not found")
        )
    if platform == "linux":
        if action == "stop" and command[-2:] == ("stop", SYSTEMD_UNIT):
            return any(
                marker in text
                for marker in (
                    f"unit {SYSTEMD_UNIT.lower()} not loaded",
                    f"unit {SYSTEMD_UNIT.lower()} could not be found",
                )
            )
        if action == "uninstall" and command[-2:] == ("disable", SYSTEMD_UNIT):
            return any(
                marker in text
                for marker in (
                    f"unit file {SYSTEMD_UNIT.lower()} does not exist",
                    f"unit {SYSTEMD_UNIT.lower()} not loaded",
                    "no files found for",
                )
            )
        return False
    if platform == "win32":
        operation = next((part.upper() for part in command if part.startswith("/")), "")
        missing = (
            "the system cannot find the file specified" in text
            or "cannot find the task specified" in text
            or "the specified task name" in text and "does not exist" in text
        )
        missing_path = "the system cannot find the path specified" in text
        if operation == "/QUERY":
            return missing or missing_path
        if operation == "/END":
            return missing or (
                "scheduled task" in text
                and ("is not running" in text or "is not currently running" in text)
            )
        if operation == "/DELETE":
            return missing or missing_path
    return False


def _parse_systemd_arguments(payload: bytes) -> Command | None:
    try:
        lines = payload.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return None
    entries = [line[len("ExecStart=") :] for line in lines if line.startswith("ExecStart=")]
    if len(entries) != 1:
        return None
    value = entries[0]
    arguments: list[str] = []
    index = 0
    while index < len(value):
        while index < len(value) and value[index].isspace():
            index += 1
        if index >= len(value):
            break
        if value[index] != '"':
            return None
        index += 1
        decoded: list[str] = []
        while index < len(value) and value[index] != '"':
            character = value[index]
            if character in ("%", "$"):
                if index + 1 >= len(value) or value[index + 1] != character:
                    return None
                decoded.append(character)
                index += 2
                continue
            if character == "\\":
                if index + 1 >= len(value):
                    return None
                escaped = value[index + 1]
                if escaped == "x":
                    digits = value[index + 2 : index + 4]
                    if len(digits) != 2:
                        return None
                    try:
                        decoded.append(chr(int(digits, 16)))
                    except ValueError:
                        return None
                    index += 4
                    continue
                if escaped not in ('"', "\\"):
                    return None
                decoded.append(escaped)
                index += 2
                continue
            decoded.append(character)
            index += 1
        if index >= len(value) or value[index] != '"':
            return None
        arguments.append("".join(decoded))
        index += 1
        if index < len(value) and not value[index].isspace():
            return None
    return tuple(arguments)


def _split_windows_command_line(value: str) -> Command:
    """Invert the quoting shape produced by subprocess.list2cmdline."""

    arguments: list[str] = []
    index = 0
    while index < len(value):
        while index < len(value) and value[index] in (" ", "\t"):
            index += 1
        if index >= len(value):
            break
        decoded: list[str] = []
        quoted = False
        while index < len(value):
            if value[index] in (" ", "\t") and not quoted:
                break
            if value[index] == '"':
                quoted = not quoted
                index += 1
                continue
            if value[index] == "\\":
                start = index
                while index < len(value) and value[index] == "\\":
                    index += 1
                backslashes = index - start
                if index < len(value) and value[index] == '"':
                    decoded.extend("\\" for _ in range(backslashes // 2))
                    if backslashes % 2:
                        decoded.append('"')
                        index += 1
                    else:
                        quoted = not quoted
                        index += 1
                else:
                    decoded.extend("\\" for _ in range(backslashes))
                continue
            decoded.append(value[index])
            index += 1
        if quoted:
            return ()
        arguments.append("".join(decoded))
    return tuple(arguments)


def _windows_task_arguments(payload: str) -> Command | None:
    try:
        root = ElementTree.fromstring(payload)
    except ElementTree.ParseError:
        return None

    def local_name(element: ElementTree.Element) -> str:
        return element.tag.rsplit("}", 1)[-1]

    exec_nodes = [element for element in root.iter() if local_name(element) == "Exec"]
    if len(exec_nodes) != 1:
        return None
    command_text: str | None = None
    argument_text = ""
    for child in exec_nodes[0]:
        if local_name(child) == "Command":
            command_text = child.text
        elif local_name(child) == "Arguments":
            argument_text = child.text or ""
    if not command_text:
        return None
    parsed = _split_windows_command_line(argument_text)
    if parsed[:3] == ("-I", "-m", "meshia_node.windowless"):
        if (len(parsed) != 8 or PureWindowsPath(command_text).name.lower() != "pythonw.exe"
                or not (PureWindowsPath(command_text).parent == PureWindowsPath(parsed[3]).parent
                    or (PureWindowsPath(parsed[3]).parent.name.lower() == "scripts"
                        and PureWindowsPath(command_text).parent == PureWindowsPath(parsed[3]).parent.parent))):
            return None
        return parsed[3:]
    return (command_text, *parsed) if parsed or not argument_text.strip() else None


def _windows_task_principal_matches(payload: str, expected_user_sid: str) -> bool:
    try:
        root = ElementTree.fromstring(payload)
        expected_sid = _validated_windows_user_sid(expected_user_sid)
    except (ElementTree.ParseError, ServiceError):
        return False

    def local_name(element: ElementTree.Element) -> str:
        return element.tag.rsplit("}", 1)[-1]

    principals = [element for element in root.iter() if local_name(element) == "Principal"]
    if len(principals) != 1:
        return False
    values: dict[str, list[str]] = {}
    for child in principals[0]:
        values.setdefault(local_name(child), []).append(child.text or "")
    if any(len(values.get(name, [])) != 1 for name in ("UserId", "LogonType")):
        return False
    try:
        actual_sid = _validated_windows_user_sid(values["UserId"][0])
    except ServiceError:
        return False
    return (
        actual_sid == expected_sid
        and values["LogonType"] == ["InteractiveToken"]
        # Scheduler exports omit its default LeastPrivilege element. An
        # explicitly empty, repeated or elevated value is still not ours.
        and values.get("RunLevel", []) in ([], ["LeastPrivilege"])
    )


def _run_command_matches_definition(
    command: Sequence[str] | None,
    expected_executable: str,
    expected_home: str,
    platform: PlatformName,
) -> bool:
    if command is None or len(command) != 5:
        return False
    if command[1] != "--home" or tuple(command[-2:]) != ("service", "run"):
        return False
    try:
        path_type = PureWindowsPath if platform == "win32" else PurePosixPath
        executable = path_type(command[0])
        wanted_executable = path_type(expected_executable)
        actual_home = path_type(command[2])
        wanted_home = path_type(expected_home)
    except (TypeError, ValueError):
        return False
    return (
        executable.is_absolute()
        and wanted_executable.is_absolute()
        and executable == wanted_executable
        and actual_home == wanted_home
    )


def _read_regular_definition(path: Path) -> tuple[bool, bytes | None]:
    """Read a bounded regular file without following a definition symlink."""

    try:
        before = path.lstat()
    except FileNotFoundError:
        return False, None
    except OSError:
        return True, None
    if not stat.S_ISREG(before.st_mode) or before.st_size > _MAX_DEFINITION_BYTES:
        return True, None

    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError:
        return True, None
    try:
        after = os.fstat(descriptor)
        if (
            not stat.S_ISREG(after.st_mode)
            or after.st_size > _MAX_DEFINITION_BYTES
            or (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino)
        ):
            return True, None
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            payload = stream.read(_MAX_DEFINITION_BYTES + 1)
        if len(payload) > _MAX_DEFINITION_BYTES:
            return True, None
        return True, payload
    except OSError:
        return True, None
    finally:
        os.close(descriptor)


class ServiceController:
    """Install and control one rendered per-user service."""

    def __init__(
        self,
        executable: str | os.PathLike[str],
        home: str | os.PathLike[str],
        *,
        platform: str | None = None,
        user_home: str | os.PathLike[str] | None = None,
        uid: int | None = None,
        runner: CommandRunner = _default_runner,
        windows_sid_detector: WindowsSidDetector | None = None,
        windows_elevation_detector: WindowsElevationDetector | None = None,
        mount_registry_probe: Callable[[str], bool | None] | None = None,
        mount_holders_probe: Callable[[str], tuple[str, ...] | None] | None = None,
        mount_release_timeout_seconds: float = MOUNT_RELEASE_TIMEOUT_SECONDS,
        native_bundle_identifier: str | None = None,
        activation_verifier: Callable[[], None] | None = None,
        windows_detached_launcher: WindowsDetachedLauncher | None = None,
    ) -> None:
        target = _platform_name(platform)
        self._mount_registry_probe = mount_registry_probe
        self._mount_holders_probe = mount_holders_probe
        self._mount_release_timeout_seconds = mount_release_timeout_seconds
        self.last_mount_release: MountReleaseOutcome | None = None
        self.last_windows_task_settlement: tuple[int, int] | None = None
        self._windows_sid_detector = windows_sid_detector
        self._windows_elevation_detector = windows_elevation_detector
        if target == "win32" and self._windows_sid_detector is None and sys.platform == "win32":
            self._windows_sid_detector = _current_windows_user_sid
        if (
            target == "win32"
            and self._windows_elevation_detector is None
            and sys.platform == "win32"
        ):
            self._windows_elevation_detector = _current_windows_token_is_elevated
        windows_user_sid = (
            _detect_windows_user_sid(self._windows_sid_detector)
            if target == "win32"
            else None
        )
        self._windows_user_sid = windows_user_sid
        self.definition = render_service(
            executable,
            home,
            platform=target,
            user_home=user_home,
            uid=uid,
            windows_user_sid=windows_user_sid,
            native_bundle_identifier=native_bundle_identifier,
        )
        self._runner = runner
        self._windows_detached_launcher = windows_detached_launcher
        if (
            target == "win32"
            and self._windows_detached_launcher is None
            and sys.platform == "win32"
        ):
            self._windows_detached_launcher = _launch_windows_detached
        self._activation_verifier = activation_verifier
        self.native_bundle_identifier = native_bundle_identifier
        self._install_uid = uid
        if self._install_uid is None and self.definition.platform in ("darwin", "linux"):
            get_effective_uid = getattr(os, "geteuid", None)
            self._install_uid = get_effective_uid() if get_effective_uid is not None else None
        # On real Windows the short-lived XML source is written under the
        # owner-restricted service home. Cross-platform render tests use the
        # process-private temporary directory instead of interpreting a
        # PureWindowsPath as a native POSIX path.
        self._home = (
            Path(home)
            if self.definition.platform != "win32" or sys.platform == "win32"
            else None
        )

    def _assert_safe_lifecycle_account(self) -> None:
        assert_safe_node_account(
            platform=self.definition.platform,
            effective_uid=self._install_uid,
            windows_sid_detector=self._windows_sid_detector,
            windows_elevation_detector=self._windows_elevation_detector,
        )

    def _execute(
        self, action: str, commands: Sequence[Command], *, check: bool
    ) -> tuple[CommandResult, ...]:
        results: list[CommandResult] = []
        for command in commands:
            try:
                result = self._runner(command)
            except subprocess.TimeoutExpired:
                # TimeoutExpired can carry captured stdout/stderr. Do not copy
                # either into the user-facing exception or its chained cause.
                raise ServiceTimeoutError(action, command) from None
            results.append(result)
            if check and result.returncode != 0:
                raise ServiceCommandError(action, command, result)
        return tuple(results)

    def _execute_tolerating_absent(
        self, action: str, commands: Sequence[Command]
    ) -> tuple[CommandResult, ...]:
        results: list[CommandResult] = []
        for command in commands:
            result = self._execute(action, (command,), check=False)[0]
            results.append(result)
            if result.returncode != 0 and not _is_benign_manager_failure(
                self.definition.platform, action, command, result
            ):
                raise ServiceCommandError(action, command, result)
        return tuple(results)

    def _write_definition(self) -> bool:
        definition = self.definition
        if definition.definition_path is None or definition.definition_bytes is None:
            return False
        path = definition.definition_path
        present, existing = _read_regular_definition(path)
        if present and existing is None:
            raise ServiceOwnershipError("install")
        changed = existing != definition.definition_bytes
        if changed:
            write_private_file(path, definition.definition_bytes)
        else:
            # Repair permissions even when content is already current.
            ensure_private_dir(path.parent)
            os.chmod(path, 0o600)
        return changed

    def _release_mount_before(self, action: str) -> MountReleaseOutcome | None:
        """Unmount first: never let a stop reach the runner under a live mount.

        Raises :class:`MountHeldError` and leaves the runner untouched when the
        OS registry cannot prove the detach within the bounded wait.
        """

        if self._home is None or self.definition.platform == "win32":
            return None
        outcome = release_native_mount(
            self._home,
            request_shutdown=self._request_runner_shutdown,
            retry_command=f"meshia-node service {action}",
            timeout_seconds=self._mount_release_timeout_seconds,
            registry_probe=self._mount_registry_probe,
            holders_probe=self._mount_holders_probe,
        )
        self.last_mount_release = outcome
        return outcome

    def _wait_for_runner_exit(self, action: str) -> None:
        """Wait until the old runner has completed its cleanup and released its lease."""

        if self._home is None:
            raise ServiceError("The service state home is unavailable.")
        deadline = time.monotonic() + SERVICE_STOP_GRACE_SECONDS
        while True:
            lease = ConnectionLease.for_home(self._home)
            try:
                lease.acquire()
            except AlreadyRunning:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise ServiceError(
                        f"Service {action} timed out waiting for the existing runner "
                        "to finish mount cleanup."
                    ) from None
                time.sleep(min(0.1, remaining))
            else:
                lease.release()
                return

    def _request_runner_shutdown(self) -> bool:
        """Ask an active runner to exit cooperatively; return false when none owns the lease."""

        if self._home is None:
            # Cross-platform render tests cannot represent a Windows absolute
            # path as a native Path. Real Windows controllers always retain it.
            return False
        lease = ConnectionLease.for_home(self._home)
        try:
            lease.acquire()
        except AlreadyRunning as error:
            if error.pid is None:
                raise ServiceError(
                    "Cannot identify the active Meshia runner for graceful shutdown."
                ) from None
            request_path = self._home / "locks" / SERVICE_SHUTDOWN_REQUEST_NAME
            write_private_file(request_path, f"{error.pid}\n".encode("ascii"))
            return True
        else:
            lease.release()
            return False

    def _wait_for_windows_task_exit(self, action: str) -> tuple[CommandResult, ...]:
        """Wait for Scheduler's launcher after the runner releases its cleanup lease.

        A Windows console launcher can still be exiting after its Python child
        releases the lease. IgnoreNew would silently drop a restart in that gap.
        Use numeric COM state without localized output or module autoloading.
        """
        self.last_windows_task_settlement = None
        powershell = str(
            PureWindowsPath(os.environ.get("SystemRoot", r"C:\Windows"))
            / "System32/WindowsPowerShell/v1.0/powershell.exe"
        )
        script = (
            "$ErrorActionPreference='Stop';try{"
            "$s=[Activator]::CreateInstance([Type]::GetTypeFromProgID('Schedule.Service'));"
            "$s.Connect();$t=$s.GetFolder('\\').GetTask('Meshia Node');"
            f"$end=[DateTime]::UtcNow.AddSeconds({WINDOWS_TASK_SETTLE_SECONDS});"
            "do{$count=[int]$t.GetInstances(0).Count;$state=[int]$t.State;"
            "if($count -eq 0 -and $state -in @(1,3)){"
            "[Console]::Out.WriteLine(('{0} {1}' -f $count,$state));exit 0};"
            "[Threading.Thread]::Sleep(100)}while([DateTime]::UtcNow -lt $end);"
            "[Console]::Out.WriteLine(('{0} {1}' -f $count,$state));exit 3"
            "}catch{[Console]::Error.WriteLine($_.Exception.HResult);exit 2}"
        )
        command = (powershell, "-NoProfile", "-NonInteractive", "-Command", script)
        result = self._execute(action, (command,), check=False)[0]
        try:
            count, state = (int(value) for value in (result.stdout or "").split())
        except (ValueError, TypeError):
            raise ServiceCommandError(action, command, result) from None
        self.last_windows_task_settlement = (count, state)
        if result.returncode == 3:
            raise ServiceError(
                f"Service {action} timed out waiting for Task Scheduler "
                f"to finish the existing instance (count={count}, state={state})."
            )
        if result.returncode != 0 or count != 0 or state not in (1, 3):
            raise ServiceCommandError(action, command, result)
        return (result,)

    def _clear_runner_shutdown_request(self) -> None:
        if self._home is None:
            return
        try:
            (self._home / "locks" / SERVICE_SHUTDOWN_REQUEST_NAME).unlink()
        except FileNotFoundError:
            pass
        except OSError:
            raise ServiceError("The service shutdown request could not be cleared.") from None

    def _windows_runner_is_active(self) -> bool:
        if self._home is None:
            return False
        lease = ConnectionLease.for_home(self._home)
        try:
            lease.acquire()
        except AlreadyRunning:
            return True
        else:
            lease.release()
            return False

    def _wait_for_windows_runner_start(self, timeout_seconds: float) -> bool:
        deadline = time.monotonic() + timeout_seconds
        while True:
            if self._windows_runner_is_active():
                return True
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            time.sleep(min(0.1, remaining))

    def _start_windows_service(
        self, action: str, commands: Sequence[Command]
    ) -> tuple[CommandResult, ...]:
        results = self._execute(action, commands, check=True)
        launcher = self._windows_detached_launcher
        if launcher is None or self._home is None:
            return results
        if self._wait_for_windows_runner_start(WINDOWS_TASK_START_GRACE_SECONDS):
            return results
        try:
            launcher(self.definition.run_command)
        except ServiceError:
            raise
        except Exception:
            raise ServiceError("The detached Windows service could not be started.") from None
        if not self._wait_for_windows_runner_start(
            WINDOWS_DETACHED_START_GRACE_SECONDS
        ):
            raise ServiceError(
                "The Windows service did not acquire its connection lease after launch."
            )
        return results

    def _execute_windows_install(self, *, replace: bool) -> tuple[CommandResult, ...]:
        definition = self.definition
        payload = definition.definition_bytes
        if definition.platform != "win32" or payload is None:
            raise ServiceError("The Windows service definition is unavailable.")
        directory = str(self._home) if self._home is not None else None
        descriptor, temporary = tempfile.mkstemp(
            prefix=".meshia-task-",
            suffix=".xml",
            dir=directory,
        )
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(temporary, 0o600)
            commands = tuple(
                tuple(
                    temporary if item == WINDOWS_TASK_XML_PLACEHOLDER else item
                    for item in command
                    if replace or item != "/F"
                )
                for command in definition.install_commands
            )
            return self._execute("install", commands, check=True)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

    def _assert_owned_or_absent(self, action: str) -> OwnershipState:
        state = self.ownership_state()
        if state == "foreign":
            raise ServiceOwnershipError(action, state)
        return state

    def _assert_owned(self, action: str) -> None:
        state = self.ownership_state()
        if state != "owned":
            raise ServiceOwnershipError(action, state)

    def install(self) -> ServiceAction:
        """Persist/replace the definition and register it for future logins."""

        # This precedes directory creation, definition writes, and manager
        # commands so an unsafe invocation is completely side-effect free.
        self._assert_safe_lifecycle_account()
        ownership = self._assert_owned_or_absent("install")
        if self.definition.platform == "win32" and sys.platform == "win32":
            pythonw = Path(_windows_service_python(self.definition.run_command[0]))
            if not pythonw.is_file():
                raise ServiceError("The installed Meshia runtime is missing pythonw.exe; repair the installation.")
        if self._activation_verifier is not None:
            self._activation_verifier()
        if self._home is not None:
            ensure_private_dir(self._home)
        changed = self._write_definition()
        results = (
            self._execute_windows_install(replace=ownership == "owned")
            if self.definition.platform == "win32"
            else self._execute("install", self.definition.install_commands, check=True)
        )
        return ServiceAction(changed=changed or bool(results), results=results)

    def ownership_state(self) -> OwnershipState:
        """Classify the fixed-name definition by exact executable and state home."""

        definition = self.definition
        expected_executable = definition.run_command[0]
        expected_home = definition.run_command[2]
        if definition.platform == "win32":
            query = ("schtasks.exe", "/Query", "/TN", WINDOWS_TASK, "/XML")
            result = self._execute("ownership", (query,), check=False)[0]
            if result.returncode != 0:
                if _is_benign_manager_failure("win32", "ownership", query, result):
                    return "absent"
                raise ServiceCommandError("ownership", query, result)
            command = _windows_task_arguments(result.stdout or "")
            return (
                "owned"
                if self._windows_user_sid is not None
                and _windows_task_principal_matches(
                    result.stdout or "", self._windows_user_sid
                )
                and _run_command_matches_definition(
                    command,
                    expected_executable,
                    expected_home,
                    "win32",
                )
                else "foreign"
            )

        path = definition.definition_path
        if path is None:
            return "absent"
        present, payload = _read_regular_definition(path)
        if not present:
            return "absent"
        if payload is None:
            return "foreign"
        if definition.platform == "darwin":
            try:
                document = plistlib.loads(payload)
            except (ValueError, plistlib.InvalidFileException):
                return "foreign"
            arguments = document.get("ProgramArguments") if isinstance(document, dict) else None
            command = tuple(arguments) if isinstance(arguments, list) else None
        else:
            command = _parse_systemd_arguments(payload)
        return (
            "owned"
            if _run_command_matches_definition(
                command, expected_executable, expected_home, definition.platform
            )
            else "foreign"
        )

    def owns_home(self) -> bool:
        """Prove exact executable and state-home ownership of the fixed name."""

        return self.ownership_state() == "owned"

    def start(self) -> ServiceAction:
        """Ensure the installed service is active now."""

        self._assert_safe_lifecycle_account()
        self._assert_owned("start")
        if self._activation_verifier is not None:
            self._activation_verifier()
        definition = self.definition
        if definition.platform == "darwin":
            # `bootstrap` is not idempotent for an already-loaded label. A loaded
            # agent may nevertheless be stopped after a successful parked exit,
            # so kickstart is the idempotent start operation for that state.
            status = self._execute("status", definition.status_commands, check=False)
            if status[-1].returncode == 0:
                target_name = definition.status_commands[0][-1]
                resumed = self._execute(
                    "start", (("/bin/launchctl", "kickstart", target_name),), check=True
                )
                return ServiceAction(changed=True, results=status + resumed)
            if not _is_benign_manager_failure(
                "darwin", "status", definition.status_commands[0], status[-1]
            ):
                raise ServiceCommandError("status", definition.status_commands[0], status[-1])
            results = status + self._execute("start", definition.start_commands, check=True)
            return ServiceAction(changed=True, results=results)
        results = (
            self._start_windows_service("start", definition.start_commands)
            if definition.platform == "win32"
            else self._execute("start", definition.start_commands, check=True)
        )
        return ServiceAction(changed=True, results=results)

    def restore_after_release(self) -> ServiceAction:
        """Bring the service back after a release that requested its shutdown.

        The runner is committed to exit (its shutdown request was consumed);
        wait for it to finish its mount teardown and release the connection
        lease, then start the installed definition again. On macOS the
        LaunchAgent stays bootstrapped across a clean exit and launchd does
        not relaunch a successful exit, so this is the start half of restart.
        """

        self._assert_safe_lifecycle_account()
        self._assert_owned("restore")
        if self._activation_verifier is not None:
            self._activation_verifier()
        definition = self.definition
        self._wait_for_runner_exit("restore")
        settled = self._wait_for_windows_task_exit("restore") if definition.platform == "win32" else ()
        self._clear_runner_shutdown_request()
        if definition.platform == "darwin":
            results = self._execute("restore", definition.restart_commands[1:], check=True)
        else:
            if definition.platform == "win32":
                self._assert_owned("restore")
            results = (
                self._start_windows_service("restore", definition.start_commands)
                if definition.platform == "win32"
                else self._execute("restore", definition.start_commands, check=True)
            )
        return ServiceAction(changed=True, results=settled + results)

    def restart(self) -> ServiceAction:
        """Replace the active process, or start the installed service if stopped."""

        self._assert_safe_lifecycle_account()
        self._assert_owned("restart")
        if self._activation_verifier is not None:
            self._activation_verifier()
        definition = self.definition
        if definition.platform == "darwin":
            status = self._execute("status", definition.status_commands, check=False)
            if status[-1].returncode != 0 and not _is_benign_manager_failure(
                "darwin", "status", definition.status_commands[0], status[-1]
            ):
                raise ServiceCommandError("status", definition.status_commands[0], status[-1])
            if status[-1].returncode == 0:
                self._release_mount_before("restart")
                stopped = self._execute(
                    "restart", definition.restart_commands[:1], check=True
                )
                self._wait_for_runner_exit("restart")
                self._clear_runner_shutdown_request()
                restarted = stopped + self._execute(
                    "restart", definition.restart_commands[1:], check=True
                )
            else:
                restarted = self._execute(
                    "restart", definition.start_commands, check=True
                )
            return ServiceAction(changed=True, results=status + restarted)
        if definition.platform == "win32":
            cooperative = self._request_runner_shutdown()
            if cooperative:
                self._wait_for_runner_exit("restart")
            stopped = (
                ()
                if cooperative
                else self._execute_tolerating_absent("stop", definition.stop_commands)
            )
            settled = self._wait_for_windows_task_exit("restart")
            if cooperative:
                self._clear_runner_shutdown_request()
            self._assert_owned("restart")
            restarted = self._start_windows_service(
                "restart", definition.restart_commands
            )
            return ServiceAction(changed=True, results=stopped + settled + restarted)
        self._release_mount_before("restart")
        results = self._execute("restart", definition.restart_commands, check=True)
        self._clear_runner_shutdown_request()
        return ServiceAction(changed=True, results=results)

    def stop(self) -> ServiceAction:
        """Stop the service without deleting its persisted definition."""

        return self._stop("stop")

    def _stop(self, action: str) -> ServiceAction:
        self._assert_safe_lifecycle_account()
        if self._assert_owned_or_absent("stop") == "absent":
            return ServiceAction(changed=False)
        definition = self.definition
        if definition.platform == "darwin":
            status = self._execute("status", definition.status_commands, check=False)
            if status[-1].returncode != 0:
                if not _is_benign_manager_failure(
                    "darwin", "status", definition.status_commands[0], status[-1]
                ):
                    raise ServiceCommandError(
                        "status", definition.status_commands[0], status[-1]
                    )
                return ServiceAction(changed=False, results=status)
            # Unmount first. `bootout` starts launchd's ExitTimeOut clock and
            # ends in SIGKILL, which must never reach a runner whose mount the
            # kernel still has attached.
            self._release_mount_before(action)
            results = status + self._execute("stop", definition.stop_commands, check=True)
            self._wait_for_runner_exit("stop")
            self._clear_runner_shutdown_request()
            return ServiceAction(changed=True, results=results)
        cooperative = (
            definition.platform == "win32" and self._request_runner_shutdown()
        )
        if cooperative:
            self._wait_for_runner_exit("stop")
        elif definition.platform == "linux":
            self._release_mount_before(action)
        results = (
            ()
            if cooperative
            else self._execute_tolerating_absent("stop", definition.stop_commands)
        )
        if definition.platform == "win32":
            results += self._wait_for_windows_task_exit(action)
        if cooperative or definition.platform == "linux":
            self._clear_runner_shutdown_request()
        return ServiceAction(
            changed=cooperative or any(result.returncode == 0 for result in results),
            results=results,
        )

    def status(self) -> ServiceAction:
        results = self._execute("status", self.definition.status_commands, check=False)
        return ServiceAction(changed=False, results=results)

    def registered_pid(self, action: ServiceAction) -> int | None:
        """The running PID in this exact LaunchAgent's bounded manager snapshot."""
        if self.definition.platform != "darwin" or not action.results:
            return None
        result = action.results[-1]
        if result.returncode != 0:
            return None
        matches = re.findall(r"^\s+pid = ([1-9][0-9]*)\s*$", result.stdout or "", re.M)
        return int(matches[0]) if len(matches) == 1 else None

    def uninstall(self) -> ServiceAction:
        """Stop, unregister, and remove the definition; safe to repeat."""

        self._assert_safe_lifecycle_account()
        if self._assert_owned_or_absent("uninstall") == "absent":
            return ServiceAction(changed=False)
        stopped = self._stop("uninstall")
        # Stop does not remove the fixed-name definition. Re-prove ownership
        # immediately before the destructive unregister/unlink phase.
        self._assert_owned("uninstall")
        definition = self.definition
        removed = False
        # On Linux, disabling must precede deleting the unit; on Windows the
        # task itself is the persisted definition. Only a recognized absent
        # definition is tolerated; policy, permission and manager failures are
        # propagated so callers cannot report a false successful uninstall.
        manager_results: tuple[CommandResult, ...] = ()
        if definition.platform == "linux":
            disable = definition.uninstall_commands[:1]
            reload_commands = definition.uninstall_commands[1:]
            manager_results += self._execute_tolerating_absent("uninstall", disable)
            if definition.definition_path is not None:
                try:
                    definition.definition_path.unlink()
                    removed = True
                except FileNotFoundError:
                    pass
            manager_results += self._execute("uninstall", reload_commands, check=True)
        else:
            manager_results = self._execute_tolerating_absent(
                "uninstall", definition.uninstall_commands
            )
            if definition.definition_path is not None:
                try:
                    definition.definition_path.unlink()
                    removed = True
                except FileNotFoundError:
                    pass
        return ServiceAction(
            changed=stopped.changed
            or removed
            or any(result.returncode == 0 for result in manager_results),
            results=stopped.results + manager_results,
        )

    def run(self) -> ServiceAction:
        """Run the service command in the current process's foreground."""

        if self._activation_verifier is not None:
            self._activation_verifier()
        results = self._execute("run", (self.definition.run_command,), check=True)
        return ServiceAction(changed=True, results=results)


def process_is_alive(pid: int) -> bool:
    """Check PID liveness without ever signaling/terminating a Windows process."""

    if not isinstance(pid, int) or isinstance(pid, bool) or pid <= 0:
        return False
    if sys.platform != "win32":
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError:
            return False
        return True

    import ctypes  # pragma: no cover - exercised on Windows hosts
    from ctypes import wintypes

    process_query_limited_information = 0x1000
    still_active = 259
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
    if not handle:
        # Access denied still proves that a process currently owns the PID.
        return ctypes.get_last_error() == 5
    try:
        exit_code = wintypes.DWORD()
        if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
            return False
        return exit_code.value == still_active
    finally:
        kernel32.CloseHandle(handle)


def _is_reparse_point(info: os.stat_result) -> bool:
    marker = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return bool(int(getattr(info, "st_file_attributes", 0)) & marker)


def _posix_owner_uid() -> int:
    get_effective_uid = getattr(os, "geteuid", None)
    if get_effective_uid is None:
        raise ServiceError("Cannot verify connection-lock ownership.")
    uid = get_effective_uid()
    if not isinstance(uid, int) or uid < 0:
        raise ServiceError("Cannot verify connection-lock ownership.")
    return uid


def preserve_service_stderr(home: Path) -> bool:
    """Preserve the last nonempty launchd stderr tail, then reuse its inode.

    Call only while holding ConnectionLease. Never copy output to structured
    logs: stderr may contain third-party diagnostics that are not redacted.
    An unsafe path or failed backup leaves the current stderr untouched.
    """
    if os.name == "nt":  # launchd's private sink is POSIX-only
        return False
    directory: int | None = None
    current: int | None = None
    temporary: str | None = None
    try:
        directory = _ensure_posix_lock_directory(home)
        current = os.open(
            SERVICE_STDERR_FILENAME,
            os.O_RDWR
            | os.O_CREAT
            | getattr(os, "O_NOFOLLOW", 0)
            | os.O_NONBLOCK,
            0o600,
            dir_fd=directory,
        )
        info = os.fstat(current)
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_nlink != 1
            or info.st_uid != _posix_owner_uid()
        ):
            return False
        os.fchmod(current, 0o600)
        if not info.st_size:
            return True  # Keep the last crash across clean/empty restarts.
        try:
            previous = os.stat(
                SERVICE_STDERR_PREVIOUS_FILENAME,
                dir_fd=directory,
                follow_symlinks=False,
            )
        except FileNotFoundError:
            previous = None
        if previous is not None and (
            not stat.S_ISREG(previous.st_mode)
            or previous.st_nlink != 1
            or previous.st_uid != _posix_owner_uid()
        ):
            return False
        os.lseek(current, max(0, info.st_size - SERVICE_STDERR_MAX_BYTES), os.SEEK_SET)
        with os.fdopen(os.dup(current), "rb") as stream:
            tail = stream.read(SERVICE_STDERR_MAX_BYTES)
        temporary = f".node.stderr.{uuid.uuid4().hex}.tmp"
        backup = os.open(
            temporary,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600, dir_fd=directory,
        )
        with os.fdopen(backup, "wb") as stream:
            stream.write(tail)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(
            temporary, SERVICE_STDERR_PREVIOUS_FILENAME,
            src_dir_fd=directory, dst_dir_fd=directory,
        )
        temporary = None
        os.fsync(directory)
        os.ftruncate(current, 0)
        return True
    except (OSError, ServiceError):
        return False  # Diagnostic housekeeping must not prevent recovery.
    finally:
        if current is not None:
            os.close(current)
        if directory is not None:
            if temporary is not None:
                try:
                    os.unlink(temporary, dir_fd=directory)
                except OSError:
                    pass
            os.close(directory)


def _ensure_posix_lock_directory(path: Path) -> int:
    """Return a no-follow descriptor for one owner-controlled lock directory."""

    try:
        before = path.lstat()
    except FileNotFoundError:
        try:
            path.mkdir(mode=0o700, parents=True, exist_ok=False)
        except FileExistsError:
            pass
        except OSError:
            raise ServiceError("The connection-lock directory is unsafe.") from None
        try:
            before = path.lstat()
        except OSError:
            raise ServiceError("The connection-lock directory is unsafe.") from None
    except OSError:
        raise ServiceError("The connection-lock directory is unsafe.") from None

    uid = _posix_owner_uid()
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    directory_flag = getattr(os, "O_DIRECTORY", 0)
    if not nofollow or not directory_flag:
        raise ServiceError("No-follow connection-lock directories are unsupported.")
    if (
        stat.S_ISLNK(before.st_mode)
        or _is_reparse_point(before)
        or not stat.S_ISDIR(before.st_mode)
        or before.st_uid != uid
    ):
        raise ServiceError("The connection-lock directory is unsafe.")

    flags = os.O_RDONLY | directory_flag | nofollow | getattr(os, "O_CLOEXEC", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError:
        raise ServiceError("The connection-lock directory is unsafe.") from None
    try:
        after = os.fstat(descriptor)
        if (
            not stat.S_ISDIR(after.st_mode)
            or _is_reparse_point(after)
            or after.st_uid != uid
            or (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino)
        ):
            raise ServiceError("The connection-lock directory is unsafe.")
        os.fchmod(descriptor, 0o700)
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _open_posix_lock_file(directory: int, path: Path) -> int:
    """Open/create the lease file without following or racing its directory entry."""

    uid = _posix_owner_uid()
    try:
        before = os.stat(path.name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError:
        before = None
    except OSError:
        raise ServiceError("The connection-lock file is unsafe.") from None
    if before is not None and (
        stat.S_ISLNK(before.st_mode)
        or _is_reparse_point(before)
        or not stat.S_ISREG(before.st_mode)
        or before.st_uid != uid
        or before.st_nlink != 1
    ):
        raise ServiceError("The connection-lock file is unsafe.")

    nofollow = getattr(os, "O_NOFOLLOW", 0)
    if not nofollow:
        raise ServiceError("No-follow connection-lock files are unsupported.")
    flags = os.O_CREAT | os.O_RDWR | nofollow
    flags |= getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOINHERIT", 0)
    try:
        descriptor = os.open(path.name, flags, 0o600, dir_fd=directory)
    except OSError:
        raise ServiceError("The connection-lock file is unsafe.") from None
    try:
        opened = os.fstat(descriptor)
        current = os.stat(path.name, dir_fd=directory, follow_symlinks=False)
        opened_identity = (opened.st_dev, opened.st_ino)
        if (
            not stat.S_ISREG(opened.st_mode)
            or _is_reparse_point(opened)
            or opened.st_uid != uid
            or opened.st_nlink != 1
            or not stat.S_ISREG(current.st_mode)
            or _is_reparse_point(current)
            or current.st_uid != uid
            or current.st_nlink != 1
            or opened_identity != (current.st_dev, current.st_ino)
            or before is not None
            and opened_identity != (before.st_dev, before.st_ino)
        ):
            raise ServiceError("The connection-lock file is unsafe.")
        os.fchmod(descriptor, 0o600)
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _windows_close_handle(handle: int) -> None:
    import ctypes  # pragma: no cover - exercised on Windows hosts
    from ctypes import wintypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.CloseHandle(handle)


def _windows_handle_is_owned_safe(handle: int, *, directory: bool) -> bool:
    """Validate type, reparse state, hardlinks, and exact token-user ownership."""

    import ctypes  # pragma: no cover - exercised on Windows hosts
    from ctypes import wintypes

    file_attribute_directory = 0x10
    file_attribute_reparse_point = 0x400
    owner_security_information = 0x1
    se_file_object = 1

    class FileTime(ctypes.Structure):
        _fields_ = [("low", wintypes.DWORD), ("high", wintypes.DWORD)]

    class ByHandleFileInformation(ctypes.Structure):
        _fields_ = [
            ("attributes", wintypes.DWORD),
            ("creation_time", FileTime),
            ("last_access_time", FileTime),
            ("last_write_time", FileTime),
            ("volume_serial", wintypes.DWORD),
            ("size_high", wintypes.DWORD),
            ("size_low", wintypes.DWORD),
            ("number_of_links", wintypes.DWORD),
            ("file_index_high", wintypes.DWORD),
            ("file_index_low", wintypes.DWORD),
        ]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32.GetFileInformationByHandle.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(ByHandleFileInformation),
    ]
    kernel32.GetFileInformationByHandle.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    advapi32.GetSecurityInfo.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.POINTER(ctypes.c_void_p),
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_void_p),
    ]
    advapi32.GetSecurityInfo.restype = wintypes.DWORD
    advapi32.ConvertSidToStringSidW.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(wintypes.LPWSTR),
    ]
    advapi32.ConvertSidToStringSidW.restype = wintypes.BOOL

    information = ByHandleFileInformation()
    if not kernel32.GetFileInformationByHandle(handle, ctypes.byref(information)):
        return False
    is_directory = bool(information.attributes & file_attribute_directory)
    if (
        is_directory != directory
        or information.attributes & file_attribute_reparse_point
        or not directory
        and information.number_of_links != 1
    ):
        return False

    owner = ctypes.c_void_p()
    security_descriptor = ctypes.c_void_p()
    status = advapi32.GetSecurityInfo(
        handle,
        se_file_object,
        owner_security_information,
        ctypes.byref(owner),
        None,
        None,
        None,
        ctypes.byref(security_descriptor),
    )
    if status != 0 or not owner:
        return False
    try:
        owner_sid = wintypes.LPWSTR()
        if not advapi32.ConvertSidToStringSidW(owner, ctypes.byref(owner_sid)):
            return False
        try:
            return bool(owner_sid.value) and (
                owner_sid.value.upper() == _current_windows_user_sid().upper()
            )
        finally:
            kernel32.LocalFree(ctypes.cast(owner_sid, ctypes.c_void_p))
    finally:
        kernel32.LocalFree(security_descriptor)


def _windows_open_path(path: Path, *, directory: bool, create: bool) -> int:
    """Open a Windows path itself (never its reparse target) and validate it."""

    import ctypes  # pragma: no cover - exercised on Windows hosts
    from ctypes import wintypes

    generic_read = 0x80000000
    generic_write = 0x40000000
    read_control = 0x00020000
    file_read_attributes = 0x80
    share_all = 0x1 | 0x2 | 0x4
    open_existing = 3
    open_always = 4
    file_attribute_normal = 0x80
    file_flag_open_reparse_point = 0x00200000
    file_flag_backup_semantics = 0x02000000

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateFileW.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.c_void_p,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.HANDLE,
    ]
    kernel32.CreateFileW.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    access = (
        file_read_attributes | read_control
        if directory
        else generic_read | generic_write | read_control
    )
    attributes = file_attribute_normal | file_flag_open_reparse_point
    if directory:
        attributes |= file_flag_backup_semantics
    handle = kernel32.CreateFileW(
        str(path),
        access,
        share_all,
        None,
        open_always if create else open_existing,
        attributes,
        None,
    )
    invalid_handle = ctypes.c_void_p(-1).value
    if handle in (None, invalid_handle):
        raise ServiceError("The connection-lock path is unsafe.")
    if not _windows_handle_is_owned_safe(handle, directory=directory):
        kernel32.CloseHandle(handle)
        raise ServiceError("The connection-lock path is unsafe.")
    return int(handle)


def _ensure_windows_lock_directory(path: Path) -> None:
    try:
        before = path.lstat()
    except FileNotFoundError:
        try:
            path.mkdir(mode=0o700, parents=True, exist_ok=False)
        except FileExistsError:
            pass
        except OSError:
            raise ServiceError("The connection-lock directory is unsafe.") from None
    except OSError:
        raise ServiceError("The connection-lock directory is unsafe.") from None
    else:
        if (
            stat.S_ISLNK(before.st_mode)
            or _is_reparse_point(before)
            or not stat.S_ISDIR(before.st_mode)
        ):
            raise ServiceError("The connection-lock directory is unsafe.")

    handle = _windows_open_path(path, directory=True, create=False)
    _windows_close_handle(handle)
    try:
        from .winsec import ensure_owner_restricted

        ensure_owner_restricted(path)
    except Exception:
        raise ServiceError("The connection-lock directory is unsafe.") from None
    handle = _windows_open_path(path, directory=True, create=False)
    _windows_close_handle(handle)


def _open_windows_lock_file(path: Path) -> int:
    handle = _windows_open_path(path, directory=False, create=True)
    try:
        return msvcrt.open_osfhandle(
            handle,
            os.O_RDWR | getattr(os, "O_BINARY", 0),
        )
    except BaseException:
        _windows_close_handle(handle)
        raise


class ConnectionLease:
    """Non-blocking, crash-safe singleton lease for the node supervision loop.

    The operating-system advisory lock is authoritative.  The PID stored in the
    lock file is diagnostic only, so a crash-released lock with a stale PID is
    immediately recoverable and PID reuse can never create a false refusal.
    """

    def __init__(self, path: str | os.PathLike[str], *, pid: int | None = None) -> None:
        self.path = Path(path)
        # Lexical normalization avoids following a hostile lock-directory or
        # final-file symlink before the no-follow validation in ``acquire``.
        self._registry_path = Path(os.path.abspath(self.path))
        self.pid = os.getpid() if pid is None else pid
        if self.pid <= 0:
            raise ValueError("Connection lease PID must be positive.")
        self._descriptor: int | None = None

    @classmethod
    def for_home(cls, home: str | os.PathLike[str], *, pid: int | None = None) -> "ConnectionLease":
        return cls(Path(home) / "locks" / CONNECTION_LOCK_NAME, pid=pid)

    @property
    def acquired(self) -> bool:
        return self._descriptor is not None

    def _owner_pid(self, descriptor: int) -> int | None:
        try:
            os.lseek(descriptor, 0, os.SEEK_SET)
            raw = (
                os.read(descriptor, _PID_PAYLOAD_BYTES)
                .decode("ascii", "strict")
                .strip("\x00\r\n ")
            )
            value = int(raw)
            return value if value > 0 else None
        except (OSError, UnicodeError, ValueError):
            return None

    def acquire(self) -> "ConnectionLease":
        if self._descriptor is not None:
            raise AlreadyRunning(self.pid)
        with _PROCESS_LEASES_LOCK:
            owner = _PROCESS_LEASES.get(self._registry_path)
            if owner is not None:
                raise AlreadyRunning(owner)
            _PROCESS_LEASES[self._registry_path] = self.pid
        try:
            if sys.platform == "win32":  # pragma: no cover - Windows host only
                _ensure_windows_lock_directory(self.path.parent)
                descriptor = _open_windows_lock_file(self.path)
            else:
                directory = _ensure_posix_lock_directory(self.path.parent)
                try:
                    descriptor = _open_posix_lock_file(directory, self.path)
                finally:
                    os.close(directory)
        except BaseException:
            with _PROCESS_LEASES_LOCK:
                _PROCESS_LEASES.pop(self._registry_path, None)
            raise
        try:
            if sys.platform == "win32":  # pragma: no cover - Windows host only
                # Keep the diagnostic PID outside the mandatory byte-range
                # lock so a contending process can still report its owner.
                if os.fstat(descriptor).st_size <= _WINDOWS_LOCK_OFFSET:
                    os.lseek(descriptor, 0, os.SEEK_SET)
                    os.write(descriptor, b"\0" * (_WINDOWS_LOCK_OFFSET + 1))
                    os.fsync(descriptor)
                os.lseek(descriptor, _WINDOWS_LOCK_OFFSET, os.SEEK_SET)
                try:
                    msvcrt.locking(descriptor, msvcrt.LK_NBLCK, 1)
                except OSError as error:
                    if error.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                        raise
                    raise AlreadyRunning(self._owner_pid(descriptor)) from error
            else:
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError as error:
                    if error.errno not in (errno.EACCES, errno.EAGAIN):
                        raise
                    raise AlreadyRunning(self._owner_pid(descriptor)) from error

            payload = f"{self.pid}\n".encode("ascii")
            os.lseek(descriptor, 0, os.SEEK_SET)
            if sys.platform == "win32":
                os.write(descriptor, payload.ljust(_PID_PAYLOAD_BYTES, b"\0"))
            else:
                os.ftruncate(descriptor, 0)
                os.write(descriptor, payload)
            os.fsync(descriptor)
            self._descriptor = descriptor
            return self
        except BaseException:
            os.close(descriptor)
            with _PROCESS_LEASES_LOCK:
                _PROCESS_LEASES.pop(self._registry_path, None)
            raise

    def release(self) -> None:
        descriptor = self._descriptor
        if descriptor is None:
            return
        self._descriptor = None
        try:
            if sys.platform == "win32":  # pragma: no cover - Windows host only
                try:
                    os.lseek(descriptor, _WINDOWS_LOCK_OFFSET, os.SEEK_SET)
                    msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
            else:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)
            with _PROCESS_LEASES_LOCK:
                _PROCESS_LEASES.pop(self._registry_path, None)

    def __enter__(self) -> "ConnectionLease":
        return self.acquire()

    def __exit__(self, _type: object, _value: object, _traceback: object) -> None:
        self.release()


__all__ = [
    "AlreadyRunning",
    "CONNECTION_LOCK_NAME",
    "ConnectionLease",
    "LAUNCHD_LABEL",
    "MACOS_SERVICE_STOP_MANAGER_TIMEOUT_SECONDS",
    "SYSTEMD_UNIT",
    "SERVICE_MANAGER_TIMEOUT_SECONDS",
    "ServiceAction",
    "ServiceCommandError",
    "ServiceController",
    "ServiceDefinition",
    "ServiceError",
    "ServiceTimeoutError",
    "WINDOWS_LOCAL_SYSTEM_SID",
    "WINDOWS_TASK",
    "render_service",
]
