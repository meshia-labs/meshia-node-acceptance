"""Mount-worker side of the split-process, account-wide ``Meshia`` mount.

The engine keeps ``WorkspaceRuntimeManager`` and every coordinator; this
module keeps the namespace. It owns the real ``MultiWorkspaceMountBackend``
and, per activated workspace, a real ``FabricMountBackend`` over the mount
process's own ``FabricDatabase``/``FabricRangeCache`` handles, with a
``CoordinatorProxy`` standing in for the engine-side coordinator.

``WorkerWorkspaceBackend`` is the mount-process twin of
``workspace_runtime._LazyWorkspaceBackend``: the same explicit per-operation
whitelist (each method carries its own admission semantics, so a blanket
``__getattr__`` would apply the wrong ones to a future method) and the same
lazy activation, except that activation asks the engine over IPC for the
workspace's state paths instead of constructing a coordinator, and the
mutation-ready fence is answered by the engine once per catalog projection
rather than evaluated locally.

Everything that must be a single truth stays in the engine: which workspaces
exist and under which label, their quota, which are running, whether a first
mutation may proceed. The engine pushes those projections here and this module
applies them exactly as the manager applies them to the in-process backend.
"""

from __future__ import annotations

import errno
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable, Mapping

from .errors import StateError
from .fabric_cache import FabricRangeCache
from .fabric_db import FabricDatabase
from .fabric_mount import (
    FabricMountBackend,
    MountNode,
    MultiWorkspaceMountBackend,
    _RemoteQuotaCapacity,
)
from .log import NULL_LOGGER, NodeLogger
from .sync_engine_ipc import IpcError, IpcRemoteError, IpcUnavailable
from .sync_engine_split import (
    ACTIVATE_TIMEOUT_SECONDS,
    STAGE_TIMEOUT_SECONDS,
    EngineLink,
    LocalCacheReader,
    _exception_from_remote,
)
from .workspace import WorkspaceBoundary

# A cold activation that loses a CATALOG_CHANGED race is retried by the
# engine; this bound only covers the link itself flapping mid-activation.
ACTIVATION_ATTEMPTS = 2


def _engine_error(error: IpcError) -> OSError:
    if isinstance(error, IpcRemoteError):
        rebuilt = _exception_from_remote(error)
        if isinstance(rebuilt, OSError):
            return rebuilt
        return OSError(errno.EIO, str(rebuilt))
    if isinstance(error, IpcUnavailable):
        return OSError(errno.EIO, "The Meshia sync engine is not running.")
    return OSError(errno.EIO, f"The Meshia sync engine failed: {error}")


class _WorkerRuntime:
    """One activated workspace: local handles plus the real mount backend."""

    def __init__(
        self,
        *,
        database: FabricDatabase,
        cache: FabricRangeCache,
        workspace: WorkspaceBoundary,
        backend: FabricMountBackend,
    ) -> None:
        self.database = database
        self.cache = cache
        self.workspace = workspace
        self.backend = backend

    def close(self) -> None:
        try:
            self.backend.close()
        finally:
            try:
                close_cache = getattr(self.cache, "close", None)
                if callable(close_cache):
                    close_cache()
            finally:
                try:
                    self.database.close()
                finally:
                    self.workspace.close()


class WorkerWorkspaceBackend:
    """A ``FabricMountBackend``-shaped proxy that activates over the link."""

    def __init__(
        self,
        manager: "MountWorkerWorkspaceManager",
        session_id: str,
        workspace_name: str,
        catalog: Mapping[str, Any],
    ) -> None:
        self._manager = manager
        self._session_id = session_id
        self._name_lock = threading.Lock()
        self._workspace_name = workspace_name
        self._remote_quota = _RemoteQuotaCapacity()
        self._stage_capacity: Any | None = None
        self._activation_lock = threading.Lock()
        self._mutation_admission_lock = threading.Lock()
        self._mutation_projection = 0
        self._runtime: _WorkerRuntime | None = None
        self._closed = False
        self._command_borrows = 0
        # Answered by the engine once per projection; see _require_mutation_ready.
        self._mutation_ready = False
        self.set_workspace_storage(catalog)

    # -- projection ----------------------------------------------------------

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def workspace_name(self) -> str:
        with self._name_lock:
            return self._workspace_name

    def set_workspace_name(self, value: str) -> None:
        with self._name_lock:
            self._workspace_name = value
            runtime = self._runtime
        if runtime is not None and runtime.backend.workspace_name != value:
            runtime.backend.set_workspace_name(value)

    def set_workspace_storage(self, catalog: Mapping[str, Any]) -> None:
        generation = catalog.get("catalog_generation", 0)
        self._remote_quota.update_catalog(
            catalog_generation=int(generation) if isinstance(generation, int) else 0,
            quota_bytes=catalog.get("quota_bytes"),
            used_bytes=catalog.get("used_bytes"),
            reserved_bytes=catalog.get("reserved_bytes"),
        )
        with self._name_lock:
            # A new projection may carry a new attachment or a repaired
            # authority; the next mutation re-asks the engine. Reads never do.
            self._mutation_ready = False
            self._mutation_projection += 1

    def set_stage_capacity(self, capacity: Any) -> None:
        with self._name_lock:
            if self._stage_capacity is capacity:
                return
            self._stage_capacity = capacity
            runtime = self._runtime
        if runtime is not None:
            runtime.backend.set_stage_capacity(capacity)

    @property
    def stage_capacity(self) -> Any | None:
        with self._name_lock:
            return self._stage_capacity

    def statfs_capacity(self) -> tuple[int, int] | None:
        """Authoritative remote quota and used bytes without activation."""

        return self._remote_quota.snapshot()

    @property
    def remote_quota(self) -> _RemoteQuotaCapacity:
        return self._remote_quota

    @property
    def activated(self) -> bool:
        with self._name_lock:
            return self._runtime is not None

    # -- activation ----------------------------------------------------------

    def _borrow(self) -> FabricMountBackend:
        with self._name_lock:
            runtime = self._runtime
            closed = self._closed
        if runtime is not None:
            return runtime.backend
        if closed:
            raise OSError(errno.ESTALE, "The workspace route was retired.")
        with self._activation_lock:
            with self._name_lock:
                runtime = self._runtime
            if runtime is not None:
                return runtime.backend
            runtime = self._activate()
            with self._name_lock:
                self._runtime = runtime
            return runtime.backend

    def _activate(self) -> _WorkerRuntime:
        described: Mapping[str, Any] | None = None
        last_error: OSError | None = None
        for attempt in range(ACTIVATION_ATTEMPTS):
            try:
                described = self._manager.activate(self._session_id)
                break
            except OSError as error:
                last_error = error
                if error.errno != errno.EIO or attempt + 1 >= ACTIVATION_ATTEMPTS:
                    raise
                time.sleep(0.2)
        if described is None:
            raise last_error or OSError(errno.EIO, "The workspace did not activate.")
        with self._name_lock:
            label = self._workspace_name
            capacity = self._stage_capacity
        database: FabricDatabase | None = None
        cache: FabricRangeCache | None = None
        workspace: WorkspaceBoundary | None = None
        backend: FabricMountBackend | None = None
        try:
            database = FabricDatabase(Path(str(described["database_path"])))
            cache = FabricRangeCache(Path(str(described["cache_path"])))
            workspace = WorkspaceBoundary(Path(str(described["workspace_root"])))
            coordinator = self._manager.link.proxy(
                self._session_id,
                local_reader=LocalCacheReader(database, cache),
            )
            backend = FabricMountBackend(
                database,
                coordinator,  # type: ignore[arg-type] - the proxy is the coordinator surface
                workspace,
                label,
                logger=self._manager.logger,
                fuse_t_transport_backend=self._manager.fuse_t_transport_backend,
            )
            if capacity is not None:
                backend.set_stage_capacity(capacity)
            backend.set_remote_quota(self._remote_quota)
        except BaseException:
            if backend is not None:
                try:
                    backend.close()
                except Exception:  # noqa: BLE001 - best-effort unwind
                    pass
            if database is not None:
                try:
                    database.close()
                except Exception:  # noqa: BLE001
                    pass
            if workspace is not None:
                try:
                    workspace.close()
                except Exception:  # noqa: BLE001
                    pass
            raise
        self._manager.logger.record(
            "mount_worker_workspace_activated",
            session_id=self._session_id,
            label=label,
        )
        return _WorkerRuntime(
            database=database, cache=cache, workspace=workspace, backend=backend
        )

    def _require_mutation_ready(self) -> None:
        with self._name_lock:
            if self._mutation_ready:
                return
        # The engine grants one foreground waiter a recovery grace. Without
        # single-flight admission, concurrent Finder CREATEs all cross IPC:
        # the first waits but its siblings get EAGAIN (shown as permission
        # denied by SMB). Share that wait, not the actual file operations.
        with self._mutation_admission_lock:
            while True:
                with self._name_lock:
                    if self._mutation_ready:
                        return
                    projection = self._mutation_projection
                self._manager.await_mutation_ready(self._session_id)
                with self._name_lock:
                    if projection == self._mutation_projection:
                        self._mutation_ready = True
                        return
                    # A projection changed while the IPC was pending. Its
                    # new authority must be admitted before accepting writes.

    def _call(
        self,
        operation: str,
        *args: Any,
        require_mutation_ready: bool = False,
        **kwargs: Any,
    ) -> Any:
        backend = self._borrow()
        if require_mutation_ready:
            self._require_mutation_ready()
        return getattr(backend, operation)(*args, **kwargs)

    # -- the mount surface (mirror of _LazyWorkspaceBackend) --------------------

    def getattr(self, path: str) -> MountNode:
        return self._call("getattr", path)

    def getattr_handle(self, handle: int) -> MountNode:
        return self._call("getattr_handle", handle)

    def listdir(self, path: str) -> tuple[str, ...]:
        return self._call("listdir", path)

    def listdir_entries(self, path: str) -> tuple[tuple[str, MountNode], ...]:
        return self._call("listdir_entries", path)

    def open(self, path: str, flags: int, *, create: bool = False) -> int:
        backend = self._borrow()
        writable = bool(
            create
            or flags & (os.O_CREAT | os.O_TRUNC | os.O_APPEND)
            or flags & (os.O_WRONLY | os.O_RDWR)
        )
        if writable:
            self._require_mutation_ready()
        return backend.open(path, flags, create=create)

    def read(self, handle: int, offset: int, size: int) -> bytes:
        return self._call("read", handle, offset, size)

    def write(self, handle: int, offset: int, data: bytes) -> int:
        return self._call("write", handle, offset, data)

    def truncate(
        self, path: str | None, length: int, *, handle: int | None = None
    ) -> None:
        if handle is None:
            self._call("truncate", path, length, require_mutation_ready=True)
            return
        self._call("truncate", path, length, handle=handle)

    def fsync(self, handle: int) -> None:
        self._call("fsync", handle)

    def flush(self, handle: int) -> None:
        self._call("flush", handle)

    def release(self, handle: int) -> None:
        self._call("release", handle)

    def unlink(self, path: str) -> None:
        backend = self._borrow()
        try:
            self._require_mutation_ready()
        except OSError as error:
            if error.errno != errno.EAGAIN:
                raise
            # FUSE-T 1.2.7 discards transient unlink errors during SMB CLOSE.
            # The callback itself is deletion authority, so retain that intent
            # locally and let Fabric retry it after recovery.
            backend.defer_unlink(path)
            self._manager.wake(self._session_id)
            return
        try:
            backend.unlink(path)
        except OSError as error:
            if error.errno != errno.EAGAIN:
                raise
            backend.defer_unlink(path)
            self._manager.wake(self._session_id)

    def defer_unlink(self, path: str) -> None:
        self._borrow().defer_unlink(path)

    def mkdir(self, path: str) -> None:
        self._call("mkdir", path, require_mutation_ready=True)

    def rmdir(self, path: str) -> None:
        self._call("rmdir", path, require_mutation_ready=True)

    def getxattr(self, path: str, name: str, position: int = 0) -> bytes:
        return bytes(self._call("getxattr", path, name, position))

    def listxattr(self, path: str) -> list[str]:
        return list(self._call("listxattr", path))

    def setxattr(
        self,
        path: str,
        name: str,
        value: bytes,
        options: int,
        position: int = 0,
    ) -> None:
        self._call(
            "setxattr",
            path,
            name,
            value,
            options,
            position,
            require_mutation_ready=True,
        )

    def removexattr(self, path: str, name: str) -> None:
        self._call("removexattr", path, name, require_mutation_ready=True)

    def set_times(self, path: str, times: Any | None = None) -> None:
        self._call("set_times", path, times, require_mutation_ready=True)

    def rename(self, source: str, destination: str) -> None:
        if source == f"/{self.workspace_name}" and destination.count("/") == 1:
            accepted = self._manager.rename_workspace_root(
                self._session_id, self.workspace_name, destination[1:]
            )
            self.set_workspace_name(accepted)
            return
        self._call("rename", source, destination, require_mutation_ready=True)

    # -- lifecycle -------------------------------------------------------------

    def can_close(self) -> bool:
        with self._name_lock:
            runtime = self._runtime
            if self._command_borrows:
                return False
        if runtime is None:
            return True
        return bool(runtime.backend.can_close())

    def close(self) -> None:
        # Route retirement is not process shutdown: the manager decides
        # whether the runtime may go now or after its transient work settles.
        self._manager._route_retired(self._session_id, self)  # noqa: SLF001 - pair

    def _close_runtime(self, *, force: bool) -> bool:
        """Close the local runtime; ``False`` when it still has transient work."""

        with self._activation_lock:
            with self._name_lock:
                if self._command_borrows and not force:
                    return False
                runtime = self._runtime
                if runtime is None:
                    self._closed = True
                    return True
                if not force and not runtime.backend.can_close():
                    return False
                self._runtime = None
                self._closed = True
            runtime.close()
            return True


class MountWorkerWorkspaceManager:
    """Apply engine-pushed projections to the real multi-workspace backend."""

    def __init__(
        self,
        link: EngineLink,
        *,
        storage_root: os.PathLike[str] | str,
        fuse_t_transport_backend: str | None = None,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        self.link = link
        self.logger = logger
        self.fuse_t_transport_backend = fuse_t_transport_backend
        self.mount_backend = MultiWorkspaceMountBackend(storage_root, logger=logger)
        self._lock = threading.RLock()
        self._proxies: dict[str, WorkerWorkspaceBackend] = {}
        self._labels: dict[str, str] = {}
        self._retired_busy: dict[str, WorkerWorkspaceBackend] = {}
        self._closed = False
        link.install_handlers(
            {
                "replace_workspaces": self._on_replace_workspaces,
                "set_compute_running": self._on_set_compute_running,
                "set_workspace_modified": self._on_set_workspace_modified,
                "invalidate_workspace": self._on_invalidate_workspace,
                "workspace_can_close": self._on_workspace_can_close,
            }
        )
        link.install_filesystem_command_handler(self._command_filesystem)

    def _command_filesystem(
        self, session_id: str, operation: str, **arguments: Any
    ) -> dict[str, Any]:
        from .command_filesystem import execute_backend_command

        # Resolve by immutable session, never a user-editable label or host
        # path. Pin the worker runtime before releasing the projection lock;
        # activation/streaming/staging can call the engine and must not hold
        # that lock while it potentially pushes a new topology back to us.
        with self._lock:
            if self._closed:
                raise OSError(errno.EIO, "The mount worker is closing.")
            proxy = self._proxies.get(session_id)
            if proxy is None or session_id not in self._labels:
                raise OSError(errno.ENOENT, "The workspace is not visible in this mount.")
            with proxy._name_lock:  # noqa: SLF001 - owning manager
                if proxy._closed:  # noqa: SLF001
                    raise OSError(errno.ESTALE, "The workspace route was retired.")
                proxy._command_borrows += 1  # noqa: SLF001
        try:
            if operation == "write":
                proxy._require_mutation_ready()  # noqa: SLF001 - same mount admission
            return execute_backend_command(
                proxy._borrow(), proxy.workspace_name, operation, **arguments  # noqa: SLF001
            )
        finally:
            with proxy._name_lock:  # noqa: SLF001
                proxy._command_borrows -= 1  # noqa: SLF001
            self._retry_retired_closes()

    # -- engine calls ----------------------------------------------------------

    def _engine_call(self, method: str, *, timeout: float, **kwargs: Any) -> Any:
        try:
            return self.link.endpoint.call(method, timeout=timeout, **kwargs)
        except IpcError as error:
            raise _engine_error(error) from error

    def pull_topology(self) -> None:
        """Fetch and apply the engine's current projection (connect/reconnect)."""

        payload = self._engine_call("topology", timeout=STAGE_TIMEOUT_SECONDS)
        if not isinstance(payload, dict):
            raise OSError(errno.EIO, "The Meshia sync engine sent no projection.")
        self._install(
            payload.get("workspaces") or [],
            running=payload.get("running"),
            modified=payload.get("modified"),
        )

    def activate(self, session_id: str) -> Mapping[str, Any]:
        described = self._engine_call(
            "activate_workspace",
            timeout=ACTIVATE_TIMEOUT_SECONDS,
            session_id=session_id,
        )
        if not isinstance(described, dict):
            raise OSError(errno.EIO, "The Meshia sync engine sent no workspace state.")
        for key in ("database_path", "cache_path", "workspace_root"):
            if not isinstance(described.get(key), str) or not described[key]:
                raise OSError(errno.EIO, f"The workspace state omitted {key}.")
        return described

    def await_mutation_ready(self, session_id: str) -> None:
        self._engine_call(
            "await_mutation_ready",
            timeout=STAGE_TIMEOUT_SECONDS,
            session_id=session_id,
        )

    def rename_workspace_root(
        self, session_id: str, source: str, destination: str
    ) -> str:
        accepted = self._engine_call(
            "rename_workspace_root",
            timeout=STAGE_TIMEOUT_SECONDS,
            session_id=session_id,
            source=source,
            destination=destination,
        )
        if not isinstance(accepted, str) or not accepted:
            raise OSError(errno.EIO, "The Meshia sync engine returned no workspace name.")
        return accepted

    def wake(self, session_id: str) -> None:
        self.link.endpoint.notify("wake", session_id=session_id)

    # -- engine pushes -----------------------------------------------------------

    def _install(
        self,
        workspaces: list[Any],
        *,
        running: Any = None,
        modified: Any = None,
    ) -> None:
        proxies: dict[str, WorkerWorkspaceBackend] = {}
        with self._lock:
            if self._closed:
                raise StateError("The mount worker is closing.")
            seen: set[str] = set()
            for item in workspaces:
                if not isinstance(item, dict):
                    continue
                session_id = item.get("session_id")
                label = item.get("label")
                if not isinstance(session_id, str) or not session_id:
                    continue
                if not isinstance(label, str) or not label:
                    continue
                proxy = self._proxies.get(session_id)
                if proxy is None:
                    proxy = self._retired_busy.pop(session_id, None)
                    if proxy is not None and proxy._closed:  # noqa: SLF001 - pair
                        proxy = None
                if proxy is None:
                    proxy = WorkerWorkspaceBackend(self, session_id, label, item)
                else:
                    proxy.set_workspace_name(label)
                    proxy.set_workspace_storage(item)
                self._proxies[session_id] = proxy
                proxies[label] = proxy
                seen.add(session_id)
            self._labels = {proxy.session_id: label for label, proxy in proxies.items()}
            # Retired routes stay in _proxies until MultiWorkspaceMountBackend
            # drains their handles and calls close(); _route_retired then
            # decides. Only routes gone from BOTH sides are dropped here.
        self.mount_backend.replace_workspaces(proxies)
        if isinstance(running, list):
            self.mount_backend.set_compute_running(
                tuple(str(label) for label in running)
            )
        if isinstance(modified, dict):
            self.mount_backend.set_workspace_modified(
                {
                    str(label): int(stamp)
                    for label, stamp in modified.items()
                    if isinstance(stamp, int) and not isinstance(stamp, bool)
                }
            )
        self._retry_retired_closes()

    def _on_replace_workspaces(self, workspaces: list[Any] | None = None) -> bool:
        self._install(workspaces or [])
        return True

    def _on_set_compute_running(self, labels: list[Any] | None = None) -> list[str]:
        return list(
            self.mount_backend.set_compute_running(
                tuple(str(label) for label in (labels or []))
            )
        )

    def _on_set_workspace_modified(self, modified: dict[str, Any] | None = None) -> bool:
        self.mount_backend.set_workspace_modified(
            {
                str(label): int(stamp)
                for label, stamp in (modified or {}).items()
                if isinstance(stamp, int) and not isinstance(stamp, bool)
            }
        )
        return True

    def _on_invalidate_workspace(
        self, label: str, paths: list[Any] | None = None
    ) -> int:
        return self.mount_backend.invalidate_workspace(
            str(label), tuple(str(path) for path in (paths or []))
        )

    def _on_workspace_can_close(self, session_id: str) -> bool:
        with self._lock:
            proxy = self._proxies.get(session_id) or self._retired_busy.get(session_id)
        if proxy is None:
            return True
        return proxy.can_close()

    # -- lifecycle --------------------------------------------------------------

    def _route_retired(self, session_id: str, proxy: WorkerWorkspaceBackend) -> None:
        with self._lock:
            if self._proxies.get(session_id) is proxy and session_id in self._labels:
                # Still projected: the mount only folded a duplicate route.
                return
            if self._proxies.get(session_id) is proxy:
                self._proxies.pop(session_id, None)
        if not proxy._close_runtime(force=False):  # noqa: SLF001 - pair
            with self._lock:
                self._retired_busy[session_id] = proxy

    def _retry_retired_closes(self) -> None:
        with self._lock:
            pending = tuple(self._retired_busy.items())
        for session_id, proxy in pending:
            if proxy._close_runtime(force=False):  # noqa: SLF001 - pair
                with self._lock:
                    if self._retired_busy.get(session_id) is proxy:
                        self._retired_busy.pop(session_id, None)

    def close(self) -> None:
        """Release every local runtime after the native mount is detached."""

        with self._lock:
            self._closed = True
            proxies = tuple(self._proxies.values()) + tuple(self._retired_busy.values())
            self._proxies = {}
            self._retired_busy = {}
            self._labels = {}
        try:
            self.mount_backend.close()
        except Exception as error:  # noqa: BLE001 - keep releasing runtimes
            self.logger.record(
                "mount_worker_backend_close_failed", error=str(error)[:200]
            )
        for proxy in proxies:
            try:
                proxy._close_runtime(force=True)  # noqa: SLF001 - pair
            except Exception as error:  # noqa: BLE001
                self.logger.record(
                    "mount_worker_runtime_close_failed",
                    session_id=proxy.session_id,
                    error=str(error)[:200],
                )


Callback = Callable[..., Any]
