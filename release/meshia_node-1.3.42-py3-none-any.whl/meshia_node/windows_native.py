"""Windows native workspace execution in a less privileged AppContainer.

The process keeps the user's CPU and network, but Windows performs a second
access check against one workspace identity. ALL APPLICATION PACKAGES is
explicitly disabled; low integrity alone is not a read boundary. The outer
winexec Job owns this trusted launcher and every descendant before any command
environment is deserialized. No elevated service, Docker or WSL is involved.
"""
from __future__ import annotations

import ctypes
import hashlib
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile
import threading
import time

from .errors import AccessRefused
from .winexec import _ProcessInformation, _StartupInfo, environment_block

KIND = "windows-lpac"
_CAPABILITIES = ("internetClientServer", "privateNetworkClientServer", "registryRead", "lpacCom",
                 "meshiaNullDevice")
_SECURITY_CAPABILITIES = 0x00020009
_HANDLE_LIST = 0x00020002
_ALL_APPLICATION_PACKAGES_POLICY = 0x0002000F
_WINSTA_COMPATIBILITY_RIGHTS = 0x00020020  # READ_CONTROL | WINSTA_ACCESSGLOBALATOMS
_acl_thread_lock = threading.RLock()
_desktop_grants: dict[tuple[int, str], int] = {}
_probe_failure = "The workspace policy has not been probed."
_probe_lock = threading.Lock()
_probe_ready = False
_probe_retry_after = 0.0
_FAILED_PROBE_RETRY_SECONDS = 30.0


class _SidAndAttributes(ctypes.Structure):
    _fields_ = [("Sid", ctypes.c_void_p), ("Attributes", ctypes.c_ulong)]


class _SecurityCapabilities(ctypes.Structure):
    _fields_ = [("AppContainerSid", ctypes.c_void_p),
                ("Capabilities", ctypes.POINTER(_SidAndAttributes)),
                ("CapabilityCount", ctypes.c_ulong), ("Reserved", ctypes.c_ulong)]


class _StartupInfoEx(ctypes.Structure):
    _fields_ = [("StartupInfo", _StartupInfo), ("lpAttributeList", ctypes.c_void_p)]


class _SecurityAttributes(ctypes.Structure):
    _fields_ = [("nLength", ctypes.c_ulong), ("lpSecurityDescriptor", ctypes.c_void_p),
                ("bInheritHandle", ctypes.c_int)]


class _Trustee(ctypes.Structure):
    _fields_ = [("pMultipleTrustee", ctypes.c_void_p),
                ("MultipleTrusteeOperation", ctypes.c_ulong),
                ("TrusteeForm", ctypes.c_ulong), ("TrusteeType", ctypes.c_ulong),
                ("ptstrName", ctypes.c_void_p)]


class _ExplicitAccess(ctypes.Structure):
    _fields_ = [("grfAccessPermissions", ctypes.c_ulong),
                ("grfAccessMode", ctypes.c_ulong), ("grfInheritance", ctypes.c_ulong),
                ("Trustee", _Trustee)]


def _error(operation: str) -> AccessRefused:
    return AccessRefused(f"Windows workspace isolation: {operation} failed ({ctypes.get_last_error()}).")


def _libraries():
    if sys.platform != "win32":
        raise AccessRefused("Windows workspace isolation requires Windows.")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    userenv = ctypes.WinDLL("userenv", use_last_error=True)
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    base = ctypes.WinDLL("kernelbase", use_last_error=True)
    handle = ctypes.c_void_p
    kernel.LocalFree.argtypes = [handle]
    kernel.LocalFree.restype = handle
    kernel.CloseHandle.argtypes = [handle]
    kernel.GetStdHandle.argtypes = [ctypes.c_ulong]
    kernel.GetStdHandle.restype = handle
    kernel.SetHandleInformation.argtypes = [handle, ctypes.c_ulong, ctypes.c_ulong]
    kernel.InitializeProcThreadAttributeList.argtypes = [handle, ctypes.c_ulong, ctypes.c_ulong,
                                                        ctypes.POINTER(ctypes.c_size_t)]
    kernel.UpdateProcThreadAttribute.argtypes = [handle, ctypes.c_ulong, ctypes.c_size_t,
        handle, ctypes.c_size_t, handle, handle]
    kernel.DeleteProcThreadAttributeList.argtypes = [handle]
    kernel.CreateProcessW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, handle, handle,
        ctypes.c_int, ctypes.c_ulong, handle, ctypes.c_wchar_p, handle, handle]
    kernel.WaitForSingleObject.argtypes = [handle, ctypes.c_ulong]
    kernel.WaitForSingleObject.restype = ctypes.c_ulong
    kernel.GetExitCodeProcess.argtypes = [handle, ctypes.POINTER(ctypes.c_ulong)]
    advapi.FreeSid.argtypes = [handle]
    advapi.FreeSid.restype = handle
    advapi.ConvertSidToStringSidW.argtypes = [handle, ctypes.POINTER(ctypes.c_wchar_p)]
    advapi.ConvertStringSidToSidW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(handle)]
    userenv.DeriveAppContainerSidFromAppContainerName.argtypes = [ctypes.c_wchar_p,
                                                               ctypes.POINTER(handle)]
    userenv.CreateAppContainerProfile.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p,
        ctypes.c_wchar_p, handle, ctypes.c_ulong, ctypes.POINTER(handle)]
    userenv.DeleteAppContainerProfile.argtypes = [ctypes.c_wchar_p]
    userenv.GetAppContainerFolderPath.argtypes = [ctypes.c_wchar_p,
                                                 ctypes.POINTER(ctypes.c_wchar_p)]
    base.DeriveCapabilitySidsFromName.argtypes = [ctypes.c_wchar_p,
        ctypes.POINTER(ctypes.POINTER(handle)), ctypes.POINTER(ctypes.c_ulong),
        ctypes.POINTER(ctypes.POINTER(handle)), ctypes.POINTER(ctypes.c_ulong)]
    return kernel, userenv, advapi, base


def available() -> bool:
    """Cache success; retry failed startup prerequisites on bounded demand.

    The ordinary node can start before Windows' fixed boot prerequisite task.
    Existing heartbeat/command callers drive recovery; no polling worker is
    added. Concurrent callers refuse while one complete OS canary is running.
    Cached success never bypasses the LPAC applied to every actual command.
    """
    global _probe_ready, _probe_retry_after, _probe_failure
    if _probe_ready:
        return True
    if time.monotonic() < _probe_retry_after or not _probe_lock.acquire(blocking=False):
        return False
    try:
        if _probe_ready or time.monotonic() < _probe_retry_after:
            return _probe_ready
        _probe_failure = "The workspace policy probe is running."
        _probe_ready = _probe_available()
        return _probe_ready
    finally:
        _probe_retry_after = time.monotonic() + _FAILED_PROBE_RETRY_SECONDS
        _probe_lock.release()


def _probe_available() -> bool:
    """Prove installed tool startup, NUL access and actual NT read/write denial."""
    global _probe_failure
    try:
        _libraries()
        from .executor import native_environment, run_bounded_subprocess
        from .native_command import command_argv, command_stdin
        from .util import console_python
        with tempfile.TemporaryDirectory(prefix="meshia-policy-") as temporary:
            directory = Path(temporary)
            workspace = directory / "workspace"
            workspace.mkdir()
            outside = directory / "outside.txt"
            outside.write_bytes(b"policy-canary")
            code = """import ctypes,os,pathlib,ssl,subprocess,sys,tempfile,_hashlib
root=pathlib.Path.cwd()
(root/'allowed').write_bytes(b'yes')
assert (root/'allowed').read_bytes()==b'yes'
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
user=ctypes.WinDLL('user32',use_last_error=True)
kernel.GetCurrentThreadId.restype=ctypes.c_ulong
user.GetThreadDesktop.argtypes=[ctypes.c_ulong]
user.GetThreadDesktop.restype=ctypes.c_void_p
user.GetUserObjectInformationW.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,
 ctypes.c_ulong,ctypes.POINTER(ctypes.c_ulong)]
desktop=user.GetThreadDesktop(kernel.GetCurrentThreadId())
needed=ctypes.c_ulong()
user.GetUserObjectInformationW(desktop,2,None,0,ctypes.byref(needed))
desktop_name=ctypes.create_unicode_buffer(needed.value//ctypes.sizeof(ctypes.c_wchar)+1)
assert user.GetUserObjectInformationW(desktop,2,desktop_name,ctypes.sizeof(desktop_name),
 ctypes.byref(needed))
assert desktop_name.value.startswith('Meshia-')
user.OpenDesktopW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong]
user.OpenDesktopW.restype=ctypes.c_void_p
assert not user.OpenDesktopW('Default',0,False,1)
# Exercise the OS device and the unmodified library path before advertising
# Limited readiness. Inherited stdio alone cannot prove DEVNULL compatibility.
null_fd=os.open(os.devnull,os.O_RDWR)
try:
 assert os.write(null_fd,b'null-device-canary')==18
 assert os.read(null_fd,1)==b''
finally: os.close(null_fd)
assert subprocess.run([sys.executable,'-I','-c','pass'],stdin=subprocess.DEVNULL,
 stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5).returncode==0
with tempfile.NamedTemporaryFile(delete=False) as stream:
 stream.write(b'temporary-workspace-data')
 temporary=pathlib.Path(stream.name)
assert temporary.parent.resolve()==root
assert temporary.read_bytes()==b'temporary-workspace-data'
temporary.unlink()
for operation in ('read','write'):
 try:
  path=pathlib.Path(sys.argv[1])
  path.read_bytes() if operation=='read' else path.write_bytes(b'no')
 except PermissionError: pass
 else: raise RuntimeError('workspace boundary was bypassed')
profile=pathlib.Path(sys.argv[2])
for operation in ('read','write'):
 try:
  list(profile.iterdir()) if operation=='read' else (profile/'forbidden').write_bytes(b'no')
 except PermissionError: pass
 else: raise RuntimeError('OS profile storage escaped the workspace boundary')
print('meshia-lpac-ready')
"""
            try:
                _, profile = create_profile(workspace)
                output, status, truncated, timed_out = run_bounded_subprocess(
                    command_argv([console_python(), "-I", "-c", code, str(outside), str(profile)],
                                 root=str(workspace), cwd=".", access="limited"),
                    cwd=os.path.abspath(os.sep), env=native_environment(), timeout_seconds=15,
                    max_output_bytes=4096, stdin=command_stdin({}, None),
                )
                passed = (status == 0 and not truncated and not timed_out
                        and output.strip() == b"meshia-lpac-ready"
                        and outside.read_bytes() == b"policy-canary")
                if not passed:
                    # Only the fixed local canary runs here, before credentials
                    # or caller commands. Preserve its bounded startup error so
                    # an installer can explain the OS failure accurately.
                    _probe_failure = (f"Probe exited {status}, timeout={timed_out}: "
                                      + output.decode("utf-8", errors="replace").strip()[-1000:])
                return passed
            finally:
                revoke_runtime_grants(workspace)
    except (AttributeError, OSError, AccessRefused, subprocess.SubprocessError) as error:
        _probe_failure = str(error)[-1000:]
        return False


def detail() -> str:
    return ("Windows workspace compute uses a less privileged AppContainer."
            if available() else "Windows cannot establish the workspace AppContainer boundary: " + _probe_failure)


def _profile_name(workspace: Path, user: str) -> str:
    key = hashlib.sha256((user + "\0" + os.path.normcase(str(workspace))).encode()).hexdigest()[:40]
    return "Meshia.Workspace." + key


def identity(workspace: Path) -> tuple[str, str]:
    """Derive the exact principal used by the view, runtime ACL and OS profile."""
    from .winsec import current_user_sid
    kernel, userenv, advapi, _ = _libraries()
    user = current_user_sid()
    sid = ctypes.c_void_p()
    if userenv.DeriveAppContainerSidFromAppContainerName(_profile_name(workspace, user),
                                                       ctypes.byref(sid)) != 0:
        raise _error("derive workspace principal")
    text = ctypes.c_wchar_p()
    try:
        if not advapi.ConvertSidToStringSidW(sid, ctypes.byref(text)):
            raise _error("read workspace principal")
        return user, str(text.value)
    finally:
        if text:
            kernel.LocalFree(text)
        advapi.FreeSid(sid)


def create_profile(workspace: Path) -> tuple[str, Path]:
    """Create the OS namespace required by CreateProcess, without extra data access."""
    from .config import file_lock
    user, package = identity(workspace)
    name = _profile_name(workspace, user)
    kernel, userenv, advapi, _ = _libraries()
    sid = ctypes.c_void_p()
    folder = ctypes.c_wchar_p()
    ole = ctypes.WinDLL("ole32", use_last_error=True)
    ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
    result = None
    with _acl_thread_lock, file_lock(Path.home() / ".meshia/locks/native-runtime-acl.lock"):
        try:
            result = userenv.CreateAppContainerProfile(name, "Meshia workspace", "Meshia workspace execution",
                                                       None, 0, ctypes.byref(sid)) & 0xFFFFFFFF
            if result not in (0, 0x800700B7):
                raise AccessRefused(f"Windows could not create its workspace profile (HRESULT {result:#x}).")
            if userenv.GetAppContainerFolderPath(package, ctypes.byref(folder)) != 0 or not folder.value:
                raise _error("locate workspace profile storage")
            storage = Path(folder.value)
            # Windows commonly returns the AC child. Protect the whole exact
            # profile tree, including LocalState, so KnownFolder APIs cannot
            # silently add another writable data location outside the workspace.
            roots = (storage, *storage.parents)
            profile = next((path for path in roots if path.name.casefold() == name.casefold()), None)
            if profile is None:
                raise AccessRefused("Windows returned an unexpected workspace profile storage path.")
            system = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/icacls.exe"
            denied = subprocess.run([str(system), str(profile), "/deny", f"*{package}:(OI)(CI)(F)",
                                     "/T", "/L", "/Q"], capture_output=True, timeout=30, check=False)
            if denied.returncode:
                raise AccessRefused("Windows could not restrict its implicit workspace profile storage.")
            return package, profile
        except BaseException:
            # Only retire a profile created by this failed call. An existing
            # profile may still belong to another command in the same workspace.
            if result == 0:
                userenv.DeleteAppContainerProfile(name)
            raise
        finally:
            if sid:
                advapi.FreeSid(sid)
            if folder:
                ole.CoTaskMemFree(folder)


def _delete_profile(workspace: Path) -> None:
    from .config import file_lock
    user, _ = identity(workspace)
    _, userenv, _, _ = _libraries()
    with _acl_thread_lock, file_lock(Path.home() / ".meshia/locks/native-runtime-acl.lock"):
        result = userenv.DeleteAppContainerProfile(_profile_name(workspace, user)) & 0xFFFFFFFF
        if result:
            raise AccessRefused(f"Windows could not retire its workspace profile (HRESULT {result:#x}).")


def runtime_read_roots() -> tuple[Path, ...]:
    """Trusted interpreter installations; command argv/environment grant no paths."""
    home = Path.home().resolve()
    candidates = [Path(sys.prefix), Path(sys.base_prefix)]
    # User-installed compilers and package managers. Never grant a whole user
    # profile, AppData, .meshia state, Desktop or Downloads.
    candidates += [home / part for part in (
        "AppData/Local/Programs/Python", "AppData/Local/Programs/Microsoft VS Code/bin",
        "AppData/Local/uv/python", ".local/share/uv/python", ".cargo/bin",
        ".rustup/toolchains", ".pyenv/pyenv-win/versions", "miniconda3", "anaconda3")]
    roots = []
    for candidate in candidates:
        resolved = candidate.resolve()
        if (resolved == home or resolved == Path(resolved.anchor)
            or resolved in (home / ".meshia", home / "AppData", home / "AppData/Local")
            or any(resolved == home / name or home / name in resolved.parents
                   for name in ("Desktop", "Downloads", "Documents", "Pictures", "Music", "Videos"))):
            raise AccessRefused("An installed runtime resolves into personal data.")
        if resolved.is_dir() and resolved not in roots:
            roots.append(resolved)
    return tuple(roots)


def _grant(path: Path, sid: str, rights: str) -> None:
    # Only the exact package SID gains access, never all applications. Inherited
    # grants belong to the selected directory; junction targets retain their
    # own security descriptor and must independently pass the package check.
    system = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/icacls.exe"
    from .config import file_lock
    # icacls updates a complete DACL. Independent command helpers must not race
    # another workspace's grant or retirement and lose that workspace's ACE.
    with _acl_thread_lock, file_lock(Path.home() / ".meshia/locks/native-runtime-acl.lock"):
        result = subprocess.run([str(system), str(path), "/grant", f"*{sid}:(OI)(CI)({rights})", "/Q"],
                                capture_output=True, timeout=30, check=False)
    if result.returncode:
        raise AccessRefused("Windows could not grant the workspace principal its exact filesystem access.")


def revoke_runtime_grants(workspace: Path) -> None:
    """Remove only this inactive workspace's package ACEs after its Jobs stop."""
    _, sid = identity(workspace)
    system = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/icacls.exe"
    from .config import file_lock
    failures: list[Exception] = []
    try:
        for runtime in runtime_read_roots():
            try:
                with _acl_thread_lock, file_lock(Path.home() / ".meshia/locks/native-runtime-acl.lock"):
                    completed = subprocess.run([str(system), str(runtime), "/remove:g", f"*{sid}", "/Q"],
                                               capture_output=True, timeout=30, check=False)
                if completed.returncode:
                    raise AccessRefused("Windows could not retire an inactive workspace runtime grant.")
            except (OSError, subprocess.SubprocessError, AccessRefused) as error:
                # One inaccessible installation must not leave every later
                # runtime's exact package grant behind during retirement.
                failures.append(error)
    except (OSError, AccessRefused) as error:
        failures.append(error)
    finally:
        try:
            _delete_profile(workspace)
        except (OSError, AccessRefused) as error:
            failures.append(error)
    if failures:
        raise AccessRefused("Windows could not fully retire the inactive workspace policy "
                            f"({len(failures)} cleanup operations failed).") from ExceptionGroup(
                                "Windows workspace retirement failures", failures)


def _private_volume(workspace: Path) -> str | None:
    """Read exact mounted security, never treat an acknowledged chmod as proof."""
    kernel, _, advapi, _ = _libraries()
    kernel.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_ulong,
                                  ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_void_p]
    kernel.CreateFileW.restype = ctypes.c_void_p
    kernel.GetVolumeInformationByHandleW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong,
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong]
    handle = kernel.CreateFileW(str(workspace), 0, 7, None, 3, 0x02000000, None)
    if handle == ctypes.c_void_p(-1).value:
        raise _error("open workspace security")
    filesystem = ctypes.create_unicode_buffer(64)
    try:
        if not kernel.GetVolumeInformationByHandleW(handle, None, 0, None, None, None,
                                                    filesystem, len(filesystem)):
            raise _error("read workspace filesystem")
    finally:
        kernel.CloseHandle(handle)
    if filesystem.value == "NTFS":
        return None
    if filesystem.value != "MeshiaWorkspace":
        raise AccessRefused("Windows workspace compute requires its exact isolated filesystem view.")
    advapi.GetNamedSecurityInfoW.argtypes = [ctypes.c_wchar_p, ctypes.c_int, ctypes.c_ulong,
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_void_p)]
    advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW.argtypes = [ctypes.c_void_p,
        ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(ctypes.c_wchar_p), ctypes.c_void_p]
    descriptor, sddl = ctypes.c_void_p(), ctypes.c_wchar_p()
    try:
        if advapi.GetNamedSecurityInfoW(str(workspace), 1, 4, None, None, None, None,
                                       ctypes.byref(descriptor)) != 0:
            raise _error("read mounted workspace policy")
        if not advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW(descriptor, 1, 4,
                                                                           ctypes.byref(sddl), None):
            raise _error("inspect mounted workspace policy")
        packages = re.findall(r"\(A;;0x1301bf;;;(S-1-15-2-[0-9-]+)\)", str(sddl.value))
        if len(packages) != 1:
            raise AccessRefused("Windows workspace volume lacks its exact isolated execution principal.")
        return packages[0]
    finally:
        if sddl:
            kernel.LocalFree(sddl)
        if descriptor:
            kernel.LocalFree(descriptor)


def workspace_directory(root: Path | str) -> Path:
    """Validate the literal workspace without requiring a DOS volume name.

    WinFsp's ordinary-user mounts are not registered with the Mount Manager.
    GetFinalPathNameByHandle(VOLUME_NAME_DOS), used even by non-strict Python
    realpath, raises ERROR_UNRECOGNIZED_VOLUME (1005) for these valid volumes.
    The mount can be an ancestor reparse point; the workspace leaf cannot.
    """
    path = Path(os.path.abspath(Path(root).expanduser()))
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
        raise AccessRefused("Windows execution requires a directory workspace without a leaf reparse point.")
    return path


def _directory_identity(path: Path) -> str:
    """Resolve an existing directory through its handle in the NT namespace."""
    if not path.is_dir():
        raise AccessRefused("Windows execution cwd must be an existing directory.")
    kernel, _, _, _ = _libraries()
    kernel.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_ulong,
                                  ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_void_p]
    kernel.CreateFileW.restype = ctypes.c_void_p
    kernel.GetFinalPathNameByHandleW.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                               ctypes.c_ulong, ctypes.c_ulong]
    kernel.GetFinalPathNameByHandleW.restype = ctypes.c_ulong
    handle = kernel.CreateFileW(str(path), 0, 7, None, 3, 0x02000000, None)
    if handle == ctypes.c_void_p(-1).value:
        raise _error("open execution directory")
    try:
        buffer = ctypes.create_unicode_buffer(32_768)
        # VOLUME_NAME_NT resolves junctions/symlinks without a global drive or
        # Mount Manager registration. Never fall back to lexical containment.
        length = kernel.GetFinalPathNameByHandleW(handle, buffer, len(buffer), 2)
        if not 0 < length < len(buffer):
            raise _error("resolve execution directory")
        return buffer.value.rstrip("\\").casefold()
    finally:
        kernel.CloseHandle(handle)


def launch(argv: list[str], *, workspace: Path, cwd: Path, env: dict[str, str]) -> None:
    """Install LPAC before the fixed child stage reads the command environment."""
    workspace = workspace_directory(workspace)
    cwd = Path(os.path.abspath(cwd))
    if cwd != workspace and workspace not in cwd.parents:
        raise AccessRefused("Windows workspace cwd escapes its authorized directory.")
    root_identity = _directory_identity(workspace)
    cwd_identity = root_identity if cwd == workspace else _directory_identity(cwd)
    if cwd_identity != root_identity and not cwd_identity.startswith(root_identity + "\\"):
        raise AccessRefused("Windows workspace cwd escapes its authorized directory.")
    volume_package = _private_volume(workspace)
    # Private views create their profile from the same lexical identity before
    # mounting; resolving a mounted path here must not invent another principal.
    package_sid = volume_package or create_profile(workspace)[0]
    for runtime in runtime_read_roots():
        _grant(runtime, package_sid, "RX")
    if volume_package is None:
        _grant(workspace, package_sid, "M")
        system = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/icacls.exe"
        # Do not walk workspace reparse points with icacls /T. A junction target
        # keeps its own label and DACL, outside this authorized tree.
        label = subprocess.run([str(system), str(workspace), "/setintegritylevel", "(OI)(CI)Low", "/L", "/Q"],
                               capture_output=True, timeout=30, check=False)
        if label.returncode:
            raise AccessRefused("Windows could not label the exact workspace for isolated writes.")
    _launch_lpac(argv, package_sid=package_sid, cwd=cwd, env=env)


def _update_user_object_access(handle: ctypes.c_void_p, package_sid: str, *,
                               rights: int, mode: int) -> None:
    kernel, _, advapi, _ = _libraries()
    advapi.GetSecurityInfo.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ulong,
                                       ctypes.c_void_p, ctypes.c_void_p,
                                       ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p,
                                       ctypes.POINTER(ctypes.c_void_p)]
    advapi.SetEntriesInAclW.argtypes = [ctypes.c_ulong, ctypes.POINTER(_ExplicitAccess),
                                        ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    advapi.SetSecurityInfo.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ulong,
                                       ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                                       ctypes.c_void_p]
    package = ctypes.c_void_p()
    if not advapi.ConvertStringSidToSidW(package_sid, ctypes.byref(package)):
        raise _error("read desktop principal")
    try:
        old_acl, descriptor = ctypes.c_void_p(), ctypes.c_void_p()
        result = advapi.GetSecurityInfo(handle, 7, 4, None, None, ctypes.byref(old_acl), None,
                                        ctypes.byref(descriptor))
        if result:
            raise AccessRefused(f"Windows workspace isolation: read desktop policy failed ({result}).")
        entry = _ExplicitAccess(rights, mode, 0, _Trustee(None, 0, 0, 0, package))
        new_acl = ctypes.c_void_p()
        result = advapi.SetEntriesInAclW(1, ctypes.byref(entry), old_acl, ctypes.byref(new_acl))
        if result:
            kernel.LocalFree(descriptor)
            raise AccessRefused(f"Windows workspace isolation: extend desktop policy failed ({result}).")
        try:
            result = advapi.SetSecurityInfo(handle, 7, 4, None, None, new_acl, None)
            if result:
                raise AccessRefused(f"Windows workspace isolation: apply desktop policy failed ({result}).")
        finally:
            kernel.LocalFree(new_acl)
            kernel.LocalFree(descriptor)
    finally:
        kernel.LocalFree(package)


def _retain_station_access(station: ctypes.c_void_p, package_sid: str) -> None:
    key = (int(getattr(station, "value", station) or 0), package_sid)
    with _acl_thread_lock:
        count = _desktop_grants.get(key, 0)
        if count == 0:
            _update_user_object_access(station, package_sid,
                                       rights=_WINSTA_COMPATIBILITY_RIGHTS, mode=1)
        _desktop_grants[key] = count + 1


def _release_station_access(station: ctypes.c_void_p, package_sid: str) -> None:
    key = (int(getattr(station, "value", station) or 0), package_sid)
    with _acl_thread_lock:
        count = _desktop_grants.get(key, 0)
        if count <= 0:
            raise AccessRefused("Windows workspace isolation lost its private desktop grant.")
        if count == 1:
            _update_user_object_access(station, package_sid, rights=0, mode=4)
            del _desktop_grants[key]
        else:
            _desktop_grants[key] = count - 1


def _private_desktop(package_sid: str) -> tuple[str, ctypes.c_void_p, ctypes.c_void_p,
                                                  ctypes.c_void_p]:
    from .winsec import current_user_sid
    kernel, _, advapi, _ = _libraries()
    user = ctypes.WinDLL("user32", use_last_error=True)
    user.GetProcessWindowStation.restype = ctypes.c_void_p
    kernel.GetCurrentThreadId.restype = ctypes.c_ulong
    user.GetThreadDesktop.argtypes = [ctypes.c_ulong]
    user.GetThreadDesktop.restype = ctypes.c_void_p
    user.SetThreadDesktop.argtypes = [ctypes.c_void_p]
    user.GetUserObjectInformationW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p,
                                               ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
    user.CreateDesktopW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_void_p,
                                    ctypes.c_ulong, ctypes.c_ulong,
                                    ctypes.POINTER(_SecurityAttributes)]
    user.CreateDesktopW.restype = ctypes.c_void_p
    user.CloseDesktop.argtypes = [ctypes.c_void_p]

    def name(handle: ctypes.c_void_p) -> str:
        size = ctypes.c_ulong()
        user.GetUserObjectInformationW(handle, 2, None, 0, ctypes.byref(size))
        value = ctypes.create_unicode_buffer(size.value // ctypes.sizeof(ctypes.c_wchar) + 1)
        if not user.GetUserObjectInformationW(handle, 2, value, ctypes.sizeof(value),
                                               ctypes.byref(size)):
            raise _error("read desktop identity")
        return value.value

    station = user.GetProcessWindowStation()
    station_name = name(station)
    # USER32 requires global atoms and descriptor visibility on the station.
    # The package receives no ACE on the user's visible desktop object.
    _retain_station_access(station, package_sid)
    descriptor = ctypes.c_void_p()
    desktop = ctypes.c_void_p()
    desktop_name = f"Meshia-{os.getpid()}-{threading.get_ident()}"
    sddl = f"D:P(A;;GA;;;{current_user_sid()})(A;;GA;;;SY)(A;;GA;;;{package_sid})"
    advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [
        ctypes.c_wchar_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p]
    try:
        if not advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW(
                sddl, 1, ctypes.byref(descriptor), None):
            raise _error("create private desktop policy")
        attributes = _SecurityAttributes(ctypes.sizeof(_SecurityAttributes), descriptor, False)
        desktop = user.CreateDesktopW(desktop_name, None, None, 0, 0x000001FF,
                                      ctypes.byref(attributes))
        if not desktop:
            raise _error("create private command desktop")
        previous_desktop = user.GetThreadDesktop(kernel.GetCurrentThreadId())
        if not user.SetThreadDesktop(desktop):
            raise _error("enter private command desktop")
        return station_name + "\\" + desktop_name, station, desktop, previous_desktop
    except BaseException:
        try:
            if desktop:
                user.CloseDesktop(desktop)
        finally:
            _release_station_access(station, package_sid)
        raise
    finally:
        if descriptor:
            kernel.LocalFree(descriptor)


def _release_private_desktop(package_sid: str, station: ctypes.c_void_p,
                             desktop: ctypes.c_void_p) -> None:
    user = ctypes.WinDLL("user32", use_last_error=True)
    user.CloseDesktop.argtypes = [ctypes.c_void_p]
    try:
        if desktop and not user.CloseDesktop(desktop):
            raise _error("close private command desktop")
    finally:
        _release_station_access(station, package_sid)


def _restore_thread_desktop(desktop: ctypes.c_void_p) -> None:
    user = ctypes.WinDLL("user32", use_last_error=True)
    user.SetThreadDesktop.argtypes = [ctypes.c_void_p]
    if desktop and not user.SetThreadDesktop(desktop):
        raise _error("restore command desktop")


def _launch_lpac(argv: list[str], *, package_sid: str, cwd: Path, env: dict[str, str]) -> None:
    kernel, userenv, advapi, base = _libraries()
    package = ctypes.c_void_p()
    allocations: list[ctypes.c_void_p] = []
    attribute_list = None
    process = _ProcessInformation()
    station = ctypes.c_void_p()
    desktop = ctypes.c_void_p()
    previous_desktop = ctypes.c_void_p()
    if not advapi.ConvertStringSidToSidW(package_sid, ctypes.byref(package)):
        raise _error("derive workspace principal")
    try:
        capabilities = []
        for name in _CAPABILITIES:
            groups = ctypes.POINTER(ctypes.c_void_p)()
            values = ctypes.POINTER(ctypes.c_void_p)()
            group_count, count = ctypes.c_ulong(), ctypes.c_ulong()
            if not base.DeriveCapabilitySidsFromName(name, ctypes.byref(groups), ctypes.byref(group_count),
                                                    ctypes.byref(values), ctypes.byref(count)):
                raise _error("derive capability")
            for array, size in ((groups, group_count.value), (values, count.value)):
                allocations.extend(array[index] for index in range(size))
                allocations.append(ctypes.cast(array, ctypes.c_void_p))
            capabilities.extend(_SidAndAttributes(values[index], 4) for index in range(count.value))
        entries = (_SidAndAttributes * len(capabilities))(*capabilities)
        security = _SecurityCapabilities(package, entries, len(entries), 0)
        size = ctypes.c_size_t()
        kernel.InitializeProcThreadAttributeList(None, 3, 0, ctypes.byref(size))
        attribute_list = ctypes.create_string_buffer(size.value)
        if not kernel.InitializeProcThreadAttributeList(attribute_list, 3, 0, ctypes.byref(size)):
            raise _error("initialize process policy")
        opt_out = ctypes.c_ulong(1)
        handles = (ctypes.c_void_p * 3)(*(kernel.GetStdHandle(code & 0xFFFFFFFF) for code in (-10, -11, -12)))
        for handle in handles:
            if not handle or not kernel.SetHandleInformation(handle, 1, 1):
                raise _error("prepare command stdio")
        # stdout and stderr normally share the bounded output pipe. Keep both
        # startup fields but include each inherited handle only once.
        unique_handles = tuple(dict.fromkeys(handles))
        inherited_handles = (ctypes.c_void_p * len(unique_handles))(*unique_handles)
        for attribute, value in ((_SECURITY_CAPABILITIES, security),
                                 (_ALL_APPLICATION_PACKAGES_POLICY, opt_out), (_HANDLE_LIST, inherited_handles)):
            if not kernel.UpdateProcThreadAttribute(attribute_list, 0, attribute, ctypes.byref(value),
                                                     ctypes.sizeof(value), None, None):
                raise _error("set process policy")
        startup = _StartupInfoEx()
        startup.StartupInfo.cb = ctypes.sizeof(startup)
        startup.StartupInfo.dwFlags = 0x100
        startup.StartupInfo.hStdInput, startup.StartupInfo.hStdOutput, startup.StartupInfo.hStdError = handles
        desktop_name, station, desktop, previous_desktop = _private_desktop(package_sid)
        desktop_buffer = ctypes.create_unicode_buffer(desktop_name)
        startup.StartupInfo.lpDesktop = ctypes.cast(desktop_buffer, ctypes.c_void_p)
        startup.lpAttributeList = ctypes.cast(attribute_list, ctypes.c_void_p)
        command = ctypes.create_unicode_buffer(subprocess.list2cmdline(argv))
        environment = ctypes.create_unicode_buffer(environment_block(env))
        # The outer helper already belongs to a kill-on-close Job. Never request
        # BREAKAWAY; the child inherits that exact Job and cannot escape it.
        created = kernel.CreateProcessW(argv[0], command, None, None, True,
                                        0x00080000 | 0x00000400 | 0x08000000,
                                        environment, str(cwd), ctypes.byref(startup), ctypes.byref(process))
        _restore_thread_desktop(previous_desktop)
        previous_desktop = ctypes.c_void_p()
        if not created:
            raise _error("create isolated command")
        if kernel.WaitForSingleObject(process.hProcess, 0xFFFFFFFF) != 0:
            raise _error("wait for isolated command")
        code = ctypes.c_ulong()
        if not kernel.GetExitCodeProcess(process.hProcess, ctypes.byref(code)):
            raise _error("read command status")
        raise SystemExit(code.value)
    finally:
        for handle in (process.hThread, process.hProcess):
            if handle:
                kernel.CloseHandle(handle)
        try:
            if previous_desktop:
                _restore_thread_desktop(previous_desktop)
        finally:
            if station:
                _release_private_desktop(package_sid, station, desktop)
        if attribute_list is not None:
            kernel.DeleteProcThreadAttributeList(attribute_list)
        for allocation in allocations:
            kernel.LocalFree(allocation)
        kernel.LocalFree(package)
