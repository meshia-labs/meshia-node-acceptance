"""Durable metadata and write-back journal for the working-set Fabric client.

The workspace bytes deliberately do *not* live in SQLite.  This database is a
small control plane for a remote-authoritative filesystem: it remembers the
remote namespace, which files are materialized locally, and which local
mutations still need an idempotent server receipt.

Every row is fenced by an authority epoch containing the host, server-proven
session, host generation, and canonical workspace root.  Rebinding to a new
authority quarantines the old epoch instead of deleting it.  That makes a
restart or re-enrollment fail closed while retaining enough evidence to recover
staged bytes manually.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Literal, Mapping, Sequence

from .errors import StateError
from .fabric_contract_generated import file_digest_algorithm
from .util import RAW_SHA256_RE, ensure_private_dir
from .workspace import split_relative

OperationKind = Literal["put", "delete", "rename"]
ConflictDecision = Literal["keep_local", "keep_remote", "keep_both"]
ConflictResolutionPhase = Literal[
    "requested",
    "prepared",
    "waiting_successor",
    "applying_remote",
    "blocked",
    "completed",
]
OperationState = Literal[
    "queued", "inflight", "retry", "acked", "conflict", "quarantined"
]
MaterializationState = Literal["absent", "clean", "dirty", "staging", "conflict"]

_OPERATION_KINDS = frozenset(("put", "delete", "rename"))
_OPERATION_STATES = frozenset(
    ("queued", "inflight", "retry", "acked", "conflict", "quarantined")
)
_MATERIALIZATION_STATES = frozenset(("absent", "clean", "dirty", "staging", "conflict"))
_NONTERMINAL_OPERATION_STATES = ("queued", "inflight", "retry")
_MAX_BLOCKS_JSON_BYTES = 2 * 1024 * 1024
_MAX_ERROR_BYTES = 16 * 1024
_MAX_RECEIPT_JSON_BYTES = 256 * 1024
_SCHEMA_VERSION = 25
_MAX_REMOTE_MANIFEST_ENTRIES = 250_000
_MAX_REMOTE_MANIFEST_PAGE = 1_000
_MAX_RESTORE_PAGE = 1_000
_MAX_PATH_STATE_PAGE = 1_000
_MAX_AUTHORITY_COMPACTION_PAGE = 16
_MAX_CONFLICT_PAGE = 200
_MAX_CONFLICT_WORK_PAGE = 256
_MAX_LOCAL_DIRECTORY_TOMBSTONES = 10_000
_SQLITE_PATH_BATCH = 400
_MAX_DIRECTORY_RENAME_PREDECESSORS = 10_000
_MAX_BASE_DIVERGED_REBASE_BATCH = 256
_MAX_BASE_DIVERGED_REBASE_SCAN = 4_096
_BASE_DIVERGED_REBASE_SCAN_PAGE = 256
_MAX_QUOTA_PROJECTION_OPERATIONS = 10_000
_DEFAULT_OPERATION_LEASE_SECONDS = 60.0

_CONFLICT_DECISIONS = frozenset(("keep_local", "keep_remote", "keep_both"))
_LOCAL_TRANSFER_ISSUES = frozenset(("local_file_present_but_unsupported",))
_CONFLICT_RESOLUTION_PHASES = frozenset(
    (
        "requested",
        "prepared",
        "waiting_successor",
        "applying_remote",
        "blocked",
        "completed",
    )
)
_CONFLICT_RESOLUTION_TRANSITIONS = {
    "requested": frozenset(("prepared", "blocked")),
    "prepared": frozenset(("waiting_successor", "applying_remote", "blocked")),
    "waiting_successor": frozenset(("applying_remote", "completed", "blocked")),
    "applying_remote": frozenset(("completed", "blocked")),
    "blocked": frozenset(("requested",)),
    "completed": frozenset(),
}

_INACTIVE_AUTHORITY_PAGE_SQL = """SELECT scope_id FROM authority_scopes
   INDEXED BY authority_inactive_compaction
   WHERE active = 0 AND scope_id > ?
   ORDER BY scope_id LIMIT ?"""

_INACTIVE_AUTHORITY_BLOCKER_SQL = """
SELECT 1 FROM pending_operations INDEXED BY pending_send_queue
WHERE scope_id = ?
  AND (state != 'acked' OR staged_path IS NOT NULL OR commit_unknown = 1)
UNION ALL
SELECT 1 FROM pending_operations AS operation INDEXED BY pending_send_queue
CROSS JOIN operation_stages AS stage INDEXED BY operation_stage_history
WHERE operation.scope_id = ? AND stage.mutation_id = operation.mutation_id
UNION ALL
SELECT 1 FROM conflicts INDEXED BY unresolved_conflicts
WHERE scope_id = ?
  AND (resolved_at_ns IS NULL OR staged_path IS NOT NULL)
UNION ALL
SELECT 1 FROM conflict_resolutions INDEXED BY conflict_resolution_work
WHERE scope_id = ? AND phase != 'completed'
UNION ALL
SELECT 1 FROM materialized_entries INDEXED BY materialized_lru
WHERE scope_id = ?
  AND (state IN ('dirty', 'staging', 'conflict') OR bytes_on_disk > 0)
UNION ALL
SELECT 1 FROM eviction_intents WHERE scope_id = ?
UNION ALL
SELECT 1 FROM local_transfer_intents WHERE scope_id = ?
UNION ALL
SELECT 1 FROM remote_manifest_loads WHERE scope_id = ?
UNION ALL
SELECT 1 FROM remote_apply_intents WHERE scope_id = ?
UNION ALL
SELECT 1 FROM remote_rename_intents WHERE scope_id = ?
LIMIT 1
"""


@dataclass(frozen=True)
class AuthorityBinding:
    scope_id: int
    host_id: str
    session_id: str
    host_generation: int
    attachment_id: str | None
    workspace_root: str
    workspace_id: str | None
    adoption_required: bool
    adoption_reason: str | None
    changed: bool
    quarantined_scope_id: int | None = None


@dataclass(frozen=True)
class AuthorityCompactionPage:
    """One bounded keyset step over inactive authority epochs.

    ``next_after_scope_id`` is present only when the page filled its requested
    limit. A caller can feed it into the next call; an exact final full page may
    therefore require one harmless empty call to prove that the sweep ended.
    """

    compacted_scope_ids: tuple[int, ...]
    examined_scope_count: int
    next_after_scope_id: int | None


@dataclass(frozen=True)
class RemoteEntry:
    path: str
    size_bytes: int
    digest: str | None
    modified: str | None = None
    blocks: Any | None = None
    kind: Literal["file", "directory"] = "file"


@dataclass(frozen=True)
class DirectoryPut:
    path: str
    mutation_id: str
    kind: Literal["put", "rename", "delete"] = "put"
    destination_path: str | None = None
    created_at_ns: int = 0


@dataclass(frozen=True)
class ReceiptedEntry:
    """One acknowledged path effect not yet observed through journal replay."""

    path: str
    generation: int
    mutation_id: str
    entry: RemoteEntry | None

    @property
    def deleted(self) -> bool:
        return self.entry is None


@dataclass
class _QuotaProjectionCache:
    """In-memory exact projection plus its durable event cursor."""

    scope_id: int
    limit: int
    last_event_id: int
    item_count: int
    delta_bytes: int
    original: dict[str, int]
    projected: dict[str, int]
    directory_rename: bool
    operation_ids: set[str]
    intent_ids: set[str]


@dataclass(frozen=True)
class RemoteChild:
    """One direct remote namespace child, including synthesized directories."""

    name: str
    path: str
    is_directory: bool
    size_bytes: int
    digest: str | None
    modified: str | None = None


@dataclass(frozen=True)
class RemoteManifest:
    generation: int
    # None for a Fabric v2 head; see RemoteManifestHead.digest.
    digest: str | None
    entries: tuple[RemoteEntry, ...]
    refreshed_at_ns: int


@dataclass(frozen=True)
class RemoteManifestHead:
    generation: int
    # Fabric v2 identifies a head by its journal sequence alone. v1 carried a
    # whole-namespace manifest digest here; v2 has no per-commit content hash
    # by design (integrity moved to checkpoints), and synthesising one from the
    # sequence would let a reader believe integrity was verified when it was
    # not. None means "a v2 head": ordering is the identity.
    digest: str | None
    refreshed_at_ns: int


@dataclass(frozen=True)
class LegacyAuthoritySnapshot:
    """Exact legacy authority plus the published head that fences its claim."""

    scope_id: int
    host_id: str
    session_id: str
    host_generation: int
    attachment_id: str | None
    workspace_root: str
    workspace_id: None
    head_generation: int
    head_digest: str
    head_refreshed_at_ns: int


@dataclass(frozen=True)
class RemoteManifestLoad:
    """Durable, capability-owned full-manifest ingestion cursor.

    ``load_id`` is an unguessable UUID owned by one refresh attempt.  Pages are
    committed independently, while the live namespace and head remain
    untouched until :meth:`commit_remote_manifest_load` succeeds.
    """

    load_id: str
    manifest_id: str
    # A v2 snapshot load identifies itself by its journal sequence in
    # `generation`; there is no manifest and so no content digest. See
    # RemoteManifestHead.digest for why one is not synthesised.
    generation: int
    digest: str | None
    expected_entries: int
    ingested_entries: int
    last_path: str | None
    created_at_ns: int
    updated_at_ns: int


@dataclass(frozen=True)
class RemoteManifestCommit:
    """Compact result of one atomic full-manifest publication."""

    generation: int
    digest: str | None
    entry_count: int
    changed_paths: int
    apply_intents: int
    rename_intents: int
    seeded_entries: int
    seeded_bytes: int
    refreshed_at_ns: int
    changed: bool


@dataclass(frozen=True)
class MaterializedEntry:
    path: str
    state: str
    pinned: bool
    clean_digest: str | None
    stat_fingerprint: str | None
    bytes_on_disk: int
    accessed_at_ns: int
    updated_at_ns: int
    #: First-hand proof these exact bytes are retrievable from object storage.
    #: Required for eviction; see the column comment in the schema.
    remote_verified: bool = False
    # Flat checksum of the clean local bytes; clean_digest remains the remote
    # file identity, which may instead be a block-descriptor root.
    content_sha256: str | None = None
    clean_digest_algorithm: str = "sha256"


@dataclass(frozen=True)
class EvictionIntent:
    """Durable proof that a missing clean file was deliberately evicted.

    The materialization remains ``clean`` (and continues to count against the
    local byte budget) until the namespace removal is proven complete.  A
    restart can therefore distinguish an interrupted eviction from a user's
    local delete and must never publish the former as a remote tombstone.
    """

    scope_id: int
    eviction_id: str
    path: str
    expected_clean_digest: str
    expected_stat_fingerprint: str
    expected_bytes: int
    created_at_ns: int
    expected_content_sha256: str | None = None


@dataclass(frozen=True)
class FabricPathState:
    """One bounded startup/reconciliation lookup, including explicit misses."""

    path: str
    remote: RemoteEntry | None
    materialized: MaterializedEntry | None
    eviction: EvictionIntent | None


@dataclass(frozen=True)
class RemoteApplyIntent:
    path: str
    created_at_ns: int


@dataclass(frozen=True)
class RemoteRenameIntent:
    source_path: str
    destination_path: str
    digest: str
    size_bytes: int
    created_at_ns: int


@dataclass(frozen=True)
class PendingOperation:
    mutation_id: str
    journal_seq: int
    predecessor_mutation_id: str | None
    kind: str
    path: str
    destination_path: str | None
    base_generation: int | None
    base_digest: str | None
    expected_source_digest: str | None
    expected_destination_digest: str | None
    staged_path: str | None
    staged_digest: str | None
    staged_size: int | None
    state: str
    commit_unknown: bool
    request_digest: str | None
    attempt_count: int
    failure_count: int
    last_error: str | None
    created_at_ns: int
    updated_at_ns: int
    claimed_at_ns: int | None
    next_attempt_at_ns: int | None
    directory_rename: bool = False
    directory_rename_observed: bool = False
    # When the operation became sendable (queued at creation, or the retry
    # deadline); the batch scheduler uses it to bound how long a ready commit
    # may wait for companions.
    ready_at_ns: int | None = None
    # Set while this operation's commit is unknown as part of one mutate_batch
    # request. Batch members share the fence; a lone unknown commit keeps the
    # single-fence uniqueness (commit_batch_id IS NULL).
    commit_batch_id: str | None = None
    # Exact source metadata for an atomic v2 file replacement. Retained with
    # the journal so replay does not depend on a source already consumed.
    rename_source: RemoteEntry | None = None


@dataclass(frozen=True)
class QuarantinedCommitUnknown:
    """An original-authority mutation awaiting status-only resolution."""

    resolver_scope_id: int | None
    original_scope_id: int
    original_host_id: str
    original_session_id: str
    original_host_generation: int
    original_attachment_id: str | None
    original_workspace_root: str
    original_workspace_id: str | None
    operation: PendingOperation


@dataclass(frozen=True)
class OperationStage:
    stage_id: int
    mutation_id: str
    staged_path: str
    staged_digest: str
    staged_size: int
    active: bool
    recorded_at_ns: int


@dataclass(frozen=True)
class LocalTransferIntent:
    """Crash-safe metadata for a background local snapshot and publication."""

    scope_id: int
    transfer_id: str
    path: str
    source_fingerprint: str
    expected_remote_digest: str | None
    delete_after_ack_path: str | None
    delete_after_ack_digest: str | None
    delete_mutation_id: str | None
    issue_code: str | None
    issue_size_bytes: int | None
    created_at_ns: int
    updated_at_ns: int


@dataclass(frozen=True)
class LocalTransferBacklog:
    """Constant-time aggregate for durable pre-publication local bytes."""

    path_count: int
    size_bytes: int


@dataclass(frozen=True)
class OperationReceipt:
    mutation_id: str
    remote_generation: int | None
    remote_manifest_digest: str | None
    remote_entry_digest: str | None
    receipt: Any | None
    recorded_at_ns: int


@dataclass(frozen=True)
class ConflictRecord:
    conflict_id: int
    scope_id: int
    mutation_id: str | None
    evidence_key: str | None
    path: str
    reason: str
    base_digest: str | None
    local_digest: str | None
    local_fingerprint: str | None
    remote_digest: str | None
    remote_generation: int | None
    staged_path: str | None
    recorded_at_ns: int
    resolved_at_ns: int | None


@dataclass(frozen=True)
class EmptyRemoteApplyRepair:
    """One legacy empty-conflict repair committed against an exact head."""

    path: str
    remote_digest: str | None


@dataclass(frozen=True)
class ConflictResolution:
    """One coordinator-owned, restart-safe decision for a conflict group."""

    resolution_id: str
    scope_id: int
    anchor_conflict_id: int
    mutation_id: str | None
    decision: str
    phase: str
    expected_local_digest: str | None
    expected_local_fingerprint: str | None
    expected_remote_digest: str | None
    expected_remote_generation: int | None
    successor_mutation_id: str | None
    survivor_path: str | None
    staged_path: str | None
    staged_digest: str | None
    staged_size: int | None
    last_error: str | None
    retry_safe: bool
    retry_requested_at_ns: int | None
    created_at_ns: int
    updated_at_ns: int
    completed_at_ns: int | None


@dataclass(frozen=True)
class ConflictView:
    """Bounded operator projection with its journal and recovery state."""

    conflict: ConflictRecord
    operation: PendingOperation | None
    resolution: ConflictResolution | None


@dataclass(frozen=True)
class FabricStatus:
    scope_id: int
    manifest_generation: int | None
    manifest_digest: str | None
    remote_entries: int
    remote_bytes: int
    materialized_entries: int
    materialized_bytes: int
    dirty_entries: int
    pinned_entries: int
    operations: dict[str, int]
    unresolved_conflicts: int
    quarantined_scopes: int
    quarantined_operations: int
    quarantined_remote_outcomes_unknown: int


@dataclass(frozen=True)
class FabricReadiness:
    """Cheap read-only signals for service health and operator status."""

    authority_bound: bool
    scope_id: int | None
    adoption_required: bool
    adoption_reason: str | None
    pending_operations: bool
    commit_unknown: bool
    unresolved_conflicts: bool
    quarantined_remote_outcomes_unknown: bool


class FabricDatabase:
    """Thread-safe SQLite working-set index and durable mutation journal."""

    _QUARANTINED_GENERATION_RESOLVER_SQL = """
        SELECT operation.*,
               original.host_id AS original_host_id,
               original.session_id AS original_session_id,
               original.host_generation AS original_host_generation,
               original.attachment_id AS original_attachment_id,
               original.workspace_root AS original_workspace_root,
               original.workspace_id AS original_workspace_id,
               resolver.scope_id AS resolver_scope_id
        FROM pending_operations AS operation
        JOIN authority_scopes AS original
          ON original.scope_id = operation.scope_id
        JOIN authority_scopes AS resolver ON resolver.active = 1
        WHERE original.active = 0
          AND original.quarantine_reason = 'host_generation_changed'
          AND original.host_id = resolver.host_id
          AND original.session_id = resolver.session_id
          AND original.workspace_root = resolver.workspace_root
          AND original.workspace_id IS resolver.workspace_id
          AND original.host_generation < resolver.host_generation
    """
    _RESOLVABLE_QUARANTINED_UNKNOWN_SQL = (
        _QUARANTINED_GENERATION_RESOLVER_SQL
        + " AND operation.state = 'quarantined' AND operation.commit_unknown = 1"
    )

    def __init__(self, path: Path | str, *, busy_timeout_ms: int = 5_000) -> None:
        if (
            isinstance(busy_timeout_ms, bool)
            or not isinstance(busy_timeout_ms, int)
            or not 1 <= busy_timeout_ms <= 120_000
        ):
            raise ValueError("busy_timeout_ms must be between 1 and 120000.")
        self.path = Path(path).expanduser()
        ensure_private_dir(self.path.parent)
        if not self.path.exists():
            descriptor = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
            os.close(descriptor)
        else:
            os.chmod(self.path, 0o600)
        self._lock = threading.RLock()
        self._closed = False
        self._connection = sqlite3.connect(
            str(self.path), isolation_level=None, check_same_thread=False
        )
        self._connection.row_factory = sqlite3.Row
        self._connection.create_function(
            "meshia_block_layout_completion_matches",
            3,
            _block_layout_completion_matches_sql,
            deterministic=True,
        )
        self._connection.execute("PRAGMA foreign_keys = ON")
        self._connection.execute(f"PRAGMA busy_timeout = {busy_timeout_ms:d}")
        self._connection.execute("PRAGMA journal_mode = WAL")
        self._connection.execute("PRAGMA synchronous = FULL")
        # Bound the sidecar in a long-running daemon without forcing a
        # checkpoint on every mutation burst.
        self._connection.execute("PRAGMA wal_autocheckpoint = 256")
        self._initialize_schema()
        # This remains only an in-memory cache over the authoritative journal.
        # Durable table triggers provide a bounded cross-connection change
        # cursor; restart always rebuilds the exact projection from source rows.
        self._quota_projection_cache: _QuotaProjectionCache | None = None
        # Request-scoped memo for the active authority scope id. The active
        # scope only changes at bind_authority/quarantine, but every metadata
        # resolution re-reads it many times (7 of the 15 queries per stat). The
        # memo is live ONLY inside an explicit `scope_read_epoch()` -- i.e. for
        # the duration of one read callback -- and is discarded when that epoch
        # ends, so a rebind from any process is always observed on the next
        # operation. It is additionally fenced to this connection's write
        # counter, so any local write (including an authority rotation that
        # runs inside an epoch) invalidates it. See `_active_scope_id`.
        self._scope_epoch_depth = 0
        self._scope_id_memo: int | None = None
        self._scope_memo_changes = -1

    def close(self) -> None:
        with self._lock:
            if not self._closed:
                self._connection.close()
                self._closed = True

    def __enter__(self) -> "FabricDatabase":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # --------------------------------------------------------------- authority

    def bind_authority(
        self,
        *,
        host_id: str,
        session_id: str,
        host_generation: int,
        workspace_root: Path | str,
        attachment_id: str | None = None,
        workspace_id: str | None = None,
    ) -> AuthorityBinding:
        """Bind the active epoch, quarantining old pending work on a fence change.

        An attachment rotation alone does not create a new epoch; the stable
        authority tuple and resolved root still prove that the bytes belong to
        the same workspace.
        """
        host_id = _nonempty("host_id", host_id)
        session_id = _nonempty("session_id", session_id)
        if (
            isinstance(host_generation, bool)
            or not isinstance(host_generation, int)
            or host_generation < 1
        ):
            raise ValueError("host_generation must be a positive integer.")
        if attachment_id is not None:
            attachment_id = _nonempty("attachment_id", attachment_id)
        if workspace_id is not None:
            workspace_id = _canonical_uuid("workspace_id", workspace_id)
        resolved_root = _resolved_root(workspace_root)
        now = time.time_ns()
        quarantined_scope_id: int | None = None
        adoption_required = False
        adoption_reason: str | None = None

        with self._transaction():
            current = self._connection.execute(
                "SELECT * FROM authority_scopes WHERE active = 1"
            ).fetchone()
            if current is not None and (
                current["host_id"] == host_id
                and current["session_id"] == session_id
                and current["host_generation"] == host_generation
                and current["workspace_root"] == resolved_root
                and current["workspace_id"] == workspace_id
            ):
                self._connection.execute(
                    """UPDATE authority_scopes
                       SET attachment_id = ?, updated_at_ns = ?
                       WHERE scope_id = ?""",
                    (attachment_id, now, current["scope_id"]),
                )
                return AuthorityBinding(
                    scope_id=current["scope_id"],
                    host_id=host_id,
                    session_id=session_id,
                    host_generation=host_generation,
                    attachment_id=attachment_id,
                    workspace_root=resolved_root,
                    workspace_id=workspace_id,
                    adoption_required=bool(current["adoption_required"]),
                    adoption_reason=(
                        str(current["adoption_reason"])
                        if current["adoption_reason"] is not None
                        else None
                    ),
                    changed=False,
                )

            if current is not None:
                quarantined_scope_id = int(current["scope_id"])
                changed_dimensions = tuple(
                    name
                    for name, before, after in (
                        ("host_id", current["host_id"], host_id),
                        ("session_id", current["session_id"], session_id),
                        (
                            "host_generation",
                            current["host_generation"],
                            host_generation,
                        ),
                        ("workspace_root", current["workspace_root"], resolved_root),
                        ("workspace_id", current["workspace_id"], workspace_id),
                    )
                    if before != after
                )
                if not changed_dimensions:  # pragma: no cover - exact match returned above
                    raise StateError("An authority rebind had no changed fence dimension.")
                reason = ",".join(f"{name}_changed" for name in changed_dimensions)
                adoption_required = True
                adoption_reason = reason
                self._connection.execute(
                    """UPDATE authority_scopes
                       SET active = 0, quarantined_at_ns = ?, quarantine_reason = ?,
                           updated_at_ns = ?
                       WHERE scope_id = ?""",
                    (now, reason, now, quarantined_scope_id),
                )
                self._connection.execute(
                    """UPDATE pending_operations
                       SET state = 'quarantined', claimed_at_ns = NULL,
                           next_attempt_at_ns = NULL, ready_at_ns = ?,
                           last_error = CASE
                             WHEN commit_unknown = 1
                               THEN 'remote_outcome_unknown:' || ?
                             ELSE ?
                           END,
                           updated_at_ns = ?
                       WHERE scope_id = ? AND state IN ('queued', 'inflight', 'retry')""",
                    (now, reason, reason, now, quarantined_scope_id),
                )
                self._discard_inactive_remote_work_locked(quarantined_scope_id)

            cursor = self._connection.execute(
                """INSERT INTO authority_scopes(
                       host_id, session_id, host_generation, attachment_id,
                       workspace_root, workspace_id, adoption_required,
                       adoption_reason, active,
                       bound_at_ns, updated_at_ns
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)""",
                (
                    host_id,
                    session_id,
                    host_generation,
                    attachment_id,
                    resolved_root,
                    workspace_id,
                    int(adoption_required),
                    adoption_reason,
                    now,
                    now,
                ),
            )
            scope_id = int(cursor.lastrowid)
        return AuthorityBinding(
            scope_id=scope_id,
            host_id=host_id,
            session_id=session_id,
            host_generation=host_generation,
            attachment_id=attachment_id,
            workspace_root=resolved_root,
            workspace_id=workspace_id,
            adoption_required=adoption_required,
            adoption_reason=adoption_reason,
            changed=True,
            quarantined_scope_id=quarantined_scope_id,
        )

    def current_authority(self) -> AuthorityBinding | None:
        with self._lock:
            self._require_open()
            row = self._connection.execute(
                "SELECT * FROM authority_scopes WHERE active = 1"
            ).fetchone()
        if row is None:
            return None
        return _authority_from_row(row, changed=False)

    def complete_authority_adoption(
        self, *, expected_scope_id: int
    ) -> AuthorityBinding:
        """Release a local-publication fence after explicit tree reconciliation.

        A changed session, host generation, workspace identity, or canonical
        root starts with local publication disabled. Remote manifest hydration
        remains available, but a caller must reconcile/quarantine the visible
        tree against a durable remote head before naming the exact new scope in
        this compare-and-swap. The original reason remains inspectable after
        completion for diagnostics.
        """

        if (
            isinstance(expected_scope_id, bool)
            or not isinstance(expected_scope_id, int)
            or expected_scope_id < 1
        ):
            raise ValueError("expected_scope_id must be a positive integer.")
        now = time.time_ns()
        with self._transaction():
            row = self._connection.execute(
                """SELECT * FROM authority_scopes
                   WHERE scope_id = ? AND active = 1""",
                (expected_scope_id,),
            ).fetchone()
            if row is None:
                raise StateError("The authority adoption target is not the active epoch.")
            if not bool(row["adoption_required"]):
                return _authority_from_row(row, changed=False)
            head = self._connection.execute(
                "SELECT 1 FROM remote_manifest_heads WHERE scope_id = ?",
                (expected_scope_id,),
            ).fetchone()
            if head is None:
                raise StateError(
                    "Authority adoption requires a durable remote manifest head."
                )
            pending = self._connection.execute(
                """SELECT 1 FROM local_transfer_intents WHERE scope_id = ?
                   UNION ALL
                   SELECT 1 FROM pending_operations WHERE scope_id = ?
                     AND state IN ('queued', 'inflight', 'retry')
                   LIMIT 1""",
                (expected_scope_id, expected_scope_id),
            ).fetchone()
            if pending is not None:
                # Builds predating the enqueue-side adoption guard could accept
                # a mounted PUT after a generation-only rebind and before this
                # adoption CAS.  Those rows belong to the *new* active scope,
                # but the generic pending-work check above would then keep the
                # scope fenced forever.  A never-sent PUT is safe to retain
                # across this CAS: the stable host/session/workspace/root tuple
                # proves its namespace, its immutable stage owns the bytes, and
                # the normal mutation path will still validate the stage and
                # authoritative base head before publishing it.
                #
                # Keep every broader authority change and every ambiguous or
                # non-PUT operation fail-closed.  A request digest means a
                # manifest mutation may have crossed the wire; local transfer
                # intents have not yet produced the immutable stage evidence
                # required by this narrow recovery.
                recoverable_generation_puts = bool(
                    row["adoption_reason"] == "host_generation_changed"
                    and self._connection.execute(
                        "SELECT 1 FROM local_transfer_intents WHERE scope_id = ? LIMIT 1",
                        (expected_scope_id,),
                    ).fetchone()
                    is None
                    and self._connection.execute(
                        """SELECT 1 FROM pending_operations AS operation
                           WHERE operation.scope_id = ?
                             AND operation.state IN ('queued', 'inflight', 'retry')
                             AND (
                               operation.kind != 'put'
                               OR operation.destination_path IS NOT NULL
                               OR operation.staged_path IS NULL
                               OR operation.staged_digest IS NULL
                               OR operation.staged_size IS NULL
                               OR operation.commit_unknown != 0
                               OR operation.request_digest IS NOT NULL
                               OR EXISTS (
                                 SELECT 1 FROM operation_receipts AS receipt
                                 WHERE receipt.mutation_id = operation.mutation_id
                               )
                               OR NOT EXISTS (
                                 SELECT 1 FROM operation_stages AS stage
                                 WHERE stage.mutation_id = operation.mutation_id
                                   AND stage.active = 1
                                   AND stage.staged_path = operation.staged_path
                                   AND stage.staged_digest = operation.staged_digest
                                   AND stage.staged_size = operation.staged_size
                               )
                             )
                           LIMIT 1""",
                        (expected_scope_id,),
                    ).fetchone()
                    is None
                )
                if not recoverable_generation_puts:
                    raise StateError(
                        "Authority adoption cannot bypass pending local publication work."
                    )
                # No request digest and no receipt prove that an inflight row
                # never reached the manifest mutation boundary.  Release only
                # its crashed local claim; provider block receipts, if any,
                # remain durably attached to the same mutation and stage.
                self._connection.execute(
                    """UPDATE pending_operations
                       SET state = 'retry', claimed_at_ns = NULL,
                           next_attempt_at_ns = ?, ready_at_ns = ?, updated_at_ns = ?
                       WHERE scope_id = ? AND state = 'inflight'
                         AND kind = 'put' AND commit_unknown = 0
                         AND request_digest IS NULL""",
                    (now, now, now, expected_scope_id),
                )
            self._connection.execute(
                """UPDATE authority_scopes
                   SET adoption_required = 0, updated_at_ns = ?
                   WHERE scope_id = ? AND active = 1 AND adoption_required = 1""",
                (now, expected_scope_id),
            )
            # Reconciliation has classified every byte still visible under
            # this exact root into the new active scope. Old clean/absent rows
            # are only accounting hints, not user evidence; retaining them
            # would keep otherwise-terminal authority epochs alive forever.
            self._connection.execute(
                """DELETE FROM materialized_entries
                   WHERE scope_id IN (
                     SELECT scope_id FROM authority_scopes
                     WHERE active = 0 AND workspace_root = ?
                   ) AND state IN ('clean', 'absent')""",
                (str(row["workspace_root"]),),
            )
            row = self._connection.execute(
                "SELECT * FROM authority_scopes WHERE scope_id = ?",
                (expected_scope_id,),
            ).fetchone()
        assert row is not None
        return _authority_from_row(row, changed=False)

    def _discard_inactive_remote_work_locked(self, scope_id: int) -> None:
        """Drop remote-derived work after an authority fence.

        These rows contain no local/user mutation evidence and can never be
        completed through active-scope APIs. Quarantined operations, stages,
        conflicts, local transfers, and dirty materializations are deliberately
        untouched so export/recovery remains lossless.
        """

        self._connection.execute(
            "DELETE FROM remote_manifest_staging WHERE scope_id = ?", (scope_id,)
        )
        self._connection.execute(
            "DELETE FROM remote_manifest_rename_staging WHERE scope_id = ?",
            (scope_id,),
        )
        self._connection.execute(
            "DELETE FROM remote_manifest_loads WHERE scope_id = ?", (scope_id,)
        )
        self._connection.execute(
            "DELETE FROM remote_apply_intents WHERE scope_id = ?", (scope_id,)
        )
        self._connection.execute(
            "DELETE FROM remote_rename_intents WHERE scope_id = ?", (scope_id,)
        )

    def get_exact_legacy_authority(
        self,
        *,
        host_id: str,
        session_id: str,
        host_generation: int,
        workspace_root: Path | str,
    ) -> LegacyAuthoritySnapshot | None:
        """Read an exact active pre-marker scope and its published head.

        This method never broadens authority: a missing head, a changed
        authority tuple/root, or an already-claimed workspace returns ``None``.
        The returned scope/head identity is a capability for the later atomic
        :meth:`claim_legacy_workspace` compare-and-swap.
        """

        host_id = _nonempty("host_id", host_id)
        session_id = _nonempty("session_id", session_id)
        if (
            isinstance(host_generation, bool)
            or not isinstance(host_generation, int)
            or host_generation < 1
        ):
            raise ValueError("host_generation must be a positive integer.")
        resolved_root = _resolved_root(workspace_root)
        with self._lock:
            self._require_open()
            row = self._connection.execute(
                """SELECT authority.*, head.generation AS head_generation,
                          head.digest AS head_digest,
                          head.refreshed_at_ns AS head_refreshed_at_ns
                   FROM authority_scopes AS authority
                   JOIN remote_manifest_heads AS head
                     ON head.scope_id = authority.scope_id
                   WHERE authority.active = 1
                     AND authority.workspace_id IS NULL
                     AND authority.host_id = ? AND authority.session_id = ?
                     AND authority.host_generation = ?
                     AND authority.workspace_root = ?""",
                (host_id, session_id, host_generation, resolved_root),
            ).fetchone()
        if row is None:
            return None
        return LegacyAuthoritySnapshot(
            scope_id=int(row["scope_id"]),
            host_id=str(row["host_id"]),
            session_id=str(row["session_id"]),
            host_generation=int(row["host_generation"]),
            attachment_id=(
                str(row["attachment_id"])
                if row["attachment_id"] is not None
                else None
            ),
            workspace_root=str(row["workspace_root"]),
            workspace_id=None,
            head_generation=int(row["head_generation"]),
            head_digest=str(row["head_digest"]),
            head_refreshed_at_ns=int(row["head_refreshed_at_ns"]),
        )

    def claim_legacy_workspace(
        self,
        *,
        expected_scope_id: int,
        expected_generation: int,
        expected_manifest_digest: str,
        workspace_id: str,
    ) -> AuthorityBinding | None:
        """Atomically bind one marker UUID to an exact legacy scope/head.

        Only a ``NULL`` workspace identity can transition to the supplied UUID.
        Replaying the same successful claim is idempotent. A different UUID,
        authority rebind, or manifest-head race fails closed without mutating or
        quarantining the legacy scope.
        """

        if (
            isinstance(expected_scope_id, bool)
            or not isinstance(expected_scope_id, int)
            or expected_scope_id < 1
        ):
            raise ValueError("expected_scope_id must be a positive integer.")
        expected_generation = _generation(expected_generation)
        expected_manifest_digest = _digest(
            "expected manifest digest", expected_manifest_digest, required=True
        )
        workspace_id = _canonical_uuid("workspace_id", workspace_id)
        assert expected_manifest_digest is not None
        now = time.time_ns()
        with self._transaction():
            row = self._connection.execute(
                """SELECT authority.* FROM authority_scopes AS authority
                   JOIN remote_manifest_heads AS head
                     ON head.scope_id = authority.scope_id
                   WHERE authority.scope_id = ? AND authority.active = 1
                     AND head.generation = ? AND head.digest = ?""",
                (
                    expected_scope_id,
                    expected_generation,
                    expected_manifest_digest,
                ),
            ).fetchone()
            if row is None:
                return None
            current_workspace_id = row["workspace_id"]
            if current_workspace_id is not None:
                if str(current_workspace_id) != workspace_id:
                    return None
                return _authority_from_row(row, changed=False)
            cursor = self._connection.execute(
                """UPDATE authority_scopes
                   SET workspace_id = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND active = 1 AND workspace_id IS NULL
                     AND EXISTS (
                       SELECT 1 FROM remote_manifest_heads AS head
                       WHERE head.scope_id = authority_scopes.scope_id
                         AND head.generation = ? AND head.digest = ?
                     )""",
                (
                    workspace_id,
                    now,
                    expected_scope_id,
                    expected_generation,
                    expected_manifest_digest,
                ),
            )
            if cursor.rowcount != 1:
                return None
            claimed = self._connection.execute(
                "SELECT * FROM authority_scopes WHERE scope_id = ?",
                (expected_scope_id,),
            ).fetchone()
        assert claimed is not None
        return _authority_from_row(claimed, changed=False)

    def compact_inactive_authorities(
        self,
        *,
        limit: int = _MAX_AUTHORITY_COMPACTION_PAGE,
        after_scope_id: int = 0,
    ) -> AuthorityCompactionPage:
        """Delete one bounded page of fully terminal inactive epochs.

        The keyset page examines at most sixteen epochs and runs in one
        ``BEGIN IMMEDIATE`` transaction. A crash therefore retains the entire
        page or commits the entire page. Active authority is never eligible.

        Compaction is deliberately downstream of filesystem GC. Any pending,
        quarantined, or conflicted operation; non-null stage reference;
        unresolved conflict; local bytes not yet proven removed; non-clean
        local materialization; or durable recovery intent preserves the whole
        epoch. Acknowledged operations
        whose stage families have already been removed and resolved conflict
        history whose staged path has already been detached are terminal.

        Feed ``next_after_scope_id`` into the next call to continue a sweep.
        Restarting a sweep from zero is idempotent and revisits epochs that may
        have become terminal since an earlier page skipped them.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_AUTHORITY_COMPACTION_PAGE
        ):
            raise ValueError(
                f"limit must be between 1 and {_MAX_AUTHORITY_COMPACTION_PAGE}."
            )
        if (
            isinstance(after_scope_id, bool)
            or not isinstance(after_scope_id, int)
            or after_scope_id < 0
        ):
            raise ValueError("after_scope_id must be a non-negative integer.")

        compacted: list[int] = []
        with self._transaction():
            rows = self._connection.execute(
                _INACTIVE_AUTHORITY_PAGE_SQL,
                (after_scope_id, limit),
            ).fetchall()
            scope_ids = tuple(int(row["scope_id"]) for row in rows)
            for scope_id in scope_ids:
                blocker = self._connection.execute(
                    _INACTIVE_AUTHORITY_BLOCKER_SQL,
                    (scope_id,) * 10,
                ).fetchone()
                if blocker is not None:
                    continue
                # Namespace-only changes carry no file stage, but remain user
                # work awaiting a receipt just like pending byte mutations.
                if self._connection.execute(
                    "SELECT 1 FROM local_directory_puts WHERE scope_id = ? LIMIT 1",
                    (scope_id,),
                ).fetchone() is not None:
                    continue

                # Child-first ordering is explicit rather than relying on a
                # mixture of CASCADE and restrictive foreign keys. Tables that
                # are eligibility blockers are still named here so a future
                # schema relaxation cannot make the final authority delete
                # accidentally depend on implicit behavior.
                self._connection.execute(
                    "DELETE FROM remote_manifest_staging WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM remote_manifest_rename_staging WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM remote_manifest_loads WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM eviction_intents WHERE scope_id = ?", (scope_id,)
                )
                self._connection.execute(
                    "DELETE FROM local_transfer_intents WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM remote_apply_intents WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM remote_rename_intents WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM conflict_resolutions WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM conflicts WHERE scope_id = ?", (scope_id,)
                )
                self._connection.execute(
                    """DELETE FROM operation_receipts
                       WHERE mutation_id IN (
                         SELECT mutation_id FROM pending_operations
                         WHERE scope_id = ?
                       )""",
                    (scope_id,),
                )
                self._connection.execute(
                    """DELETE FROM operation_stages
                       WHERE mutation_id IN (
                         SELECT mutation_id FROM pending_operations
                         WHERE scope_id = ?
                       )""",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM operation_dependencies WHERE scope_id = ?",
                    (scope_id,),
                )
                self._connection.execute(
                    "DELETE FROM pending_operations WHERE scope_id = ?", (scope_id,)
                )
                self._connection.execute(
                    "DELETE FROM materialized_entries WHERE scope_id = ?", (scope_id,)
                )
                self._connection.execute(
                    "DELETE FROM fabric_scope_usage WHERE scope_id = ?", (scope_id,)
                )
                self._connection.execute(
                    "DELETE FROM remote_entries WHERE scope_id = ?", (scope_id,)
                )
                self._connection.execute(
                    "DELETE FROM remote_manifest_heads WHERE scope_id = ?",
                    (scope_id,),
                )
                removed = self._connection.execute(
                    """DELETE FROM authority_scopes
                       WHERE scope_id = ? AND active = 0""",
                    (scope_id,),
                )
                if removed.rowcount != 1:
                    raise StateError(
                        "An inactive authority changed during terminal compaction."
                    )
                compacted.append(scope_id)

        next_after_scope_id = (
            scope_ids[-1] if len(scope_ids) == limit else None
        )
        return AuthorityCompactionPage(
            compacted_scope_ids=tuple(compacted),
            examined_scope_count=len(scope_ids),
            next_after_scope_id=next_after_scope_id,
        )

    # ---------------------------------------------------------- remote manifest

    def begin_remote_manifest_load(
        self,
        generation: int,
        digest: str | None,
        expected_entries: int,
        *,
        manifest_id: str,
        load_id: str | None = None,
    ) -> RemoteManifestLoad:
        """Create a durable, isolated full-manifest ingestion attempt.

        The returned UUID is the ownership capability for the load.  Merely
        beginning or ingesting a load never changes the published namespace or
        cursor; a crash therefore leaves the previous head fully readable.
        """

        # A v2 snapshot load carries no digest, and its sequence may legitimately
        # be 0 -- the settled state of a workspace nothing has been written to.
        # The relaxation is tied to the absent digest so a v1 manifest load is
        # still held to a positive generation.
        if digest is None:
            generation = _sequence("generation", generation)
        else:
            generation = _generation(generation)
        digest = _digest("manifest digest", digest, required=digest is not None)
        manifest_id = _mutation_id(manifest_id)
        if (
            isinstance(expected_entries, bool)
            or not isinstance(expected_entries, int)
            or not 0 <= expected_entries <= _MAX_REMOTE_MANIFEST_ENTRIES
        ):
            raise ValueError(
                f"expected_entries must be between 0 and {_MAX_REMOTE_MANIFEST_ENTRIES}."
            )
        load_id = _mutation_id(load_id)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            active_load = self._connection.execute(
                """SELECT load_id FROM remote_manifest_loads
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            if active_load is not None:
                raise StateError(
                    "The active authority epoch already owns a remote manifest load."
                )
            head = self._connection.execute(
                "SELECT generation, digest FROM remote_manifest_heads WHERE scope_id = ?",
                (scope_id,),
            ).fetchone()
            _validate_manifest_successor(head, generation, digest)
            self._connection.execute(
                """INSERT INTO remote_manifest_loads(
                       scope_id, load_id, manifest_id, generation, digest, expected_entries,
                       ingested_entries, last_path, created_at_ns, updated_at_ns
                   ) VALUES (?, ?, ?, ?, ?, ?, 0, NULL, ?, ?)""",
                (
                    scope_id,
                    load_id,
                    manifest_id,
                    generation,
                    digest,
                    expected_entries,
                    now,
                    now,
                ),
            )
            row = self._connection.execute(
                "SELECT * FROM remote_manifest_loads WHERE load_id = ?", (load_id,)
            ).fetchone()
        assert row is not None
        return _manifest_load_from_row(row)

    def get_remote_manifest_load(self) -> RemoteManifestLoad | None:
        """Return the active epoch's sole resumable full-manifest load."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM remote_manifest_loads
                   INDEXED BY remote_manifest_one_load_per_scope
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
        return _manifest_load_from_row(row) if row is not None else None

    def ingest_remote_manifest_page(
        self,
        load_id: str,
        entries: Iterable[RemoteEntry | Mapping[str, Any]],
    ) -> RemoteManifestLoad:
        """Append one bounded, strictly increasing page to a durable load."""

        load_id = _mutation_id(load_id)
        normalized = tuple(_remote_entry(item) for item in entries)
        if not normalized or len(normalized) > _MAX_REMOTE_MANIFEST_PAGE:
            raise ValueError(
                f"A manifest page must contain between 1 and {_MAX_REMOTE_MANIFEST_PAGE} entries."
            )
        paths = tuple(item.path for item in normalized)
        if any(left >= right for left, right in zip(paths, paths[1:])):
            raise StateError("Remote manifest page paths must be strictly increasing.")
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            load = self._connection.execute(
                """SELECT * FROM remote_manifest_loads
                   WHERE scope_id = ? AND load_id = ?""",
                (scope_id, load_id),
            ).fetchone()
            if load is None:
                raise StateError("The remote manifest load is not owned by the active epoch.")
            if load["last_path"] is not None and paths[0] <= str(load["last_path"]):
                raise StateError("Remote manifest pages must advance the durable path cursor.")
            next_count = int(load["ingested_entries"]) + len(normalized)
            if next_count > int(load["expected_entries"]):
                raise StateError("The remote manifest load contains more entries than declared.")
            self._connection.executemany(
                """INSERT INTO remote_manifest_staging(
                       scope_id, load_id, path, size_bytes, digest, modified, blocks_json
                   ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    (
                        scope_id,
                        load_id,
                        item.path,
                        item.size_bytes,
                        item.digest,
                        item.modified,
                        _blocks_json(item.blocks),
                    )
                    for item in normalized
                    if item.kind == "file"
                ),
            )
            self._connection.executemany(
                """INSERT INTO remote_directory_staging(scope_id, load_id, path)
                   VALUES (?, ?, ?)""",
                ((scope_id, load_id, item.path) for item in normalized
                 if item.kind == "directory"),
            )
            self._connection.execute(
                """UPDATE remote_manifest_loads
                   SET ingested_entries = ?, last_path = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND load_id = ?""",
                (next_count, paths[-1], now, scope_id, load_id),
            )
            row = self._connection.execute(
                "SELECT * FROM remote_manifest_loads WHERE load_id = ?", (load_id,)
            ).fetchone()
        assert row is not None
        return _manifest_load_from_row(row)

    def seal_remote_manifest_load(self, load_id: str) -> RemoteManifestLoad:
        """Fix a v2 snapshot load's size once its walk has reached EOF.

        A v1 manifest page declares `total_files` up front, so a load knows
        from page 0 how many entries must arrive before it may be committed.
        A v2 snapshot has no such header: the walk is over when a page comes
        back short, and only then is the count known.

        Rather than weaken the "an incomplete load cannot be committed" rule --
        which is the one thing standing between a dropped page and publishing a
        truncated namespace as the whole workspace -- the load starts with the
        hard cap as an upper bound and is narrowed to exactly what it ingested
        at EOF. Sealing is therefore the caller asserting "the walk finished",
        and it is refused once the load is already exact so a second, shorter
        walk cannot quietly redefine what complete means.
        """

        load_id = _mutation_id(load_id)
        with self._transaction():
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM remote_manifest_loads
                   WHERE scope_id = ? AND load_id = ?""",
                (scope_id, load_id),
            ).fetchone()
            if row is None:
                raise StateError("The remote manifest load is not owned by the active epoch.")
            if row["digest"] is not None:
                raise StateError("Only a Fabric v2 snapshot load is sealed at EOF.")
            ingested = int(row["ingested_entries"])
            if int(row["expected_entries"]) == ingested:
                raise StateError("The remote manifest load is already sealed.")
            self._connection.execute(
                """UPDATE remote_manifest_loads
                   SET expected_entries = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND load_id = ?""",
                (ingested, time.time_ns(), scope_id, load_id),
            )
            sealed = self._connection.execute(
                "SELECT * FROM remote_manifest_loads WHERE load_id = ?", (load_id,)
            ).fetchone()
        assert sealed is not None
        return _manifest_load_from_row(sealed)

    def commit_remote_manifest_load(
        self,
        load_id: str,
        *,
        max_materialized_entries: int,
        max_materialized_bytes: int,
        retire_absent_local: bool = True,
    ) -> RemoteManifestCommit:
        """Atomically diff, seed, publish, and advance one complete load.

        Diffing and unique-digest rename inference stay in SQLite.  Only
        bounded seed-candidate pages cross into Python, so a 250k-entry refresh
        never constructs old/new namespace tuples or dictionaries.  Existing
        materialization rows, including explicit ``absent`` eviction choices,
        are never overwritten by automatic seeding.
        """

        load_id = _mutation_id(load_id)
        if (
            isinstance(max_materialized_entries, bool)
            or not isinstance(max_materialized_entries, int)
            or not 0 <= max_materialized_entries <= _MAX_REMOTE_MANIFEST_ENTRIES
        ):
            raise ValueError(
                f"max_materialized_entries must be between 0 and {_MAX_REMOTE_MANIFEST_ENTRIES}."
            )
        if (
            isinstance(max_materialized_bytes, bool)
            or not isinstance(max_materialized_bytes, int)
            or not 0 <= max_materialized_bytes <= (1 << 60)
        ):
            raise ValueError("max_materialized_bytes must be between 0 and 2^60.")
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            load = self._connection.execute(
                """SELECT * FROM remote_manifest_loads
                   WHERE scope_id = ? AND load_id = ?""",
                (scope_id, load_id),
            ).fetchone()
            if load is None:
                raise StateError("The remote manifest load is not owned by the active epoch.")
            expected_entries = int(load["expected_entries"])
            if int(load["ingested_entries"]) != expected_entries:
                raise StateError("An incomplete remote manifest load cannot be committed.")
            generation = int(load["generation"])
            raw_load_digest = load["digest"]
            digest = str(raw_load_digest) if raw_load_digest is not None else None
            head = self._connection.execute(
                "SELECT * FROM remote_manifest_heads WHERE scope_id = ?", (scope_id,)
            ).fetchone()
            _validate_manifest_successor(head, generation, digest)
            raw_head_digest = head["digest"] if head is not None else None
            if (
                head is not None
                and int(head["generation"]) == generation
                and (str(raw_head_digest) if raw_head_digest is not None else None) == digest
            ):
                # The exact head won a race while this load was being fetched.
                # Discard only this isolated stage and leave its publication
                # timestamp and namespace untouched.
                self._connection.execute(
                    "DELETE FROM remote_manifest_loads WHERE load_id = ?", (load_id,)
                )
                return RemoteManifestCommit(
                    generation=generation,
                    digest=digest,
                    entry_count=expected_entries,
                    changed_paths=0,
                    apply_intents=0,
                    rename_intents=0,
                    seeded_entries=0,
                    seeded_bytes=0,
                    refreshed_at_ns=int(head["refreshed_at_ns"]),
                    changed=False,
                )

            changed_row = self._connection.execute(
                """SELECT COUNT(*) AS count FROM (
                       SELECT staged.path
                       FROM remote_manifest_staging AS staged
                       LEFT JOIN remote_entries AS current
                         ON current.scope_id = staged.scope_id
                        AND current.path = staged.path
                       WHERE staged.scope_id = ? AND staged.load_id = ?
                         AND (
                           current.path IS NULL
                           OR current.size_bytes != staged.size_bytes
                           OR current.digest != staged.digest
                         )
                       UNION ALL
                       SELECT current.path
                       FROM remote_entries AS current
                       LEFT JOIN remote_manifest_staging AS staged
                         ON staged.scope_id = current.scope_id
                        AND staged.load_id = ? AND staged.path = current.path
                       WHERE current.scope_id = ? AND staged.path IS NULL
                   )""",
                (scope_id, load_id, load_id, scope_id),
            ).fetchone()
            assert changed_row is not None
            changed_paths = int(changed_row["count"])

            # A full index page may intentionally carry only a deferred block
            # summary.  Do not throw away a previously CAS-fetched complete
            # map when the exact file bytes are unchanged; that would force a
            # redundant multi-page block-index fetch after every full refresh.
            self._connection.execute(
                """UPDATE remote_manifest_staging AS staged
                   SET blocks_json = (
                     SELECT current.blocks_json
                     FROM remote_entries AS current
                     WHERE current.scope_id = staged.scope_id
                       AND current.path = staged.path
                   )
                   WHERE staged.scope_id = ? AND staged.load_id = ?
                     AND COALESCE(json_extract(staged.blocks_json, '$.blocks_complete'), 0) = 0
                     AND EXISTS (
                       SELECT 1 FROM remote_entries AS current
                       WHERE current.scope_id = staged.scope_id
                         AND current.path = staged.path
                         AND current.size_bytes = staged.size_bytes
                         AND current.digest = staged.digest
                         AND json_extract(
                               current.blocks_json, '$.blocks_complete'
                             ) = 1
                         AND meshia_block_layout_completion_matches(
                               staged.blocks_json,
                               current.blocks_json,
                               staged.size_bytes
                             ) = 1
                     )""",
                (scope_id, load_id),
            )

            # Materialize only unambiguous remove/add pairs.  Both grouping
            # inputs are ordered by covering digest indexes; no Python digest
            # map or correlated per-entry count is involved.
            self._connection.execute(
                """INSERT INTO remote_manifest_rename_staging(
                       scope_id, load_id, source_path, destination_path,
                       digest, size_bytes
                   )
                   WITH removed AS (
                     SELECT current.path, current.digest, current.size_bytes
                     FROM remote_entries AS current
                     LEFT JOIN remote_manifest_staging AS same_path
                       ON same_path.scope_id = current.scope_id
                      AND same_path.load_id = ? AND same_path.path = current.path
                     WHERE current.scope_id = ? AND same_path.path IS NULL
                   ),
                   added AS (
                     SELECT staged.path, staged.digest, staged.size_bytes
                     FROM remote_manifest_staging AS staged
                     LEFT JOIN remote_entries AS same_path
                       ON same_path.scope_id = staged.scope_id
                      AND same_path.path = staged.path
                     WHERE staged.scope_id = ? AND staged.load_id = ?
                       AND same_path.path IS NULL
                   ),
                   unique_removed AS (
                     SELECT digest, MIN(path) AS path, MIN(size_bytes) AS size_bytes
                     FROM removed GROUP BY digest HAVING COUNT(*) = 1
                   ),
                   unique_added AS (
                     SELECT digest, MIN(path) AS path, MIN(size_bytes) AS size_bytes
                     FROM added GROUP BY digest HAVING COUNT(*) = 1
                   )
                   SELECT ?, ?, removed.path, added.path,
                          removed.digest, added.size_bytes
                   FROM unique_removed AS removed
                   JOIN unique_added AS added USING(digest)
                   JOIN materialized_entries AS materialized
                     ON materialized.scope_id = ?
                    AND materialized.path = removed.path
                    AND materialized.state = 'clean'
                    AND materialized.clean_digest = removed.digest
                   WHERE removed.size_bytes = added.size_bytes""",
                (
                    load_id,
                    scope_id,
                    scope_id,
                    load_id,
                    scope_id,
                    load_id,
                    scope_id,
                ),
            )
            rename_count_row = self._connection.execute(
                """SELECT COUNT(*) AS count FROM remote_manifest_rename_staging
                   WHERE scope_id = ? AND load_id = ?""",
                (scope_id, load_id),
            ).fetchone()
            assert rename_count_row is not None
            rename_count = int(rename_count_row["count"])
            intent_stamp = self._next_remote_intent_stamp(scope_id, now)

            rename_cursor = self._connection.execute(
                """INSERT OR REPLACE INTO remote_rename_intents(
                       scope_id, source_path, destination_path, digest,
                       size_bytes, created_at_ns
                   )
                   SELECT scope_id, source_path, destination_path, digest,
                          size_bytes, ?
                   FROM remote_manifest_rename_staging
                   WHERE scope_id = ? AND load_id = ?""",
                (intent_stamp, scope_id, load_id),
            )
            # Persist byte applies for every currently materialized path whose
            # content changed, except endpoints handled by an atomic rename.
            if not retire_absent_local:
                # A reset/adoption snapshot deliberately preserves absent local
                # bytes. An older generic hydration intent is not a deletion
                # receipt and must not acquire that meaning after replacement.
                self._connection.execute(
                    """DELETE FROM remote_apply_intents
                       WHERE scope_id = ? AND NOT EXISTS (
                           SELECT 1 FROM remote_manifest_staging AS staged
                           WHERE staged.scope_id = remote_apply_intents.scope_id
                             AND staged.load_id = ?
                             AND staged.path = remote_apply_intents.path
                       )""",
                    (scope_id, load_id),
                )
            apply_cursor = self._connection.execute(
                """INSERT OR IGNORE INTO remote_apply_intents(
                       scope_id, path, created_at_ns
                   )
                   SELECT materialized.scope_id, materialized.path, ?
                   FROM materialized_entries AS materialized
                   LEFT JOIN remote_entries AS current
                     ON current.scope_id = materialized.scope_id
                    AND current.path = materialized.path
                   LEFT JOIN remote_manifest_staging AS staged
                     ON staged.scope_id = materialized.scope_id
                    AND staged.load_id = ? AND staged.path = materialized.path
                   WHERE materialized.scope_id = ?
                     AND materialized.state != 'absent'
                     AND (
                       (current.path IS NULL AND staged.path IS NOT NULL)
                       OR (
                         ? AND current.path IS NOT NULL AND staged.path IS NULL
                       )
                       OR (
                         current.path IS NOT NULL AND staged.path IS NOT NULL
                         AND (
                           current.size_bytes != staged.size_bytes
                           OR current.digest != staged.digest
                         )
                       )
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_manifest_rename_staging AS rename
                       WHERE rename.scope_id = materialized.scope_id
                         AND rename.load_id = ?
                         AND rename.source_path = materialized.path
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_manifest_rename_staging AS rename
                       WHERE rename.scope_id = materialized.scope_id
                         AND rename.load_id = ?
                         AND rename.destination_path = materialized.path
                     )""",
                (
                    intent_stamp,
                    load_id,
                    scope_id,
                    # False is reserved for reset/adoption snapshots without
                    # namespace continuity. A monotonic same-authority snapshot
                    # or explicit journal delete retains retirement ownership.
                    1 if retire_absent_local else 0,
                    load_id,
                    load_id,
                ),
            )

            usage = self._connection.execute(
                """SELECT COUNT(*) AS entry_count,
                          COALESCE(SUM(
                            materialized.bytes_on_disk
                            + CASE
                                WHEN materialized.state = 'clean'
                                 AND materialized.bytes_on_disk = 0
                                 AND materialized.stat_fingerprint IS NULL
                                THEN COALESCE(staged.size_bytes, 0)
                                ELSE 0
                              END
                          ), 0) AS reserved_bytes
                   FROM materialized_entries AS materialized
                   LEFT JOIN remote_manifest_staging AS staged
                     ON staged.scope_id = materialized.scope_id
                    AND staged.load_id = ? AND staged.path = materialized.path
                   WHERE materialized.scope_id = ?
                     AND materialized.state != 'absent'""",
                (load_id, scope_id),
            ).fetchone()
            assert usage is not None
            remaining_entries = max(
                0, max_materialized_entries - int(usage["entry_count"])
            )
            remaining_bytes = max(
                0, max_materialized_bytes - int(usage["reserved_bytes"])
            )
            seeded_entries = 0
            seeded_bytes = 0
            seed_apply_count = 0
            after_path: str | None = None
            # A zero-byte policy disables automatic materialization entirely,
            # matching the coordinator's explicit off switch.  Otherwise an
            # empty file may still be selected after the byte budget is full.
            while remaining_entries > 0 and max_materialized_bytes > 0:
                candidates = self._connection.execute(
                    """SELECT staged.path, staged.size_bytes, staged.digest
                       FROM remote_manifest_staging AS staged
                       LEFT JOIN remote_entries AS current
                         ON current.scope_id = staged.scope_id
                        AND current.path = staged.path
                       LEFT JOIN materialized_entries AS materialized
                         ON materialized.scope_id = staged.scope_id
                        AND materialized.path = staged.path
                       WHERE staged.scope_id = ? AND staged.load_id = ?
                         AND staged.path > ?
                         AND staged.size_bytes <= ?
                         AND current.path IS NULL
                         AND materialized.path IS NULL
                         AND NOT EXISTS (
                           SELECT 1 FROM remote_manifest_rename_staging AS rename
                           WHERE rename.scope_id = staged.scope_id
                             AND rename.load_id = staged.load_id
                             AND rename.destination_path = staged.path
                         )
                       ORDER BY staged.path LIMIT ?""",
                    (
                        scope_id,
                        load_id,
                        after_path or "",
                        remaining_bytes,
                        min(_MAX_REMOTE_MANIFEST_PAGE, remaining_entries),
                    ),
                ).fetchall()
                if not candidates:
                    break
                selected: list[sqlite3.Row] = []
                for candidate in candidates:
                    after_path = str(candidate["path"])
                    size = int(candidate["size_bytes"])
                    if size > remaining_bytes:
                        continue
                    selected.append(candidate)
                    remaining_entries -= 1
                    remaining_bytes -= size
                    seeded_entries += 1
                    seeded_bytes += size
                    if remaining_entries == 0:
                        break
                if selected:
                    self._connection.executemany(
                        """INSERT INTO materialized_entries(
                               scope_id, path, state, pinned, clean_digest,
                               stat_fingerprint, bytes_on_disk,
                               accessed_at_ns, updated_at_ns
                           ) VALUES (?, ?, 'clean', 0, ?, NULL, 0, ?, ?)""",
                        (
                            (scope_id, row["path"], row["digest"], now, now)
                            for row in selected
                        ),
                    )
                    seed_cursor = self._connection.executemany(
                        """INSERT OR IGNORE INTO remote_apply_intents(
                               scope_id, path, created_at_ns
                           ) VALUES (?, ?, ?)""",
                        (
                            (scope_id, row["path"], intent_stamp)
                            for row in selected
                        ),
                    )
                    seed_apply_count += max(0, seed_cursor.rowcount)

            self._connection.execute(
                "DELETE FROM remote_entries WHERE scope_id = ?", (scope_id,)
            )
            self._connection.execute(
                """INSERT OR IGNORE INTO remote_apply_intents(scope_id, path, created_at_ns)
                   SELECT old.scope_id, old.path, ? FROM remote_directories AS old
                   WHERE old.scope_id = ? AND NOT EXISTS (
                       SELECT 1 FROM remote_directory_staging AS new
                       WHERE new.scope_id = old.scope_id AND new.load_id = ? AND new.path = old.path
                   )""", (now, scope_id, load_id),
            )
            self._connection.execute(
                "DELETE FROM remote_directories WHERE scope_id = ?", (scope_id,)
            )
            self._connection.execute(
                """INSERT INTO remote_directories(scope_id, path)
                   SELECT scope_id, path FROM remote_directory_staging
                   WHERE scope_id = ? AND load_id = ?""", (scope_id, load_id),
            )
            self._connection.execute(
                """INSERT INTO remote_entries(
                       scope_id, path, size_bytes, digest, modified, blocks_json
                   )
                   SELECT scope_id, path, size_bytes, digest, modified, blocks_json
                   FROM remote_manifest_staging
                   WHERE scope_id = ? AND load_id = ?
                   ORDER BY path""",
                (scope_id, load_id),
            )
            self._connection.execute(
                """INSERT INTO remote_manifest_heads(
                       scope_id, generation, digest, refreshed_at_ns
                   ) VALUES (?, ?, ?, ?)
                   ON CONFLICT(scope_id) DO UPDATE SET
                       generation = excluded.generation,
                       digest = excluded.digest,
                       refreshed_at_ns = excluded.refreshed_at_ns""",
                (scope_id, generation, digest, now),
            )
            self._connection.execute(
                "DELETE FROM remote_manifest_loads WHERE load_id = ?", (load_id,)
            )
            self._record_quota_rebuild_locked(scope_id)
        return RemoteManifestCommit(
            generation=generation,
            digest=digest,
            entry_count=expected_entries,
            changed_paths=changed_paths,
            apply_intents=max(0, apply_cursor.rowcount) + seed_apply_count,
            rename_intents=max(rename_count, max(0, rename_cursor.rowcount)),
            seeded_entries=seeded_entries,
            seeded_bytes=seeded_bytes,
            refreshed_at_ns=now,
            changed=True,
        )

    def abort_remote_manifest_load(self, load_id: str) -> bool:
        """Discard one active epoch's isolated load without touching its head."""

        load_id = _mutation_id(load_id)
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                """DELETE FROM remote_manifest_loads
                   WHERE scope_id = ? AND load_id = ?""",
                (scope_id, load_id),
            )
        return cursor.rowcount == 1

    def cleanup_stale_remote_manifest_loads(
        self, *, stale_before_ns: int, limit: int = 16
    ) -> int:
        """Boundedly reclaim abandoned full-manifest stages across epochs."""

        if (
            isinstance(stale_before_ns, bool)
            or not isinstance(stale_before_ns, int)
            or stale_before_ns < 0
        ):
            raise ValueError("stale_before_ns must be a non-negative integer.")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 256:
            raise ValueError("limit must be between 1 and 256.")
        with self._transaction():
            rows = self._connection.execute(
                """SELECT load_id FROM remote_manifest_loads
                   WHERE updated_at_ns < ?
                   ORDER BY updated_at_ns, load_id LIMIT ?""",
                (stale_before_ns, limit),
            ).fetchall()
            self._connection.executemany(
                "DELETE FROM remote_manifest_loads WHERE load_id = ?",
                ((row["load_id"],) for row in rows),
            )
        return len(rows)

    def replace_remote_manifest(
        self,
        generation: int,
        digest: str,
        entries: Iterable[RemoteEntry | Mapping[str, Any]],
        *,
        apply_paths: Iterable[str] = (),
        rename_intents: Iterable[tuple[str, str, str, int]] = (),
    ) -> RemoteManifest:
        """Atomically replace the active epoch's remote namespace snapshot."""
        generation = _generation(generation)
        digest = _digest("manifest digest", digest, required=True)
        normalized = tuple(_remote_entry(item) for item in entries)
        seen: set[str] = set()
        for item in normalized:
            if item.path in seen:
                raise StateError(f"Duplicate remote manifest path {item.path!r}.")
            seen.add(item.path)
        normalized = tuple(sorted(normalized, key=lambda item: item.path))
        normalized_applies, normalized_renames = _remote_intents(
            apply_paths, rename_intents
        )
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            existing_head = self._connection.execute(
                "SELECT generation, digest FROM remote_manifest_heads WHERE scope_id = ?",
                (scope_id,),
            ).fetchone()
            if existing_head is not None and generation < int(existing_head["generation"]):
                raise StateError("A stale remote manifest generation cannot replace a newer one.")
            if (
                existing_head is not None
                and generation == int(existing_head["generation"])
                and digest != str(existing_head["digest"])
            ):
                raise StateError("One remote manifest generation cannot have two digests.")
            self._connection.execute(
                "DELETE FROM remote_directories WHERE scope_id = ?", (scope_id,)
            )
            self._connection.executemany(
                "INSERT INTO remote_directories(scope_id, path) VALUES (?, ?)",
                ((scope_id, item.path) for item in normalized if item.kind == "directory"),
            )
            self._connection.execute(
                "DELETE FROM remote_entries WHERE scope_id = ?", (scope_id,)
            )
            self._connection.executemany(
                """INSERT INTO remote_entries(
                       scope_id, path, size_bytes, digest, modified, blocks_json
                   ) VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    (
                        scope_id,
                        item.path,
                        item.size_bytes,
                        item.digest,
                        item.modified,
                        _blocks_json(item.blocks),
                    )
                    for item in normalized if item.kind == "file"
                ),
            )
            self._connection.execute(
                """INSERT INTO remote_manifest_heads(
                       scope_id, generation, digest, refreshed_at_ns
                   ) VALUES (?, ?, ?, ?)
                   ON CONFLICT(scope_id) DO UPDATE SET
                       generation = excluded.generation,
                       digest = excluded.digest,
                       refreshed_at_ns = excluded.refreshed_at_ns""",
                (scope_id, generation, digest, now),
            )
            self._insert_remote_intents(
                scope_id, normalized_applies, normalized_renames, now
            )
            self._record_quota_rebuild_locked(scope_id)
        return RemoteManifest(generation, digest, normalized, now)

    def apply_remote_delta_v2(
        self,
        *,
        expected_seq: int,
        seq: int,
        entries: Mapping[str, RemoteEntry | Mapping[str, Any] | None],
        apply_paths: Iterable[str] = (),
        rename_intents: Iterable[tuple[str, str, str, int]] = (),
    ) -> tuple[RemoteEntry, ...]:
        """Apply a Fabric v2 change page, fencing on the journal sequence.

        v1 fenced this local apply with (generation, manifest digest). That
        digest was never a content check of local state against the remote --
        it is optimistic concurrency on the local head row -- and a per-scope
        monotonic sequence carries that on its own: a scope's sequence never
        repeats, and a re-attachment allocates a new scope, so a workspace that
        has been reset cannot hand this scope a sequence it has already seen.

        Sequence-only identity is the design ("version identity = journal
        seq"), not a concession to it: v2 has no per-commit content hash, and
        synthesising one from the sequence would let a reader believe integrity
        was verified when it was not. Whole-tree verification lives in
        checkpoints (fabric_tree_digest_1763) instead.
        """

        return self.apply_remote_delta(
            expected_generation=expected_seq,
            expected_digest=None,
            generation=seq,
            digest=None,
            entries=entries,
            apply_paths=apply_paths,
            rename_intents=rename_intents,
        )

    def apply_remote_delta(
        self,
        *,
        expected_generation: int,
        expected_digest: str | None,
        generation: int,
        digest: str | None,
        entries: Mapping[str, RemoteEntry | Mapping[str, Any] | None],
        apply_paths: Iterable[str] = (),
        rename_intents: Iterable[tuple[str, str, str, int]] = (),
    ) -> tuple[RemoteEntry, ...]:
        """Atomically apply only touched rows and advance the exact cursor.

        The returned rows are the pre-delta values for touched paths. Callers
        use that bounded snapshot for rename inference without loading the full
        remote namespace.
        """

        # v2 passes None for both digests: the journal sequence is the fence,
        # and a sequence starts at 0 (an untouched workspace) where a v1
        # manifest generation starts at 1. v1 callers still supply a digest and
        # are still checked against it, and still held to a positive
        # generation, so the relaxation cannot leak into that lane.
        expected_generation = (
            _sequence("expected generation", expected_generation)
            if expected_digest is None
            else _generation(expected_generation)
        )
        generation = (
            _sequence("generation", generation)
            if digest is None
            else _generation(generation)
        )
        expected_digest = _digest(
            "expected manifest digest",
            expected_digest,
            required=expected_digest is not None,
        )
        digest = _digest("manifest digest", digest, required=digest is not None)
        if generation <= expected_generation:
            raise ValueError("A remote delta must advance the manifest generation.")
        normalized: dict[str, RemoteEntry | None] = {}
        for raw_path, raw_entry in entries.items():
            path = _canonical_path(raw_path)
            entry = _remote_entry(raw_entry) if raw_entry is not None else None
            if entry is not None and entry.path != path:
                raise ValueError("A remote delta entry path does not match its key.")
            normalized[path] = entry
        if not normalized:
            raise ValueError("A remote delta must touch at least one path.")
        normalized_applies, normalized_renames = _remote_intents(
            apply_paths, rename_intents
        )
        now = time.time_ns()
        previous: list[RemoteEntry] = []
        with self._transaction():
            scope_id = self._active_scope_id()
            head = self._connection.execute(
                """SELECT generation, digest FROM remote_manifest_heads
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            # v1 fences on (generation, digest); v2 has no digest and fences
            # on the sequence alone, which is monotonic per scope. Comparing a
            # stored digest against None would fail every v2 apply, and
            # stringifying NULL would compare "None" to itself and pass
            # vacuously -- so the digest leg applies only when one was given.
            if (
                head is None
                or int(head["generation"]) != expected_generation
                or (
                    expected_digest is not None
                    and (
                        head["digest"] is None
                        or str(head["digest"]) != expected_digest
                    )
                )
            ):
                raise StateError("The remote manifest cursor changed before delta commit.")
            paths = tuple(sorted(normalized))
            for start in range(0, len(paths), 500):
                page = paths[start : start + 500]
                placeholders = ",".join("?" for _ in page)
                rows = self._connection.execute(
                    f"""SELECT * FROM remote_entries
                        WHERE scope_id = ? AND path IN ({placeholders})""",
                    (scope_id, *page),
                ).fetchall()
                previous.extend(_remote_from_row(row) for row in rows)
            for path, entry in normalized.items():
                if entry is None or entry.kind == "file":
                    self._connection.execute(
                        """INSERT OR IGNORE INTO remote_apply_intents(scope_id, path, created_at_ns)
                           SELECT scope_id, path, ? FROM remote_directories
                           WHERE scope_id = ? AND path = ?""", (now, scope_id, path),
                    )
                self._connection.execute(
                    "DELETE FROM remote_directories WHERE scope_id = ? AND path = ?",
                    (scope_id, path),
                )
                if entry is not None and entry.kind == "directory":
                    self._connection.execute(
                        "INSERT INTO remote_directories(scope_id, path) VALUES (?, ?)",
                        (scope_id, path),
                    )
                    entry = None  # Never send a directory into file hydration.
                if entry is None:
                    self._connection.execute(
                        "DELETE FROM remote_entries WHERE scope_id = ? AND path = ?",
                        (scope_id, path),
                    )
                else:
                    self._connection.execute(
                        """INSERT INTO remote_entries(
                               scope_id, path, size_bytes, digest, modified, blocks_json
                           ) VALUES (?, ?, ?, ?, ?, ?)
                           ON CONFLICT(scope_id, path) DO UPDATE SET
                               size_bytes = excluded.size_bytes,
                               digest = excluded.digest,
                               modified = excluded.modified,
                               blocks_json = excluded.blocks_json""",
                        (
                            scope_id,
                            entry.path,
                            entry.size_bytes,
                            entry.digest,
                            entry.modified,
                            _blocks_json(entry.blocks),
                        ),
                    )
            self._connection.execute(
                """UPDATE remote_manifest_heads
                   SET generation = ?, digest = ?, refreshed_at_ns = ?
                   WHERE scope_id = ?""",
                (generation, digest, now, scope_id),
            )
            self._insert_remote_intents(
                scope_id, normalized_applies, normalized_renames, now
            )
            self._record_quota_rebuild_locked(scope_id)
        return tuple(sorted(previous, key=lambda item: item.path))

    def advance_remote_manifest_head(
        self,
        *,
        expected_generation: int,
        expected_digest: str | None,
        generation: int,
        digest: str | None,
    ) -> RemoteManifestHead:
        """CAS-advance a cursor-only delta without touching namespace rows.

        A Fabric v2 caller passes no digest: the head is identified by its
        journal sequence, and the CAS is on that alone. The sequence is
        monotonic per scope, so it fences a stale advance exactly as the
        digest pair did.
        """

        expected_generation = _generation(expected_generation)
        # A v2 cursor is a journal sequence: it may start from 0 and carries
        # no digest. See apply_remote_delta for why the relaxation is tied to
        # the absent digest rather than applied unconditionally.
        generation = (
            _sequence("generation", generation)
            if digest is None
            else _generation(generation)
        )
        expected_digest = _digest(
            "expected manifest digest",
            expected_digest,
            required=expected_digest is not None,
        )
        digest = _digest("manifest digest", digest, required=digest is not None)
        if generation <= expected_generation:
            raise ValueError("A cursor-only delta must advance the manifest generation.")
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            # `digest IS ?` rather than `= ?` so a v2 head (NULL) matches on
            # NULL instead of never matching, which SQL equality would do.
            cursor = self._connection.execute(
                """UPDATE remote_manifest_heads
                   SET generation = ?, digest = ?, refreshed_at_ns = ?
                   WHERE scope_id = ? AND generation = ?
                     AND (? IS NULL OR digest IS ?)""",
                (
                    generation,
                    digest,
                    now,
                    scope_id,
                    expected_generation,
                    expected_digest,
                    expected_digest,
                ),
            )
            if cursor.rowcount != 1:
                raise StateError(
                    "The remote manifest cursor changed before cursor-only commit."
                )
        return RemoteManifestHead(generation, digest, now)

    def get_remote_manifest(self) -> RemoteManifest | None:
        # The head and namespace must come from one WAL snapshot. A separate
        # process may replace both between two autocommit SELECTs even though
        # this instance's Python lock is held.
        with self._read_transaction():
            scope_id = self._active_scope_id()
            head = self._connection.execute(
                "SELECT * FROM remote_manifest_heads WHERE scope_id = ?", (scope_id,)
            ).fetchone()
            if head is None:
                return None
            rows = self._connection.execute(
                "SELECT * FROM remote_entries WHERE scope_id = ? ORDER BY path", (scope_id,)
            ).fetchall()
        return RemoteManifest(
            generation=int(head["generation"]),
            digest=None if head["digest"] is None else str(head["digest"]),
            entries=tuple(_remote_from_row(row) for row in rows),
            refreshed_at_ns=int(head["refreshed_at_ns"]),
        )

    def get_remote_manifest_head(self) -> RemoteManifestHead | None:
        """Read the cursor without materializing the remote namespace."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT generation, digest, refreshed_at_ns
                   FROM remote_manifest_heads WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
        if row is None:
            return None
        return RemoteManifestHead(
            generation=int(row["generation"]),
            # A v2 head has no digest; keep it None rather than stringifying
            # NULL into the literal "None", which would compare equal to
            # itself and silently satisfy a digest fence.
            digest=None if row["digest"] is None else str(row["digest"]),
            refreshed_at_ns=int(row["refreshed_at_ns"]),
        )

    def mark_local_directory_removed(
        self,
        path: str,
        *,
        expected_generation: int | None,
        expected_manifest_digest: str | None,
        expected_scope_id: int | None = None,
    ) -> bool:
        """Durably hide one empty local directory at an exact remote head.

        The compare-and-set prevents a concurrent remote child from being
        hidden. Fabric v2 fences on its sequence alone, without a digest.
        """

        path = _canonical_path(path)
        if expected_scope_id is not None and (
            isinstance(expected_scope_id, bool)
            or not isinstance(expected_scope_id, int)
            or expected_scope_id < 1
        ):
            raise ValueError("expected_scope_id must be a positive integer.")
        if expected_generation is None and expected_manifest_digest is not None:
            raise ValueError("A manifest digest requires an expected generation.")
        if expected_generation is not None:
            expected_generation = (
                _sequence("expected generation", expected_generation)
                if expected_manifest_digest is None else _generation(expected_generation)
            )
            expected_manifest_digest = _digest(
                "expected manifest digest",
                expected_manifest_digest,
                required=expected_manifest_digest is not None,
            )
        now = time.time_ns()
        expected = (
            None
            if expected_generation is None
            else (expected_generation, expected_manifest_digest)
        )
        with self._transaction():
            scope_id = self._active_scope_id()
            if expected_scope_id is not None:
                # Native rmdir may yield between removing its physical cache
                # directory and this journal transaction. Never bind that old
                # intent to a newly active workspace, even with the same head.
                active = self._connection.execute(
                    "SELECT scope_id FROM authority_scopes WHERE active = 1"
                ).fetchone()
                if active is None or int(active["scope_id"]) != expected_scope_id:
                    return False
                scope_id = expected_scope_id
            head = self._connection.execute(
                "SELECT generation, digest FROM remote_manifest_heads WHERE scope_id = ?",
                (scope_id,),
            ).fetchone()
            actual = (
                None
                if head is None
                else (
                    int(head["generation"]),
                    # Same NULL trap as the snapshot: str() on a v2 head's
                    # missing digest yields "None", which can never equal the
                    # caller's real None, so the compare-and-set silently
                    # failed and the directory was never hidden.
                    None if head["digest"] is None else str(head["digest"]),
                )
            )
            if actual != expected:
                return False
            current = self._rebase_local_directory_tombstones_locked(
                scope_id,
                generation=expected_generation,
                digest=expected_manifest_digest,
            )
            if path not in current and len(current) >= _MAX_LOCAL_DIRECTORY_TOMBSTONES:
                raise StateError(
                    "The local empty-directory overlay reached its bounded limit."
                )
            self._connection.execute(
                """INSERT INTO local_directory_tombstones(
                       scope_id, path, head_generation, head_digest, created_at_ns
                   ) VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(scope_id, path) DO UPDATE SET
                       head_generation = excluded.head_generation,
                       head_digest = excluded.head_digest""",
                (
                    scope_id,
                    path,
                    expected_generation,
                    expected_manifest_digest,
                    now,
                ),
            )
            pending_directory = self._connection.execute(
                """SELECT 1 FROM local_directory_puts WHERE scope_id = ?
                   AND (path = ? OR destination_path = ?) LIMIT 1""",
                (scope_id, path, path),
            ).fetchone()
            if expected_manifest_digest is None and (
                expected_generation is not None or pending_directory is not None
            ):
                # Keep delete in the same ordered journal as mkdir/rename.
                # A recreation may clear the visibility overlay, but must not
                # forget a delete whose server outcome is still unknown.
                stamp = self._connection.execute(
                    """SELECT created_at_ns FROM local_directory_tombstones
                       WHERE scope_id = ? AND path = ?""", (scope_id, path),
                ).fetchone()["created_at_ns"]
                mutation_id = str(uuid.uuid5(
                    uuid.NAMESPACE_URL, f"meshia:directory-delete:{scope_id}:{path}:{stamp}"
                ))
                self._connection.execute(
                    """INSERT OR IGNORE INTO local_directory_puts(
                           scope_id, path, mutation_id, created_at_ns, kind
                       ) VALUES (?, ?, ?, ?, 'delete')""",
                    (scope_id, path, mutation_id, now),
                )
        return True

    def _rebase_local_directory_tombstones_locked(
        self,
        scope_id: int,
        *,
        generation: int | None,
        digest: str | None,
    ) -> tuple[str, ...]:
        """Carry overlays across unrelated heads, revealing real remote children."""

        rows = self._connection.execute(
            """SELECT path, head_generation, head_digest
               FROM local_directory_tombstones
               WHERE scope_id = ? ORDER BY path LIMIT ?""",
            (scope_id, _MAX_LOCAL_DIRECTORY_TOMBSTONES + 1),
        ).fetchall()
        if len(rows) > _MAX_LOCAL_DIRECTORY_TOMBSTONES:
            raise StateError(
                "The local empty-directory overlay exceeds its bounded limit."
            )
        receipt = self._connection.execute(
            "SELECT generation FROM namespace_receipt_heads WHERE scope_id = ?",
            (scope_id,),
        ).fetchone()
        receipt_generation = (
            int(receipt["generation"]) if receipt is not None else None
        )
        visible: list[str] = []
        for row in rows:
            path = str(row["path"])
            recorded = (
                None
                if row["head_generation"] is None
                else (
                    int(row["head_generation"]),
                    None
                    if row["head_digest"] is None
                    else str(row["head_digest"]),
                )
            )
            current = None if generation is None else (generation, digest)
            if recorded != current:
                # ``remote_directories`` has no per-row generation. The exact
                # path may therefore still be the pre-delete row while a
                # receipted native rmdir is ahead of our observed head. Only a
                # head strictly newer than the latest namespace receipt can
                # prove that an exact empty directory is a later recreation.
                exact_directory_recreated = (
                    generation is not None
                    and receipt_generation is not None
                    and generation > receipt_generation
                    and self._connection.execute(
                        """SELECT 1 FROM remote_directories
                           WHERE scope_id = ? AND path = ?""",
                        (scope_id, path),
                    ).fetchone()
                    is not None
                )
                if exact_directory_recreated:
                    self._connection.execute(
                        """DELETE FROM local_directory_tombstones
                           WHERE scope_id = ? AND path = ?""",
                        (scope_id, path),
                    )
                    continue
                prefix = path + "/"
                # The raw feed can still contain descendants already hidden
                # by durable local deletes. Do not resurrect their directories
                # on an unrelated head advance. Only the latest exact file
                # preimage is suppressed; a new path/digest or unremoved child
                # directory reveals the subtree and remains server-protected.
                remote_child = self._connection.execute(
                    """SELECT 1 FROM (
                           SELECT path, digest, 'file' AS kind FROM remote_entries
                           WHERE scope_id = :scope
                           UNION ALL
                           SELECT path, NULL AS digest, 'dir' AS kind FROM remote_directories
                           WHERE scope_id = :scope AND path != :path
                       ) AS child WHERE (
                           child.path = :path OR substr(child.path, 1, :prefix_length) = :prefix
                       ) AND NOT (
                           child.kind = 'file' AND EXISTS (
                               SELECT 1 FROM pending_operations AS deletion
                               WHERE deletion.scope_id = :scope AND deletion.path = child.path
                                 AND deletion.kind = 'delete'
                                 AND deletion.expected_source_digest = child.digest
                                 AND (deletion.state IN ('queued', 'inflight', 'retry') OR (
                                     deletion.state = 'acked' AND EXISTS (
                                         SELECT 1 FROM operation_receipts AS receipt
                                         WHERE receipt.mutation_id = deletion.mutation_id
                                           AND receipt.remote_manifest_digest IS NULL
                                           AND receipt.remote_generation > COALESCE(:generation, -1)
                                     )
                                 )) AND NOT EXISTS (
                                     SELECT 1 FROM pending_operations AS successor
                                     WHERE successor.scope_id = :scope
                                       AND successor.journal_seq > deletion.journal_seq
                                       AND successor.state IN ('queued', 'inflight', 'retry', 'acked')
                                       AND (successor.path = child.path OR successor.destination_path = child.path)
                                 )
                           )
                       ) AND NOT (
                           child.kind = 'dir' AND (
                               EXISTS (SELECT 1 FROM local_directory_tombstones AS removed
                                       WHERE removed.scope_id = :scope AND removed.path = child.path)
                               OR 'delete' = COALESCE((
                                   SELECT kind FROM local_directory_puts AS namespace
                                   WHERE namespace.scope_id = :scope
                                     AND (namespace.path = child.path OR namespace.destination_path = child.path)
                                   ORDER BY created_at_ns DESC, mutation_id DESC LIMIT 1
                               ), '')
                           )
                       ) LIMIT 1""",
                    {"scope": scope_id, "path": path, "prefix": prefix,
                     "prefix_length": len(prefix), "generation": generation},
                ).fetchone()
                if remote_child is not None:
                    self._connection.execute(
                        """DELETE FROM local_directory_tombstones
                           WHERE scope_id = ? AND path = ?""",
                        (scope_id, path),
                    )
                    continue
                self._connection.execute(
                    """UPDATE local_directory_tombstones
                       SET head_generation = ?, head_digest = ?
                       WHERE scope_id = ? AND path = ?""",
                    (generation, digest, scope_id, path),
                )
            visible.append(path)
        return tuple(visible)

    def local_directory_tombstone_snapshot(
        self,
    ) -> tuple[tuple[int, str | None] | None, tuple[str, ...]]:
        """Restore one head-fenced empty-directory overlay and prune stale rows.

        The digest is returned exactly as the head holds it, including NULL. A
        Fabric v2 head has no manifest digest at all, and ``str()`` on that
        NULL produced the literal ``"None"`` -- which was then sent as a
        base_manifest_digest and rejected by the server's sha256 validator, so
        every folder delete on a v2 workspace failed on a request this client
        had malformed itself.
        """

        with self._transaction():
            scope_id = self._active_scope_id()
            head = self._connection.execute(
                "SELECT generation, digest FROM remote_manifest_heads WHERE scope_id = ?",
                (scope_id,),
            ).fetchone()
            generation = int(head["generation"]) if head is not None else None
            digest = (
                str(head["digest"])
                if head is not None and head["digest"] is not None
                else None
            )
            paths = self._rebase_local_directory_tombstones_locked(
                scope_id,
                generation=generation,
                digest=digest,
            )
        identity: tuple[int, str | None] | None = (
            None if head is None else (int(head["generation"]), digest)
        )
        return identity, paths

    def forget_local_directory_tombstone(self, path: str) -> bool:
        """Make an explicitly recreated local directory visible again."""

        path = _canonical_path(path)
        with self._transaction():
            scope_id = self._active_scope_id()
            removed = self._connection.execute(
                """DELETE FROM local_directory_tombstones
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, path),
            )
        return removed.rowcount == 1

    def record_namespace_receipt(self, generation: int) -> None:
        """Remember acknowledged metadata progress, without claiming it observed."""
        generation = _sequence("receipt generation", generation)
        with self._transaction():
            self._connection.execute(
                """INSERT INTO namespace_receipt_heads(scope_id, generation) VALUES (?, ?)
                   ON CONFLICT(scope_id) DO UPDATE SET generation = MAX(generation, excluded.generation)""",
                (self._active_scope_id(), generation),
            )

    def max_unobserved_receipt_generation(self) -> int | None:
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT MAX(generation) AS generation FROM (
                       SELECT MAX(remote_generation) AS generation FROM operation_receipts
                       WHERE scope_id = ? AND remote_manifest_digest IS NULL
                       UNION ALL
                       SELECT generation FROM namespace_receipt_heads WHERE scope_id = ?
                   ) WHERE generation > COALESCE((
                       SELECT generation FROM remote_manifest_heads WHERE scope_id = ?
                   ), -1)""", (scope_id, scope_id, scope_id),
            ).fetchone()
        return int(row["generation"]) if row["generation"] is not None else None

    def has_unobserved_receipts(self) -> bool:
        return self.max_unobserved_receipt_generation() is not None

    def _receipted_entry_locked(self, scope_id: int, row: sqlite3.Row, path: str) -> ReceiptedEntry:
        entry = None
        if row["kind"] == "put" or (row["kind"] == "rename" and row["destination_path"] == path):
            digest = row["remote_entry_digest"] or row["staged_digest"] or row["expected_source_digest"]
            if digest is None:
                raise StateError("An acknowledged file effect has no durable content identity.")
            size = row["staged_size"]
            receipt = json.loads(row["receipt_json"]) if row["receipt_json"] else {}
            blocks = receipt.get("entry_blocks") if isinstance(receipt, dict) else None
            raw_modified = (
                receipt.get("entry_modified_at")
                if isinstance(receipt, dict)
                else None
            )
            modified = str(raw_modified) if isinstance(raw_modified, str) else None
            if row["kind"] == "rename" and row["rename_source_json"] is not None:
                frozen = _remote_entry(json.loads(row["rename_source_json"]))
                if frozen.digest != digest:
                    raise StateError("The acknowledged replacement changed its frozen content identity.")
                size, blocks, modified = frozen.size_bytes, frozen.blocks, frozen.modified
            if size is None or blocks is None:
                source = self._connection.execute(
                    """SELECT size_bytes, blocks_json, modified FROM remote_entries
                       WHERE scope_id = ? AND digest = ? ORDER BY path LIMIT 1""",
                    (scope_id, digest),
                ).fetchone()
                if source is not None:
                    if size is None:
                        size = int(source["size_bytes"])
                    if blocks is None and source["blocks_json"] is not None:
                        blocks = json.loads(source["blocks_json"])
                    if modified is None:
                        modified = source["modified"]
            if size is None or (blocks is None and row["kind"] == "rename"):
                # Rename receipts can precede projection of their source put.
                # The retained put journal owns both size and its descriptor.
                source = self._connection.execute(
                    """SELECT operation.staged_size, receipt.receipt_json
                       FROM pending_operations AS operation
                       JOIN operation_receipts AS receipt ON receipt.mutation_id = operation.mutation_id
                       WHERE operation.scope_id = ? AND operation.state = 'acked'
                         AND operation.kind = 'put' AND operation.staged_digest = ?
                       ORDER BY receipt.remote_generation DESC, operation.journal_seq DESC LIMIT 1""",
                    (scope_id, digest),
                ).fetchone()
                if source is not None:
                    if size is None:
                        size = source["staged_size"]
                    prior = json.loads(source["receipt_json"]) if source["receipt_json"] else {}
                    if blocks is None and isinstance(prior, dict):
                        blocks = prior.get("entry_blocks")
            if size is None:
                source = self._connection.execute(
                    """SELECT bytes_on_disk FROM materialized_entries
                       WHERE scope_id = ? AND clean_digest = ? AND state = 'clean'
                       ORDER BY path LIMIT 1""", (scope_id, digest),
                ).fetchone()
                if source is None:
                    raise StateError("An acknowledged file effect has no durable size metadata.")
                size = int(source["bytes_on_disk"])
            entry = RemoteEntry(path, int(size), str(digest), modified, blocks)
        return ReceiptedEntry(path, int(row["remote_generation"]), str(row["mutation_id"]), entry)

    def get_receipted_entry(self, path: str) -> ReceiptedEntry | None:
        """Exact-path read-your-write overlay; None means no newer receipt."""
        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT operation.*, receipt.remote_generation,
                          receipt.remote_entry_digest, receipt.receipt_json
                   FROM pending_operations AS operation
                   JOIN operation_receipts AS receipt ON receipt.mutation_id = operation.mutation_id
                   WHERE operation.scope_id = ? AND operation.state = 'acked'
                     AND operation.directory_rename = 0
                     AND (operation.path = ? OR operation.destination_path = ?)
                     AND receipt.remote_manifest_digest IS NULL
                     AND receipt.remote_generation > COALESCE((
                         SELECT generation FROM remote_manifest_heads WHERE scope_id = ?
                     ), -1)
                   ORDER BY receipt.remote_generation DESC, operation.journal_seq DESC LIMIT 1""",
                (scope_id, path, path, scope_id),
            ).fetchone()
            return self._receipted_entry_locked(scope_id, row, path) if row is not None else None

    def has_later_receipted_operation(self, path: str, journal_seq: int) -> bool:
        """Whether a newer durable mutation receipt supersedes one path result."""

        path = _canonical_path(path)
        if isinstance(journal_seq, bool) or not isinstance(journal_seq, int) or journal_seq < 1:
            raise ValueError("journal_seq must be a positive integer")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT 1 FROM pending_operations AS operation
                   JOIN operation_receipts AS receipt
                     ON receipt.mutation_id = operation.mutation_id
                   WHERE operation.scope_id = ? AND operation.state = 'acked'
                     AND operation.journal_seq > ?
                     AND (operation.path = ? OR operation.destination_path = ?)
                   LIMIT 1""",
                (scope_id, journal_seq, path, path),
            ).fetchone()
        return row is not None

    def list_receipted_entries(
        self, prefix: str | None = None, *, limit: int = 100_000
    ) -> tuple[ReceiptedEntry, ...]:
        """Latest acknowledged effects per path, bounded and scoped to a subtree."""
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000")
        prefix = _canonical_path(prefix) if prefix else None
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            scope_filter = ""
            parameters: tuple[Any, ...] = (scope_id, scope_id)
            if prefix is not None:
                scope_filter = "AND (effect_path = ? OR (effect_path >= ? AND effect_path < ?))"
                parameters += (prefix, prefix + "/", _prefix_upper_bound(prefix + "/"))
            rows = self._connection.execute(
                f"""WITH acknowledged AS (
                       SELECT operation.*, receipt.remote_generation,
                              receipt.remote_entry_digest, receipt.receipt_json
                       FROM pending_operations AS operation
                       JOIN operation_receipts AS receipt ON receipt.mutation_id = operation.mutation_id
                       WHERE operation.scope_id = ? AND operation.state = 'acked'
                         AND operation.directory_rename = 0 AND receipt.remote_manifest_digest IS NULL
                         AND receipt.remote_generation > COALESCE((
                             SELECT generation FROM remote_manifest_heads WHERE scope_id = ?
                         ), -1)
                   ), effects AS (
                       SELECT acknowledged.*, path AS effect_path FROM acknowledged
                       UNION ALL
                       SELECT acknowledged.*, destination_path AS effect_path FROM acknowledged
                       WHERE kind = 'rename'
                   ), latest AS (
                       SELECT effects.*, ROW_NUMBER() OVER (
                           PARTITION BY effect_path ORDER BY remote_generation DESC, journal_seq DESC
                       ) AS rank FROM effects
                   ) SELECT * FROM latest WHERE rank = 1 {scope_filter}
                   ORDER BY effect_path LIMIT ?""", (*parameters, limit + 1),
            ).fetchall()
            if len(rows) > limit:
                raise StateError("Unobserved receipt projection exceeds its bounded path page.")
            return tuple(self._receipted_entry_locked(scope_id, row, str(row["effect_path"])) for row in rows)

    def is_remote_directory(self, path: str) -> bool:
        """Whether the server explicitly retains this directory, even empty."""
        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            return self._connection.execute(
                "SELECT 1 FROM remote_directories WHERE scope_id = ? AND path = ?",
                (self._active_scope_id(), path),
            ).fetchone() is not None

    def list_remote_directories(
        self, prefix: str = "", *, limit: int = 100_000
    ) -> tuple[str, ...]:
        """List explicit directories at or below a bounded subtree."""
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 250_000:
            raise ValueError("limit must be between 1 and 250000")
        path = _canonical_path(prefix) if prefix else ""
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if path:
                rows = self._connection.execute(
                    """SELECT path FROM remote_directories WHERE scope_id = ?
                       AND (path = ? OR (path >= ? AND path < ?))
                       ORDER BY path LIMIT ?""",
                    (scope_id, path, path + "/", _prefix_upper_bound(path + "/"), limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    "SELECT path FROM remote_directories WHERE scope_id = ? ORDER BY path LIMIT ?",
                    (scope_id, limit),
                ).fetchall()
        return tuple(str(row["path"]) for row in rows)

    def queue_directory_put(self, path: str) -> DirectoryPut:
        """Persist mkdir before acknowledging it; retries retain one mutation ID."""
        path = _canonical_path(path)
        with self._transaction():
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT mutation_id, kind, created_at_ns FROM local_directory_puts
                   WHERE scope_id = ? AND (path = ? OR destination_path = ?)
                   ORDER BY created_at_ns DESC LIMIT 1""",
                (scope_id, path, path),
            ).fetchone()
            if row is not None and row["kind"] != "put":
                row = None
            mutation_id = str(row["mutation_id"]) if row else str(uuid.uuid4())
            created_at_ns = int(row["created_at_ns"]) if row else time.time_ns()
            if row is None:
                self._connection.execute(
                    """INSERT INTO local_directory_puts(
                           scope_id, path, mutation_id, created_at_ns, kind
                       ) VALUES (?, ?, ?, ?, 'put')""",
                    (scope_id, path, mutation_id, created_at_ns),
                )
            self._connection.execute(
                "DELETE FROM local_directory_tombstones WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            )
        return DirectoryPut(path, mutation_id, created_at_ns=created_at_ns)

    def queue_directory_rename(self, path: str, destination_path: str) -> DirectoryPut:
        path, destination_path = _canonical_path(path), _canonical_path(destination_path)
        if path == destination_path or destination_path.startswith(path + "/"):
            raise ValueError("A directory cannot be renamed into itself.")
        mutation_id = str(uuid.uuid4())
        created_at_ns = time.time_ns()
        with self._transaction():
            self._connection.execute(
                """INSERT INTO local_directory_puts(
                       scope_id, path, mutation_id, created_at_ns, kind, destination_path
                   ) VALUES (?, ?, ?, ?, 'rename', ?)""",
                (self._active_scope_id(), path, mutation_id, created_at_ns, destination_path),
            )
        return DirectoryPut(path, mutation_id, "rename", destination_path, created_at_ns)

    def has_pending_directory_put(self, path: str) -> bool:
        """Protect a pending directory and its parents from remote cache pruning."""
        path = _canonical_path(path)
        prefix = path + "/"
        with self._lock:
            self._require_open()
            return self._connection.execute(
                """SELECT 1 FROM local_directory_puts WHERE scope_id = ? AND (
                       path = ? OR (path >= ? AND path < ?) OR
                       destination_path = ? OR (destination_path >= ? AND destination_path < ?)
                   ) LIMIT 1""",
                (self._active_scope_id(), path, prefix, _prefix_upper_bound(prefix),
                 path, prefix, _prefix_upper_bound(prefix)),
            ).fetchone() is not None

    def has_queued_directory_delete(self, path: str) -> bool:
        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            return self._connection.execute(
                """SELECT 1 FROM local_directory_puts
                   WHERE scope_id = ? AND path = ? AND kind = 'delete' LIMIT 1""",
                (self._active_scope_id(), path),
            ).fetchone() is not None

    def directory_delete_mutation_id(self, path: str) -> str | None:
        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                "SELECT created_at_ns FROM local_directory_tombstones WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
        if row is None:
            return None
        return str(uuid.uuid5(uuid.NAMESPACE_URL, f"meshia:directory-delete:{scope_id}:{path}:{row['created_at_ns']}"))

    def list_directory_puts(self, *, limit: int = 100) -> tuple[DirectoryPut, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit must be between 1 and 1000")
        with self._lock:
            self._require_open()
            rows = self._connection.execute(
                """SELECT path, mutation_id, kind, destination_path, created_at_ns FROM local_directory_puts
                   WHERE scope_id = ? ORDER BY created_at_ns, path, mutation_id LIMIT ?""",
                (self._active_scope_id(), limit),
            ).fetchall()
        return tuple(DirectoryPut(str(row["path"]), str(row["mutation_id"]),
                                  str(row["kind"]), row["destination_path"],
                                  int(row["created_at_ns"])) for row in rows)

    def conflict_directory_operations(
        self, path: str, mutation_id: str, reason: str
    ) -> tuple[DirectoryPut, ...]:
        """Retire a rejected FIFO head and its dependent namespace safely.

        Namespace rows have no file stages, so each gets standalone conflict
        evidence before removal. Dependent byte operations retain their journal
        and stage ownership in conflict state. An ambiguous byte commit retains
        its unknown-outcome fence in quarantine instead. No user bytes move.
        """
        path, mutation_id = _canonical_path(path), _mutation_id(mutation_id)
        reason = _bounded_text("reason", reason, _MAX_ERROR_BYTES)

        def overlaps(left: str, right: str) -> bool:
            return left == right or left.startswith(right + "/") or right.startswith(left + "/")

        def paths_of(row: sqlite3.Row) -> tuple[str, ...]:
            return (str(row["path"]),) + (
                (str(row["destination_path"]),) if row["destination_path"] is not None else ()
            )

        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT * FROM local_directory_puts WHERE scope_id = ?
                   ORDER BY created_at_ns, path, mutation_id LIMIT 100001""", (scope_id,),
            ).fetchall()
            if not rows or rows[0]["path"] != path or rows[0]["mutation_id"] != mutation_id:
                return ()  # Receipt belongs to a former head; never retire its successor.
            if len(rows) > 100_000:
                raise StateError("Directory conflict recovery exceeds its bounded namespace queue.")
            roots: set[str] = set(paths_of(rows[0]))
            file_rows = self._connection.execute(
                """SELECT * FROM pending_operations WHERE scope_id = ?
                   AND state IN ('queued', 'inflight', 'retry')
                   ORDER BY journal_seq LIMIT 100001""", (scope_id,),
            ).fetchall()
            if len(file_rows) > 100_000:
                raise StateError("Directory conflict recovery exceeds its bounded file journal.")
            # A file rename can bridge into another queued directory, whose
            # rename can bridge back into byte work. Reach a fixed point over
            # both journals before retiring anything; two separate one-way
            # passes would leave those indirect dependents publishable.
            affected_ids: set[str] = set()
            affected_file_ids: set[str] = set()
            changed = True
            while changed:
                changed = False
                for candidates, selected in ((rows, affected_ids), (file_rows, affected_file_ids)):
                    for row in candidates:
                        candidate_id = str(row["mutation_id"])
                        if candidate_id in selected:
                            continue
                        operation_paths = paths_of(row)
                        if any(overlaps(candidate, root) for candidate in operation_paths for root in roots):
                            selected.add(candidate_id)
                            roots.update(operation_paths)
                            changed = True
            affected = [row for row in rows if str(row["mutation_id"]) in affected_ids]
            affected_files = [row for row in file_rows if str(row["mutation_id"]) in affected_file_ids]

            for row in affected:
                evidence_reason = reason + "; namespace=" + json.dumps({
                    "kind": row["kind"], "path": row["path"],
                    "destination_path": row["destination_path"],
                    "rejected_mutation_id": mutation_id,
                }, separators=(",", ":"))
                self._connection.execute(
                    """INSERT OR IGNORE INTO conflicts(
                           scope_id, evidence_key, path, reason, recorded_at_ns
                       ) VALUES (?, ?, ?, ?, ?)""",
                    (scope_id, f"directory-operation:{row['mutation_id']}",
                     row["path"], evidence_reason, now),
                )
                self._connection.execute(
                    """DELETE FROM local_directory_puts
                       WHERE scope_id = ? AND mutation_id = ?""",
                    (scope_id, row["mutation_id"]),
                )
                for affected_path in paths_of(row):
                    self._connection.execute(
                        "DELETE FROM local_directory_tombstones WHERE scope_id = ? AND path = ?",
                        (scope_id, affected_path),
                    )

            for row in affected_files:
                self._connection.execute(
                    """INSERT OR IGNORE INTO conflicts(
                           scope_id, mutation_id, evidence_key, path, reason,
                           base_digest, local_digest, remote_generation, staged_path, recorded_at_ns
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (scope_id, row["mutation_id"], f"directory-dependency:{row['mutation_id']}",
                     row["path"], reason, row["base_digest"], row["staged_digest"],
                     row["base_generation"], row["staged_path"], now),
                )
                self._connection.execute(
                    """UPDATE pending_operations
                       SET state = CASE WHEN commit_unknown = 1 THEN 'quarantined' ELSE 'conflict' END,
                           claimed_at_ns = NULL, next_attempt_at_ns = NULL,
                           ready_at_ns = ?, last_error = ?, updated_at_ns = ?
                       WHERE scope_id = ? AND mutation_id = ?""",
                    (now, reason, now, scope_id, row["mutation_id"]),
                )
                self._adjust_direct_dependents(scope_id, str(row["mutation_id"]), delta=-1, now_ns=now)
                for affected_path in paths_of(row):
                    self._connection.execute(
                        """UPDATE materialized_entries SET state = 'conflict', updated_at_ns = ?
                           WHERE scope_id = ? AND path = ?""", (now, scope_id, affected_path),
                    )
            if affected_files:
                self._record_quota_rebuild_locked(scope_id)
        return tuple(DirectoryPut(str(row["path"]), str(row["mutation_id"]),
                                  str(row["kind"]), row["destination_path"],
                                  int(row["created_at_ns"])) for row in affected)

    def complete_directory_put(self, path: str, mutation_id: str) -> bool:
        """Remove only the exact acknowledged mkdir, never a newer incarnation."""
        path, mutation_id = _canonical_path(path), _mutation_id(mutation_id)
        with self._transaction():
            cursor = self._connection.execute(
                """DELETE FROM local_directory_puts
                   WHERE scope_id = ? AND path = ? AND mutation_id = ?""",
                (self._active_scope_id(), path, mutation_id),
            )
        return cursor.rowcount == 1

    def forget_directory_put(self, path: str) -> bool:
        """Cancel a queued mkdir; callers must serialize this with publication."""
        path = _canonical_path(path)
        with self._transaction():
            cursor = self._connection.execute(
                "DELETE FROM local_directory_puts WHERE scope_id = ? AND path = ?",
                (self._active_scope_id(), path),
            )
        return cursor.rowcount == 1

    def get_remote_entry(self, path: str) -> RemoteEntry | None:
        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                "SELECT * FROM remote_entries WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
        return _remote_from_row(row) if row is not None else None

    def fill_remote_entry_blocks_v2(
        self,
        path: str,
        *,
        expected_file_digest: str,
        expected_size_bytes: int,
        blocks: Mapping[str, Any],
    ) -> bool:
        """Attach a lazily fetched v2 block descriptor to an entry that has none.

        Fenced on the exact file identity (path, digest, size) and on the
        descriptor being absent: an entry that already carries one is never
        overwritten here, and a v2 head has no manifest digest to fence on.
        """

        path = _canonical_path(path)
        expected_file_digest = _digest(
            "expected file digest", expected_file_digest, required=True
        )
        if not isinstance(blocks, Mapping):
            raise ValueError("blocks must be a mapping.")
        blocks_json = _blocks_json(blocks)
        if blocks_json is None:
            raise ValueError("blocks must be a mapping.")
        with self._transaction():
            scope_id = self._active_scope_id()
            updated = self._connection.execute(
                """UPDATE remote_entries
                   SET blocks_json = ?
                   WHERE scope_id = ? AND path = ? AND digest = ?
                     AND size_bytes = ? AND blocks_json IS NULL""",
                (blocks_json, scope_id, path, expected_file_digest, int(expected_size_bytes)),
            )
            return updated.rowcount == 1

    def set_remote_entry_blocks(
        self,
        path: str,
        *,
        expected_generation: int,
        expected_manifest_digest: str,
        expected_file_digest: str,
        blocks: Mapping[str, Any],
    ) -> bool:
        """CAS one lazily fetched block map into the exact deferred layout.

        This enriches local read metadata only.  It deliberately does not move
        the remote cursor or create namespace/apply intents. Besides the
        head/path/file digest fence, the completed map must preserve the
        current deferred storage object and every layout parameter. This keeps
        equal file bytes stored under distinct CAS keyspaces from cross-seeding
        one another.
        """

        path = _canonical_path(path)
        expected_generation = _generation(expected_generation)
        expected_manifest_digest = _digest(
            "expected manifest digest", expected_manifest_digest, required=True
        )
        expected_file_digest = _digest(
            "expected file digest", expected_file_digest, required=True
        )
        if not isinstance(blocks, Mapping):
            raise ValueError("blocks must be a mapping.")
        blocks_json = _blocks_json(blocks)
        assert blocks_json is not None
        completed_blocks = json.loads(blocks_json)
        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                """SELECT entry.size_bytes, entry.blocks_json
                   FROM remote_entries AS entry
                   JOIN remote_manifest_heads AS head
                     ON head.scope_id = entry.scope_id
                   WHERE entry.scope_id = ? AND entry.path = ?
                     AND entry.digest = ? AND head.generation = ?
                     AND head.digest = ?""",
                (
                    scope_id,
                    path,
                    expected_file_digest,
                    expected_generation,
                    expected_manifest_digest,
                ),
            ).fetchone()
            if current is None or current["blocks_json"] is None:
                return False
            try:
                deferred_blocks = json.loads(str(current["blocks_json"]))
            except (TypeError, ValueError):
                return False
            if not _block_layout_completion_matches(
                deferred_blocks,
                completed_blocks,
                file_size_bytes=int(current["size_bytes"]),
            ):
                return False
            cursor = self._connection.execute(
                """UPDATE remote_entries
                   SET blocks_json = ?
                   WHERE scope_id = ? AND path = ? AND digest = ?
                     AND size_bytes = ? AND blocks_json = ?
                     AND EXISTS (
                       SELECT 1 FROM remote_manifest_heads AS head
                       WHERE head.scope_id = remote_entries.scope_id
                         AND head.generation = ? AND head.digest = ?
                     )""",
                (
                    blocks_json,
                    scope_id,
                    path,
                    expected_file_digest,
                    int(current["size_bytes"]),
                    str(current["blocks_json"]),
                    expected_generation,
                    expected_manifest_digest,
                ),
            )
        return cursor.rowcount == 1

    def list_remote_entries(
        self, *, prefix: str | None = None, limit: int = 10_000, offset: int = 0
    ) -> tuple[RemoteEntry, ...]:
        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or isinstance(offset, bool)
            or not isinstance(offset, int)
            or not 1 <= limit <= 100_000
            or offset < 0
        ):
            raise ValueError("Invalid remote-entry pagination.")
        canonical_prefix = _canonical_path(prefix) if prefix is not None else None
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if canonical_prefix is None:
                rows = self._connection.execute(
                    """SELECT * FROM remote_entries WHERE scope_id = ?
                       ORDER BY path LIMIT ? OFFSET ?""",
                    (scope_id, limit, offset),
                ).fetchall()
            else:
                descendant_prefix = canonical_prefix + "/"
                # Distributing scope_id into both OR arms lets SQLite resolve
                # each arm through the (scope_id, path) primary key (a
                # MULTI-INDEX OR of two range/point searches) instead of
                # scanning every path in the scope and post-filtering substr.
                #
                # The prefix upper bound is a byte increment and the node pages
                # by codepoint order, so the range and page order are only valid
                # under byte collation. The `path` column is BINARY (proven by
                # test_remote_entries_path_uses_binary_collation), which is
                # exactly byte order for UTF-8, so the bare comparison already
                # is byte-ordered. An explicit `COLLATE BINARY` here is NOT
                # inert: it defeats the MULTI-INDEX OR (the planner falls back
                # to a full SCAN), reintroducing the O(N) cost this rewrite
                # removed. So the invariant is asserted by the collation test
                # instead of forced inline.
                rows = self._connection.execute(
                    """SELECT * FROM remote_entries
                       WHERE (scope_id = ? AND path = ?)
                          OR (scope_id = ? AND path >= ? AND path < ?)
                       ORDER BY path LIMIT ? OFFSET ?""",
                    (
                        scope_id,
                        canonical_prefix,
                        scope_id,
                        descendant_prefix,
                        _prefix_upper_bound(descendant_prefix),
                        limit,
                        offset,
                    ),
                ).fetchall()
        return tuple(_remote_from_row(row) for row in rows)

    def list_remote_children(
        self,
        parent_path: str | None,
        *,
        after_name: str | None = None,
        limit: int = 1_000,
    ) -> tuple[RemoteChild, ...]:
        """Page direct children without materializing the recursive subtree.

        SQLite combines explicit directories with directories synthesized
        from matching file prefixes, so Finder enumeration is
        bounded by the requested child page even for deeply nested workspaces.
        """

        parent = _canonical_path(parent_path) if parent_path is not None else None
        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_REMOTE_MANIFEST_PAGE
        ):
            raise ValueError("limit must be between 1 and 1000")
        if after_name is None:
            after = ""
        else:
            parts = split_relative(after_name)
            if len(parts) != 1:
                raise ValueError("after_name must be one portable path component")
            after = parts[0]
        prefix = "" if parent is None else parent + "/"
        relative_start = len(prefix) + 1
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if parent is None:
                rows = self._connection.execute(
                    """
                    WITH descendants AS (
                      SELECT path AS relative_path, size_bytes, digest, modified
                      FROM remote_entries
                      WHERE scope_id = ?
                      UNION ALL
                      SELECT path AS relative_path, 0, NULL, NULL
                      FROM remote_directories WHERE scope_id = ?
                    ), children AS (
                      SELECT
                        CASE WHEN instr(relative_path, '/') = 0
                             THEN relative_path
                             ELSE substr(relative_path, 1, instr(relative_path, '/') - 1)
                        END AS child_name,
                        instr(relative_path, '/') AS slash,
                        size_bytes, digest, modified
                      FROM descendants
                    )
                    SELECT child_name,
                           MIN(CASE WHEN slash = 0 AND digest IS NOT NULL THEN 1 ELSE 0 END) AS is_file,
                           MAX(CASE WHEN slash = 0 THEN size_bytes END) AS size_bytes,
                           MAX(CASE WHEN slash = 0 THEN digest END) AS digest,
                           MAX(CASE WHEN slash = 0 THEN modified END) AS modified
                    FROM children
                    WHERE child_name > ?
                    GROUP BY child_name
                    ORDER BY child_name
                    LIMIT ?
                    """,
                    (scope_id, scope_id, after, limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """
                    WITH descendants AS (
                      SELECT substr(path, ?) AS relative_path,
                             size_bytes, digest, modified
                      FROM remote_entries
                      -- The prefix upper bound is a byte increment, valid only
                      -- because `path` sorts by byte (BINARY) collation --
                      -- asserted by test_remote_entries_path_uses_binary_collation.
                      -- Bare comparison keeps the (scope_id, path) index range;
                      -- an explicit COLLATE would drop it to a SCAN.
                      WHERE scope_id = ? AND path >= ? AND path < ?
                      UNION ALL
                      SELECT substr(path, ?) AS relative_path, 0, NULL, NULL
                      FROM remote_directories
                      WHERE scope_id = ? AND path >= ? AND path < ?
                    ), children AS (
                      SELECT
                        CASE WHEN instr(relative_path, '/') = 0
                             THEN relative_path
                             ELSE substr(relative_path, 1, instr(relative_path, '/') - 1)
                        END AS child_name,
                        instr(relative_path, '/') AS slash,
                        size_bytes, digest, modified
                      FROM descendants
                    )
                    SELECT child_name,
                           MIN(CASE WHEN slash = 0 AND digest IS NOT NULL THEN 1 ELSE 0 END) AS is_file,
                           MAX(CASE WHEN slash = 0 THEN size_bytes END) AS size_bytes,
                           MAX(CASE WHEN slash = 0 THEN digest END) AS digest,
                           MAX(CASE WHEN slash = 0 THEN modified END) AS modified
                    FROM children
                    WHERE child_name > ?
                    GROUP BY child_name
                    ORDER BY child_name
                    LIMIT ?
                    """,
                    (
                        relative_start,
                        scope_id,
                        prefix,
                        _prefix_upper_bound(prefix),
                        relative_start,
                        scope_id,
                        prefix,
                        _prefix_upper_bound(prefix),
                        after,
                        limit,
                    ),
                ).fetchall()
        result: list[RemoteChild] = []
        for row in rows:
            name = str(row["child_name"])
            path = f"{parent}/{name}" if parent is not None else name
            is_directory = int(row["is_file"]) == 0
            result.append(
                RemoteChild(
                    name=name,
                    path=path,
                    is_directory=is_directory,
                    size_bytes=(0 if is_directory else int(row["size_bytes"])),
                    digest=(None if is_directory else str(row["digest"])),
                    modified=(
                        None
                        if is_directory or row["modified"] is None
                        else str(row["modified"])
                    ),
                )
            )
        return tuple(result)

    def get_remote_entries(self, paths: Iterable[str]) -> tuple[RemoteEntry, ...]:
        normalized = tuple(sorted(set(_canonical_path(path) for path in paths)))
        if len(normalized) > 250_000:
            raise ValueError("At most 250000 remote paths may be read at once.")
        if not normalized:
            return ()
        rows: list[sqlite3.Row] = []
        with self._read_transaction():
            scope_id = self._active_scope_id()
            for start in range(0, len(normalized), 500):
                page = normalized[start : start + 500]
                placeholders = ",".join("?" for _ in page)
                rows.extend(
                    self._connection.execute(
                        f"""SELECT * FROM remote_entries
                            WHERE scope_id = ? AND path IN ({placeholders})""",
                        (scope_id, *page),
                    ).fetchall()
                )
        return tuple(sorted((_remote_from_row(row) for row in rows), key=lambda item: item.path))

    def prefetch_child_resolution(
        self, paths: Sequence[str]
    ) -> tuple[
        dict[str, PendingOperation],
        dict[str, RemoteEntry],
        dict[str, MaterializedEntry],
        frozenset[str],
    ]:
        """Batch the per-path ledgers a directory listing resolves per child.

        A mount ``listdir`` filters visibility by resolving each candidate name,
        which otherwise issues ``get_latest_nonterminal_operation`` +
        ``get_remote_entry`` + ``get_materialized`` per child -- an N+1 that
        re-derives what one page already knew. This returns the same three
        ledgers for a whole child set in a bounded number of queries.

        Every returned value is built with the exact row-builders the singular
        readers use, so a prefetched hit is identical to the corresponding point
        read; the returned key set says which paths were actually looked up, so
        a caller can tell "absent" (path prefetched, no row) from "unknown"
        (path not prefetched) and fall back to a point read on the latter.
        """

        normalized = tuple(dict.fromkeys(_canonical_path(path) for path in paths))
        operations: dict[str, PendingOperation] = {}
        remotes: dict[str, RemoteEntry] = {}
        materialized: dict[str, MaterializedEntry] = {}
        if not normalized:
            return operations, remotes, materialized, frozenset()
        requested = frozenset(normalized)
        with self._read_transaction():
            scope_id = self._active_scope_id()
            for start in range(0, len(normalized), _SQLITE_PATH_BATCH):
                page = normalized[start : start + _SQLITE_PATH_BATCH]
                placeholders = ",".join("?" for _ in page)
                for row in self._connection.execute(
                    f"""SELECT * FROM remote_entries
                        WHERE scope_id = ? AND path IN ({placeholders})""",
                    (scope_id, *page),
                ):
                    entry = _remote_from_row(row)
                    remotes[entry.path] = entry
                for row in self._connection.execute(
                    f"""SELECT * FROM materialized_entries
                        WHERE scope_id = ? AND path IN ({placeholders})""",
                    (scope_id, *page),
                ):
                    entry = _materialized_from_row(row)
                    materialized[entry.path] = entry
                # The latest nonterminal operation for a path is the newest row
                # whose source OR destination equals it. One batched query, then
                # a Python max on journal_seq per affected path -- identical to
                # calling get_latest_nonterminal_operation on each child.
                op_rows = self._connection.execute(
                    f"""SELECT * FROM pending_operations
                        WHERE scope_id = ?
                          AND state IN ('queued', 'inflight', 'retry')
                          AND (path IN ({placeholders})
                               OR destination_path IN ({placeholders}))""",
                    (scope_id, *page, *page),
                ).fetchall()
                page_set = set(page)
                for row in op_rows:
                    journal_seq = int(row["journal_seq"])
                    for affected in (row["path"], row["destination_path"]):
                        if affected is None:
                            continue
                        affected = str(affected)
                        if affected not in page_set:
                            continue
                        current = operations.get(affected)
                        if current is None or journal_seq > current.journal_seq:
                            operations[affected] = _operation_from_row(row)
        return operations, remotes, materialized, requested

    def get_path_states(self, paths: Sequence[str]) -> tuple[FabricPathState, ...]:
        """Read one bounded path page from one consistent WAL snapshot.

        Every distinct requested path is returned in first-occurrence order,
        including paths missing from all three ledgers. Remote block manifests
        are deliberately excluded: startup reconciliation needs descriptor and
        local-state metadata, not potentially multi-megabyte block arrays.
        """

        if isinstance(paths, (str, bytes)) or not isinstance(paths, Sequence):
            raise TypeError("paths must be a bounded sequence of relative paths.")
        if len(paths) > _MAX_PATH_STATE_PAGE:
            raise ValueError(
                f"At most {_MAX_PATH_STATE_PAGE} path states may be read at once."
            )
        normalized = tuple(dict.fromkeys(_canonical_path(path) for path in paths))
        if not normalized:
            return ()
        remotes: dict[str, RemoteEntry] = {}
        materialized: dict[str, MaterializedEntry] = {}
        evictions: dict[str, EvictionIntent] = {}
        with self._read_transaction():
            scope_id = self._active_scope_id()
            for start in range(0, len(normalized), _SQLITE_PATH_BATCH):
                page = normalized[start : start + _SQLITE_PATH_BATCH]
                placeholders = ",".join("?" for _ in page)
                remote_rows = self._connection.execute(
                    f"""SELECT path, size_bytes, digest, modified
                        FROM remote_entries
                        WHERE scope_id = ? AND path IN ({placeholders})""",
                    (scope_id, *page),
                ).fetchall()
                for row in remote_rows:
                    path = str(row["path"])
                    remotes[path] = RemoteEntry(
                        path=path,
                        size_bytes=int(row["size_bytes"]),
                        digest=str(row["digest"]),
                        modified=(
                            str(row["modified"])
                            if row["modified"] is not None
                            else None
                        ),
                        blocks=None,
                    )
                materialized_rows = self._connection.execute(
                    f"""SELECT * FROM materialized_entries
                        WHERE scope_id = ? AND path IN ({placeholders})""",
                    (scope_id, *page),
                ).fetchall()
                for row in materialized_rows:
                    entry = _materialized_from_row(row)
                    materialized[entry.path] = entry
                eviction_rows = self._connection.execute(
                    f"""SELECT * FROM eviction_intents
                        WHERE scope_id = ? AND path IN ({placeholders})""",
                    (scope_id, *page),
                ).fetchall()
                for row in eviction_rows:
                    intent = _eviction_from_row(row)
                    evictions[intent.path] = intent
        return tuple(
            FabricPathState(
                path=path,
                remote=remotes.get(path),
                materialized=materialized.get(path),
                eviction=evictions.get(path),
            )
            for path in normalized
        )

    def enqueue_remote_apply_intents(self, paths: Iterable[str]) -> None:
        """Retain follow-up apply work before its original intent retires."""
        normalized, _renames = _remote_intents(paths, ())
        with self._transaction():
            self._insert_remote_intents(
                self._active_scope_id(), normalized, (), time.time_ns()
            )

    def page_remote_apply_intents(
        self,
        *,
        limit: int = 256,
        after: tuple[int, str] | None = None,
    ) -> tuple[RemoteApplyIntent, ...]:
        """Return one bounded restore page in durable keyset order."""

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_RESTORE_PAGE
        ):
            raise ValueError(f"limit must be between 1 and {_MAX_RESTORE_PAGE}.")
        cursor: tuple[int, str] | None = None
        if after is not None:
            if not isinstance(after, tuple) or len(after) != 2:
                raise ValueError("after must be a (created_at_ns, path) tuple.")
            created_at_ns, path = after
            if (
                isinstance(created_at_ns, bool)
                or not isinstance(created_at_ns, int)
                or created_at_ns < 0
            ):
                raise ValueError("after created_at_ns must be non-negative.")
            cursor = (created_at_ns, _canonical_path(path))
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if cursor is None:
                rows = self._connection.execute(
                    """SELECT path, created_at_ns FROM remote_apply_intents
                       WHERE scope_id = ?
                       ORDER BY created_at_ns, path LIMIT ?""",
                    (scope_id, limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """SELECT path, created_at_ns FROM remote_apply_intents
                       WHERE scope_id = ?
                         AND (created_at_ns, path) > (?, ?)
                       ORDER BY created_at_ns, path LIMIT ?""",
                    (scope_id, *cursor, limit),
                ).fetchall()
        return tuple(
            RemoteApplyIntent(
                path=str(row["path"]), created_at_ns=int(row["created_at_ns"])
            )
            for row in rows
        )

    def page_remote_rename_intents(
        self,
        *,
        limit: int = 256,
        after: tuple[int, str, str] | None = None,
    ) -> tuple[RemoteRenameIntent, ...]:
        """Return one bounded rename-restore page in durable keyset order."""

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_RESTORE_PAGE
        ):
            raise ValueError(f"limit must be between 1 and {_MAX_RESTORE_PAGE}.")
        cursor: tuple[int, str, str] | None = None
        if after is not None:
            if not isinstance(after, tuple) or len(after) != 3:
                raise ValueError(
                    "after must be a (created_at_ns, source_path, destination_path) tuple."
                )
            created_at_ns, source, destination = after
            if (
                isinstance(created_at_ns, bool)
                or not isinstance(created_at_ns, int)
                or created_at_ns < 0
            ):
                raise ValueError("after created_at_ns must be non-negative.")
            cursor = (
                created_at_ns,
                _canonical_path(source),
                _canonical_path(destination),
            )
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if cursor is None:
                rows = self._connection.execute(
                    """SELECT source_path, destination_path, digest,
                              size_bytes, created_at_ns
                       FROM remote_rename_intents WHERE scope_id = ?
                       ORDER BY created_at_ns, source_path, destination_path
                       LIMIT ?""",
                    (scope_id, limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """SELECT source_path, destination_path, digest,
                              size_bytes, created_at_ns
                       FROM remote_rename_intents WHERE scope_id = ?
                         AND (created_at_ns, source_path, destination_path)
                             > (?, ?, ?)
                       ORDER BY created_at_ns, source_path, destination_path
                       LIMIT ?""",
                    (scope_id, *cursor, limit),
                ).fetchall()
        return tuple(_remote_rename_from_row(row) for row in rows)

    def list_remote_apply_intents(
        self, *, limit: int = 100_000, materialized_first: bool = False
    ) -> tuple[str, ...]:
        """Restore applies, optionally putting visible working-set work first.

        Unpinned clean rows without bytes or a stat baseline are speculative hydration
        reservations. Ordering those last does not rewrite durable intent keys
        or change the published head used to validate the eventual apply.
        """
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if materialized_first:
                rows = self._connection.execute(
                    """SELECT intent.path FROM remote_apply_intents AS intent
                       LEFT JOIN materialized_entries AS materialized
                         ON materialized.scope_id = intent.scope_id
                        AND materialized.path = intent.path
                       LEFT JOIN remote_entries AS remote
                         ON remote.scope_id = intent.scope_id
                        AND remote.path = intent.path
                       WHERE intent.scope_id = ?
                       ORDER BY CASE WHEN materialized.state = 'clean'
                                      AND materialized.pinned = 0
                                      AND materialized.stat_fingerprint IS NULL
                                      AND materialized.bytes_on_disk = 0
                                      AND materialized.clean_digest = remote.digest
                                     THEN 1 ELSE 0 END,
                                intent.created_at_ns, intent.path
                       LIMIT ?""",
                    (scope_id, limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """SELECT path FROM remote_apply_intents WHERE scope_id = ?
                       ORDER BY created_at_ns, path LIMIT ?""",
                    (scope_id, limit),
                ).fetchall()
        return tuple(str(row["path"]) for row in rows)

    def list_remote_rename_intents(
        self, *, limit: int = 100_000
    ) -> tuple[RemoteRenameIntent, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT * FROM remote_rename_intents WHERE scope_id = ?
                   ORDER BY created_at_ns, source_path, destination_path LIMIT ?""",
                (scope_id, limit),
            ).fetchall()
        return tuple(_remote_rename_from_row(row) for row in rows)

    def has_pending_remote_intents(self) -> tuple[bool, bool]:
        """Return durable apply/rename readiness without consuming a page.

        Manifest commit counters describe work inserted by that commit. This
        constant-result LIMIT-1 probe preserves a prior keyset tail when a
        later no-op refresh inserts nothing between restore/drain turns.
        """

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT
                     EXISTS(
                       SELECT 1 FROM remote_apply_intents
                       WHERE scope_id = ? LIMIT 1
                     ) AS has_apply,
                     EXISTS(
                       SELECT 1 FROM remote_rename_intents
                       WHERE scope_id = ? LIMIT 1
                     ) AS has_rename""",
                (scope_id, scope_id),
            ).fetchone()
        assert row is not None
        return bool(row["has_apply"]), bool(row["has_rename"])

    def has_remote_apply_intent(self, path: str) -> bool:
        """Probe one active-scope apply owner through its composite primary key."""

        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT 1 FROM remote_apply_intents
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, path),
            ).fetchone()
        return row is not None

    def complete_remote_apply_intent(self, path: str) -> bool:
        path = _canonical_path(path)
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                "DELETE FROM remote_apply_intents WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            )
        return cursor.rowcount == 1

    def complete_remote_rename_intent(self, source: str, destination: str) -> bool:
        source = _canonical_path(source)
        destination = _canonical_path(destination)
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                """DELETE FROM remote_rename_intents
                   WHERE scope_id = ? AND source_path = ? AND destination_path = ?""",
                (scope_id, source, destination),
            )
        return cursor.rowcount == 1

    # ---------------------------------------------------------- materialization

    def mark_materialized(
        self,
        path: str,
        *,
        state: MaterializationState | str,
        clean_digest: str | None = None,
        stat_fingerprint: str | None = None,
        bytes_on_disk: int | None = None,
        pinned: bool | None = None,
        accessed_at_ns: int | None = None,
        remote_verified: bool | None = None,
        queue_remote_apply: bool = False,
        content_sha256: str | None = None,
        clean_digest_algorithm: str | None = None,
    ) -> MaterializedEntry:
        path = _canonical_path(path)
        if state not in _MATERIALIZATION_STATES:
            raise ValueError(f"Unknown materialization state {state!r}.")
        clean_digest = _digest("clean digest", clean_digest)
        content_sha256 = _digest("content sha256", content_sha256)
        if clean_digest_algorithm is not None:
            file_digest_algorithm({"file_digest_algorithm": clean_digest_algorithm})
        if bytes_on_disk is not None and (
            isinstance(bytes_on_disk, bool)
            or not isinstance(bytes_on_disk, int)
            or bytes_on_disk < 0
        ):
            raise ValueError("bytes_on_disk must be non-negative.")
        if stat_fingerprint is not None:
            stat_fingerprint = _bounded_text("stat_fingerprint", stat_fingerprint, 4_096)
        now = time.time_ns()
        accessed = accessed_at_ns if accessed_at_ns is not None else now
        if isinstance(accessed, bool) or not isinstance(accessed, int) or accessed < 0:
            raise ValueError("accessed_at_ns must be non-negative.")

        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                "SELECT * FROM materialized_entries WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
            actual_pinned = bool(current["pinned"]) if pinned is None and current else bool(pinned)
            actual_clean_digest = (
                clean_digest
                if clean_digest is not None
                else (
                    str(current["clean_digest"])
                    if current is not None and current["clean_digest"] is not None
                    else None
                )
            )
            actual_bytes = (
                int(current["bytes_on_disk"])
                if bytes_on_disk is None and current
                else int(bytes_on_disk or 0)
            )
            # The proof is about specific bytes, so it does not survive a
            # digest change: verified content that is then edited locally is
            # unverified content again. Carrying it forward across an edit is
            # exactly how a caller would accidentally authorise deleting the
            # only copy of the new bytes.
            previous_digest = (
                str(current["clean_digest"])
                if current is not None and current["clean_digest"] is not None
                else None
            )
            if remote_verified is not None:
                actual_remote_verified = bool(remote_verified)
            elif (
                current is not None
                and actual_clean_digest is not None
                and actual_clean_digest == previous_digest
            ):
                actual_remote_verified = bool(current["remote_verified"])
            else:
                actual_remote_verified = False
            if state == "clean" and actual_clean_digest is None:
                raise ValueError("A clean materialization requires its synced digest.")
            if state == "absent":
                actual_bytes = 0
                stat_fingerprint = None
            remote = self._connection.execute(
                "SELECT blocks_json FROM remote_entries WHERE scope_id = ? AND path = ? AND digest = ?",
                (scope_id, path, actual_clean_digest),
            ).fetchone()
            clean_algorithm = (
                clean_digest_algorithm if clean_digest_algorithm is not None else
                file_digest_algorithm(json.loads(remote["blocks_json"]))
                if remote is not None and remote["blocks_json"] is not None
                else str(current["clean_digest_algorithm"])
                if current is not None and actual_clean_digest == previous_digest
                else "sha256"
            )
            if (remote is not None and remote["blocks_json"] is not None
                    and clean_algorithm != file_digest_algorithm(json.loads(remote["blocks_json"]))):
                raise ValueError("The clean file algorithm does not match the remote identity.")
            root_identity = clean_algorithm != "sha256"
            actual_content_sha256 = content_sha256
            if actual_content_sha256 is None:
                if current is not None and actual_clean_digest == previous_digest:
                    actual_content_sha256 = current["content_sha256"]
                if actual_content_sha256 is None and not root_identity:
                    actual_content_sha256 = actual_clean_digest
            if (state == "clean" and stat_fingerprint is not None
                    and actual_content_sha256 is None):
                raise ValueError("A clean local file requires its actual content checksum.")
            if (state == "clean" and not root_identity and actual_content_sha256 is not None
                    and actual_content_sha256 != actual_clean_digest):
                raise ValueError("The clean content checksum does not match the flat file identity.")
            self._connection.execute(
                """INSERT INTO materialized_entries(
                       scope_id, path, state, pinned, clean_digest,
                       stat_fingerprint, bytes_on_disk, accessed_at_ns,
                       updated_at_ns, remote_verified
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(scope_id, path) DO UPDATE SET
                       state = excluded.state,
                       pinned = excluded.pinned,
                       clean_digest = excluded.clean_digest,
                       stat_fingerprint = excluded.stat_fingerprint,
                       bytes_on_disk = excluded.bytes_on_disk,
                       accessed_at_ns = excluded.accessed_at_ns,
                       updated_at_ns = excluded.updated_at_ns,
                       remote_verified = excluded.remote_verified""",
                (
                    scope_id,
                    path,
                    state,
                    int(actual_pinned),
                    actual_clean_digest,
                    stat_fingerprint,
                    actual_bytes,
                    accessed,
                    now,
                    int(actual_remote_verified),
                ),
            )
            self._connection.execute(
                "UPDATE materialized_entries SET content_sha256 = ?, clean_digest_algorithm = ? WHERE scope_id = ? AND path = ?",
                (actual_content_sha256, clean_algorithm, scope_id, path),
            )
            row = self._connection.execute(
                "SELECT * FROM materialized_entries WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
            if queue_remote_apply:
                # A new reservation is not a completed cache copy. Retain its
                # apply in the same transaction so restart and directory-overlay
                # retirement cannot mistake an in-memory queue for completion.
                self._insert_remote_intents(scope_id, (path,), (), now)
        assert row is not None
        return _materialized_from_row(row)

    def get_materialized(self, path: str) -> MaterializedEntry | None:
        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                "SELECT * FROM materialized_entries WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
        return _materialized_from_row(row) if row is not None else None

    def list_materialized_entries(
        self,
        *,
        states: Sequence[MaterializationState | str] | None = None,
        limit: int = 1_000,
        offset: int = 0,
        after_path: str | None = None,
    ) -> tuple[MaterializedEntry, ...]:
        """Page the local working-set ledger independently of remote sort order."""

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= 100_000
            or isinstance(offset, bool)
            or not isinstance(offset, int)
            or offset < 0
        ):
            raise ValueError("Materialization pagination is outside the allowed range.")
        if after_path is not None:
            after_path = _canonical_path(after_path)
            if offset:
                raise ValueError("after_path cannot be combined with a nonzero offset.")
        normalized = tuple(states or ())
        if any(state not in _MATERIALIZATION_STATES for state in normalized):
            raise ValueError("Unknown materialization state filter.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if normalized:
                placeholders = ",".join("?" for _ in normalized)
                if after_path is None:
                    rows = self._connection.execute(
                        f"""SELECT * FROM materialized_entries
                            WHERE scope_id = ? AND state IN ({placeholders})
                            ORDER BY path LIMIT ? OFFSET ?""",
                        (scope_id, *normalized, limit, offset),
                    ).fetchall()
                else:
                    rows = self._connection.execute(
                        f"""SELECT * FROM materialized_entries
                            WHERE scope_id = ? AND state IN ({placeholders})
                              AND path > ?
                            ORDER BY path LIMIT ?""",
                        (scope_id, *normalized, after_path, limit),
                    ).fetchall()
            else:
                if after_path is None:
                    rows = self._connection.execute(
                        """SELECT * FROM materialized_entries WHERE scope_id = ?
                           ORDER BY path LIMIT ? OFFSET ?""",
                        (scope_id, limit, offset),
                    ).fetchall()
                else:
                    rows = self._connection.execute(
                        """SELECT * FROM materialized_entries
                           WHERE scope_id = ? AND path > ?
                           ORDER BY path LIMIT ?""",
                        (scope_id, after_path, limit),
                    ).fetchall()
        return tuple(_materialized_from_row(row) for row in rows)

    def working_set_reservation(self) -> tuple[int, int]:
        """Return clean unpinned entry count and pending-hydration bytes."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT COUNT(*) AS count,
                          COALESCE(SUM(
                            CASE WHEN materialized.bytes_on_disk = 0
                                      AND materialized.stat_fingerprint IS NULL
                                 THEN COALESCE(remote.size_bytes, 0) ELSE 0 END
                          ), 0) AS reserved_bytes
                   FROM materialized_entries AS materialized
                   LEFT JOIN remote_entries AS remote
                     ON remote.scope_id = materialized.scope_id
                    AND remote.path = materialized.path
                   WHERE materialized.scope_id = ?
                     AND materialized.state = 'clean'
                     AND materialized.pinned = 0""",
                (scope_id,),
            ).fetchone()
        assert row is not None
        return int(row["count"]), int(row["reserved_bytes"])

    def filter_materialized_paths(
        self, paths: Iterable[str], *, speculative_only: bool = False
    ) -> tuple[str, ...]:
        """Return touched paths that currently belong to the local working set."""

        normalized = tuple(sorted(set(_canonical_path(path) for path in paths)))
        if len(normalized) > 250_000:
            raise ValueError("At most 250000 materialized paths may be filtered at once.")
        if not normalized:
            return ()
        selected: list[str] = []
        speculative_filter = (
            "AND state = 'clean' AND pinned = 0 AND stat_fingerprint IS NULL AND bytes_on_disk = 0"
            " AND EXISTS (SELECT 1 FROM remote_entries AS remote"
            " WHERE remote.scope_id = materialized_entries.scope_id"
            " AND remote.path = materialized_entries.path"
            " AND remote.digest = materialized_entries.clean_digest)"
            if speculative_only else ""
        )
        with self._read_transaction():
            scope_id = self._active_scope_id()
            for start in range(0, len(normalized), 500):
                page = normalized[start : start + 500]
                placeholders = ",".join("?" for _ in page)
                rows = self._connection.execute(
                    f"""SELECT path FROM materialized_entries
                        WHERE scope_id = ? AND state != 'absent'
                          {speculative_filter}
                          AND path IN ({placeholders})""",
                    (scope_id, *page),
                ).fetchall()
                selected.extend(str(row["path"]) for row in rows)
        return tuple(sorted(selected))

    def touch_materialized(self, path: str, *, accessed_at_ns: int | None = None) -> bool:
        path = _canonical_path(path)
        stamp = accessed_at_ns if accessed_at_ns is not None else time.time_ns()
        if isinstance(stamp, bool) or not isinstance(stamp, int) or stamp < 0:
            raise ValueError("accessed_at_ns must be non-negative.")
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                """UPDATE materialized_entries SET accessed_at_ns = ?
                   WHERE scope_id = ? AND path = ?""",
                (stamp, scope_id, path),
            )
        return cursor.rowcount == 1

    def set_pinned(self, path: str, pinned: bool) -> MaterializedEntry:
        path = _canonical_path(path)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            self._connection.execute(
                """INSERT INTO materialized_entries(
                       scope_id, path, state, pinned, bytes_on_disk,
                       accessed_at_ns, updated_at_ns
                   ) VALUES (?, ?, 'absent', ?, 0, ?, ?)
                   ON CONFLICT(scope_id, path) DO UPDATE SET
                       pinned = excluded.pinned, updated_at_ns = excluded.updated_at_ns""",
                (scope_id, path, int(bool(pinned)), now, now),
            )
            row = self._connection.execute(
                "SELECT * FROM materialized_entries WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
        assert row is not None
        return _materialized_from_row(row)

    def free_candidates(
        self,
        *,
        limit: int = 1_000,
        bytes_needed: int | None = None,
        exclude_path: str | None = None,
        exclude_paths: Iterable[str] | None = None,
        not_accessed_since_ns: int | None = None,
    ) -> tuple[MaterializedEntry, ...]:
        """Return oldest clean, unpinned files eligible for cache eviction.

        Re-fetchability is proven twice over, because getting this wrong
        deletes the only copy of a user's bytes:

        1. ``remote_verified`` -- first-hand evidence that THIS node either
           streamed these exact bytes back out of object storage, or uploaded
           them and watched the provider confirm every block by HEAD. A commit
           receipt alone is explicitly not enough: it says the control plane
           recorded the entry, not that the objects exist. Rows predating this
           column default to 0 and are never evicted until re-proven.
        2. The remote manifest still holds this same path at this same digest,
           so the proof from (1) is about the bytes the manifest points at now
           and not about a superseded version.

        Dirty, staging, conflicted, and pinned rows are excluded by state, and
        a path with a pending remote apply is excluded because the apply lane
        jointly owns its visible preimage.
        """
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        if bytes_needed is not None and (
            isinstance(bytes_needed, bool)
            or not isinstance(bytes_needed, int)
            or bytes_needed < 0
        ):
            raise ValueError("bytes_needed must be non-negative.")
        if not_accessed_since_ns is not None and (
            isinstance(not_accessed_since_ns, bool)
            or not isinstance(not_accessed_since_ns, int)
            or not_accessed_since_ns < 0
        ):
            raise ValueError("not_accessed_since_ns must be non-negative.")
        requested: list[str] = []
        if exclude_path is not None:
            requested.append(exclude_path)
        if exclude_paths is not None:
            requested.extend(exclude_paths)
        excluded = sorted({_canonical_path(path) for path in requested})
        if len(excluded) > 100:
            raise ValueError("At most 100 paths may be excluded at once.")
        idle_filter = (
            "AND materialized_entries.accessed_at_ns < ?"
            if not_accessed_since_ns is not None
            else ""
        )
        idle_parameters = (
            (not_accessed_since_ns,) if not_accessed_since_ns is not None else ()
        )
        placeholders = ",".join("?" for _ in excluded)
        exclusion = (
            f"AND materialized_entries.path NOT IN ({placeholders})"
            if excluded
            else ""
        )
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                f"""SELECT * FROM materialized_entries
                   WHERE materialized_entries.scope_id = ?
                         AND materialized_entries.state = 'clean'
                         AND materialized_entries.pinned = 0
                         AND materialized_entries.bytes_on_disk > 0
                         {exclusion}
                         {idle_filter}
                         AND materialized_entries.remote_verified = 1
                         AND EXISTS (
                           SELECT 1 FROM remote_entries AS remote
                           WHERE remote.scope_id = materialized_entries.scope_id
                             AND remote.path = materialized_entries.path
                             AND remote.digest = materialized_entries.clean_digest
                         )
                         AND NOT EXISTS (
                           SELECT 1 FROM remote_apply_intents AS apply
                           WHERE apply.scope_id = materialized_entries.scope_id
                             AND apply.path = materialized_entries.path
                         )
                   ORDER BY materialized_entries.accessed_at_ns ASC,
                            materialized_entries.path ASC LIMIT ?""",
                (scope_id, *excluded, *idle_parameters, limit),
            ).fetchall()
        candidates = [_materialized_from_row(row) for row in rows]
        if bytes_needed is None:
            return tuple(candidates)
        chosen: list[MaterializedEntry] = []
        freed = 0
        for item in candidates:
            if freed >= bytes_needed:
                break
            chosen.append(item)
            freed += item.bytes_on_disk
        return tuple(chosen)

    def mark_evicted(self, path: str) -> MaterializedEntry:
        current = self.get_materialized(path)
        if current is None:
            raise StateError(f"No materialization exists for {path!r}.")
        if current.pinned or current.state != "clean":
            raise StateError("Only clean, unpinned materializations may be evicted.")
        return self.mark_materialized(
            path,
            state="absent",
            pinned=False,
            clean_digest=current.clean_digest,
            stat_fingerprint=None,
            bytes_on_disk=0,
            accessed_at_ns=current.accessed_at_ns,
        )

    def begin_eviction(
        self,
        path: str,
        *,
        observed_clean_digest: str,
        observed_stat_fingerprint: str,
        observed_bytes: int,
        observed_content_sha256: str | None = None,
    ) -> EvictionIntent | None:
        """Persist an exact clean-file eviction intent before removing bytes.

        This is a compare-and-swap against the materialization's clean digest,
        byte count, state and pin.  A stored fingerprint, when present, must
        also match the just-hashed file.  Returning ``None`` means the caller's
        observation lost a race and no namespace mutation is authorized.
        """

        path = _canonical_path(path)
        observed_clean_digest = _digest(
            "observed clean digest", observed_clean_digest, required=True
        )
        observed_content_sha256 = _digest(
            "observed content sha256", observed_content_sha256 or observed_clean_digest, required=True
        )
        observed_stat_fingerprint = _bounded_text(
            "observed_stat_fingerprint", observed_stat_fingerprint, 4_096
        )
        if (
            isinstance(observed_bytes, bool)
            or not isinstance(observed_bytes, int)
            or observed_bytes < 0
        ):
            raise ValueError("observed_bytes must be non-negative.")
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                "SELECT * FROM materialized_entries WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
            if (
                current is None
                or current["state"] != "clean"
                or bool(current["pinned"])
                or current["clean_digest"] != observed_clean_digest
                or current["content_sha256"] != observed_content_sha256
                or int(current["bytes_on_disk"]) != observed_bytes
                or (
                    current["stat_fingerprint"] is not None
                    and current["stat_fingerprint"] != observed_stat_fingerprint
                )
            ):
                return None
            existing = self._connection.execute(
                "SELECT * FROM eviction_intents WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
            if existing is not None:
                if (
                    existing["expected_clean_digest"] == observed_clean_digest
                    and existing["expected_content_sha256"] == observed_content_sha256
                    and existing["expected_stat_fingerprint"]
                    == observed_stat_fingerprint
                    and int(existing["expected_bytes"]) == observed_bytes
                ):
                    return _eviction_from_row(existing)
                return None
            eviction_id = str(uuid.uuid4())
            self._connection.execute(
                """INSERT INTO eviction_intents(
                       scope_id, eviction_id, path, expected_clean_digest,
                       expected_stat_fingerprint, expected_bytes, created_at_ns,
                       expected_content_sha256
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    scope_id,
                    eviction_id,
                    path,
                    observed_clean_digest,
                    observed_stat_fingerprint,
                    observed_bytes,
                    now,
                    observed_content_sha256,
                ),
            )
            # Upgrade legacy clean rows that predate fingerprint tracking.  The
            # exact observed fingerprint is now part of the durable CAS proof.
            self._connection.execute(
                """UPDATE materialized_entries
                   SET stat_fingerprint = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ?""",
                (observed_stat_fingerprint, now, scope_id, path),
            )
            row = self._connection.execute(
                "SELECT * FROM eviction_intents WHERE eviction_id = ?",
                (eviction_id,),
            ).fetchone()
        assert row is not None
        return _eviction_from_row(row)

    def list_eviction_intents(self, *, limit: int = 10_000) -> tuple[EvictionIntent, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT * FROM eviction_intents WHERE scope_id = ?
                   ORDER BY created_at_ns, path LIMIT ?""",
                (scope_id, limit),
            ).fetchall()
        return tuple(_eviction_from_row(row) for row in rows)

    def has_eviction_intent(self, path: str) -> bool:
        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                "SELECT 1 FROM eviction_intents WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
        return row is not None

    def cancel_eviction(self, eviction_id: str) -> bool:
        eviction_id = _mutation_id(eviction_id)
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                "DELETE FROM eviction_intents WHERE scope_id = ? AND eviction_id = ?",
                (scope_id, eviction_id),
            )
        return cursor.rowcount == 1

    def complete_eviction(self, eviction_id: str) -> MaterializedEntry:
        """Atomically finalize one persisted eviction as remote-only."""

        eviction_id = _mutation_id(eviction_id)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            intent = self._connection.execute(
                """SELECT * FROM eviction_intents
                   WHERE scope_id = ? AND eviction_id = ?""",
                (scope_id, eviction_id),
            ).fetchone()
            if intent is None:
                raise StateError("The eviction intent is not in the active authority epoch.")
            cursor = self._connection.execute(
                """UPDATE materialized_entries
                   SET state = 'absent', pinned = 0, stat_fingerprint = NULL,
                       bytes_on_disk = 0, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ? AND state = 'clean'
                         AND pinned = 0 AND clean_digest = ?
                         AND bytes_on_disk = ? AND stat_fingerprint = ?
                         AND content_sha256 = ?""",
                (
                    now,
                    scope_id,
                    intent["path"],
                    intent["expected_clean_digest"],
                    intent["expected_bytes"],
                    intent["expected_stat_fingerprint"],
                    intent["expected_content_sha256"],
                ),
            )
            if cursor.rowcount != 1:
                raise StateError("The clean materialization changed during eviction.")
            self._connection.execute(
                "DELETE FROM eviction_intents WHERE eviction_id = ?", (eviction_id,)
            )
            row = self._connection.execute(
                "SELECT * FROM materialized_entries WHERE scope_id = ? AND path = ?",
                (scope_id, intent["path"]),
            ).fetchone()
        assert row is not None
        return _materialized_from_row(row)

    def rebase_local_metadata_fingerprint(
        self,
        path: str,
        *,
        expected_fingerprint: str,
        current_fingerprint: str,
    ) -> bool:
        """CAS-advance byte-neutral local metadata across durable owners.

        The coordinator calls this only after a mounted metadata operation has
        pinned one inode and proved that its byte-visible identity did not
        change.  Keeping the materialization and any pre-journal transfer
        intent in one transaction prevents restart from assigning two
        different source fingerprints to the same local snapshot.

        A matching current value is an idempotent replay.  Any third value is
        a newer local state and fails closed instead of blessing it as
        metadata-only.
        """

        path = _canonical_path(path)
        expected_fingerprint = _bounded_text(
            "expected_fingerprint", expected_fingerprint, 4_096
        )
        current_fingerprint = _bounded_text(
            "current_fingerprint", current_fingerprint, 4_096
        )
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            materialized = self._connection.execute(
                """SELECT state, stat_fingerprint FROM materialized_entries
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, path),
            ).fetchone()
            intent = self._connection.execute(
                """SELECT source_fingerprint FROM local_transfer_intents
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, path),
            ).fetchone()

            owns_materialization = materialized is not None and materialized[
                "stat_fingerprint"
            ] in (expected_fingerprint, current_fingerprint)
            owns_transfer = intent is not None and intent[
                "source_fingerprint"
            ] in (expected_fingerprint, current_fingerprint)
            if materialized is not None and (
                materialized["state"] in ("absent", "conflict")
                or not owns_materialization
            ):
                raise StateError(
                    "The local materialization changed before metadata acknowledgement."
                )
            if intent is not None and not owns_transfer:
                raise StateError(
                    "The local transfer changed before metadata acknowledgement."
                )
            if not owns_materialization and not owns_transfer:
                return False
            if owns_transfer:
                _local_transfer_source_size(current_fingerprint)

            self._connection.execute(
                """UPDATE materialized_entries
                   SET stat_fingerprint = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ? AND stat_fingerprint = ?""",
                (
                    current_fingerprint,
                    now,
                    scope_id,
                    path,
                    expected_fingerprint,
                ),
            )
            self._connection.execute(
                """UPDATE local_transfer_intents
                   SET source_fingerprint = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ? AND source_fingerprint = ?""",
                (
                    current_fingerprint,
                    now,
                    scope_id,
                    path,
                    expected_fingerprint,
                ),
            )
        return True

    # --------------------------------------------------------- local transfers

    def begin_local_transfer_intent(
        self,
        *,
        transfer_id: str,
        path: str,
        source_fingerprint: str,
        expected_remote_digest: str | None = None,
        delete_after_ack_path: str | None = None,
        delete_after_ack_digest: str | None = None,
        delete_mutation_id: str | None = None,
        issue_code: str | None = None,
        issue_size_bytes: int | None = None,
    ) -> LocalTransferIntent:
        """Fence watcher acknowledgement behind durable snapshot metadata.

        ``transfer_id`` is also suitable as the later put mutation UUID.  When
        a content-changing rename needs a source delete, the returned
        ``delete_mutation_id`` makes that second enqueue idempotent across a
        crash between enqueue and intent cleanup.
        """

        transfer_id = _mutation_id(transfer_id)
        path = _canonical_path(path)
        source_fingerprint = _bounded_text(
            "source_fingerprint", source_fingerprint, 4_096
        )
        expected_remote_digest = _digest(
            "expected remote digest", expected_remote_digest
        )
        issue_code, issue_size_bytes = _local_transfer_issue(
            issue_code, issue_size_bytes
        )
        if (delete_after_ack_path is None) != (delete_after_ack_digest is None):
            raise ValueError(
                "delete_after_ack_path and delete_after_ack_digest must be supplied together."
            )
        if delete_after_ack_path is not None:
            delete_after_ack_path = _canonical_path(delete_after_ack_path)
            delete_after_ack_digest = _digest(
                "delete-after-ack digest", delete_after_ack_digest, required=True
            )
            supplied_delete_mutation_id = delete_mutation_id is not None
            if delete_mutation_id is not None:
                delete_mutation_id = _mutation_id(delete_mutation_id)
        elif delete_mutation_id is not None:
            raise ValueError("delete_mutation_id requires a delete-after-ack path.")
        else:
            supplied_delete_mutation_id = False
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            self._require_authority_adopted(scope_id)
            _local_transfer_source_size(source_fingerprint)
            existing = self._connection.execute(
                "SELECT * FROM local_transfer_intents WHERE transfer_id = ?",
                (transfer_id,),
            ).fetchone()
            if existing is not None:
                candidate = _local_transfer_from_row(existing)
                if (
                    candidate.scope_id != scope_id
                    or candidate.path != path
                    or candidate.source_fingerprint != source_fingerprint
                    or candidate.expected_remote_digest != expected_remote_digest
                    or candidate.delete_after_ack_path != delete_after_ack_path
                    or candidate.delete_after_ack_digest != delete_after_ack_digest
                    or candidate.issue_code != issue_code
                    or candidate.issue_size_bytes != issue_size_bytes
                    or (
                        supplied_delete_mutation_id
                        and candidate.delete_mutation_id != delete_mutation_id
                    )
                ):
                    raise StateError("A transfer UUID cannot identify two local snapshots.")
                return candidate
            if delete_after_ack_path is not None and delete_mutation_id is None:
                delete_mutation_id = _mutation_id(None)
            try:
                self._connection.execute(
                    """INSERT INTO local_transfer_intents(
                           scope_id, transfer_id, path, source_fingerprint,
                           expected_remote_digest, delete_after_ack_path,
                           delete_after_ack_digest, delete_mutation_id,
                           issue_code, issue_size_bytes,
                           created_at_ns, updated_at_ns
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        scope_id,
                        transfer_id,
                        path,
                        source_fingerprint,
                        expected_remote_digest,
                        delete_after_ack_path,
                        delete_after_ack_digest,
                        delete_mutation_id,
                        issue_code,
                        issue_size_bytes,
                        now,
                        now,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise StateError(
                    "A local snapshot transfer is already active for this path."
                ) from error
            row = self._connection.execute(
                "SELECT * FROM local_transfer_intents WHERE transfer_id = ?",
                (transfer_id,),
            ).fetchone()
        assert row is not None
        return _local_transfer_from_row(row)

    def supersede_local_transfer_intent(
        self,
        expected_transfer_id: str,
        *,
        transfer_id: str,
        path: str,
        source_fingerprint: str,
        expected_remote_digest: str | None = None,
        delete_after_ack_path: str | None = None,
        delete_after_ack_digest: str | None = None,
        delete_mutation_id: str | None = None,
        issue_code: str | None = None,
        issue_size_bytes: int | None = None,
    ) -> LocalTransferIntent:
        """CAS-replace a drifted local snapshot intent without a durable gap.

        The first caller matching ``expected_transfer_id`` wins.  Retrying the
        exact winning replacement after an uncertain commit is idempotent;
        another replacement racing from the stale predecessor fails closed.
        """

        expected_transfer_id = _mutation_id(expected_transfer_id)
        transfer_id = _mutation_id(transfer_id)
        if transfer_id == expected_transfer_id:
            raise ValueError("A superseding transfer must use a new UUID.")
        path = _canonical_path(path)
        source_fingerprint = _bounded_text(
            "source_fingerprint", source_fingerprint, 4_096
        )
        expected_remote_digest = _digest(
            "expected remote digest", expected_remote_digest
        )
        issue_code, issue_size_bytes = _local_transfer_issue(
            issue_code, issue_size_bytes
        )
        if (delete_after_ack_path is None) != (delete_after_ack_digest is None):
            raise ValueError(
                "delete_after_ack_path and delete_after_ack_digest must be supplied together."
            )
        supplied_delete_mutation_id = delete_mutation_id is not None
        if delete_after_ack_path is not None:
            delete_after_ack_path = _canonical_path(delete_after_ack_path)
            delete_after_ack_digest = _digest(
                "delete-after-ack digest", delete_after_ack_digest, required=True
            )
            if delete_mutation_id is not None:
                delete_mutation_id = _mutation_id(delete_mutation_id)
        elif delete_mutation_id is not None:
            raise ValueError("delete_mutation_id requires a delete-after-ack path.")
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            self._require_authority_adopted(scope_id)
            _local_transfer_source_size(source_fingerprint)
            current = self._connection.execute(
                """SELECT * FROM local_transfer_intents
                   WHERE scope_id = ? AND path = ? AND transfer_id = ?""",
                (scope_id, path, expected_transfer_id),
            ).fetchone()
            if current is None:
                # The connection may have dropped after COMMIT.  Recognize only
                # the exact requested winner; a different winner remains a
                # genuine stale-CAS failure.
                existing_winner = self._connection.execute(
                    """SELECT * FROM local_transfer_intents
                       WHERE transfer_id = ? AND scope_id = ?""",
                    (transfer_id, scope_id),
                ).fetchone()
                if existing_winner is not None:
                    candidate = _local_transfer_from_row(existing_winner)
                    if (
                        candidate.path == path
                        and candidate.source_fingerprint == source_fingerprint
                        and candidate.expected_remote_digest == expected_remote_digest
                        and candidate.delete_after_ack_path == delete_after_ack_path
                        and candidate.delete_after_ack_digest
                        == delete_after_ack_digest
                        and candidate.issue_code == issue_code
                        and candidate.issue_size_bytes == issue_size_bytes
                        and (
                            not supplied_delete_mutation_id
                            or candidate.delete_mutation_id == delete_mutation_id
                        )
                    ):
                        return candidate
                raise StateError(
                    "The local transfer intent changed before it could be superseded."
                )
            if delete_after_ack_path is not None and delete_mutation_id is None:
                delete_mutation_id = _mutation_id(None)
            try:
                cursor = self._connection.execute(
                    """UPDATE local_transfer_intents
                       SET transfer_id = ?, source_fingerprint = ?,
                           expected_remote_digest = ?, delete_after_ack_path = ?,
                           delete_after_ack_digest = ?, delete_mutation_id = ?,
                           issue_code = ?, issue_size_bytes = ?,
                           created_at_ns = ?, updated_at_ns = ?
                       WHERE scope_id = ? AND path = ? AND transfer_id = ?""",
                    (
                        transfer_id,
                        source_fingerprint,
                        expected_remote_digest,
                        delete_after_ack_path,
                        delete_after_ack_digest,
                        delete_mutation_id,
                        issue_code,
                        issue_size_bytes,
                        now,
                        now,
                        scope_id,
                        path,
                        expected_transfer_id,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise StateError(
                    "The superseding transfer UUID is already in use."
                ) from error
            if cursor.rowcount != 1:  # pragma: no cover - IMMEDIATE transaction fences this
                raise StateError(
                    "The local transfer intent changed before it could be superseded."
                )
            row = self._connection.execute(
                "SELECT * FROM local_transfer_intents WHERE transfer_id = ?",
                (transfer_id,),
            ).fetchone()
        assert row is not None
        return _local_transfer_from_row(row)

    def list_local_transfer_intents(
        self,
        *,
        limit: int = 1_000,
        after: tuple[int, str] | None = None,
    ) -> tuple[LocalTransferIntent, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 10_000:
            raise ValueError("limit must be between 1 and 10000.")
        if after is not None:
            if (
                not isinstance(after, tuple)
                or len(after) != 2
                or isinstance(after[0], bool)
                or not isinstance(after[0], int)
                or after[0] < 0
            ):
                raise ValueError("after must be a (created_at_ns, transfer_id) tuple.")
            after = (after[0], _mutation_id(after[1]))
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if after is None:
                rows = self._connection.execute(
                    """SELECT * FROM local_transfer_intents
                       WHERE scope_id = ?
                       ORDER BY created_at_ns, transfer_id LIMIT ?""",
                    (scope_id, limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """SELECT * FROM local_transfer_intents
                       WHERE scope_id = ?
                         AND (
                           created_at_ns > ?
                           OR (created_at_ns = ? AND transfer_id > ?)
                         )
                       ORDER BY created_at_ns, transfer_id LIMIT ?""",
                    (scope_id, after[0], after[0], after[1], limit),
                ).fetchall()
        return tuple(_local_transfer_from_row(row) for row in rows)

    def list_local_transfer_issues(
        self,
        *,
        limit: int = 5,
        after: tuple[int, str] | None = None,
    ) -> tuple[LocalTransferIntent, ...]:
        """Return a bounded active-scope page of explicit local-file issues."""

        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100.")
        if after is not None:
            if (
                not isinstance(after, tuple)
                or len(after) != 2
                or isinstance(after[0], bool)
                or not isinstance(after[0], int)
                or after[0] < 0
            ):
                raise ValueError("after must be a (created_at_ns, transfer_id) tuple.")
            after = (after[0], _mutation_id(after[1]))
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if after is None:
                rows = self._connection.execute(
                    """SELECT * FROM local_transfer_intents
                       INDEXED BY local_transfer_issue_page
                       WHERE scope_id = ? AND issue_code IS NOT NULL
                       ORDER BY created_at_ns, transfer_id LIMIT ?""",
                    (scope_id, limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """SELECT * FROM local_transfer_intents
                       INDEXED BY local_transfer_issue_page
                       WHERE scope_id = ? AND issue_code IS NOT NULL
                         AND (
                           created_at_ns > ?
                           OR (created_at_ns = ? AND transfer_id > ?)
                         )
                       ORDER BY created_at_ns, transfer_id LIMIT ?""",
                    (scope_id, after[0], after[0], after[1], limit),
                ).fetchall()
        return tuple(_local_transfer_from_row(row) for row in rows)

    def get_runnable_local_transfer_intent(self) -> LocalTransferIntent | None:
        """Return the oldest unclassified intent without scanning issue rows."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM local_transfer_intents
                   INDEXED BY local_transfer_runnable_page
                   WHERE scope_id = ? AND issue_code IS NULL
                   ORDER BY created_at_ns, transfer_id LIMIT 1""",
                (scope_id,),
            ).fetchone()
        return _local_transfer_from_row(row) if row is not None else None

    def set_local_transfer_issue(
        self,
        transfer_id: str,
        *,
        issue_code: str | None,
        issue_size_bytes: int | None,
    ) -> LocalTransferIntent:
        """Update only the bounded issue projection for one durable snapshot."""

        transfer_id = _mutation_id(transfer_id)
        issue_code, issue_size_bytes = _local_transfer_issue(
            issue_code, issue_size_bytes
        )
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                """UPDATE local_transfer_intents
                   SET issue_code = ?, issue_size_bytes = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND transfer_id = ?""",
                (issue_code, issue_size_bytes, now, scope_id, transfer_id),
            )
            if cursor.rowcount != 1:
                raise StateError("The local transfer issue owner is unavailable.")
            row = self._connection.execute(
                "SELECT * FROM local_transfer_intents WHERE transfer_id = ?",
                (transfer_id,),
            ).fetchone()
        assert row is not None
        return _local_transfer_from_row(row)

    def local_transfer_backlog_snapshot(self) -> LocalTransferBacklog:
        """Return exact durable local-transfer count/bytes in one PK lookup."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT path_count, size_bytes
                   FROM fabric_local_transfer_usage WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
        return LocalTransferBacklog(
            path_count=int(row["path_count"]) if row is not None else 0,
            size_bytes=int(row["size_bytes"]) if row is not None else 0,
        )

    def pending_rename_sources(self, paths: Sequence[str]) -> frozenset[tuple[str, str]]:
        """Read exact source identities retained by content-changing renames.

        The transfer stays durable until its destination ACK atomically queues
        the source DELETE. This is only a local namespace projection; it never
        advances deletion or grants permission to remove a replacement.
        """

        if isinstance(paths, (str, bytes)) or len(paths) > 10_000:
            raise ValueError("Rename source lookup requires at most 10000 paths.")
        canonical = tuple(dict.fromkeys(_canonical_path(path) for path in paths))
        result: set[tuple[str, str]] = set()
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            for offset in range(0, len(canonical), 400):
                batch = canonical[offset : offset + 400]
                placeholders = ",".join("?" for _ in batch)
                rows = self._connection.execute(
                    f"""SELECT delete_after_ack_path, delete_after_ack_digest
                        FROM local_transfer_intents
                        INDEXED BY local_transfer_delete_source
                        WHERE scope_id = ? AND delete_after_ack_path IS NOT NULL
                          AND delete_after_ack_path IN ({placeholders})
                          AND delete_after_ack_digest IS NOT NULL
                          AND path <> delete_after_ack_path""",
                    (scope_id, *batch),
                ).fetchall()
                result.update((str(row[0]), str(row[1])) for row in rows)
        return frozenset(result)

    def get_local_transfer_intent(self, path: str) -> LocalTransferIntent | None:
        """Read one active transfer by canonical path using the table key."""

        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM local_transfer_intents
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, path),
            ).fetchone()
        return _local_transfer_from_row(row) if row is not None else None

    def get_local_transfer_intent_by_id(
        self, transfer_id: str
    ) -> LocalTransferIntent | None:
        """Read one active transfer by its globally indexed publication UUID."""

        transfer_id = _mutation_id(transfer_id)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM local_transfer_intents
                   WHERE transfer_id = ? AND scope_id = ?""",
                (transfer_id, scope_id),
            ).fetchone()
        return _local_transfer_from_row(row) if row is not None else None

    def complete_local_transfer_intent(self, transfer_id: str) -> bool:
        """Forget metadata only after its idempotent journal enqueue is durable."""

        transfer_id = _mutation_id(transfer_id)
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                """DELETE FROM local_transfer_intents
                   WHERE scope_id = ? AND transfer_id = ?""",
                (scope_id, transfer_id),
            )
        return cursor.rowcount == 1

    def ack_put_with_dependent_delete(
        self,
        parent_mutation_id: str,
        *,
        delete_mutation_id: str,
        delete_path: str,
        delete_base_generation: int,
        delete_base_digest: str | None,
        delete_expected_source_digest: str,
        remote_generation: int,
        remote_manifest_digest: str | None,
        remote_entry_digest: str,
        receipt: Mapping[str, Any],
        delete_staged_path: Path | str | None = None,
    ) -> PendingOperation:
        """Atomically finish a staged put and enqueue its rename-source delete.

        A large, content-changing rename is represented as an uploaded put plus
        a dependent source deletion.  Publishing those journal transitions in
        separate transactions leaves a crash window where the put receipt is
        durable but the sole deterministic delete identity has disappeared.
        This method closes that window and makes uncertain-commit replay exact.
        """

        parent_mutation_id = _mutation_id(parent_mutation_id)
        delete_mutation_id = _mutation_id(delete_mutation_id)
        if delete_mutation_id == parent_mutation_id:
            raise ValueError("The dependent delete must use a distinct mutation UUID.")
        delete_path = _canonical_path(delete_path)
        delete_base_generation = _generation(delete_base_generation)
        remote_generation = _generation(remote_generation)
        delete_base_digest = _digest(
            "delete base digest", delete_base_digest
        )
        delete_expected_source_digest = _digest(
            "delete expected source digest",
            delete_expected_source_digest,
            required=True,
        )
        remote_manifest_digest = _digest(
            "remote manifest digest", remote_manifest_digest
        )
        remote_entry_digest = _digest(
            "remote entry digest", remote_entry_digest, required=True
        )
        if not isinstance(receipt, Mapping):
            raise ValueError("receipt must be a JSON mapping.")
        normalized_delete_staged_path = (
            str(Path(delete_staged_path).resolve(strict=False))
            if delete_staged_path is not None
            else None
        )
        receipt_json = _bounded_json(receipt, _MAX_RECEIPT_JSON_BYTES, "receipt")
        assert (
            delete_expected_source_digest is not None
            and remote_entry_digest is not None
            and receipt_json is not None
        )
        now = time.time_ns()

        with self._transaction():
            scope_id = self._active_scope_id()
            parent = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (parent_mutation_id, scope_id),
            ).fetchone()
            if parent is None or str(parent["kind"]) != "put":
                raise StateError("The parent put is not in the active authority epoch.")
            if str(parent["path"]) == delete_path:
                raise StateError("A dependent rename delete must target the source path.")
            if str(parent["state"]) not in (*_NONTERMINAL_OPERATION_STATES, "acked"):
                raise StateError(
                    f"A {parent['state']} parent put cannot publish a dependent delete."
                )
            if (
                delete_base_generation != remote_generation
                or delete_base_digest != remote_manifest_digest
            ):
                raise StateError(
                    "The dependent delete must be based on the acknowledged put head."
                )
            if str(parent["staged_digest"] or "") != remote_entry_digest:
                raise StateError("The acknowledged put digest does not match its staged bytes.")

            intent = self._connection.execute(
                """SELECT * FROM local_transfer_intents
                   WHERE scope_id = ? AND transfer_id = ?""",
                (scope_id, parent_mutation_id),
            ).fetchone()
            if intent is not None:
                if (
                    str(intent["path"]) != str(parent["path"])
                    or str(intent["delete_after_ack_path"] or "") != delete_path
                    or str(intent["delete_after_ack_digest"] or "")
                    != delete_expected_source_digest
                    or str(intent["delete_mutation_id"] or "") != delete_mutation_id
                ):
                    raise StateError(
                        "The local transfer intent does not authorize this dependent delete."
                    )

            existing_receipt = self._connection.execute(
                "SELECT * FROM operation_receipts WHERE mutation_id = ?",
                (parent_mutation_id,),
            ).fetchone()
            if existing_receipt is not None and not self._receipt_matches(
                existing_receipt,
                scope_id=scope_id,
                remote_generation=remote_generation,
                remote_manifest_digest=remote_manifest_digest,
                remote_entry_digest=remote_entry_digest,
                receipt_json=receipt_json,
            ):
                raise StateError("The parent put already has a different durable receipt.")
            if str(parent["state"]) == "acked" and existing_receipt is None:
                raise StateError("The acknowledged parent put is missing its durable receipt.")
            if intent is None and str(parent["state"]) != "acked":
                raise StateError("The parent put is missing its local transfer intent.")

            successor = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (delete_mutation_id,),
            ).fetchone()
            if successor is None:
                latest_by_path = self._latest_path_predecessors(scope_id, (delete_path,))
                predecessors = {
                    str(row["mutation_id"]): row for row in latest_by_path.values()
                }
                predecessor = max(
                    predecessors.values(),
                    key=lambda row: int(row["journal_seq"]),
                    default=None,
                )
                predecessor_mutation_id = (
                    str(predecessor["mutation_id"])
                    if predecessor is not None
                    else None
                )
                journal_seq = self._next_journal_sequence(scope_id)
                self._connection.execute(
                    """INSERT INTO pending_operations(
                           scope_id, mutation_id, journal_seq, kind, path, destination_path,
                           base_generation, base_digest, expected_source_digest,
                           expected_destination_digest, staged_path, staged_digest,
                           staged_size, state, attempt_count, created_at_ns, updated_at_ns,
                           predecessor_mutation_id, blocked_count, ready_at_ns
                       ) VALUES (?, ?, ?, 'delete', ?, NULL, ?, ?, ?, NULL, ?,
                                 NULL, NULL, 'queued', 0, ?, ?, ?, ?, ?)""",
                    (
                        scope_id,
                        delete_mutation_id,
                        journal_seq,
                        delete_path,
                        delete_base_generation,
                        delete_base_digest,
                        delete_expected_source_digest,
                        normalized_delete_staged_path,
                        now,
                        now,
                        predecessor_mutation_id,
                        len(predecessors),
                        now,
                    ),
                )
                self._connection.executemany(
                    """INSERT INTO operation_dependencies(
                           scope_id, mutation_id, predecessor_mutation_id
                       ) VALUES (?, ?, ?)""",
                    (
                        (scope_id, delete_mutation_id, predecessor_id)
                        for predecessor_id in sorted(predecessors)
                    ),
                )
            elif (
                int(successor["scope_id"]) != scope_id
                or str(successor["kind"]) != "delete"
                or str(successor["path"]) != delete_path
                or successor["destination_path"] is not None
                or int(successor["base_generation"] or 0) != delete_base_generation
                or successor["base_digest"] != delete_base_digest
                or str(successor["expected_source_digest"] or "")
                != delete_expected_source_digest
                or successor["expected_destination_digest"] is not None
                or successor["staged_path"] != normalized_delete_staged_path
            ):
                raise StateError("The dependent delete UUID identifies different work.")

            if intent is not None:
                cursor = self._connection.execute(
                    """DELETE FROM local_transfer_intents
                       WHERE scope_id = ? AND transfer_id = ? AND path = ?
                         AND delete_after_ack_path = ?
                         AND delete_after_ack_digest = ? AND delete_mutation_id = ?""",
                    (
                        scope_id,
                        parent_mutation_id,
                        parent["path"],
                        delete_path,
                        delete_expected_source_digest,
                        delete_mutation_id,
                    ),
                )
                if cursor.rowcount != 1:  # pragma: no cover - IMMEDIATE transaction fences this
                    raise StateError("The local transfer intent changed before acknowledgement.")

            self._ack_operation_locked(
                scope_id,
                parent,
                remote_generation=remote_generation,
                remote_manifest_digest=remote_manifest_digest,
                remote_entry_digest=remote_entry_digest,
                receipt_json=receipt_json,
                now=now,
            )
            successor = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (delete_mutation_id,),
            ).fetchone()
        assert successor is not None
        return _operation_from_row(successor)

    # --------------------------------------------------------------- operations

    def _next_journal_sequence(self, scope_id: int) -> int:
        """Allocate one durable causal position inside the active transaction."""

        self._connection.execute(
            """INSERT INTO fabric_journal_sequences(scope_id, next_seq)
               VALUES (?, 1) ON CONFLICT(scope_id) DO NOTHING""",
            (scope_id,),
        )
        row = self._connection.execute(
            "SELECT next_seq FROM fabric_journal_sequences WHERE scope_id = ?",
            (scope_id,),
        ).fetchone()
        assert row is not None
        sequence = int(row["next_seq"])
        if sequence >= (1 << 63) - 1:
            raise StateError("The mutation journal sequence is exhausted.")
        self._connection.execute(
            """UPDATE fabric_journal_sequences SET next_seq = ?
               WHERE scope_id = ? AND next_seq = ?""",
            (sequence + 1, scope_id, sequence),
        )
        return sequence

    def _latest_path_predecessors(
        self, scope_id: int, paths: Sequence[str]
    ) -> dict[str, sqlite3.Row]:
        """Newest nonterminal operation affecting each of at most two paths.

        Source and destination use separate covering indexes.  This avoids an
        OR scan of a journal that can contain hundreds of thousands of rows,
        while still allowing one rename to depend on two independent chains.
        The caller holds this database's transaction or process lock.
        """

        if not 1 <= len(paths) <= 2:
            raise ValueError("Operation dependency lookup accepts one or two paths.")
        latest: dict[str, sqlite3.Row] = {}
        for affected_path in paths:
            candidates: list[sqlite3.Row] = []
            for column in ("path", "destination_path"):
                row = self._connection.execute(
                    f"""SELECT * FROM pending_operations
                        WHERE scope_id = ? AND {column} = ?
                          AND state IN ('queued', 'inflight', 'retry')
                        ORDER BY journal_seq DESC LIMIT 1""",
                    (scope_id, affected_path),
                ).fetchone()
                if row is not None:
                    candidates.append(row)
            if candidates:
                latest[affected_path] = max(
                    candidates,
                    key=lambda row: int(row["journal_seq"]),
                )
        return latest

    def _nonterminal_operations_touching_prefix(
        self,
        scope_id: int,
        prefix: str,
        *,
        limit: int,
    ) -> tuple[sqlite3.Row, ...]:
        """Return a bounded, index-driven set of operations under one prefix.

        Source and destination columns are queried separately so a large
        journal never falls back to an ``OR`` scan.  Exact-prefix operations
        are included alongside descendants; callers decide which shapes are
        safe for their namespace transition.
        """

        descendant = prefix + "/"
        upper = prefix + "0"
        found: dict[str, sqlite3.Row] = {}
        for column, index in (
            ("path", "pending_source_path_order"),
            ("destination_path", "pending_destination_path_order"),
        ):
            for predicate, values in (
                (f"{column} = ?", (prefix,)),
                (f"{column} >= ? AND {column} < ?", (descendant, upper)),
            ):
                rows = self._connection.execute(
                    f"""SELECT * FROM pending_operations INDEXED BY {index}
                        WHERE scope_id = ? AND {predicate}
                          AND state IN ('queued', 'inflight', 'retry')
                        ORDER BY {column}, journal_seq DESC LIMIT ?""",
                    (scope_id, *values, limit),
                ).fetchall()
                for row in rows:
                    mutation_id = str(row["mutation_id"])
                    found[mutation_id] = row
                    if len(found) >= limit:
                        return tuple(
                            sorted(
                                found.values(),
                                key=lambda item: int(item["journal_seq"]),
                            )
                        )
        return tuple(
            sorted(found.values(), key=lambda item: int(item["journal_seq"]))
        )

    def list_nonterminal_operations_touching_prefix(
        self,
        prefix: str,
        *,
        limit: int = _MAX_DIRECTORY_RENAME_PREDECESSORS + 1,
    ) -> tuple[PendingOperation, ...]:
        """List bounded pending work whose source or destination touches a prefix."""

        prefix = _canonical_path(prefix)
        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= 100_000
        ):
            raise ValueError("limit must be between 1 and 100000.")
        with self._lock:
            self._require_open()
            rows = self._nonterminal_operations_touching_prefix(
                self._active_scope_id(),
                prefix,
                limit=limit,
            )
        return tuple(_operation_from_row(row) for row in rows)

    def enqueue_operation(
        self,
        kind: OperationKind | str,
        path: str,
        *,
        destination_path: str | None = None,
        base_generation: int | None = None,
        base_digest: str | None = None,
        expected_source_digest: str | None = None,
        expected_destination_digest: str | None = None,
        staged_path: Path | str | None = None,
        staged_digest: str | None = None,
        staged_size: int | None = None,
        mutation_id: str | None = None,
        initial_retry_error: str | None = None,
        directory_rename: bool = False,
        coalesce: bool = True,
    ) -> PendingOperation:
        """Durably enqueue, coalescing only an operation never put on the wire.

        Every put stage is retained in ``operation_stages``.  Updating a queued
        put therefore never loses the path to its previous staged bytes; the
        reconciler can clean those files only after observing the journal.
        """
        if kind not in _OPERATION_KINDS:
            raise ValueError(f"Unknown Fabric operation kind {kind!r}.")
        if not isinstance(directory_rename, bool):
            raise ValueError("directory_rename must be a boolean.")
        if not isinstance(coalesce, bool):
            raise ValueError("coalesce must be a boolean.")
        if directory_rename and kind != "rename":
            raise ValueError("Only a rename may be directory-scoped.")
        path = _canonical_path(path)
        if kind == "rename":
            if destination_path is None:
                raise ValueError("A rename requires destination_path.")
            destination_path = _canonical_path(destination_path)
            if destination_path == path:
                raise ValueError("A rename destination must differ from its source.")
        elif destination_path is not None:
            raise ValueError(f"{kind} does not accept destination_path.")
        base_digest = _digest("base digest", base_digest)
        if base_generation is not None:
            # A v1 base is (generation, manifest digest): the pair is what the
            # authority fences the whole namespace on, so half of it is
            # meaningless. A v2 base is a journal sequence alone -- there is no
            # per-commit content hash to pair it with, and the operation is
            # fenced per path by `expected_source_digest` instead. Sequence 0
            # is a real base: a workspace with no writes yet.
            base_generation = (
                _sequence("base generation", base_generation)
                if base_digest is None
                else _generation(base_generation)
            )
        elif base_digest is not None:
            raise ValueError("A base digest requires a base generation.")
        expected_source_digest = _digest("expected source digest", expected_source_digest)
        expected_destination_digest = _digest(
            "expected destination digest", expected_destination_digest
        )
        normalized_staged_path: str | None = None
        if kind == "put":
            if staged_path is None or staged_digest is None or staged_size is None:
                raise ValueError("A put requires staged_path, staged_digest, and staged_size.")
            normalized_staged_path = str(Path(staged_path).expanduser().resolve(strict=False))
            staged_digest = _digest("staged digest", staged_digest, required=True)
            if (
                isinstance(staged_size, bool)
                or not isinstance(staged_size, int)
                or staged_size < 0
            ):
                raise ValueError("staged_size must be non-negative.")
        elif staged_path is not None or staged_digest is not None or staged_size is not None:
            raise ValueError(f"{kind} does not accept staged content.")
        if initial_retry_error is not None:
            if kind != "rename":
                raise ValueError("Only a rename may start behind a verification fence.")
            initial_retry_error = _bounded_text(
                "initial_retry_error", initial_retry_error, _MAX_ERROR_BYTES
            )
        initial_state = "retry" if initial_retry_error is not None else "queued"
        requested_mutation_id = _mutation_id(mutation_id)
        now = time.time_ns()
        affected_paths = (
            (path, destination_path)
            if destination_path is not None
            else (path,)
        )

        with self._transaction():
            scope_id = self._active_scope_id()
            self._require_authority_adopted(scope_id)
            directory_predecessors: tuple[sqlite3.Row, ...] = ()
            active_directory = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE scope_id = ? AND directory_rename = 1
                     AND directory_rename_observed = 0
                     AND state IN ('queued','inflight','retry','acked')
                   ORDER BY journal_seq DESC LIMIT 1""",
                (scope_id,),
            ).fetchone()
            if directory_rename:
                if active_directory is not None:
                    raise StateError("A directory rename is already pending.")
                assert destination_path is not None
                source_work = self._nonterminal_operations_touching_prefix(
                    scope_id,
                    path,
                    limit=_MAX_DIRECTORY_RENAME_PREDECESSORS + 1,
                )
                destination_work = self._nonterminal_operations_touching_prefix(
                    scope_id,
                    destination_path,
                    limit=1,
                )
                if destination_work:
                    raise StateError(
                        "A directory rename destination contains pending work."
                    )
                if len(source_work) > _MAX_DIRECTORY_RENAME_PREDECESSORS:
                    raise StateError(
                        "A directory rename exceeds the bounded dependency set."
                    )
                if any(
                    str(row["kind"]) != "put"
                    or row["destination_path"] is not None
                    or not str(row["path"]).startswith(path + "/")
                    for row in source_work
                ):
                    raise StateError(
                        "A directory rename contains incompatible pending work."
                    )
                latest_source_puts: dict[str, sqlite3.Row] = {}
                for row in source_work:
                    source = str(row["path"])
                    previous = latest_source_puts.get(source)
                    if previous is None or int(row["journal_seq"]) > int(
                        previous["journal_seq"]
                    ):
                        latest_source_puts[source] = row
                directory_predecessors = tuple(latest_source_puts.values())
            elif active_directory is not None:
                directory_prefixes = (
                    str(active_directory["path"]),
                    str(active_directory["destination_path"]),
                )
                if any(
                    affected == prefix
                    or affected.startswith(prefix + "/")
                    for affected in affected_paths
                    for prefix in directory_prefixes
                ):
                    # The optimistic prefix projection intentionally has one
                    # durable writer. Freezing its two subtrees until the
                    # receipt generation is observed keeps exact-path journal
                    # expectations unambiguous across crashes and reconnects.
                    raise StateError("The directory rename is still reconciling.")
            latest_by_path = self._latest_path_predecessors(
                scope_id, affected_paths
            )
            existing = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE scope_id = ? AND kind = ? AND path = ?
                         AND destination_path IS ? AND state = 'queued'
                         AND attempt_count = 0
                   ORDER BY journal_seq DESC LIMIT 1""",
                (scope_id, kind, path, destination_path),
            ).fetchone()
            coalescible = coalesce and existing is not None and all(
                str(latest_by_path[affected]["mutation_id"])
                == str(existing["mutation_id"])
                for affected in affected_paths
            )
            if coalescible:
                assert existing is not None
                effective_mutation_id = str(existing["mutation_id"])
                if kind == "put":
                    self._connection.execute(
                        "UPDATE operation_stages SET active = 0 WHERE mutation_id = ?",
                        (effective_mutation_id,),
                    )
                    self._insert_stage(
                        effective_mutation_id,
                        normalized_staged_path,
                        staged_digest,
                        staged_size,
                        now,
                    )
                self._connection.execute(
                    """UPDATE pending_operations SET
                           base_generation = ?, base_digest = ?,
                           expected_source_digest = ?, expected_destination_digest = ?,
                           staged_path = ?, staged_digest = ?, staged_size = ?,
                           state = ?, last_error = ?, claimed_at_ns = NULL,
                           next_attempt_at_ns = ?, ready_at_ns = ?, updated_at_ns = ?,
                           directory_rename = ?, directory_rename_observed = 0,
                           rename_source_json = NULL
                       WHERE mutation_id = ?""",
                    (
                        base_generation,
                        base_digest,
                        expected_source_digest,
                        expected_destination_digest,
                        normalized_staged_path,
                        staged_digest,
                        staged_size,
                        initial_state,
                        initial_retry_error,
                        0 if initial_retry_error is not None else None,
                        0 if initial_retry_error is not None else now,
                        now,
                        int(directory_rename),
                        effective_mutation_id,
                    ),
                )
            else:
                effective_mutation_id = requested_mutation_id
                predecessors = {
                    str(row["mutation_id"]): row
                    for row in (*latest_by_path.values(), *directory_predecessors)
                }
                predecessor = max(
                    predecessors.values(),
                    key=lambda row: int(row["journal_seq"]),
                    default=None,
                )
                predecessor_mutation_id = (
                    str(predecessor["mutation_id"])
                    if predecessor is not None
                    else None
                )
                journal_seq = self._next_journal_sequence(scope_id)
                self._connection.execute(
                    """INSERT INTO pending_operations(
                           scope_id, mutation_id, journal_seq, kind, path, destination_path,
                           base_generation, base_digest, expected_source_digest,
                           expected_destination_digest, staged_path, staged_digest,
                           staged_size, state, attempt_count, created_at_ns, updated_at_ns,
                           predecessor_mutation_id, blocked_count, ready_at_ns,
                           last_error, next_attempt_at_ns, directory_rename,
                           directory_rename_observed
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, 0)""",
                    (
                        scope_id,
                        effective_mutation_id,
                        journal_seq,
                        kind,
                        path,
                        destination_path,
                        base_generation,
                        base_digest,
                        expected_source_digest,
                        expected_destination_digest,
                        normalized_staged_path,
                        staged_digest,
                        staged_size,
                        initial_state,
                        now,
                        now,
                        predecessor_mutation_id,
                        len(predecessors),
                        0 if initial_retry_error is not None else now,
                        initial_retry_error,
                        0 if initial_retry_error is not None else None,
                        int(directory_rename),
                    ),
                )
                self._connection.executemany(
                    """INSERT INTO operation_dependencies(
                           scope_id, mutation_id, predecessor_mutation_id
                       ) VALUES (?, ?, ?)""",
                    (
                        (scope_id, effective_mutation_id, predecessor_id)
                        for predecessor_id in sorted(predecessors)
                    ),
                )
                if kind == "put":
                    self._insert_stage(
                        effective_mutation_id,
                        normalized_staged_path,
                        staged_digest,
                        staged_size,
                        now,
                    )
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (effective_mutation_id,),
            ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def enqueue_put(self, path: str, **fields: Any) -> PendingOperation:
        return self.enqueue_operation("put", path, **fields)

    def enqueue_delete(self, path: str, **fields: Any) -> PendingOperation:
        return self.enqueue_operation("delete", path, **fields)

    def enqueue_rename(
        self, path: str, destination_path: str, **fields: Any
    ) -> PendingOperation:
        return self.enqueue_operation(
            "rename", path, destination_path=destination_path, **fields
        )

    def freeze_rename_source(
        self, mutation_id: str, source: RemoteEntry
    ) -> PendingOperation:
        """Persist one exact replacement source before its first wire fence."""
        source = _remote_entry(source)
        encoded = _bounded_json({
            "path": source.path, "size_bytes": source.size_bytes,
            "digest": source.digest, "modified": source.modified,
            "blocks": source.blocks,
        }, _MAX_BLOCKS_JSON_BYTES + 8192, "rename source")
        with self._transaction():
            scope_id = self._active_scope_id()
            self._require_authority_adopted(scope_id)
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE scope_id = ? AND mutation_id = ?",
                (scope_id, mutation_id),
            ).fetchone()
            if (row is None or row["kind"] != "rename" or row["directory_rename"]
                or row["path"] != source.path
                or row["expected_source_digest"] != source.digest
                or row["expected_destination_digest"] is None
                or source.kind != "file" or source.blocks is None):
                raise StateError("The atomic replacement source does not match its journal.")
            if row["rename_source_json"] is not None:
                if row["rename_source_json"] != encoded:
                    raise StateError("The atomic replacement source is already frozen.")
                return _operation_from_row(row)
            if (row["state"] not in ("queued", "retry", "inflight")
                or row["request_digest"] is not None or row["commit_unknown"]):
                raise StateError("A sent rename cannot change its wire contract.")
            self._connection.execute(
                "UPDATE pending_operations SET rename_source_json = ? WHERE mutation_id = ?",
                (encoded, mutation_id),
            )
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?", (mutation_id,)
            ).fetchone()
            return _operation_from_row(row)

    def get_active_directory_rename(self) -> PendingOperation | None:
        """Return the one durable prefix overlay still visible to the mount."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE scope_id = ? AND directory_rename = 1
                     AND directory_rename_observed = 0
                     AND state IN ('queued','inflight','retry','acked')
                   ORDER BY journal_seq LIMIT 1""",
                (scope_id,),
            ).fetchone()
        return _operation_from_row(row) if row is not None else None

    def get_observable_directory_rename(self) -> PendingOperation | None:
        """Return the acknowledged overlay ready for one local prune pass.

        The later UPDATE repeats these predicates transactionally. This probe
        exists to keep filesystem cleanup O(subtree) once at retirement rather
        than once per bounded per-file reconciliation tick.
        """

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT operation.* FROM pending_operations AS operation
                   WHERE operation.scope_id = ?
                     AND operation.directory_rename = 1
                     AND operation.directory_rename_observed = 0
                     AND operation.state = 'acked'
                     AND EXISTS (
                       SELECT 1
                       FROM operation_receipts AS receipt
                       JOIN remote_manifest_heads AS head
                         ON head.scope_id = receipt.scope_id
                       WHERE receipt.mutation_id = operation.mutation_id
                         AND receipt.remote_generation IS NOT NULL
                         AND head.generation >= receipt.remote_generation
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_apply_intents AS apply
                       WHERE apply.scope_id = operation.scope_id
                         AND (
                           apply.path = operation.path
                           OR substr(apply.path, 1, length(operation.path) + 1) =
                              operation.path || '/'
                           OR apply.path = operation.destination_path
                           OR substr(
                                apply.path, 1,
                                length(operation.destination_path) + 1
                              ) = operation.destination_path || '/'
                         )
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_rename_intents AS rename
                       WHERE rename.scope_id = operation.scope_id
                         AND (
                           rename.source_path = operation.path
                           OR substr(
                                rename.source_path, 1,
                                length(operation.path) + 1
                              ) = operation.path || '/'
                           OR rename.source_path = operation.destination_path
                           OR substr(
                                rename.source_path, 1,
                                length(operation.destination_path) + 1
                              ) = operation.destination_path || '/'
                           OR rename.destination_path = operation.path
                           OR substr(
                                rename.destination_path, 1,
                                length(operation.path) + 1
                              ) = operation.path || '/'
                           OR rename.destination_path = operation.destination_path
                           OR substr(
                                rename.destination_path, 1,
                                length(operation.destination_path) + 1
                              ) = operation.destination_path || '/'
                         )
                     )
                   ORDER BY operation.journal_seq LIMIT 1""",
                (scope_id,),
            ).fetchone()
        return _operation_from_row(row) if row is not None else None

    def mark_directory_renames_observed(self) -> int:
        """Retire acknowledged overlays after their receipt generation is local.

        A contiguous delta chain or committed full-manifest load proves every
        generation up to the current head.  Using receipt generation rather
        than present paths also handles a directory moved and then deleted by
        another node before this node next polls.
        """

        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            cursor = self._connection.execute(
                """UPDATE pending_operations AS operation
                   SET directory_rename_observed = 1, updated_at_ns = ?
                   WHERE operation.scope_id = ?
                     AND operation.directory_rename = 1
                     AND operation.directory_rename_observed = 0
                     AND operation.state = 'acked'
                     AND EXISTS (
                       SELECT 1
                       FROM operation_receipts AS receipt
                       JOIN remote_manifest_heads AS head
                         ON head.scope_id = receipt.scope_id
                       WHERE receipt.mutation_id = operation.mutation_id
                         AND receipt.remote_generation IS NOT NULL
                         AND head.generation >= receipt.remote_generation
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_apply_intents AS apply
                       WHERE apply.scope_id = operation.scope_id
                         AND (
                           apply.path = operation.path
                           OR substr(apply.path, 1, length(operation.path) + 1) =
                              operation.path || '/'
                           OR apply.path = operation.destination_path
                           OR substr(
                                apply.path, 1,
                                length(operation.destination_path) + 1
                              ) = operation.destination_path || '/'
                         )
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_rename_intents AS rename
                       WHERE rename.scope_id = operation.scope_id
                         AND (
                           rename.source_path = operation.path
                           OR substr(
                                rename.source_path, 1,
                                length(operation.path) + 1
                              ) = operation.path || '/'
                           OR rename.source_path = operation.destination_path
                           OR substr(
                                rename.source_path, 1,
                                length(operation.destination_path) + 1
                              ) = operation.destination_path || '/'
                           OR rename.destination_path = operation.path
                           OR substr(
                                rename.destination_path, 1,
                                length(operation.path) + 1
                              ) = operation.path || '/'
                           OR rename.destination_path = operation.destination_path
                           OR substr(
                                rename.destination_path, 1,
                                length(operation.destination_path) + 1
                              ) = operation.destination_path || '/'
                         )
                     )""",
                (now, scope_id),
            )
        return int(cursor.rowcount)

    def get_latest_nonterminal_operation(self, path: str) -> PendingOperation | None:
        """Return the newest durable operation that can still change ``path``."""

        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._latest_path_predecessors(scope_id, (path,)).get(path)
        return _operation_from_row(row) if row is not None else None

    def repair_unbacked_conflict_materializations(
        self, *, limit: int = 10_000
    ) -> tuple[str, ...]:
        """Heal materializations fenced as ``conflict`` with nothing backing them.

        ``state = 'conflict'`` is a fence, and its only legitimate backing is an
        unresolved row in ``conflicts``. A row that outlives its evidence is
        pure inconsistency: it keeps the entry pinned and out of the ordinary
        reconciliation lanes forever, and no ``conflicts list`` output explains
        why. Restart is the one moment every writer is quiesced, so this heals
        it there rather than leaving the entry stranded until the user re-pairs.

        The transition is chosen from evidence the row itself carries, and it
        never discards bytes:

        * nothing on disk (no fingerprint, no bytes) -- ``absent``, so the next
          read simply hydrates from the remote entry again;
        * bytes on disk -- ``dirty``, which hands the entry back to the
          reconciler. ``clean`` is deliberately NOT used: completion of the
          fence does not by itself prove the local bytes equal the remote
          digest, and claiming it would let a stale preimage be served and its
          upload skipped.

        A path that still has an unresolved conflict is left exactly as it is.
        """

        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
            raise ValueError("limit must be a positive integer.")
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT path, bytes_on_disk, stat_fingerprint
                   FROM materialized_entries AS entry
                   WHERE scope_id = ? AND state = 'conflict'
                     AND NOT EXISTS (
                         SELECT 1 FROM conflicts
                          WHERE conflicts.scope_id = entry.scope_id
                            AND conflicts.path = entry.path
                            AND conflicts.resolved_at_ns IS NULL
                     )
                   ORDER BY path
                   LIMIT ?""",
                (scope_id, limit),
            ).fetchall()
            repaired: list[str] = []
            for row in rows:
                path = str(row["path"])
                has_local = bool(
                    int(row["bytes_on_disk"] or 0) > 0
                    or row["stat_fingerprint"] is not None
                )
                updated = self._connection.execute(
                    """UPDATE materialized_entries
                       SET state = ?, pinned = 0, updated_at_ns = ?
                       WHERE scope_id = ? AND path = ? AND state = 'conflict'""",
                    (
                        "dirty" if has_local else "absent",
                        now,
                        scope_id,
                        path,
                    ),
                )
                if updated.rowcount == 1:
                    repaired.append(path)
        return tuple(repaired)

    def get_unresolved_delete_intent(self, path: str) -> PendingOperation | None:
        """Return a durable unlink receipt that stopped short of its ACK.

        A mounted ``unlink`` commits its delete to this journal *before* the
        syscall returns 0, so the journal -- not the remote manifest mirror --
        is what the caller was promised. When that delete later lands in a
        terminal, unacknowledged state (``conflict``/``quarantined``) the
        promise is still outstanding: the namespace must keep hiding the path
        instead of silently resurrecting it from the mirror the same delete
        was trying to change.

        Only the newest journal row for the path qualifies, so a later PUT
        that recreates the file (or an ACK) retires the intent immediately.
        """

        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM pending_operations
                   INDEXED BY pending_source_path_order
                   WHERE scope_id = ? AND path = ?
                     AND state IN ('conflict', 'quarantined')
                     AND kind = 'delete'
                     AND journal_seq = (
                         SELECT MAX(journal_seq) FROM pending_operations
                          WHERE scope_id = ? AND path = ?
                     )
                   LIMIT 1""",
                (scope_id, path, scope_id, path),
            ).fetchone()
        return _operation_from_row(row) if row is not None else None

    def get_operation(self, mutation_id: str) -> PendingOperation | None:
        """Read one exact operation in the active authority epoch by UUID."""

        mutation_id = _mutation_id(mutation_id)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
        return _operation_from_row(row) if row is not None else None

    def is_operation_sendable(
        self, mutation_id: str, *, now_ns: int | None = None
    ) -> bool:
        """Whether one exact mutation is currently eligible for a send claim."""

        mutation_id = _mutation_id(mutation_id)
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT 1 FROM pending_operations
                   WHERE scope_id = ? AND mutation_id = ?
                     AND blocked_count = 0 AND commit_unknown = 0
                     AND (
                       state = 'queued'
                       OR (state = 'retry' AND ready_at_ns <= ?)
                     )
                   LIMIT 1""",
                (scope_id, mutation_id, now),
            ).fetchone()
        return row is not None

    def _ensure_commit_batch_fence(self) -> None:
        """Bring pending_operations to the v20 batch-fence shape, idempotently."""

        columns = {
            str(row["name"])
            for row in self._connection.execute(
                "PRAGMA table_info(pending_operations)"
            ).fetchall()
        }
        index_sql = self._connection.execute(
            """SELECT sql FROM sqlite_master
               WHERE type = 'index' AND name = 'pending_one_commit_unknown_per_scope'"""
        ).fetchone()
        current_index = str(index_sql["sql"]) if index_sql is not None and index_sql["sql"] else ""
        if "commit_batch_id" in columns and "commit_batch_id IS NULL" in current_index:
            return
        self._connection.execute("BEGIN IMMEDIATE")
        try:
            if "commit_batch_id" not in columns:
                self._connection.execute(
                    "ALTER TABLE pending_operations ADD COLUMN commit_batch_id TEXT"
                )
            self._connection.execute(
                "DROP INDEX IF EXISTS pending_one_commit_unknown_per_scope"
            )
            self._connection.execute(
                """CREATE UNIQUE INDEX pending_one_commit_unknown_per_scope
                   ON pending_operations(scope_id)
                   WHERE commit_unknown = 1 AND commit_batch_id IS NULL"""
            )
            self._connection.execute("COMMIT")
        except BaseException:
            if self._connection.in_transaction:
                self._connection.execute("ROLLBACK")
            raise

    def list_sendable_operations(
        self, *, limit: int = 64, now_ns: int | None = None
    ) -> tuple[PendingOperation, ...]:
        """Return the operations ``claim_operation`` could lease right now.

        Journal order, bounded, read-only: queued rows, due retries and expired
        inflight leases with no unacked predecessor or unknown commit. The
        scheduler excludes its still-owned byte workers, then atomically claims
        exactly the selected rows. Merely listing never releases a lease.
        """

        # 1024 is the server's per-commit op ceiling (fabric_commit_v2_1762,
        # BETWEEN 1 AND 1024): the bulk v2 lane pulls a full page so one commit
        # can carry a whole 1024-descriptor cohort. It is a bounded, read-only
        # scan, so serving one more page row than the old 1000 costs nothing.
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1_024:
            raise ValueError("limit must be between 1 and 1024.")
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE scope_id = ? AND blocked_count = 0 AND commit_unknown = 0
                     AND (
                       state = 'queued'
                       OR (state = 'retry' AND ready_at_ns <= ?)
                       OR (state = 'inflight' AND claimed_at_ns <= ?)
                     )
                   ORDER BY journal_seq LIMIT ?""",
                (scope_id, now, now - int(_DEFAULT_OPERATION_LEASE_SECONDS * 1_000_000_000), limit),
            ).fetchall()
        return tuple(_operation_from_row(row) for row in rows)

    def claim_operations(
        self,
        mutation_ids: Sequence[str],
        *,
        now_ns: int | None = None,
    ) -> tuple[PendingOperation, ...]:
        """Lease exactly the named sendable operations in one transaction.

        Rows that are no longer sendable (a concurrent state change) are left
        untouched and omitted from the result, so the caller sends only what it
        durably owns. Expired uncommitted leases use the same default deadline
        as ``claim_operation``; a new winner renews the lease atomically.
        """

        ids = tuple(_mutation_id(mutation_id) for mutation_id in mutation_ids)
        if not ids or len(set(ids)) != len(ids):
            raise ValueError("mutation_ids must be a non-empty set of UUIDs.")
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        claimed: list[PendingOperation] = []
        with self._transaction():
            scope_id = self._active_scope_id()
            for mutation_id in ids:
                cursor = self._connection.execute(
                    """UPDATE pending_operations SET
                           state = 'inflight', attempt_count = attempt_count + 1,
                           failure_count = failure_count + CASE WHEN state = 'inflight' THEN 1 ELSE 0 END,
                           last_error = CASE WHEN state = 'inflight'
                             THEN COALESCE(last_error, 'operation lease expired') ELSE last_error END,
                           claimed_at_ns = ?, next_attempt_at_ns = NULL,
                           ready_at_ns = ?, updated_at_ns = ?
                       WHERE scope_id = ? AND mutation_id = ? AND blocked_count = 0
                         AND commit_unknown = 0
                         AND (
                           state = 'queued'
                           OR (state = 'retry' AND ready_at_ns <= ?)
                           OR (state = 'inflight' AND claimed_at_ns <= ?)
                         )""",
                    (now, now, now, scope_id, mutation_id, now,
                     now - int(_DEFAULT_OPERATION_LEASE_SECONDS * 1_000_000_000)),
                )
                if cursor.rowcount != 1:
                    continue
                row = self._connection.execute(
                    "SELECT * FROM pending_operations WHERE mutation_id = ?",
                    (mutation_id,),
                ).fetchone()
                assert row is not None
                claimed.append(_operation_from_row(row))
        return tuple(claimed)

    def mark_operations_commit_unknown(
        self,
        items: Sequence[tuple[str, str]],
        *,
        batch_id: str,
        now_ns: int | None = None,
    ) -> tuple[PendingOperation, ...]:
        """Freeze every (mutation_id, request_digest) of one batch before its POST.

        All rows enter commit_unknown in one FULL-synchronous transaction, so a
        crash between the fence and the response can never resend any member
        without a status readback. Members share ``batch_id``; the single-fence
        uniqueness only applies to unknown commits outside a batch.
        """

        batch_id = _mutation_id(batch_id)
        frozen = tuple(
            (_mutation_id(mutation_id), _digest("request digest", request_digest, required=True))
            for mutation_id, request_digest in items
        )
        if not frozen or len({mutation_id for mutation_id, _digest_ in frozen}) != len(frozen):
            raise ValueError("items must be a non-empty set of (mutation_id, request_digest).")
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        marked: list[PendingOperation] = []
        with self._transaction():
            scope_id = self._active_scope_id()
            for mutation_id, request_digest in frozen:
                current = self._connection.execute(
                    """SELECT * FROM pending_operations
                       WHERE mutation_id = ? AND scope_id = ?""",
                    (mutation_id, scope_id),
                ).fetchone()
                if current is None:
                    raise StateError("The pending operation is not in the active authority epoch.")
                frozen_digest = current["request_digest"]
                if frozen_digest is not None and str(frozen_digest) != request_digest:
                    raise StateError(
                        "The operation is already bound to a different mutation request."
                    )
                if int(current["commit_unknown"]) == 1:
                    raise StateError("The operation already has an unknown commit.")
                if str(current["state"]) != "inflight" or int(current["blocked_count"]) != 0:
                    raise StateError("Only the exact claimed operation can enter commit_unknown.")
                cursor = self._connection.execute(
                    """UPDATE pending_operations
                       SET commit_unknown = 1, request_digest = ?, commit_batch_id = ?,
                           ready_at_ns = ?, updated_at_ns = ?
                       WHERE mutation_id = ? AND scope_id = ?
                         AND state = 'inflight' AND commit_unknown = 0""",
                    (request_digest, batch_id, now, now, mutation_id, scope_id),
                )
                if cursor.rowcount != 1:
                    raise StateError("The operation changed before its commit fence was durable.")
                row = self._connection.execute(
                    "SELECT * FROM pending_operations WHERE mutation_id = ?",
                    (mutation_id,),
                ).fetchone()
                assert row is not None
                marked.append(_operation_from_row(row))
        return tuple(marked)

    def count_commit_unknown_operations(self) -> int:
        """How many mutations in the active scope await status readback."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT count(*) AS n FROM pending_operations
                   INDEXED BY pending_commit_unknown_ready
                   WHERE scope_id = ? AND commit_unknown = 1""",
                (scope_id,),
            ).fetchone()
        return int(row["n"]) if row is not None else 0

    def get_commit_unknown_operation(self) -> PendingOperation | None:
        """Return the one mutation whose commit result needs readback.

        ``commit_unknown`` is a durable fence, independent of the retry state:
        normal queue claiming must never resend such a mutation.  The partial
        covering index keeps restart recovery constant-time even with a large
        acknowledged journal.
        """

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            identity = self._connection.execute(
                """SELECT mutation_id FROM pending_operations
                   INDEXED BY pending_commit_unknown_ready
                   WHERE scope_id = ? AND commit_unknown = 1
                   ORDER BY journal_seq LIMIT 1""",
                (scope_id,),
            ).fetchone()
            row = (
                self._connection.execute(
                    """SELECT * FROM pending_operations
                       WHERE mutation_id = ? AND scope_id = ?""",
                    (identity["mutation_id"], scope_id),
                ).fetchone()
                if identity is not None
                else None
            )
        return _operation_from_row(row) if row is not None else None

    def list_quarantined_commit_unknowns(
        self, *, limit: int = 256
    ) -> tuple[QuarantinedCommitUnknown, ...]:
        """Export bounded unresolved outcomes from their original authorities.

        This is deliberately broader than status resolution: cross-session,
        workspace, and root outcomes remain visible for operator recovery but
        are never returned with a resolver capability.
        """

        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 10_000:
            raise ValueError("limit must be between 1 and 10000.")
        with self._lock:
            self._require_open()
            rows = self._connection.execute(
                """SELECT operation.*,
                          authority.host_id AS original_host_id,
                          authority.session_id AS original_session_id,
                          authority.host_generation AS original_host_generation,
                          authority.attachment_id AS original_attachment_id,
                          authority.workspace_root AS original_workspace_root,
                          authority.workspace_id AS original_workspace_id
                   FROM pending_operations AS operation
                   JOIN authority_scopes AS authority
                     ON authority.scope_id = operation.scope_id
                   WHERE operation.state = 'quarantined'
                     AND operation.commit_unknown = 1
                   ORDER BY operation.scope_id, operation.journal_seq
                   LIMIT ?""",
                (limit,),
            ).fetchall()
        return tuple(
            _quarantined_unknown_from_row(row, resolver_scope_id=None)
            for row in rows
        )

    def get_resolvable_quarantined_commit_unknown(
        self,
    ) -> QuarantinedCommitUnknown | None:
        """Return one status-only outcome from a prior generation.

        Eligibility is intentionally narrow: the host, session, canonical
        root, and workspace marker must be identical, and the inactive scope
        must have been fenced *only* by an increasing host generation. No API
        in this class can make the returned old operation sendable again.
        """

        with self._lock:
            self._require_open()
            row = self._connection.execute(
                self._RESOLVABLE_QUARANTINED_UNKNOWN_SQL +
                " ORDER BY original.scope_id, operation.journal_seq LIMIT 1"
            ).fetchone()
        return (
            _quarantined_unknown_from_row(
                row, resolver_scope_id=int(row["resolver_scope_id"])
            )
            if row is not None
            else None
        )

    def resolve_quarantined_commit_unknown_found(
        self,
        *,
        original_scope_id: int,
        mutation_id: str,
        request_digest: str,
        remote_generation: int | None = None,
        remote_manifest_digest: str | None = None,
        remote_entry_digest: str | None = None,
        receipt: Any | None = None,
    ) -> OperationReceipt:
        """Record a status-proven commit without replaying the old request."""

        original_scope_id = _positive_id("original_scope_id", original_scope_id)
        mutation_id = _mutation_id(mutation_id)
        request_digest = _digest(
            "request digest", request_digest, required=True
        )  # type: ignore[assignment]
        if remote_generation is not None:
            remote_generation = _generation(remote_generation)
        remote_manifest_digest = _digest(
            "remote manifest digest", remote_manifest_digest
        )
        remote_entry_digest = _digest("remote entry digest", remote_entry_digest)
        receipt_json = _bounded_json(receipt, _MAX_RECEIPT_JSON_BYTES, "receipt")
        assert request_digest is not None
        now = time.time_ns()
        with self._transaction():
            operation, _resolver_scope_id = self._quarantined_unknown_for_resolution(
                original_scope_id, mutation_id, request_digest, allow_resolved=True
            )
            was_unknown = (
                str(operation["state"]) == "quarantined"
                and bool(operation["commit_unknown"])
            )
            row = self._ack_operation_locked(
                original_scope_id,
                operation,
                remote_generation=remote_generation,
                remote_manifest_digest=remote_manifest_digest,
                remote_entry_digest=remote_entry_digest,
                receipt_json=receipt_json,
                now=now,
            )
            if was_unknown:
                self._adjust_direct_dependents(
                    original_scope_id, mutation_id, delta=-1, now_ns=now
                )
        return _receipt_from_row(row)

    def resolve_quarantined_commit_unknown_missing(
        self,
        *,
        original_scope_id: int,
        mutation_id: str,
        request_digest: str,
        reason: str,
        preserve_as_conflict: bool = False,
    ) -> PendingOperation:
        """Retire a status-proven miss without ever requeueing the old request.

        ``preserve_as_conflict`` retains an unreconstructable PUT stage as
        explicit user-recovery evidence. Both outcomes are terminal and clear
        only the ambiguity bit; the frozen request digest and original scope
        identity remain durable.
        """

        original_scope_id = _positive_id("original_scope_id", original_scope_id)
        mutation_id = _mutation_id(mutation_id)
        request_digest = _digest(
            "request digest", request_digest, required=True
        )  # type: ignore[assignment]
        reason = _bounded_text("reason", reason, _MAX_ERROR_BYTES - 32)
        if not isinstance(preserve_as_conflict, bool):
            raise ValueError("preserve_as_conflict must be a boolean.")
        assert request_digest is not None
        outcome_reason = "remote_outcome_not_found:" + reason
        now = time.time_ns()
        with self._transaction():
            operation, _resolver_scope_id = self._quarantined_unknown_for_resolution(
                original_scope_id, mutation_id, request_digest, allow_resolved=True
            )
            state = str(operation["state"])
            if not bool(operation["commit_unknown"]):
                expected_state = "conflict" if preserve_as_conflict else "quarantined"
                if state == expected_state and str(operation["last_error"] or "") == outcome_reason:
                    return _operation_from_row(operation)
                raise StateError("The quarantined remote outcome was resolved differently.")
            if preserve_as_conflict:
                existing = self._connection.execute(
                    """SELECT 1 FROM conflicts
                       WHERE scope_id = ? AND mutation_id = ? AND reason = ? LIMIT 1""",
                    (original_scope_id, mutation_id, outcome_reason),
                ).fetchone()
                if existing is None:
                    self._connection.execute(
                        """INSERT INTO conflicts(
                               scope_id, mutation_id, path, reason,
                               base_digest, local_digest, staged_path,
                               recorded_at_ns
                           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            original_scope_id,
                            mutation_id,
                            operation["path"],
                            outcome_reason,
                            operation["expected_source_digest"],
                            operation["staged_digest"],
                            operation["staged_path"],
                            now,
                        ),
                    )
            next_state = "conflict" if preserve_as_conflict else "quarantined"
            self._connection.execute(
                """UPDATE pending_operations
                   SET state = ?, commit_unknown = 0, commit_batch_id = NULL, last_error = ?,
                       claimed_at_ns = NULL, next_attempt_at_ns = NULL,
                       ready_at_ns = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND mutation_id = ?
                     AND state = 'quarantined' AND commit_unknown = 1
                     AND request_digest = ?""",
                (
                    next_state,
                    outcome_reason,
                    now,
                    now,
                    original_scope_id,
                    mutation_id,
                    request_digest,
                ),
            )
            self._adjust_direct_dependents(
                original_scope_id, mutation_id, delta=-1, now_ns=now
            )
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def mark_operation_commit_unknown(
        self,
        mutation_id: str,
        *,
        request_digest: str,
        now_ns: int | None = None,
    ) -> PendingOperation:
        """Freeze one exact request and fence it immediately before mutate POST."""

        mutation_id = _mutation_id(mutation_id)
        request_digest = _digest(
            "request digest", request_digest, required=True
        )  # type: ignore[assignment]
        assert request_digest is not None
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if current is None:
                raise StateError("The pending operation is not in the active authority epoch.")
            frozen_digest = current["request_digest"]
            if frozen_digest is not None and str(frozen_digest) != request_digest:
                raise StateError(
                    "The operation is already bound to a different mutation request."
                )
            if int(current["commit_unknown"]) == 1:
                if str(current["state"]) not in _NONTERMINAL_OPERATION_STATES:
                    raise StateError("A terminal operation cannot retain an unknown commit.")
                if frozen_digest is None:
                    raise StateError("An unknown commit has no frozen request digest.")
                return _operation_from_row(current)
            if str(current["state"]) != "inflight" or int(current["blocked_count"]) != 0:
                raise StateError("Only the exact claimed operation can enter commit_unknown.")
            try:
                cursor = self._connection.execute(
                    """UPDATE pending_operations
                       SET commit_unknown = 1, request_digest = ?,
                           ready_at_ns = ?, updated_at_ns = ?
                       WHERE mutation_id = ? AND scope_id = ?
                         AND state = 'inflight' AND commit_unknown = 0""",
                    (request_digest, now, now, mutation_id, scope_id),
                )
            except sqlite3.IntegrityError as error:
                raise StateError(
                    "Another mutation already owns the active commit_unknown fence."
                ) from error
            if cursor.rowcount != 1:
                raise StateError("The operation changed before its commit fence was durable.")
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def clear_operation_commit_unknown_for_retry(
        self,
        mutation_id: str,
        *,
        reason: str,
        now_ns: int | None = None,
        preserve_batch_id: bool = False,
        renew_v2_cohort: bool = False,
        expected_v2_batch_id: str | None = None,
        expected_v2_request_digest: str | None = None,
    ) -> PendingOperation:
        """Clear the fence only after authoritative proof no commit exists.

        The operation becomes queued in the same transaction.  Resending is a
        later coordinator turn, so status readback and mutation submission can
        never consume one signed-control tick together.
        Exact v2 retries retain the original batch identity when requested;
        the default continues to release the batch fence for older callers.
        An authoritative per-op v2 rejection may instead renew the cohort
        attempt and release its request digest, preserving the journal ID.
        Never use that option for an unknown outcome or a received operation.
        """

        mutation_id = _mutation_id(mutation_id)
        if not isinstance(preserve_batch_id, bool):
            raise ValueError("preserve_batch_id must be a boolean.")
        if not isinstance(renew_v2_cohort, bool) or (renew_v2_cohort and preserve_batch_id):
            raise ValueError("renew_v2_cohort must be boolean and cannot preserve the old batch.")
        if renew_v2_cohort:
            expected_v2_batch_id = _mutation_id(expected_v2_batch_id)
            expected_v2_request_digest = _digest(
                "expected v2 request digest", expected_v2_request_digest, required=True
            )
        elif expected_v2_batch_id is not None or expected_v2_request_digest is not None:
            raise ValueError("Expected v2 identity requires renew_v2_cohort.")
        reason = _bounded_text("reason", reason, _MAX_ERROR_BYTES)
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if current is None:
                raise StateError("The pending operation is not in the active authority epoch.")
            if int(current["commit_unknown"]) == 0:
                if str(current["state"]) == "queued" and current["last_error"] == reason:
                    return _operation_from_row(current)
                raise StateError("The operation has no unknown commit to clear.")
            if str(current["state"]) not in _NONTERMINAL_OPERATION_STATES:
                raise StateError("A terminal operation cannot be retried.")
            if renew_v2_cohort and (
                current["commit_batch_id"] != expected_v2_batch_id
                or current["request_digest"] != expected_v2_request_digest
            ):
                raise StateError("The rejected v2 cohort is no longer this operation's frozen attempt.")
            if renew_v2_cohort and (
                current["commit_batch_id"] is None
                or self._connection.execute(
                    "SELECT 1 FROM operation_receipts WHERE mutation_id = ?", (mutation_id,)
                ).fetchone() is not None
            ):
                raise StateError("Only an unreceived v2 cohort member may renew its attempt.")
            self._connection.execute(
                """UPDATE pending_operations
                   SET commit_unknown = 0,
                       commit_batch_id = CASE WHEN ? THEN ? WHEN ? THEN commit_batch_id ELSE NULL END,
                       request_digest = CASE WHEN ? THEN NULL ELSE request_digest END,
                       state = 'queued', last_error = ?,
                       claimed_at_ns = NULL, next_attempt_at_ns = NULL,
                       ready_at_ns = ?, updated_at_ns = ?
                   WHERE mutation_id = ? AND scope_id = ? AND commit_unknown = 1""",
                (int(renew_v2_cohort), str(uuid.uuid4()) if renew_v2_cohort else None,
                 int(preserve_batch_id), int(renew_v2_cohort), reason, now, now, mutation_id, scope_id),
            )
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def release_unroutable_commit_fence(
        self,
        mutation_id: str,
        *,
        expected_request_digest: str,
        reason: str,
        now_ns: int | None = None,
    ) -> PendingOperation:
        """Release a fence frozen by a commit route the server does not have.

        ``request_digest`` is normally kept across a retry on purpose: one
        mutation id may only ever carry one request body, so a readback that
        says found=false still may not license resending a DIFFERENT document
        under the same id.  That invariant assumes both attempts hash the same
        way.  They do not.  The v1 lane freezes
        ``_mutation_request_digest`` (a path-mutation document) and the v2
        lane freezes ``_fabric_v2_request_digest`` (an ops array) into this one
        column, so a v2 fence left behind after v2 latches off is unmatchable
        by v1 forever -- the operation can never commit again on any lane.

        A 404 is the one signal that discharges the invariant rather than
        weakening it: the route does not exist, so no handler ran and no body
        under this id was ever seen.  The fence is therefore released whole,
        digest included, but only for the exact digest we sent on the
        unroutable route and only while no receipt proves the server saw it.
        """

        mutation_id = _mutation_id(mutation_id)
        expected_request_digest = _digest(
            "expected request digest", expected_request_digest, required=True
        )  # type: ignore[assignment]
        reason = _bounded_text("reason", reason, _MAX_ERROR_BYTES)
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if current is None:
                raise StateError("The pending operation is not in the active authority epoch.")
            if str(current["state"]) not in _NONTERMINAL_OPERATION_STATES:
                raise StateError("A terminal operation cannot be retried.")
            if self._connection.execute(
                "SELECT 1 FROM operation_receipts WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone() is not None:
                raise StateError("A received operation cannot release its fence.")
            frozen_digest = current["request_digest"]
            if frozen_digest is None:
                # Already released; a repeated 404 in the same fallback must be
                # idempotent rather than tearing down an unrelated later fence.
                if str(current["state"]) == "queued" and current["last_error"] == reason:
                    return _operation_from_row(current)
                raise StateError("The operation has no frozen request to release.")
            if str(frozen_digest) != expected_request_digest:
                raise StateError(
                    "The operation is already bound to a different mutation request."
                )
            self._connection.execute(
                """UPDATE pending_operations
                   SET commit_unknown = 0, commit_batch_id = NULL, request_digest = NULL,
                       state = 'queued', last_error = ?,
                       claimed_at_ns = NULL, next_attempt_at_ns = NULL,
                       ready_at_ns = ?, updated_at_ns = ?
                   WHERE mutation_id = ? AND scope_id = ? AND request_digest = ?""",
                (reason, now, now, mutation_id, scope_id, expected_request_digest),
            )
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def rebase_precommit_operation_to_current_head(
        self,
        mutation_id: str,
        *,
        expected_request_digest: str,
        expected_marker: str,
        now_ns: int | None = None,
    ) -> PendingOperation | None:
        """Rebase one proven-uncommitted mutation across disjoint remote work.

        A BASE_DIVERGED response proves that the frozen request was rejected
        before publication.  After the coordinator installs a signed full
        manifest, this transaction advances the operation only when every
        path precondition still names the exact same file or absence.  A path
        mismatch is an ordinary user conflict and returns ``None``; broken
        journal/fence invariants fail closed with ``StateError``.
        """

        mutation_id = _mutation_id(mutation_id)
        expected_request_digest = _digest(
            "expected request digest", expected_request_digest, required=True
        )  # type: ignore[assignment]
        expected_marker = _bounded_text(
            "expected marker", expected_marker, _MAX_ERROR_BYTES
        )
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        assert expected_request_digest is not None

        with self._transaction():
            scope_id = self._active_scope_id()
            operation = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE scope_id = ? AND mutation_id = ?""",
                (scope_id, mutation_id),
            ).fetchone()
            if operation is None:
                raise StateError(
                    "The pending operation is not in the active authority epoch."
                )
            if (
                str(operation["state"]) != "retry"
                or int(operation["commit_unknown"]) != 0
                or int(operation["blocked_count"]) != 0
                or operation["last_error"] != expected_marker
                or operation["request_digest"] != expected_request_digest
            ):
                raise StateError(
                    "The precommit-rejected operation changed before rebase."
                )
            receipt = self._connection.execute(
                "SELECT 1 FROM operation_receipts WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone()
            if receipt is not None:
                raise StateError("A received operation cannot be rebased.")
            if operation["base_generation"] is None:
                raise StateError("A base-diverged operation has no frozen base.")
            if bool(operation["directory_rename"]):
                return None

            head = self._connection.execute(
                """SELECT generation, digest FROM remote_manifest_heads
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            if head is None:
                raise StateError("The signed remote manifest is unavailable for rebase.")
            old_generation = int(operation["base_generation"])
            new_generation = int(head["generation"])
            new_digest = head["digest"]
            v2 = operation["base_digest"] is None and new_digest is None
            if not v2 and operation["base_digest"] is None:
                raise StateError("A base-diverged operation has no frozen base.")
            if new_generation < old_generation or (
                not v2 and new_generation == old_generation
            ):
                raise StateError(
                    "The signed remote head did not advance beyond the rejected base."
                )

            def expectation_matches(path: str, expected_digest: str | None) -> bool:
                exact = self._connection.execute(
                    """SELECT digest FROM remote_entries
                       WHERE scope_id = ? AND path = ?""",
                    (scope_id, path),
                ).fetchone()
                descendant = path + "/"
                child = self._connection.execute(
                    """SELECT 1 FROM remote_entries
                       WHERE scope_id = ? AND path >= ? AND path < ? LIMIT 1""",
                    (scope_id, descendant, path + "0"),
                ).fetchone()
                if child is not None:
                    return False
                if expected_digest is None:
                    return exact is None
                return exact is not None and exact["digest"] == expected_digest

            if not expectation_matches(
                str(operation["path"]), operation["expected_source_digest"]
            ):
                return None
            if str(operation["kind"]) == "rename":
                destination_path = operation["destination_path"]
                if destination_path is None or not expectation_matches(
                    str(destination_path),
                    operation["expected_destination_digest"],
                ):
                    return None

            cursor = self._connection.execute(
                """UPDATE pending_operations
                   SET base_generation = ?, base_digest = ?,
                       request_digest = NULL, state = 'queued', last_error = NULL,
                       claimed_at_ns = NULL, next_attempt_at_ns = NULL,
                       ready_at_ns = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND mutation_id = ?
                     AND state = 'retry' AND commit_unknown = 0
                     AND request_digest = ? AND last_error = ?""",
                (
                    new_generation,
                    new_digest,
                    now,
                    now,
                    scope_id,
                    mutation_id,
                    expected_request_digest,
                    expected_marker,
                ),
            )
            if cursor.rowcount != 1:  # pragma: no cover - IMMEDIATE transaction fences this
                raise StateError(
                    "The precommit-rejected operation changed during rebase."
                )
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def rebase_never_sent_operation_to_current_head(
        self, mutation_id: str, *, now_ns: int | None = None
    ) -> PendingOperation | None:
        """Bind one never-signed operation to the current head before sending.

        A burst of local writes is journaled against the head observed at
        write time; each of the host's own commits then advances that head,
        so every later operation would be rejected as BASE_DIVERGED and pay a
        signed refresh before its rebase. The local manifest already reflects
        the host's own acked commits, so when the operation's exact path
        preimage still matches the current head it can be rebound locally.
        Only operations the control plane has never seen (no frozen request
        digest, no receipt, not commit-unknown) are eligible; anything else is
        left byte-for-byte unchanged and ``None`` is returned.
        """

        mutation_id = _mutation_id(mutation_id)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            operation = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE scope_id = ? AND mutation_id = ?""",
                (scope_id, mutation_id),
            ).fetchone()
            if (
                operation is None
                or str(operation["state"]) not in ("queued", "inflight", "retry")
                or int(operation["commit_unknown"]) != 0
                or operation["request_digest"] is not None
                or int(operation["blocked_count"]) != 0
                or int(operation["directory_rename"]) != 0
                or operation["base_generation"] is None
                or operation["base_digest"] is None
            ):
                return None
            if self._connection.execute(
                "SELECT 1 FROM operation_receipts WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone() is not None:
                return None
            load = self._connection.execute(
                "SELECT 1 FROM remote_manifest_loads WHERE scope_id = ? LIMIT 1",
                (scope_id,),
            ).fetchone()
            if load is not None:
                return None
            head = self._connection.execute(
                """SELECT generation, digest FROM remote_manifest_heads
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            if head is None:
                return None
            new_generation = int(head["generation"])
            new_digest = str(head["digest"])
            if int(operation["base_generation"]) >= new_generation:
                return None

            def expectation_matches(path: str, expected_digest: str | None) -> bool:
                exact = self._connection.execute(
                    """SELECT digest FROM remote_entries
                       WHERE scope_id = ? AND path = ?""",
                    (scope_id, path),
                ).fetchone()
                child = self._connection.execute(
                    """SELECT 1 FROM remote_entries
                       WHERE scope_id = ? AND path >= ? AND path < ? LIMIT 1""",
                    (scope_id, path + "/", path + "0"),
                ).fetchone()
                if child is not None:
                    return False
                if expected_digest is None:
                    return exact is None
                return exact is not None and exact["digest"] == expected_digest

            if not expectation_matches(
                str(operation["path"]), operation["expected_source_digest"]
            ):
                return None
            if str(operation["kind"]) == "rename":
                destination_path = operation["destination_path"]
                if destination_path is None or not expectation_matches(
                    str(destination_path), operation["expected_destination_digest"]
                ):
                    return None
            updated = self._connection.execute(
                """UPDATE pending_operations
                   SET base_generation = ?, base_digest = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND mutation_id = ?
                     AND commit_unknown = 0 AND request_digest IS NULL
                     AND blocked_count = 0""",
                (
                    new_generation,
                    new_digest,
                    now_ns if now_ns is not None else time.time_ns(),
                    scope_id,
                    mutation_id,
                ),
            )
            if updated.rowcount != 1:
                return None
            self._connection.commit()
            return self.get_operation(mutation_id)

    def rebase_compatible_never_sent_operations_to_current_head(
        self,
        refreshed_mutation_id: str,
        *,
        limit: int,
        now_ns: int | None = None,
    ) -> tuple[PendingOperation, ...]:
        """Rebase a bounded disjoint burst from one signed manifest refresh.

        A full-manifest refresh is expensive.  When it proves that several
        later, never-sent operations still have their exact path preimages,
        advance those rows to the same head as the operation whose
        BASE_DIVERGED rejection caused the refresh. No dependencies are added,
        so one slow operation never creates head-of-line blocking.

        Only pristine queued rows are eligible: no attempt, frozen request,
        receipt, active dependency, or directory rename may exist.  Every
        source/destination expectation is checked against the complete signed
        manifest and every selected namespace is disjoint from the burst.
        Keyset pages inspect at most 4,096 eligible journal rows so early
        incompatibilities cannot consume the output limit while work remains
        strictly bounded. Incompatible rows are left byte-for-byte unchanged.
        """

        refreshed_mutation_id = _mutation_id(refreshed_mutation_id)
        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_BASE_DIVERGED_REBASE_BATCH
        ):
            raise ValueError(
                f"limit must be between 1 and {_MAX_BASE_DIVERGED_REBASE_BATCH}."
            )
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")

        with self._transaction():
            scope_id = self._active_scope_id()
            refreshed = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE scope_id = ? AND mutation_id = ?""",
                (scope_id, refreshed_mutation_id),
            ).fetchone()
            if refreshed is None:
                raise StateError(
                    "The refreshed operation is not in the active authority epoch."
                )
            if (
                str(refreshed["state"]) != "queued"
                or int(refreshed["commit_unknown"]) != 0
                or refreshed["request_digest"] is not None
                or refreshed["base_generation"] is None
                or refreshed["base_digest"] is None
            ):
                raise StateError("The batch root is not freshly rebased.")
            head = self._connection.execute(
                """SELECT generation, digest FROM remote_manifest_heads
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            if head is None:
                raise StateError("The signed remote manifest is unavailable for rebase.")
            load = self._connection.execute(
                "SELECT 1 FROM remote_manifest_loads WHERE scope_id = ? LIMIT 1",
                (scope_id,),
            ).fetchone()
            if load is not None:
                raise StateError("The signed remote manifest refresh is incomplete.")
            new_generation = int(head["generation"])
            new_digest = str(head["digest"])
            if (
                int(refreshed["base_generation"]) != new_generation
                or str(refreshed["base_digest"]) != new_digest
            ):
                raise StateError("The batch root is not bound to the current head.")

            def expectation_matches(path: str, expected_digest: str | None) -> bool:
                exact = self._connection.execute(
                    """SELECT digest FROM remote_entries
                       WHERE scope_id = ? AND path = ?""",
                    (scope_id, path),
                ).fetchone()
                descendant = path + "/"
                child = self._connection.execute(
                    """SELECT 1 FROM remote_entries
                       WHERE scope_id = ? AND path >= ? AND path < ? LIMIT 1""",
                    (scope_id, descendant, path + "0"),
                ).fetchone()
                if child is not None:
                    return False
                if expected_digest is None:
                    return exact is None
                return exact is not None and exact["digest"] == expected_digest

            def affected_paths(operation: sqlite3.Row) -> tuple[str, ...]:
                destination = operation["destination_path"]
                return (
                    (str(operation["path"]), str(destination))
                    if destination is not None
                    else (str(operation["path"]),)
                )

            selected_namespaces = list(affected_paths(refreshed))

            def namespace_is_disjoint(paths: tuple[str, ...]) -> bool:
                return not any(
                    left == right
                    or left.startswith(right + "/")
                    or right.startswith(left + "/")
                    for left in paths
                    for right in selected_namespaces
                )

            rebased: list[PendingOperation] = []
            after_journal_seq = int(refreshed["journal_seq"])
            scanned = 0
            while (
                len(rebased) < limit
                and scanned < _MAX_BASE_DIVERGED_REBASE_SCAN
            ):
                page_limit = min(
                    _BASE_DIVERGED_REBASE_SCAN_PAGE,
                    _MAX_BASE_DIVERGED_REBASE_SCAN - scanned,
                )
                candidates = self._connection.execute(
                    """SELECT operation.* FROM pending_operations AS operation
                       INDEXED BY pending_queued_ready
                       WHERE operation.scope_id = ?
                         AND operation.journal_seq > ?
                         AND operation.state = 'queued'
                         AND operation.attempt_count = 0
                         AND operation.commit_unknown = 0
                         AND operation.request_digest IS NULL
                         AND operation.blocked_count = 0
                         AND operation.directory_rename = 0
                         AND operation.base_generation IS NOT NULL
                         AND operation.base_digest IS NOT NULL
                         AND operation.base_generation < ?
                         AND NOT EXISTS (
                           SELECT 1 FROM operation_receipts AS receipt
                           WHERE receipt.mutation_id = operation.mutation_id
                         )
                       ORDER BY operation.journal_seq LIMIT ?""",
                    (
                        scope_id,
                        after_journal_seq,
                        new_generation,
                        page_limit,
                    ),
                ).fetchall()
                if not candidates:
                    break
                scanned += len(candidates)
                after_journal_seq = int(candidates[-1]["journal_seq"])

                for candidate in candidates:
                    paths = affected_paths(candidate)
                    if not namespace_is_disjoint(paths):
                        continue
                    if not expectation_matches(
                        str(candidate["path"]),
                        candidate["expected_source_digest"],
                    ):
                        continue
                    if str(candidate["kind"]) == "rename":
                        destination_path = candidate["destination_path"]
                        if destination_path is None or not expectation_matches(
                            str(destination_path),
                            candidate["expected_destination_digest"],
                        ):
                            continue

                    mutation_id = str(candidate["mutation_id"])
                    cursor = self._connection.execute(
                        """UPDATE pending_operations
                           SET base_generation = ?, base_digest = ?, updated_at_ns = ?
                           WHERE scope_id = ? AND mutation_id = ?
                             AND state = 'queued' AND attempt_count = 0
                             AND commit_unknown = 0 AND request_digest IS NULL
                             AND blocked_count = 0""",
                        (
                            new_generation,
                            new_digest,
                            now,
                            scope_id,
                            mutation_id,
                        ),
                    )
                    if cursor.rowcount != 1:  # pragma: no cover - IMMEDIATE transaction fences this
                        raise StateError(
                            "A never-sent operation changed during batch rebase."
                        )
                    row = self._connection.execute(
                        "SELECT * FROM pending_operations WHERE mutation_id = ?",
                        (mutation_id,),
                    ).fetchone()
                    assert row is not None
                    rebased.append(_operation_from_row(row))
                    selected_namespaces.extend(paths)
                    if len(rebased) >= limit:
                        break
        return tuple(rebased)

    def list_operation_dependencies(self, mutation_id: str) -> tuple[str, ...]:
        """Return every durable predecessor of one mutation."""

        mutation_id = _mutation_id(mutation_id)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT predecessor_mutation_id FROM operation_dependencies
                   WHERE scope_id = ? AND mutation_id = ?
                   ORDER BY predecessor_mutation_id""",
                (scope_id, mutation_id),
            ).fetchall()
        return tuple(str(row["predecessor_mutation_id"]) for row in rows)

    def list_nonterminal_source_operations(
        self, path: str
    ) -> tuple[PendingOperation, ...]:
        """Return active operations whose source is one exact path.

        This deliberately uses the source-path journal index instead of the
        broader namespace/prefix scanners.  Native deletion uses it to retire
        unpublished PUTs for the deleted inode without walking unrelated work
        or mistaking a rename destination for staged source bytes.
        """

        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            rows = self._connection.execute(
                """SELECT * FROM pending_operations
                   INDEXED BY pending_source_path_order
                   WHERE scope_id = ? AND path = ?
                     AND state IN ('queued', 'inflight', 'retry')
                   ORDER BY journal_seq""",
                (self._active_scope_id(), path),
            ).fetchall()
        return tuple(_operation_from_row(row) for row in rows)

    def conflict_operations_for_paths(
        self, paths: Iterable[str], reason: str
    ) -> int:
        """Fail closed every nonterminal operation touching exact paths.

        Source and destination lookups are separately index-driven; no OR scan
        is introduced into the large journal.  Conflict evidence and all stage
        references remain durable, while direct successors are unblocked just
        as they are for any other terminal predecessor transition.
        """

        normalized = tuple(sorted(set(_canonical_path(path) for path in paths)))
        if not normalized or len(normalized) > 256:
            raise ValueError("paths must contain between 1 and 256 exact paths.")
        reason = _bounded_text("reason", reason, _MAX_ERROR_BYTES)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            self._connection.execute(
                """CREATE TEMP TABLE IF NOT EXISTS fabric_collision_operations (
                       mutation_id TEXT PRIMARY KEY,
                       collision_path TEXT NOT NULL
                   ) WITHOUT ROWID"""
            )
            self._connection.execute("DELETE FROM fabric_collision_operations")
            for path in normalized:
                self._connection.execute(
                    """INSERT OR IGNORE INTO fabric_collision_operations(
                           mutation_id, collision_path
                       )
                       SELECT mutation_id, ?
                       FROM pending_operations INDEXED BY pending_source_path_order
                       WHERE scope_id = ? AND path = ?
                         AND state IN ('queued', 'inflight', 'retry')""",
                    (path, scope_id, path),
                )
                self._connection.execute(
                    """INSERT OR IGNORE INTO fabric_collision_operations(
                           mutation_id, collision_path
                       )
                       SELECT mutation_id, ?
                       FROM pending_operations INDEXED BY pending_destination_path_order
                       WHERE scope_id = ? AND destination_path = ?
                         AND state IN ('queued', 'inflight', 'retry')""",
                    (path, scope_id, path),
                )
            count_row = self._connection.execute(
                "SELECT COUNT(*) AS count FROM fabric_collision_operations"
            ).fetchone()
            assert count_row is not None
            affected = int(count_row["count"])
            if affected:
                self._connection.execute(
                    """INSERT INTO conflicts(
                           scope_id, mutation_id, path, reason, base_digest,
                           local_digest, remote_digest, remote_generation,
                           staged_path, recorded_at_ns
                       )
                       SELECT operation.scope_id, operation.mutation_id,
                              collision.collision_path, ?, operation.base_digest,
                              operation.staged_digest, NULL,
                              operation.base_generation, operation.staged_path, ?
                       FROM fabric_collision_operations AS collision
                       JOIN pending_operations AS operation
                         ON operation.mutation_id = collision.mutation_id""",
                    (reason, now),
                )
                self._connection.execute(
                    """WITH reductions AS (
                         SELECT dependency.mutation_id, COUNT(*) AS count
                         FROM operation_dependencies AS dependency
                         JOIN fabric_collision_operations AS collision
                           ON collision.mutation_id = dependency.predecessor_mutation_id
                         WHERE dependency.scope_id = ?
                         GROUP BY dependency.mutation_id
                       )
                       UPDATE pending_operations
                       SET blocked_count = MAX(
                             0,
                             blocked_count - COALESCE((
                               SELECT count FROM reductions
                               WHERE reductions.mutation_id = pending_operations.mutation_id
                             ), 0)
                           ),
                           updated_at_ns = ?
                       WHERE scope_id = ?
                         AND mutation_id IN (SELECT mutation_id FROM reductions)""",
                    (scope_id, now, scope_id),
                )
                self._connection.execute(
                    """UPDATE pending_operations
                       SET state = 'conflict', claimed_at_ns = NULL,
                           next_attempt_at_ns = NULL, commit_unknown = 0, commit_batch_id = NULL,
                           ready_at_ns = ?,
                           last_error = ?, updated_at_ns = ?
                       WHERE scope_id = ?
                         AND mutation_id IN (
                           SELECT mutation_id FROM fabric_collision_operations
                         )""",
                    (now, reason, now, scope_id),
                )
            self._connection.execute("DELETE FROM fabric_collision_operations")
        return affected

    def list_operations(
        self,
        *,
        states: Sequence[OperationState | str] | None = None,
        limit: int = 10_000,
        after: tuple[int, str] | None = None,
    ) -> tuple[PendingOperation, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        selected_states = tuple(states) if states is not None else tuple(_OPERATION_STATES)
        if not selected_states or any(state not in _OPERATION_STATES for state in selected_states):
            raise ValueError("states contains an unknown operation state.")
        if after is not None:
            if (
                not isinstance(after, tuple)
                or len(after) != 2
                or isinstance(after[0], bool)
                or not isinstance(after[0], int)
                or after[0] < 0
            ):
                raise ValueError("after must be a (journal_seq, mutation_id) tuple.")
            after = (after[0], _mutation_id(after[1]))
        placeholders = ",".join("?" for _ in selected_states)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            if after is None:
                rows = self._connection.execute(
                    f"""SELECT * FROM pending_operations
                        WHERE scope_id = ? AND state IN ({placeholders})
                        ORDER BY journal_seq LIMIT ?""",
                    (scope_id, *selected_states, limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    f"""SELECT * FROM pending_operations
                        WHERE scope_id = ? AND state IN ({placeholders})
                          AND (
                            journal_seq > ?
                            OR (journal_seq = ? AND mutation_id > ?)
                          )
                        ORDER BY journal_seq LIMIT ?""",
                    (
                        scope_id,
                        *selected_states,
                        after[0],
                        after[0],
                        after[1],
                        limit,
                    ),
                ).fetchall()
        return tuple(_operation_from_row(row) for row in rows)

    def pending_quota_delta(
        self, *, limit: int = _MAX_QUOTA_PROJECTION_OPERATIONS
    ) -> int:
        """Project the bounded nonterminal journal's byte delta.

        The first read (and every explicit rebuild event) replays authoritative
        rows. Ordinary inserts then advance the cached path projection from a
        bounded durable event cursor in O(changes), so N distinct close-time
        handoffs do not perform 1+2+...+N journal work. Restart, event pruning,
        cross-process writes, coalesces, terminal transitions, remote manifest
        changes, and directory-renames all fall back to one exact replay.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= 100_000
        ):
            raise ValueError("limit must be between 1 and 100000.")
        with self._read_transaction():
            scope_id = self._active_scope_id()
            cached = self._quota_projection_cache
            tail_row = self._connection.execute(
                "SELECT COALESCE(MAX(event_id), 0) FROM fabric_quota_events"
            ).fetchone()
            assert tail_row is not None
            event_tail = int(tail_row[0])
            if (
                cached is not None
                and cached.scope_id == scope_id
                and cached.limit == limit
            ):
                if cached.last_event_id == event_tail:
                    return cached.delta_bytes
                retained_row = self._connection.execute(
                    "SELECT MIN(event_id) FROM fabric_quota_events"
                ).fetchone()
                retained = (
                    int(retained_row[0])
                    if retained_row is not None and retained_row[0] is not None
                    else event_tail + 1
                )
                if cached.last_event_id >= retained - 1:
                    events = self._connection.execute(
                        """SELECT * FROM fabric_quota_events
                           WHERE event_id > ? ORDER BY event_id LIMIT 10001""",
                        (cached.last_event_id,),
                    ).fetchall()
                    if len(events) <= 10_000 and (
                        not events or int(events[-1]["event_id"]) == event_tail
                    ):
                        try:
                            if self._advance_quota_projection_locked(
                                cached, events
                            ):
                                cached.last_event_id = event_tail
                                return cached.delta_bytes
                        except (KeyError, TypeError, ValueError, StateError):
                            self._quota_projection_cache = None
                            raise
            rebuilt = self._replay_pending_quota_delta_locked(
                scope_id, limit, event_tail
            )
            self._quota_projection_cache = rebuilt
            return rebuilt.delta_bytes

    def _replay_pending_quota_delta_locked(
        self, scope_id: int, limit: int, event_tail: int | None = None
    ) -> _QuotaProjectionCache:
        """Replay one consistent journal snapshot while the DB lock is held."""

        if event_tail is None:
            row = self._connection.execute(
                "SELECT COALESCE(MAX(event_id), 0) FROM fabric_quota_events"
            ).fetchone()
            assert row is not None
            event_tail = int(row[0])
        rows = self._connection.execute(
            """SELECT mutation_id, journal_seq, kind, path, destination_path,
                      staged_size, directory_rename
               FROM pending_operations
               WHERE scope_id = ? AND state IN ('queued','inflight','retry')
               ORDER BY journal_seq LIMIT ?""",
            (scope_id, limit + 1),
        ).fetchall()
        if len(rows) > limit:
            raise StateError(
                "The pending Fabric journal is too large for bounded quota admission."
            )
        intent_rows = self._connection.execute(
            """SELECT intent.transfer_id, intent.path,
                      intent.source_fingerprint,
                      intent.expected_remote_digest,
                      remote.size_bytes AS remote_size_bytes,
                      remote.digest AS remote_digest
               FROM local_transfer_intents AS intent
               LEFT JOIN remote_entries AS remote
                 ON remote.scope_id = intent.scope_id
                AND remote.path = intent.path
               WHERE intent.scope_id = ?
                 AND NOT EXISTS (
                   SELECT 1 FROM pending_operations AS operation
                   WHERE operation.scope_id = intent.scope_id
                     AND operation.mutation_id = intent.transfer_id
                 )
               LIMIT ?""",
            (scope_id, limit + 1),
        ).fetchall()
        if len(intent_rows) + len(rows) > limit:
            raise StateError(
                "The pending Fabric journal is too large for bounded quota admission."
            )
        intent_sizes: list[tuple[str, str, int]] = []
        for intent in intent_rows:
            try:
                source_bytes = _local_transfer_source_size(
                    str(intent["source_fingerprint"])
                )
            except ValueError as error:
                raise StateError(
                    "A durable source-backed upload has an invalid size."
                ) from error
            intent_sizes.append(
                (str(intent["transfer_id"]), str(intent["path"]), source_bytes)
            )
        if any(bool(row["directory_rename"]) for row in rows):
            # A source-backed transfer is not yet a pending_operations row,
            # so the directory-rename dependency scan cannot retarget it.
            # Its old remote path may move before the eventual PUT lands;
            # charge the complete source bytes rather than stale overwrite
            # or shrink credit. The server remains the final quota fence.
            conservative = sum(size for _, _, size in intent_sizes) + sum(
                int(row["staged_size"])
                for row in rows
                if str(row["kind"]) == "put"
                and row["staged_size"] is not None
            )
            return _QuotaProjectionCache(
                scope_id=scope_id,
                limit=limit,
                last_event_id=event_tail,
                item_count=len(rows) + len(intent_rows),
                delta_bytes=conservative,
                original={},
                projected={},
                directory_rename=True,
                operation_ids={str(row["mutation_id"]) for row in rows},
                intent_ids={item[0] for item in intent_sizes},
            )

        touched = sorted(
            {
                str(value)
                for row in rows
                for value in (row["path"], row["destination_path"])
                if value is not None
            }
            | {path for _, path, _ in intent_sizes}
        )
        original: dict[str, int] = {path: 0 for path in touched}
        for offset in range(0, len(touched), _SQLITE_PATH_BATCH):
            page = touched[offset : offset + _SQLITE_PATH_BATCH]
            placeholders = ",".join("?" for _ in page)
            remote_rows = self._connection.execute(
                f"""SELECT path, size_bytes FROM remote_entries
                     WHERE scope_id = ? AND path IN ({placeholders})""",
                (scope_id, *page),
            ).fetchall()
            original.update(
                {str(row["path"]): int(row["size_bytes"]) for row in remote_rows}
            )
        projected = dict(original)
        for row in rows:
            kind = str(row["kind"])
            path = str(row["path"])
            if kind == "put":
                staged_size = row["staged_size"]
                if staged_size is None:
                    raise StateError("A pending PUT is missing its staged size.")
                projected[path] = int(staged_size)
            elif kind == "delete":
                projected[path] = 0
            elif kind == "rename":
                destination = row["destination_path"]
                if destination is None:
                    raise StateError("A pending rename is missing its destination.")
                projected[str(destination)] = projected.get(path, 0)
                projected[path] = 0
            else:  # pragma: no cover - database constraint owns the closed set
                raise StateError("The pending journal contains an invalid operation.")
        # A newer source-backed intent and an older pending generation may
        # coexist at one path. Charge the largest realizable generation rather
        # than independently subtracting the committed overwrite twice.
        for _transfer_id, path, source_bytes in intent_sizes:
            projected[path] = max(projected.get(path, original[path]), source_bytes)
        return _QuotaProjectionCache(
            scope_id=scope_id,
            limit=limit,
            last_event_id=event_tail,
            item_count=len(rows) + len(intent_rows),
            delta_bytes=sum(projected.values()) - sum(original.values()),
            original=original,
            projected=projected,
            directory_rename=False,
            operation_ids={str(row["mutation_id"]) for row in rows},
            intent_ids={item[0] for item in intent_sizes},
        )

    def _advance_quota_projection_locked(
        self, cache: _QuotaProjectionCache, events: Sequence[sqlite3.Row]
    ) -> bool:
        """Apply append-only quota events; return false when replay is required."""

        active = [row for row in events if int(row["scope_id"]) == cache.scope_id]
        if not active:
            return True
        if cache.directory_rename or any(
            str(row["event_kind"]) == "rebuild" for row in active
        ):
            return False
        required_paths = {
            str(value)
            for row in active
            for value in (row["path"], row["destination_path"])
            if value is not None and str(value) not in cache.original
        }
        if required_paths:
            paths = sorted(required_paths)
            for offset in range(0, len(paths), _SQLITE_PATH_BATCH):
                page = paths[offset : offset + _SQLITE_PATH_BATCH]
                placeholders = ",".join("?" for _ in page)
                remote_rows = self._connection.execute(
                    f"""SELECT path, size_bytes FROM remote_entries
                         WHERE scope_id = ? AND path IN ({placeholders})""",
                    (cache.scope_id, *page),
                ).fetchall()
                found = {str(row["path"]): int(row["size_bytes"]) for row in remote_rows}
                for path in page:
                    base = found.get(path, 0)
                    cache.original[path] = base
                    cache.projected[path] = base

        def set_size(path: str, size: int) -> None:
            before = cache.projected[path] - cache.original[path]
            cache.projected[path] = size
            cache.delta_bytes += size - cache.original[path] - before

        for event in active:
            event_kind = str(event["event_kind"])
            mutation_id = str(event["mutation_id"])
            if event_kind == "intent_insert":
                if mutation_id in cache.operation_ids:
                    continue
                path = str(event["path"])
                source = event["source_fingerprint"]
                if source is None:
                    raise StateError(
                        "A durable source-backed upload has an invalid size."
                    )
                try:
                    size = _local_transfer_source_size(str(source))
                except ValueError as error:
                    raise StateError(
                        "A durable source-backed upload has an invalid size."
                    ) from error
                cache.intent_ids.add(mutation_id)
                cache.item_count += 1
                set_size(path, max(cache.projected[path], size))
            elif event_kind == "operation_insert":
                if bool(event["directory_rename"]):
                    return False
                operation_kind = str(event["operation_kind"])
                path = str(event["path"])
                if mutation_id in cache.intent_ids:
                    cache.intent_ids.remove(mutation_id)
                else:
                    cache.item_count += 1
                cache.operation_ids.add(mutation_id)
                if operation_kind == "put":
                    staged_size = event["staged_size"]
                    if staged_size is None:
                        raise StateError("A pending PUT is missing its staged size.")
                    set_size(path, int(staged_size))
                elif operation_kind == "delete":
                    set_size(path, 0)
                elif operation_kind == "rename":
                    destination = event["destination_path"]
                    if destination is None:
                        raise StateError("A pending rename is missing its destination.")
                    destination_path = str(destination)
                    source_size = cache.projected[path]
                    set_size(destination_path, source_size)
                    set_size(path, 0)
                else:
                    raise StateError(
                        "The pending journal contains an invalid operation."
                    )
            else:
                return False
            if cache.item_count > cache.limit:
                raise StateError(
                    "The pending Fabric journal is too large for bounded quota admission."
                )
        return True

    def list_quarantined_operations(self, *, limit: int = 10_000) -> tuple[PendingOperation, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        with self._lock:
            self._require_open()
            rows = self._connection.execute(
                """SELECT * FROM pending_operations WHERE state = 'quarantined'
                   ORDER BY updated_at_ns DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return tuple(_operation_from_row(row) for row in rows)

    def list_acked_operations_for_cleanup(
        self,
        *,
        limit: int = 256,
        after: tuple[int, str] | None = None,
    ) -> tuple[PendingOperation, ...]:
        """Keyset-page acknowledged rows across active and fenced epochs.

        An authority change must retain pending/conflict evidence, but an acked
        mutation is already finalized. Its receipt and stages are safe to GC
        even if cleanup did not run before the epoch was fenced, except while
        an unfinished conflict resolution still needs that exact ACK proof.
        """

        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        if after is not None:
            if (
                not isinstance(after, tuple)
                or len(after) != 2
                or isinstance(after[0], bool)
                or not isinstance(after[0], int)
                or after[0] < 0
            ):
                raise ValueError("after must be a (created_at_ns, mutation_id) tuple.")
            after = (after[0], _mutation_id(after[1]))
        with self._lock:
            self._require_open()
            if after is None:
                rows = self._connection.execute(
                    """SELECT operation.* FROM pending_operations AS operation
                       WHERE operation.state = 'acked'
                         AND NOT EXISTS (
                           SELECT 1 FROM operation_receipts AS receipt
                           JOIN authority_scopes AS authority ON authority.scope_id = receipt.scope_id
                           LEFT JOIN remote_manifest_heads AS head ON head.scope_id = receipt.scope_id
                           WHERE receipt.mutation_id = operation.mutation_id AND authority.active = 1
                             AND receipt.remote_manifest_digest IS NULL
                             AND receipt.remote_generation > COALESCE(head.generation, -1)
                         )
                         AND NOT (
                           operation.directory_rename = 1
                           AND operation.directory_rename_observed = 0
                         )
                         AND NOT EXISTS (
                           SELECT 1 FROM conflict_resolutions AS resolution
                           WHERE resolution.successor_mutation_id =
                                 operation.mutation_id
                             AND resolution.phase != 'completed'
                         )
                       ORDER BY operation.created_at_ns, operation.mutation_id
                       LIMIT ?""",
                    (limit,),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """SELECT operation.* FROM pending_operations AS operation
                       WHERE operation.state = 'acked'
                         AND NOT EXISTS (
                           SELECT 1 FROM operation_receipts AS receipt
                           JOIN authority_scopes AS authority ON authority.scope_id = receipt.scope_id
                           LEFT JOIN remote_manifest_heads AS head ON head.scope_id = receipt.scope_id
                           WHERE receipt.mutation_id = operation.mutation_id AND authority.active = 1
                             AND receipt.remote_manifest_digest IS NULL
                             AND receipt.remote_generation > COALESCE(head.generation, -1)
                         )
                         AND NOT (
                           operation.directory_rename = 1
                           AND operation.directory_rename_observed = 0
                         )
                         AND (
                           operation.created_at_ns > ?
                           OR (
                             operation.created_at_ns = ?
                             AND operation.mutation_id > ?
                           )
                         )
                         AND NOT EXISTS (
                           SELECT 1 FROM conflict_resolutions AS resolution
                           WHERE resolution.successor_mutation_id =
                                 operation.mutation_id
                             AND resolution.phase != 'completed'
                         )
                       ORDER BY operation.created_at_ns, operation.mutation_id
                       LIMIT ?""",
                    (after[0], after[0], after[1], limit),
                ).fetchall()
        return tuple(_operation_from_row(row) for row in rows)

    def list_resolved_conflict_operations_for_cleanup(
        self,
        *,
        limit: int = 256,
        after: tuple[int, str] | None = None,
    ) -> tuple[PendingOperation, ...]:
        """Keyset-page conflict operations whose complete history is resolved.

        The page spans active and fenced authority epochs. A row is eligible
        only when it owns at least one conflict and every associated conflict is
        resolved. Callers may therefore remove its stage-file family before
        invoking :meth:`finalize_resolved_conflict_cleanup`; unresolved evidence
        is never exposed as filesystem-GC work.
        """

        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100_000:
            raise ValueError("limit must be between 1 and 100000.")
        if after is not None:
            if (
                not isinstance(after, tuple)
                or len(after) != 2
                or isinstance(after[0], bool)
                or not isinstance(after[0], int)
                or after[0] < 0
            ):
                raise ValueError("after must be a (created_at_ns, mutation_id) tuple.")
            after = (after[0], _mutation_id(after[1]))
        keyset = ""
        parameters: tuple[Any, ...]
        if after is None:
            parameters = (limit,)
        else:
            keyset = """AND (
                         operation.created_at_ns > ?
                         OR (
                           operation.created_at_ns = ?
                           AND operation.mutation_id > ?
                         )
                       )"""
            parameters = (after[0], after[0], after[1], limit)
        with self._lock:
            self._require_open()
            rows = self._connection.execute(
                f"""SELECT operation.*
                    FROM pending_operations AS operation
                    INDEXED BY pending_acked_cleanup
                    WHERE operation.state = 'conflict'
                      {keyset}
                      AND EXISTS (
                        SELECT 1 FROM conflicts AS associated
                        INDEXED BY conflict_operation_cleanup
                        WHERE associated.mutation_id = operation.mutation_id
                          AND associated.scope_id = operation.scope_id
                      )
                      AND NOT EXISTS (
                        SELECT 1 FROM conflicts AS unresolved
                        INDEXED BY conflict_operation_cleanup
                        WHERE unresolved.mutation_id = operation.mutation_id
                          AND unresolved.scope_id = operation.scope_id
                          AND unresolved.resolved_at_ns IS NULL
                      )
                    ORDER BY operation.created_at_ns, operation.mutation_id
                    LIMIT ?""",
                parameters,
            ).fetchall()
        return tuple(_operation_from_row(row) for row in rows)

    def list_operation_stages(self, mutation_id: str) -> tuple[OperationStage, ...]:
        mutation_id = _mutation_id(mutation_id)
        with self._lock:
            self._require_open()
            rows = self._connection.execute(
                """SELECT * FROM operation_stages WHERE mutation_id = ?
                   ORDER BY stage_id""",
                (mutation_id,),
            ).fetchall()
        return tuple(_stage_from_row(row) for row in rows)

    def list_resolved_standalone_conflicts_for_cleanup(
        self, *, limit: int = 256, after_conflict_id: int = 0
    ) -> tuple[ConflictRecord, ...]:
        """Page resolved standalone evidence whose file can be garbage-collected.

        Operation-owned conflicts use the existing operation cleanup flow. A
        standalone conflict has no journal owner, so its conflict row itself is
        the durable GC handle until the caller removes the stage and finalizes
        the row below. The page intentionally spans active and inactive scopes.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_CONFLICT_WORK_PAGE
        ):
            raise ValueError(
                f"limit must be between 1 and {_MAX_CONFLICT_WORK_PAGE}."
            )
        if (
            isinstance(after_conflict_id, bool)
            or not isinstance(after_conflict_id, int)
            or after_conflict_id < 0
        ):
            raise ValueError("after_conflict_id must be non-negative.")
        with self._lock:
            self._require_open()
            rows = self._connection.execute(
                """SELECT * FROM conflicts INDEXED BY conflict_standalone_cleanup
                   WHERE mutation_id IS NULL AND resolved_at_ns IS NOT NULL
                     AND staged_path IS NOT NULL AND conflict_id > ?
                   ORDER BY conflict_id LIMIT ?""",
                (after_conflict_id, limit),
            ).fetchall()
        return tuple(_conflict_from_row(row) for row in rows)

    def finalize_resolved_standalone_conflict_cleanup(
        self, conflict_ids: Sequence[int]
    ) -> int:
        """Detach standalone stage handles after idempotent filesystem GC."""

        if len(conflict_ids) > 1_000:
            raise ValueError("At most 1000 standalone conflicts may be finalized.")
        normalized = tuple(dict.fromkeys(_positive_id("conflict_id", value) for value in conflict_ids))
        if not normalized:
            return 0
        detached = 0
        with self._transaction():
            for conflict_id in normalized:
                cursor = self._connection.execute(
                    """UPDATE conflicts SET staged_path = NULL
                       WHERE conflict_id = ? AND mutation_id IS NULL
                         AND resolved_at_ns IS NOT NULL
                         AND staged_path IS NOT NULL""",
                    (conflict_id,),
                )
                detached += cursor.rowcount
        return detached

    def list_inactive_operation_stages(
        self, *, limit: int = 256, after_stage_id: int = 0
    ) -> tuple[OperationStage, ...]:
        """Page superseded stages that no sendable operation can reference.

        Conflict and quarantined operations intentionally retain their complete
        evidence. For queued/inflight/retry operations only the row marked
        active is part of the immutable payload; inactive rows are GC handles.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= 100_000
            or isinstance(after_stage_id, bool)
            or not isinstance(after_stage_id, int)
            or after_stage_id < 0
        ):
            raise ValueError("Invalid inactive-stage pagination.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT stages.* FROM operation_stages AS stages
                   JOIN pending_operations AS operations
                     ON operations.mutation_id = stages.mutation_id
                   WHERE operations.scope_id = ?
                     AND operations.state IN ('queued', 'inflight', 'retry')
                     AND stages.active = 0 AND stages.stage_id > ?
                     AND NOT EXISTS (
                       SELECT 1 FROM conflicts
                       WHERE conflicts.resolved_at_ns IS NULL
                         AND conflicts.staged_path = stages.staged_path
                     )
                   ORDER BY stages.stage_id LIMIT ?""",
                (scope_id, after_stage_id, limit),
            ).fetchall()
        return tuple(_stage_from_row(row) for row in rows)

    def prune_inactive_operation_stages(self, stage_ids: Sequence[int]) -> int:
        """Delete GC metadata only while each stage remains safely inactive."""

        if len(stage_ids) > 1_000:
            raise ValueError("At most 1000 inactive stages may be pruned at once.")
        normalized: tuple[int, ...] = tuple(dict.fromkeys(stage_ids))
        if any(
            isinstance(stage_id, bool)
            or not isinstance(stage_id, int)
            or stage_id < 1
            for stage_id in normalized
        ):
            raise ValueError("stage_ids must contain positive integers.")
        if not normalized:
            return 0
        removed = 0
        with self._transaction():
            scope_id = self._active_scope_id()
            for stage_id in normalized:
                cursor = self._connection.execute(
                    """DELETE FROM operation_stages
                       WHERE stage_id = ? AND active = 0
                         AND mutation_id IN (
                           SELECT mutation_id FROM pending_operations
                           WHERE scope_id = ?
                             AND state IN ('queued', 'inflight', 'retry')
                         )""",
                    (stage_id, scope_id),
                )
                removed += cursor.rowcount
        return removed

    def referenced_stage_paths(
        self, candidates: Sequence[Path | str] | None = None
    ) -> frozenset[str]:
        """Return durable stage references across active and fenced scopes.

        Orphan scavenging must retain quarantined evidence as well as active
        work, so this intentionally is not restricted to the active scope.
        ``pending_operations.staged_path`` is included defensively for databases
        created by older clients before ``operation_stages`` became complete.

        Supplying a bounded candidate page keeps startup scavenging proportional
        to the directory page instead of materializing an arbitrarily large
        operation history in memory.
        """

        normalized: tuple[str, ...] | None = None
        if candidates is not None:
            if len(candidates) > 4_096:
                raise ValueError("At most 4096 candidate stage paths may be checked.")
            normalized = tuple(
                dict.fromkeys(
                    str(Path(value).expanduser().resolve(strict=False))
                    for value in candidates
                )
            )
            if not normalized:
                return frozenset()
        with self._lock:
            self._require_open()
            if normalized is None:
                rows = self._connection.execute(
                    """SELECT staged_path FROM operation_stages
                       UNION SELECT staged_path FROM pending_operations
                             WHERE staged_path IS NOT NULL
                       UNION SELECT staged_path FROM conflicts
                             WHERE staged_path IS NOT NULL
                               AND resolved_at_ns IS NULL
                       UNION SELECT staged_path FROM conflict_resolutions
                             WHERE staged_path IS NOT NULL
                               AND phase != 'completed'"""
                ).fetchall()
                return frozenset(str(row["staged_path"]) for row in rows)

            referenced: set[str] = set()
            # Each value is used in four UNION arms. Two hundred values keeps
            # the statement below SQLite's conservative 999-variable builds.
            for start in range(0, len(normalized), 200):
                page = normalized[start : start + 200]
                placeholders = ",".join("?" for _ in page)
                rows = self._connection.execute(
                    f"""SELECT staged_path FROM operation_stages
                         WHERE staged_path IN ({placeholders})
                         UNION SELECT staged_path FROM pending_operations
                               WHERE staged_path IN ({placeholders})
                         UNION SELECT staged_path FROM conflicts
                               WHERE staged_path IN ({placeholders})
                                 AND resolved_at_ns IS NULL
                         UNION SELECT staged_path FROM conflict_resolutions
                               WHERE staged_path IN ({placeholders})
                                 AND phase != 'completed'""",
                    (*page, *page, *page, *page),
                ).fetchall()
                referenced.update(str(row["staged_path"]) for row in rows)
        return frozenset(referenced)

    def stage_path_has_external_reference(
        self, staged_path: Path | str, *, excluding_mutation_id: str
    ) -> bool:
        """Whether another operation or unresolved conflict owns stage bytes."""

        normalized_path = str(Path(staged_path).expanduser().resolve(strict=False))
        mutation_id = _mutation_id(excluding_mutation_id)
        with self._lock:
            self._require_open()
            row = self._connection.execute(
                """SELECT 1 FROM operation_stages
                   WHERE staged_path = ? AND mutation_id != ?
                   UNION ALL
                   SELECT 1 FROM pending_operations
                   WHERE staged_path = ? AND mutation_id != ?
                   UNION ALL
                   SELECT 1 FROM conflicts
                   WHERE staged_path = ? AND resolved_at_ns IS NULL
                   UNION ALL
                   SELECT 1 FROM conflict_resolutions
                   WHERE staged_path = ? AND phase != 'completed'
                   LIMIT 1""",
                (
                    normalized_path,
                    mutation_id,
                    normalized_path,
                    mutation_id,
                    normalized_path,
                    normalized_path,
                ),
            ).fetchone()
        return row is not None

    def prune_acked_operations(self, mutation_ids: Sequence[str]) -> int:
        """Transactionally remove terminal journal metadata after byte cleanup.

        Filesystem cleanup happens first and is idempotent.  Only then may this
        transaction delete the receipt, every active/inactive stage reference,
        and finally the acknowledged operation.  Any non-acked ID is retained.
        """

        if len(mutation_ids) > 1_000:
            raise ValueError("At most 1000 acknowledged operations may be pruned at once.")
        normalized = tuple(dict.fromkeys(_mutation_id(value) for value in mutation_ids))
        if not normalized:
            return 0
        removed = 0
        with self._transaction():
            for mutation_id in normalized:
                row = self._connection.execute(
                    """SELECT state FROM pending_operations AS operation
                       WHERE mutation_id = ?
                         AND NOT EXISTS (
                           SELECT 1 FROM operation_receipts AS receipt
                           JOIN authority_scopes AS authority ON authority.scope_id = receipt.scope_id
                           LEFT JOIN remote_manifest_heads AS head ON head.scope_id = receipt.scope_id
                           WHERE receipt.mutation_id = operation.mutation_id AND authority.active = 1
                             AND receipt.remote_manifest_digest IS NULL
                             AND receipt.remote_generation > COALESCE(head.generation, -1)
                         )
                         AND NOT (
                           operation.directory_rename = 1
                           AND operation.directory_rename_observed = 0
                         )
                         AND NOT EXISTS (
                           SELECT 1 FROM conflict_resolutions AS resolution
                           WHERE resolution.successor_mutation_id =
                                 operation.mutation_id
                             AND resolution.phase != 'completed'
                         )""",
                    (mutation_id,),
                ).fetchone()
                if row is None or row["state"] != "acked":
                    continue
                self._connection.execute(
                    "DELETE FROM operation_receipts WHERE mutation_id = ?",
                    (mutation_id,),
                )
                self._connection.execute(
                    "DELETE FROM operation_stages WHERE mutation_id = ?",
                    (mutation_id,),
                )
                cursor = self._connection.execute(
                    """DELETE FROM pending_operations
                       WHERE mutation_id = ? AND state = 'acked'""",
                    (mutation_id,),
                )
                removed += cursor.rowcount
        return removed

    def finalize_resolved_conflict_cleanup(
        self, mutation_ids: Sequence[str]
    ) -> int:
        """Compact resolved conflict metadata after idempotent stage-file GC.

        The caller removes every unshared stage-file family first. This method
        then rechecks that the operation is a conflict with at least one
        associated conflict and no unresolved conflict, detaches the compact
        conflict history from its filesystem/journal owners, and deletes the
        operation metadata in one transaction. Replaying after a crash is a
        no-op once the operation has already been finalized.
        """

        if len(mutation_ids) > 1_000:
            raise ValueError("At most 1000 resolved conflict operations may be finalized at once.")
        normalized = tuple(dict.fromkeys(_mutation_id(value) for value in mutation_ids))
        if not normalized:
            return 0
        removed = 0
        now = time.time_ns()
        with self._transaction():
            for mutation_id in normalized:
                operation = self._connection.execute(
                    """SELECT scope_id FROM pending_operations AS operation
                       WHERE operation.mutation_id = ?
                         AND operation.state = 'conflict'
                         AND EXISTS (
                           SELECT 1 FROM conflicts AS associated
                           INDEXED BY conflict_operation_cleanup
                           WHERE associated.mutation_id = operation.mutation_id
                             AND associated.scope_id = operation.scope_id
                         )
                         AND NOT EXISTS (
                           SELECT 1 FROM conflicts AS unresolved
                           INDEXED BY conflict_operation_cleanup
                           WHERE unresolved.mutation_id = operation.mutation_id
                             AND unresolved.scope_id = operation.scope_id
                             AND unresolved.resolved_at_ns IS NULL
                         )""",
                    (mutation_id,),
                ).fetchone()
                if operation is None:
                    continue
                scope_id = int(operation["scope_id"])
                # Conflict transitions normally decrement their direct
                # successors. Recompute the exact count before deleting the
                # predecessor so an older/crashed writer cannot leave a
                # successor permanently blocked.
                self._connection.execute(
                    """UPDATE pending_operations AS successor
                       SET blocked_count = (
                             SELECT COUNT(*)
                             FROM operation_dependencies AS dependency
                             JOIN pending_operations AS predecessor
                               ON predecessor.mutation_id =
                                  dependency.predecessor_mutation_id
                             WHERE dependency.scope_id = successor.scope_id
                               AND dependency.mutation_id = successor.mutation_id
                               AND predecessor.state IN ('queued', 'inflight', 'retry')
                           ),
                           updated_at_ns = ?
                       WHERE successor.scope_id = ?
                         AND successor.mutation_id IN (
                           SELECT dependency.mutation_id
                           FROM operation_dependencies AS dependency
                           WHERE dependency.scope_id = ?
                             AND dependency.predecessor_mutation_id = ?
                         )""",
                    (now, scope_id, scope_id, mutation_id),
                )
                # Keep the human/debugging record while releasing both foreign
                # key ownership and the path that pins on-disk evidence.
                self._connection.execute(
                    """UPDATE conflicts
                       SET mutation_id = NULL, staged_path = NULL
                       WHERE scope_id = ? AND mutation_id = ?
                         AND resolved_at_ns IS NOT NULL""",
                    (scope_id, mutation_id),
                )
                self._connection.execute(
                    "DELETE FROM operation_receipts WHERE mutation_id = ?",
                    (mutation_id,),
                )
                self._connection.execute(
                    "DELETE FROM operation_stages WHERE mutation_id = ?",
                    (mutation_id,),
                )
                cursor = self._connection.execute(
                    """DELETE FROM pending_operations
                       WHERE mutation_id = ? AND scope_id = ? AND state = 'conflict'""",
                    (mutation_id, scope_id),
                )
                removed += cursor.rowcount
        return removed

    def _adjust_direct_dependents(
        self,
        scope_id: int,
        predecessor_mutation_id: str,
        *,
        delta: Literal[-1, 1],
        now_ns: int,
    ) -> None:
        """Maintain durable sendability on one predecessor state transition."""

        if delta == -1:
            self._connection.execute(
                """UPDATE pending_operations
                   SET blocked_count = blocked_count - 1, updated_at_ns = ?
                   WHERE scope_id = ? AND blocked_count > 0
                     AND mutation_id IN (
                       SELECT mutation_id
                       FROM operation_dependencies
                       WHERE scope_id = ? AND predecessor_mutation_id = ?
                     )""",
                (now_ns, scope_id, scope_id, predecessor_mutation_id),
            )
        else:
            self._connection.execute(
                """UPDATE pending_operations
                   SET blocked_count = blocked_count + 1, updated_at_ns = ?
                   WHERE scope_id = ?
                     AND mutation_id IN (
                       SELECT mutation_id
                       FROM operation_dependencies
                       WHERE scope_id = ? AND predecessor_mutation_id = ?
                     )""",
                (now_ns, scope_id, scope_id, predecessor_mutation_id),
            )

    def claim_operation(
        self, *, lease_seconds: float = _DEFAULT_OPERATION_LEASE_SECONDS, now_ns: int | None = None
    ) -> PendingOperation | None:
        """Atomically lease the oldest sendable operation.

        A crashed process's expired lease is changed to ``retry`` before the
        next operation is selected, so an inflight row cannot wedge the queue.
        """
        if (
            isinstance(lease_seconds, bool)
            or not isinstance(lease_seconds, (int, float))
            or not 0.1 <= lease_seconds <= 86_400
        ):
            raise ValueError("lease_seconds must be between 0.1 and 86400.")
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        stale_before = now - int(lease_seconds * 1_000_000_000)
        with self._transaction():
            scope_id = self._active_scope_id()
            self._connection.execute(
                """UPDATE pending_operations
                   SET state = 'retry', claimed_at_ns = NULL,
                       last_error = COALESCE(last_error, 'operation lease expired'),
                       failure_count = failure_count + 1,
                       next_attempt_at_ns = ?, ready_at_ns = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND state = 'inflight'
                         AND commit_unknown = 0
                         AND claimed_at_ns <= ?""",
                (now, now, now, scope_id, stale_before),
            )
            queued = self._connection.execute(
                """SELECT mutation_id, journal_seq
                   FROM pending_operations INDEXED BY pending_queued_ready
                   WHERE scope_id = ? AND state = 'queued' AND blocked_count = 0
                     AND commit_unknown = 0
                   ORDER BY journal_seq LIMIT 1""",
                (scope_id,),
            ).fetchone()
            retry = self._connection.execute(
                """SELECT mutation_id, journal_seq
                   FROM pending_operations INDEXED BY pending_retry_ready
                   WHERE scope_id = ? AND state = 'retry' AND blocked_count = 0
                     AND commit_unknown = 0 AND ready_at_ns <= ?
                   ORDER BY ready_at_ns, journal_seq LIMIT 1""",
                (scope_id, now),
            ).fetchone()
            candidates = tuple(row for row in (queued, retry) if row is not None)
            if not candidates:
                return None
            selected = min(
                candidates,
                key=lambda row: int(row["journal_seq"]),
            )
            mutation_id = str(selected["mutation_id"])
            self._connection.execute(
                """UPDATE pending_operations SET
                       state = 'inflight', attempt_count = attempt_count + 1,
                       claimed_at_ns = ?, next_attempt_at_ns = NULL,
                       ready_at_ns = ?, updated_at_ns = ?
                   WHERE mutation_id = ? AND blocked_count = 0
                     AND commit_unknown = 0 AND state IN ('queued', 'retry')""",
                (now, now, now, mutation_id),
            )
            claimed = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?",
                (mutation_id,),
            ).fetchone()
        assert claimed is not None
        return _operation_from_row(claimed)

    def next_operation_attempt_ns(
        self, *, lease_seconds: float = _DEFAULT_OPERATION_LEASE_SECONDS, now_ns: int | None = None
    ) -> int | None:
        """Return the earliest wall-clock deadline for pending operation work.

        Queued rows are immediately sendable, retry rows retain their durable
        backoff deadline, and an inflight row becomes recoverable when its lease
        expires.  This lets the coordinator sleep until useful work exists
        without turning a delayed retry into a permanent 2 Hz poll.
        """

        if (
            isinstance(lease_seconds, bool)
            or not isinstance(lease_seconds, (int, float))
            or not 0.1 <= lease_seconds <= 86_400
        ):
            raise ValueError("lease_seconds must be between 0.1 and 86400.")
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        lease_ns = int(float(lease_seconds) * 1_000_000_000)
        with self._lock:
            scope_id = self._active_scope_id()
            queued = self._connection.execute(
                """SELECT ready_at_ns
                   FROM pending_operations INDEXED BY pending_queued_ready
                   WHERE scope_id = ? AND state = 'queued' AND blocked_count = 0
                     AND commit_unknown = 0
                   ORDER BY journal_seq LIMIT 1""",
                (scope_id,),
            ).fetchone()
            retry = self._connection.execute(
                """SELECT ready_at_ns
                   FROM pending_operations INDEXED BY pending_retry_ready
                   WHERE scope_id = ? AND state = 'retry' AND blocked_count = 0
                     AND commit_unknown = 0
                   ORDER BY ready_at_ns, journal_seq LIMIT 1""",
                (scope_id,),
            ).fetchone()
            inflight = self._connection.execute(
                """SELECT claimed_at_ns
                   FROM pending_operations INDEXED BY pending_inflight_lease
                   WHERE scope_id = ? AND state = 'inflight'
                     AND commit_unknown = 0
                   ORDER BY claimed_at_ns, mutation_id LIMIT 1""",
                (scope_id,),
            ).fetchone()
            commit_unknown = self._connection.execute(
                """SELECT ready_at_ns FROM pending_operations
                   INDEXED BY pending_commit_unknown_ready
                   WHERE scope_id = ? AND commit_unknown = 1
                   ORDER BY journal_seq LIMIT 1""",
                (scope_id,),
            ).fetchone()
        deadlines: list[int] = []
        if queued is not None:
            deadlines.append(now)
        if retry is not None:
            deadlines.append(int(retry["ready_at_ns"]))
        if inflight is not None:
            deadlines.append(int(inflight["claimed_at_ns"]) + lease_ns)
        if commit_unknown is not None:
            deadlines.append(int(commit_unknown["ready_at_ns"]))
        if not deadlines:
            return None
        return min(deadlines)

    def update_operation(
        self,
        mutation_id: str,
        *,
        state: OperationState | str,
        error: str | None = None,
        retry_after_seconds: float | None = None,
        count_failure: bool = False,
        reset_failures: bool = False,
        now_ns: int | None = None,
    ) -> PendingOperation:
        mutation_id = _mutation_id(mutation_id)
        if state not in ("queued", "inflight", "retry", "conflict"):
            raise ValueError("Use ack_operation for acknowledgements; quarantine is authority-owned.")
        if state == "conflict" and error is None:
            error = "operation entered conflict without a supplied reason"
        if error is not None:
            error = _bounded_text("error", error, _MAX_ERROR_BYTES)
        if not isinstance(count_failure, bool) or not isinstance(reset_failures, bool):
            raise ValueError("count_failure and reset_failures must be booleans.")
        if count_failure and reset_failures:
            raise ValueError("A retry update cannot both count and reset failures.")
        if retry_after_seconds is not None and (
            isinstance(retry_after_seconds, bool)
            or not isinstance(retry_after_seconds, (int, float))
            or not 0 <= retry_after_seconds <= 86_400
        ):
            raise ValueError("retry_after_seconds must be between 0 and 86400.")
        if state != "retry" and retry_after_seconds is not None:
            raise ValueError("retry_after_seconds is valid only for retry state.")
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        next_attempt_at_ns = (
            now + int(float(retry_after_seconds or 0) * 1_000_000_000)
            if state == "retry"
            else None
        )
        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if current is None:
                raise StateError("The pending operation is not in the active authority epoch.")
            if current["state"] in ("acked", "quarantined"):
                raise StateError(f"A {current['state']} operation cannot be updated.")
            if state == "inflight" and int(current["blocked_count"]) != 0:
                raise StateError("A dependency-blocked operation cannot become inflight.")
            if state == "conflict":
                evidence = self._connection.execute(
                    """SELECT 1 FROM conflicts
                       WHERE scope_id = ? AND mutation_id = ? LIMIT 1""",
                    (scope_id, mutation_id),
                ).fetchone()
                if evidence is None:
                    assert error is not None
                    self._connection.execute(
                        """INSERT INTO conflicts(
                               scope_id, mutation_id, path, reason,
                               base_digest, local_digest, staged_path,
                               recorded_at_ns
                           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            scope_id,
                            mutation_id,
                            current["path"],
                            error,
                            current["expected_source_digest"],
                            current["staged_digest"],
                            current["staged_path"],
                            now,
                        ),
                    )
            claimed_at = now if state == "inflight" else None
            failure_count = (
                0
                if reset_failures
                else int(current["failure_count"]) + (1 if count_failure else 0)
            )
            ready_at_ns = (
                int(current["created_at_ns"])
                if state == "queued"
                else int(next_attempt_at_ns if state == "retry" else now)
            )
            self._connection.execute(
                """UPDATE pending_operations SET state = ?, last_error = ?,
                       commit_unknown = CASE WHEN ? = 'conflict'
                                             THEN 0 ELSE commit_unknown END,
                       commit_batch_id = CASE WHEN ? = 'conflict'
                                             THEN NULL ELSE commit_batch_id END,
                       claimed_at_ns = ?, failure_count = ?, next_attempt_at_ns = ?,
                       ready_at_ns = ?, updated_at_ns = ? WHERE mutation_id = ?""",
                (
                    state,
                    error,
                    state,
                    state,
                    claimed_at,
                    failure_count,
                    next_attempt_at_ns,
                    ready_at_ns,
                    now,
                    mutation_id,
                ),
            )
            was_nonterminal = str(current["state"]) in _NONTERMINAL_OPERATION_STATES
            is_nonterminal = state in _NONTERMINAL_OPERATION_STATES
            if was_nonterminal and not is_nonterminal:
                self._adjust_direct_dependents(
                    scope_id, mutation_id, delta=-1, now_ns=now
                )
            elif not was_nonterminal and is_nonterminal:
                self._adjust_direct_dependents(
                    scope_id, mutation_id, delta=1, now_ns=now
                )
            row = self._connection.execute(
                "SELECT * FROM pending_operations WHERE mutation_id = ?", (mutation_id,)
            ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def supersede_operation(self, mutation_id: str, *, reason: str) -> PendingOperation:
        """Retire a locally superseded plan without surfacing a user conflict.

        A byte-verified rename may prove that the destination was edited and
        replace itself with a durable put-plus-delete plan.  The abandoned
        metadata mutation is terminal, but it is not a divergent user file.
        Keep a resolved audit record and unblock dependents in the same SQLite
        transaction so a crash cannot expose a false unresolved conflict.
        """

        mutation_id = _mutation_id(mutation_id)
        reason = _bounded_text("reason", reason, _MAX_ERROR_BYTES)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            current = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if current is None:
                raise StateError("The pending operation is not in the active authority epoch.")
            if current["state"] in ("acked", "quarantined"):
                raise StateError(f"A {current['state']} operation cannot be superseded.")
            if current["state"] == "conflict":
                self._connection.execute(
                    """UPDATE conflicts SET resolved_at_ns = COALESCE(resolved_at_ns, ?)
                       WHERE scope_id = ? AND mutation_id = ?""",
                    (now, scope_id, mutation_id),
                )
                row = current
            else:
                self._connection.execute(
                    """INSERT INTO conflicts(
                           scope_id, mutation_id, path, reason,
                           base_digest, local_digest, staged_path,
                           recorded_at_ns, resolved_at_ns
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        scope_id,
                        mutation_id,
                        current["path"],
                        reason,
                        current["expected_source_digest"],
                        current["staged_digest"],
                        current["staged_path"],
                        now,
                        now,
                    ),
                )
                self._connection.execute(
                    """UPDATE pending_operations
                       SET state = 'conflict', last_error = ?, commit_unknown = 0,
                           commit_batch_id = NULL,
                           claimed_at_ns = NULL, next_attempt_at_ns = NULL,
                           ready_at_ns = ?, updated_at_ns = ?
                       WHERE mutation_id = ? AND scope_id = ?""",
                    (reason, now, now, mutation_id, scope_id),
                )
                if str(current["state"]) in _NONTERMINAL_OPERATION_STATES:
                    self._adjust_direct_dependents(
                        scope_id, mutation_id, delta=-1, now_ns=now
                    )
                row = self._connection.execute(
                    "SELECT * FROM pending_operations WHERE mutation_id = ?",
                    (mutation_id,),
                ).fetchone()
        assert row is not None
        return _operation_from_row(row)

    def resolve_satisfied_conflict_operation(
        self, mutation_id: str, *, now_ns: int | None = None
    ) -> bool:
        """Resolve a conflict-state op the remote independently already satisfies.

        Safety proof, identical to the keep-remote directory completion: the op
        is state=conflict, never froze a request digest, has no receipt, and has
        no unknown commit -- so it CANNOT itself be the remote effect the caller
        observed. The intended outcome was reached by another path (the same
        move applied server-side, another client). Marking the linked conflict
        resolved lets `finalize_resolved_conflict_cleanup` retire the op; for a
        directory rename it also drops the empty conflict overlay and marks the
        rename observed, exactly as `complete_unsent_directory_rename_keep_
        remote`. Returns True if it resolved one, False if the op no longer
        qualifies (a race, or nothing to resolve).
        """

        mutation_id = _mutation_id(mutation_id)
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        with self._transaction():
            scope_id = self._active_scope_id()
            operation = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if operation is None:
                return False
            if (
                str(operation["state"]) != "conflict"
                or bool(operation["commit_unknown"])
                or operation["request_digest"] is not None
                or str(operation["kind"]) not in ("rename", "put")
            ):
                return False
            if self._connection.execute(
                "SELECT 1 FROM operation_receipts WHERE mutation_id = ? LIMIT 1",
                (mutation_id,),
            ).fetchone() is not None:
                return False
            resolved = self._connection.execute(
                """UPDATE conflicts SET resolved_at_ns = ?
                   WHERE scope_id = ? AND mutation_id = ?
                     AND resolved_at_ns IS NULL""",
                (now, scope_id, mutation_id),
            )
            if resolved.rowcount < 1:
                return False
            if bool(operation["directory_rename"]):
                self._connection.execute(
                    """DELETE FROM materialized_entries
                       WHERE scope_id = ? AND path = ? AND state = 'conflict'
                         AND clean_digest IS NULL AND stat_fingerprint IS NULL
                         AND bytes_on_disk = 0""",
                    (scope_id, str(operation["path"])),
                )
                self._connection.execute(
                    """UPDATE pending_operations
                       SET directory_rename_observed = 1, updated_at_ns = ?
                       WHERE mutation_id = ? AND scope_id = ?
                         AND state = 'conflict' AND directory_rename = 1""",
                    (now, mutation_id, scope_id),
                )
            return True

    def resubmit_conflict_operation_once(
        self, mutation_id: str, *, now_ns: int | None = None
    ) -> bool:
        """Re-arm a conflict-state, never-sent op for one more attempt.

        For a rename rejected with a code the server can later accept (e.g. a
        FABRIC_PATH_ABSENT the server answered before the source was visible),
        allow ONE fresh submit after a refresh rather than leaving it terminal.
        Only a never-sent op (no request digest, no receipt, no unknown commit)
        is eligible -- one that HAS crossed the remote boundary is owned by the
        readback lane. The linked conflict is resolved and the op returns to
        'queued'. The caller guards this to a single re-arm per op. Returns True
        if re-armed.
        """

        mutation_id = _mutation_id(mutation_id)
        now = time.time_ns() if now_ns is None else now_ns
        if isinstance(now, bool) or not isinstance(now, int) or now < 0:
            raise ValueError("now_ns must be a non-negative integer.")
        with self._transaction():
            scope_id = self._active_scope_id()
            operation = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if operation is None:
                return False
            if (
                str(operation["state"]) != "conflict"
                or bool(operation["commit_unknown"])
                or operation["request_digest"] is not None
                or str(operation["kind"]) != "rename"
            ):
                return False
            if self._connection.execute(
                "SELECT 1 FROM operation_receipts WHERE mutation_id = ? LIMIT 1",
                (mutation_id,),
            ).fetchone() is not None:
                return False
            self._connection.execute(
                """UPDATE conflicts SET resolved_at_ns = ?
                   WHERE scope_id = ? AND mutation_id = ?
                     AND resolved_at_ns IS NULL""",
                (now, scope_id, mutation_id),
            )
            self._connection.execute(
                """UPDATE pending_operations
                   SET state = 'queued', last_error = NULL, claimed_at_ns = NULL,
                       next_attempt_at_ns = NULL, ready_at_ns = ?, updated_at_ns = ?
                   WHERE mutation_id = ? AND scope_id = ? AND state = 'conflict'
                     AND commit_unknown = 0 AND request_digest IS NULL""",
                (now, now, mutation_id, scope_id),
            )
            return True

    def ack_operation(
        self,
        mutation_id: str,
        *,
        remote_generation: int | None = None,
        remote_manifest_digest: str | None = None,
        remote_entry_digest: str | None = None,
        receipt: Any | None = None,
    ) -> OperationReceipt:
        mutation_id = _mutation_id(mutation_id)
        if remote_generation is not None:
            remote_generation = (
                _sequence("receipt generation", remote_generation)
                if remote_manifest_digest is None else _generation(remote_generation)
            )
        remote_manifest_digest = _digest("remote manifest digest", remote_manifest_digest)
        remote_entry_digest = _digest("remote entry digest", remote_entry_digest)
        receipt_json = _bounded_json(receipt, _MAX_RECEIPT_JSON_BYTES, "receipt")
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            operation = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (mutation_id, scope_id),
            ).fetchone()
            if operation is None:
                raise StateError("The operation is not in the active authority epoch.")
            row = self._ack_operation_locked(
                scope_id,
                operation,
                remote_generation=remote_generation,
                remote_manifest_digest=remote_manifest_digest,
                remote_entry_digest=remote_entry_digest,
                receipt_json=receipt_json,
                now=now,
            )
        assert row is not None
        return _receipt_from_row(row)

    def get_receipt(self, mutation_id: str) -> OperationReceipt | None:
        mutation_id = _mutation_id(mutation_id)
        with self._lock:
            self._require_open()
            row = self._connection.execute(
                "SELECT * FROM operation_receipts WHERE mutation_id = ?", (mutation_id,)
            ).fetchone()
        return _receipt_from_row(row) if row is not None else None

    # --------------------------------------------------------------- conflicts

    def get_conflict_by_evidence_key(
        self, evidence_key: str
    ) -> ConflictRecord | None:
        """Read one idempotent recovery record in the active authority epoch."""

        evidence_key = _bounded_text("evidence_key", evidence_key, 256)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM conflicts
                   WHERE scope_id = ? AND evidence_key = ? LIMIT 1""",
                (scope_id, evidence_key),
            ).fetchone()
        return _conflict_from_row(row) if row is not None else None

    def record_conflict(
        self,
        path: str,
        reason: str,
        *,
        mutation_id: str | None = None,
        evidence_key: str | None = None,
        base_digest: str | None = None,
        local_digest: str | None = None,
        local_fingerprint: str | None = None,
        remote_digest: str | None = None,
        remote_generation: int | None = None,
        staged_path: Path | str | None = None,
    ) -> ConflictRecord:
        path = _canonical_path(path)
        reason = _bounded_text("reason", reason, _MAX_ERROR_BYTES)
        if mutation_id is not None:
            mutation_id = _mutation_id(mutation_id)
        if evidence_key is not None:
            evidence_key = _bounded_text("evidence_key", evidence_key, 256)
        base_digest = _digest("base digest", base_digest)
        local_digest = _digest("local digest", local_digest)
        if local_fingerprint is not None:
            local_fingerprint = _bounded_text(
                "local_fingerprint", local_fingerprint, 4_096
            )
        if local_digest is not None and local_fingerprint is not None:
            raise ValueError(
                "local_digest and local_fingerprint are alternative local evidence."
            )
        remote_digest = _digest("remote digest", remote_digest)
        if remote_generation is not None:
            remote_generation = _generation(remote_generation)
        normalized_staged_path = (
            str(Path(staged_path).expanduser().resolve(strict=False))
            if staged_path is not None
            else None
        )
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            existing_evidence = (
                self._connection.execute(
                    """SELECT * FROM conflicts
                       WHERE scope_id = ? AND evidence_key = ? LIMIT 1""",
                    (scope_id, evidence_key),
                ).fetchone()
                if evidence_key is not None
                else None
            )
            if existing_evidence is not None:
                existing = _conflict_from_row(existing_evidence)
                if (
                    existing.mutation_id != mutation_id
                    or existing.path != path
                    or existing.reason != reason
                    or existing.base_digest != base_digest
                    or existing.local_digest != local_digest
                    or existing.local_fingerprint != local_fingerprint
                    or existing.remote_digest != remote_digest
                    or existing.remote_generation != remote_generation
                    or existing.staged_path != normalized_staged_path
                ):
                    raise StateError(
                        "A conflict evidence key cannot identify two recovery records."
                    )
                return existing
            if mutation_id is not None:
                operation = self._connection.execute(
                    """SELECT mutation_id, state FROM pending_operations
                       WHERE mutation_id = ? AND scope_id = ?""",
                    (mutation_id, scope_id),
                ).fetchone()
                if operation is None:
                    raise StateError("The conflicting operation is not in the active epoch.")
                if operation["state"] in ("acked", "quarantined"):
                    raise StateError(
                        f"A {operation['state']} operation cannot be changed to a conflict."
                    )
            cursor = self._connection.execute(
                """INSERT INTO conflicts(
                       scope_id, mutation_id, evidence_key, path, reason, base_digest, local_digest,
                       local_fingerprint, remote_digest, remote_generation,
                       staged_path, recorded_at_ns
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    scope_id,
                    mutation_id,
                    evidence_key,
                    path,
                    reason,
                    base_digest,
                    local_digest,
                    local_fingerprint,
                    remote_digest,
                    remote_generation,
                    normalized_staged_path,
                    now,
                ),
            )
            if mutation_id is not None:
                self._connection.execute(
                    """UPDATE pending_operations SET state = 'conflict',
                           commit_unknown = 0, commit_batch_id = NULL, last_error = ?, claimed_at_ns = NULL,
                           next_attempt_at_ns = NULL, ready_at_ns = ?, updated_at_ns = ?
                       WHERE mutation_id = ?""",
                    (reason, now, now, mutation_id),
                )
                if str(operation["state"]) in _NONTERMINAL_OPERATION_STATES:
                    self._adjust_direct_dependents(
                        scope_id, mutation_id, delta=-1, now_ns=now
                    )
            conflict_id = int(cursor.lastrowid)
            row = self._connection.execute(
                "SELECT * FROM conflicts WHERE conflict_id = ?", (conflict_id,)
            ).fetchone()
        assert row is not None
        return _conflict_from_row(row)

    def list_conflicts(self, *, unresolved_only: bool = True) -> tuple[ConflictRecord, ...]:
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            suffix = "AND resolved_at_ns IS NULL" if unresolved_only else ""
            rows = self._connection.execute(
                f"""SELECT * FROM conflicts WHERE scope_id = ? {suffix}
                    ORDER BY recorded_at_ns, conflict_id""",
                (scope_id,),
            ).fetchall()
        return tuple(_conflict_from_row(row) for row in rows)

    def list_empty_remote_apply_conflicts(
        self, *, limit: int = 8, after_conflict_id: int = 0
    ) -> tuple[ConflictRecord, ...]:
        """Return a bounded page of structurally empty standalone conflicts.

        The coordinator still validates the historical error document and the
        local namespace under its watcher fence.  This query deliberately
        excludes every durable owner that could represent user bytes or an
        in-progress operator decision.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_CONFLICT_PAGE
        ):
            raise ValueError(f"limit must be between 1 and {_MAX_CONFLICT_PAGE}.")
        if (
            isinstance(after_conflict_id, bool)
            or not isinstance(after_conflict_id, int)
            or after_conflict_id < 0
        ):
            raise ValueError("after_conflict_id must be non-negative.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT conflict.*
                   FROM conflicts AS conflict
                   JOIN materialized_entries AS materialized
                     ON materialized.scope_id = conflict.scope_id
                    AND materialized.path = conflict.path
                   WHERE conflict.scope_id = ?
                     AND conflict.conflict_id > ?
                     AND conflict.resolved_at_ns IS NULL
                     AND conflict.mutation_id IS NULL
                     AND conflict.evidence_key IS NULL
                     AND conflict.local_digest IS NULL
                     AND conflict.local_fingerprint IS NULL
                     AND conflict.staged_path IS NULL
                     AND conflict.remote_digest IS NOT NULL
                     AND conflict.remote_generation IS NOT NULL
                     AND materialized.state = 'conflict'
                     AND materialized.pinned = 1
                     AND materialized.stat_fingerprint IS NULL
                     AND materialized.bytes_on_disk = 0
                     AND NOT EXISTS (
                       SELECT 1 FROM conflict_resolutions AS resolution
                       WHERE resolution.anchor_conflict_id = conflict.conflict_id
                     )
                     AND NOT EXISTS (
                       SELECT 1
                       FROM conflict_resolutions AS resolution
                       JOIN conflicts AS anchor
                         ON anchor.conflict_id = resolution.anchor_conflict_id
                       WHERE resolution.scope_id = conflict.scope_id
                         AND anchor.path = conflict.path
                         AND resolution.completed_at_ns IS NULL
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM local_transfer_intents AS transfer
                       WHERE transfer.scope_id = conflict.scope_id
                         AND transfer.path = conflict.path
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM pending_operations AS operation
                       WHERE operation.scope_id = conflict.scope_id
                         AND operation.state IN ('queued','inflight','retry','conflict')
                         AND (
                           operation.path = conflict.path
                           OR operation.destination_path = conflict.path
                       )
                     )
                     AND NOT EXISTS (
                       SELECT 1
                       FROM operation_stages AS stage
                       JOIN pending_operations AS operation
                         ON operation.mutation_id = stage.mutation_id
                       WHERE stage.active = 1
                         AND operation.scope_id = conflict.scope_id
                         AND (
                           operation.path = conflict.path
                           OR operation.destination_path = conflict.path
                         )
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM eviction_intents AS eviction
                       WHERE eviction.scope_id = conflict.scope_id
                         AND eviction.path = conflict.path
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_rename_intents AS rename
                       WHERE rename.scope_id = conflict.scope_id
                         AND (
                           rename.source_path = conflict.path
                           OR rename.destination_path = conflict.path
                         )
                     )
                   ORDER BY conflict.conflict_id
                   LIMIT ?""",
                (scope_id, after_conflict_id, limit),
            ).fetchall()
        return tuple(_conflict_from_row(row) for row in rows)

    def repair_empty_remote_apply_conflict(
        self,
        conflict_id: int,
        *,
        expected_reason: str,
        expected_generation: int,
        expected_manifest_digest: str | None,
    ) -> EmptyRemoteApplyRepair | None:
        """Resolve one empty legacy conflict against the exact refreshed head.

        The filesystem absence proof is coordinator-owned.  This transaction
        repeats every durable fence, resolves the evidence, and either requeues
        current remote bytes or records authoritative absence atomically.
        """

        conflict_id = _positive_id("conflict_id", conflict_id)
        expected_reason = _bounded_text(
            "expected_reason", expected_reason, _MAX_ERROR_BYTES
        )
        expected_generation = _generation(expected_generation)
        expected_manifest_digest = _digest(
            "expected manifest digest", expected_manifest_digest
        )
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            head = self._connection.execute(
                """SELECT generation, digest FROM remote_manifest_heads
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            if (
                head is None
                or int(head["generation"]) != expected_generation
                or head["digest"] != expected_manifest_digest
            ):
                return None
            conflict = self._connection.execute(
                """SELECT conflict.*, materialized.clean_digest
                   FROM conflicts AS conflict
                   JOIN materialized_entries AS materialized
                     ON materialized.scope_id = conflict.scope_id
                    AND materialized.path = conflict.path
                   WHERE conflict.conflict_id = ?
                     AND conflict.scope_id = ?
                     AND conflict.reason = ?
                     AND conflict.resolved_at_ns IS NULL
                     AND conflict.mutation_id IS NULL
                     AND conflict.evidence_key IS NULL
                     AND conflict.local_digest IS NULL
                     AND conflict.local_fingerprint IS NULL
                     AND conflict.staged_path IS NULL
                     AND conflict.remote_digest IS NOT NULL
                     AND conflict.remote_generation IS NOT NULL
                     AND materialized.state = 'conflict'
                     AND materialized.pinned = 1
                     AND materialized.stat_fingerprint IS NULL
                     AND materialized.bytes_on_disk = 0
                     AND NOT EXISTS (
                       SELECT 1 FROM conflict_resolutions AS resolution
                       WHERE resolution.anchor_conflict_id = conflict.conflict_id
                     )
                     AND NOT EXISTS (
                       SELECT 1
                       FROM conflict_resolutions AS resolution
                       JOIN conflicts AS anchor
                         ON anchor.conflict_id = resolution.anchor_conflict_id
                       WHERE resolution.scope_id = conflict.scope_id
                         AND anchor.path = conflict.path
                         AND resolution.completed_at_ns IS NULL
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM local_transfer_intents AS transfer
                       WHERE transfer.scope_id = conflict.scope_id
                         AND transfer.path = conflict.path
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM pending_operations AS operation
                       WHERE operation.scope_id = conflict.scope_id
                         AND operation.state IN ('queued','inflight','retry','conflict')
                         AND (
                           operation.path = conflict.path
                           OR operation.destination_path = conflict.path
                       )
                     )
                     AND NOT EXISTS (
                       SELECT 1
                       FROM operation_stages AS stage
                       JOIN pending_operations AS operation
                         ON operation.mutation_id = stage.mutation_id
                       WHERE stage.active = 1
                         AND operation.scope_id = conflict.scope_id
                         AND (
                           operation.path = conflict.path
                           OR operation.destination_path = conflict.path
                         )
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM eviction_intents AS eviction
                       WHERE eviction.scope_id = conflict.scope_id
                         AND eviction.path = conflict.path
                     )
                     AND NOT EXISTS (
                       SELECT 1 FROM remote_rename_intents AS rename
                       WHERE rename.scope_id = conflict.scope_id
                         AND (
                           rename.source_path = conflict.path
                           OR rename.destination_path = conflict.path
                         )
                     )""",
                (conflict_id, scope_id, expected_reason),
            ).fetchone()
            if conflict is None:
                return None

            path = str(conflict["path"])
            remote = self._connection.execute(
                """SELECT digest FROM remote_entries
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, path),
            ).fetchone()
            remote_digest = str(remote["digest"]) if remote is not None else None
            if (
                remote_digest is not None
                and remote_digest != str(conflict["remote_digest"])
            ):
                # A successor file was never part of the historical failure.
                # Preserve the conflict for an explicit operator decision.
                return None
            clean_digest = (
                remote_digest
                if remote_digest is not None
                else (
                    str(conflict["clean_digest"])
                    if conflict["clean_digest"] is not None
                    else str(conflict["remote_digest"])
                )
            )
            state = "clean" if remote_digest is not None else "absent"
            updated = self._connection.execute(
                """UPDATE materialized_entries
                   SET state = ?, pinned = 0, clean_digest = ?,
                       stat_fingerprint = NULL, bytes_on_disk = 0,
                       accessed_at_ns = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ?
                     AND state = 'conflict' AND pinned = 1
                     AND stat_fingerprint IS NULL AND bytes_on_disk = 0""",
                (state, clean_digest, now, now, scope_id, path),
            )
            if updated.rowcount != 1:
                raise StateError(
                    "The legacy content-missing conflict changed before repair."
                )
            resolved = self._connection.execute(
                """UPDATE conflicts SET resolved_at_ns = ?
                   WHERE conflict_id = ? AND scope_id = ?
                     AND resolved_at_ns IS NULL""",
                (now, conflict_id, scope_id),
            )
            if resolved.rowcount != 1:
                raise StateError(
                    "The legacy content-missing evidence changed before repair."
                )
            if remote_digest is None:
                self._connection.execute(
                    """DELETE FROM remote_apply_intents
                       WHERE scope_id = ? AND path = ?""",
                    (scope_id, path),
                )
            else:
                self._insert_remote_intents(scope_id, (path,), (), now)
        return EmptyRemoteApplyRepair(path=path, remote_digest=remote_digest)

    def list_conflicts_for_scope(
        self, scope_id: int, *, unresolved_only: bool = True
    ) -> tuple[ConflictRecord, ...]:
        """Export conflict evidence from an exact active or quarantined scope."""

        scope_id = _positive_id("scope_id", scope_id)
        if not isinstance(unresolved_only, bool):
            raise ValueError("unresolved_only must be a boolean.")
        with self._lock:
            self._require_open()
            suffix = "AND resolved_at_ns IS NULL" if unresolved_only else ""
            rows = self._connection.execute(
                f"""SELECT * FROM conflicts WHERE scope_id = ? {suffix}
                    ORDER BY recorded_at_ns, conflict_id""",
                (scope_id,),
            ).fetchall()
        return tuple(_conflict_from_row(row) for row in rows)

    def list_conflict_views(
        self,
        *,
        limit: int = 50,
        after_conflict_id: int = 0,
        unresolved_only: bool = True,
    ) -> tuple[ConflictView, ...]:
        """Return one bounded active-scope operator page.

        Content hashing and filesystem access deliberately stay outside this
        metadata projection. Linked operations and one group resolution are
        loaded in bounded set queries, avoiding an N+1 query pattern.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_CONFLICT_PAGE
        ):
            raise ValueError(f"limit must be between 1 and {_MAX_CONFLICT_PAGE}.")
        if (
            isinstance(after_conflict_id, bool)
            or not isinstance(after_conflict_id, int)
            or after_conflict_id < 0
        ):
            raise ValueError("after_conflict_id must be non-negative.")
        if not isinstance(unresolved_only, bool):
            raise ValueError("unresolved_only must be a boolean.")
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            resolved_filter = "AND resolved_at_ns IS NULL" if unresolved_only else ""
            rows = self._connection.execute(
                f"""SELECT * FROM conflicts INDEXED BY conflict_scope_page
                    WHERE scope_id = ? AND conflict_id > ? {resolved_filter}
                    ORDER BY conflict_id LIMIT ?""",
                (scope_id, after_conflict_id, limit),
            ).fetchall()
            return self._conflict_views_locked(scope_id, rows)

    def get_conflict_view(self, conflict_id: int) -> ConflictView | None:
        """Return an exact conflict only while its authority is active."""

        conflict_id = _positive_id("conflict_id", conflict_id)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                "SELECT * FROM conflicts WHERE scope_id = ? AND conflict_id = ?",
                (scope_id, conflict_id),
            ).fetchone()
            if row is None:
                return None
            return self._conflict_views_locked(scope_id, (row,))[0]

    def request_conflict_resolution(
        self, conflict_id: int, decision: ConflictDecision | str
    ) -> ConflictResolution:
        """Durably choose one resolution for an active conflict group.

        The latest unresolved observation anchors a mutation-owned group. An
        exact retry returns the original row and preallocated successor UUID;
        a different decision never rewrites durable intent.
        """

        conflict_id = _positive_id("conflict_id", conflict_id)
        decision = _conflict_decision(decision)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            selected = self._connection.execute(
                "SELECT * FROM conflicts WHERE scope_id = ? AND conflict_id = ?",
                (scope_id, conflict_id),
            ).fetchone()
            if selected is None:
                raise StateError("The conflict is not in the active authority epoch.")

            mutation_id = (
                str(selected["mutation_id"])
                if selected["mutation_id"] is not None
                else None
            )
            if mutation_id is None:
                existing = self._connection.execute(
                    """SELECT * FROM conflict_resolutions
                       WHERE scope_id = ? AND anchor_conflict_id = ?""",
                    (scope_id, conflict_id),
                ).fetchone()
            else:
                existing = self._connection.execute(
                    """SELECT * FROM conflict_resolutions
                       WHERE scope_id = ? AND mutation_id = ?""",
                    (scope_id, mutation_id),
                ).fetchone()
            if existing is not None:
                if str(existing["decision"]) != decision:
                    raise StateError(
                        "The conflict group already has a different durable decision."
                    )
                return _conflict_resolution_from_row(existing)

            if selected["resolved_at_ns"] is not None:
                raise StateError("The conflict is already resolved.")
            anchor = selected
            if mutation_id is not None:
                latest = self._connection.execute(
                    """SELECT * FROM conflicts
                       WHERE scope_id = ? AND mutation_id = ?
                         AND resolved_at_ns IS NULL
                       ORDER BY recorded_at_ns DESC, conflict_id DESC LIMIT 1""",
                    (scope_id, mutation_id),
                ).fetchone()
                if latest is None:
                    raise StateError("The conflict group is already resolved.")
                anchor = latest
                incompatible = self._connection.execute(
                    """SELECT 1 FROM conflicts
                       WHERE scope_id = ? AND mutation_id = ?
                         AND resolved_at_ns IS NULL
                         AND NOT (
                           path = ?
                           AND base_digest IS ?
                           AND local_digest IS ?
                           AND local_fingerprint IS ?
                           AND remote_digest IS ?
                           AND remote_generation IS ?
                         )
                       LIMIT 1""",
                    (
                        scope_id,
                        mutation_id,
                        str(anchor["path"]),
                        anchor["base_digest"],
                        anchor["local_digest"],
                        anchor["local_fingerprint"],
                        anchor["remote_digest"],
                        anchor["remote_generation"],
                    ),
                ).fetchone()
                if incompatible is not None:
                    raise StateError(
                        "The conflict group has incompatible unresolved observations."
                    )
            if decision in ("keep_local", "keep_both") and anchor[
                "local_fingerprint"
            ] is not None:
                raise StateError(
                    "This local file exceeds the Fabric upload protocol ceiling; "
                    "export it or choose keep-remote."
                )
            if decision == "keep_both" and anchor["local_digest"] is None:
                raise StateError("Keep-both requires preserved local bytes.")

            resolution_id = self._fresh_recovery_uuid_locked()
            successor_mutation_id = (
                self._fresh_recovery_uuid_locked()
                if decision in ("keep_local", "keep_both")
                else None
            )
            self._connection.execute(
                """INSERT INTO conflict_resolutions(
                       resolution_id, scope_id, anchor_conflict_id, mutation_id,
                       decision, phase, expected_local_digest,
                       expected_local_fingerprint,
                       expected_remote_digest, expected_remote_generation,
                       successor_mutation_id, created_at_ns, updated_at_ns
                   ) VALUES (?, ?, ?, ?, ?, 'requested', ?, ?, ?, ?, ?, ?, ?)""",
                (
                    resolution_id,
                    scope_id,
                    int(anchor["conflict_id"]),
                    mutation_id,
                    decision,
                    anchor["local_digest"],
                    anchor["local_fingerprint"],
                    anchor["remote_digest"],
                    anchor["remote_generation"],
                    successor_mutation_id,
                    now,
                    now,
                ),
            )
            row = self._connection.execute(
                "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                (resolution_id,),
            ).fetchone()
        assert row is not None
        return _conflict_resolution_from_row(row)

    def list_conflict_resolutions_for_work(
        self, *, limit: int = 64
    ) -> tuple[ConflictResolution, ...]:
        """Return bounded runnable work from the active authority only."""

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= _MAX_CONFLICT_WORK_PAGE
        ):
            raise ValueError(
                f"limit must be between 1 and {_MAX_CONFLICT_WORK_PAGE}."
            )
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   INDEXED BY conflict_resolution_work
                   WHERE scope_id = ?
                     AND (
                       phase IN ('requested','prepared','waiting_successor','applying_remote')
                       OR (phase = 'blocked' AND retry_requested_at_ns IS NOT NULL)
                     )
                   ORDER BY updated_at_ns, resolution_id LIMIT ?""",
                (scope_id, limit),
            ).fetchall()
        return tuple(_conflict_resolution_from_row(row) for row in rows)

    def get_active_conflict_resolution(
        self, resolution_id: str
    ) -> ConflictResolution | None:
        resolution_id = _canonical_uuid("resolution_id", resolution_id)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?""",
                (resolution_id, scope_id),
            ).fetchone()
        return _conflict_resolution_from_row(row) if row is not None else None

    def request_conflict_resolution_retry(
        self, conflict_id: int
    ) -> ConflictResolution:
        """Ask the coordinator to rebase one safely blocked active decision."""

        conflict_id = _positive_id("conflict_id", conflict_id)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            conflict = self._connection.execute(
                "SELECT * FROM conflicts WHERE scope_id = ? AND conflict_id = ?",
                (scope_id, conflict_id),
            ).fetchone()
            if conflict is None or conflict["resolved_at_ns"] is not None:
                raise StateError("The unresolved conflict is not in the active epoch.")
            if conflict["mutation_id"] is None:
                row = self._connection.execute(
                    """SELECT * FROM conflict_resolutions
                       WHERE scope_id = ? AND anchor_conflict_id = ?""",
                    (scope_id, conflict_id),
                ).fetchone()
            else:
                row = self._connection.execute(
                    """SELECT * FROM conflict_resolutions
                       WHERE scope_id = ? AND mutation_id = ?""",
                    (scope_id, str(conflict["mutation_id"])),
                ).fetchone()
            if row is None:
                raise StateError("The conflict has no durable decision to retry.")
            if str(row["phase"]) != "blocked" or not bool(row["retry_safe"]):
                raise StateError(
                    "This blocked decision cannot be safely rebased; inspect or export "
                    "the conflict before choosing a new recovery action."
                )
            if row["retry_requested_at_ns"] is None:
                self._connection.execute(
                    """UPDATE conflict_resolutions
                       SET retry_requested_at_ns = ?, updated_at_ns = ?
                       WHERE resolution_id = ? AND scope_id = ?
                         AND phase = 'blocked' AND retry_safe = 1""",
                    (now, now, str(row["resolution_id"]), scope_id),
                )
                row = self._connection.execute(
                    "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                    (str(row["resolution_id"]),),
                ).fetchone()
        assert row is not None
        return _conflict_resolution_from_row(row)

    def request_conflict_resolution_rearm(
        self, conflict_id: int
    ) -> ConflictResolution:
        """Queue explicit abandonment of a blocked, provably no-effect attempt.

        This is deliberately distinct from ``retry``: retry preserves the
        durable decision and is limited to phases that never published work.
        Rearm lets the coordinator retire a later failed attempt so the human
        can choose again, but only when the journal already proves that no
        remote effect is pending or ambiguous.  Filesystem and current remote
        preconditions are re-proved by the coordinator before abandonment.
        """

        conflict_id = _positive_id("conflict_id", conflict_id)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            conflict = self._connection.execute(
                "SELECT * FROM conflicts WHERE scope_id = ? AND conflict_id = ?",
                (scope_id, conflict_id),
            ).fetchone()
            if conflict is None or conflict["resolved_at_ns"] is not None:
                raise StateError("The unresolved conflict is not in the active epoch.")
            if conflict["mutation_id"] is None:
                row = self._connection.execute(
                    """SELECT * FROM conflict_resolutions
                       WHERE scope_id = ? AND anchor_conflict_id = ?""",
                    (scope_id, conflict_id),
                ).fetchone()
            else:
                row = self._connection.execute(
                    """SELECT * FROM conflict_resolutions
                       WHERE scope_id = ? AND mutation_id = ?""",
                    (scope_id, str(conflict["mutation_id"])),
                ).fetchone()
            if row is None:
                raise StateError("The conflict has no durable decision to rearm.")
            if str(row["phase"]) != "blocked" or bool(row["retry_safe"]):
                raise StateError(
                    "Only a blocked post-authorization decision can be rearmed; "
                    "use retry for a side-effect-free pre-authorization race."
                )
            self._require_no_effect_rearm_journal_locked(scope_id, row, conflict)
            if row["retry_requested_at_ns"] is None:
                self._connection.execute(
                    """UPDATE conflict_resolutions
                       SET retry_requested_at_ns = ?, updated_at_ns = ?
                       WHERE resolution_id = ? AND scope_id = ?
                         AND phase = 'blocked' AND retry_safe = 0""",
                    (now, now, str(row["resolution_id"]), scope_id),
                )
                row = self._connection.execute(
                    "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                    (str(row["resolution_id"]),),
                ).fetchone()
        assert row is not None
        return _conflict_resolution_from_row(row)

    def abandon_blocked_conflict_resolution(
        self,
        resolution_id: str,
        *,
        expected_local_digest: str | None,
        expected_local_fingerprint: str | None,
        materialized_fingerprint: str | None,
        local_bytes: int,
        expected_remote_digest: str | None,
        expected_remote_generation: int | None,
    ) -> int:
        """Retire one no-effect attempt and return its still-unresolved anchor.

        The transaction removes the old decision only after rechecking every
        journal proof that could imply a live or unknown remote effect.  A
        terminal conflicting successor is metadata-only evidence of a rejected
        mutation; it is folded into the original conflict and retired here.
        The original conflict remains the durable recovery handle, refreshed to
        the coordinator's exact current local and remote observations, so a
        subsequent ``resolve`` allocates fresh resolution and mutation IDs.
        """

        resolution_id = _canonical_uuid("resolution_id", resolution_id)
        expected_local_digest = _digest(
            "expected local digest", expected_local_digest
        )
        if expected_local_fingerprint is not None:
            expected_local_fingerprint = _bounded_text(
                "expected_local_fingerprint", expected_local_fingerprint, 4_096
            )
        if expected_local_digest is not None and expected_local_fingerprint is not None:
            raise ValueError("Local digest and identity evidence are alternatives.")
        if materialized_fingerprint is not None:
            materialized_fingerprint = _bounded_text(
                "materialized_fingerprint", materialized_fingerprint, 4_096
            )
        if (
            isinstance(local_bytes, bool)
            or not isinstance(local_bytes, int)
            or local_bytes < 0
        ):
            raise ValueError("local_bytes must be non-negative.")
        if (expected_local_digest is None and expected_local_fingerprint is None) != (
            materialized_fingerprint is None and local_bytes == 0
        ):
            raise ValueError("Local evidence and materialized state must agree.")
        if (
            expected_local_fingerprint is not None
            and materialized_fingerprint != expected_local_fingerprint
        ):
            raise ValueError(
                "Protocol-oversize identity must match materialized state."
            )
        expected_remote_digest = _digest(
            "expected remote digest", expected_remote_digest
        )
        if expected_remote_generation is not None:
            expected_remote_generation = _generation(expected_remote_generation)

        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?""",
                (resolution_id, scope_id),
            ).fetchone()
            if row is None:
                raise StateError("The conflict resolution is not in the active epoch.")
            if (
                str(row["phase"]) != "blocked"
                or bool(row["retry_safe"])
                or row["retry_requested_at_ns"] is None
            ):
                raise StateError("The conflict resolution has no rearm request.")
            anchor = self._connection.execute(
                """SELECT * FROM conflicts
                   WHERE scope_id = ? AND conflict_id = ?
                     AND resolved_at_ns IS NULL""",
                (scope_id, int(row["anchor_conflict_id"])),
            ).fetchone()
            if anchor is None:
                raise StateError("The conflict anchor is no longer unresolved.")
            successor = self._require_no_effect_rearm_journal_locked(
                scope_id, row, anchor
            )

            materialized = self._connection.execute(
                """SELECT state FROM materialized_entries
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, str(anchor["path"])),
            ).fetchone()
            if materialized is None or str(materialized["state"]) not in (
                "conflict",
                "dirty",
            ):
                # A path that has since converged (clean, mirroring the exact
                # current remote bytes, or absent on both sides) is the
                # strongest no-effect proof: the blocked decision protects
                # nothing. Retire the whole conflict group instead of leaving
                # sync wedged in "reconciling (unresolved_conflicts)" forever.
                remote_now = self._connection.execute(
                    "SELECT digest FROM remote_entries WHERE scope_id = ? AND path = ?",
                    (scope_id, str(anchor["path"])),
                ).fetchone()
                materialized_full = self._connection.execute(
                    """SELECT state, clean_digest, stat_fingerprint, bytes_on_disk
                       FROM materialized_entries
                       WHERE scope_id = ? AND path = ?""",
                    (scope_id, str(anchor["path"])),
                ).fetchone()
                clean_converged = (
                    materialized_full is not None
                    and str(materialized_full["state"]) == "clean"
                    and materialized_full["clean_digest"] is not None
                    and remote_now is not None
                    and str(remote_now["digest"]) == str(materialized_full["clean_digest"])
                )
                head = self._connection.execute(
                    "SELECT generation FROM remote_manifest_heads WHERE scope_id = ?",
                    (scope_id,),
                ).fetchone()
                observed_generation = int(head["generation"]) if head is not None else None
                conflict_path = str(anchor["path"])
                descendant = conflict_path + "/"
                descendant_upper = _prefix_upper_bound(descendant)
                remote_namespace_occupied = self._connection.execute(
                    """SELECT 1 FROM remote_directories
                       WHERE scope_id = ? AND (
                           path = ? OR (path >= ? AND path < ?)
                       )
                       UNION ALL
                       SELECT 1 FROM remote_entries
                       WHERE scope_id = ? AND (
                           (path >= ? AND path < ?)
                           OR substr(?, 1, length(path) + 1) = path || '/'
                       ) LIMIT 1""",
                    (
                        scope_id,
                        conflict_path,
                        descendant,
                        descendant_upper,
                        scope_id,
                        descendant,
                        descendant_upper,
                        conflict_path,
                    ),
                ).fetchone() is not None
                materialized_absent = materialized_full is None or (
                    str(materialized_full["state"]) == "absent"
                    and materialized_full["stat_fingerprint"] is None
                    and int(materialized_full["bytes_on_disk"]) == 0
                )
                both_absent = (
                    expected_local_digest is None
                    and expected_local_fingerprint is None
                    and materialized_fingerprint is None
                    and local_bytes == 0
                    and expected_remote_digest is None
                    and remote_now is None
                    and not remote_namespace_occupied
                    and materialized_absent
                    and observed_generation == expected_remote_generation
                )
                if not (clean_converged or both_absent):
                    raise StateError(
                        "The local recovery projection is no longer a conflict or "
                        "rejected successor."
                    )
                pending_namespace_work = self._connection.execute(
                    """WITH endpoints(endpoint) AS (
                           SELECT path FROM pending_operations
                            WHERE scope_id = ?
                              AND state IN ('queued','inflight','retry')
                           UNION ALL
                           SELECT destination_path FROM pending_operations
                            WHERE scope_id = ?
                              AND state IN ('queued','inflight','retry')
                              AND destination_path IS NOT NULL
                           UNION ALL
                           SELECT path FROM local_directory_puts WHERE scope_id = ?
                           UNION ALL
                           SELECT destination_path FROM local_directory_puts
                            WHERE scope_id = ? AND destination_path IS NOT NULL
                       ) SELECT 1 FROM endpoints WHERE
                           endpoint = ?
                           OR (endpoint >= ? AND endpoint < ?)
                           OR substr(?, 1, length(endpoint) + 1) = endpoint || '/'
                       LIMIT 1""",
                    (
                        scope_id,
                        scope_id,
                        scope_id,
                        scope_id,
                        conflict_path,
                        descendant,
                        descendant_upper,
                        conflict_path,
                    ),
                ).fetchone()
                if pending_namespace_work is not None:
                    raise StateError(
                        "A pending mutation owns the converged conflict path."
                    )
                converged_mutation_id = (
                    str(row["mutation_id"]) if row["mutation_id"] is not None else None
                )
                if converged_mutation_id is None:
                    converged_where = "conflict_id = ?"
                    converged_value: object = int(row["anchor_conflict_id"])
                else:
                    converged_where = "mutation_id = ?"
                    converged_value = converged_mutation_id
                self._connection.execute(
                    f"""UPDATE conflicts
                        SET resolved_at_ns = COALESCE(resolved_at_ns, ?)
                        WHERE scope_id = ? AND {converged_where}
                          AND resolved_at_ns IS NULL""",
                    (now, scope_id, converged_value),
                )
                self._connection.execute(
                    """UPDATE conflicts SET resolved_at_ns = COALESCE(resolved_at_ns, ?)
                       WHERE scope_id = ? AND conflict_id = ?""",
                    (now, scope_id, int(row["anchor_conflict_id"])),
                )
                if successor is not None:
                    self._connection.execute(
                        """UPDATE conflicts SET resolved_at_ns = COALESCE(resolved_at_ns, ?)
                           WHERE scope_id = ? AND mutation_id = ?""",
                        (now, scope_id, str(successor["mutation_id"])),
                    )
                deleted_converged = self._connection.execute(
                    """DELETE FROM conflict_resolutions
                       WHERE resolution_id = ? AND scope_id = ?
                         AND phase = 'blocked' AND retry_safe = 0
                         AND retry_requested_at_ns IS NOT NULL""",
                    (resolution_id, scope_id),
                )
                if deleted_converged.rowcount != 1:
                    raise StateError("The conflict rearm raced another coordinator.")
                return int(row["anchor_conflict_id"])
            remote = self._connection.execute(
                "SELECT digest FROM remote_entries WHERE scope_id = ? AND path = ?",
                (scope_id, str(anchor["path"])),
            ).fetchone()
            observed_remote = str(remote["digest"]) if remote is not None else None
            if observed_remote != expected_remote_digest:
                raise StateError("The remote state advanced during conflict rearm.")
            head = self._connection.execute(
                "SELECT generation FROM remote_manifest_heads WHERE scope_id = ?",
                (scope_id,),
            ).fetchone()
            observed_generation = int(head["generation"]) if head is not None else None
            if observed_generation != expected_remote_generation:
                raise StateError("The remote generation advanced during conflict rearm.")

            self._retire_exact_pending_local_locked(
                scope_id,
                str(anchor["path"]),
                expected_local_digest=expected_local_digest,
                materialized_fingerprint=materialized_fingerprint,
                local_bytes=local_bytes,
            )

            old_local_digest = anchor["local_digest"]
            old_local_fingerprint = anchor["local_fingerprint"]
            keep_stage = (
                old_local_digest == expected_local_digest
                and old_local_fingerprint == expected_local_fingerprint
            )
            mutation_id = (
                str(row["mutation_id"]) if row["mutation_id"] is not None else None
            )
            if mutation_id is None:
                group_where = "conflict_id = ?"
                group_value: object = int(row["anchor_conflict_id"])
            else:
                group_where = "mutation_id = ?"
                group_value = mutation_id
            self._connection.execute(
                f"""UPDATE conflicts
                    SET local_digest = ?, local_fingerprint = ?,
                        remote_digest = ?, remote_generation = ?,
                        staged_path = CASE WHEN ? THEN staged_path ELSE NULL END
                    WHERE scope_id = ? AND {group_where}
                      AND resolved_at_ns IS NULL""",
                (
                    expected_local_digest,
                    expected_local_fingerprint,
                    expected_remote_digest,
                    expected_remote_generation,
                    int(keep_stage),
                    scope_id,
                    group_value,
                ),
            )
            # Remote-apply divergence can create a second standalone record for
            # the same exact current bytes. Fold only exact, newer observations;
            # unrelated or incompatible conflict evidence remains visible.
            self._connection.execute(
                """UPDATE conflicts SET resolved_at_ns = ?
                   WHERE scope_id = ? AND conflict_id != ?
                     AND mutation_id IS NULL AND path = ?
                     AND resolved_at_ns IS NULL AND recorded_at_ns >= ?
                     AND local_digest IS ? AND local_fingerprint IS ?
                     AND remote_digest IS ? AND remote_generation IS ?""",
                (
                    now,
                    scope_id,
                    int(row["anchor_conflict_id"]),
                    str(anchor["path"]),
                    int(row["created_at_ns"]),
                    expected_local_digest,
                    expected_local_fingerprint,
                    expected_remote_digest,
                    expected_remote_generation,
                ),
            )
            self._connection.execute(
                """UPDATE materialized_entries
                   SET state = 'conflict', clean_digest = ?,
                       stat_fingerprint = ?, bytes_on_disk = ?, pinned = 1,
                       accessed_at_ns = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ?""",
                (
                    expected_remote_digest,
                    materialized_fingerprint,
                    local_bytes,
                    now,
                    now,
                    scope_id,
                    str(anchor["path"]),
                ),
            )

            if successor is not None:
                successor_id = str(successor["mutation_id"])
                self._connection.execute(
                    """UPDATE conflicts SET resolved_at_ns = COALESCE(resolved_at_ns, ?)
                       WHERE scope_id = ? AND mutation_id = ?""",
                    (now, scope_id, successor_id),
                )
                # Keep the terminal operation and its stage handles until the
                # ordinary resolved-conflict cleanup has removed the stage
                # family and released its cache owner. It is no longer
                # sendable, and all of its conflict evidence is resolved in
                # this same transaction.

            deleted_resolution = self._connection.execute(
                """DELETE FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?
                     AND phase = 'blocked' AND retry_safe = 0
                     AND retry_requested_at_ns IS NOT NULL""",
                (resolution_id, scope_id),
            )
            if deleted_resolution.rowcount != 1:
                raise StateError("The conflict rearm raced another coordinator.")
        return int(row["anchor_conflict_id"])

    def _retire_exact_pending_local_locked(
        self,
        scope_id: int,
        path: str,
        *,
        expected_local_digest: str | None,
        materialized_fingerprint: str | None,
        local_bytes: int,
    ) -> None:
        """Retire an exact unsent watcher handoff for the rearmed path.

        A post-authorization local edit can be observed by the normal watcher
        while the old conflict decision is still failing. Leaving that queued
        handoff alive would race the fresh decision and recreate the dead-end.
        It is safe to retire only when it represents the exact bytes just
        observed by the coordinator and has no receipt, unknown outcome,
        inflight claim, or dependent work.
        """

        operations = self._connection.execute(
            """SELECT * FROM pending_operations
               WHERE scope_id = ? AND state IN ('queued','inflight','retry')
                 AND (path = ? OR destination_path = ?)
               ORDER BY journal_seq LIMIT 2""",
            (scope_id, path, path),
        ).fetchall()
        if len(operations) > 1:
            raise StateError(
                "Multiple pending mutations own the conflict path and cannot be rearmed."
            )
        if operations:
            operation = operations[0]
            mutation_id = str(operation["mutation_id"])
            exact_put = (
                str(operation["kind"]) == "put"
                and str(operation["path"]) == path
                and operation["destination_path"] is None
                and operation["staged_digest"] == expected_local_digest
                and operation["staged_size"] is not None
                and int(operation["staged_size"]) == local_bytes
            )
            exact_delete = (
                str(operation["kind"]) == "delete"
                and str(operation["path"]) == path
                and expected_local_digest is None
                and materialized_fingerprint is None
                and local_bytes == 0
            )
            if (
                str(operation["state"]) not in ("queued", "retry")
                or bool(operation["commit_unknown"])
                or not (exact_put or exact_delete)
            ):
                raise StateError(
                    "A pending mutation with possible or different effects owns "
                    "the conflict path."
                )
            if self._connection.execute(
                "SELECT 1 FROM operation_receipts WHERE mutation_id = ? LIMIT 1",
                (mutation_id,),
            ).fetchone() is not None:
                raise StateError(
                    "A pending path mutation has a durable receipt and cannot be rearmed."
                )
            if self._connection.execute(
                """SELECT 1 FROM operation_dependencies
                   WHERE scope_id = ? AND predecessor_mutation_id = ? LIMIT 1""",
                (scope_id, mutation_id),
            ).fetchone() is not None:
                raise StateError(
                    "The pending path mutation has dependent work and cannot be rearmed."
                )
            now = time.time_ns()
            self._connection.execute(
                """INSERT INTO conflicts(
                       scope_id, mutation_id, path, reason,
                       base_digest, local_digest, staged_path,
                       recorded_at_ns, resolved_at_ns
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    scope_id,
                    mutation_id,
                    path,
                    "exact local watcher handoff retired by conflict rearm",
                    operation["expected_source_digest"],
                    operation["staged_digest"],
                    operation["staged_path"],
                    now,
                    now,
                ),
            )
            updated = self._connection.execute(
                """UPDATE pending_operations
                   SET state = 'conflict', commit_unknown = 0, commit_batch_id = NULL,
                       last_error = ?, claimed_at_ns = NULL,
                       next_attempt_at_ns = NULL, ready_at_ns = ?, updated_at_ns = ?
                   WHERE mutation_id = ? AND scope_id = ?
                     AND state IN ('queued','retry') AND commit_unknown = 0""",
                (
                    "exact local watcher handoff retired by conflict rearm",
                    now,
                    now,
                    mutation_id,
                    scope_id,
                ),
            )
            if updated.rowcount != 1:
                raise StateError("The pending path mutation changed during rearm.")

        intent = self._connection.execute(
            """SELECT transfer_id, source_fingerprint
               FROM local_transfer_intents WHERE scope_id = ? AND path = ?""",
            (scope_id, path),
        ).fetchone()
        if intent is not None:
            qualifier = (
                "different"
                if materialized_fingerprint is None
                or str(intent["source_fingerprint"]) != materialized_fingerprint
                else "unfinished"
            )
            raise StateError(
                f"An {qualifier} local snapshot is still being staged for the "
                "conflict path."
            )

    def _require_no_effect_rearm_journal_locked(
        self, scope_id: int, resolution: sqlite3.Row, conflict: sqlite3.Row
    ) -> sqlite3.Row | None:
        """Prove that abandoning ``resolution`` cannot discard a remote effect."""

        if self._connection.execute(
            """SELECT 1 FROM remote_apply_intents
               WHERE scope_id = ? AND path = ? LIMIT 1""",
            (scope_id, str(conflict["path"])),
        ).fetchone() is not None:
            raise StateError(
                "The decision still owns a remote-apply intent and cannot be rearmed."
            )
        successor_id = resolution["successor_mutation_id"]
        if successor_id is None:
            return None
        successor = self._connection.execute(
            """SELECT * FROM pending_operations
               WHERE mutation_id = ? AND scope_id = ?""",
            (str(successor_id), scope_id),
        ).fetchone()
        if successor is None:
            return None
        if self._connection.execute(
            "SELECT 1 FROM operation_receipts WHERE mutation_id = ? LIMIT 1",
            (str(successor_id),),
        ).fetchone() is not None:
            raise StateError(
                "The decision successor has a durable remote receipt and cannot be rearmed."
            )
        if bool(successor["commit_unknown"]):
            raise StateError(
                "The decision successor has an unknown remote outcome and cannot be rearmed."
            )
        if str(successor["state"]) != "conflict":
            raise StateError(
                "The decision successor is not a terminal no-effect conflict and "
                "cannot be rearmed."
            )
        if self._connection.execute(
            """SELECT 1 FROM operation_dependencies
               WHERE scope_id = ? AND predecessor_mutation_id = ? LIMIT 1""",
            (scope_id, str(successor_id)),
        ).fetchone() is not None:
            raise StateError(
                "The rejected successor has dependent journal work and cannot be rearmed."
            )
        return successor

    def rebase_blocked_conflict_resolution(
        self,
        resolution_id: str,
        *,
        expected_local_digest: str | None,
        expected_local_fingerprint: str | None,
        materialized_fingerprint: str | None,
        local_bytes: int,
        expected_remote_digest: str | None,
        expected_remote_generation: int | None,
    ) -> ConflictResolution:
        """Re-arm a side-effect-free block against freshly observed exact state."""

        resolution_id = _canonical_uuid("resolution_id", resolution_id)
        expected_local_digest = _digest(
            "expected local digest", expected_local_digest
        )
        if expected_local_fingerprint is not None:
            expected_local_fingerprint = _bounded_text(
                "expected_local_fingerprint", expected_local_fingerprint, 4_096
            )
        if expected_local_digest is not None and expected_local_fingerprint is not None:
            raise ValueError("Local digest and identity evidence are alternatives.")
        if materialized_fingerprint is not None:
            materialized_fingerprint = _bounded_text(
                "materialized_fingerprint", materialized_fingerprint, 4_096
            )
        if (
            isinstance(local_bytes, bool)
            or not isinstance(local_bytes, int)
            or local_bytes < 0
        ):
            raise ValueError("local_bytes must be non-negative.")
        if (expected_local_digest is None and expected_local_fingerprint is None) != (
            materialized_fingerprint is None and local_bytes == 0
        ):
            raise ValueError("Local evidence and materialized state must agree.")
        if (
            expected_local_fingerprint is not None
            and materialized_fingerprint != expected_local_fingerprint
        ):
            raise ValueError(
                "Protocol-oversize identity must match materialized state."
            )
        expected_remote_digest = _digest(
            "expected remote digest", expected_remote_digest
        )
        if expected_remote_generation is not None:
            expected_remote_generation = _generation(expected_remote_generation)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?""",
                (resolution_id, scope_id),
            ).fetchone()
            if row is None:
                raise StateError("The conflict resolution is not in the active epoch.")
            if (
                str(row["phase"]) != "blocked"
                or not bool(row["retry_safe"])
                or row["retry_requested_at_ns"] is None
            ):
                raise StateError("The conflict resolution has no safe retry request.")
            decision = str(row["decision"])
            if expected_local_fingerprint is not None and decision != "keep_remote":
                raise StateError(
                    "Protocol-oversize local bytes cannot be uploaded by this decision."
                )
            anchor = self._connection.execute(
                """SELECT * FROM conflicts
                   WHERE scope_id = ? AND conflict_id = ?
                     AND resolved_at_ns IS NULL""",
                (scope_id, int(row["anchor_conflict_id"])),
            ).fetchone()
            if anchor is None:
                raise StateError("The conflict anchor is no longer unresolved.")
            old_successor = row["successor_mutation_id"]
            if old_successor is not None:
                published = self._connection.execute(
                    "SELECT 1 FROM pending_operations WHERE mutation_id = ? LIMIT 1",
                    (str(old_successor),),
                ).fetchone()
                if published is not None:
                    raise StateError(
                        "The blocked decision already published successor work and "
                        "cannot be rebased safely."
                    )
            if self._connection.execute(
                """SELECT 1 FROM remote_apply_intents
                   WHERE scope_id = ? AND path = ? LIMIT 1""",
                (scope_id, str(anchor["path"])),
            ).fetchone() is not None:
                raise StateError(
                    "The blocked decision already authorized remote apply and "
                    "cannot be rebased safely."
                )
            materialized = self._connection.execute(
                """SELECT state FROM materialized_entries
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, str(anchor["path"])),
            ).fetchone()
            if materialized is None or str(materialized["state"]) != "conflict":
                raise StateError(
                    "The local conflict projection changed during retry rebase."
                )
            remote = self._connection.execute(
                "SELECT digest FROM remote_entries WHERE scope_id = ? AND path = ?",
                (scope_id, str(anchor["path"])),
            ).fetchone()
            observed_remote = str(remote["digest"]) if remote is not None else None
            if observed_remote != expected_remote_digest:
                raise StateError("The remote state advanced during retry rebase.")
            successor = (
                self._fresh_recovery_uuid_locked()
                if decision in ("keep_local", "keep_both")
                else None
            )
            self._connection.execute(
                """UPDATE materialized_entries
                   SET stat_fingerprint = ?, bytes_on_disk = ?, pinned = 1,
                       accessed_at_ns = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ? AND state = 'conflict'""",
                (
                    materialized_fingerprint,
                    local_bytes,
                    now,
                    now,
                    scope_id,
                    str(anchor["path"]),
                ),
            )
            updated = self._connection.execute(
                """UPDATE conflict_resolutions
                   SET phase = 'requested',
                       expected_local_digest = ?,
                       expected_local_fingerprint = ?,
                       expected_remote_digest = ?,
                       expected_remote_generation = ?,
                       successor_mutation_id = ?, survivor_path = NULL,
                       staged_path = NULL, staged_digest = NULL, staged_size = NULL,
                       last_error = NULL, retry_safe = 0,
                       retry_requested_at_ns = NULL, updated_at_ns = ?
                   WHERE resolution_id = ? AND scope_id = ?
                     AND phase = 'blocked' AND retry_safe = 1
                     AND retry_requested_at_ns IS NOT NULL""",
                (
                    expected_local_digest,
                    expected_local_fingerprint,
                    expected_remote_digest,
                    expected_remote_generation,
                    successor,
                    now,
                    resolution_id,
                    scope_id,
                ),
            )
            if updated.rowcount != 1:
                raise StateError("The conflict retry raced another coordinator.")
            row = self._connection.execute(
                "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                (resolution_id,),
            ).fetchone()
        assert row is not None
        return _conflict_resolution_from_row(row)

    def get_applying_conflict_resolution_for_path(
        self, path: str
    ) -> ConflictResolution | None:
        """Return one exact active remote-apply owner, failing on ambiguity."""

        path = _canonical_path(path)
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            rows = self._connection.execute(
                """SELECT resolution.*
                   FROM conflicts AS conflict INDEXED BY conflict_scope_path
                   JOIN conflict_resolutions AS resolution
                     ON resolution.anchor_conflict_id = conflict.conflict_id
                    AND resolution.scope_id = conflict.scope_id
                   WHERE conflict.scope_id = ? AND conflict.path = ?
                     AND resolution.phase = 'applying_remote'
                   ORDER BY resolution.resolution_id LIMIT 2""",
                (scope_id, path),
            ).fetchall()
        if len(rows) > 1:
            raise StateError(
                "Multiple conflict resolutions claim the same remote-apply path."
            )
        return _conflict_resolution_from_row(rows[0]) if rows else None

    def transition_conflict_resolution(
        self,
        resolution_id: str,
        *,
        expected_phase: ConflictResolutionPhase | str,
        phase: ConflictResolutionPhase | str,
        staged_path: Path | str | None = None,
        staged_digest: str | None = None,
        staged_size: int | None = None,
        survivor_path: str | None = None,
        last_error: str | None = None,
        retry_safe: bool = False,
    ) -> ConflictResolution | None:
        """CAS one coordinator phase and its immutable filesystem handles.

        An exact post-commit retry returns the current row. A stale worker gets
        ``None``. The terminal phase is reserved for
        :meth:`complete_conflict_resolution`, which owns the proof checks.
        """

        resolution_id = _canonical_uuid("resolution_id", resolution_id)
        expected_phase = _conflict_resolution_phase(expected_phase)
        phase = _conflict_resolution_phase(phase)
        if phase == "completed":
            raise ValueError("Use complete_conflict_resolution for completion.")
        if phase != expected_phase and phase not in _CONFLICT_RESOLUTION_TRANSITIONS[expected_phase]:
            raise ValueError(
                f"Conflict resolution cannot transition from {expected_phase} to {phase}."
            )
        stage_values = (staged_path, staged_digest, staged_size)
        if any(value is not None for value in stage_values) and not all(
            value is not None for value in stage_values
        ):
            raise ValueError("staged_path, staged_digest, and staged_size are one tuple.")
        normalized_staged_path: str | None = None
        if staged_path is not None:
            normalized_staged_path = str(
                Path(staged_path).expanduser().resolve(strict=False)
            )
            staged_digest = _digest("staged digest", staged_digest, required=True)
            if (
                isinstance(staged_size, bool)
                or not isinstance(staged_size, int)
                or staged_size < 0
            ):
                raise ValueError("staged_size must be non-negative.")
        normalized_survivor = (
            _canonical_path(survivor_path) if survivor_path is not None else None
        )
        if phase == "blocked":
            if last_error is None:
                raise ValueError("A blocked resolution requires last_error.")
            last_error = _bounded_text("last_error", last_error, _MAX_ERROR_BYTES)
            if not isinstance(retry_safe, bool):
                raise ValueError("retry_safe must be a boolean.")
        elif last_error is not None:
            raise ValueError("last_error is valid only for a blocked resolution.")
        elif retry_safe:
            raise ValueError("retry_safe is valid only for a blocked resolution.")

        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?""",
                (resolution_id, scope_id),
            ).fetchone()
            if row is None:
                raise StateError("The conflict resolution is not in the active epoch.")
            if normalized_survivor is not None and str(row["decision"]) != "keep_both":
                raise StateError("Only keep-both can publish a survivor path.")
            if str(row["phase"]) != expected_phase:
                if str(row["phase"]) == phase and _resolution_fields_match(
                    row,
                    staged_path=normalized_staged_path,
                    staged_digest=staged_digest,
                    staged_size=staged_size,
                    survivor_path=normalized_survivor,
                    last_error=last_error,
                    retry_safe=retry_safe,
                ):
                    return _conflict_resolution_from_row(row)
                return None
            for column, proposed in (
                ("staged_path", normalized_staged_path),
                ("staged_digest", staged_digest),
                ("staged_size", staged_size),
                ("survivor_path", normalized_survivor),
            ):
                if proposed is not None and row[column] is not None and row[column] != proposed:
                    raise StateError(
                        f"The conflict resolution already owns a different {column}."
                    )
            self._connection.execute(
                """UPDATE conflict_resolutions
                   SET phase = ?,
                       staged_path = COALESCE(staged_path, ?),
                       staged_digest = COALESCE(staged_digest, ?),
                       staged_size = COALESCE(staged_size, ?),
                       survivor_path = COALESCE(survivor_path, ?),
                       last_error = ?, retry_safe = ?,
                       retry_requested_at_ns = NULL, updated_at_ns = ?
                   WHERE resolution_id = ? AND scope_id = ? AND phase = ?""",
                (
                    phase,
                    normalized_staged_path,
                    staged_digest,
                    staged_size,
                    normalized_survivor,
                    last_error,
                    int(retry_safe),
                    now,
                    resolution_id,
                    scope_id,
                    expected_phase,
                ),
            )
            updated = self._connection.execute(
                "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                (resolution_id,),
            ).fetchone()
        assert updated is not None
        return _conflict_resolution_from_row(updated)

    def complete_conflict_resolution(
        self, resolution_id: str
    ) -> ConflictResolution:
        """Atomically resolve a group only after durable postcondition proof."""

        resolution_id = _canonical_uuid("resolution_id", resolution_id)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?""",
                (resolution_id, scope_id),
            ).fetchone()
            if row is None:
                raise StateError("The conflict resolution is not in the active epoch.")
            if str(row["phase"]) == "completed":
                return _conflict_resolution_from_row(row)

            decision = str(row["decision"])
            required_phase = (
                "waiting_successor" if decision == "keep_local" else "applying_remote"
            )
            if str(row["phase"]) != required_phase:
                raise StateError(
                    f"The {decision} resolution is not ready for completion."
                )
            if decision in ("keep_local", "keep_both"):
                self._require_resolution_successor_receipt_locked(row)
            if decision in ("keep_remote", "keep_both"):
                self._require_resolution_materialization_locked(row)

            if row["mutation_id"] is None:
                resolved = self._connection.execute(
                    """UPDATE conflicts SET resolved_at_ns = ?
                       WHERE scope_id = ? AND conflict_id = ?
                         AND resolved_at_ns IS NULL""",
                    (now, scope_id, int(row["anchor_conflict_id"])),
                )
            else:
                resolved = self._connection.execute(
                    """UPDATE conflicts SET resolved_at_ns = ?
                       WHERE scope_id = ? AND mutation_id = ?
                         AND resolved_at_ns IS NULL""",
                    (now, scope_id, str(row["mutation_id"])),
                )
            if resolved.rowcount < 1:
                raise StateError("The conflict group has no unresolved records.")
            self._connection.execute(
                """UPDATE conflict_resolutions
                   SET phase = 'completed', staged_path = NULL,
                       staged_digest = NULL, staged_size = NULL,
                       last_error = NULL, completed_at_ns = ?, updated_at_ns = ?
                   WHERE resolution_id = ? AND scope_id = ?
                     AND phase = ?""",
                (now, now, resolution_id, scope_id, required_phase),
            )
            # Both decisions normally clear the fence through the receipt they
            # required above (an ACK marks the path clean/absent). If one did
            # not, the resolved group would leave the entry pinned in
            # `conflict` with nothing backing it -- unreadable, and invisible
            # to `conflicts list`. Release it here on the same evidence rule
            # the startup repair uses; a path that still holds an unresolved
            # conflict is untouched by the WHERE clause.
            anchor_path = self._connection.execute(
                "SELECT path FROM conflicts WHERE conflict_id = ? AND scope_id = ?",
                (int(row["anchor_conflict_id"]), scope_id),
            ).fetchone()
            if anchor_path is not None:
                self._connection.execute(
                    """UPDATE materialized_entries
                       SET state = CASE
                               WHEN bytes_on_disk > 0 OR stat_fingerprint IS NOT NULL
                               THEN 'dirty' ELSE 'absent' END,
                           pinned = 0, updated_at_ns = ?
                       WHERE scope_id = ? AND path = ? AND state = 'conflict'
                         AND NOT EXISTS (
                             SELECT 1 FROM conflicts
                              WHERE conflicts.scope_id = ?
                                AND conflicts.path = ?
                                AND conflicts.resolved_at_ns IS NULL
                         )""",
                    (
                        now,
                        scope_id,
                        str(anchor_path["path"]),
                        scope_id,
                        str(anchor_path["path"]),
                    ),
                )
            completed = self._connection.execute(
                "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                (resolution_id,),
            ).fetchone()
        assert completed is not None
        return _conflict_resolution_from_row(completed)

    def complete_unsent_directory_rename_keep_remote(
        self, resolution_id: str
    ) -> ConflictResolution:
        """Retire an unsent directory-rename overlay under keep-remote.

        Directory conflicts normally need endpoint-by-endpoint evidence that
        the current file-oriented recovery protocol does not carry.  One case
        is nevertheless fully provable from the durable journal: a local
        preflight conflict whose rename never froze a request digest, never
        received a receipt, and has no unknown outcome.  The remote namespace
        cannot contain an effect from that operation.  Completing keep-remote
        removes only the metadata-only overlay and its empty root projection;
        descendant files remain governed by the ordinary remote manifest.
        """

        resolution_id = _canonical_uuid("resolution_id", resolution_id)
        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            resolution = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?""",
                (resolution_id, scope_id),
            ).fetchone()
            if resolution is None:
                raise StateError("The conflict resolution is not in the active epoch.")
            if str(resolution["phase"]) == "completed":
                return _conflict_resolution_from_row(resolution)
            if str(resolution["decision"]) != "keep_remote" or str(
                resolution["phase"]
            ) not in ("requested", "blocked"):
                raise StateError(
                    "Only a requested unsent directory keep-remote decision can complete directly."
                )
            if (
                str(resolution["phase"]) == "blocked"
                and resolution["retry_requested_at_ns"] is None
            ):
                raise StateError("The blocked directory decision has no rearm request.")
            mutation_id = resolution["mutation_id"]
            if mutation_id is None:
                raise StateError("The directory conflict has no linked operation.")
            operation = self._connection.execute(
                """SELECT * FROM pending_operations
                   WHERE mutation_id = ? AND scope_id = ?""",
                (str(mutation_id), scope_id),
            ).fetchone()
            if (
                operation is None
                or str(operation["kind"]) != "rename"
                or not bool(operation["directory_rename"])
                or str(operation["state"]) != "conflict"
                or bool(operation["commit_unknown"])
                or operation["request_digest"] is not None
            ):
                raise StateError(
                    "The directory rename lacks exact proof that it never crossed the remote boundary."
                )
            if self._connection.execute(
                "SELECT 1 FROM operation_receipts WHERE mutation_id = ? LIMIT 1",
                (str(mutation_id),),
            ).fetchone() is not None:
                raise StateError("The directory rename has a durable remote receipt.")

            resolved = self._connection.execute(
                """UPDATE conflicts SET resolved_at_ns = ?
                   WHERE scope_id = ? AND mutation_id = ?
                     AND resolved_at_ns IS NULL""",
                (now, scope_id, str(mutation_id)),
            )
            if resolved.rowcount < 1:
                raise StateError("The directory conflict group has no unresolved records.")
            self._connection.execute(
                """DELETE FROM materialized_entries
                   WHERE scope_id = ? AND path = ? AND state = 'conflict'
                     AND clean_digest IS NULL AND stat_fingerprint IS NULL
                     AND bytes_on_disk = 0""",
                (scope_id, str(operation["path"])),
            )
            self._connection.execute(
                """UPDATE pending_operations
                   SET directory_rename_observed = 1, updated_at_ns = ?
                   WHERE mutation_id = ? AND scope_id = ?
                     AND state = 'conflict' AND directory_rename = 1""",
                (now, str(mutation_id), scope_id),
            )
            self._connection.execute(
                """UPDATE conflict_resolutions
                   SET phase = 'completed', last_error = NULL,
                       retry_safe = 0, retry_requested_at_ns = NULL,
                       completed_at_ns = ?, updated_at_ns = ?
                   WHERE resolution_id = ? AND scope_id = ?
                     AND phase IN ('requested','blocked')""",
                (now, now, resolution_id, scope_id),
            )
            completed = self._connection.execute(
                "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                (resolution_id,),
            ).fetchone()
        assert completed is not None
        return _conflict_resolution_from_row(completed)

    def authorize_conflict_remote_apply(
        self,
        resolution_id: str,
        *,
        expected_phase: ConflictResolutionPhase | str,
        local_fingerprint: str | None,
        local_bytes: int,
    ) -> ConflictResolution:
        """Atomically authorize the existing guarded remote-apply machinery.

        The coordinator has already verified either the local digest or an
        explicit protocol-oversize stat identity. This transaction verifies
        that durable evidence and the accepted remote
        namespace, converts only that exact loser into the clean baseline used
        by normal remote apply, persists the apply intent, and advances phase.
        There is therefore no crash window where a restart can upload the loser
        or forget that the remote winner was authorized.
        """

        resolution_id = _canonical_uuid("resolution_id", resolution_id)
        expected_phase = _conflict_resolution_phase(expected_phase)
        if expected_phase not in ("prepared", "waiting_successor"):
            raise ValueError(
                "Remote apply may be authorized only from prepared or waiting_successor."
            )
        if (
            isinstance(local_bytes, bool)
            or not isinstance(local_bytes, int)
            or local_bytes < 0
        ):
            raise ValueError("local_bytes must be non-negative.")
        if local_fingerprint is not None:
            local_fingerprint = _bounded_text(
                "local_fingerprint", local_fingerprint, 4_096
            )

        now = time.time_ns()
        with self._transaction():
            scope_id = self._active_scope_id()
            resolution = self._connection.execute(
                """SELECT * FROM conflict_resolutions
                   WHERE resolution_id = ? AND scope_id = ?""",
                (resolution_id, scope_id),
            ).fetchone()
            if resolution is None:
                raise StateError("The conflict resolution is not in the active epoch.")
            decision = str(resolution["decision"])
            if decision not in ("keep_remote", "keep_both"):
                raise StateError("This resolution does not accept the remote winner.")
            if decision == "keep_remote" and expected_phase != "prepared":
                raise ValueError("Keep-remote authorizes apply from prepared.")
            if decision == "keep_both" and expected_phase != "waiting_successor":
                raise ValueError("Keep-both authorizes apply after its successor proof.")
            if decision == "keep_both":
                self._require_resolution_successor_receipt_locked(resolution)

            conflict = self._connection.execute(
                """SELECT * FROM conflicts
                   WHERE conflict_id = ? AND scope_id = ?
                     AND resolved_at_ns IS NULL""",
                (int(resolution["anchor_conflict_id"]), scope_id),
            ).fetchone()
            if conflict is None:
                raise StateError("The resolution anchor is no longer unresolved.")
            path = str(conflict["path"])
            expected_local = resolution["expected_local_digest"]
            expected_local_fingerprint = resolution[
                "expected_local_fingerprint"
            ]
            if expected_local is None and expected_local_fingerprint is None:
                if local_fingerprint is not None or local_bytes != 0:
                    raise StateError("Known local absence cannot carry local bytes.")
            elif local_fingerprint is None:
                raise StateError("Local bytes require their exact stat fingerprint.")
            elif (
                expected_local_fingerprint is not None
                and local_fingerprint != expected_local_fingerprint
            ):
                raise StateError("The protocol-oversize local identity advanced.")

            remote = self._connection.execute(
                "SELECT digest FROM remote_entries WHERE scope_id = ? AND path = ?",
                (scope_id, path),
            ).fetchone()
            expected_remote = resolution["expected_remote_digest"]
            if (
                (expected_remote is None and remote is not None)
                or (
                    expected_remote is not None
                    and (remote is None or remote["digest"] != expected_remote)
                )
            ):
                raise StateError("The remote conflict winner advanced before apply.")

            materialized = self._connection.execute(
                """SELECT * FROM materialized_entries
                   WHERE scope_id = ? AND path = ?""",
                (scope_id, path),
            ).fetchone()
            exact_baseline = (
                materialized is not None
                and str(materialized["state"]) == "clean"
                and materialized["clean_digest"] == expected_local
                and materialized["stat_fingerprint"] == local_fingerprint
                and int(materialized["bytes_on_disk"]) == local_bytes
            )
            if str(resolution["phase"]) == "applying_remote":
                intent = self._connection.execute(
                    """SELECT 1 FROM remote_apply_intents
                       WHERE scope_id = ? AND path = ?""",
                    (scope_id, path),
                ).fetchone()
                if exact_baseline and intent is not None:
                    return _conflict_resolution_from_row(resolution)
                raise StateError("The remote-apply authorization replay is incomplete.")
            if str(resolution["phase"]) != expected_phase:
                raise StateError("The conflict resolution phase changed before apply.")
            if (
                materialized is None
                or str(materialized["state"]) != "conflict"
                or materialized["stat_fingerprint"] != local_fingerprint
                or int(materialized["bytes_on_disk"]) != local_bytes
            ):
                raise StateError("The local conflict loser advanced before apply.")

            self._connection.execute(
                """UPDATE materialized_entries
                   SET state = 'clean', pinned = 0, clean_digest = ?,
                       stat_fingerprint = ?, bytes_on_disk = ?,
                       accessed_at_ns = ?, updated_at_ns = ?
                   WHERE scope_id = ? AND path = ? AND state = 'conflict'""",
                (
                    expected_local,
                    local_fingerprint,
                    local_bytes,
                    now,
                    now,
                    scope_id,
                    path,
                ),
            )
            self._connection.execute(
                """INSERT OR IGNORE INTO remote_apply_intents(
                       scope_id, path, created_at_ns
                   ) VALUES (?, ?, ?)""",
                (scope_id, path, now),
            )
            updated = self._connection.execute(
                """UPDATE conflict_resolutions
                   SET phase = 'applying_remote', last_error = NULL,
                       updated_at_ns = ?
                   WHERE resolution_id = ? AND scope_id = ? AND phase = ?""",
                (now, resolution_id, scope_id, expected_phase),
            )
            if updated.rowcount != 1:
                raise StateError("The conflict resolution phase changed before apply.")
            row = self._connection.execute(
                "SELECT * FROM conflict_resolutions WHERE resolution_id = ?",
                (resolution_id,),
            ).fetchone()
        assert row is not None
        return _conflict_resolution_from_row(row)

    def _conflict_views_locked(
        self, scope_id: int, rows: Sequence[sqlite3.Row]
    ) -> tuple[ConflictView, ...]:
        if not rows:
            return ()
        conflicts = tuple(_conflict_from_row(row) for row in rows)
        mutation_ids = tuple(
            dict.fromkeys(
                conflict.mutation_id
                for conflict in conflicts
                if conflict.mutation_id is not None
            )
        )
        operations: dict[str, PendingOperation] = {}
        if mutation_ids:
            placeholders = ",".join("?" for _ in mutation_ids)
            operation_rows = self._connection.execute(
                f"""SELECT * FROM pending_operations
                    WHERE scope_id = ? AND mutation_id IN ({placeholders})""",
                (scope_id, *mutation_ids),
            ).fetchall()
            operations = {
                str(row["mutation_id"]): _operation_from_row(row)
                for row in operation_rows
            }

        resolution_rows: list[sqlite3.Row] = []
        if mutation_ids:
            placeholders = ",".join("?" for _ in mutation_ids)
            resolution_rows.extend(
                self._connection.execute(
                    f"""SELECT * FROM conflict_resolutions
                        WHERE scope_id = ? AND mutation_id IN ({placeholders})""",
                    (scope_id, *mutation_ids),
                ).fetchall()
            )
        anchor_ids = tuple(conflict.conflict_id for conflict in conflicts)
        if anchor_ids:
            placeholders = ",".join("?" for _ in anchor_ids)
            resolution_rows.extend(
                self._connection.execute(
                    f"""SELECT * FROM conflict_resolutions
                        WHERE scope_id = ?
                          AND anchor_conflict_id IN ({placeholders})""",
                    (scope_id, *anchor_ids),
                ).fetchall()
            )
        by_mutation: dict[str, ConflictResolution] = {}
        by_anchor: dict[int, ConflictResolution] = {}
        for resolution_row in resolution_rows:
            resolution = _conflict_resolution_from_row(resolution_row)
            if resolution.mutation_id is not None:
                by_mutation[resolution.mutation_id] = resolution
            else:
                by_anchor[resolution.anchor_conflict_id] = resolution
        return tuple(
            ConflictView(
                conflict=conflict,
                operation=(
                    operations.get(conflict.mutation_id)
                    if conflict.mutation_id is not None
                    else None
                ),
                resolution=(
                    by_mutation.get(conflict.mutation_id)
                    if conflict.mutation_id is not None
                    else by_anchor.get(conflict.conflict_id)
                ),
            )
            for conflict in conflicts
        )

    def _fresh_recovery_uuid_locked(self) -> str:
        while True:
            candidate = str(uuid.uuid4())
            collision = self._connection.execute(
                """SELECT 1 FROM pending_operations WHERE mutation_id = ?
                   UNION ALL
                   SELECT 1 FROM conflict_resolutions
                   WHERE resolution_id = ? OR successor_mutation_id = ?
                   LIMIT 1""",
                (candidate, candidate, candidate),
            ).fetchone()
            if collision is None:
                return candidate

    def _require_resolution_successor_receipt_locked(
        self, resolution: sqlite3.Row
    ) -> None:
        successor_mutation_id = resolution["successor_mutation_id"]
        if successor_mutation_id is None:
            raise StateError("The resolution is missing its durable successor ID.")
        proof = self._connection.execute(
            """SELECT operation.state, operation.kind, operation.path,
                      operation.staged_digest, receipt.remote_entry_digest
               FROM pending_operations AS operation
               JOIN operation_receipts AS receipt
                 ON receipt.mutation_id = operation.mutation_id
                AND receipt.scope_id = operation.scope_id
               WHERE operation.scope_id = ? AND operation.mutation_id = ?""",
            (int(resolution["scope_id"]), str(successor_mutation_id)),
        ).fetchone()
        expected = resolution["expected_local_digest"]
        anchor = self._connection.execute(
            "SELECT path FROM conflicts WHERE conflict_id = ? AND scope_id = ?",
            (int(resolution["anchor_conflict_id"]), int(resolution["scope_id"])),
        ).fetchone()
        expected_path = (
            resolution["survivor_path"]
            if str(resolution["decision"]) == "keep_both"
            else (anchor["path"] if anchor is not None else None)
        )
        if expected is None:
            proven = (
                proof is not None
                and str(proof["state"]) == "acked"
                and str(proof["kind"]) == "delete"
                and proof["path"] == expected_path
            )
        else:
            proven = (
                proof is not None
                and str(proof["state"]) == "acked"
                and str(proof["kind"]) == "put"
                and proof["path"] == expected_path
                and proof["staged_digest"] == expected
                and proof["remote_entry_digest"] == expected
            )
        if not proven:
            raise StateError(
                "The resolution successor lacks an exact acknowledged receipt."
            )

    def _require_resolution_materialization_locked(
        self, resolution: sqlite3.Row
    ) -> None:
        conflict = self._connection.execute(
            "SELECT path FROM conflicts WHERE conflict_id = ? AND scope_id = ?",
            (int(resolution["anchor_conflict_id"]), int(resolution["scope_id"])),
        ).fetchone()
        if conflict is None:
            raise StateError("The resolution anchor conflict is missing.")
        path = str(conflict["path"])
        expected = resolution["expected_remote_digest"]
        remote = self._connection.execute(
            "SELECT digest FROM remote_entries WHERE scope_id = ? AND path = ?",
            (int(resolution["scope_id"]), path),
        ).fetchone()
        materialized = self._connection.execute(
            """SELECT state, clean_digest, bytes_on_disk
               FROM materialized_entries WHERE scope_id = ? AND path = ?""",
            (int(resolution["scope_id"]), path),
        ).fetchone()
        pending_apply = self._connection.execute(
            """SELECT 1 FROM remote_apply_intents
               WHERE scope_id = ? AND path = ?""",
            (int(resolution["scope_id"]), path),
        ).fetchone()
        if expected is None:
            proven = (
                remote is None
                and pending_apply is None
                and materialized is not None
                and str(materialized["state"]) == "absent"
                and int(materialized["bytes_on_disk"]) == 0
            )
        else:
            proven = (
                remote is not None
                and pending_apply is None
                and remote["digest"] == expected
                and materialized is not None
                and str(materialized["state"]) in ("clean", "absent")
                and materialized["clean_digest"] == expected
                and (
                    str(materialized["state"]) != "absent"
                    or int(materialized["bytes_on_disk"]) == 0
                )
            )
        if not proven:
            raise StateError(
                "The accepted remote state is not durably materialized."
            )

    # ------------------------------------------------------------------ status

    def unproven_materialized_summary(self) -> tuple[int, int]:
        """Return ``(rows, bytes)`` of clean cache held only for want of proof.

        These are entries eviction cannot touch because nothing has yet shown
        their bytes are retrievable. It is the population an operator needs to
        see when the cache sits above its budget and refuses to shrink.
        """

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT COUNT(*) AS rows_held,
                          COALESCE(SUM(bytes_on_disk), 0) AS bytes_held
                   FROM materialized_entries
                   WHERE scope_id = ? AND state = 'clean' AND pinned = 0
                     AND bytes_on_disk > 0 AND remote_verified = 0""",
                (scope_id,),
            ).fetchone()
        assert row is not None
        return int(row["rows_held"]), int(row["bytes_held"])

    def materialized_bytes(self) -> int:
        """Return active-scope on-disk working-set bytes in one PK lookup."""

        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            row = self._connection.execute(
                """SELECT materialized_bytes FROM fabric_scope_usage
                   WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
        return int(row["materialized_bytes"]) if row is not None else 0

    def readiness_snapshot(self) -> FabricReadiness:
        """Read bounded health signals without recovery, cleanup, or writes."""

        with self._lock:
            self._require_open()
            authority = self._connection.execute(
                """SELECT scope_id, adoption_required, adoption_reason
                   FROM authority_scopes WHERE active = 1"""
            ).fetchone()
            if authority is None:
                return FabricReadiness(
                    authority_bound=False,
                    scope_id=None,
                    adoption_required=False,
                    adoption_reason=None,
                    pending_operations=False,
                    commit_unknown=False,
                    unresolved_conflicts=False,
                    quarantined_remote_outcomes_unknown=False,
                )
            scope_id = int(authority["scope_id"])
            row = self._connection.execute(
                """SELECT
                     EXISTS(
                       SELECT 1 FROM pending_operations
                       WHERE scope_id = ?
                         AND state IN ('queued', 'inflight', 'retry') LIMIT 1
                     ) AS has_pending,
                     EXISTS(
                       SELECT 1 FROM pending_operations
                       WHERE scope_id = ? AND commit_unknown = 1 LIMIT 1
                     ) AS has_commit_unknown,
                     EXISTS(
                       SELECT 1 FROM conflicts
                       WHERE scope_id = ? AND resolved_at_ns IS NULL LIMIT 1
                     ) AS has_conflict,
                     EXISTS(
                       SELECT 1 FROM pending_operations
                       WHERE state = 'quarantined' AND commit_unknown = 1 LIMIT 1
                     ) AS has_quarantined_unknown""",
                (scope_id, scope_id, scope_id),
            ).fetchone()
        assert row is not None
        return FabricReadiness(
            authority_bound=True,
            scope_id=scope_id,
            adoption_required=bool(authority["adoption_required"]),
            adoption_reason=(
                str(authority["adoption_reason"])
                if authority["adoption_reason"] is not None
                else None
            ),
            pending_operations=bool(row["has_pending"]),
            commit_unknown=bool(row["has_commit_unknown"]),
            unresolved_conflicts=bool(row["has_conflict"]),
            quarantined_remote_outcomes_unknown=bool(
                row["has_quarantined_unknown"]
            ),
        )

    def status(self) -> FabricStatus:
        with self._lock:
            self._require_open()
            scope_id = self._active_scope_id()
            head = self._connection.execute(
                "SELECT generation, digest FROM remote_manifest_heads WHERE scope_id = ?",
                (scope_id,),
            ).fetchone()
            remote = self._connection.execute(
                """SELECT COUNT(*) AS count, COALESCE(SUM(size_bytes), 0) AS bytes
                   FROM remote_entries WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            local = self._connection.execute(
                """SELECT COUNT(*) AS count, COALESCE(SUM(bytes_on_disk), 0) AS bytes,
                          COALESCE(SUM(state = 'dirty'), 0) AS dirty,
                          COALESCE(SUM(pinned), 0) AS pinned
                   FROM materialized_entries WHERE scope_id = ?""",
                (scope_id,),
            ).fetchone()
            operation_rows = self._connection.execute(
                """SELECT state, COUNT(*) AS count FROM pending_operations
                   WHERE scope_id = ? GROUP BY state""",
                (scope_id,),
            ).fetchall()
            conflicts = self._connection.execute(
                """SELECT COUNT(*) AS count FROM conflicts
                   WHERE scope_id = ? AND resolved_at_ns IS NULL""",
                (scope_id,),
            ).fetchone()
            quarantined_scopes = self._connection.execute(
                "SELECT COUNT(*) AS count FROM authority_scopes WHERE quarantined_at_ns IS NOT NULL"
            ).fetchone()
            quarantined_operations = self._connection.execute(
                "SELECT COUNT(*) AS count FROM pending_operations WHERE state = 'quarantined'"
            ).fetchone()
            quarantined_unknown = self._connection.execute(
                """SELECT COUNT(*) AS count FROM pending_operations
                   WHERE state = 'quarantined' AND commit_unknown = 1"""
            ).fetchone()
        assert remote is not None and local is not None
        return FabricStatus(
            scope_id=scope_id,
            manifest_generation=int(head["generation"]) if head else None,
            manifest_digest=(
                None if head is None or head["digest"] is None else str(head["digest"])
            ),
            remote_entries=int(remote["count"]),
            remote_bytes=int(remote["bytes"]),
            materialized_entries=int(local["count"]),
            materialized_bytes=int(local["bytes"]),
            dirty_entries=int(local["dirty"]),
            pinned_entries=int(local["pinned"]),
            operations={str(row["state"]): int(row["count"]) for row in operation_rows},
            unresolved_conflicts=int(conflicts["count"]) if conflicts else 0,
            quarantined_scopes=int(quarantined_scopes["count"]) if quarantined_scopes else 0,
            quarantined_operations=(
                int(quarantined_operations["count"]) if quarantined_operations else 0
            ),
            quarantined_remote_outcomes_unknown=(
                int(quarantined_unknown["count"]) if quarantined_unknown else 0
            ),
        )

    # --------------------------------------------------------------- internals

    @contextmanager
    def _transaction(self) -> Iterator[None]:
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                yield
            except BaseException:
                self._connection.execute("ROLLBACK")
                raise
            else:
                try:
                    self._connection.execute("COMMIT")
                except BaseException:
                    # SQLite can leave a transaction open after a disk-full or
                    # I/O failure during COMMIT. Restore connection usability;
                    # the caller still receives the original ambiguous error
                    # and must read back durable state before retrying.
                    if self._connection.in_transaction:
                        try:
                            self._connection.execute("ROLLBACK")
                        except sqlite3.Error:
                            pass
                    raise

    @contextmanager
    def _read_transaction(self) -> Iterator[None]:
        """Hold a consistent cross-process WAL snapshot for a compound read."""

        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN")
            try:
                yield
            except BaseException:
                self._connection.execute("ROLLBACK")
                raise
            else:
                self._connection.execute("COMMIT")

    def _require_open(self) -> None:
        if self._closed:
            raise StateError("The Fabric database is closed.")

    @contextmanager
    def scope_read_epoch(self) -> Iterator[None]:
        """Memoize the active scope id for the duration of one read.

        A single metadata resolution (a getattr, a listdir) reads the active
        authority scope through ~7 independent call sites. They all return the
        same answer, because a read never rotates authority. Opening an epoch
        around the resolution collapses those to one query and reuses it for the
        rest of the epoch; the memo is dropped when the outermost epoch exits,
        so the very next operation re-reads from SQLite and observes any
        cross-process rebind. Re-entrant: nested epochs share one memo.
        """

        with self._lock:
            self._scope_epoch_depth += 1
        try:
            yield
        finally:
            with self._lock:
                self._scope_epoch_depth -= 1
                if self._scope_epoch_depth == 0:
                    self._scope_id_memo = None
                    self._scope_memo_changes = -1

    def _active_scope_id(self) -> int:
        # `total_changes` is a plain C-level counter read (no statement, so it
        # never releases the GIL for a query) of rows this connection has
        # written. Folding it into the memo key means any local write -- most
        # importantly an authority rotation that lands inside an epoch --
        # invalidates the memo without a manual call at every mutation site.
        changes = self._connection.total_changes
        if (
            self._scope_epoch_depth > 0
            and self._scope_id_memo is not None
            and changes == self._scope_memo_changes
        ):
            return self._scope_id_memo
        row = self._connection.execute(
            "SELECT scope_id FROM authority_scopes WHERE active = 1"
        ).fetchone()
        if row is None:
            raise StateError("The Fabric database has no bound authority.")
        scope_id = int(row["scope_id"])
        if self._scope_epoch_depth > 0:
            self._scope_id_memo = scope_id
            self._scope_memo_changes = changes
        return scope_id

    def _record_quota_rebuild_locked(self, scope_id: int) -> None:
        """Invalidate incremental quota state inside the caller's transaction."""

        self._connection.execute(
            """INSERT INTO fabric_quota_events(scope_id, event_kind)
               VALUES (?, 'rebuild')""",
            (scope_id,),
        )

    def _require_authority_adopted(self, scope_id: int) -> None:
        row = self._connection.execute(
            """SELECT adoption_required, adoption_reason
               FROM authority_scopes WHERE scope_id = ? AND active = 1""",
            (scope_id,),
        ).fetchone()
        if row is None:
            raise StateError("The Fabric database has no matching active authority.")
        if bool(row["adoption_required"]):
            reason = str(row["adoption_reason"] or "authority_changed")
            raise StateError(
                "The active authority requires explicit local-byte adoption "
                f"before publication ({reason})."
            )

    def _quarantined_unknown_for_resolution(
        self,
        original_scope_id: int,
        mutation_id: str,
        request_digest: str,
        *,
        allow_resolved: bool,
    ) -> tuple[sqlite3.Row, int]:
        """Validate an exact generation-only status capability under lock."""

        row = self._connection.execute(
            self._QUARANTINED_GENERATION_RESOLVER_SQL
            + " AND original.scope_id = ? AND operation.mutation_id = ?",
            (original_scope_id, mutation_id),
        ).fetchone()
        if row is None:
            raise StateError(
                "The quarantined remote outcome is not status-resolvable "
                "under the active authority."
            )
        if str(row["request_digest"] or "") != request_digest:
            raise StateError("The quarantined mutation request digest changed.")
        state = str(row["state"])
        if bool(row["commit_unknown"]):
            if state != "quarantined":
                raise StateError(
                    "An unresolved quarantined outcome has an invalid journal state."
                )
        elif not allow_resolved or state not in ("acked", "quarantined", "conflict"):
            raise StateError("The quarantined remote outcome is no longer unresolved.")
        return row, int(row["resolver_scope_id"])

    @staticmethod
    def _receipt_matches(
        row: sqlite3.Row,
        *,
        scope_id: int,
        remote_generation: int | None,
        remote_manifest_digest: str | None,
        remote_entry_digest: str | None,
        receipt_json: str | None,
    ) -> bool:
        return (
            int(row["scope_id"]) == scope_id
            and (
                int(row["remote_generation"])
                if row["remote_generation"] is not None
                else None
            )
            == remote_generation
            and row["remote_manifest_digest"] == remote_manifest_digest
            and row["remote_entry_digest"] == remote_entry_digest
            and row["receipt_json"] == receipt_json
        )

    def _ack_operation_locked(
        self,
        scope_id: int,
        operation: sqlite3.Row,
        *,
        remote_generation: int | None,
        remote_manifest_digest: str | None,
        remote_entry_digest: str | None,
        receipt_json: str | None,
        now: int,
    ) -> sqlite3.Row:
        """Record an acknowledgement inside the caller's IMMEDIATE transaction."""

        mutation_id = str(operation["mutation_id"])
        existing = self._connection.execute(
            "SELECT * FROM operation_receipts WHERE mutation_id = ?", (mutation_id,)
        ).fetchone()
        if existing is not None:
            if not self._receipt_matches(
                existing,
                scope_id=scope_id,
                remote_generation=remote_generation,
                remote_manifest_digest=remote_manifest_digest,
                remote_entry_digest=remote_entry_digest,
                receipt_json=receipt_json,
            ):
                raise StateError("The operation already has a different durable receipt.")
            if str(operation["state"]) != "acked":
                raise StateError(
                    "The operation receipt exists without an acknowledged journal state."
                )
            # The original IMMEDIATE transaction already updated every direct
            # successor. An exact response-loss replay must be a true no-op;
            # rebasing again would make the replay depend on newly supplied
            # arguments or advance durable timestamps without new authority.
            return existing
        self._connection.execute(
            """INSERT INTO operation_receipts(
                   mutation_id, scope_id, remote_generation,
                   remote_manifest_digest, remote_entry_digest,
                   receipt_json, recorded_at_ns
               ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                mutation_id,
                scope_id,
                remote_generation,
                remote_manifest_digest,
                remote_entry_digest,
                receipt_json,
                now,
            ),
        )
        self._connection.execute(
            """UPDATE pending_operations SET state = 'acked', last_error = NULL,
                   commit_unknown = 0, commit_batch_id = NULL, claimed_at_ns = NULL, failure_count = 0,
                   next_attempt_at_ns = NULL, ready_at_ns = ?, updated_at_ns = ?
               WHERE mutation_id = ?""",
            (now, now, mutation_id),
        )
        if str(operation["state"]) in _NONTERMINAL_OPERATION_STATES:
            self._adjust_direct_dependents(
                scope_id, mutation_id, delta=-1, now_ns=now
            )
        effects: dict[str, str | None]
        if operation["kind"] == "put":
            effects = {str(operation["path"]): remote_entry_digest}
        elif operation["kind"] == "delete":
            effects = {str(operation["path"]): None}
        else:
            effects = {
                str(operation["path"]): None,
                str(operation["destination_path"]): (
                    remote_entry_digest
                    or (
                        str(operation["expected_source_digest"])
                        if operation["expected_source_digest"] is not None
                        else None
                    )
                ),
            }
        successors = self._connection.execute(
            """SELECT successor.*
               FROM operation_dependencies AS dependency
               JOIN pending_operations AS successor
                 ON successor.mutation_id = dependency.mutation_id
               WHERE dependency.scope_id = ?
                 AND dependency.predecessor_mutation_id = ?
                 AND successor.state IN ('queued', 'retry')""",
            (scope_id, mutation_id),
        ).fetchall()
        for successor in successors:
            source_digest = successor["expected_source_digest"]
            destination_digest = successor["expected_destination_digest"]
            if str(successor["path"]) in effects:
                source_digest = effects[str(successor["path"])]
            if (
                successor["destination_path"] is not None
                and str(successor["destination_path"]) in effects
            ):
                destination_digest = effects[str(successor["destination_path"])]
            self._connection.execute(
                """UPDATE pending_operations
                   SET base_generation = COALESCE(?, base_generation),
                       base_digest = COALESCE(?, base_digest),
                       expected_source_digest = ?,
                       expected_destination_digest = ?, updated_at_ns = ?
                   WHERE mutation_id = ?""",
                (
                    remote_generation,
                    remote_manifest_digest,
                    source_digest,
                    destination_digest,
                    now,
                    successor["mutation_id"],
                ),
            )
        row = self._connection.execute(
            "SELECT * FROM operation_receipts WHERE mutation_id = ?", (mutation_id,)
        ).fetchone()
        assert row is not None
        return row

    def _insert_stage(
        self,
        mutation_id: str,
        staged_path: str | None,
        staged_digest: str | None,
        staged_size: int | None,
        now: int,
    ) -> None:
        assert staged_path is not None and staged_digest is not None and staged_size is not None
        self._connection.execute(
            """INSERT INTO operation_stages(
                   mutation_id, staged_path, staged_digest, staged_size,
                   active, recorded_at_ns
               ) VALUES (?, ?, ?, ?, 1, ?)""",
            (mutation_id, staged_path, staged_digest, staged_size, now),
        )

    def _insert_remote_intents(
        self,
        scope_id: int,
        apply_paths: tuple[str, ...],
        renames: tuple[tuple[str, str, str, int], ...],
        now: int,
    ) -> None:
        if not apply_paths and not renames:
            return
        stamp = self._next_remote_intent_stamp(scope_id, now)
        self._connection.executemany(
            """INSERT INTO remote_apply_intents(scope_id, path, created_at_ns)
               VALUES (?, ?, ?)
               ON CONFLICT(scope_id, path) DO NOTHING""",
            ((scope_id, path, stamp) for path in apply_paths),
        )
        self._connection.executemany(
            """INSERT INTO remote_rename_intents(
                   scope_id, source_path, destination_path, digest,
                   size_bytes, created_at_ns
               ) VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(scope_id, source_path, destination_path) DO UPDATE SET
                   digest = excluded.digest,
                   size_bytes = excluded.size_bytes,
                   created_at_ns = excluded.created_at_ns""",
            (
                (scope_id, source, destination, digest, size, stamp)
                for source, destination, digest, size in renames
            ),
        )

    def _next_remote_intent_stamp(self, scope_id: int, proposed: int) -> int:
        """Return a transactionally monotonic restore key for one scope.

        Wall clocks can regress and every row in one SQL batch intentionally
        shares a stamp. The full primary key breaks those ties; the next batch
        is placed strictly after both restore queues, so concurrent/refill
        pagination cannot miss newly committed work behind its cursor.
        """

        latest = proposed - 1
        apply_row = self._connection.execute(
            """SELECT created_at_ns FROM remote_apply_intents
               WHERE scope_id = ?
               ORDER BY created_at_ns DESC, path DESC LIMIT 1""",
            (scope_id,),
        ).fetchone()
        if apply_row is not None:
            latest = max(latest, int(apply_row["created_at_ns"]))
        rename_row = self._connection.execute(
            """SELECT created_at_ns FROM remote_rename_intents
               WHERE scope_id = ?
               ORDER BY created_at_ns DESC, source_path DESC,
                        destination_path DESC LIMIT 1""",
            (scope_id,),
        ).fetchone()
        if rename_row is not None:
            latest = max(latest, int(rename_row["created_at_ns"]))
        if latest >= (1 << 63) - 1:
            raise StateError("The remote intent restore sequence is exhausted.")
        return latest + 1

    def _initialize_schema(self) -> None:
        with self._lock:
            version = int(self._connection.execute("PRAGMA user_version").fetchone()[0])
            if version > _SCHEMA_VERSION:
                raise StateError(
                    f"Fabric database schema {version} is newer than this node supports."
                )
            if version == 1:
                # Version 2 is additive. Keep the migration in one durable
                # transaction so a process can never observe half of the retry
                # scheduler or crash-safe eviction contract.
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    ALTER TABLE pending_operations
                        ADD COLUMN next_attempt_at_ns INTEGER;
                    ALTER TABLE pending_operations
                        ADD COLUMN failure_count INTEGER NOT NULL DEFAULT 0
                        CHECK(failure_count >= 0);
                    CREATE TABLE eviction_intents (
                        scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                        eviction_id TEXT NOT NULL UNIQUE,
                        path TEXT NOT NULL,
                        expected_clean_digest TEXT NOT NULL,
                        expected_stat_fingerprint TEXT NOT NULL,
                        expected_bytes INTEGER NOT NULL CHECK(expected_bytes >= 0),
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, path),
                        FOREIGN KEY(scope_id, path)
                            REFERENCES materialized_entries(scope_id, path)
                            ON DELETE CASCADE
                    ) WITHOUT ROWID;
                    CREATE INDEX eviction_intents_created
                        ON eviction_intents(scope_id, created_at_ns, path);
                    PRAGMA user_version = 2;
                    COMMIT;
                    """
                )
                version = 2
            if version == 2:
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    ALTER TABLE pending_operations
                        ADD COLUMN predecessor_mutation_id TEXT;
                    CREATE INDEX pending_predecessor
                        ON pending_operations(scope_id, predecessor_mutation_id);
                    PRAGMA user_version = 3;
                    COMMIT;
                    """
                )
                version = 3
            if version == 3:
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE remote_apply_intents (
                        scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                        path TEXT NOT NULL,
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, path)
                    ) WITHOUT ROWID;
                    CREATE TABLE remote_rename_intents (
                        scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                        source_path TEXT NOT NULL,
                        destination_path TEXT NOT NULL,
                        digest TEXT NOT NULL,
                        size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, source_path, destination_path)
                    ) WITHOUT ROWID;
                    PRAGMA user_version = 4;
                    COMMIT;
                    """
                )
                version = 4
            if version == 4:
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE INDEX IF NOT EXISTS pending_source_path_order
                        ON pending_operations(
                            scope_id, path, state, created_at_ns DESC, mutation_id DESC
                        );
                    CREATE INDEX IF NOT EXISTS pending_destination_path_order
                        ON pending_operations(
                            scope_id, destination_path, state,
                            created_at_ns DESC, mutation_id DESC
                        ) WHERE destination_path IS NOT NULL;
                    CREATE INDEX IF NOT EXISTS pending_coalesce
                        ON pending_operations(
                            scope_id, kind, path, destination_path,
                            state, attempt_count, created_at_ns DESC
                        );
                    CREATE TABLE IF NOT EXISTS operation_dependencies (
                        scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                        mutation_id TEXT NOT NULL
                            REFERENCES pending_operations(mutation_id) ON DELETE CASCADE,
                        predecessor_mutation_id TEXT NOT NULL
                            REFERENCES pending_operations(mutation_id) ON DELETE CASCADE,
                        PRIMARY KEY(scope_id, mutation_id, predecessor_mutation_id)
                    ) WITHOUT ROWID;
                    CREATE INDEX IF NOT EXISTS operation_dependencies_predecessor
                        ON operation_dependencies(
                            scope_id, predecessor_mutation_id, mutation_id
                        );
                    INSERT INTO operation_dependencies(
                        scope_id, mutation_id, predecessor_mutation_id
                    )
                    SELECT scope_id, mutation_id, predecessor_mutation_id
                    FROM pending_operations
                    WHERE predecessor_mutation_id IS NOT NULL;
                    PRAGMA user_version = 5;
                    COMMIT;
                    """
                )
                version = 5
            if version == 5:
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    ALTER TABLE pending_operations
                        ADD COLUMN blocked_count INTEGER NOT NULL DEFAULT 0
                        CHECK(blocked_count >= 0);
                    ALTER TABLE pending_operations
                        ADD COLUMN ready_at_ns INTEGER NOT NULL DEFAULT 0
                        CHECK(ready_at_ns >= 0);
                    UPDATE pending_operations
                    SET claimed_at_ns = COALESCE(claimed_at_ns, updated_at_ns)
                    WHERE state = 'inflight' AND claimed_at_ns IS NULL;
                    UPDATE pending_operations
                    SET ready_at_ns = CASE
                        WHEN state = 'queued' THEN created_at_ns
                        WHEN state = 'retry'
                            THEN COALESCE(next_attempt_at_ns, updated_at_ns)
                        WHEN state = 'inflight'
                            THEN COALESCE(claimed_at_ns, updated_at_ns)
                        ELSE updated_at_ns
                    END;
                    UPDATE pending_operations AS operation
                    SET blocked_count = (
                        SELECT COUNT(*)
                        FROM operation_dependencies AS dependency
                        JOIN pending_operations AS predecessor
                          ON predecessor.mutation_id = dependency.predecessor_mutation_id
                        WHERE dependency.scope_id = operation.scope_id
                          AND dependency.mutation_id = operation.mutation_id
                          AND predecessor.state IN ('queued', 'inflight', 'retry')
                    );
                    CREATE INDEX pending_queued_ready
                        ON pending_operations(
                            scope_id, ready_at_ns, created_at_ns, mutation_id
                        )
                        WHERE state = 'queued' AND blocked_count = 0;
                    CREATE INDEX pending_retry_ready
                        ON pending_operations(
                            scope_id, ready_at_ns, created_at_ns, mutation_id
                        )
                        WHERE state = 'retry' AND blocked_count = 0;
                    CREATE INDEX pending_inflight_lease
                        ON pending_operations(scope_id, claimed_at_ns, mutation_id)
                        WHERE state = 'inflight';
                    PRAGMA user_version = 6;
                    COMMIT;
                    """
                )
                version = 6
            if version == 6:
                # Version 7 adds a durable readback-before-retry fence. The
                # partial indexes keep both recovery and the one-unknown-per-
                # authority invariant independent of journal size.
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    ALTER TABLE pending_operations
                        ADD COLUMN commit_unknown INTEGER NOT NULL DEFAULT 0
                        CHECK(commit_unknown IN (0, 1));
                    ALTER TABLE pending_operations
                        ADD COLUMN request_digest TEXT
                        CHECK(request_digest IS NULL OR (
                            length(request_digest) = 64
                            AND request_digest NOT GLOB '*[^a-f0-9]*'
                        ));
                    CREATE UNIQUE INDEX pending_one_commit_unknown_per_scope
                        ON pending_operations(scope_id)
                        WHERE commit_unknown = 1;
                    CREATE INDEX pending_commit_unknown_ready
                        ON pending_operations(
                            scope_id, ready_at_ns, created_at_ns, mutation_id
                        ) WHERE commit_unknown = 1;
                    PRAGMA user_version = 7;
                    COMMIT;
                    """
                )
                version = 7
            if version == 7:
                # Version 8 makes the hot working-set byte budget a single-row
                # lookup. Triggers keep the counter in the same transaction as
                # every materialization change; startup pays the aggregate scan
                # exactly once during migration, never on each poll.
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE IF NOT EXISTS materialized_entries (
                        scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                        path TEXT NOT NULL,
                        state TEXT NOT NULL CHECK(state IN ('absent','clean','dirty','staging','conflict')),
                        pinned INTEGER NOT NULL DEFAULT 0 CHECK(pinned IN (0, 1)),
                        clean_digest TEXT,
                        stat_fingerprint TEXT,
                        bytes_on_disk INTEGER NOT NULL DEFAULT 0 CHECK(bytes_on_disk >= 0),
                        accessed_at_ns INTEGER NOT NULL,
                        updated_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, path)
                    ) WITHOUT ROWID;
                    CREATE INDEX IF NOT EXISTS materialized_lru
                        ON materialized_entries(scope_id, state, pinned, accessed_at_ns);
                    CREATE TABLE fabric_scope_usage (
                        scope_id INTEGER PRIMARY KEY
                            REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                        materialized_bytes INTEGER NOT NULL DEFAULT 0
                            CHECK(materialized_bytes >= 0)
                    );
                    INSERT INTO fabric_scope_usage(scope_id, materialized_bytes)
                    SELECT scope.scope_id, COALESCE(SUM(entry.bytes_on_disk), 0)
                    FROM authority_scopes AS scope
                    LEFT JOIN materialized_entries AS entry
                      ON entry.scope_id = scope.scope_id
                    GROUP BY scope.scope_id;
                    CREATE TRIGGER materialized_usage_insert
                    AFTER INSERT ON materialized_entries
                    BEGIN
                      INSERT INTO fabric_scope_usage(scope_id, materialized_bytes)
                      VALUES (NEW.scope_id, NEW.bytes_on_disk)
                      ON CONFLICT(scope_id) DO UPDATE SET
                        materialized_bytes = materialized_bytes + NEW.bytes_on_disk;
                    END;
                    CREATE TRIGGER materialized_usage_update
                    AFTER UPDATE OF scope_id, bytes_on_disk ON materialized_entries
                    BEGIN
                      UPDATE fabric_scope_usage
                      SET materialized_bytes = materialized_bytes - OLD.bytes_on_disk
                      WHERE scope_id = OLD.scope_id;
                      INSERT INTO fabric_scope_usage(scope_id, materialized_bytes)
                      VALUES (NEW.scope_id, NEW.bytes_on_disk)
                      ON CONFLICT(scope_id) DO UPDATE SET
                        materialized_bytes = materialized_bytes + NEW.bytes_on_disk;
                    END;
                    CREATE TRIGGER materialized_usage_delete
                    AFTER DELETE ON materialized_entries
                    BEGIN
                      UPDATE fabric_scope_usage
                      SET materialized_bytes = materialized_bytes - OLD.bytes_on_disk
                      WHERE scope_id = OLD.scope_id;
                    END;
                    PRAGMA user_version = 8;
                    COMMIT;
                    """
                )
                version = 8
            if version == 8:
                # Version 9 makes restart restoration a covering keyset walk,
                # rather than a 100k-row materialization plus temp B-tree.
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE IF NOT EXISTS remote_apply_intents (
                        scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                        path TEXT NOT NULL,
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, path)
                    ) WITHOUT ROWID;
                    CREATE TABLE IF NOT EXISTS remote_rename_intents (
                        scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                        source_path TEXT NOT NULL,
                        destination_path TEXT NOT NULL,
                        digest TEXT NOT NULL,
                        size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, source_path, destination_path)
                    ) WITHOUT ROWID;
                    CREATE INDEX IF NOT EXISTS remote_apply_restore
                        ON remote_apply_intents(scope_id, created_at_ns, path);
                    CREATE INDEX IF NOT EXISTS remote_rename_restore
                        ON remote_rename_intents(
                            scope_id, created_at_ns, source_path,
                            destination_path, digest, size_bytes
                        );
                    PRAGMA user_version = 9;
                    COMMIT;
                    """
                )
                version = 9
            if version == 9:
                # Version 10 binds a durable root marker UUID into the authority
                # epoch. Legacy NULL rows remain explicit until an exact
                # head-fenced claim fills them once.
                authority_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(authority_scopes)"
                    ).fetchall()
                }
                if "workspace_id" not in authority_columns:
                    self._connection.executescript(
                        """
                        BEGIN IMMEDIATE;
                        ALTER TABLE authority_scopes ADD COLUMN workspace_id TEXT;
                        PRAGMA user_version = 10;
                        COMMIT;
                        """
                    )
                else:
                    self._connection.executescript(
                        """
                        BEGIN IMMEDIATE;
                        PRAGMA user_version = 10;
                        COMMIT;
                        """
                    )
                version = 10
            if version == 10:
                # Version 11 removes wall-clock time from mutation causality.
                # A per-authority allocator survives journal cleanup, so a
                # later enqueue can never move behind an earlier mutation even
                # when the device clock regresses. The authority adoption bit
                # durably fences visible bytes after an identity/root change.
                authority_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(authority_scopes)"
                    ).fetchall()
                }
                operation_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(pending_operations)"
                    ).fetchall()
                }
                self._connection.execute("BEGIN IMMEDIATE")
                try:
                    if "adoption_required" not in authority_columns:
                        self._connection.execute(
                            """ALTER TABLE authority_scopes
                               ADD COLUMN adoption_required INTEGER NOT NULL DEFAULT 0
                               CHECK(adoption_required IN (0, 1))"""
                        )
                    if "adoption_reason" not in authority_columns:
                        self._connection.execute(
                            "ALTER TABLE authority_scopes ADD COLUMN adoption_reason TEXT"
                        )
                    if "journal_seq" not in operation_columns:
                        self._connection.execute(
                            "ALTER TABLE pending_operations ADD COLUMN journal_seq INTEGER"
                        )
                    # The v10 rowid is the only insertion-order evidence that
                    # is independent of a regressed device clock. Existing
                    # dependency edges remain authoritative; this rank gives
                    # every surviving row a stable total order for later tails.
                    self._connection.execute(
                        """WITH ranked AS MATERIALIZED (
                               SELECT mutation_id,
                                      ROW_NUMBER() OVER (
                                        PARTITION BY scope_id
                                        ORDER BY rowid
                                      ) AS sequence
                               FROM pending_operations
                               WHERE journal_seq IS NULL
                           )
                           UPDATE pending_operations
                           SET journal_seq = (
                             SELECT sequence FROM ranked
                             WHERE ranked.mutation_id = pending_operations.mutation_id
                           )
                           WHERE journal_seq IS NULL"""
                    )
                    self._connection.execute(
                        """CREATE TABLE IF NOT EXISTS fabric_journal_sequences (
                               scope_id INTEGER PRIMARY KEY
                                   REFERENCES authority_scopes(scope_id)
                                   ON DELETE CASCADE,
                               next_seq INTEGER NOT NULL CHECK(next_seq > 0)
                           )"""
                    )
                    self._connection.execute(
                        """INSERT INTO fabric_journal_sequences(scope_id, next_seq)
                           SELECT scope.scope_id,
                                  COALESCE(MAX(operation.journal_seq), 0) + 1
                           FROM authority_scopes AS scope
                           LEFT JOIN pending_operations AS operation
                             ON operation.scope_id = scope.scope_id
                           GROUP BY scope.scope_id
                           ON CONFLICT(scope_id) DO UPDATE SET
                             next_seq = MAX(
                               fabric_journal_sequences.next_seq,
                               excluded.next_seq
                             )"""
                    )
                    for index_name in (
                        "pending_scope_journal_sequence",
                        "pending_source_path_order",
                        "pending_destination_path_order",
                        "pending_coalesce",
                        "pending_queued_ready",
                        "pending_retry_ready",
                        "pending_commit_unknown_ready",
                    ):
                        self._connection.execute(f"DROP INDEX IF EXISTS {index_name}")
                    self._connection.execute(
                        "DROP TRIGGER IF EXISTS pending_journal_sequence_insert"
                    )
                    self._connection.execute(
                        "DROP TRIGGER IF EXISTS pending_journal_sequence_update"
                    )
                    for statement in (
                        """CREATE UNIQUE INDEX pending_scope_journal_sequence
                               ON pending_operations(scope_id, journal_seq)""",
                        """CREATE INDEX pending_source_path_order
                               ON pending_operations(
                                   scope_id, path, state, journal_seq DESC
                               )""",
                        """CREATE INDEX pending_destination_path_order
                               ON pending_operations(
                                   scope_id, destination_path, state,
                                   journal_seq DESC
                               ) WHERE destination_path IS NOT NULL""",
                        """CREATE INDEX pending_coalesce
                               ON pending_operations(
                                   scope_id, kind, path, destination_path,
                                   state, attempt_count, journal_seq DESC
                               )""",
                        """CREATE INDEX pending_queued_ready
                               ON pending_operations(
                                   scope_id, journal_seq, mutation_id
                               )
                               WHERE state = 'queued' AND blocked_count = 0""",
                        """CREATE INDEX pending_retry_ready
                               ON pending_operations(
                                   scope_id, ready_at_ns, journal_seq, mutation_id
                               )
                               WHERE state = 'retry' AND blocked_count = 0""",
                        """CREATE INDEX pending_commit_unknown_ready
                               ON pending_operations(
                                   scope_id, journal_seq, mutation_id
                               )
                               WHERE commit_unknown = 1""",
                        """CREATE TRIGGER pending_journal_sequence_insert
                           BEFORE INSERT ON pending_operations
                           WHEN NEW.journal_seq IS NULL OR NEW.journal_seq < 1
                           BEGIN
                             SELECT RAISE(ABORT, 'pending operation requires journal_seq');
                           END""",
                        """CREATE TRIGGER pending_journal_sequence_update
                           BEFORE UPDATE OF journal_seq ON pending_operations
                           WHEN NEW.journal_seq IS NULL OR NEW.journal_seq < 1
                           BEGIN
                             SELECT RAISE(ABORT, 'pending operation requires journal_seq');
                           END""",
                    ):
                        self._connection.execute(statement)
                    self._connection.execute("PRAGMA user_version = 11")
                    self._connection.execute("COMMIT")
                except BaseException:
                    if self._connection.in_transaction:
                        self._connection.execute("ROLLBACK")
                    raise
                version = 11
            if version == 11:
                # Version 12 makes durable local-copy backlog health a single
                # indexed row instead of a namespace-sized intent scan.
                local_intent_table = self._connection.execute(
                    """SELECT 1 FROM sqlite_master
                       WHERE type = 'table' AND name = 'local_transfer_intents'"""
                ).fetchone()
                if local_intent_table is not None:
                    self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE IF NOT EXISTS fabric_local_transfer_usage (
                        scope_id INTEGER PRIMARY KEY
                            REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                        path_count INTEGER NOT NULL DEFAULT 0
                            CHECK(path_count >= 0),
                        size_bytes INTEGER NOT NULL DEFAULT 0
                            CHECK(size_bytes >= 0)
                    );
                    INSERT INTO fabric_local_transfer_usage(
                        scope_id, path_count, size_bytes
                    )
                    SELECT scope.scope_id,
                           COUNT(intent.transfer_id),
                           COALESCE(SUM(CASE
                             WHEN json_valid(intent.source_fingerprint) THEN COALESCE(
                               json_extract(intent.source_fingerprint, '$.size_bytes'),
                               json_extract(intent.source_fingerprint, '$.size'), 0
                             ) ELSE 0 END), 0)
                    FROM authority_scopes AS scope
                    LEFT JOIN local_transfer_intents AS intent
                      ON intent.scope_id = scope.scope_id
                    GROUP BY scope.scope_id
                    ON CONFLICT(scope_id) DO UPDATE SET
                      path_count = excluded.path_count,
                      size_bytes = excluded.size_bytes;
                    CREATE TRIGGER IF NOT EXISTS local_transfer_usage_insert
                    AFTER INSERT ON local_transfer_intents
                    BEGIN
                      INSERT INTO fabric_local_transfer_usage(
                          scope_id, path_count, size_bytes
                      ) VALUES (
                          NEW.scope_id,
                          1,
                          CASE WHEN json_valid(NEW.source_fingerprint) THEN COALESCE(
                              json_extract(NEW.source_fingerprint, '$.size_bytes'),
                              json_extract(NEW.source_fingerprint, '$.size'), 0
                          ) ELSE 0 END
                      )
                      ON CONFLICT(scope_id) DO UPDATE SET
                        path_count = path_count + 1,
                        size_bytes = size_bytes + excluded.size_bytes;
                    END;
                    CREATE TRIGGER IF NOT EXISTS local_transfer_usage_update
                    AFTER UPDATE OF scope_id, source_fingerprint
                    ON local_transfer_intents
                    BEGIN
                      UPDATE fabric_local_transfer_usage
                      SET path_count = path_count - 1,
                          size_bytes = size_bytes - CASE
                            WHEN json_valid(OLD.source_fingerprint) THEN COALESCE(
                              json_extract(OLD.source_fingerprint, '$.size_bytes'),
                              json_extract(OLD.source_fingerprint, '$.size'), 0
                            ) ELSE 0 END
                      WHERE scope_id = OLD.scope_id;
                      INSERT INTO fabric_local_transfer_usage(
                          scope_id, path_count, size_bytes
                      ) VALUES (
                          NEW.scope_id,
                          1,
                          CASE WHEN json_valid(NEW.source_fingerprint) THEN COALESCE(
                              json_extract(NEW.source_fingerprint, '$.size_bytes'),
                              json_extract(NEW.source_fingerprint, '$.size'), 0
                          ) ELSE 0 END
                      )
                      ON CONFLICT(scope_id) DO UPDATE SET
                        path_count = path_count + 1,
                        size_bytes = size_bytes + excluded.size_bytes;
                    END;
                    CREATE TRIGGER IF NOT EXISTS local_transfer_usage_delete
                    AFTER DELETE ON local_transfer_intents
                    BEGIN
                      UPDATE fabric_local_transfer_usage
                      SET path_count = path_count - 1,
                          size_bytes = size_bytes - CASE
                            WHEN json_valid(OLD.source_fingerprint) THEN COALESCE(
                              json_extract(OLD.source_fingerprint, '$.size_bytes'),
                              json_extract(OLD.source_fingerprint, '$.size'), 0
                            ) ELSE 0 END
                      WHERE scope_id = OLD.scope_id;
                    END;
                    PRAGMA user_version = 12;
                    COMMIT;
                    """
                    )
                    version = 12
            if version == 12:
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE INDEX IF NOT EXISTS conflict_scope_page
                        ON conflicts(scope_id, conflict_id);
                    CREATE INDEX IF NOT EXISTS conflict_scope_path
                        ON conflicts(scope_id, path, conflict_id);
                    CREATE INDEX IF NOT EXISTS conflict_standalone_cleanup
                        ON conflicts(conflict_id)
                        WHERE mutation_id IS NULL
                          AND resolved_at_ns IS NOT NULL
                          AND staged_path IS NOT NULL;
                    CREATE TABLE IF NOT EXISTS conflict_resolutions (
                        resolution_id TEXT PRIMARY KEY,
                        scope_id INTEGER NOT NULL
                            REFERENCES authority_scopes(scope_id),
                        anchor_conflict_id INTEGER NOT NULL UNIQUE
                            REFERENCES conflicts(conflict_id),
                        mutation_id TEXT,
                        decision TEXT NOT NULL
                            CHECK(decision IN ('keep_local','keep_remote','keep_both')),
                        phase TEXT NOT NULL CHECK(phase IN (
                            'requested','prepared','waiting_successor',
                            'applying_remote','blocked','completed'
                        )),
                        expected_local_digest TEXT,
                        expected_remote_digest TEXT,
                        expected_remote_generation INTEGER,
                        successor_mutation_id TEXT UNIQUE,
                        survivor_path TEXT,
                        staged_path TEXT,
                        staged_digest TEXT,
                        staged_size INTEGER CHECK(staged_size >= 0),
                        last_error TEXT,
                        created_at_ns INTEGER NOT NULL,
                        updated_at_ns INTEGER NOT NULL,
                        completed_at_ns INTEGER,
                        CHECK(
                          (staged_path IS NULL AND staged_digest IS NULL
                           AND staged_size IS NULL)
                          OR
                          (staged_path IS NOT NULL AND staged_digest IS NOT NULL
                           AND staged_size IS NOT NULL)
                        ),
                        CHECK(
                          (phase = 'completed' AND completed_at_ns IS NOT NULL)
                          OR
                          (phase != 'completed' AND completed_at_ns IS NULL)
                        )
                    );
                    CREATE UNIQUE INDEX IF NOT EXISTS conflict_resolution_mutation
                        ON conflict_resolutions(scope_id, mutation_id)
                        WHERE mutation_id IS NOT NULL;
                    CREATE INDEX IF NOT EXISTS conflict_resolution_work
                        ON conflict_resolutions(
                            scope_id, phase, updated_at_ns, resolution_id
                        );
                    CREATE INDEX IF NOT EXISTS conflict_resolution_stage
                        ON conflict_resolutions(staged_path)
                        WHERE staged_path IS NOT NULL AND phase != 'completed';
                    PRAGMA user_version = 13;
                    COMMIT;
                    """
                )
                version = 13
            if version == 13:
                # Development/test snapshots may have received one additive
                # column before their user_version advanced. Migrate each
                # column by catalog identity so reopening such a v13 journal is
                # idempotent and never mistakes partial source state for
                # corruption.
                self._connection.execute("BEGIN IMMEDIATE")
                try:
                    additions = {
                        "conflicts": (
                            ("local_fingerprint", "local_fingerprint TEXT"),
                        ),
                        "conflict_resolutions": (
                            (
                                "expected_local_fingerprint",
                                "expected_local_fingerprint TEXT",
                            ),
                            (
                                "retry_safe",
                                "retry_safe INTEGER NOT NULL DEFAULT 0 "
                                "CHECK(retry_safe IN (0, 1))",
                            ),
                            ("retry_requested_at_ns", "retry_requested_at_ns INTEGER"),
                        ),
                        "local_transfer_intents": (
                            (
                                "issue_code",
                                "issue_code TEXT CHECK(issue_code IS NULL OR "
                                "issue_code = 'local_file_present_but_unsupported')",
                            ),
                            (
                                "issue_size_bytes",
                                "issue_size_bytes INTEGER CHECK(issue_size_bytes >= 0)",
                            ),
                        ),
                    }
                    for table, columns in additions.items():
                        present = {
                            str(row["name"])
                            for row in self._connection.execute(
                                f"PRAGMA table_info({table})"
                            ).fetchall()
                        }
                        for name, definition in columns:
                            if name not in present:
                                self._connection.execute(
                                    f"ALTER TABLE {table} ADD COLUMN {definition}"
                                )
                    self._connection.execute(
                        """CREATE INDEX IF NOT EXISTS local_transfer_issue_page
                           ON local_transfer_intents(
                               scope_id, created_at_ns, transfer_id
                           ) WHERE issue_code IS NOT NULL"""
                    )
                    self._connection.execute("PRAGMA user_version = 14")
                    self._connection.execute("COMMIT")
                except BaseException:
                    if self._connection.in_transaction:
                        self._connection.execute("ROLLBACK")
                    raise
                version = 14
            if version == 14:
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE INDEX IF NOT EXISTS local_transfer_runnable_page
                        ON local_transfer_intents(
                            scope_id, created_at_ns, transfer_id
                        ) WHERE issue_code IS NULL;
                    PRAGMA user_version = 15;
                    COMMIT;
                    """
                )
                version = 15
            if version == 15:
                columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(pending_operations)"
                    ).fetchall()
                }
                self._connection.execute("BEGIN IMMEDIATE")
                try:
                    if "directory_rename" not in columns:
                        self._connection.execute(
                            """ALTER TABLE pending_operations
                               ADD COLUMN directory_rename INTEGER NOT NULL DEFAULT 0
                               CHECK(directory_rename IN (0, 1))"""
                        )
                    if "directory_rename_observed" not in columns:
                        self._connection.execute(
                            """ALTER TABLE pending_operations
                               ADD COLUMN directory_rename_observed INTEGER NOT NULL DEFAULT 0
                               CHECK(directory_rename_observed IN (0, 1))"""
                        )
                    self._connection.execute(
                        """CREATE INDEX IF NOT EXISTS pending_directory_rename_overlay
                           ON pending_operations(
                               scope_id, directory_rename_observed,
                               state, journal_seq
                           ) WHERE directory_rename = 1"""
                    )
                    self._connection.execute("PRAGMA user_version = 16")
                    self._connection.execute("COMMIT")
                except BaseException:
                    if self._connection.in_transaction:
                        self._connection.execute("ROLLBACK")
                    raise
                version = 16
            if version == 16:
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE IF NOT EXISTS local_directory_tombstones (
                        scope_id INTEGER NOT NULL
                            REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                        path TEXT NOT NULL,
                        head_generation INTEGER CHECK(head_generation > 0),
                        head_digest TEXT,
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, path),
                        CHECK(
                            (head_generation IS NULL AND head_digest IS NULL)
                            OR
                            (head_generation IS NOT NULL AND head_digest IS NOT NULL)
                        )
                    ) WITHOUT ROWID;
                    PRAGMA user_version = 17;
                    COMMIT;
                    """
                )
                version = 17
            if version == 17:
                columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(conflicts)"
                    ).fetchall()
                }
                self._connection.execute("BEGIN IMMEDIATE")
                try:
                    if "evidence_key" not in columns:
                        self._connection.execute(
                            "ALTER TABLE conflicts ADD COLUMN evidence_key TEXT"
                        )
                    self._connection.execute(
                        """CREATE UNIQUE INDEX IF NOT EXISTS conflict_evidence_key
                           ON conflicts(scope_id, evidence_key)
                           WHERE evidence_key IS NOT NULL"""
                    )
                    self._connection.execute("PRAGMA user_version = 18")
                    self._connection.execute("COMMIT")
                except BaseException:
                    if self._connection.in_transaction:
                        self._connection.execute("ROLLBACK")
                    raise
                version = 18
            if version == 18:
                # Version 19 adds a bounded durable cursor for incrementally
                # maintaining quota admission across processes. The journal
                # and transfer tables remain the sole mutation authority.
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE IF NOT EXISTS fabric_quota_events (
                        event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        scope_id INTEGER NOT NULL
                            REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                        event_kind TEXT NOT NULL CHECK(event_kind IN (
                            'operation_insert','intent_insert','rebuild'
                        )),
                        mutation_id TEXT,
                        operation_kind TEXT,
                        path TEXT,
                        destination_path TEXT,
                        staged_size INTEGER,
                        source_fingerprint TEXT,
                        directory_rename INTEGER NOT NULL DEFAULT 0
                            CHECK(directory_rename IN (0, 1))
                    );
                    CREATE INDEX IF NOT EXISTS fabric_quota_events_scope
                        ON fabric_quota_events(scope_id, event_id);
                    CREATE TRIGGER IF NOT EXISTS fabric_quota_events_bound
                    AFTER INSERT ON fabric_quota_events
                    BEGIN
                      DELETE FROM fabric_quota_events
                      WHERE event_id <= NEW.event_id - 10000;
                    END;
                    CREATE TRIGGER IF NOT EXISTS fabric_quota_operation_insert
                    AFTER INSERT ON pending_operations
                    WHEN NEW.state IN ('queued','inflight','retry')
                    BEGIN
                      INSERT INTO fabric_quota_events(
                          scope_id, event_kind, mutation_id, operation_kind,
                          path, destination_path, staged_size, directory_rename
                      ) VALUES (
                          NEW.scope_id, 'operation_insert', NEW.mutation_id,
                          NEW.kind, NEW.path, NEW.destination_path,
                          NEW.staged_size, NEW.directory_rename
                      );
                    END;
                    CREATE TRIGGER IF NOT EXISTS fabric_quota_operation_update
                    AFTER UPDATE ON pending_operations
                    WHEN
                      (OLD.state IN ('queued','inflight','retry')) !=
                        (NEW.state IN ('queued','inflight','retry'))
                      OR OLD.kind IS NOT NEW.kind
                      OR OLD.path IS NOT NEW.path
                      OR OLD.destination_path IS NOT NEW.destination_path
                      OR OLD.staged_size IS NOT NEW.staged_size
                      OR OLD.directory_rename IS NOT NEW.directory_rename
                    BEGIN
                      INSERT INTO fabric_quota_events(
                          scope_id, event_kind, mutation_id
                      ) VALUES (NEW.scope_id, 'rebuild', NEW.mutation_id);
                    END;
                    CREATE TRIGGER IF NOT EXISTS fabric_quota_operation_delete
                    AFTER DELETE ON pending_operations
                    WHEN OLD.state IN ('queued','inflight','retry')
                    BEGIN
                      INSERT INTO fabric_quota_events(
                          scope_id, event_kind, mutation_id
                      ) VALUES (OLD.scope_id, 'rebuild', OLD.mutation_id);
                    END;
                    CREATE TRIGGER IF NOT EXISTS fabric_quota_intent_insert
                    AFTER INSERT ON local_transfer_intents
                    BEGIN
                      INSERT INTO fabric_quota_events(
                          scope_id, event_kind, mutation_id, path,
                          source_fingerprint
                      ) VALUES (
                          NEW.scope_id, 'intent_insert', NEW.transfer_id,
                          NEW.path, NEW.source_fingerprint
                      );
                    END;
                    CREATE TRIGGER IF NOT EXISTS fabric_quota_intent_update
                    AFTER UPDATE ON local_transfer_intents
                    BEGIN
                      INSERT INTO fabric_quota_events(
                          scope_id, event_kind, mutation_id
                      ) VALUES (NEW.scope_id, 'rebuild', NEW.transfer_id);
                    END;
                    CREATE TRIGGER IF NOT EXISTS fabric_quota_intent_delete
                    AFTER DELETE ON local_transfer_intents
                    BEGIN
                      INSERT INTO fabric_quota_events(
                          scope_id, event_kind, mutation_id
                      ) VALUES (OLD.scope_id, 'rebuild', OLD.transfer_id);
                    END;
                    PRAGMA user_version = 19;
                    COMMIT;
                    """
                )
                version = 19
            if version == 19:
                # v20: batched commits. Several operations may await status
                # readback at once when one mutate_batch request was in flight;
                # they share a batch id, while a lone unknown commit keeps the
                # one-per-scope fence.
                self._ensure_commit_batch_fence()
                self._connection.execute("PRAGMA user_version = 20")
                version = 20
            if version == 20:
                # v21: Fabric v2 head identity is the journal sequence. The
                # manifest digest column becomes nullable because v2 commits
                # have no content hash to put in it. SQLite cannot drop a NOT
                # NULL in place, so the table is rebuilt.
                self._connection.executescript(
                    """
                    BEGIN;
                    CREATE TABLE remote_manifest_heads_v21 (
                        scope_id INTEGER PRIMARY KEY
                            REFERENCES authority_scopes(scope_id),
                        generation INTEGER NOT NULL CHECK(generation > 0),
                        digest TEXT,
                        refreshed_at_ns INTEGER NOT NULL
                    );
                    INSERT INTO remote_manifest_heads_v21
                        (scope_id, generation, digest, refreshed_at_ns)
                    SELECT scope_id, generation, digest, refreshed_at_ns
                    FROM remote_manifest_heads;
                    DROP TABLE remote_manifest_heads;
                    ALTER TABLE remote_manifest_heads_v21
                        RENAME TO remote_manifest_heads;
                    PRAGMA user_version = 21;
                    COMMIT;
                    """
                )
                version = 21
            if version == 21:
                # v22: bootstrap a Fabric v2 workspace from the snapshot lane.
                #
                # Two constraints written for v1 are wrong for a sequence.
                # `generation > 0` cannot express seq 0, which is the real and
                # settled state of a workspace nothing has been written to; and
                # a load's `digest` is NOT NULL when a v2 snapshot has no
                # content hash to carry. SQLite can change neither in place, so
                # both tables are rebuilt.
                #
                # In-flight loads are deliberately NOT carried across. The
                # staging tables cascade off remote_manifest_loads, so dropping
                # it deletes their rows; copying the parent rows would leave a
                # load whose `ingested_entries` counts pages that no longer
                # exist, and committing that would publish a truncated
                # namespace as if it were the whole workspace. A discarded load
                # costs one re-fetch and touches no published state, which is
                # the entire reason loads are isolated in the first place.
                self._connection.executescript(
                    """
                    BEGIN;
                    CREATE TABLE remote_manifest_heads_v22 (
                        scope_id INTEGER PRIMARY KEY
                            REFERENCES authority_scopes(scope_id),
                        generation INTEGER NOT NULL CHECK(generation >= 0),
                        digest TEXT,
                        refreshed_at_ns INTEGER NOT NULL
                    );
                    INSERT INTO remote_manifest_heads_v22
                        (scope_id, generation, digest, refreshed_at_ns)
                    SELECT scope_id, generation, digest, refreshed_at_ns
                    FROM remote_manifest_heads;
                    DROP TABLE remote_manifest_heads;
                    ALTER TABLE remote_manifest_heads_v22
                        RENAME TO remote_manifest_heads;

                    DELETE FROM remote_manifest_rename_staging;
                    DELETE FROM remote_manifest_staging;
                    CREATE TABLE remote_manifest_loads_v22 (
                        scope_id INTEGER NOT NULL
                            REFERENCES authority_scopes(scope_id),
                        load_id TEXT NOT NULL UNIQUE,
                        manifest_id TEXT NOT NULL,
                        generation INTEGER NOT NULL CHECK(generation >= 0),
                        digest TEXT,
                        expected_entries INTEGER NOT NULL
                            CHECK(expected_entries >= 0 AND expected_entries <= 250000),
                        ingested_entries INTEGER NOT NULL DEFAULT 0
                            CHECK(ingested_entries >= 0 AND ingested_entries <= expected_entries),
                        last_path TEXT,
                        created_at_ns INTEGER NOT NULL,
                        updated_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, load_id)
                    ) WITHOUT ROWID;
                    DROP TABLE remote_manifest_loads;
                    ALTER TABLE remote_manifest_loads_v22
                        RENAME TO remote_manifest_loads;
                    CREATE INDEX remote_manifest_loads_stale
                        ON remote_manifest_loads(updated_at_ns, load_id);
                    CREATE UNIQUE INDEX remote_manifest_one_load_per_scope
                        ON remote_manifest_loads(scope_id);
                    PRAGMA user_version = 22;
                    COMMIT;
                    """
                )
                version = 22
            if version == 22:
                # Version 23 adds the eviction re-fetchability proof. Existing
                # rows default to 0 (unproven) on purpose: this node has no
                # first-hand evidence about content it materialized before the
                # column existed, and an unproven row is one it must not
                # delete. They become evictable the first time the node either
                # re-fetches them or re-uploads them with provider
                # confirmation.
                materialized_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(materialized_entries)"
                    ).fetchall()
                }
                self._connection.execute("BEGIN IMMEDIATE")
                try:
                    if "remote_verified" not in materialized_columns:
                        self._connection.execute(
                            """ALTER TABLE materialized_entries
                               ADD COLUMN remote_verified INTEGER NOT NULL
                               DEFAULT 0 CHECK(remote_verified IN (0, 1))"""
                        )
                    self._connection.execute("PRAGMA user_version = 23")
                except BaseException:
                    self._connection.execute("ROLLBACK")
                    raise
                self._connection.execute("COMMIT")
                version = 23
            if version == 23:
                # Preserve pending deletions while allowing v2 sequence-only fences.
                self._connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE local_directory_tombstones_v24 (
                        scope_id INTEGER NOT NULL
                            REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                        path TEXT NOT NULL,
                        head_generation INTEGER CHECK(head_generation >= 0),
                        head_digest TEXT,
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(scope_id, path),
                        CHECK(head_generation IS NOT NULL OR head_digest IS NULL)
                    ) WITHOUT ROWID;
                    INSERT INTO local_directory_tombstones_v24
                    SELECT * FROM local_directory_tombstones;
                    DROP TABLE local_directory_tombstones;
                    ALTER TABLE local_directory_tombstones_v24
                        RENAME TO local_directory_tombstones;
                    PRAGMA user_version = 24;
                    COMMIT;
                    """
                )
                version = 24
            # The eviction proof column is additive and load-bearing for
            # data safety, so add it on every path rather than only on the
            # exact 22 -> 23 step: a database can reach this point from a
            # development snapshot, a fresh create, or a partially-applied
            # ladder, and a missing column here would fail every
            # materialization write.
            materialized_table = self._connection.execute(
                """SELECT 1 FROM sqlite_master
                   WHERE type = 'table' AND name = 'materialized_entries'"""
            ).fetchone()
            if materialized_table is not None:
                materialized_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(materialized_entries)"
                    ).fetchall()
                }
                if "remote_verified" not in materialized_columns:
                    self._connection.executescript(
                        """
                        BEGIN IMMEDIATE;
                        ALTER TABLE materialized_entries
                            ADD COLUMN remote_verified INTEGER NOT NULL
                            DEFAULT 0 CHECK(remote_verified IN (0, 1));
                        COMMIT;
                        """
                    )
            # Development snapshots may already identify as v7 while lacking
            # the request-bound proof added before the schema was released.
            # Keep the migration additive and preserve every journal row.
            operation_table = self._connection.execute(
                """SELECT 1 FROM sqlite_master
                   WHERE type = 'table' AND name = 'pending_operations'"""
            ).fetchone()
            if operation_table is not None:
                operation_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(pending_operations)"
                    ).fetchall()
                }
                if "request_digest" not in operation_columns:
                    self._connection.executescript(
                        """
                        BEGIN IMMEDIATE;
                        ALTER TABLE pending_operations
                            ADD COLUMN request_digest TEXT
                            CHECK(request_digest IS NULL OR (
                                length(request_digest) = 64
                                AND request_digest NOT GLOB '*[^a-f0-9]*'
                            ));
                        COMMIT;
                        """
                    )
                operation_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(pending_operations)"
                    ).fetchall()
                }
                if (
                    "directory_rename" not in operation_columns
                    or "directory_rename_observed" not in operation_columns
                ):
                    self._connection.execute("BEGIN IMMEDIATE")
                    try:
                        if "directory_rename" not in operation_columns:
                            self._connection.execute(
                                """ALTER TABLE pending_operations
                                   ADD COLUMN directory_rename INTEGER NOT NULL DEFAULT 0
                                   CHECK(directory_rename IN (0, 1))"""
                            )
                        if "directory_rename_observed" not in operation_columns:
                            self._connection.execute(
                                """ALTER TABLE pending_operations
                                   ADD COLUMN directory_rename_observed INTEGER NOT NULL DEFAULT 0
                                   CHECK(directory_rename_observed IN (0, 1))"""
                            )
                        self._connection.execute(
                            """CREATE INDEX IF NOT EXISTS pending_directory_rename_overlay
                               ON pending_operations(
                                   scope_id, directory_rename_observed,
                                   state, journal_seq
                               ) WHERE directory_rename = 1"""
                        )
                        self._connection.execute("COMMIT")
                    except BaseException:
                        if self._connection.in_transaction:
                            self._connection.execute("ROLLBACK")
                        raise
                # Snapshots that stamped v20 before the batch fence landed
                # (or hand-built test databases) receive the exact v20 shape.
                self._ensure_commit_batch_fence()
            # Older v6 nodes could crash mid-keyset load without retaining the
            # server's immutable manifest UUID. Such a cursor cannot be resumed
            # safely: discard only its isolated staging rows, preserve the
            # published head, and add the identity column before normal schema
            # creation. Hand-built v1/v5 test databases do not have this table
            # yet and receive the exact v7 definition below.
            load_table = self._connection.execute(
                """SELECT 1 FROM sqlite_master
                   WHERE type = 'table' AND name = 'remote_manifest_loads'"""
            ).fetchone()
            if load_table is not None:
                load_columns = {
                    str(row["name"])
                    for row in self._connection.execute(
                        "PRAGMA table_info(remote_manifest_loads)"
                    ).fetchall()
                }
                if "manifest_id" not in load_columns:
                    self._connection.executescript(
                        """
                        BEGIN IMMEDIATE;
                        DELETE FROM remote_manifest_loads;
                        ALTER TABLE remote_manifest_loads
                            ADD COLUMN manifest_id TEXT NOT NULL
                            DEFAULT '00000000-0000-4000-8000-000000000000';
                        COMMIT;
                        """
                    )
            self._connection.executescript(
                """
                BEGIN IMMEDIATE;
                CREATE TABLE IF NOT EXISTS authority_scopes (
                    scope_id INTEGER PRIMARY KEY,
                    host_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    host_generation INTEGER NOT NULL CHECK(host_generation > 0),
                    attachment_id TEXT,
                    workspace_root TEXT NOT NULL,
                    workspace_id TEXT,
                    adoption_required INTEGER NOT NULL DEFAULT 0
                        CHECK(adoption_required IN (0, 1)),
                    adoption_reason TEXT,
                    active INTEGER NOT NULL CHECK(active IN (0, 1)),
                    bound_at_ns INTEGER NOT NULL,
                    updated_at_ns INTEGER NOT NULL,
                    quarantined_at_ns INTEGER,
                    quarantine_reason TEXT
                );
                CREATE UNIQUE INDEX IF NOT EXISTS authority_one_active
                    ON authority_scopes(active) WHERE active = 1;
                CREATE INDEX IF NOT EXISTS authority_inactive_compaction
                    ON authority_scopes(scope_id) WHERE active = 0;
                CREATE TABLE IF NOT EXISTS fabric_journal_sequences (
                    scope_id INTEGER PRIMARY KEY
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    next_seq INTEGER NOT NULL CHECK(next_seq > 0)
                );

                CREATE TABLE IF NOT EXISTS remote_manifest_heads (
                    scope_id INTEGER PRIMARY KEY REFERENCES authority_scopes(scope_id),
                    -- >= 0: a Fabric v2 head is a journal sequence, and 0 is
                    -- the settled state of a workspace with no writes yet.
                    generation INTEGER NOT NULL CHECK(generation >= 0),
                    -- NULL for a Fabric v2 head: the journal sequence in
                    -- `generation` is the identity, and v2 has no per-commit
                    -- content digest to record here.
                    digest TEXT,
                    refreshed_at_ns INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS local_directory_tombstones (
                    scope_id INTEGER NOT NULL
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    path TEXT NOT NULL,
                    head_generation INTEGER CHECK(head_generation >= 0),
                    head_digest TEXT,
                    created_at_ns INTEGER NOT NULL,
                    PRIMARY KEY(scope_id, path),
                    CHECK(head_generation IS NOT NULL OR head_digest IS NULL)
                ) WITHOUT ROWID;
                CREATE TABLE IF NOT EXISTS remote_directories (
                    scope_id INTEGER NOT NULL
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    path TEXT NOT NULL,
                    PRIMARY KEY(scope_id, path)
                ) WITHOUT ROWID;
                CREATE TABLE IF NOT EXISTS local_directory_puts (
                    scope_id INTEGER NOT NULL
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    path TEXT NOT NULL,
                    mutation_id TEXT NOT NULL,
                    created_at_ns INTEGER NOT NULL,
                    kind TEXT NOT NULL CHECK(kind IN ('put', 'rename', 'delete')),
                    destination_path TEXT,
                    PRIMARY KEY(scope_id, mutation_id),
                    CHECK((kind IN ('put', 'delete') AND destination_path IS NULL) OR
                          (kind = 'rename' AND destination_path IS NOT NULL))
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS local_directory_puts_path
                    ON local_directory_puts(scope_id, path, kind, created_at_ns);
                CREATE TABLE IF NOT EXISTS remote_entries (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    path TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
                    digest TEXT NOT NULL,
                    modified TEXT,
                    blocks_json TEXT,
                    PRIMARY KEY(scope_id, path)
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS remote_entries_digest
                    ON remote_entries(scope_id, digest, path, size_bytes);

                CREATE TABLE IF NOT EXISTS remote_manifest_loads (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    load_id TEXT NOT NULL UNIQUE,
                    manifest_id TEXT NOT NULL,
                    generation INTEGER NOT NULL CHECK(generation >= 0),
                    -- NULL for a Fabric v2 snapshot load: there is no manifest
                    -- and so no content digest to fence the load's identity on.
                    digest TEXT,
                    expected_entries INTEGER NOT NULL
                        CHECK(expected_entries >= 0 AND expected_entries <= 250000),
                    ingested_entries INTEGER NOT NULL DEFAULT 0
                        CHECK(ingested_entries >= 0 AND ingested_entries <= expected_entries),
                    last_path TEXT,
                    created_at_ns INTEGER NOT NULL,
                    updated_at_ns INTEGER NOT NULL,
                    PRIMARY KEY(scope_id, load_id)
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS remote_manifest_loads_stale
                    ON remote_manifest_loads(updated_at_ns, load_id);
                CREATE UNIQUE INDEX IF NOT EXISTS remote_manifest_one_load_per_scope
                    ON remote_manifest_loads(scope_id);
                CREATE TABLE IF NOT EXISTS remote_directory_staging (
                    scope_id INTEGER NOT NULL,
                    load_id TEXT NOT NULL,
                    path TEXT NOT NULL,
                    PRIMARY KEY(scope_id, load_id, path),
                    FOREIGN KEY(scope_id, load_id)
                        REFERENCES remote_manifest_loads(scope_id, load_id)
                        ON DELETE CASCADE
                ) WITHOUT ROWID;
                CREATE TABLE IF NOT EXISTS remote_manifest_staging (
                    scope_id INTEGER NOT NULL,
                    load_id TEXT NOT NULL,
                    path TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
                    digest TEXT NOT NULL,
                    modified TEXT,
                    blocks_json TEXT,
                    PRIMARY KEY(scope_id, load_id, path),
                    FOREIGN KEY(scope_id, load_id)
                        REFERENCES remote_manifest_loads(scope_id, load_id)
                        ON DELETE CASCADE
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS remote_manifest_staging_digest
                    ON remote_manifest_staging(
                        scope_id, load_id, digest, path, size_bytes
                    );
                CREATE TABLE IF NOT EXISTS remote_manifest_rename_staging (
                    scope_id INTEGER NOT NULL,
                    load_id TEXT NOT NULL,
                    source_path TEXT NOT NULL,
                    destination_path TEXT NOT NULL,
                    digest TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
                    PRIMARY KEY(scope_id, load_id, source_path),
                    UNIQUE(scope_id, load_id, destination_path),
                    FOREIGN KEY(scope_id, load_id)
                        REFERENCES remote_manifest_loads(scope_id, load_id)
                        ON DELETE CASCADE
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS remote_manifest_rename_destination
                    ON remote_manifest_rename_staging(
                        scope_id, load_id, destination_path
                    );

                CREATE TABLE IF NOT EXISTS materialized_entries (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    path TEXT NOT NULL,
                    state TEXT NOT NULL CHECK(state IN ('absent','clean','dirty','staging','conflict')),
                    pinned INTEGER NOT NULL DEFAULT 0 CHECK(pinned IN (0, 1)),
                    clean_digest TEXT,
                    stat_fingerprint TEXT,
                    bytes_on_disk INTEGER NOT NULL DEFAULT 0 CHECK(bytes_on_disk >= 0),
                    accessed_at_ns INTEGER NOT NULL,
                    updated_at_ns INTEGER NOT NULL,
                    -- First-hand proof that these exact bytes are retrievable
                    -- from object storage: either this node fetched them from
                    -- there, or it uploaded them and the provider confirmed
                    -- every block by HEAD before the commit. Eviction requires
                    -- it. Defaults to 0, so a row this node cannot vouch for
                    -- is never reclaimed -- absence of proof is not proof.
                    remote_verified INTEGER NOT NULL DEFAULT 0
                        CHECK(remote_verified IN (0, 1)),
                    PRIMARY KEY(scope_id, path)
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS materialized_lru
                    ON materialized_entries(scope_id, state, pinned, accessed_at_ns);
                CREATE TABLE IF NOT EXISTS fabric_scope_usage (
                    scope_id INTEGER PRIMARY KEY
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    materialized_bytes INTEGER NOT NULL DEFAULT 0
                        CHECK(materialized_bytes >= 0)
                );
                CREATE TRIGGER IF NOT EXISTS materialized_usage_insert
                AFTER INSERT ON materialized_entries
                BEGIN
                  INSERT INTO fabric_scope_usage(scope_id, materialized_bytes)
                  VALUES (NEW.scope_id, NEW.bytes_on_disk)
                  ON CONFLICT(scope_id) DO UPDATE SET
                    materialized_bytes = materialized_bytes + NEW.bytes_on_disk;
                END;
                CREATE TRIGGER IF NOT EXISTS materialized_usage_update
                AFTER UPDATE OF scope_id, bytes_on_disk ON materialized_entries
                BEGIN
                  UPDATE fabric_scope_usage
                  SET materialized_bytes = materialized_bytes - OLD.bytes_on_disk
                  WHERE scope_id = OLD.scope_id;
                  INSERT INTO fabric_scope_usage(scope_id, materialized_bytes)
                  VALUES (NEW.scope_id, NEW.bytes_on_disk)
                  ON CONFLICT(scope_id) DO UPDATE SET
                    materialized_bytes = materialized_bytes + NEW.bytes_on_disk;
                END;
                CREATE TRIGGER IF NOT EXISTS materialized_usage_delete
                AFTER DELETE ON materialized_entries
                BEGIN
                  UPDATE fabric_scope_usage
                  SET materialized_bytes = materialized_bytes - OLD.bytes_on_disk
                  WHERE scope_id = OLD.scope_id;
                END;

                CREATE TABLE IF NOT EXISTS local_transfer_intents (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    transfer_id TEXT NOT NULL UNIQUE,
                    path TEXT NOT NULL,
                    source_fingerprint TEXT NOT NULL,
                    expected_remote_digest TEXT,
                    delete_after_ack_path TEXT,
                    delete_after_ack_digest TEXT,
                    delete_mutation_id TEXT,
                    issue_code TEXT CHECK(
                        issue_code IS NULL OR
                        issue_code = 'local_file_present_but_unsupported'
                    ),
                    issue_size_bytes INTEGER CHECK(issue_size_bytes >= 0),
                    created_at_ns INTEGER NOT NULL,
                    updated_at_ns INTEGER NOT NULL,
                    PRIMARY KEY(scope_id, path)
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS local_transfer_intents_restore
                    ON local_transfer_intents(scope_id, created_at_ns, transfer_id);
                CREATE INDEX IF NOT EXISTS local_transfer_delete_source
                    ON local_transfer_intents(scope_id, delete_after_ack_path, delete_after_ack_digest)
                    WHERE delete_after_ack_path IS NOT NULL;
                CREATE INDEX IF NOT EXISTS local_transfer_issue_page
                    ON local_transfer_intents(
                        scope_id, created_at_ns, transfer_id
                    ) WHERE issue_code IS NOT NULL;
                CREATE INDEX IF NOT EXISTS local_transfer_runnable_page
                    ON local_transfer_intents(
                        scope_id, created_at_ns, transfer_id
                    ) WHERE issue_code IS NULL;
                CREATE TABLE IF NOT EXISTS fabric_local_transfer_usage (
                    scope_id INTEGER PRIMARY KEY
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    path_count INTEGER NOT NULL DEFAULT 0 CHECK(path_count >= 0),
                    size_bytes INTEGER NOT NULL DEFAULT 0 CHECK(size_bytes >= 0)
                );
                CREATE TRIGGER IF NOT EXISTS local_transfer_usage_insert
                AFTER INSERT ON local_transfer_intents
                BEGIN
                  INSERT INTO fabric_local_transfer_usage(
                      scope_id, path_count, size_bytes
                  ) VALUES (
                      NEW.scope_id,
                      1,
                      CASE WHEN json_valid(NEW.source_fingerprint) THEN COALESCE(
                          json_extract(NEW.source_fingerprint, '$.size_bytes'),
                          json_extract(NEW.source_fingerprint, '$.size'), 0
                      ) ELSE 0 END
                  )
                  ON CONFLICT(scope_id) DO UPDATE SET
                    path_count = path_count + 1,
                    size_bytes = size_bytes + excluded.size_bytes;
                END;
                CREATE TRIGGER IF NOT EXISTS local_transfer_usage_update
                AFTER UPDATE OF scope_id, source_fingerprint
                ON local_transfer_intents
                BEGIN
                  UPDATE fabric_local_transfer_usage
                  SET path_count = path_count - 1,
                      size_bytes = size_bytes - CASE
                        WHEN json_valid(OLD.source_fingerprint) THEN COALESCE(
                          json_extract(OLD.source_fingerprint, '$.size_bytes'),
                          json_extract(OLD.source_fingerprint, '$.size'), 0
                        ) ELSE 0 END
                  WHERE scope_id = OLD.scope_id;
                  INSERT INTO fabric_local_transfer_usage(
                      scope_id, path_count, size_bytes
                  ) VALUES (
                      NEW.scope_id,
                      1,
                      CASE WHEN json_valid(NEW.source_fingerprint) THEN COALESCE(
                          json_extract(NEW.source_fingerprint, '$.size_bytes'),
                          json_extract(NEW.source_fingerprint, '$.size'), 0
                      ) ELSE 0 END
                  )
                  ON CONFLICT(scope_id) DO UPDATE SET
                    path_count = path_count + 1,
                    size_bytes = size_bytes + excluded.size_bytes;
                END;
                CREATE TRIGGER IF NOT EXISTS local_transfer_usage_delete
                AFTER DELETE ON local_transfer_intents
                BEGIN
                  UPDATE fabric_local_transfer_usage
                  SET path_count = path_count - 1,
                      size_bytes = size_bytes - CASE
                        WHEN json_valid(OLD.source_fingerprint) THEN COALESCE(
                          json_extract(OLD.source_fingerprint, '$.size_bytes'),
                          json_extract(OLD.source_fingerprint, '$.size'), 0
                        ) ELSE 0 END
                  WHERE scope_id = OLD.scope_id;
                END;

                CREATE TABLE IF NOT EXISTS pending_operations (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    mutation_id TEXT PRIMARY KEY,
                    journal_seq INTEGER NOT NULL CHECK(journal_seq > 0),
                    kind TEXT NOT NULL CHECK(kind IN ('put','delete','rename')),
                    path TEXT NOT NULL,
                    destination_path TEXT,
                    base_generation INTEGER,
                    base_digest TEXT,
                    expected_source_digest TEXT,
                    expected_destination_digest TEXT,
                    staged_path TEXT,
                    staged_digest TEXT,
                    staged_size INTEGER,
                    state TEXT NOT NULL CHECK(state IN ('queued','inflight','retry','acked','conflict','quarantined')),
                    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0),
                    failure_count INTEGER NOT NULL DEFAULT 0 CHECK(failure_count >= 0),
                    last_error TEXT,
                    created_at_ns INTEGER NOT NULL,
                    updated_at_ns INTEGER NOT NULL,
                    claimed_at_ns INTEGER,
                    next_attempt_at_ns INTEGER,
                    predecessor_mutation_id TEXT,
                    blocked_count INTEGER NOT NULL DEFAULT 0 CHECK(blocked_count >= 0),
                    ready_at_ns INTEGER NOT NULL DEFAULT 0 CHECK(ready_at_ns >= 0),
                    commit_unknown INTEGER NOT NULL DEFAULT 0
                        CHECK(commit_unknown IN (0, 1)),
                    directory_rename INTEGER NOT NULL DEFAULT 0
                        CHECK(directory_rename IN (0, 1)),
                    directory_rename_observed INTEGER NOT NULL DEFAULT 0
                        CHECK(directory_rename_observed IN (0, 1)),
                    request_digest TEXT CHECK(request_digest IS NULL OR (
                        length(request_digest) = 64
                        AND request_digest NOT GLOB '*[^a-f0-9]*'
                    )),
                    commit_batch_id TEXT
                );
                CREATE INDEX IF NOT EXISTS pending_send_queue
                    ON pending_operations(scope_id, state, created_at_ns);
                CREATE INDEX IF NOT EXISTS pending_acked_cleanup
                    ON pending_operations(state, created_at_ns, mutation_id);
                CREATE INDEX IF NOT EXISTS pending_staged_path
                    ON pending_operations(staged_path)
                    WHERE staged_path IS NOT NULL;
                CREATE INDEX IF NOT EXISTS pending_predecessor
                    ON pending_operations(scope_id, predecessor_mutation_id);
                CREATE INDEX IF NOT EXISTS pending_source_path_order
                    ON pending_operations(
                        scope_id, path, state, journal_seq DESC
                    );
                CREATE INDEX IF NOT EXISTS pending_destination_path_order
                    ON pending_operations(
                        scope_id, destination_path, state, journal_seq DESC
                    ) WHERE destination_path IS NOT NULL;
                CREATE INDEX IF NOT EXISTS pending_coalesce
                    ON pending_operations(
                        scope_id, kind, path, destination_path,
                        state, attempt_count, journal_seq DESC
                    );
                CREATE UNIQUE INDEX IF NOT EXISTS pending_scope_journal_sequence
                    ON pending_operations(scope_id, journal_seq);
                CREATE INDEX IF NOT EXISTS pending_queued_ready
                    ON pending_operations(scope_id, journal_seq, mutation_id)
                    WHERE state = 'queued' AND blocked_count = 0;
                CREATE INDEX IF NOT EXISTS pending_retry_ready
                    ON pending_operations(
                        scope_id, ready_at_ns, journal_seq, mutation_id
                    )
                    WHERE state = 'retry' AND blocked_count = 0;
                CREATE INDEX IF NOT EXISTS pending_inflight_lease
                    ON pending_operations(scope_id, claimed_at_ns, mutation_id)
                    WHERE state = 'inflight';
                CREATE UNIQUE INDEX IF NOT EXISTS pending_one_commit_unknown_per_scope
                    ON pending_operations(scope_id)
                    WHERE commit_unknown = 1 AND commit_batch_id IS NULL;
                CREATE INDEX IF NOT EXISTS pending_commit_unknown_ready
                    ON pending_operations(scope_id, journal_seq, mutation_id)
                    WHERE commit_unknown = 1;
                CREATE INDEX IF NOT EXISTS pending_directory_rename_overlay
                    ON pending_operations(
                        scope_id, directory_rename_observed, state, journal_seq
                    ) WHERE directory_rename = 1;
                CREATE INDEX IF NOT EXISTS pending_quarantined_outcome_unknown
                    ON pending_operations(scope_id, journal_seq, mutation_id)
                    WHERE state = 'quarantined' AND commit_unknown = 1;

                CREATE TABLE IF NOT EXISTS fabric_quota_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scope_id INTEGER NOT NULL
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    event_kind TEXT NOT NULL CHECK(event_kind IN (
                        'operation_insert','intent_insert','rebuild'
                    )),
                    mutation_id TEXT,
                    operation_kind TEXT,
                    path TEXT,
                    destination_path TEXT,
                    staged_size INTEGER,
                    source_fingerprint TEXT,
                    directory_rename INTEGER NOT NULL DEFAULT 0
                        CHECK(directory_rename IN (0, 1))
                );
                CREATE INDEX IF NOT EXISTS fabric_quota_events_scope
                    ON fabric_quota_events(scope_id, event_id);
                CREATE TRIGGER IF NOT EXISTS fabric_quota_events_bound
                AFTER INSERT ON fabric_quota_events
                BEGIN
                  DELETE FROM fabric_quota_events
                  WHERE event_id <= NEW.event_id - 10000;
                END;
                CREATE TRIGGER IF NOT EXISTS fabric_quota_operation_insert
                AFTER INSERT ON pending_operations
                WHEN NEW.state IN ('queued','inflight','retry')
                BEGIN
                  INSERT INTO fabric_quota_events(
                      scope_id, event_kind, mutation_id, operation_kind,
                      path, destination_path, staged_size, directory_rename
                  ) VALUES (
                      NEW.scope_id, 'operation_insert', NEW.mutation_id,
                      NEW.kind, NEW.path, NEW.destination_path,
                      NEW.staged_size, NEW.directory_rename
                  );
                END;
                CREATE TRIGGER IF NOT EXISTS fabric_quota_operation_update
                AFTER UPDATE ON pending_operations
                WHEN
                  (OLD.state IN ('queued','inflight','retry')) !=
                    (NEW.state IN ('queued','inflight','retry'))
                  OR OLD.kind IS NOT NEW.kind
                  OR OLD.path IS NOT NEW.path
                  OR OLD.destination_path IS NOT NEW.destination_path
                  OR OLD.staged_size IS NOT NEW.staged_size
                  OR OLD.directory_rename IS NOT NEW.directory_rename
                BEGIN
                  INSERT INTO fabric_quota_events(scope_id, event_kind, mutation_id)
                  VALUES (NEW.scope_id, 'rebuild', NEW.mutation_id);
                END;
                CREATE TRIGGER IF NOT EXISTS fabric_quota_operation_delete
                AFTER DELETE ON pending_operations
                WHEN OLD.state IN ('queued','inflight','retry')
                BEGIN
                  INSERT INTO fabric_quota_events(scope_id, event_kind, mutation_id)
                  VALUES (OLD.scope_id, 'rebuild', OLD.mutation_id);
                END;
                CREATE TRIGGER IF NOT EXISTS fabric_quota_intent_insert
                AFTER INSERT ON local_transfer_intents
                BEGIN
                  INSERT INTO fabric_quota_events(
                      scope_id, event_kind, mutation_id, path,
                      source_fingerprint
                  ) VALUES (
                      NEW.scope_id, 'intent_insert', NEW.transfer_id,
                      NEW.path, NEW.source_fingerprint
                  );
                END;
                CREATE TRIGGER IF NOT EXISTS fabric_quota_intent_update
                AFTER UPDATE ON local_transfer_intents
                BEGIN
                  INSERT INTO fabric_quota_events(scope_id, event_kind, mutation_id)
                  VALUES (NEW.scope_id, 'rebuild', NEW.transfer_id);
                END;
                CREATE TRIGGER IF NOT EXISTS fabric_quota_intent_delete
                AFTER DELETE ON local_transfer_intents
                BEGIN
                  INSERT INTO fabric_quota_events(scope_id, event_kind, mutation_id)
                  VALUES (OLD.scope_id, 'rebuild', OLD.transfer_id);
                END;

                CREATE TABLE IF NOT EXISTS operation_dependencies (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    mutation_id TEXT NOT NULL
                        REFERENCES pending_operations(mutation_id) ON DELETE CASCADE,
                    predecessor_mutation_id TEXT NOT NULL
                        REFERENCES pending_operations(mutation_id) ON DELETE CASCADE,
                    PRIMARY KEY(scope_id, mutation_id, predecessor_mutation_id)
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS operation_dependencies_predecessor
                    ON operation_dependencies(
                        scope_id, predecessor_mutation_id, mutation_id
                    );

                CREATE TABLE IF NOT EXISTS operation_stages (
                    stage_id INTEGER PRIMARY KEY,
                    mutation_id TEXT NOT NULL REFERENCES pending_operations(mutation_id),
                    staged_path TEXT NOT NULL,
                    staged_digest TEXT NOT NULL,
                    staged_size INTEGER NOT NULL CHECK(staged_size >= 0),
                    active INTEGER NOT NULL CHECK(active IN (0, 1)),
                    recorded_at_ns INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS operation_stage_history
                    ON operation_stages(mutation_id, stage_id);

                CREATE TABLE IF NOT EXISTS remote_apply_intents (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    path TEXT NOT NULL,
                    created_at_ns INTEGER NOT NULL,
                    PRIMARY KEY(scope_id, path)
                ) WITHOUT ROWID;
                CREATE TABLE IF NOT EXISTS remote_rename_intents (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    source_path TEXT NOT NULL,
                    destination_path TEXT NOT NULL,
                    digest TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
                    created_at_ns INTEGER NOT NULL,
                    PRIMARY KEY(scope_id, source_path, destination_path)
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS remote_apply_restore
                    ON remote_apply_intents(scope_id, created_at_ns, path);
                CREATE INDEX IF NOT EXISTS remote_rename_restore
                    ON remote_rename_intents(
                        scope_id, created_at_ns, source_path,
                        destination_path, digest, size_bytes
                    );
                CREATE INDEX IF NOT EXISTS operation_stage_path
                    ON operation_stages(staged_path);

                CREATE TABLE IF NOT EXISTS operation_receipts (
                    mutation_id TEXT PRIMARY KEY REFERENCES pending_operations(mutation_id),
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    remote_generation INTEGER,
                    remote_manifest_digest TEXT,
                    remote_entry_digest TEXT,
                    receipt_json TEXT,
                    recorded_at_ns INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS operation_receipts_projection
                    ON operation_receipts(scope_id, remote_manifest_digest, remote_generation);
                CREATE TABLE IF NOT EXISTS namespace_receipt_heads (
                    scope_id INTEGER PRIMARY KEY
                        REFERENCES authority_scopes(scope_id) ON DELETE CASCADE,
                    generation INTEGER NOT NULL CHECK(generation >= 0)
                );

                CREATE TABLE IF NOT EXISTS eviction_intents (
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    eviction_id TEXT NOT NULL UNIQUE,
                    path TEXT NOT NULL,
                    expected_clean_digest TEXT NOT NULL,
                    expected_stat_fingerprint TEXT NOT NULL,
                    expected_bytes INTEGER NOT NULL CHECK(expected_bytes >= 0),
                    created_at_ns INTEGER NOT NULL,
                    PRIMARY KEY(scope_id, path),
                    FOREIGN KEY(scope_id, path)
                        REFERENCES materialized_entries(scope_id, path)
                        ON DELETE CASCADE
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS eviction_intents_created
                    ON eviction_intents(scope_id, created_at_ns, path);

                CREATE TABLE IF NOT EXISTS conflicts (
                    conflict_id INTEGER PRIMARY KEY,
                    scope_id INTEGER NOT NULL REFERENCES authority_scopes(scope_id),
                    mutation_id TEXT REFERENCES pending_operations(mutation_id),
                    evidence_key TEXT,
                    path TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    base_digest TEXT,
                    local_digest TEXT,
                    local_fingerprint TEXT,
                    remote_digest TEXT,
                    remote_generation INTEGER,
                    staged_path TEXT,
                    recorded_at_ns INTEGER NOT NULL,
                    resolved_at_ns INTEGER
                );
                CREATE INDEX IF NOT EXISTS unresolved_conflicts
                    ON conflicts(scope_id, resolved_at_ns, recorded_at_ns);
                CREATE INDEX IF NOT EXISTS unresolved_conflict_stage
                    ON conflicts(staged_path)
                    WHERE staged_path IS NOT NULL AND resolved_at_ns IS NULL;
                CREATE INDEX IF NOT EXISTS conflict_operation_cleanup
                    ON conflicts(mutation_id, resolved_at_ns, scope_id)
                    WHERE mutation_id IS NOT NULL;
                CREATE INDEX IF NOT EXISTS conflict_scope_page
                    ON conflicts(scope_id, conflict_id);
                CREATE INDEX IF NOT EXISTS conflict_scope_path
                    ON conflicts(scope_id, path, conflict_id);
                CREATE UNIQUE INDEX IF NOT EXISTS conflict_evidence_key
                    ON conflicts(scope_id, evidence_key)
                    WHERE evidence_key IS NOT NULL;
                CREATE INDEX IF NOT EXISTS conflict_standalone_cleanup
                    ON conflicts(conflict_id)
                    WHERE mutation_id IS NULL
                      AND resolved_at_ns IS NOT NULL
                      AND staged_path IS NOT NULL;
                CREATE TABLE IF NOT EXISTS conflict_resolutions (
                    resolution_id TEXT PRIMARY KEY,
                    scope_id INTEGER NOT NULL
                        REFERENCES authority_scopes(scope_id),
                    anchor_conflict_id INTEGER NOT NULL UNIQUE
                        REFERENCES conflicts(conflict_id),
                    mutation_id TEXT,
                    decision TEXT NOT NULL
                        CHECK(decision IN ('keep_local','keep_remote','keep_both')),
                    phase TEXT NOT NULL CHECK(phase IN (
                        'requested','prepared','waiting_successor',
                        'applying_remote','blocked','completed'
                    )),
                    expected_local_digest TEXT,
                    expected_local_fingerprint TEXT,
                    expected_remote_digest TEXT,
                    expected_remote_generation INTEGER,
                    successor_mutation_id TEXT UNIQUE,
                    survivor_path TEXT,
                    staged_path TEXT,
                    staged_digest TEXT,
                    staged_size INTEGER CHECK(staged_size >= 0),
                    last_error TEXT,
                    retry_safe INTEGER NOT NULL DEFAULT 0
                        CHECK(retry_safe IN (0, 1)),
                    retry_requested_at_ns INTEGER,
                    created_at_ns INTEGER NOT NULL,
                    updated_at_ns INTEGER NOT NULL,
                    completed_at_ns INTEGER,
                    CHECK(
                      (staged_path IS NULL AND staged_digest IS NULL
                       AND staged_size IS NULL)
                      OR
                      (staged_path IS NOT NULL AND staged_digest IS NOT NULL
                       AND staged_size IS NOT NULL)
                    ),
                    CHECK(
                      (phase = 'completed' AND completed_at_ns IS NOT NULL)
                      OR
                      (phase != 'completed' AND completed_at_ns IS NULL)
                    )
                );
                CREATE UNIQUE INDEX IF NOT EXISTS conflict_resolution_mutation
                    ON conflict_resolutions(scope_id, mutation_id)
                    WHERE mutation_id IS NOT NULL;
                CREATE INDEX IF NOT EXISTS conflict_resolution_work
                    ON conflict_resolutions(
                        scope_id, phase, updated_at_ns, resolution_id
                    );
                CREATE INDEX IF NOT EXISTS conflict_resolution_stage
                    ON conflict_resolutions(staged_path)
                    WHERE staged_path IS NOT NULL AND phase != 'completed';
                    PRAGMA user_version = 25;
                COMMIT;
                """
            )
            self._ensure_content_checksum_columns()
            # Additive journal metadata: older pending/fenced operations retain
            # NULL and keep their original request until conclusively settled.
            with self._transaction():
                columns = {row["name"] for row in self._connection.execute(
                    "PRAGMA table_info(pending_operations)"
                )}
                if "rename_source_json" not in columns:
                    self._connection.execute(
                        "ALTER TABLE pending_operations ADD COLUMN rename_source_json TEXT"
                    )

    def _ensure_content_checksum_columns(self) -> None:
        """Bind local-byte eviction proof independently of a remote file root."""
        self._connection.execute("BEGIN IMMEDIATE")
        try:
            columns = {row["name"] for row in self._connection.execute("PRAGMA table_info(materialized_entries)")}
            if "clean_digest_algorithm" not in columns:
                self._connection.execute("ALTER TABLE materialized_entries ADD COLUMN clean_digest_algorithm TEXT NOT NULL DEFAULT 'sha256'")
                self._connection.execute("""UPDATE materialized_entries AS materialized
                    SET clean_digest_algorithm = COALESCE((
                        SELECT COALESCE(json_extract(remote.blocks_json, '$.file_digest_algorithm'),
                                        json_extract(remote.blocks_json, '$.fileDigestAlgorithm'), 'sha256')
                        FROM remote_entries AS remote
                        WHERE remote.scope_id = materialized.scope_id AND remote.path = materialized.path
                          AND remote.digest = materialized.clean_digest
                    ), 'sha256')""")
            if "content_sha256" not in columns:
                self._connection.execute("ALTER TABLE materialized_entries ADD COLUMN content_sha256 TEXT")
                # Existing flat identities are themselves the byte checksum.
                # Never infer the bytes checksum from a block-root identity.
                self._connection.execute("""UPDATE materialized_entries AS materialized
                    SET content_sha256 = clean_digest
                    WHERE clean_digest IS NOT NULL AND NOT EXISTS (
                        SELECT 1 FROM remote_entries AS remote
                        WHERE remote.scope_id = materialized.scope_id AND remote.path = materialized.path
                          AND remote.digest = materialized.clean_digest
                          AND COALESCE(json_extract(remote.blocks_json, '$.file_digest_algorithm'),
                                       json_extract(remote.blocks_json, '$.fileDigestAlgorithm'), 'sha256') != 'sha256'
                    )""")
            columns = {row["name"] for row in self._connection.execute("PRAGMA table_info(eviction_intents)")}
            if "expected_content_sha256" not in columns:
                self._connection.execute("ALTER TABLE eviction_intents ADD COLUMN expected_content_sha256 TEXT")
                self._connection.execute("""UPDATE eviction_intents AS intent
                    SET expected_content_sha256 = (
                        SELECT content_sha256 FROM materialized_entries AS materialized
                        WHERE materialized.scope_id = intent.scope_id AND materialized.path = intent.path
                          AND materialized.clean_digest = intent.expected_clean_digest
                    )""")
            # Internal SQL state transitions also change clean identities.
            # Rebind flat checksums and clear block-root byte proof atomically.
            for trigger, event, condition in (
                ("materialized_content_identity_inserted", "INSERT", ""),
                ("materialized_content_identity_changed", "UPDATE OF clean_digest",
                 "WHEN NEW.clean_digest IS NOT OLD.clean_digest"),
            ):
                self._connection.execute(f"""CREATE TRIGGER IF NOT EXISTS {trigger}
                    AFTER {event} ON materialized_entries {condition}
                    BEGIN
                        UPDATE materialized_entries SET clean_digest_algorithm = COALESCE((
                            SELECT COALESCE(json_extract(remote.blocks_json, '$.file_digest_algorithm'),
                                            json_extract(remote.blocks_json, '$.fileDigestAlgorithm'), 'sha256')
                            FROM remote_entries AS remote
                            WHERE remote.scope_id = NEW.scope_id AND remote.path = NEW.path
                              AND remote.digest = NEW.clean_digest
                        ), 'sha256') WHERE scope_id = NEW.scope_id AND path = NEW.path;
                        UPDATE materialized_entries SET content_sha256 = CASE
                            WHEN clean_digest_algorithm = 'sha256' THEN NEW.clean_digest ELSE NULL END
                        WHERE scope_id = NEW.scope_id AND path = NEW.path;
                    END""")
            self._connection.execute("PRAGMA user_version = 25")
        except BaseException:
            self._connection.execute("ROLLBACK")
            raise
        self._connection.execute("COMMIT")


def _canonical_path(path: str) -> str:
    return "/".join(split_relative(path))


def _prefix_upper_bound(prefix: str) -> str:
    """Smallest string strictly greater than every string starting with ``prefix``.

    Increment the final code point so ``prefix <= p < upper`` is exactly the set
    of paths that begin with ``prefix``. This turns a non-sargable
    ``substr(path, 1, n) = prefix`` filter into an indexed ``path`` range scan on
    the ``(scope_id, path)`` primary key. Directory prefixes always end in ``/``
    (0x2F), whose successor is ``0`` (0x30); every character that can begin a
    sibling name sorts outside ``[prefix, upper)``, so the range selects true
    descendants only.
    """

    if not prefix:
        raise ValueError("prefix must be non-empty to bound a range")
    return prefix[:-1] + chr(ord(prefix[-1]) + 1)


def _validate_manifest_successor(
    head: sqlite3.Row | None, generation: int, digest: str | None
) -> None:
    if head is None:
        return
    current_digest_raw = head["digest"]
    if (current_digest_raw is None) != (digest is None):
        # A v1 head counts manifest generations and carries a digest; a v2 head
        # counts journal sequences and carries none. The two are unrelated
        # number spaces, so "is this newer?" is not a question that can be
        # asked across them -- v2 sequence 1 is not stale with respect to v1
        # generation 97. Crossing between the lanes is a bootstrap, and the
        # only thing that publishes one is a complete snapshot load, which is
        # self-consistent whichever direction it goes.
        return
    current_generation = int(head["generation"])
    if generation < current_generation:
        if digest is None:
            # Both callers are COMPLETE loads -- a full walk of the tree, not a
            # page of a delta -- so what they publish replaces the namespace
            # rather than being applied on top of it. For a v2 workspace that
            # makes a lower sequence adoptable rather than stale: it is what a
            # reset workspace legitimately reports, and refusing it wedges the
            # node forever with no signal, which is strictly worse than
            # adopting a complete, self-consistent picture. The delta lane
            # keeps its own strictly-advancing fence (apply_remote_delta), so
            # this cannot let an out-of-order page through.
            return
        raise StateError("A stale remote manifest generation cannot replace a newer one.")
    if generation == current_generation:
        # Compare the digests as stored. Two None digests are the same v2 head,
        # which is what makes a re-published snapshot at an unchanged sequence a
        # no-op rather than a conflict; a None on one side only is a v1/v2
        # identity mismatch and must not be silently accepted.
        current_digest = head["digest"]
        current = str(current_digest) if current_digest is not None else None
        if digest != current:
            raise StateError("One remote manifest generation cannot have two digests.")


def _resolved_root(root: Path | str) -> str:
    value = Path(root).expanduser().resolve(strict=False)
    if not value.is_absolute():  # pragma: no cover - Path.resolve guarantees this
        raise ValueError("workspace_root must resolve to an absolute path.")
    return os.path.normcase(os.path.realpath(str(value)))


def _nonempty(name: str, value: str) -> str:
    if not isinstance(value, str) or not value or len(value.encode("utf-8")) > 4_096:
        raise ValueError(f"{name} must be a non-empty bounded string.")
    return value


def _bounded_text(name: str, value: str, maximum: int) -> str:
    if not isinstance(value, str) or not value or len(value.encode("utf-8")) > maximum:
        raise ValueError(f"{name} must be a non-empty string of at most {maximum} bytes.")
    return value


def _generation(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError("generation must be a positive integer.")
    return value


def _sequence(name: str, value: int) -> int:
    """A Fabric v2 journal sequence, which starts at 0 rather than 1.

    Sequence 0 is not "unset": it is the exact, settled head of a workspace
    that has never been written to, and a client that cannot represent it
    would have to re-bootstrap an empty workspace on every poll.
    """

    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer.")
    return value


def _positive_id(name: str, value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{name} must be a positive integer.")
    return value


def _digest(name: str, value: str | None, *, required: bool = False) -> str | None:
    if value is None and not required:
        return None
    if not isinstance(value, str) or RAW_SHA256_RE.fullmatch(value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256 digest.")
    return value


def _mutation_id(value: str | None) -> str:
    if value is None:
        return str(uuid.uuid4())
    try:
        parsed = uuid.UUID(value)
    except (AttributeError, TypeError, ValueError) as error:
        raise ValueError("mutation_id must be a UUID.") from error
    if str(parsed) != value.lower():
        raise ValueError("mutation_id must use canonical UUID form.")
    return str(parsed)


def _canonical_uuid(name: str, value: str) -> str:
    try:
        parsed = uuid.UUID(value)
    except (AttributeError, TypeError, ValueError) as error:
        raise ValueError(f"{name} must be a UUID.") from error
    if str(parsed) != value.lower():
        raise ValueError(f"{name} must use canonical UUID form.")
    return str(parsed)


def _conflict_decision(value: ConflictDecision | str) -> str:
    if not isinstance(value, str) or value not in _CONFLICT_DECISIONS:
        raise ValueError(
            "decision must be keep_local, keep_remote, or keep_both."
        )
    return value


def _local_transfer_issue(
    code: str | None, size_bytes: int | None
) -> tuple[str | None, int | None]:
    if code is None:
        if size_bytes is not None:
            raise ValueError("issue_size_bytes requires issue_code.")
        return None, None
    if not isinstance(code, str) or code not in _LOCAL_TRANSFER_ISSUES:
        raise ValueError("Unknown local transfer issue code.")
    if (
        isinstance(size_bytes, bool)
        or not isinstance(size_bytes, int)
        or size_bytes < 0
    ):
        raise ValueError("issue_size_bytes must be non-negative.")
    return code, size_bytes


def _local_transfer_source_size(source_fingerprint: str) -> int:
    """Read the one strict byte-size field accepted by transfer admission.

    ``size`` remains accepted for durable rows written by pre-``size_bytes``
    clients, but ambiguous dual fields, JSON numbers represented as floats or
    strings, null, booleans, and negative values all fail closed.
    """

    try:
        document = json.loads(source_fingerprint)
    except (TypeError, json.JSONDecodeError) as error:
        raise ValueError("source_fingerprint must contain a valid JSON object.") from error
    if not isinstance(document, Mapping):
        raise ValueError("source_fingerprint must contain a valid JSON object.")
    present = tuple(name for name in ("size_bytes", "size") if name in document)
    if len(present) != 1:
        raise ValueError("source_fingerprint must contain one canonical byte size.")
    value = document[present[0]]
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("source_fingerprint size must be a non-negative integer.")
    return value


def _conflict_resolution_phase(value: ConflictResolutionPhase | str) -> str:
    if not isinstance(value, str) or value not in _CONFLICT_RESOLUTION_PHASES:
        raise ValueError("Unknown conflict resolution phase.")
    return value


def _resolution_fields_match(
    row: sqlite3.Row,
    *,
    staged_path: str | None,
    staged_digest: str | None,
    staged_size: int | None,
    survivor_path: str | None,
    last_error: str | None,
    retry_safe: bool,
) -> bool:
    proposed = {
        "staged_path": staged_path,
        "staged_digest": staged_digest,
        "staged_size": staged_size,
        "survivor_path": survivor_path,
        "last_error": last_error,
        "retry_safe": int(retry_safe),
    }
    return all(value is None or row[column] == value for column, value in proposed.items())


def _blocks_json(blocks: Any | None) -> str | None:
    if blocks is None:
        return None
    return _bounded_json(blocks, _MAX_BLOCKS_JSON_BYTES, "blocks")


def _block_layout_completion_matches(
    deferred: object,
    completed: object,
    *,
    file_size_bytes: int,
) -> bool:
    """Whether a completed map is the exact continuation of one summary."""

    if not isinstance(deferred, dict) or not isinstance(completed, dict):
        return False
    if (
        deferred.get("blocks_complete") is not False
        or completed.get("blocks_complete") is not True
        or deferred.get("blocks") != []
        or not isinstance(completed.get("blocks"), list)
    ):
        return False

    required = (
        "version",
        "algorithm",
        "block_size_bytes",
        "block_count",
        "total_bytes",
        "storage",
    )
    if any(key not in deferred or key not in completed for key in required):
        return False
    if any(
        json.dumps(deferred[key], sort_keys=True, separators=(",", ":"))
        != json.dumps(completed[key], sort_keys=True, separators=(",", ":"))
        for key in required
    ):
        return False
    if deferred.get("version") != 1 or deferred.get("algorithm") != "sha256":
        return False
    if deferred.get("file_digest_algorithm", "sha256") != completed.get("file_digest_algorithm", "sha256"):
        return False

    block_size = deferred.get("block_size_bytes")
    block_count = deferred.get("block_count")
    total_bytes = deferred.get("total_bytes")
    storage = deferred.get("storage")
    if (
        isinstance(block_size, bool)
        or not isinstance(block_size, int)
        or block_size < 1
        or isinstance(block_count, bool)
        or not isinstance(block_count, int)
        or block_count < 1
        or len(completed["blocks"]) != block_count
        or isinstance(total_bytes, bool)
        or not isinstance(total_bytes, int)
        or total_bytes != file_size_bytes
        or not isinstance(storage, dict)
        or not isinstance(storage.get("kind"), str)
        or not storage["kind"]
    ):
        return False

    deferred_has_chunking = "chunking" in deferred
    if deferred_has_chunking != ("chunking" in completed):
        return False
    if deferred_has_chunking:
        if (
            not isinstance(deferred["chunking"], dict)
            or json.dumps(
                deferred["chunking"], sort_keys=True, separators=(",", ":")
            )
            != json.dumps(
                completed["chunking"], sort_keys=True, separators=(",", ":")
            )
        ):
            return False
    return True


def _block_layout_completion_matches_sql(
    deferred_json: object,
    completed_json: object,
    file_size_bytes: object,
) -> int:
    """SQLite-safe adapter for exact deferred-map preservation."""

    if (
        not isinstance(deferred_json, str)
        or not isinstance(completed_json, str)
        or isinstance(file_size_bytes, bool)
        or not isinstance(file_size_bytes, int)
    ):
        return 0
    try:
        deferred = json.loads(deferred_json)
        completed = json.loads(completed_json)
    except (TypeError, ValueError, json.JSONDecodeError):
        return 0
    return int(
        _block_layout_completion_matches(
            deferred,
            completed,
            file_size_bytes=file_size_bytes,
        )
    )


def _remote_intents(
    apply_paths: Iterable[str],
    renames: Iterable[tuple[str, str, str, int]],
) -> tuple[tuple[str, ...], tuple[tuple[str, str, str, int], ...]]:
    applies = tuple(sorted(set(_canonical_path(path) for path in apply_paths)))
    normalized: dict[tuple[str, str], tuple[str, str, str, int]] = {}
    for raw in renames:
        if not isinstance(raw, tuple) or len(raw) != 4:
            raise ValueError("A remote rename intent must contain four fields.")
        source = _canonical_path(raw[0])
        destination = _canonical_path(raw[1])
        if source == destination:
            raise ValueError("A remote rename intent must change the path.")
        digest = _digest("rename digest", raw[2], required=True)
        size = raw[3]
        if isinstance(size, bool) or not isinstance(size, int) or size < 0:
            raise ValueError("A remote rename intent size must be non-negative.")
        normalized[(source, destination)] = (source, destination, digest, size)
    return applies, tuple(normalized[key] for key in sorted(normalized))


def _bounded_json(value: Any | None, maximum: int, name: str) -> str | None:
    if value is None:
        return None
    try:
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be JSON serializable.") from error
    if len(encoded.encode("utf-8")) > maximum:
        raise ValueError(f"{name} exceeds its {maximum}-byte metadata limit.")
    return encoded


def _remote_entry(value: RemoteEntry | Mapping[str, Any]) -> RemoteEntry:
    if isinstance(value, RemoteEntry):
        kind = value.kind
        path, size, digest, modified, blocks = (
            value.path,
            value.size_bytes,
            value.digest,
            value.modified,
            value.blocks,
        )
    elif isinstance(value, Mapping):
        kind = value.get("kind", "file")
        path = value.get("path")
        size = value.get("size_bytes")
        digest = value.get("digest", value.get("sha256"))
        modified = value.get("modified")
        blocks = value.get("blocks")
    else:
        raise TypeError("Remote manifest entries must be RemoteEntry values or mappings.")
    path = _canonical_path(path)  # type: ignore[arg-type]
    if kind not in ("file", "directory"):
        raise ValueError("Remote entry kind must be file or directory.")
    if kind == "directory":
        if size not in (None, 0) or digest is not None or blocks is not None:
            raise ValueError("Remote directories cannot carry file content.")
        return RemoteEntry(path, 0, None, kind="directory")
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise ValueError("Remote entry size_bytes must be non-negative.")
    digest = _digest("remote entry digest", digest, required=True)  # type: ignore[arg-type]
    if modified is not None:
        modified = _bounded_text("modified", modified, 4_096)
    # Validate size/canonical form now; serialization is repeated inside the
    # transaction only to keep the immutable dataclass convenient to callers.
    if blocks is not None:
        _blocks_json(blocks)
    assert digest is not None
    return RemoteEntry(path, size, digest, modified, blocks)


def _remote_from_row(row: sqlite3.Row) -> RemoteEntry:
    return RemoteEntry(
        path=str(row["path"]),
        size_bytes=int(row["size_bytes"]),
        digest=str(row["digest"]),
        modified=str(row["modified"]) if row["modified"] is not None else None,
        blocks=json.loads(row["blocks_json"]) if row["blocks_json"] is not None else None,
    )


def _authority_from_row(row: sqlite3.Row, *, changed: bool) -> AuthorityBinding:
    return AuthorityBinding(
        scope_id=int(row["scope_id"]),
        host_id=str(row["host_id"]),
        session_id=str(row["session_id"]),
        host_generation=int(row["host_generation"]),
        attachment_id=str(row["attachment_id"]) if row["attachment_id"] is not None else None,
        workspace_root=str(row["workspace_root"]),
        workspace_id=(
            str(row["workspace_id"]) if row["workspace_id"] is not None else None
        ),
        adoption_required=bool(row["adoption_required"]),
        adoption_reason=(
            str(row["adoption_reason"])
            if row["adoption_reason"] is not None
            else None
        ),
        changed=changed,
    )


def _manifest_load_from_row(row: sqlite3.Row) -> RemoteManifestLoad:
    return RemoteManifestLoad(
        load_id=str(row["load_id"]),
        manifest_id=str(row["manifest_id"]),
        generation=int(row["generation"]),
        digest=str(row["digest"]) if row["digest"] is not None else None,
        expected_entries=int(row["expected_entries"]),
        ingested_entries=int(row["ingested_entries"]),
        last_path=str(row["last_path"]) if row["last_path"] is not None else None,
        created_at_ns=int(row["created_at_ns"]),
        updated_at_ns=int(row["updated_at_ns"]),
    )


def _local_transfer_from_row(row: sqlite3.Row) -> LocalTransferIntent:
    return LocalTransferIntent(
        scope_id=int(row["scope_id"]),
        transfer_id=str(row["transfer_id"]),
        path=str(row["path"]),
        source_fingerprint=str(row["source_fingerprint"]),
        expected_remote_digest=(
            str(row["expected_remote_digest"])
            if row["expected_remote_digest"] is not None
            else None
        ),
        delete_after_ack_path=(
            str(row["delete_after_ack_path"])
            if row["delete_after_ack_path"] is not None
            else None
        ),
        delete_after_ack_digest=(
            str(row["delete_after_ack_digest"])
            if row["delete_after_ack_digest"] is not None
            else None
        ),
        delete_mutation_id=(
            str(row["delete_mutation_id"])
            if row["delete_mutation_id"] is not None
            else None
        ),
        issue_code=(
            str(row["issue_code"]) if row["issue_code"] is not None else None
        ),
        issue_size_bytes=(
            int(row["issue_size_bytes"])
            if row["issue_size_bytes"] is not None
            else None
        ),
        created_at_ns=int(row["created_at_ns"]),
        updated_at_ns=int(row["updated_at_ns"]),
    )


def _materialized_from_row(row: sqlite3.Row) -> MaterializedEntry:
    return MaterializedEntry(
        path=str(row["path"]),
        state=str(row["state"]),
        pinned=bool(row["pinned"]),
        clean_digest=str(row["clean_digest"]) if row["clean_digest"] is not None else None,
        stat_fingerprint=(
            str(row["stat_fingerprint"]) if row["stat_fingerprint"] is not None else None
        ),
        bytes_on_disk=int(row["bytes_on_disk"]),
        accessed_at_ns=int(row["accessed_at_ns"]),
        updated_at_ns=int(row["updated_at_ns"]),
        remote_verified=bool(row["remote_verified"]),
        content_sha256=str(row["content_sha256"]) if row["content_sha256"] is not None else None,
        clean_digest_algorithm=str(row["clean_digest_algorithm"]),
    )


def _eviction_from_row(row: sqlite3.Row) -> EvictionIntent:
    return EvictionIntent(
        scope_id=int(row["scope_id"]),
        eviction_id=str(row["eviction_id"]),
        path=str(row["path"]),
        expected_clean_digest=str(row["expected_clean_digest"]),
        expected_content_sha256=(str(row["expected_content_sha256"])
            if row["expected_content_sha256"] is not None else None),
        expected_stat_fingerprint=str(row["expected_stat_fingerprint"]),
        expected_bytes=int(row["expected_bytes"]),
        created_at_ns=int(row["created_at_ns"]),
    )


def _remote_rename_from_row(row: sqlite3.Row) -> RemoteRenameIntent:
    return RemoteRenameIntent(
        source_path=str(row["source_path"]),
        destination_path=str(row["destination_path"]),
        digest=str(row["digest"]),
        size_bytes=int(row["size_bytes"]),
        created_at_ns=int(row["created_at_ns"]),
    )


def _operation_from_row(row: sqlite3.Row) -> PendingOperation:
    return PendingOperation(
        mutation_id=str(row["mutation_id"]),
        journal_seq=int(row["journal_seq"]),
        predecessor_mutation_id=(
            str(row["predecessor_mutation_id"])
            if row["predecessor_mutation_id"] is not None
            else None
        ),
        kind=str(row["kind"]),
        path=str(row["path"]),
        destination_path=(
            str(row["destination_path"]) if row["destination_path"] is not None else None
        ),
        base_generation=(
            int(row["base_generation"]) if row["base_generation"] is not None else None
        ),
        base_digest=str(row["base_digest"]) if row["base_digest"] is not None else None,
        expected_source_digest=(
            str(row["expected_source_digest"])
            if row["expected_source_digest"] is not None
            else None
        ),
        expected_destination_digest=(
            str(row["expected_destination_digest"])
            if row["expected_destination_digest"] is not None
            else None
        ),
        staged_path=str(row["staged_path"]) if row["staged_path"] is not None else None,
        staged_digest=(
            str(row["staged_digest"]) if row["staged_digest"] is not None else None
        ),
        staged_size=int(row["staged_size"]) if row["staged_size"] is not None else None,
        state=str(row["state"]),
        commit_unknown=bool(row["commit_unknown"]),
        request_digest=(
            str(row["request_digest"]) if row["request_digest"] is not None else None
        ),
        attempt_count=int(row["attempt_count"]),
        failure_count=int(row["failure_count"]),
        last_error=str(row["last_error"]) if row["last_error"] is not None else None,
        created_at_ns=int(row["created_at_ns"]),
        updated_at_ns=int(row["updated_at_ns"]),
        claimed_at_ns=int(row["claimed_at_ns"]) if row["claimed_at_ns"] is not None else None,
        next_attempt_at_ns=(
            int(row["next_attempt_at_ns"])
            if row["next_attempt_at_ns"] is not None
            else None
        ),
        directory_rename=bool(row["directory_rename"]),
        directory_rename_observed=bool(row["directory_rename_observed"]),
        ready_at_ns=(
            int(row["ready_at_ns"])
            if "ready_at_ns" in row.keys() and row["ready_at_ns"] is not None
            else None
        ),
        commit_batch_id=(
            str(row["commit_batch_id"])
            if "commit_batch_id" in row.keys() and row["commit_batch_id"] is not None
            else None
        ),
        rename_source=(
            _remote_entry(json.loads(row["rename_source_json"]))
            if "rename_source_json" in row.keys() and row["rename_source_json"] is not None
            else None
        ),
    )


def _quarantined_unknown_from_row(
    row: sqlite3.Row, *, resolver_scope_id: int | None
) -> QuarantinedCommitUnknown:
    return QuarantinedCommitUnknown(
        resolver_scope_id=resolver_scope_id,
        original_scope_id=int(row["scope_id"]),
        original_host_id=str(row["original_host_id"]),
        original_session_id=str(row["original_session_id"]),
        original_host_generation=int(row["original_host_generation"]),
        original_attachment_id=(
            str(row["original_attachment_id"])
            if row["original_attachment_id"] is not None
            else None
        ),
        original_workspace_root=str(row["original_workspace_root"]),
        original_workspace_id=(
            str(row["original_workspace_id"])
            if row["original_workspace_id"] is not None
            else None
        ),
        operation=_operation_from_row(row),
    )


def _stage_from_row(row: sqlite3.Row) -> OperationStage:
    return OperationStage(
        stage_id=int(row["stage_id"]),
        mutation_id=str(row["mutation_id"]),
        staged_path=str(row["staged_path"]),
        staged_digest=str(row["staged_digest"]),
        staged_size=int(row["staged_size"]),
        active=bool(row["active"]),
        recorded_at_ns=int(row["recorded_at_ns"]),
    )


def _receipt_from_row(row: sqlite3.Row) -> OperationReceipt:
    return OperationReceipt(
        mutation_id=str(row["mutation_id"]),
        remote_generation=(
            int(row["remote_generation"]) if row["remote_generation"] is not None else None
        ),
        remote_manifest_digest=(
            str(row["remote_manifest_digest"])
            if row["remote_manifest_digest"] is not None
            else None
        ),
        remote_entry_digest=(
            str(row["remote_entry_digest"]) if row["remote_entry_digest"] is not None else None
        ),
        receipt=json.loads(row["receipt_json"]) if row["receipt_json"] is not None else None,
        recorded_at_ns=int(row["recorded_at_ns"]),
    )


def _conflict_from_row(row: sqlite3.Row) -> ConflictRecord:
    return ConflictRecord(
        conflict_id=int(row["conflict_id"]),
        scope_id=int(row["scope_id"]),
        mutation_id=str(row["mutation_id"]) if row["mutation_id"] is not None else None,
        evidence_key=(
            str(row["evidence_key"])
            if row["evidence_key"] is not None
            else None
        ),
        path=str(row["path"]),
        reason=str(row["reason"]),
        base_digest=str(row["base_digest"]) if row["base_digest"] is not None else None,
        local_digest=str(row["local_digest"]) if row["local_digest"] is not None else None,
        local_fingerprint=(
            str(row["local_fingerprint"])
            if row["local_fingerprint"] is not None
            else None
        ),
        remote_digest=str(row["remote_digest"]) if row["remote_digest"] is not None else None,
        remote_generation=(
            int(row["remote_generation"]) if row["remote_generation"] is not None else None
        ),
        staged_path=str(row["staged_path"]) if row["staged_path"] is not None else None,
        recorded_at_ns=int(row["recorded_at_ns"]),
        resolved_at_ns=(
            int(row["resolved_at_ns"]) if row["resolved_at_ns"] is not None else None
        ),
    )


def _conflict_resolution_from_row(row: sqlite3.Row) -> ConflictResolution:
    return ConflictResolution(
        resolution_id=str(row["resolution_id"]),
        scope_id=int(row["scope_id"]),
        anchor_conflict_id=int(row["anchor_conflict_id"]),
        mutation_id=(
            str(row["mutation_id"]) if row["mutation_id"] is not None else None
        ),
        decision=str(row["decision"]),
        phase=str(row["phase"]),
        expected_local_digest=(
            str(row["expected_local_digest"])
            if row["expected_local_digest"] is not None
            else None
        ),
        expected_local_fingerprint=(
            str(row["expected_local_fingerprint"])
            if row["expected_local_fingerprint"] is not None
            else None
        ),
        expected_remote_digest=(
            str(row["expected_remote_digest"])
            if row["expected_remote_digest"] is not None
            else None
        ),
        expected_remote_generation=(
            int(row["expected_remote_generation"])
            if row["expected_remote_generation"] is not None
            else None
        ),
        successor_mutation_id=(
            str(row["successor_mutation_id"])
            if row["successor_mutation_id"] is not None
            else None
        ),
        survivor_path=(
            str(row["survivor_path"])
            if row["survivor_path"] is not None
            else None
        ),
        staged_path=(
            str(row["staged_path"]) if row["staged_path"] is not None else None
        ),
        staged_digest=(
            str(row["staged_digest"])
            if row["staged_digest"] is not None
            else None
        ),
        staged_size=(
            int(row["staged_size"]) if row["staged_size"] is not None else None
        ),
        last_error=(
            str(row["last_error"]) if row["last_error"] is not None else None
        ),
        retry_safe=bool(row["retry_safe"]),
        retry_requested_at_ns=(
            int(row["retry_requested_at_ns"])
            if row["retry_requested_at_ns"] is not None
            else None
        ),
        created_at_ns=int(row["created_at_ns"]),
        updated_at_ns=int(row["updated_at_ns"]),
        completed_at_ns=(
            int(row["completed_at_ns"])
            if row["completed_at_ns"] is not None
            else None
        ),
    )
