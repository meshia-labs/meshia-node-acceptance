"""One JSON-RPC exchange with a **local stdio** MCP server on this host.

Why this exists at all, and why it is this small
------------------------------------------------

The control plane's MCP support (``pod/daemon/mesh/mcp_manager.py``) is entirely
*remote HTTP* MCP: it discovers tools with a ``tools/list`` POST over HTTPS,
dispatches with ``tools/call``, and reads bearer tokens out of the pod process
environment by name (``MESHIA_MCP_<ID>_TOKEN``). Two consequences follow, and
they decide the whole shape of this module.

**Remote MCP needs nothing here.** A remote server is reachable from our
backend, the manager already runs there, and the agent already sees those tools
whether or not a node is attached to the session. Re-implementing that on a
customer-owned host would move a live credential onto a machine whose owner is
assumed hostile, in exchange for no capability at all. So the remote case is
refused here, explicitly, rather than left merely unimplemented — see
:func:`build_request`.

**Local stdio MCP needs something, and nothing existed.** A server that has to
run *on the host* — one that reads local files, reaches a network only that
machine can reach, or drives local hardware — cannot be run from the backend by
definition. That is the one case with a real reason to execute node-side, and
it is what this module does.

Stateless by construction
-------------------------

An MCP conversation is ``initialize`` → validate the server's response →
``notifications/initialized`` → one request. The phases are deliberately
sequential: sending the notification or request before the server accepts the
initialization violates MCP and breaks strict servers. A small client child in
this module owns that conversation and starts the requested server beneath the
existing bounded process. One command is therefore one complete conversation,
and both client and server are gone before the command completes. There is no
session table, no long-lived child, no lease to resurrect after a node restart,
and no orphan to reap. The existing bounded executor still owns the overall
deadline, process group or Windows Job Object, output cap, and limited-access
confinement.

The cost is real and worth stating: a server that keeps state between calls (an
open transaction, a cursor) will not work through this path. That is a
deliberate trade — persistent host-side process state is the part most likely to
become a hole, and no known connector needs it.

Credentials
-----------

There is no inline credential-value channel here. A local server that needs
authentication receives only named variables through the ordinary sealed
workspace-environment path (``payload["env"]``, see
:mod:`meshia_node.task_env`). The durable command carries those names and never
their values; the node resolves the values after validating the command, for a
workspace whose owner deliberately attached this machine as compute.

The refusals cover both halves of the definition, because covering only one
covered nothing: rejecting ``url``/``auth``-style *keys* is useless while
``argv`` can express the same thing — ``["npx", "mcp-remote", "https://…",
"--header", "Authorization: …"]`` is a remote server and a credential at once.
So argv is checked too.

What that is *not* is a proof. A secret can be a bare token with no recognisable
shape, and argv is visible to any local user through the process table anyway,
which is the standing reason not to put secrets there. The enforced property is
narrower and worth stating exactly: **the MCP command payload has no channel
that carries a credential value**. It carries a bounded list of names; values
arrive through the separately authenticated, sealed task-environment exchange.
The obvious argv ways to bypass that exchange are refused.
"""

from __future__ import annotations

import inspect
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import Any

from .errors import InvalidTask
from .task_env import requested_names
from .util import bounded_int, clean

PROTOCOL_VERSION = "2024-11-05"
CLIENT_NAME = "meshia-node"
DEFAULT_TIMEOUT_SECONDS = 60
MAX_TIMEOUT_SECONDS = 300
DEFAULT_MAX_OUTPUT_BYTES = 262_144
MAX_OUTPUT_BYTES_CAP = 1_048_576
MAX_ARGV_ITEMS = 64
MAX_ARGV_ITEM_BYTES = 4096
MAX_PARAMS_BYTES = 262_144
INITIALIZE_ID = 1
CALL_ID = 2
MAX_CLIENT_CONFIG_BYTES = 1_048_576
CLIENT_READ_CHUNK_BYTES = 16_384
CLIENT_QUEUE_DEPTH = 8
CLIENT_TERMINATE_GRACE_SECONDS = 0.5

# The isolated interpreter receives its fixed client program and private
# request configuration over stdin. That avoids depending on an editable source
# checkout (which a limited-access sandbox correctly cannot read) and keeps the
# server argv and tool parameters out of the process table.
_CLIENT_BOOTSTRAP = (
    "import sys;"
    "s=sys.stdin.buffer;"
    "n=int.from_bytes(s.read(4),'big');"
    "b=s.read(n);"
    "assert len(b)==n,'incomplete MCP client';"
    "exec(compile(b,'<meshia-mcp-client>','exec'))"
)

# Methods worth reaching from a hostile-host relay. `tools/list` and
# `tools/call` are the whole point; `prompts/*` and `resources/*` are omitted
# because nothing consumes them yet and an unused method is an unused attack
# surface. Widen this list when something actually needs it.
ALLOWED_METHODS = ("tools/list", "tools/call")

# A local stdio server is fully described by these two fields. The definition is
# closed rather than open: an unrecognised key is refused instead of ignored, so
# a credential nested under some future-looking name (``options``, ``config``)
# cannot ride along as inert payload waiting for a later reader to honour it.
ALLOWED_SERVER_KEYS = ("argv", "cwd")
ALLOWED_PAYLOAD_KEYS = ("server", "method", "params", "timeout_seconds", "max_output_bytes", "env")


def _has_control_characters(value: str) -> bool:
    """Reject characters that can split logs, shells, or process arguments."""
    return any(ord(character) < 32 or ord(character) == 127 for character in value)


def _valid_process_text(value: Any, *, max_bytes: int, allow_empty: bool = False) -> bool:
    if not isinstance(value, str) or (not allow_empty and not value) or _has_control_characters(value):
        return False
    try:
        return len(value.encode("utf-8")) <= max_bytes
    except UnicodeEncodeError:
        return False

# Any of these in a server definition means the caller is trying to hand the
# node either a remote endpoint or a credential. Both are refusals, not
# warnings, and both are checked before the closed-schema check purely so the
# error says *why*. Matched case-insensitively against the definition's keys.
REMOTE_TRANSPORT_KEYS = ("url", "endpoint", "uri", "host", "transport", "sse", "http")
CREDENTIAL_KEYS = (
    "auth",
    "authorization",
    "token",
    "auth_token",
    "access_token",
    "bearer",
    "credential",
    "credentials",
    "api_key",
    "apikey",
    "secret",
    "password",
    "headers",
    "auth_token_env",
)
REMOTE_URI_RE = re.compile(r"(?:https?|ssh|wss?|sse)://", re.IGNORECASE)
REMOTE_WRAPPER_RE = re.compile(
    r"(?:^|[/\\])mcp-remote(?:@[^/\\]+)?(?:\.(?:cmd|exe|js|cjs|mjs|py|sh))?$",
    re.IGNORECASE,
)
RAW_AUTH_OPTIONS = frozenset({
    "--auth", "--authorization", "--bearer", "--token", "--access-token",
    "--auth-token", "--auth_token", "--api-key", "--api_key", "--apikey", "--password", "--secret",
    "--credential", "--credentials", "--header", "--headers", "--http-header",
    "--request-header",
})
CREDENTIAL_FILE_OPTIONS = frozenset({
    "--token-file", "--access-token-file", "--auth-token-file", "--api-key-file",
    "--apikey-file", "--password-file", "--secret-file", "--credential-file",
    "--credentials-file", "--header-file", "--headers-file",
    "--token-path", "--access-token-path", "--auth-token-path", "--api-key-path",
    "--apikey-path", "--password-path", "--secret-path", "--credential-path",
    "--credentials-path", "--header-path", "--headers-path",
})


def _looks_like_a_credential(item: str) -> bool:
    """Shapes that are unambiguously an inline secret rather than an argument."""
    lowered = item.lower()
    return (
        "authorization:" in lowered
        or "proxy-authorization:" in lowered
        or lowered.startswith("bearer ")
        or "bearer " in lowered
        and ":" in lowered  # a header value pasted whole
    )


def _credential_file_path(value: str) -> bool:
    """Accept an auth file only when its value is unmistakably a local path."""
    return (
        bool(value)
        and not _has_control_characters(value)
        and not REMOTE_URI_RE.search(value)
        and bool(
            value.startswith(("/", "./", "../", "~/", "\\\\"))
            or re.match(r"^[A-Za-z]:[/\\]", value)
            or "/" in value
            or "\\" in value
        )
    )


def _validate_local_argv(argv: list[str]) -> None:
    for index, argument in enumerate(argv):
        lowered = argument.lower()
        option, separator, _inline_value = lowered.partition("=")
        if REMOTE_URI_RE.search(argument):
            raise InvalidTask(
                "mcp_call.server.argv must not contain a remote URI. Remote MCP servers "
                "and their credentials stay in the control plane."
            )
        if REMOTE_WRAPPER_RE.search(argument):
            raise InvalidTask("mcp_call.server.argv must not launch the mcp-remote wrapper.")
        if (
            _looks_like_a_credential(argument)
            or option in RAW_AUTH_OPTIONS
            or argument.startswith("-H")
        ):
            raise InvalidTask(
                "mcp_call.server.argv must not carry a raw authentication or header option. "
                "Pass only workspace environment variable names through mcp_call.env."
            )
        if option in CREDENTIAL_FILE_OPTIONS:
            path = argument.split("=", 1)[1] if separator else (
                argv[index + 1] if index + 1 < len(argv) else ""
            )
            if not _credential_file_path(path):
                raise InvalidTask(
                    "mcp_call credential-file options require an explicit local filesystem path."
                )


@dataclass(frozen=True)
class McpRequest:
    argv: list[str]
    cwd: str
    method: str
    params: dict[str, Any]
    timeout_seconds: int
    max_output_bytes: int

    def client_argv(self) -> list[str]:
        """The trusted one-shot client, with no request data in process argv."""
        from .util import console_python

        return [console_python(), "-I", "-c", _CLIENT_BOOTSTRAP]

    def client_stdin(self) -> bytes:
        """Length-prefixed private configuration for the trusted client child."""
        config = json.dumps(
            {
                "argv": self.argv,
                "method": self.method,
                "params": self.params,
                "timeout_seconds": self.timeout_seconds,
                "max_output_bytes": self.max_output_bytes,
            },
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
        if len(config) > MAX_CLIENT_CONFIG_BYTES:  # defensive; build_request is tighter
            raise InvalidTask("The local MCP client configuration exceeds its transfer bound.")
        program = _client_program()
        return (
            len(program).to_bytes(4, "big")
            + program
            + len(config).to_bytes(4, "big")
            + config
        )


class _ClientProtocolError(RuntimeError):
    """A bounded, user-safe failure produced by the trusted client child."""


def _initialize_frame() -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": INITIALIZE_ID,
        "method": "initialize",
        "params": {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": CLIENT_NAME, "version": "1"},
        },
    }


def _request_frame(method: str, params: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": CALL_ID, "method": method, "params": params}


def _validate_initialize_response(frame: Any) -> None:
    """Accept only the MCP version and response shape this client implements."""
    if not isinstance(frame, dict):
        raise _ClientProtocolError("MCP initialize returned a non-object JSON-RPC frame.")
    if frame.get("jsonrpc") != "2.0":
        raise _ClientProtocolError("MCP initialize returned an invalid JSON-RPC version.")
    # bool is an int subclass; do not let true accidentally match request id 1.
    response_id = frame.get("id")
    if isinstance(response_id, bool) or response_id != INITIALIZE_ID:
        raise _ClientProtocolError("MCP initialize returned a mismatched response id.")
    if "error" in frame:
        error = frame.get("error")
        message = error.get("message") if isinstance(error, dict) else error
        raise _ClientProtocolError(f"MCP initialize was rejected: {message or 'server error'}")
    result = frame.get("result")
    if not isinstance(result, dict):
        raise _ClientProtocolError("MCP initialize returned no result object.")
    if result.get("protocolVersion") != PROTOCOL_VERSION:
        value = result.get("protocolVersion")
        raise _ClientProtocolError(
            f"MCP initialize negotiated unsupported protocol version {value!r}."
        )
    if not isinstance(result.get("capabilities"), dict):
        raise _ClientProtocolError("MCP initialize returned invalid server capabilities.")
    server_info = result.get("serverInfo")
    if (
        not isinstance(server_info, dict)
        or not isinstance(server_info.get("name"), str)
        or not server_info.get("name")
        or not isinstance(server_info.get("version"), str)
        or not server_info.get("version")
    ):
        raise _ClientProtocolError("MCP initialize returned invalid serverInfo.")


def _read_exact(stream: Any, size: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < size:
        chunk = stream.read(size - len(chunks))
        if not chunk:
            raise _ClientProtocolError("The local MCP client configuration is incomplete.")
        chunks.extend(chunk)
    return bytes(chunks)


def _write_frame(process: subprocess.Popen[bytes], frame: dict[str, Any]) -> None:
    if process.stdin is None:
        raise _ClientProtocolError("The MCP server closed stdin before the exchange completed.")
    try:
        process.stdin.write(json.dumps(frame, separators=(",", ":")).encode("utf-8") + b"\n")
        process.stdin.flush()
    except (BrokenPipeError, OSError) as error:
        raise _ClientProtocolError(
            "The MCP server closed stdin before the exchange completed."
        ) from error


def _client_error(message: str) -> None:
    """Return lifecycle failures through the existing CALL_ID result channel."""
    frame = {
        "jsonrpc": "2.0",
        "id": CALL_ID,
        "error": {"code": -32002, "message": str(message)[:2048]},
    }
    sys.stdout.buffer.write(json.dumps(frame, separators=(",", ":")).encode("utf-8") + b"\n")
    sys.stdout.buffer.flush()


def _client_main() -> int:
    """Run a protocol-faithful, one-request MCP stdio conversation.

    This function executes only in the bounded child created by the command
    executor. The MCP server it starts inherits that child's confinement,
    process group or Job Object, scrubbed environment, and cancellation fate.
    """
    process: subprocess.Popen[bytes] | None = None
    try:
        size = int.from_bytes(_read_exact(sys.stdin.buffer, 4), "big")
        if not 2 <= size <= MAX_CLIENT_CONFIG_BYTES:
            raise _ClientProtocolError("The local MCP client configuration exceeds its bound.")
        config = json.loads(_read_exact(sys.stdin.buffer, size))
        if not isinstance(config, dict):
            raise _ClientProtocolError("The local MCP client configuration is invalid.")
        argv = config.get("argv")
        method = config.get("method")
        params = config.get("params")
        timeout_seconds = config.get("timeout_seconds")
        max_output_bytes = config.get("max_output_bytes")
        if (
            not isinstance(argv, list)
            or not argv
            or any(not isinstance(item, str) or not item for item in argv)
            or method not in ALLOWED_METHODS
            or not isinstance(params, dict)
            or isinstance(timeout_seconds, bool)
            or not isinstance(timeout_seconds, int)
            or timeout_seconds < 1
            or isinstance(max_output_bytes, bool)
            or not isinstance(max_output_bytes, int)
            or max_output_bytes < 1
        ):
            raise _ClientProtocolError("The local MCP client configuration is invalid.")

        creation = (
            {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
            if sys.platform == "win32"
            else {}
        )
        try:
            process = subprocess.Popen(  # noqa: S603 - validated argv, never a shell
                argv,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                close_fds=True,
                **creation,
            )
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            raise _ClientProtocolError(f"The MCP server could not be started: {error}") from error
        assert process.stdout is not None and process.stderr is not None

        events: queue.Queue[tuple[str, bytes | None]] = queue.Queue(maxsize=CLIENT_QUEUE_DEPTH)

        def pump(stream: Any, channel: str) -> None:
            try:
                while True:
                    chunk = os.read(stream.fileno(), CLIENT_READ_CHUNK_BYTES)
                    if not chunk:
                        break
                    events.put((channel, chunk))
            except OSError:
                pass
            finally:
                events.put((channel, None))

        for stream, channel in ((process.stdout, "out"), (process.stderr, "err")):
            threading.Thread(target=pump, args=(stream, channel), daemon=True).start()

        deadline = time.monotonic() + timeout_seconds
        stdout_buffer = bytearray()
        pending_lines: deque[bytes] = deque()
        stderr_buffer = bytearray()
        total_output = 0
        stdout_eof = False

        def next_protocol_frame(phase: str) -> dict[str, Any]:
            nonlocal total_output, stdout_eof
            while True:
                while pending_lines:
                    line = pending_lines.popleft().strip()
                    if not line:
                        continue
                    # Preserve the historical tolerance for banners while
                    # rejecting anything that presents itself as JSON-RPC but
                    # is malformed or has the wrong shape.
                    if not line.startswith((b"{", b"[")):
                        continue
                    try:
                        frame = json.loads(line.decode("utf-8"))
                    except (UnicodeDecodeError, ValueError) as error:
                        raise _ClientProtocolError(
                            f"MCP {phase} returned malformed JSON."
                        ) from error
                    if not isinstance(frame, dict):
                        raise _ClientProtocolError(
                            f"MCP {phase} returned a non-object JSON-RPC frame."
                        )
                    return frame
                if stdout_eof:
                    detail = stderr_buffer.decode("utf-8", "replace").strip()[:512]
                    suffix = f" ({detail})" if detail else ""
                    raise _ClientProtocolError(
                        f"The MCP server closed before its {phase} response{suffix}."
                    )
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise _ClientProtocolError(f"The MCP server timed out during {phase}.")
                try:
                    channel, chunk = events.get(timeout=min(0.1, remaining))
                except queue.Empty:
                    continue
                if chunk is None:
                    if channel == "out":
                        stdout_eof = True
                        if stdout_buffer:
                            pending_lines.append(bytes(stdout_buffer))
                            stdout_buffer.clear()
                    continue
                total_output += len(chunk)
                if total_output > max_output_bytes:
                    raise _ClientProtocolError("The MCP server exceeded its output byte limit.")
                if channel == "err":
                    stderr_buffer.extend(chunk[: max(0, 2048 - len(stderr_buffer))])
                    continue
                stdout_buffer.extend(chunk)
                while True:
                    newline = stdout_buffer.find(b"\n")
                    if newline < 0:
                        break
                    pending_lines.append(bytes(stdout_buffer[:newline]))
                    del stdout_buffer[: newline + 1]

        _write_frame(process, _initialize_frame())
        initialize = next_protocol_frame("initialize")
        _validate_initialize_response(initialize)

        # Do not pipeline these before the validated initialize result. Strict
        # MCP servers are allowed to reject a client that does.
        _write_frame(process, {"jsonrpc": "2.0", "method": "notifications/initialized"})
        _write_frame(process, _request_frame(method, params))
        while True:
            response = next_protocol_frame(method)
            if "method" in response and "id" not in response:
                continue  # server notification during the request
            response_id = response.get("id")
            if isinstance(response_id, bool) or response_id != CALL_ID:
                raise _ClientProtocolError(f"MCP {method} returned a mismatched response id.")
            if response.get("jsonrpc") != "2.0" or not ({"result", "error"} & response.keys()):
                raise _ClientProtocolError(f"MCP {method} returned an invalid JSON-RPC response.")
            sys.stdout.buffer.write(
                json.dumps(response, separators=(",", ":")).encode("utf-8") + b"\n"
            )
            sys.stdout.buffer.flush()
            return 0
    except (_ClientProtocolError, json.JSONDecodeError, UnicodeError) as error:
        _client_error(str(error))
        return 70
    finally:
        if process is not None:
            if process.stdin is not None:
                try:
                    process.stdin.close()
                except OSError:
                    pass
            try:
                process.wait(timeout=CLIENT_TERMINATE_GRACE_SECONDS)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=CLIENT_TERMINATE_GRACE_SECONDS)
                except subprocess.TimeoutExpired:
                    process.kill()
                    try:
                        process.wait(timeout=CLIENT_TERMINATE_GRACE_SECONDS)
                    except subprocess.TimeoutExpired:
                        pass


def _client_program() -> bytes:
    """Serialize the fixed stdlib-only client into its confined child."""
    constants = {
        "PROTOCOL_VERSION": PROTOCOL_VERSION,
        "CLIENT_NAME": CLIENT_NAME,
        "INITIALIZE_ID": INITIALIZE_ID,
        "CALL_ID": CALL_ID,
        "MAX_CLIENT_CONFIG_BYTES": MAX_CLIENT_CONFIG_BYTES,
        "CLIENT_READ_CHUNK_BYTES": CLIENT_READ_CHUNK_BYTES,
        "CLIENT_QUEUE_DEPTH": CLIENT_QUEUE_DEPTH,
        "CLIENT_TERMINATE_GRACE_SECONDS": CLIENT_TERMINATE_GRACE_SECONDS,
        "ALLOWED_METHODS": ALLOWED_METHODS,
    }
    functions = (
        _ClientProtocolError,
        _initialize_frame,
        _request_frame,
        _validate_initialize_response,
        _read_exact,
        _write_frame,
        _client_error,
        _client_main,
    )
    source = [
        "from __future__ import annotations",
        "import json, os, queue, subprocess, sys, threading, time",
        "from collections import deque",
        "from typing import Any",
        *(f"{name}={value!r}" for name, value in constants.items()),
        *(inspect.getsource(function) for function in functions),
        "raise SystemExit(_client_main())",
    ]
    return "\n".join(source).encode("utf-8")


def build_request(payload: dict[str, Any]) -> McpRequest:
    """Validate an ``mcp_call`` payload into a launchable local request."""
    unknown_payload = sorted(str(key) for key in payload if str(key) not in ALLOWED_PAYLOAD_KEYS)
    if unknown_payload:
        raise InvalidTask(
            f"mcp_call accepts only {', '.join(ALLOWED_PAYLOAD_KEYS)}; refused unknown "
            f"field(s) {', '.join(unknown_payload)}."
        )
    # Names are validated here before a provider is consulted. Their values are
    # resolved later by CommandExecutor through the sealed task-env channel.
    requested_names(payload.get("env"))
    server = payload.get("server")
    if not isinstance(server, dict):
        raise InvalidTask("mcp_call.server must be a JSON object describing a local stdio server.")

    # Refuse the remote and credentialed shapes by name, before anything else,
    # so the failure message says *why* rather than "argv missing".
    present = {str(key).lower() for key in server}
    remote = sorted(present & set(REMOTE_TRANSPORT_KEYS))
    if remote:
        raise InvalidTask(
            f"mcp_call refuses remote MCP servers on a connected host (saw {', '.join(remote)}). "
            "Remote and authenticated MCP servers are managed by the control plane, which is "
            "where their credentials stay."
        )
    credentialed = sorted(present & set(CREDENTIAL_KEYS))
    if credentialed:
        raise InvalidTask(
            f"mcp_call refuses a server definition carrying credentials (saw "
            f"{', '.join(credentialed)}). A local server that needs a secret must receive it "
            "through the workspace environment, which the workspace owner controls explicitly."
        )

    unknown = sorted(present - set(ALLOWED_SERVER_KEYS))
    if unknown:
        raise InvalidTask(
            f"mcp_call.server accepts only {', '.join(ALLOWED_SERVER_KEYS)}; "
            f"refused unknown field(s) {', '.join(unknown)}."
        )

    argv = server.get("argv")
    if not isinstance(argv, list) or not argv or len(argv) > MAX_ARGV_ITEMS:
        raise InvalidTask("mcp_call.server.argv must be a non-empty list of at most 64 strings.")
    for item in argv:
        if not _valid_process_text(item, max_bytes=MAX_ARGV_ITEM_BYTES):
            raise InvalidTask(
                "mcp_call.server.argv entries must be non-empty control-free strings under 4 KiB."
            )

    # Without this the field checks above guard nothing: `argv` alone expresses
    # both refused shapes at once, e.g.
    #   ["npx", "mcp-remote", "https://x/mcp", "--header", "Authorization: ..."]
    # which is a remote server *and* a credential, smuggled past a key denylist
    # that only ever inspected key names. Rejecting an HTTP(S) URL in argv is
    # what makes "local only" true rather than merely stated.
    #
    # It is still not a proof. A secret can be a bare token with no recognisable
    # shape, and argv is visible to any local user through the process table
    # anyway — which is the standing reason not to pass secrets there. The
    # supported way to give a local server a secret is the workspace
    # environment, and that is enforced; this check just closes the obvious door.
    _validate_local_argv(argv)

    raw_cwd = server.get("cwd")
    if raw_cwd is not None and not isinstance(raw_cwd, str):
        raise InvalidTask("mcp_call.server.cwd must be a string when present.")
    if isinstance(raw_cwd, str) and not _valid_process_text(
        raw_cwd, max_bytes=MAX_ARGV_ITEM_BYTES, allow_empty=True
    ):
        raise InvalidTask("mcp_call.server.cwd must be a control-free path under 4 KiB.")
    cwd = "." if raw_cwd in (None, "") else str(raw_cwd)

    method = payload.get("method", "tools/list")
    if method not in ALLOWED_METHODS:
        raise InvalidTask(
            f"mcp_call.method must be one of {', '.join(ALLOWED_METHODS)}; "
            f"got {clean(str(method), 48)!r}."
        )
    params = payload.get("params")
    if params is None:
        params = {}
    if not isinstance(params, dict):
        raise InvalidTask("mcp_call.params must be a JSON object when present.")
    try:
        encoded = json.dumps(params, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, UnicodeError) as error:
        raise InvalidTask("mcp_call.params must be JSON-serialisable.") from error
    if len(encoded) > MAX_PARAMS_BYTES:
        raise InvalidTask(f"mcp_call.params must be at most {MAX_PARAMS_BYTES} bytes.")

    return McpRequest(
        argv=list(argv),
        cwd=cwd,
        method=method,
        params=params,
        timeout_seconds=bounded_int(
            payload.get("timeout_seconds"), 1, MAX_TIMEOUT_SECONDS, DEFAULT_TIMEOUT_SECONDS
        ),
        max_output_bytes=bounded_int(
            payload.get("max_output_bytes"), 1, MAX_OUTPUT_BYTES_CAP, DEFAULT_MAX_OUTPUT_BYTES
        ),
    )


def interpret_response(
    output: bytes, *, exit_code: int, truncated: bool, method: str
) -> Any:
    """Pick the answer frame out of the server's stdout.

    Servers interleave their own logging with protocol frames, and some write
    banners before the first response, so every line is tried and non-JSON ones
    are skipped rather than treated as a protocol violation.
    """
    from .executor import CommandOutcome

    answer: dict[str, Any] | None = None
    for line in output.splitlines():
        line = line.strip()
        if not line.startswith(b"{"):
            continue
        try:
            frame = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            continue
        if isinstance(frame, dict) and frame.get("id") == CALL_ID:
            answer = frame
            break

    if answer is None:
        return CommandOutcome(
            status="failed",
            output=output,
            exit_code=exit_code,
            truncated=truncated,
            message=(
                "The MCP server produced no response frame for this request."
                if not truncated
                else "The MCP server's response was truncated before a response frame appeared."
            ),
            extra={"mcp_method": method},
        )

    if "error" in answer:
        error = answer.get("error")
        message = error.get("message") if isinstance(error, dict) else None
        return CommandOutcome(
            status="failed",
            output=json.dumps(answer).encode("utf-8"),
            exit_code=exit_code,
            truncated=truncated,
            message=f"The MCP server returned an error: {clean(str(message or error))}",
            extra={"mcp_method": method, "mcp_error": True},
        )

    return CommandOutcome(
        status="succeeded",
        output=json.dumps(answer.get("result")).encode("utf-8"),
        exit_code=exit_code,
        truncated=truncated,
        extra={"mcp_method": method, "mcp_error": False},
    )
