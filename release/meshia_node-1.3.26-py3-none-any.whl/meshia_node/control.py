"""User-authorized Meshia control plane, shared by the CLI and stdio MCP.

Device enrollment remains separate from user OAuth: mounting a workspace must
never give its runtime the owner's account-wide credential. No automatic
mutation retries; refresh rotation is serialized across client processes.
"""
from __future__ import annotations

import base64
import hashlib
import http.server
import json
import math
import os
import secrets
import stat
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
from pathlib import Path
from typing import Any

from .client import SignedClient, validate_api_url
from .config import ConfigStore, Paths, file_lock
from .errors import MeshiaNodeError
from .identity import DeviceIdentity
from .http_pool import create_https_context
from .util import ensure_private_dir, write_private_file

PROTOCOL_VERSION = "2025-06-18"
MAX_BYTES = 8 * 1024 * 1024


class ControlError(MeshiaNodeError):
    code = "CONTROL_ERROR"


def message_receipt_matches(value: Any, workspace_id: str, message_id: str) -> bool:
    """Only the saved message row acknowledges a resumable transcript append."""
    if not isinstance(value, dict) or value.get("ok") is False:
        return False
    message = value.get("message")
    return (isinstance(message, dict)
            and message.get("id") == message_id.lower()
            and message.get("session_id") == workspace_id.lower())


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def origin(value: str) -> str:
    parts = urllib.parse.urlsplit(value)
    if parts.username or parts.password:
        raise ControlError("Meshia origins cannot contain credentials.")
    normalized = validate_api_url(value)
    return "https://meshia.io" if normalized == "https://run.meshia.io" else normalized


def request_json(url: str, *, body: Any = None, token: str | None = None,
                 form: bool = False, timeout: float = 35) -> Any:
    headers = {"Accept": "application/json, text/event-stream", "MCP-Protocol-Version": PROTOCOL_VERSION}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = None
    if body is not None:
        data = (urllib.parse.urlencode(body) if form else json.dumps(body)).encode()
        if len(data) > 4 * 1024 * 1024:
            raise ControlError("Request exceeds the 4 MiB limit.")
        headers["Content-Type"] = "application/x-www-form-urlencoded" if form else "application/json"
    try:
        with urllib.request.build_opener(
            NoRedirect(), urllib.request.HTTPSHandler(context=create_https_context())
        ).open(
            urllib.request.Request(url, data=data, headers=headers), timeout=timeout
        ) as response:
            raw = response.read(MAX_BYTES + 1)
    except urllib.error.HTTPError as error:
        # Error bodies/URLs can contain credentials or reflected input.
        raise ControlError(f"Meshia returned HTTP {error.code}. No operation was retried.") from None
    except (OSError, urllib.error.URLError, TimeoutError):
        raise ControlError("Meshia connection failed. Mutation outcome may be unknown; read back state before retrying.") from None
    if len(raw) > MAX_BYTES:
        raise ControlError("Meshia response exceeded the limit; use pagination.")
    try:
        return json.loads(raw) if raw else {}
    except (ValueError, UnicodeError):
        raise ControlError("Meshia returned an invalid JSON response.") from None


class ControlClient:
    def __init__(self, paths: Paths):
        self.paths = paths
        self.directory = paths.home / "control"
        self.credentials = self.directory / "oauth.json"
        self.lock = paths.locks_dir / "control-oauth.lock"
        self._thread_lock = threading.RLock()
        self._verifying_login = False

    def load(self) -> dict[str, Any]:
        if not self.credentials.exists():
            raise ControlError("Sign in first with meshia login.")
        # Never follow an OAuth store symlink or accept a world-readable token.
        if self.paths.home.is_symlink() or self.directory.is_symlink() or self.credentials.is_symlink():
            raise ControlError("Refusing a symlinked Meshia credential store.")
        info = self.credentials.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > 65536:
            raise ControlError("Invalid Meshia credential store.")
        if os.name != "nt" and (info.st_uid != os.getuid() or info.st_mode & 0o077):
            raise ControlError("Meshia credentials must be owned by you with permissions 0600.")
        directory_info = self.directory.stat()
        if os.name != "nt" and (directory_info.st_uid != os.getuid() or directory_info.st_mode & 0o077):
            raise ControlError("Meshia's credential directory must be owned by you with permissions 0700.")
        if os.name == "nt":
            ensure_private_dir(self.directory)
        try:
            descriptor = os.open(self.credentials, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
            with os.fdopen(descriptor, "r") as stream:
                value = json.loads(stream.read(65537))
            if not isinstance(value, dict) or not isinstance(value.get("origin"), str):
                raise ValueError()
            if any(not isinstance(value.get(key), str) or not value[key] for key in ("client_id", "access_token", "refresh_token")):
                raise ValueError()
            expiry = value.get("expires_at")
            if isinstance(expiry, bool) or not isinstance(expiry, (int, float)) or not math.isfinite(expiry):
                raise ValueError()
            value["origin"] = origin(value["origin"])
            if value.get("resource") != value["origin"] + "/api/mcp":
                raise ValueError()
            return value
        except (ValueError, TypeError, OSError):
            raise ControlError("Invalid Meshia credentials; run meshia login.") from None

    def save(self, value: dict[str, Any]) -> None:
        if self.paths.home.is_symlink() or self.directory.is_symlink() or self.credentials.is_symlink():
            raise ControlError("Refusing a symlinked Meshia credential store.")
        write_private_file(self.credentials, json.dumps(value).encode())

    @staticmethod
    def token_document(previous: dict[str, Any], reply: Any) -> dict[str, Any]:
        if not isinstance(reply, dict) or reply.get("token_type", "").lower() != "bearer":
            raise ControlError("Invalid OAuth token response.")
        for key in ("access_token", "refresh_token"):
            if not isinstance(reply.get(key), str) or not reply[key] or len(reply[key]) > 8192:
                raise ControlError("OAuth did not return a complete rotating token pair.")
        expires = reply.get("expires_in")
        if isinstance(expires, bool) or not isinstance(expires, (int, float)) or not math.isfinite(expires) or expires <= 0:
            raise ControlError("OAuth did not return a valid token expiry.")
        return {**previous, "access_token": reply["access_token"], "refresh_token": reply["refresh_token"],
                "expires_at": time.time() + expires, "refresh_pending": False}

    def authorized(self) -> dict[str, Any]:
        with self._thread_lock, file_lock(self.lock):
            value = self.load()
            if value.get("refresh_pending"):
                raise ControlError("A previous token rotation was interrupted. Run meshia login; the old refresh token will not be replayed.")
            if value.get("expires_at", 0) <= time.time() + 60:
                # A crash/timeout after rotation must not replay a consumed token.
                self.save({**value, "refresh_pending": True})
                reply = request_json(value["origin"] + "/api/oauth/token", form=True, body={
                    "grant_type": "refresh_token", "refresh_token": value["refresh_token"],
                    "client_id": value["client_id"], "resource": value["resource"],
                })
                value = self.token_document(value, reply)
                self.save(value)
            return self._link_device(value)

    def _link_device(self, value: dict[str, Any]) -> dict[str, Any]:
        """Bind an enrolled computer to its own OAuth grant, never a runtime token.

        Called under the OAuth lock. A stored receipt avoids a network round trip
        on each MCP call; generation changes require a new signed confirmation.
        """
        store = ConfigStore(self.paths)
        config = store.load()
        if self._verifying_login or config is None or origin(config.api_url) != value["origin"]:
            return value
        account_email = value.get("account_email")
        if config.account_email and isinstance(account_email, str) and config.account_email.lower() != account_email.lower():
            return value
        if config.lifecycle == "disconnected" and config.disconnect_reason not in (None, "USER_DISCONNECTED"):
            return value
        expected = {"host_id": config.host_id, "generation": config.generation}
        if value.get("device_binding") == expected:
            return value
        if not (self.paths.identity_dir / "device-key.pem").exists():
            raise ControlError("This device's signing identity is missing. Reconnect with a new token.")
        identity = DeviceIdentity.load_or_create(self.paths.identity_dir)
        receipt = SignedClient(store, identity).post_json(
            f"api/connected-hosts/{config.host_id}/account-connection",
            {"access_token": value["access_token"]},
        )
        if not isinstance(receipt, dict) or receipt.get("linked") is not True or any(
            receipt.get(key) != item for key, item in expected.items()
        ):
            raise ControlError("Meshia did not confirm this device's account connection.")
        value = {**value, "device_binding": expected}
        self.save(value)
        return value

    def link_device_if_present(self) -> None:
        """Adopt an existing installable's revocation binding after an update."""
        if self.credentials.exists():
            self.authorized()

    def forget_device_credentials(self, host_id: str) -> None:
        """Erase only credentials proved to belong to the revoked enrollment."""
        with self._thread_lock, file_lock(self.lock):
            if not self.credentials.exists():
                return
            value = self.load()
            binding = value.get("device_binding")
            if isinstance(binding, dict) and binding.get("host_id") == host_id:
                self.credentials.unlink()

    def rpc(self, method: str, params: dict | None = None, *, request_id: Any = None) -> dict:
        value = self.authorized()
        rpc_id = request_id if request_id is not None else str(uuid.uuid4())
        reply = request_json(value["resource"], token=value["access_token"], body={
            "jsonrpc": "2.0", "id": rpc_id, "method": method, "params": params or {},
        }, timeout=65)
        if not isinstance(reply, dict) or reply.get("jsonrpc") != "2.0" or reply.get("id") != rpc_id:
            raise ControlError("Invalid MCP response identity.")
        return reply

    def tool(self, name: str, arguments: dict | None = None) -> Any:
        reply = self.rpc("tools/call", {"name": name, "arguments": arguments or {}})
        if "error" in reply:
            raise ControlError(f"MCP rejected {name}; inspect its input schema with meshia tools.")
        result = reply.get("result", {})
        if not isinstance(result, dict):
            raise ControlError("MCP returned an invalid tool result.")
        value = result.get("structuredContent")
        if value is None:
            try:
                value = json.loads(result["content"][0]["text"])
            except (KeyError, IndexError, TypeError, ValueError):
                raise ControlError("MCP returned no structured tool result.") from None
        if result.get("isError"):
            # Useful structured tool errors are deliberately returned to callers;
            # credentials are never included in these canonical tool payloads.
            return {**value, "ok": False} if isinstance(value, dict) else {"ok": False}
        return value.get("result", value) if isinstance(value, dict) else value

    def login(self, api_url: str, *, open_browser: bool = True, timeout: float = 180) -> dict:
        base = origin(api_url)
        if self.credentials.exists():
            # Renewing a login must not abandon a live refresh family. A
            # failed revocation keeps the existing store intact for recovery.
            self.logout()
        resource = base + "/api/mcp"
        protected = request_json(base + "/.well-known/oauth-protected-resource")
        metadata = request_json(base + "/.well-known/oauth-authorization-server")
        if not isinstance(protected, dict) or not isinstance(metadata, dict):
            raise ControlError("Invalid OAuth discovery document.")
        if protected.get("resource") != resource or base not in protected.get("authorization_servers", []):
            raise ControlError("OAuth resource discovery did not match this Meshia server.")
        expected = {"authorization_endpoint": "/oauth/authorize", "token_endpoint": "/api/oauth/token",
                    "registration_endpoint": "/api/oauth/register"}
        if metadata.get("issuer") != base or any(metadata.get(k) != base + v for k, v in expected.items()):
            raise ControlError("OAuth discovery returned an unexpected endpoint.")
        if "S256" not in metadata.get("code_challenge_methods_supported", []):
            raise ControlError("Meshia OAuth must support PKCE S256.")
        state, verifier = secrets.token_urlsafe(32), secrets.token_urlsafe(48)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        accepted: dict[str, str] = {}

        class Callback(http.server.BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def do_GET(self):
                parsed = urllib.parse.urlsplit(self.path)
                query = urllib.parse.parse_qs(parsed.query)
                valid = (self.headers.get("Host") == f"127.0.0.1:{self.server.server_port}"
                         and parsed.path == "/callback" and query.get("state") == [state]
                         and not accepted and (len(query.get("code", [])) == 1 or "error" in query))
                if valid:
                    accepted.update({"code": query.get("code", [""])[0], "error": query.get("error", [""])[0]})
                self.send_response(200 if valid else 400)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.end_headers()
                self.wfile.write(b"Return to your terminal to finish connecting Meshia." if valid else b"Invalid Meshia callback.")

        class CallbackServer(http.server.HTTPServer):
            def get_request(self):
                connection, address = super().get_request()
                connection.settimeout(2)
                return connection, address

        with self._thread_lock, file_lock(self.lock), CallbackServer(("127.0.0.1", 0), Callback) as server:
            server.timeout = 0.5
            redirect = f"http://127.0.0.1:{server.server_port}/callback"
            client = request_json(metadata["registration_endpoint"], body={
                "client_name": "Meshia CLI", "redirect_uris": [redirect], "token_endpoint_auth_method": "none",
                "grant_types": ["authorization_code", "refresh_token"], "response_types": ["code"],
            })
            if not isinstance(client, dict) or not isinstance(client.get("client_id"), str):
                raise ControlError("OAuth registration did not return a client identity.")
            url = metadata["authorization_endpoint"] + "?" + urllib.parse.urlencode({
                "response_type": "code", "client_id": client["client_id"], "redirect_uri": redirect,
                "scope": "meshia:control", "resource": resource, "state": state,
                "code_challenge": challenge, "code_challenge_method": "S256",
            })
            print(f"Open Meshia to approve this computer:\n{url}", file=sys.stderr)
            if open_browser:
                webbrowser.open(url)
            deadline = time.monotonic() + timeout
            while not accepted and time.monotonic() < deadline:
                server.handle_request()
            if not accepted.get("code") or accepted.get("error"):
                raise ControlError("Meshia login was cancelled or timed out.")
            reply = request_json(metadata["token_endpoint"], form=True, body={
                "grant_type": "authorization_code", "code": accepted["code"], "code_verifier": verifier,
                "client_id": client["client_id"], "redirect_uri": redirect, "resource": resource,
            })
            self.save(self.token_document({"origin": base, "resource": resource, "client_id": client["client_id"]}, reply))
        self._verifying_login = True
        try:
            account = self.tool("meshia_account_get")
        finally:
            self._verifying_login = False
        if not isinstance(account, dict) or account.get("ok") is False or not isinstance(account.get("email"), str):
            raise ControlError("OAuth completed but account verification failed.")
        with self._thread_lock, file_lock(self.lock):
            self.save({**self.load(), "account_email": account["email"].lower()})
        self.link_device_if_present()
        return {"connected": True, "account": account, "next": "meshia projects"}

    def logout(self) -> dict:
        with self._thread_lock, file_lock(self.lock):
            value = self.load()
            request_json(value["origin"] + "/api/oauth/revoke", form=True,
                         body={"token": value["refresh_token"], "token_type_hint": "refresh_token"})
            self.credentials.unlink()
        return {"connected": False, "revoked": True, "mount": "Device enrollment is separate; use meshia disconnect to stop it."}

    def status(self) -> dict:
        if not self.credentials.exists():
            return {"state": "signed_out", "next": "meshia login"}
        try:
            value = self.load()
            state = "login_required" if value.get("refresh_pending") else "saved"
            return {"state": state, "origin": value["origin"], "expires_at": value.get("expires_at"),
                    "verified_live": False, "next": "meshia account"}
        except ControlError:
            return {"state": "invalid", "next": "meshia login"}
