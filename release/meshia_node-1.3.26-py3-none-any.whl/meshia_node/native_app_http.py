"""Bounded, single-request HTTP response state for an owned native app.

The opaque ID selects private state; it does not grant access. The app lane
checks its exact current authority before every open/read/close operation.
"""
from __future__ import annotations

import base64
import http.client
import socket
import threading
import time

from .errors import MeshiaNodeError

MAX_CHUNK_BYTES = 256 * 1024
MAX_RESPONSE_BYTES = 64 * 1024 * 1024
HEADER_SECONDS = 10
FINITE_SECONDS = 240
SSE_SECONDS = 240
IDLE_SECONDS = 30
READ_SECONDS = 1
OPEN_READ_SECONDS = .1
TOMBSTONE_SECONDS = 60


class AppError(MeshiaNodeError):
    def __init__(self, code: str, message: str, status: int = 409):
        super().__init__(message)
        self.code, self.status = code, status


class AppResponse:
    def __init__(self, stream_id, app, fingerprint):
        self.stream_id, self.app, self.fingerprint = stream_id, app, fingerprint
        self.created = self.touched = time.monotonic()
        self.deadline = self.created + HEADER_SECONDS
        self.closed_at = None
        self.connection = None
        self.upload = None
        self.upload_digest = None
        self.socket = None
        self.response = None
        self.reader = None
        self.ready = threading.Event()
        self.condition = threading.Condition()
        self.read_lock = threading.Lock()
        self.io_lock = threading.Lock()
        self.buffer = bytearray()
        self.total = self.offset = self.sequence = 0
        self.last = None
        self.last_size = None
        self.open_result = None
        self.eof = False
        self.bodyless = False
        self.finished = False
        self.closed = False
        self.error = None
        self.status, self.headers, self.set_cookies, self.sse = None, {}, [], False

    def _check(self):
        if self.closed:
            raise self.error or AppError("APP_STREAM_CLOSED", "This app response is closed.", 410)
        if self.app.stopped.is_set() or time.monotonic() >= self.app.deadline:
            raise AppError("APP_AUTHORITY_CHANGED", "App response authority expired.", 403)

    def set_connection(self, connection):
        with self.condition:
            self._check()
            self.connection = connection

    def publish(self, response, headers, *, head=False, set_cookies=()):
        with self.condition:
            self._check()
            self.response, self.status, self.headers = response, response.status, headers
            self.set_cookies = list(set_cookies)
            self.sse = headers.get("content-type", "").split(";", 1)[0].strip().lower() == "text/event-stream"
            self.deadline = self.created + (SSE_SECONDS if self.sse else FINITE_SECONDS)
            self.bodyless = head or response.status in (204, 205, 304)
            self.eof = self.bodyless
            self.ready.set()
            if self.eof:
                self._disconnect()
                return
            # An independent owner timer enforces absolute/idle deadlines.
            # Socket inactivity timeouts cannot safely resume HTTPResponse.
            if self.socket is not None:
                self.socket.settimeout(None)
            self.reader = threading.Thread(target=self._produce, name="meshia-app-response", daemon=True)
            self.reader.start()

    def metadata(self):
        if not self.ready.wait(HEADER_SECONDS):
            raise AppError("APP_HTTP_TIMEOUT", "App response headers timed out.", 504)
        with self.read_lock, self.condition:
            self._check()
            self.touched = time.monotonic()
            if self.open_result is not None:
                return dict(self.open_result)
            result = {"schema": "meshia.connected_host_app_http_result.v1", "operation": "open",
                    "status": self.status, "headers": dict(self.headers), "set_cookies": list(self.set_cookies),
                    "stream_id": self.stream_id,
                    "instance_id": self.app.instance_id, "sequence": 0, "offset": 0,
                    "next_sequence": 0, "next_offset": 0, "body_base64": "", "eof": False}
            # Most app assets fit one chunk. Give the existing bounded producer
            # a short opportunity to include them without another queue trip.
            # Event streams must publish their headers without waiting for data.
            if not self.sse or self.bodyless:
                wait_until = time.monotonic() + OPEN_READ_SECONDS
                while not self.closed and not self.eof and len(self.buffer) < MAX_CHUNK_BYTES:
                    remaining = wait_until - time.monotonic()
                    if remaining <= 0:
                        break
                    self.condition.wait(remaining)
                self._check()
                if self.buffer or self.eof:
                    chunk = self._take_chunk(0, MAX_CHUNK_BYTES)
                    result.update({key: chunk[key] for key in ("body_base64", "next_sequence", "next_offset", "eof")})
            self.open_result = result
            return dict(result)

    def _produce(self):
        try:
            while True:
                with self.condition:
                    self.condition.wait_for(lambda: self.closed or len(self.buffer) < MAX_CHUNK_BYTES)
                    if self.closed:
                        return
                    capacity = min(65536, MAX_CHUNK_BYTES - len(self.buffer), MAX_RESPONSE_BYTES - self.total + 1)
                with self.io_lock:
                    chunk = self.response.read1(capacity)
                with self.condition:
                    if self.closed:
                        return
                    if not chunk:
                        if self.response.length not in (None, 0):
                            raise AppError("APP_HTTP_UNAVAILABLE", "The app response ended before its declared length.", 502)
                        self.eof = True
                        self.condition.notify_all()
                        return
                    if self.total + len(chunk) > MAX_RESPONSE_BYTES:
                        raise AppError("APP_RESPONSE_TOO_LARGE", "App response exceeds the 64 MiB transfer limit.", 413)
                    self.total += len(chunk)
                    self.buffer.extend(chunk)
                    if self.response.length == 0:
                        self.eof = True
                    self.condition.notify_all()
                    if self.eof:
                        return
        except AppError as error:
            self.close(error)
        except (OSError, ValueError, http.client.HTTPException):
            self.close(AppError("APP_HTTP_UNAVAILABLE", "The app response stream ended unexpectedly.", 502))
        finally:
            self._disconnect()

    def read(self, sequence, max_bytes):
        if type(sequence) is not int or sequence < 0 or type(max_bytes) is not int or not 1 <= max_bytes <= MAX_CHUNK_BYTES:
            raise AppError("APP_REQUEST_INVALID", "Invalid app stream sequence or chunk bound.", 400)
        # Serializes readers while condition.wait releases the producer lock.
        with self.read_lock, self.condition:
            self._check()
            if not self.ready.is_set() or self.open_result is None:
                raise AppError("APP_STREAM_NOT_READY", "Wait for the app response headers before reading.")
            self.touched = time.monotonic()
            if self.last is not None and sequence == self.sequence - 1:
                if max_bytes != self.last_size:
                    raise AppError("APP_STREAM_SEQUENCE_INVALID", "A retried chunk must preserve its byte bound.")
                return dict(self.last)
            if sequence != self.sequence:
                raise AppError("APP_STREAM_SEQUENCE_INVALID", "Read the next app stream sequence or replay its last chunk.")
            if self.last is not None and self.last["eof"]:
                raise AppError("APP_STREAM_CLOSED", "The app response has reached EOF.", 410)
            wait_until = time.monotonic() + READ_SECONDS
            while not self.closed and not self.eof and (not self.buffer if self.sse else len(self.buffer) < max_bytes):
                remaining = wait_until - time.monotonic()
                if remaining <= 0:
                    break
                self.condition.wait(remaining)
            self._check()
            return self._take_chunk(sequence, max_bytes)

    def _take_chunk(self, sequence, max_bytes):
        # The caller holds both the consumer and producer-state locks.
        data = bytes(self.buffer[:max_bytes])
        del self.buffer[:len(data)]
        result = {"schema": "meshia.connected_host_app_http_result.v1", "operation": "read",
                      "stream_id": self.stream_id, "instance_id": self.app.instance_id,
                      "sequence": sequence, "next_sequence": sequence + 1,
                      "offset": self.offset, "next_offset": self.offset + len(data),
                      "body_base64": base64.b64encode(data).decode("ascii"),
                      "eof": self.eof and not self.buffer}
        self.offset += len(data)
        self.sequence += 1
        self.last, self.last_size = result, max_bytes
        if result["eof"]:
            # Keep small exact replay receipts for the tombstone window while
            # releasing the live-stream admission slot and upstream socket.
            self.finished, self.closed_at = True, time.monotonic()
            self._disconnect()
        self.condition.notify_all()
        return dict(result)

    def _disconnect(self):
        connection = self.connection
        if connection is not None:
            candidate = self.socket
            if candidate is not None:
                try:
                    candidate.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
        with self.io_lock:
            if connection is not None:
                connection.close()
            response = self.response
            if response is not None:
                # HTTPConnection detaches close-delimited responses. Their file
                # retains the descriptor after connection.close(). Never race
                # HTTPResponse's internal EOF close against a producer read.
                response.close()

    def close(self, error=None):
        with self.condition:
            if not self.closed:
                self.closed, self.closed_at, self.error = True, time.monotonic(), error
                self.buffer.clear()
                self.last = None
                self.open_result = None
                self.headers, self.set_cookies = {}, []
                self.ready.set()
                self.condition.notify_all()
        # Header parsing may have completed concurrently with cancellation and
        # attached a response after the first close. Always release its handles.
        if self.upload is not None:
            self.upload.close(error)
        self._disconnect()

    def expire(self, now):
        if not self.closed and not self.finished and (now >= self.deadline or now - self.touched >= IDLE_SECONDS):
            self.close(AppError("APP_HTTP_TIMEOUT", "App response exceeded its transfer or idle deadline.", 504))
