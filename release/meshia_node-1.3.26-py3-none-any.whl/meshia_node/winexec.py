"""Bounded subprocess execution on Windows, with optional low-IL confinement.

The POSIX executor forks, applies Landlock in ``preexec_fn``, and kills the
process *group* on timeout. None of those exist on Windows, so this module is
the platform's own spawn path with the same contract as
``executor.run_bounded_subprocess``:

* the child (and everything it spawns) is placed in a **Job Object** created
  with ``KILL_ON_JOB_CLOSE`` — ``TerminateJobObject`` on timeout is the
  ``killpg`` analog, and a leaked handle still reaps the tree;
* when ``confined_root`` is set (`limited` access), the child runs under a
  **low-integrity token** (:mod:`meshia_node.winconfine`): mandatory
  no-write-up blocks writes to everything except the Low-labeled workspace
  tree, and the label is inherited by every descendant process' file access —
  the Landlock parity point. ``%TEMP%`` is pointed at a scratch directory
  inside the workspace so children that need a writable temp still work;
* stdio flows over inheritable pipe handles pumped by bounded reader threads,
  byte-for-byte the same truncation semantics as the POSIX path.

The spawn uses ``CreateProcessW`` (unconfined) or ``CreateProcessAsUserW``
with the lowered duplicate of our own token (confined; assigning a lowered
duplicate of the caller's own token requires no privilege). The process starts
``CREATE_SUSPENDED``, is assigned to the job, and only then resumes, so no
child ever runs outside the job.
"""

from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import threading
import time
import uuid
from typing import Any

if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
    import msvcrt
else:  # the pure helpers (environment_block) stay importable everywhere
    msvcrt = None  # type: ignore[assignment]

from .errors import AccessRefused, InvalidTask
from .winconfine import WinconfineUnavailable, build_low_integrity_token

MARKER = "meshia-winexec"
TIMEOUT_EXIT_CODE = 124

CREATE_SUSPENDED = 0x00000004
CREATE_UNICODE_ENVIRONMENT = 0x00000400
CREATE_NO_WINDOW = 0x08000000
EXTENDED_STARTUPINFO_PRESENT = 0x00080000
PROC_THREAD_ATTRIBUTE_HANDLE_LIST = 0x00020002
STARTF_USESTDHANDLES = 0x00000100
HANDLE_FLAG_INHERIT = 0x00000001
WAIT_OBJECT_0 = 0x00000000
WAIT_TIMEOUT = 0x00000102
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9


class _StartupInfo(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("lpReserved", ctypes.c_void_p),
        ("lpDesktop", ctypes.c_void_p),
        ("lpTitle", ctypes.c_void_p),
        ("dwX", ctypes.c_ulong),
        ("dwY", ctypes.c_ulong),
        ("dwXSize", ctypes.c_ulong),
        ("dwYSize", ctypes.c_ulong),
        ("dwXCountChars", ctypes.c_ulong),
        ("dwYCountChars", ctypes.c_ulong),
        ("dwFillAttribute", ctypes.c_ulong),
        ("dwFlags", ctypes.c_ulong),
        ("wShowWindow", ctypes.c_ushort),
        ("cbReserved2", ctypes.c_ushort),
        ("lpReserved2", ctypes.c_void_p),
        ("hStdInput", ctypes.c_void_p),
        ("hStdOutput", ctypes.c_void_p),
        ("hStdError", ctypes.c_void_p),
    ]


class _ProcessInformation(ctypes.Structure):
    _fields_ = [
        ("hProcess", ctypes.c_void_p),
        ("hThread", ctypes.c_void_p),
        ("dwProcessId", ctypes.c_ulong),
        ("dwThreadId", ctypes.c_ulong),
    ]


class _StartupInfoEx(ctypes.Structure):
    _fields_ = [("StartupInfo", _StartupInfo), ("lpAttributeList", ctypes.c_void_p)]


class _IoCounters(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_uint64),
        ("WriteOperationCount", ctypes.c_uint64),
        ("OtherOperationCount", ctypes.c_uint64),
        ("ReadTransferCount", ctypes.c_uint64),
        ("WriteTransferCount", ctypes.c_uint64),
        ("OtherTransferCount", ctypes.c_uint64),
    ]


class _JobBasicLimits(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_int64),
        ("PerJobUserTimeLimit", ctypes.c_int64),
        ("LimitFlags", ctypes.c_ulong),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", ctypes.c_ulong),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", ctypes.c_ulong),
        ("SchedulingClass", ctypes.c_ulong),
    ]


class _JobExtendedLimits(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", _JobBasicLimits),
        ("IoInfo", _IoCounters),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]



def _declare_win32(kernel32, advapi32) -> None:
    """Pin restype/argtypes: ctypes' 32-bit default truncates 64-bit HANDLEs.

    CreateJobObjectW *returns* a HANDLE, so leaving restype at the default int
    silently truncates it and every later job call operates on a bogus handle.
    See meshia_node.winconfine._declare_win32 for the failure this class of bug
    produced on a live Windows host.
    """
    H = ctypes.c_void_p
    kernel32.CreateJobObjectW.restype = H
    kernel32.CreateJobObjectW.argtypes = [H, ctypes.c_wchar_p]
    kernel32.SetInformationJobObject.argtypes = [H, ctypes.c_int, H, ctypes.c_ulong]
    kernel32.AssignProcessToJobObject.argtypes = [H, H]
    kernel32.TerminateJobObject.argtypes = [H, ctypes.c_uint]
    kernel32.TerminateProcess.argtypes = [H, ctypes.c_uint]
    kernel32.ResumeThread.argtypes = [H]
    kernel32.WaitForSingleObject.restype = ctypes.c_ulong
    kernel32.WaitForSingleObject.argtypes = [H, ctypes.c_ulong]
    kernel32.GetExitCodeProcess.argtypes = [H, ctypes.POINTER(ctypes.c_ulong)]
    kernel32.CloseHandle.argtypes = [H]
    kernel32.SetHandleInformation.argtypes = [H, ctypes.c_ulong, ctypes.c_ulong]
    kernel32.InitializeProcThreadAttributeList.argtypes = [
        H, ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(ctypes.c_size_t)
    ]
    kernel32.UpdateProcThreadAttribute.argtypes = [
        H, ctypes.c_ulong, ctypes.c_size_t, H, ctypes.c_size_t, H, H
    ]
    kernel32.DeleteProcThreadAttributeList.argtypes = [H]
    kernel32.DeleteProcThreadAttributeList.restype = None
    process_arguments = [ctypes.c_wchar_p, ctypes.c_wchar_p, H, H,
                         ctypes.c_int, ctypes.c_ulong, H, ctypes.c_wchar_p, H, H]
    kernel32.CreateProcessW.argtypes = process_arguments
    advapi32.CreateProcessAsUserW.argtypes = [H, *process_arguments]
    for create in (kernel32.CreateProcessW, advapi32.CreateProcessAsUserW):
        create.restype = ctypes.c_int


def environment_block(env: dict[str, str]) -> str:
    """A ``CREATE_UNICODE_ENVIRONMENT`` block: sorted ``k=v`` pairs, NUL-joined.

    Windows convention sorts the block case-insensitively; a missing trailing
    double-NUL is the classic corruption, so the terminator is explicit. Pure
    (no Windows APIs) and therefore unit-testable on any platform.
    """
    for key, value in env.items():
        if "\0" in key or "\0" in value or "=" in key or not key:
            raise InvalidTask(f"{MARKER}: environment entries must be NUL-free with plain names")
    pairs = sorted(env.items(), key=lambda item: item[0].upper())
    return "".join(f"{key}={value}\0" for key, value in pairs) + "\0"


def _bounded_reader(stream: Any, limit: int, sink: dict[str, Any], key: str) -> None:
    collected = bytearray()
    overflow = False
    while True:
        chunk = stream.read(65536)
        if not chunk:
            break
        remaining = limit - len(collected)
        if remaining > 0:
            collected += chunk[:remaining]
        if len(chunk) > max(remaining, 0):
            overflow = True
    sink[key] = (bytes(collected), overflow)


def _inheritable_pipe(kernel32: Any, child_end: str) -> tuple[int, int]:
    """An anonymous pipe as (parent_fd, child_handle); only the child end inherits."""
    read_fd, write_fd = os.pipe()  # non-inheritable on Windows by default
    if child_end == "write":
        parent_fd, child_fd = read_fd, write_fd
    else:
        parent_fd, child_fd = write_fd, read_fd
    child_handle = msvcrt.get_osfhandle(child_fd)
    if not kernel32.SetHandleInformation(
        ctypes.c_void_p(child_handle), HANDLE_FLAG_INHERIT, HANDLE_FLAG_INHERIT
    ):
        os.close(read_fd)
        os.close(write_fd)
        raise InvalidTask(f"{MARKER}: SetHandleInformation failed ({ctypes.get_last_error()})")
    return parent_fd, child_fd


def _write_stdin(descriptor: int, data: bytes) -> None:
    """The coordinator must remain able to kill a child that never reads stdin."""
    try:
        remaining = memoryview(data)
        while remaining:
            written = os.write(descriptor, remaining[:65536])
            if written <= 0:
                break
            remaining = remaining[written:]
    except OSError:
        pass
    finally:
        os.close(descriptor)


def _wait_command(kernel32: Any, process_handle: Any, job: Any,
                  timeout_seconds: float | None, cancel_event: threading.Event | None) -> tuple[bool, bool]:
    deadline = float("inf") if timeout_seconds is None else time.monotonic() + timeout_seconds
    while True:
        cancelled = cancel_event is not None and cancel_event.is_set()
        remaining = deadline - time.monotonic()
        if cancelled or remaining <= 0:
            kernel32.TerminateJobObject(job, TIMEOUT_EXIT_CODE)
            kernel32.WaitForSingleObject(process_handle, 5000)
            return not cancelled, cancelled
        wait_ms = 100 if timeout_seconds is None else max(1, min(100, int(remaining * 1000)))
        waited = kernel32.WaitForSingleObject(process_handle, wait_ms)
        if waited == 0:
            return False, False
        if waited != WAIT_TIMEOUT:
            raise InvalidTask("The command process wait failed.")


def run_bounded_subprocess(
    argv: list[str],
    *,
    cwd: str,
    env: dict[str, str],
    timeout_seconds: int | None,
    max_output_bytes: int,
    stdin: bytes | None = None,
    confined_root: str | None = None,
    cancel_event: threading.Event | None = None,
    process_owner: Any = None,
) -> tuple[bytes, int, bool, bool]:
    """Windows implementation of the executor's bounded-subprocess contract."""
    if timeout_seconds is None and (process_owner is None or cancel_event is None):
        raise InvalidTask("A renewable app requires retained process ownership and cancellation.")
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)  # type: ignore[attr-defined]
    _declare_win32(kernel32, advapi32)

    child_env = dict(env)
    scratch: str | None = None
    if confined_root is not None:
        # A low-IL child cannot write the system %TEMP% (Medium label). Point it
        # at a scratch directory inside the workspace, which carries the
        # inheritable Low label, so temp-hungry tools keep working confined.
        scratch = os.path.join(confined_root, f".meshia-exec-tmp-{uuid.uuid4().hex}")
        os.makedirs(scratch, exist_ok=True)
        child_env["TEMP"] = scratch
        child_env["TMP"] = scratch

    token: ctypes.c_void_p | None = None
    job: ctypes.c_void_p | None = None
    process = _ProcessInformation()
    attribute_list = None
    parent_fds: list[int] = []
    child_fds: list[int] = []
    try:
        if confined_root is not None:
            try:
                token = build_low_integrity_token()
            except WinconfineUnavailable as error:
                raise AccessRefused(f"exec confinement unavailable ({error})") from error

        stdout_fd, stdout_child = _inheritable_pipe(kernel32, "write")
        stderr_fd, stderr_child = _inheritable_pipe(kernel32, "write")
        stdin_fd, stdin_child = _inheritable_pipe(kernel32, "read")
        parent_fds = [stdout_fd, stderr_fd, stdin_fd]
        child_fds = [stdout_child, stderr_child, stdin_child]

        startup = _StartupInfoEx()
        startup.StartupInfo.cb = ctypes.sizeof(startup)
        startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES
        startup.StartupInfo.hStdOutput = msvcrt.get_osfhandle(stdout_child)
        startup.StartupInfo.hStdError = msvcrt.get_osfhandle(stderr_child)
        startup.StartupInfo.hStdInput = msvcrt.get_osfhandle(stdin_child)
        # Concurrent launches have other inheritable pipe ends open in this
        # process. Inheriting all of them lets B hold A's output open after A
        # exits, withholding EOF and losing its result at the bounded join.
        # Give each command only its own stdio, including the legacy token path.
        handles = (ctypes.c_void_p * 3)(
            startup.StartupInfo.hStdInput, startup.StartupInfo.hStdOutput,
            startup.StartupInfo.hStdError,
        )
        size = ctypes.c_size_t()
        kernel32.InitializeProcThreadAttributeList(None, 1, 0, ctypes.byref(size))
        attributes = ctypes.create_string_buffer(size.value)
        if not kernel32.InitializeProcThreadAttributeList(attributes, 1, 0, ctypes.byref(size)):
            raise InvalidTask(f"{MARKER}: initialize stdio policy failed ({ctypes.get_last_error()})")
        attribute_list = attributes
        if not kernel32.UpdateProcThreadAttribute(
            attribute_list, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST, ctypes.byref(handles),
            ctypes.sizeof(handles), None, None,
        ):
            raise InvalidTask(f"{MARKER}: isolate stdio handles failed ({ctypes.get_last_error()})")
        startup.lpAttributeList = ctypes.cast(attribute_list, ctypes.c_void_p)

        command_line = ctypes.create_unicode_buffer(subprocess.list2cmdline(argv))
        block = ctypes.create_unicode_buffer(environment_block(child_env))
        flags = (CREATE_SUSPENDED | CREATE_UNICODE_ENVIRONMENT | CREATE_NO_WINDOW
                 | EXTENDED_STARTUPINFO_PRESENT)

        if token is not None:
            created = advapi32.CreateProcessAsUserW(
                token, None, command_line, None, None, True, flags, block,
                ctypes.c_wchar_p(cwd), ctypes.byref(startup), ctypes.byref(process),
            )
        else:
            created = kernel32.CreateProcessW(
                None, command_line, None, None, True, flags, block,
                ctypes.c_wchar_p(cwd), ctypes.byref(startup), ctypes.byref(process),
            )
        if not created:
            raise InvalidTask(
                f"The command could not be started: CreateProcess failed "
                f"({ctypes.get_last_error()})"
            )

        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            _terminate(kernel32, process, None)
            raise InvalidTask(f"{MARKER}: CreateJobObjectW failed ({ctypes.get_last_error()})")
        limits = _JobExtendedLimits()
        limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not kernel32.SetInformationJobObject(
            job, JOB_OBJECT_EXTENDED_LIMIT_INFORMATION, ctypes.byref(limits), ctypes.sizeof(limits)
        ) or not kernel32.AssignProcessToJobObject(job, process.hProcess):
            _terminate(kernel32, process, job)
            raise InvalidTask(f"{MARKER}: job containment failed ({ctypes.get_last_error()})")
        if process_owner is not None:
            process_owner.on_started(process, job_handle=job)
        kernel32.ResumeThread(process.hThread)

        # Parent must drop the child ends or EOF never reaches the readers.
        for descriptor in child_fds:
            os.close(descriptor)
        child_fds = []

        sink: dict[str, Any] = {}
        readers = [
            threading.Thread(
                target=_bounded_reader,
                args=(os.fdopen(stdout_fd, "rb", closefd=True), max_output_bytes, sink, "out"),
            ),
            threading.Thread(
                target=_bounded_reader,
                args=(os.fdopen(stderr_fd, "rb", closefd=True), max_output_bytes, sink, "err"),
            ),
        ]
        parent_fds = [stdin_fd]  # the reader fdopens own stdout/stderr now
        for reader in readers:
            reader.daemon = True
            reader.start()
        writer = None
        if stdin:
            writer = threading.Thread(target=_write_stdin, args=(stdin_fd, stdin),
                                      name="meshia-command-stdin", daemon=True)
            writer.start()
        else:
            os.close(stdin_fd)
        parent_fds = []  # the writer owns stdin until it closes, including errors

        timed_out, cancelled = _wait_command(kernel32, process.hProcess, job,
                                             timeout_seconds, cancel_event)
        # KILL_ON_JOB_CLOSE also releases pipes held by descendants after a
        # normal parent exit. Close before joining the pipe threads.
        if process_owner is not None:
            process_owner.close()
        kernel32.CloseHandle(job)
        job = None
        join_deadline = time.monotonic() + 5.0
        for reader in [*readers, *([writer] if writer is not None else [])]:
            reader.join(timeout=max(0.0, join_deadline - time.monotonic()))
        if cancelled:
            raise InvalidTask("The command was cancelled because the node is shutting down.")

        exit_code = ctypes.c_ulong(0)
        if not kernel32.GetExitCodeProcess(process.hProcess, ctypes.byref(exit_code)):
            exit_code.value = 0xFFFFFFFF
        code = ctypes.c_int32(exit_code.value).value  # present DWORD codes as signed

        out, out_overflow = sink.get("out", (b"", False))
        err, err_overflow = sink.get("err", (b"", False))
        combined = (out + err)[:max_output_bytes]
        truncated = out_overflow or err_overflow or len(out) + len(err) > max_output_bytes
        return combined, code, truncated, timed_out
    finally:
        if process_owner is not None:
            process_owner.close()
        if attribute_list is not None:
            kernel32.DeleteProcThreadAttributeList(attribute_list)
        for descriptor in (*parent_fds, *child_fds):
            try:
                os.close(descriptor)
            except OSError:
                pass
        for handle in (process.hThread, process.hProcess, job, token):
            if handle:
                kernel32.CloseHandle(handle)
        if scratch is not None:
            shutil.rmtree(scratch, ignore_errors=True)


def _terminate(kernel32: Any, process: _ProcessInformation, job: ctypes.c_void_p | None) -> None:
    if job:
        kernel32.TerminateJobObject(job, TIMEOUT_EXIT_CODE)
    elif process.hProcess:
        kernel32.TerminateProcess(process.hProcess, TIMEOUT_EXIT_CODE)


__all__ = ["MARKER", "TIMEOUT_EXIT_CODE", "environment_block", "run_bounded_subprocess"]
