"""Short-lived native directory watches for externally changed SMB names.

FUSE invalidation breaks file leases but does not clear macOS's negative name
cache. A vnode watch asks smbfs to refresh the changed directory. Do this off
the FUSE callback thread, without changing files or global mount/cache options.
"""
from __future__ import annotations

import os
import errno
from pathlib import Path
import select
import threading
import time


class NativeDirectoryWatch:
    MAX_DIRECTORIES = 128
    WATCH_SECONDS = 12.0

    def __init__(self, mount_point: Path):
        self.mount_point = mount_point
        self._lock = threading.Lock()
        self._pending: dict[str, None] = {}
        self._wake = threading.Event()
        self._closed = False
        self._thread: threading.Thread | None = None

    def changed(self, path: str) -> None:
        if not hasattr(select, "kqueue"):
            return
        if not path.startswith('/') or '\0' in path:
            return
        parent = path.rsplit('/', 1)[0]
        if any(part in ('.', '..') for part in parent.split('/')):
            return
        with self._lock:
            if self._closed:
                return
            if parent not in self._pending and len(self._pending) >= self.MAX_DIRECTORIES:
                self._pending.pop(next(iter(self._pending)))
            self._pending[parent] = None
            if self._thread is None:
                self._thread = threading.Thread(target=self._run, name='meshia-directory-watch', daemon=True)
                self._thread.start()
        self._wake.set()

    def _open(self, path: str) -> int:
        required = ("O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC")
        if not all(hasattr(os, name) for name in required):
            raise OSError(errno.ENOTSUP, "Native directory watches require POSIX directory handles")
        # Never drop no-follow or directory validation on an unsupported OS.
        flags = os.O_RDONLY
        for name in required:
            flags |= getattr(os, name)
        descriptor = os.open(self.mount_point, flags)
        try:
            for part in path.strip('/').split('/') if path.strip('/') else ():
                child = os.open(part, flags, dir_fd=descriptor)
                os.close(descriptor)
                descriptor = child
            return descriptor
        except BaseException:
            os.close(descriptor)
            raise

    def _run(self) -> None:
        watches: dict[str, tuple[int, float]] = {}
        queue = select.kqueue()
        try:
            while True:
                self._wake.wait(.25)
                self._wake.clear()
                with self._lock:
                    if self._closed:
                        return
                    pending, self._pending = self._pending, {}
                now = time.monotonic()
                for path in pending:
                    with self._lock:
                        if self._closed:
                            return
                    if path in watches:
                        watches[path] = (watches[path][0], now + self.WATCH_SECONDS)
                        continue
                    if len(watches) >= self.MAX_DIRECTORIES:
                        oldest = min(watches, key=lambda key: watches[key][1])
                        os.close(watches.pop(oldest)[0])
                    descriptor = None
                    try:
                        descriptor = self._open(path)
                        queue.control([select.kevent(descriptor, filter=select.KQ_FILTER_VNODE,
                            flags=select.KQ_EV_ADD | select.KQ_EV_CLEAR,
                            fflags=select.KQ_NOTE_WRITE | select.KQ_NOTE_ATTRIB)], 0, 0)
                        watches[path] = (descriptor, now + self.WATCH_SECONDS)
                    except OSError:
                        if descriptor is not None:
                            os.close(descriptor)
                queue.control(None, self.MAX_DIRECTORIES, 0)
                for path, (descriptor, deadline) in tuple(watches.items()):
                    if deadline <= time.monotonic():
                        del watches[path]
                        os.close(descriptor)
        finally:
            queue.close()
            for descriptor, _deadline in watches.values():
                os.close(descriptor)

    def close(self) -> bool:
        with self._lock:
            self._closed = True
            self._pending.clear()
            thread = self._thread
        self._wake.set()
        if thread is not None:
            thread.join(timeout=1)
        return thread is None or not thread.is_alive()
