"""Workspace environment variables for node tasks: vetting, sealing, injection.

The node's default is and stays :func:`~meshia_node.executor.scrubbed_environment`
— a short allowlist copied from the node operator's own environment, with
nothing of ours in it. This module adds the *only* way anything else reaches a
task environment: a named set of workspace-configured variables that the control
plane hands over, sealed, on an authenticated request.

Three rules shape everything here.

**Named, never blanket.** A task environment is the scrub baseline plus exactly
the names the control plane sealed for it. There is no path that copies an
unlisted name out of the node operator's environment: a variable the control
plane did not send is simply absent from the child, and a variable sent without
a string value is refused rather than resolved locally. That is what keeps the
node from becoming a laundering step for the operator's own secrets.

**Reserved names are not overridable.** ``HOME`` anchors containment (the
executor pins it to the workspace root, and `limited` access enforces that
anchor with Landlock), ``PATH`` and the Windows system plumbing decide which
binary an argv actually resolves to, and ``MESHIA_*`` is the node's own control
namespace — :data:`meshia_node.config.default_home` and the signing-origin
override both read it, so a task that re-invokes the node must not be able to
inherit a redirected one. Cosmetic names (``LANG``, ``TERM``) are overridable
because nothing is anchored to them.

**Sealed in flight, in memory only.** Values live in a local for the duration of
one command and are written to no file the node controls — not the config, not
the log. The outbox needed an explicit measure rather than an assumption: it
persists a command's *result* until the control plane acknowledges it, so a task
that echoes its own environment would turn a one-command value into durable
at-rest state on a machine we do not control. Delivered values are therefore
stripped from a result before it is saved (see
:func:`~meshia_node.executor.CommandExecutor._redacted`), which is literal and
best-effort: it removes the value as delivered, not one the task transformed
first, and not one shorter than
:data:`~meshia_node.executor.MIN_REDACTABLE_VALUE_BYTES`. The transport seal (see
:mod:`meshia_node.sealed_env`) is end-to-end from the control plane to this
process, which matters because the node explicitly supports running behind a
TLS-terminating reverse proxy (``MESHIA_SIGNING_ORIGIN`` in
:mod:`meshia_node.client`) — an intermediary that sees the response body still
never sees a value.

What this module deliberately does **not** try to be
----------------------------------------------------

It is not a defence against the human who owns the host. That person has root;
they can read this process's memory, and the whole design assumes they may. The
property that has to hold is the one enforced on the *other* side of the wire:
what gets delivered here is workspace-scoped, and the control plane never seals
one of its own secrets into it (:mod:`customer-runtime-env-policy` does that
value-level comparison server-side, because only the server knows those values).
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Mapping

from .errors import MeshiaNodeError

# POSIX portable character set for names, plus the leading-digit rule. A name
# outside this set cannot be exported by a shell and is a sign of a malformed or
# hostile payload rather than a real configuration.
# `\Z`, not `$`: Python's `$` also matches just before a trailing newline, so
# `$` would accept "HOME\n" — a name the control plane's own JavaScript NAME_RE
# rejects (JS `$` is a strict end-of-string). The node must not be the looser of
# the two validators, since its re-check is what guards against a bad provider.
NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*\Z")

# The node's own control namespace. `MESHIA_HOME` relocates the state directory
# and `MESHIA_SIGNING_ORIGIN` changes what the client signs; a task that shells
# out to `meshia-node` must never inherit either from workspace configuration.
MESHIA_NAMESPACE_PREFIX = "MESHIA_"

# Names the injection may never set, because something else is anchored to them.
#   HOME/USERPROFILE  the executor pins these to the workspace root; `limited`
#                     access confines writes to exactly that tree, so a task
#                     that believed a different HOME would fail confusingly at
#                     best and write outside the boundary at worst.
#   PATH/PATHEXT      decide which binary an argv resolves to.
#   COMSPEC/SYSTEMROOT/WINDIR
#                     Windows program resolution; COMSPEC in particular is a
#                     direct code-execution redirect.
RESERVED_NAMES = frozenset(
    {
        "HOME",
        "USERPROFILE",
        "PATH",
        "PATHEXT",
        "COMSPEC",
        "SYSTEMROOT",
        "WINDIR",
    }
)

MAX_VARIABLES = 64
MAX_NAME_LENGTH = 128
MAX_VALUE_BYTES = 32_768
MAX_TOTAL_BYTES = 262_144


class EnvironmentRefused(MeshiaNodeError):
    """A workspace environment payload was refused before it reached a task.

    Local and deliberate: the control plane applies its own policy first, and
    this is the node declining to widen a task environment on the strength of a
    payload it cannot vouch for.
    """

    code = "LOCAL_ENV_REFUSED"


def _refuse(reason: str) -> "EnvironmentRefused":
    # Reasons name the *variable* and the rule, never the value.
    return EnvironmentRefused(f"Workspace environment refused: {reason}")


def vet_workspace_environment(payload: Any) -> dict[str, str]:
    """Validate a delivered variable set, returning the names safe to inject.

    Structural only — the node has no way to judge whether a value is a secret
    it should not have received, because it does not know any of the control
    plane's secrets. That comparison is the server's job and is the reason the
    delivery route applies the customer-runtime env policy before sealing.

    Raises :class:`EnvironmentRefused` on anything malformed, oversized, or
    aimed at a reserved name.
    """
    if not isinstance(payload, Mapping):
        raise _refuse("the payload is not a JSON object.")
    if len(payload) > MAX_VARIABLES:
        raise _refuse(f"at most {MAX_VARIABLES} variables may be delivered.")

    vetted: dict[str, str] = {}
    total = 0
    for name, value in payload.items():
        if not isinstance(name, str) or not name:
            raise _refuse("variable names must be non-empty strings.")
        if len(name) > MAX_NAME_LENGTH:
            raise _refuse(f"{name[:32]!r} exceeds the {MAX_NAME_LENGTH}-character name limit.")
        if not NAME_RE.match(name):
            raise _refuse(f"{name!r} is not a portable environment variable name.")
        # A name sent without a usable string value is refused outright rather
        # than resolved from the node operator's environment. Falling back to
        # os.environ here is exactly the blanket passthrough this module exists
        # to prevent, so "no value" means "no variable", never "look it up".
        if not isinstance(value, str):
            raise _refuse(f"{name!r} was delivered without a string value.")
        if "\0" in value:
            raise _refuse(f"{name!r} contains a NUL byte.")
        if "\0" in name:  # pragma: no cover - NAME_RE already excludes it
            raise _refuse(f"{name!r} contains a NUL byte.")
        if name.upper().startswith(MESHIA_NAMESPACE_PREFIX):
            raise _refuse(f"{name!r} is inside the node's own {MESHIA_NAMESPACE_PREFIX}* namespace.")
        if name.upper() in RESERVED_NAMES:
            raise _refuse(f"{name!r} is reserved by the node and cannot be overridden.")
        encoded = len(value.encode("utf-8"))
        if encoded > MAX_VALUE_BYTES:
            raise _refuse(f"{name!r} exceeds the {MAX_VALUE_BYTES}-byte value limit.")
        total += len(name.encode("utf-8")) + encoded
        if total > MAX_TOTAL_BYTES:
            raise _refuse(f"the delivered set exceeds {MAX_TOTAL_BYTES} bytes in total.")
        vetted[name] = value
    return vetted


def apply_workspace_environment(
    base: dict[str, str], workspace_variables: Mapping[str, str]
) -> dict[str, str]:
    """Layer vetted workspace variables on top of a scrubbed base environment.

    `base` is whatever :func:`~meshia_node.executor.scrubbed_environment`
    produced, and it wins on every reserved name — the vetting step has already
    refused those, so this is a second, independent check rather than a
    redundant one: two different code paths would both have to be wrong for a
    reserved name to be overridden.
    """
    merged = dict(base)
    for name, value in workspace_variables.items():
        if name.upper() in RESERVED_NAMES or name.upper().startswith(MESHIA_NAMESPACE_PREFIX):
            # Unreachable through vet_workspace_environment; kept because this
            # function is also the one an injection bug would have to defeat.
            continue
        merged[name] = value
    return merged


def requested_names(payload: Any) -> list[str]:
    """The variable names a command asked for, vetted for shape only.

    A command declares the names it needs; the node asks the control plane for
    exactly those and gets back exactly those (or fewer). Declaring the names
    up front is what keeps a task from receiving the whole workspace secret set
    just because it needed one variable.
    """
    if payload is None:
        return []
    if not isinstance(payload, list):
        raise _refuse("the requested variable list must be an array of names.")
    if len(payload) > MAX_VARIABLES:
        raise _refuse(f"at most {MAX_VARIABLES} variables may be requested.")
    names: list[str] = []
    for entry in payload:
        if not isinstance(entry, str) or not NAME_RE.match(entry) or len(entry) > MAX_NAME_LENGTH:
            raise _refuse("requested variable names must be portable environment names.")
        if entry.upper() in RESERVED_NAMES or entry.upper().startswith(MESHIA_NAMESPACE_PREFIX):
            raise _refuse(f"{entry!r} is reserved by the node and cannot be requested.")
        if entry not in names:
            names.append(entry)
    return names


def redacted_summary(variables: Iterable[str]) -> str:
    """A log-safe description of an injection: names only, never values."""
    names = sorted(variables)
    return ",".join(names) if names else "(none)"
