"""Bounded, signed client for the account-scoped workspace mount catalog.

The catalog is control-plane authority, not a directory scan.  A complete
snapshot is assembled in memory, validated across every page, and only then
atomically replaces the last authenticated snapshot on disk.  Consequently a
timeout, a malformed later page, or ``CATALOG_CHANGED`` can never turn a
temporary control-plane failure into an empty ``Meshia`` mount.

This module intentionally does not start Fabric coordinators.  It is the small
wire and persistence seam consumed by the future account/workspace multiplexer.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
import os
import re
import stat
import unicodedata
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol, Sequence

from .config import file_lock
from .errors import InvalidArgument, NetworkError, RemoteError, StateError
from .object_edge import ObjectEdgeRegistry, default_registry
from .util import POSTGRES_UUID_RE, UUID_RE, ensure_private_dir, write_private_file

CATALOG_SCHEMA = "meshia.connected_host.workspace_catalog.v1"
ATTACHMENTS_SCHEMA = "meshia.connected_host.workspace_attachments.v1"
HEARTBEAT_SCHEMA = "meshia.connected_host.workspace_heartbeat.v1"
RENAME_SCHEMA = "meshia.connected_host.workspace_rename.v1"
SNAPSHOT_SCHEMA = "meshia.node.workspace_catalog_snapshot.v1"

MAX_SAFE_INTEGER = 2**53 - 1
MAX_CATALOG_PAGE_SIZE = 200
MAX_CATALOG_PAGES = 50
MAX_CATALOG_WORKSPACES = MAX_CATALOG_PAGE_SIZE * MAX_CATALOG_PAGES
MAX_ATTACH_BATCH = 32
MAX_HEARTBEAT_BATCH = 200
MAX_WORKSPACE_NAME_CHARS = 100
MAX_WORKSPACE_NAME_BYTES = 400
MAX_PORTABLE_COMPONENT_BYTES = 240
MAX_EMAIL_BYTES = 320
MAX_LEASE_TIMESTAMP_BYTES = 64
MAX_IDEMPOTENCY_KEY_BYTES = 160
MIN_IDEMPOTENCY_KEY_BYTES = 8
MAX_CATALOG_RESTARTS = 2

# A persisted snapshot must admit the complete advertised 10,000-workspace
# catalog while remaining strictly bounded. Compact UTF-8 JSON can still use a
# six-byte ``\u00xx`` escape per display-name character and two bytes per
# printable quote/backslash in a lease timestamp. The per-workspace fixed
# envelope covers both UUIDs, every key and delimiter, and maximum-width safe
# integers; the document envelope covers the maximum email and account fields.
MAX_SNAPSHOT_WORKSPACE_BYTES = (
    512 + (MAX_WORKSPACE_NAME_CHARS * 6) + (MAX_LEASE_TIMESTAMP_BYTES * 2)
)
MAX_SNAPSHOT_BYTES = 2 * 1024 + (MAX_CATALOG_WORKSPACES * MAX_SNAPSHOT_WORKSPACE_BYTES)

_WINDOWS_INVALID = frozenset('<>:"/\\|?*')
_WINDOWS_RESERVED = re.compile(
    r"^(?:CON|PRN|AUX|NUL|CLOCK\$|CONIN\$|CONOUT\$|COM[1-9]|LPT[1-9])(?:\..*)?$",
    re.IGNORECASE,
)
_IDEMPOTENCY_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{7,159}$")


class SignedJsonClient(Protocol):
    def post_json(self, path: str, payload: dict[str, Any]) -> Any: ...


@dataclass(frozen=True)
class AccountIdentity:
    """Immutable authenticated account identity returned by Meshia."""

    id: str
    email: str
    catalog_generation: int


@dataclass(frozen=True)
class WorkspaceStorage:
    state: str
    binding_generation: int
    quota_bytes: int | None = None
    used_bytes: int | None = None
    # Active in-flight reservation bytes from every device (M1736). Older
    # catalogs omit it; the mount then projects only its own pending writes.
    reserved_bytes: int | None = None


@dataclass(frozen=True)
class AttachmentLease:
    id: str
    lease_expires_at: str


@dataclass(frozen=True)
class WorkspaceCatalogEntry:
    session_id: str
    name: str
    name_revision: int
    access: str
    storage: WorkspaceStorage
    attachment: AttachmentLease | None
    #: Whether the workspace is OPEN on Meshia: its session is live
    #: (provisioning, starting or running) with no stop fence, whatever its
    #: compute is doing -- booting, attached or absent (server predicate
    #: M1809; M1762 required ``status = running`` and so flapped with every
    #: compute attach). The mount renders it as Finder's green tag. The wire
    #: key stays ``compute.running`` and is optional, so a node that predates
    #: the field and a server that does not send it both behave exactly as
    #: before (``False``).
    compute_running: bool = False
    #: When the workspace's durable content last changed (ISO-8601, as the
    #: catalog delivered it), or ``None`` from a server that predates M1790.
    #: The mount reports it as the workspace folder's modification time
    #: instead of "now", so Finder/Explorer sort and show real dates.
    modified_at: str | None = None

    @property
    def modified_ns(self) -> int | None:
        """``modified_at`` as integer nanoseconds since the epoch, if present."""

        if self.modified_at is None:
            return None
        return _timestamp_ns(self.modified_at)


@dataclass(frozen=True)
class ProjectedWorkspace:
    workspace: WorkspaceCatalogEntry
    component_name: str


@dataclass(frozen=True)
class WorkspaceCatalogSnapshot:
    account: AccountIdentity
    snapshot_generation: int
    workspaces: tuple[WorkspaceCatalogEntry, ...]

    @property
    def projected(self) -> tuple[ProjectedWorkspace, ...]:
        names = project_workspace_names(self.workspaces)
        return tuple(
            ProjectedWorkspace(workspace=workspace, component_name=names[workspace.session_id])
            for workspace in self.workspaces
        )


@dataclass(frozen=True)
class CatalogFetchResult:
    account: AccountIdentity
    snapshot_generation: int
    unchanged: bool
    snapshot: WorkspaceCatalogSnapshot | None


@dataclass(frozen=True)
class WorkspaceAttachmentReceipt:
    session_id: str
    workspace_name: str
    name_revision: int
    attachment: AttachmentLease
    workspace_storage: WorkspaceStorage
    reused: bool
    object_edge: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class WorkspaceAttachmentBatch:
    account: AccountIdentity
    attachments: tuple[WorkspaceAttachmentReceipt, ...]


@dataclass(frozen=True)
class AttachmentHeartbeatRef:
    attachment_id: str
    session_id: str


@dataclass(frozen=True)
class WorkspaceHeartbeatReceipt:
    attachment_id: str
    session_id: str
    lease_expires_at: str
    workspace_name: str
    name_revision: int
    access_mode: str
    object_edge: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class WorkspaceHeartbeatBatch:
    account: AccountIdentity
    catalog_changed: bool
    attachments: tuple[WorkspaceHeartbeatReceipt, ...]


@dataclass(frozen=True)
class WorkspaceRenameReceipt:
    session_id: str
    name: str
    expected_name_revision: int
    name_revision: int
    catalog_generation: int
    changed: bool


def catalog_restart_required(error: BaseException) -> bool:
    """Return whether a signed 409 says pagination must restart at page one."""

    return (
        isinstance(error, RemoteError)
        and error.status == 409
        and error.remote_code == "CATALOG_CHANGED"
    )


def portable_workspace_name(name: str) -> str:
    """Validate a user-requested name accepted on macOS, Linux, and Windows."""

    if not isinstance(name, str):
        raise InvalidArgument("Workspace name must be text.")
    normalized = unicodedata.normalize("NFC", name)
    if normalized != name:
        raise InvalidArgument("Workspace name must use canonical Unicode normalization.")
    encoded = name.encode("utf-8")
    if not 1 <= len(name) <= MAX_WORKSPACE_NAME_CHARS or len(encoded) > MAX_WORKSPACE_NAME_BYTES:
        raise InvalidArgument("Workspace name must be between 1 and 100 portable characters.")
    if name in (".", "..") or name != name.strip() or name.endswith("."):
        raise InvalidArgument("Workspace name cannot have unsafe leading or trailing characters.")
    if any(
        character in _WINDOWS_INVALID
        or ord(character) < 0x20
        or 0x7F <= ord(character) <= 0x9F
        for character in name
    ):
        raise InvalidArgument("Workspace name contains a character unsupported by a target OS.")
    if _WINDOWS_RESERVED.fullmatch(name):
        raise InvalidArgument("Workspace name is reserved by Windows.")
    return name


def project_workspace_names(
    workspaces: Iterable[WorkspaceCatalogEntry],
) -> dict[str, str]:
    """Project display names into deterministic, collision-free path components.

    Historical names may predate the portable-name validation used by rename.
    Projection therefore sanitizes instead of hiding those workspaces.  Unicode
    normalization and case folding model the strictest common filesystem; all
    members of a collision group receive a short stable session UUID suffix.
    """

    ordered = sorted(tuple(workspaces), key=lambda item: item.session_id.lower())
    if len(ordered) > MAX_CATALOG_WORKSPACES:
        raise StateError("The workspace catalog exceeds the local projection bound.")
    if len({item.session_id.lower() for item in ordered}) != len(ordered):
        raise StateError("The workspace catalog contains duplicate session ids.")

    bases = {item.session_id: _project_component_base(item.name) for item in ordered}
    groups: dict[str, list[WorkspaceCatalogEntry]] = {}
    for item in ordered:
        groups.setdefault(_canonical_component(bases[item.session_id]), []).append(item)

    suffix_lengths = {
        item.session_id: (8 if len(groups[_canonical_component(bases[item.session_id])]) > 1 else 0)
        for item in ordered
    }
    candidates: dict[str, str] = {}
    # Eight bounded passes are enough to grow an ambiguous 8-character suffix
    # through the complete 32 hexadecimal UUID characters.
    for _ in range(8):
        candidates = {
            item.session_id: _with_session_suffix(
                bases[item.session_id], item.session_id, suffix_lengths[item.session_id]
            )
            for item in ordered
        }
        collisions: dict[str, list[str]] = {}
        for session_id, candidate in candidates.items():
            collisions.setdefault(_canonical_component(candidate), []).append(session_id)
        ambiguous = [ids for ids in collisions.values() if len(ids) > 1]
        if not ambiguous:
            return candidates
        for ids in ambiguous:
            for session_id in ids:
                current = suffix_lengths[session_id]
                suffix_lengths[session_id] = 8 if current == 0 else min(32, current + 4)
    raise StateError("Workspace names could not be projected without a collision.")


class WorkspaceCatalogStore:
    """Atomic private persistence for the last complete authenticated snapshot."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.lock_path = self.path.with_name(f".{self.path.name}.lock")

    def load(self) -> WorkspaceCatalogSnapshot | None:
        ensure_private_dir(self.path.parent)
        with file_lock(self.lock_path):
            return self._load_unlocked()

    def load_readonly(self) -> WorkspaceCatalogSnapshot | None:
        """Read one atomic snapshot without creating state or taking a writer lock.

        Snapshot publication uses atomic replacement, and ``_load_unlocked``
        pins and validates one bounded regular-file descriptor. Diagnostics can
        therefore observe either complete generation without contending with
        the connected host's refresh loop.
        """

        return self._load_unlocked()

    def save(self, snapshot: WorkspaceCatalogSnapshot) -> WorkspaceCatalogSnapshot:
        _validate_snapshot(snapshot)
        encoded = _bounded_snapshot_bytes(snapshot)
        ensure_private_dir(self.path.parent)
        with file_lock(self.lock_path):
            write_private_file(self.path, encoded)
        return snapshot

    def apply_rename(self, receipt: WorkspaceRenameReceipt) -> WorkspaceCatalogSnapshot:
        """Atomically project only the receipt's workspace name revision.

        ``catalog_generation`` is a current server observation, but the rename
        request fences only one workspace.  Other workspace/storage changes may
        already be part of that newer account generation, so promoting the
        cached snapshot generation here could make a later refresh incorrectly
        return ``unchanged`` and hide them.  Keep the last *complete* catalog
        generation until a normal catalog refresh proves the full snapshot.
        """

        with file_lock(self.lock_path):
            snapshot = self._load_unlocked()
            if snapshot is None:
                raise StateError("No workspace catalog snapshot exists to rename.")
            matching = [
                workspace for workspace in snapshot.workspaces
                if workspace.session_id == receipt.session_id
            ]
            if len(matching) != 1:
                raise StateError("The renamed workspace is not in the authenticated snapshot.")
            current = matching[0]
            already_applied = (
                current.name == receipt.name
                and current.name_revision == receipt.name_revision
            )
            if not already_applied and current.name_revision != receipt.expected_name_revision:
                raise StateError("The local workspace name revision changed during rename.")
            if receipt.name_revision < current.name_revision:
                raise StateError("Meshia returned a stale workspace rename revision.")
            if receipt.catalog_generation < snapshot.account.catalog_generation:
                raise StateError("Meshia returned a stale catalog generation after rename.")
            if already_applied:
                return snapshot

            updated = replace(
                snapshot,
                workspaces=tuple(
                    replace(
                        workspace,
                        name=receipt.name,
                        name_revision=receipt.name_revision,
                    )
                    if workspace.session_id == receipt.session_id
                    else workspace
                    for workspace in snapshot.workspaces
                ),
            )
            _validate_snapshot(updated)
            write_private_file(self.path, _bounded_snapshot_bytes(updated))
            return updated

    def _load_unlocked(self) -> WorkspaceCatalogSnapshot | None:
        if not self.path.exists():
            return None
        try:
            flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_CLOEXEC", 0)
            flags |= getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(str(self.path), flags)
            try:
                metadata = os.fstat(descriptor)
                if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > MAX_SNAPSHOT_BYTES:
                    raise StateError("The workspace catalog snapshot is not a bounded regular file.")
                raw = bytearray()
                while len(raw) <= MAX_SNAPSHOT_BYTES:
                    chunk = os.read(descriptor, min(64 * 1024, MAX_SNAPSHOT_BYTES + 1 - len(raw)))
                    if not chunk:
                        break
                    raw.extend(chunk)
            finally:
                os.close(descriptor)
            if len(raw) > MAX_SNAPSHOT_BYTES:
                raise StateError("The workspace catalog snapshot exceeds its size bound.")
            document = json.loads(bytes(raw).decode("utf-8"))
            return _parse_snapshot(document)
        except StateError:
            raise
        except (OSError, UnicodeError, ValueError) as error:
            raise StateError(f"The workspace catalog snapshot at {self.path} is unreadable.") from error


class WorkspaceCatalogClient:
    """Signed, bounded Stage-1 account/workspace control-plane client."""

    def __init__(
        self,
        client: SignedJsonClient,
        host_id: str,
        *,
        access_mode: str = "files",
        object_edge_registry: ObjectEdgeRegistry | None = None,
        request_object_edge: bool = True,
    ) -> None:
        self.client = client
        self.host_id = _uuid(host_id, "host id")
        if access_mode not in ("files", "limited", "full"):
            raise InvalidArgument("Workspace attachment access mode is unsupported.")
        self.access_mode = access_mode
        self.object_edge_registry = object_edge_registry or default_registry()
        # Opt in to per-attachment object edge grants. An older control plane
        # rejects the unknown field once (400); we then stop asking for the
        # process lifetime, and that plane mints no grants anyway.
        self._request_object_edge = bool(request_object_edge)

    def _post_workspace_json(self, path: str, body: dict[str, Any]) -> Any:
        if not self._request_object_edge:
            return self.client.post_json(path, body)
        try:
            return self.client.post_json(path, {**body, "object_edge": True})
        except RemoteError as error:
            if error.status != 400:
                raise
            self._request_object_edge = False
            return self.client.post_json(path, body)

    def _observe_object_edge(
        self, session_id: str, attachment_id: str, grant: Mapping[str, Any] | None
    ) -> None:
        if not self._request_object_edge and grant is None:
            return
        self.object_edge_registry.observe(session_id, grant, attachment_id=attachment_id)

    def fetch_catalog(
        self,
        *,
        known_generation: int | None = None,
        page_limit: int = MAX_CATALOG_PAGE_SIZE,
    ) -> CatalogFetchResult:
        """Fetch one generation-consistent snapshot without persisting partial pages."""

        if known_generation is not None:
            known_generation = _positive_int(known_generation, "known catalog generation")
        if isinstance(page_limit, bool) or not isinstance(page_limit, int) or not 1 <= page_limit <= 200:
            raise InvalidArgument("Catalog page limit must be between 1 and 200.")

        account: AccountIdentity | None = None
        snapshot_generation: int | None = None
        after_session_id: str | None = None
        workspaces: list[WorkspaceCatalogEntry] = []
        for page_index in range(MAX_CATALOG_PAGES):
            body: dict[str, Any] = {"limit": page_limit}
            if page_index == 0:
                if known_generation is not None:
                    body["known_generation"] = known_generation
            else:
                assert snapshot_generation is not None and after_session_id is not None
                body["snapshot_generation"] = snapshot_generation
                body["after_session_id"] = after_session_id

            page = _parse_catalog_page(
                self.client.post_json(
                    f"api/connected-hosts/{self.host_id}/workspaces/catalog", body
                )
            )
            if len(page.workspaces) > page_limit:
                raise NetworkError("Meshia exceeded the requested workspace catalog page limit.")
            if account is None:
                account = page.account
                snapshot_generation = page.snapshot_generation
                if page.unchanged:
                    if known_generation != page.account.catalog_generation:
                        raise NetworkError("Meshia returned an inconsistent unchanged catalog receipt.")
                    return CatalogFetchResult(
                        account=page.account,
                        snapshot_generation=page.snapshot_generation,
                        unchanged=True,
                        snapshot=None,
                    )
            elif page.account != account or page.snapshot_generation != snapshot_generation:
                raise NetworkError("Meshia changed account or generation during catalog pagination.")

            if page.unchanged:
                raise NetworkError("Meshia returned unchanged on a catalog continuation page.")
            if page.workspaces and after_session_id is not None:
                if page.workspaces[0].session_id.lower() <= after_session_id.lower():
                    raise NetworkError("Meshia returned an overlapping workspace catalog page.")
            workspaces.extend(page.workspaces)
            if len(workspaces) > MAX_CATALOG_WORKSPACES:
                raise NetworkError("Meshia returned too many workspaces in one catalog snapshot.")
            if page.next_after_session_id is None:
                assert account is not None and snapshot_generation is not None
                snapshot = WorkspaceCatalogSnapshot(
                    account=account,
                    snapshot_generation=snapshot_generation,
                    workspaces=tuple(workspaces),
                )
                _validate_snapshot(snapshot)
                return CatalogFetchResult(
                    account=account,
                    snapshot_generation=snapshot_generation,
                    unchanged=False,
                    snapshot=snapshot,
                )
            if not page.workspaces or page.next_after_session_id != page.workspaces[-1].session_id:
                raise NetworkError("Meshia returned a non-advancing workspace catalog cursor.")
            after_session_id = page.next_after_session_id
        raise NetworkError("Meshia workspace catalog pagination exceeded its page bound.")

    def refresh(self, store: WorkspaceCatalogStore) -> WorkspaceCatalogSnapshot:
        """Refresh and atomically persist; keep the old snapshot on every failure."""

        previous = store.load()
        known = previous.account.catalog_generation if previous is not None else None
        last_changed: RemoteError | None = None
        for attempt in range(MAX_CATALOG_RESTARTS + 1):
            try:
                result = self.fetch_catalog(
                    known_generation=known if attempt == 0 else None
                )
            except RemoteError as error:
                if not catalog_restart_required(error) or attempt >= MAX_CATALOG_RESTARTS:
                    raise
                last_changed = error
                continue
            if result.unchanged:
                if previous is None or previous.account != result.account:
                    raise NetworkError("Meshia returned unchanged without the matching local snapshot.")
                return previous
            assert result.snapshot is not None
            return store.save(result.snapshot)
        assert last_changed is not None  # pragma: no cover - loop is exhaustive
        raise last_changed

    def attach_workspaces(
        self,
        *,
        catalog_generation: int,
        workspace_ids: Sequence[str],
    ) -> WorkspaceAttachmentBatch:
        generation = _positive_int(catalog_generation, "catalog generation")
        ids = tuple(_uuid(value, "workspace id") for value in workspace_ids)
        _require_unique(ids, "workspace ids")
        if not ids:
            raise InvalidArgument("At least one workspace id is required for attach.")

        account: AccountIdentity | None = None
        receipts: list[WorkspaceAttachmentReceipt] = []
        for offset in range(0, len(ids), MAX_ATTACH_BATCH):
            chunk = ids[offset : offset + MAX_ATTACH_BATCH]
            parsed_account, parsed_receipts = _parse_attachment_batch(
                self._post_workspace_json(
                    f"api/connected-hosts/{self.host_id}/workspaces/attach",
                    {
                        "catalog_generation": generation,
                        "workspace_ids": list(chunk),
                        "access_mode": self.access_mode,
                    },
                )
            )
            if parsed_account.catalog_generation != generation:
                raise NetworkError("Meshia attached workspaces under a different catalog generation.")
            if account is None:
                account = parsed_account
            elif parsed_account != account:
                raise NetworkError("Meshia changed account during workspace attachment.")
            if {item.session_id for item in parsed_receipts} != set(chunk):
                raise NetworkError("Meshia returned attachments for the wrong workspaces.")
            for item in parsed_receipts:
                self._observe_object_edge(item.session_id, item.attachment.id, item.object_edge)
            receipts.extend(parsed_receipts)
        assert account is not None
        return WorkspaceAttachmentBatch(account=account, attachments=tuple(receipts))

    def heartbeat_workspaces(
        self,
        attachments: Sequence[AttachmentHeartbeatRef],
        *,
        known_catalog_generation: int | None = None,
    ) -> WorkspaceHeartbeatBatch:
        refs = tuple(
            AttachmentHeartbeatRef(
                attachment_id=_uuid(item.attachment_id, "attachment id"),
                session_id=_uuid(item.session_id, "session id"),
            )
            for item in attachments
        )
        pairs = tuple((item.attachment_id, item.session_id) for item in refs)
        _require_unique(pairs, "attachment/session pairs")
        _require_unique((item.attachment_id for item in refs), "attachment ids")
        _require_unique((item.session_id for item in refs), "workspace session ids")
        if not refs:
            raise InvalidArgument("At least one workspace attachment is required for heartbeat.")
        if known_catalog_generation is not None:
            known_catalog_generation = _positive_int(
                known_catalog_generation, "known catalog generation"
            )

        account: AccountIdentity | None = None
        changed = False
        receipts: list[WorkspaceHeartbeatReceipt] = []
        for offset in range(0, len(refs), MAX_HEARTBEAT_BATCH):
            chunk = refs[offset : offset + MAX_HEARTBEAT_BATCH]
            body: dict[str, Any] = {
                "attachments": [
                    {"attachment_id": item.attachment_id, "session_id": item.session_id}
                    for item in chunk
                ]
            }
            if known_catalog_generation is not None:
                body["known_catalog_generation"] = known_catalog_generation
            parsed_account, page_changed, parsed_receipts = _parse_heartbeat_batch(
                self._post_workspace_json(
                    f"api/connected-hosts/{self.host_id}/heartbeat", body
                )
            )
            if account is None:
                account = parsed_account
            elif parsed_account != account:
                raise NetworkError("Meshia changed account during workspace heartbeat.")
            expected = {(item.attachment_id, item.session_id) for item in chunk}
            actual = {(item.attachment_id, item.session_id) for item in parsed_receipts}
            if actual != expected:
                raise NetworkError("Meshia returned heartbeat leases for the wrong attachments.")
            for item in parsed_receipts:
                self._observe_object_edge(item.session_id, item.attachment_id, item.object_edge)
            changed = changed or page_changed
            receipts.extend(parsed_receipts)
        assert account is not None
        return WorkspaceHeartbeatBatch(
            account=account,
            catalog_changed=changed,
            attachments=tuple(receipts),
        )

    def rename_workspace(
        self,
        *,
        session_id: str,
        attachment_id: str,
        expected_name_revision: int,
        name: str,
        idempotency_key: str,
    ) -> WorkspaceRenameReceipt:
        session = _uuid(session_id, "session id")
        attachment = _uuid(attachment_id, "attachment id")
        revision = _positive_int(expected_name_revision, "expected name revision")
        accepted_name = portable_workspace_name(name)
        key = _idempotency_key(idempotency_key)
        document = self.client.post_json(
            f"api/connected-hosts/{self.host_id}/workspaces/{session}/rename",
            {
                "attachment_id": attachment,
                "expected_name_revision": revision,
                "name": accepted_name,
                "idempotency_key": key,
            },
        )
        receipt = _parse_rename_receipt(document, expected_name_revision=revision)
        if receipt.session_id != session or receipt.name != accepted_name:
            raise NetworkError("Meshia returned a rename receipt for a different workspace or name.")
        return receipt


@dataclass(frozen=True)
class _CatalogPage:
    account: AccountIdentity
    unchanged: bool
    snapshot_generation: int
    workspaces: tuple[WorkspaceCatalogEntry, ...]
    next_after_session_id: str | None


def _parse_catalog_page(document: Any) -> _CatalogPage:
    value = _object(
        document,
        {"schema", "account", "unchanged", "snapshot_generation", "workspaces", "next_after_session_id"},
        "workspace catalog page",
    )
    if value["schema"] != CATALOG_SCHEMA:
        raise NetworkError("Meshia returned an unknown workspace catalog schema.")
    account = _parse_account(value["account"])
    generation = _positive_int_remote(value["snapshot_generation"], "snapshot generation")
    if generation != account.catalog_generation:
        raise NetworkError("Meshia returned inconsistent workspace catalog generations.")
    unchanged = _boolean(value["unchanged"], "catalog unchanged")
    raw_workspaces = _array(value["workspaces"], MAX_CATALOG_PAGE_SIZE, "workspace catalog page")
    workspaces = tuple(_parse_catalog_entry(item) for item in raw_workspaces)
    if tuple(sorted(item.session_id.lower() for item in workspaces)) != tuple(
        item.session_id.lower() for item in workspaces
    ) or len({item.session_id.lower() for item in workspaces}) != len(workspaces):
        raise NetworkError("Meshia returned an unsorted or duplicate workspace catalog page.")
    cursor = value["next_after_session_id"]
    if cursor is not None:
        cursor = _uuid_remote(cursor, "catalog cursor")
    if unchanged and (workspaces or cursor is not None):
        raise NetworkError("Meshia returned workspaces in an unchanged catalog receipt.")
    return _CatalogPage(account, unchanged, generation, workspaces, cursor)


def _parse_account(value: Any) -> AccountIdentity:
    document = _object(value, {"id", "email", "catalog_generation"}, "account identity")
    email = document["email"]
    if (
        not isinstance(email, str)
        or not 3 <= len(email.encode("utf-8")) <= MAX_EMAIL_BYTES
        or "@" not in email
        or any(ord(character) < 0x21 or ord(character) == 0x7F for character in email)
    ):
        raise NetworkError("Meshia returned an invalid account email.")
    return AccountIdentity(
        id=_postgres_uuid_remote(document["id"], "account id"),
        email=email,
        catalog_generation=_positive_int_remote(
            document["catalog_generation"], "catalog generation"
        ),
    )


def _parse_compute(value: Any) -> bool:
    """Read the optional compute projection; absent or unknown means closed.

    Only the running flag is consumed (it means "workspace open", see
    ``WorkspaceCatalogEntry.compute_running``). Unknown sibling keys are tolerated so
    the server can extend the projection without a coordinated node release.
    """

    if value is None:
        return False
    if not isinstance(value, dict):
        raise NetworkError("The workspace catalog entry has invalid compute fields.")
    running = value.get("running", False)
    if not isinstance(running, bool):
        raise NetworkError("The workspace catalog entry has an invalid compute state.")
    return running


def _parse_catalog_entry(value: Any) -> WorkspaceCatalogEntry:
    document = _object_with_optional(
        value,
        {"session_id", "name", "name_revision", "access", "storage", "attachment"},
        {"compute", "modified_at"},
        "workspace catalog entry",
    )
    if document["access"] != "read_write":
        raise NetworkError("Meshia returned an unsupported workspace access mode.")
    return WorkspaceCatalogEntry(
        session_id=_uuid_remote(document["session_id"], "workspace session id"),
        name=_display_name(document["name"]),
        name_revision=_positive_int_remote(document["name_revision"], "workspace name revision"),
        access="read_write",
        storage=_parse_storage(document["storage"], "binding_generation"),
        attachment=(
            None if document["attachment"] is None else _parse_lease(document["attachment"])
        ),
        compute_running=_parse_compute(document.get("compute")),
        modified_at=_optional_modified_at(document.get("modified_at")),
    )


def _optional_modified_at(value: Any) -> str | None:
    """Read the optional workspace modification time; absent means unknown."""

    if value is None:
        return None
    if (
        not isinstance(value, str)
        or not 1 <= len(value.encode("utf-8")) <= MAX_LEASE_TIMESTAMP_BYTES
        or any(ord(character) < 0x20 or ord(character) > 0x7E for character in value)
    ):
        raise NetworkError("The workspace catalog entry has an invalid modification time.")
    try:
        _timestamp_ns(value)
    except ValueError as error:
        raise NetworkError(
            "The workspace catalog entry has an invalid modification time."
        ) from error
    return value


def _timestamp_ns(value: str) -> int:
    """Parse an ISO-8601 timestamp (``Z`` or offset) to epoch nanoseconds."""

    text = value[:-1] + "+00:00" if value.endswith("Z") else value
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.timestamp() * 1_000_000_000)


def _parse_attachment_batch(
    document: Any,
) -> tuple[AccountIdentity, tuple[WorkspaceAttachmentReceipt, ...]]:
    value = _object(document, {"schema", "account", "attachments"}, "workspace attachments")
    if value["schema"] != ATTACHMENTS_SCHEMA:
        raise NetworkError("Meshia returned an unknown workspace attachment schema.")
    raw = _array(value["attachments"], MAX_ATTACH_BATCH, "workspace attachments")
    receipts: list[WorkspaceAttachmentReceipt] = []
    for item in raw:
        row = _object_with_optional(
            item,
            {"session_id", "workspace_name", "name_revision", "attachment", "workspace_storage", "reused"},
            {"object_edge"},
            "workspace attachment receipt",
        )
        receipts.append(
            WorkspaceAttachmentReceipt(
                session_id=_uuid_remote(row["session_id"], "workspace session id"),
                workspace_name=_display_name(row["workspace_name"]),
                name_revision=_positive_int_remote(row["name_revision"], "workspace name revision"),
                attachment=_parse_lease(row["attachment"]),
                workspace_storage=_parse_storage(row["workspace_storage"], "generation"),
                reused=_boolean(row["reused"], "attachment reused"),
                object_edge=_optional_object_edge(row.get("object_edge")),
            )
        )
    _require_unique_remote((item.session_id for item in receipts), "workspace attachment receipts")
    return _parse_account(value["account"]), tuple(receipts)


def _parse_heartbeat_batch(
    document: Any,
) -> tuple[AccountIdentity, bool, tuple[WorkspaceHeartbeatReceipt, ...]]:
    value = _object(
        document,
        {"schema", "account", "catalog_changed", "attachments"},
        "workspace heartbeat",
    )
    if value["schema"] != HEARTBEAT_SCHEMA:
        raise NetworkError("Meshia returned an unknown workspace heartbeat schema.")
    raw = _array(value["attachments"], MAX_HEARTBEAT_BATCH, "workspace heartbeat")
    receipts: list[WorkspaceHeartbeatReceipt] = []
    for item in raw:
        row = _object_with_optional(
            item,
            {"attachment_id", "session_id", "lease_expires_at", "workspace_name", "name_revision", "access_mode"},
            {"object_edge"},
            "workspace heartbeat receipt",
        )
        if row["access_mode"] not in ("files", "limited", "full"):
            raise NetworkError("Meshia returned an unsupported heartbeat access mode.")
        receipts.append(
            WorkspaceHeartbeatReceipt(
                attachment_id=_uuid_remote(row["attachment_id"], "attachment id"),
                session_id=_uuid_remote(row["session_id"], "workspace session id"),
                lease_expires_at=_lease_timestamp(row["lease_expires_at"]),
                workspace_name=_display_name(row["workspace_name"]),
                name_revision=_positive_int_remote(row["name_revision"], "workspace name revision"),
                access_mode=row["access_mode"],
                object_edge=_optional_object_edge(row.get("object_edge")),
            )
        )
    _require_unique_remote(
        ((item.attachment_id, item.session_id) for item in receipts),
        "workspace heartbeat receipts",
    )
    return (
        _parse_account(value["account"]),
        _boolean(value["catalog_changed"], "catalog changed"),
        tuple(receipts),
    )


def _parse_rename_receipt(document: Any, *, expected_name_revision: int) -> WorkspaceRenameReceipt:
    value = _object(
        document,
        {"schema", "session_id", "name", "name_revision", "catalog_generation", "changed"},
        "workspace rename receipt",
    )
    if value["schema"] != RENAME_SCHEMA:
        raise NetworkError("Meshia returned an unknown workspace rename schema.")
    name_revision = _positive_int_remote(value["name_revision"], "workspace name revision")
    if name_revision < expected_name_revision:
        raise NetworkError("Meshia returned a stale workspace rename revision.")
    return WorkspaceRenameReceipt(
        session_id=_uuid_remote(value["session_id"], "workspace session id"),
        name=_display_name(value["name"]),
        expected_name_revision=expected_name_revision,
        name_revision=name_revision,
        catalog_generation=_positive_int_remote(value["catalog_generation"], "catalog generation"),
        changed=_boolean(value["changed"], "workspace name changed"),
    )


def _parse_storage(value: Any, generation_key: str) -> WorkspaceStorage:
    legacy_keys = {"state", generation_key}
    current_keys = {*legacy_keys, "quota_bytes", "used_bytes"}
    reserved_keys = {*current_keys, "reserved_bytes"}
    if not isinstance(value, dict) or set(value) not in (
        legacy_keys,
        current_keys,
        reserved_keys,
    ):
        raise NetworkError("The workspace storage has invalid fields.")
    document = value
    if document["state"] != "ready":
        raise NetworkError("Meshia returned workspace storage that is not ready.")
    quota_bytes: int | None = None
    used_bytes: int | None = None
    reserved_bytes: int | None = None
    if "quota_bytes" in document:
        quota_bytes = _positive_int_remote(
            document["quota_bytes"], "workspace storage quota"
        )
        used_bytes = _nonnegative_int_remote(
            document["used_bytes"], "workspace storage usage"
        )
    if "reserved_bytes" in document:
        reserved_bytes = _nonnegative_int_remote(
            document["reserved_bytes"], "workspace storage reservations"
        )
    return WorkspaceStorage(
        state="ready",
        binding_generation=_positive_int_remote(
            document[generation_key], "workspace storage generation"
        ),
        quota_bytes=quota_bytes,
        used_bytes=used_bytes,
        reserved_bytes=reserved_bytes,
    )


def _parse_lease(value: Any) -> AttachmentLease:
    document = _object(value, {"id", "lease_expires_at"}, "attachment lease")
    return AttachmentLease(
        id=_uuid_remote(document["id"], "attachment id"),
        lease_expires_at=_lease_timestamp(document["lease_expires_at"]),
    )


def _snapshot_document(snapshot: WorkspaceCatalogSnapshot) -> dict[str, Any]:
    return {
        "schema": SNAPSHOT_SCHEMA,
        "account": {
            "id": snapshot.account.id,
            "email": snapshot.account.email,
            "catalog_generation": snapshot.account.catalog_generation,
        },
        "snapshot_generation": snapshot.snapshot_generation,
        "workspaces": [
            {
                "session_id": workspace.session_id,
                "name": workspace.name,
                "name_revision": workspace.name_revision,
                "access": workspace.access,
                **(
                    {"compute": {"running": True}}
                    if workspace.compute_running
                    else {}
                ),
                **(
                    {}
                    if workspace.modified_at is None
                    else {"modified_at": workspace.modified_at}
                ),
                "storage": {
                    "state": workspace.storage.state,
                    "binding_generation": workspace.storage.binding_generation,
                    **(
                        {}
                        if workspace.storage.quota_bytes is None
                        else {
                            "quota_bytes": workspace.storage.quota_bytes,
                            "used_bytes": workspace.storage.used_bytes,
                        }
                    ),
                },
                "attachment": (
                    None
                    if workspace.attachment is None
                    else {
                        "id": workspace.attachment.id,
                        "lease_expires_at": workspace.attachment.lease_expires_at,
                    }
                ),
            }
            for workspace in snapshot.workspaces
        ],
    }


def _bounded_snapshot_bytes(snapshot: WorkspaceCatalogSnapshot) -> bytes:
    """Encode one snapshot only if the store can read the published bytes back."""

    encoded = json.dumps(
        _snapshot_document(snapshot),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    if len(encoded) > MAX_SNAPSHOT_BYTES:
        raise StateError("The workspace catalog snapshot exceeds its size bound.")
    return encoded


def _parse_snapshot(document: Any) -> WorkspaceCatalogSnapshot:
    value = _object(
        document,
        {"schema", "account", "snapshot_generation", "workspaces"},
        "workspace catalog snapshot",
        state=True,
    )
    if value["schema"] != SNAPSHOT_SCHEMA:
        raise StateError("The workspace catalog snapshot schema is unsupported.")
    try:
        raw = _array(
            value["workspaces"], MAX_CATALOG_WORKSPACES, "workspace catalog snapshot"
        )
        snapshot = WorkspaceCatalogSnapshot(
            account=_parse_account(value["account"]),
            snapshot_generation=_positive_int_remote(
                value["snapshot_generation"], "snapshot generation"
            ),
            workspaces=tuple(_parse_catalog_entry(item) for item in raw),
        )
        _validate_snapshot(snapshot)
        return snapshot
    except NetworkError as error:
        raise StateError("The persisted workspace catalog snapshot is invalid.") from error


def _validate_snapshot(snapshot: WorkspaceCatalogSnapshot) -> None:
    try:
        document = _snapshot_document(snapshot)
        if _parse_account(document["account"]) != snapshot.account:
            raise StateError("The workspace catalog account identity is not canonical.")
        parsed_workspaces = tuple(
            _parse_catalog_entry(item) for item in document["workspaces"]
        )
        if parsed_workspaces != snapshot.workspaces:
            raise StateError("The workspace catalog contains non-canonical entries.")
    except NetworkError as error:
        raise StateError("The workspace catalog contains invalid authority data.") from error
    if snapshot.snapshot_generation != snapshot.account.catalog_generation:
        raise StateError("Workspace snapshot and account generations differ.")
    if len(snapshot.workspaces) > MAX_CATALOG_WORKSPACES:
        raise StateError("The workspace catalog exceeds its persisted bound.")
    sessions = tuple(item.session_id.lower() for item in snapshot.workspaces)
    if sessions != tuple(sorted(sessions)) or len(set(sessions)) != len(sessions):
        raise StateError("Workspace catalog snapshots must be sorted and unique.")
    # Also proves that every visible root can be projected without ambiguity.
    project_workspace_names(snapshot.workspaces)


def _project_component_base(name: str) -> str:
    normalized = unicodedata.normalize("NFC", name)
    cleaned = "".join(
        " "
        if character in _WINDOWS_INVALID
        or ord(character) < 0x20
        or 0x7F <= ord(character) <= 0x9F
        else character
        for character in normalized
    )
    cleaned = " ".join(cleaned.split()).strip(" .") or "Workspace"
    if cleaned in (".", "..") or _WINDOWS_RESERVED.fullmatch(cleaned):
        cleaned = f"{cleaned} Workspace"
    return _truncate_utf8(cleaned, MAX_PORTABLE_COMPONENT_BYTES)


def _canonical_component(value: str) -> str:
    return unicodedata.normalize("NFC", value).casefold().rstrip(" .")


def _with_session_suffix(base: str, session_id: str, length: int) -> str:
    if length == 0:
        return base
    # The tail is still a literal short session UUID fragment, while avoiding
    # the common test/import pattern where UUIDs share a long zero prefix.
    token = session_id.replace("-", "").lower()[-length:]
    suffix = f" ({token})"
    return f"{_truncate_utf8(base, MAX_PORTABLE_COMPONENT_BYTES - len(suffix))}{suffix}"


def _truncate_utf8(value: str, byte_limit: int) -> str:
    encoded = value.encode("utf-8")
    if len(encoded) <= byte_limit:
        return value
    clipped = encoded[:byte_limit]
    while clipped:
        try:
            return clipped.decode("utf-8").rstrip(" .") or "Workspace"
        except UnicodeDecodeError:
            clipped = clipped[:-1]
    return "Workspace"


def _object_with_optional(
    value: Any,
    required: set[str],
    optional: set[str],
    label: str,
) -> Mapping[str, Any]:
    """Exact required keys plus a bounded set of optional extension keys."""

    if (
        not isinstance(value, dict)
        or not required <= set(value)
        or not set(value) <= (required | optional)
    ):
        raise NetworkError(f"The {label} has invalid fields.")
    return value


def _optional_object_edge(value: Any) -> Mapping[str, Any] | None:
    """Keep the raw grant for the registry; its parser validates it."""

    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != {"url", "token", "expires_at", "kid"}:
        raise NetworkError("The workspace receipt has an invalid object edge grant.")
    return value


def _object(
    value: Any,
    keys: set[str],
    label: str,
    *,
    state: bool = False,
) -> Mapping[str, Any]:
    error_type = StateError if state else NetworkError
    if not isinstance(value, dict) or set(value) != keys:
        raise error_type(f"The {label} has invalid fields.")
    return value


def _array(value: Any, limit: int, label: str) -> list[Any]:
    if not isinstance(value, list) or len(value) > limit:
        raise NetworkError(f"The {label} exceeds its array bound.")
    return value


def _positive_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= MAX_SAFE_INTEGER:
        raise InvalidArgument(f"{label.capitalize()} must be a positive safe integer.")
    return value


def _positive_int_remote(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= MAX_SAFE_INTEGER:
        raise NetworkError(f"Meshia returned an invalid {label}.")
    return value


def _nonnegative_int_remote(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= MAX_SAFE_INTEGER:
        raise NetworkError(f"Meshia returned an invalid {label}.")
    return value


def _uuid(value: Any, label: str) -> str:
    if not isinstance(value, str) or UUID_RE.fullmatch(value) is None:
        raise InvalidArgument(f"{label.capitalize()} must be a UUID.")
    return value.lower()


def _uuid_remote(value: Any, label: str) -> str:
    if not isinstance(value, str) or UUID_RE.fullmatch(value) is None:
        raise NetworkError(f"Meshia returned an invalid {label}.")
    return value.lower()


def _postgres_uuid_remote(value: Any, label: str) -> str:
    if not isinstance(value, str) or POSTGRES_UUID_RE.fullmatch(value) is None:
        raise NetworkError(f"Meshia returned an invalid {label}.")
    return value.lower()


def _display_name(value: Any) -> str:
    if (
        not isinstance(value, str)
        or not 1 <= len(value) <= MAX_WORKSPACE_NAME_CHARS
        or len(value.encode("utf-8")) > MAX_WORKSPACE_NAME_BYTES
        or "\x00" in value
    ):
        raise NetworkError("Meshia returned an invalid workspace display name.")
    return value


def _lease_timestamp(value: Any) -> str:
    if (
        not isinstance(value, str)
        or not 1 <= len(value.encode("utf-8")) <= MAX_LEASE_TIMESTAMP_BYTES
        or any(ord(character) < 0x20 or ord(character) > 0x7E for character in value)
    ):
        raise NetworkError("Meshia returned an invalid attachment lease expiry.")
    return value


def _boolean(value: Any, label: str) -> bool:
    if not isinstance(value, bool):
        raise NetworkError(f"Meshia returned an invalid {label} flag.")
    return value


def _idempotency_key(value: Any) -> str:
    if not isinstance(value, str):
        raise InvalidArgument("Rename idempotency key must be text.")
    encoded = value.encode("utf-8")
    if (
        not MIN_IDEMPOTENCY_KEY_BYTES <= len(encoded) <= MAX_IDEMPOTENCY_KEY_BYTES
        or _IDEMPOTENCY_RE.fullmatch(value) is None
    ):
        raise InvalidArgument("Rename idempotency key is outside the portable bound.")
    return value


def _require_unique(values: Iterable[Any], label: str) -> None:
    materialized = tuple(values)
    if len(set(materialized)) != len(materialized):
        raise InvalidArgument(f"{label.capitalize()} must be unique.")


def _require_unique_remote(values: Iterable[Any], label: str) -> None:
    materialized = tuple(values)
    if len(set(materialized)) != len(materialized):
        raise NetworkError(f"Meshia returned duplicate {label}.")


__all__ = [
    "AccountIdentity",
    "AttachmentHeartbeatRef",
    "AttachmentLease",
    "CatalogFetchResult",
    "ProjectedWorkspace",
    "WorkspaceAttachmentBatch",
    "WorkspaceAttachmentReceipt",
    "WorkspaceCatalogClient",
    "WorkspaceCatalogEntry",
    "WorkspaceCatalogSnapshot",
    "WorkspaceCatalogStore",
    "WorkspaceHeartbeatBatch",
    "WorkspaceHeartbeatReceipt",
    "WorkspaceRenameReceipt",
    "WorkspaceStorage",
    "catalog_restart_required",
    "portable_workspace_name",
    "project_workspace_names",
]
