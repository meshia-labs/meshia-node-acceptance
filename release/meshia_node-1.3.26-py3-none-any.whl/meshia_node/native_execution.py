"""Native research compute with a workspace filesystem boundary.

This does not provision a container, replace the machine's software stack, or
set CPU/RAM quotas. macOS Seatbelt restricts the command and
its descendants to workspace data plus read-only installed runtimes. IP
networking and the host's compute devices remain available. A platform without
a complete boundary must refuse workspace-only execution. Linux combines
mount/PID/IPC namespaces, Landlock IPC scopes and seccomp; Landlock filesystem
rules alone are insufficient. Windows low integrity alone does not prevent
personal-file reads and never qualifies as a workspace compute boundary.
"""

from __future__ import annotations

from functools import lru_cache
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
from typing import Sequence


class WorkspaceExecutionUnavailable(RuntimeError):
    """The OS cannot enforce native workspace-only execution."""


# These are software installations, never an entire home or data volume. In
# particular /System would include /System/Volumes/Data on macOS.
_SYSTEM_RUNTIME_ROOTS = (
    "/bin", "/sbin", "/lib", "/lib64",
    "/usr/bin", "/usr/sbin", "/usr/lib", "/usr/libexec", "/usr/share", "/usr/include",
    "/usr/local/bin", "/usr/local/sbin", "/usr/local/lib", "/usr/local/lib64",
    "/usr/local/libexec", "/usr/local/share", "/usr/local/include", "/usr/local/Cellar", "/usr/local/opt",
    "/System/Library", "/System/Applications", "/System/Cryptexes",
    "/Library/Apple", "/Library/Frameworks", "/Library/Developer",
    "/Library/GPUBundles", "/Applications/Xcode.app",
    "/opt/homebrew/bin", "/opt/homebrew/sbin", "/opt/homebrew/lib", "/opt/homebrew/include",
    "/opt/homebrew/libexec", "/opt/homebrew/share", "/opt/homebrew/Cellar",
    "/opt/homebrew/opt", "/opt/homebrew/Frameworks", "/opt/cuda", "/opt/rocm",
    "/usr/local/cuda",
)
_USER_RUNTIME_ROOTS = (
    ".local/bin", ".local/lib", ".local/share/uv/python",
    ".pyenv/versions", ".rbenv/versions", ".nvm/versions",
    ".cargo/bin", ".rustup/toolchains", ".conda/envs",
    "miniconda3", "anaconda3", "miniforge3", ".meshia/runtime",
    "Library/Python",
)
_SYSTEM_CONFIGURATION = (
    "/etc/resolv.conf", "/etc/hosts", "/etc/nsswitch.conf",
    "/etc/localtime", "/etc/services", "/etc/protocols",
    "/etc/ld.so.cache", "/etc/ld.so.conf", "/etc/ld.so.conf.d",
    # TLS runtime inputs are public trust/configuration, not the enclosing
    # SSL/PKI trees: those also contain account-readable private server keys.
    "/etc/ssl/certs", "/etc/ssl/cert.pem", "/etc/ssl/openssl.cnf",
    "/etc/pki/tls/certs", "/etc/pki/tls/cert.pem", "/etc/pki/tls/openssl.cnf",
    "/etc/pki/ca-trust/extracted", "/etc/pki/java/cacerts",
    "/opt/homebrew/etc/openssl@3/certs", "/opt/homebrew/etc/openssl@3/cert.pem",
    "/opt/homebrew/etc/openssl@3/openssl.cnf",
    "/usr/local/etc/openssl@3/certs", "/usr/local/etc/openssl@3/cert.pem",
    "/usr/local/etc/openssl@3/openssl.cnf",
    "/etc/alternatives",
    "/private/var/db/timezone", "/private/var/db/dyld",
    "/private/var/db/DarwinDirectory/local/recordStore.data",
    "/Library/Preferences/com.apple.dt.Xcode.plist",
    "/proc/cpuinfo", "/proc/meminfo", "/proc/loadavg", "/proc/uptime",
    "/proc/version", "/proc/sys/kernel/osrelease", "/sys/devices", "/sys/dev/char",
    "/sys/class/drm", "/sys/module/nvidia", "/proc/driver/nvidia",
    "/dev/random", "/dev/urandom",
)
_PERSONAL_TREES = (
    "Desktop", "Downloads", "Documents", "Pictures", "Movies", "Music",
    ".ssh", ".aws", ".azure", ".config", ".gnupg",
    "Library/Keychains", "Library/Mail", "Library/Messages",
    "Library/Application Support", "Library/Containers",
)


def _within(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def runtime_read_roots(home: Path | None = None) -> tuple[str, ...]:
    """Read-only system/package locations, independent of command arguments.

    Never infer an allowed directory from argv or a task-provided environment:
    asking to execute ``~/Desktop/private.txt`` must not grant Desktop access.
    The node interpreter's own environment is trusted installation metadata.
    """
    home = (home or Path.home()).resolve()
    personal = tuple((home / name).resolve() for name in _PERSONAL_TREES)
    candidates = [Path(path) for path in _SYSTEM_RUNTIME_ROOTS + _SYSTEM_CONFIGURATION]
    candidates += [home / name for name in _USER_RUNTIME_ROOTS]
    if sys.platform == "linux":
        # NVIDIA installs multiple toolkit versions beside the canonical
        # /usr/local/cuda link. This fixed package location is independent of
        # CUDA_HOME, task argv and task environment; personal-target symlinks
        # still pass through the same rejection below.
        try:
            candidates += Path("/usr/local").glob("cuda-[0-9]*")
        except OSError:
            pass
    # Interpreter prefixes can be /usr/local or a Homebrew root. Allow only
    # their software directories, never their etc/var credentials and data.
    prefixes = {Path(sys.prefix), Path(sys.base_prefix)}
    # Managed Python launchers can traverse a version alias that base_prefix
    # has already resolved. dyld still opens the executable and its relative
    # libraries through that alias, so allow its software paths as well. This
    # comes from the running interpreter, never the command's argv or env.
    base_executable = Path(getattr(sys, "_base_executable", sys.executable))
    if base_executable.parent.name == "bin":
        prefixes.add(base_executable.parent.parent)
    for prefix in prefixes:
        candidates += [prefix / name for name in ("bin", "lib", "lib64", "libexec", "include", "share", "pyvenv.cfg")]
    roots: set[str] = set()
    for candidate in candidates:
        try:
            if not candidate.exists():
                continue
            resolved = candidate.resolve()
        except OSError:
            # Optional package locations can be unreadable or absent. Their
            # failure cannot disable otherwise usable installed runtimes.
            continue
        if _within(home, resolved):
            continue
        # A runtime-directory symlink must not become a grant to personal data.
        if any(_within(resolved, denied) for denied in personal):
            continue
        roots.add(str(resolved))
        roots.add(str(candidate.absolute()))
    return tuple(sorted(roots))


def kind() -> str:
    if sys.platform == "win32":
        from .windows_native import KIND
        return KIND
    if sys.platform == "darwin":
        return "macos-seatbelt"
    if sys.platform == "linux":
        from .linux_native import KIND
        return KIND
    return "none"


def _quoted(value: str) -> str:
    # SBPL string escaping has the same quote/backslash escapes. Keep Unicode
    # literal rather than producing JSON's unsupported \uXXXX syntax.
    return json.dumps(value, ensure_ascii=False)


def _macos_profile(workspace: str, readable: Sequence[str]) -> str:
    roots = tuple(dict.fromkeys((workspace, *readable)))
    filters = "\n".join(f"(subpath {_quoted(root)})" for root in roots)
    ancestors = sorted({str(parent) for root in roots for parent in Path(root).parents})
    metadata = "\n".join(f"(literal {_quoted(root)})" for root in ancestors)
    return f"""(version 3)
(deny default)
(import "dyld-support.sb")
(allow syscall* mach-bootstrap system-fcntl)
(allow system-mac-syscall
  (require-all (mac-policy-name "AMFI") (mac-syscall-number 90)))
(allow process-exec process-fork)
(allow process-info* (target self))
(allow signal (target self) (target same-sandbox))
(allow sysctl-read)
(allow file-read* file-test-existence file-map-executable {filters})
(allow file-read-metadata file-test-existence {metadata}
  (literal "/tmp") (literal "/var") (literal "/etc")
  (literal "/var/select/sh") (literal "/private/var/select/sh")
  (literal "/var/select/developer_dir") (literal "/private/var/select/developer_dir")
  (literal "/var/db/xcode_select_link") (literal "/private/var/db/xcode_select_link")
  (literal "/var/run/mDNSResponder") (literal "/private/var/run/mDNSResponder"))
(allow file-read* file-write* file-test-existence file-map-executable
  (subpath {_quoted(workspace)}))
(allow file-read* file-write-data file-test-existence
  (literal "/dev/null") (literal "/dev/zero") (subpath "/dev/fd"))
(allow network-outbound (remote ip)
  (literal "/private/var/run/mDNSResponder"))
(allow network-inbound network-bind (local ip))
(allow network-outbound network-inbound network-bind (subpath {_quoted(workspace)}))
(allow system-socket (socket-domain AF_INET) (socket-domain AF_INET6) (socket-domain AF_UNIX))
(allow socket-option-get socket-option-set)
(allow necp-client-open)
; Named POSIX objects share the host namespace. Library prefixes such as
; /psm_, /torch_ and /mp- also match other applications' private objects.
; Keep them denied; ordinary pipes, forks and workspace Unix sockets work.
(allow mach-lookup
  (global-name "com.apple.system.opendirectoryd.libinfo")
  (global-name "com.apple.system.opendirectoryd.membership")
  (global-name "com.apple.system.DirectoryService.libinfo_v1")
  (global-name "com.apple.system.DirectoryService.membership_v1")
  (global-name "com.apple.dnssd.service")
  (global-name "com.apple.SystemConfiguration.SCNetworkReachability")
  (global-name "com.apple.networkd")
  (global-name "com.apple.trustd")
  (global-name "com.apple.trustd.agent")
  (global-name "com.apple.MTLCompilerService")
  (global-name "com.apple.cvmsServ"))
(allow iokit-get-properties)
(allow iokit-open-service
  (iokit-registry-entry-class "IOAccelerator")
  (iokit-registry-entry-class "IOSurfaceRoot")
  (iokit-registry-entry-class-prefix "AGXAcceleratorG")
  (iokit-registry-entry-class "IOGPU"))
(allow iokit-open-user-client
  (iokit-user-client-class "AGXDeviceUserClient")
  (iokit-user-client-class "AGXSharedUserClient")
  (iokit-user-client-class "AGXCommandQueue")
  (iokit-user-client-class "IOGPUDeviceUserClient")
  (iokit-user-client-class "IOAccelerationUserClient")
  (iokit-user-client-class "IOSurfaceRootUserClient")
  (iokit-user-client-class "IOSurfaceAcceleratorClient"))
"""


@lru_cache(maxsize=1)
def _macos_probe() -> tuple[bool, str]:
    executable = Path("/usr/bin/sandbox-exec")
    if not executable.is_file():
        return False, "macOS native workspace execution requires the system sandbox-exec utility"
    try:
        # A read-only OS directory is sufficient for this no-op probe. No user
        # command receives this profile: each execution gets its actual root.
        result = subprocess.run(
            [str(executable), "-p", _macos_profile("/usr/bin", runtime_read_roots()), "/usr/bin/true"],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError) as error:
        return False, f"macOS native workspace boundary could not start: {type(error).__name__}"
    if result.returncode != 0:
        return False, "macOS refused the native workspace filesystem boundary"
    return True, "Native macOS compute; workspace writes, installed-runtime reads, and IP networking"


def available() -> bool:
    if sys.platform == "win32":
        from .windows_native import available as windows_available
        return windows_available()
    if sys.platform == "darwin":
        return full_available() and _macos_probe()[0]
    if sys.platform == "linux":
        from . import linux_native
        return linux_native.available()
    return False


def full_available() -> bool:
    if sys.platform == "darwin":
        from .macos_native import readiness
        return readiness()[0]
    return sys.platform in ("linux", "win32")


def full_detail() -> str:
    if sys.platform == "darwin":
        from .macos_native import readiness
        return readiness()[1]
    return "Native commands as the installing OS account"


def detail() -> str:
    if sys.platform == "darwin":
        if not full_available():
            return full_detail()
        return _macos_probe()[1]
    if sys.platform == "linux":
        from . import linux_native
        return linux_native.detail()
    if sys.platform == "win32":
        from .windows_native import detail as windows_detail
        return windows_detail()
    return f"Native workspace filesystem isolation is unavailable on {sys.platform}"


def _workspace_environment(env: dict[str, str], workspace: Path) -> dict[str, str]:
    result = dict(env)
    # Existing private HOME/cache/session-bus variables must not accidentally
    # route a library back into the owner's personal environment or OS services.
    for name in ("XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS", "SSH_AUTH_SOCK"):
        result.pop(name, None)
    result.update({
        "HOME": str(workspace), "USERPROFILE": str(workspace),
        "TMPDIR": str(workspace), "TMP": str(workspace), "TEMP": str(workspace),
        "XDG_CACHE_HOME": str(workspace / ".cache"),
        "XDG_CONFIG_HOME": str(workspace / ".config"),
        "XDG_DATA_HOME": str(workspace / ".local/share"),
        "PYTHONDONTWRITEBYTECODE": "1",
    })
    if sys.platform == "linux":
        # Native FUSE workspace files are durable data, not an IPC filesystem.
        # multiprocessing/PyTorch need pathname sockets in private tmpfs.
        result.update({"TMPDIR": "/tmp", "TMP": "/tmp", "TEMP": "/tmp"})
    if sys.platform == "win32":
        result.update({"LOCALAPPDATA": str(workspace / ".local"),
                       "APPDATA": str(workspace / ".config"),
                       "HOMEDRIVE": workspace.drive,
                       "HOMEPATH": str(workspace)[len(workspace.drive):]})
    if sys.platform == "darwin":
        # CoreFoundation otherwise tries the real user's text-encoding file
        # during interpreter startup. Supply the ordinary UTF-8/default locale
        # hint without opening any personal preferences or copying node env.
        result["__CF_USER_TEXT_ENCODING"] = f"0x{os.getuid():X}:0:0"
    return result


def run_workspace_subprocess(
    argv: list[str], *, workspace: str | Path, cwd: str, env: dict[str, str],
    timeout_seconds: int, max_output_bytes: int, stdin: bytes | None = None,
    cancel_event: threading.Event | None = None,
) -> tuple[bytes, int, bool, bool]:
    """Run native code with workspace-only data access; never fall back to full."""
    from .executor import run_bounded_subprocess

    if not available():
        raise WorkspaceExecutionUnavailable(detail())
    if sys.platform in ("win32", "darwin"):
        from .executor import native_environment, run_bounded_subprocess
        from .native_command import command_argv, command_stdin
        directory = Path(cwd).resolve(strict=True)
        root = Path(workspace).resolve(strict=True)
        if not _within(directory, root):
            raise WorkspaceExecutionUnavailable("Workspace-only commands must start inside their attached workspace")
        return run_bounded_subprocess(
            command_argv(list(argv), root=str(root), cwd=directory.relative_to(root).as_posix(), access="limited"),
            cwd=os.path.abspath(os.sep), env=native_environment(),
            timeout_seconds=timeout_seconds, max_output_bytes=max_output_bytes,
            stdin=command_stdin(env, stdin), cancel_event=cancel_event,
        )
    root = Path(workspace).resolve(strict=True)
    directory = Path(cwd).resolve(strict=True)
    if not root.is_dir() or not directory.is_dir() or not _within(directory, root):
        raise WorkspaceExecutionUnavailable("Workspace-only commands must start inside their attached workspace")
    if sys.platform == "linux":
        from . import linux_native
        return linux_native.run_workspace_subprocess(
            argv, workspace=root, cwd=directory, env=env, stdin=stdin,
            timeout_seconds=timeout_seconds, max_output_bytes=max_output_bytes,
            cancel_event=cancel_event,
        )
    raise WorkspaceExecutionUnavailable("Native workspace execution is unavailable on this OS")


__all__ = ["WorkspaceExecutionUnavailable", "available", "detail", "full_available",
           "full_detail", "kind", "run_workspace_subprocess"]
