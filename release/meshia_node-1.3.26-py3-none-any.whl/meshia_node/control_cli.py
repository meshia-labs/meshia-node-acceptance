"""Small human CLI over the same tool contracts desktop agents use."""
from __future__ import annotations

import argparse
import json
import os
import shlex
import sys
import uuid
from pathlib import Path

from .config import ConfigStore, Paths
from .control import ControlClient, ControlError, message_receipt_matches, request_json


def add_commands(sub) -> None:
    def command(name, help):
        parser = sub.add_parser(name, help=help)
        parser.add_argument("--json", action="store_true", default=argparse.SUPPRESS)
        return parser

    login = command("login", "Sign in once for project controls and desktop MCP.")
    login.add_argument("--api-url", default="https://meshia.io")
    login.add_argument("--no-browser", action="store_true")
    command("logout", "Revoke this computer's account token (mount enrollment is separate).")
    command("account", "Verify the connected account live.")
    projects = command("projects", "List personal and team projects.")
    projects.add_argument("--cursor")
    projects.add_argument("--limit", type=int, default=10)
    project = command("project", "Create or inspect a project.")
    actions = project.add_subparsers(dest="action", required=True)
    create = actions.add_parser("create", help="Create a project without starting compute.")
    create.add_argument("name")
    create.add_argument("--budget-cents", type=int, default=1000)
    show = actions.add_parser("show", help="Inspect a project.")
    show.add_argument("workspace_id")
    for name, help in [("send", "Send a durable turn to the project's driving agent."),
                       ("messages", "Read saved conversation history."),
                       ("watch", "Wait for changes; Ctrl-C detaches without cancelling remote work."),
                       ("threads", "List durable project conversation threads.")]:
        parser = command(name, help)
        parser.add_argument("workspace_id")
        if name != "threads":
            parser.add_argument("--thread", dest="thread_id")
        if name == "send":
            parser.add_argument("message", nargs="?", help="Omit to read the message from stdin.")
            parser.add_argument("--request-id", help="Stable UUID for recovering an ambiguous send.")
        if name == "messages":
            parser.add_argument("--limit", type=int, default=30)
            parser.add_argument("--offset", type=int, default=0)
        if name == "watch":
            parser.add_argument("--cursor")
            parser.add_argument("--once", action="store_true")
    sync = command("sync", "Save an explicitly supplied JSON transcript into the project ledger.")
    sync.add_argument("workspace_id")
    sync.add_argument("file", help="JSON array of messages, or - for stdin; each message requires a stable UUID id.")
    sync.add_argument("--thread", dest="thread_id")
    tools = command("tools", "Discover every Meshia capability and its exact input schema.")
    tools.add_argument("name", nargs="?")
    call = command("call", "Call any Meshia tool with a JSON object from stdin or --file.")
    call.add_argument("name")
    call.add_argument("--file", default="-")
    agents = command("agents", "Inspect or start durable remote agent runs.")
    agents.add_argument("workspace_id")
    agents.add_argument("--run", dest="run_id")
    agents.add_argument("--start", metavar="PLAN.json", help="Run plan containing goal, workers, artifacts and budget.")
    host = command("host", "Link a Codex conversation for automatic history sync and native callbacks.")
    actions = host.add_subparsers(dest="action", required=True)
    install = actions.add_parser("install", help="Install Codex hooks and MCP together; preserves existing settings.")
    install.add_argument("client", choices=["codex"])
    install.add_argument("--codex-home", default=os.environ.get("CODEX_HOME", str(Path.home() / ".codex")))
    for action in ("link", "status", "unlink", "watch", "renew"):
        parser = actions.add_parser(action, help={"link": "Share this selected conversation with a project.", "status": "Inspect sync and callback delivery.", "unlink": "Stop sharing and watching; retain saved history.", "watch": "Run the bounded callback observer.", "renew": "Renew the bounded callback watch."}[action])
        parser.add_argument("--session", help="Exact Codex conversation UUID; defaults to CODEX_THREAD_ID.")
        if action in ("link", "renew"):
            parser.add_argument("--watch-minutes", type=int, default=60, help="Bounded native callback watch, at most 1440 minutes.")
        if action == "link":
            parser.add_argument("workspace_id")
            parser.add_argument("--thread", dest="thread_id")
            parser.add_argument("--include-tools", action="store_true", help="Also share visible tool inputs/outputs, which may include file contents.")
            parser.add_argument("--codex-home", default=os.environ.get("CODEX_HOME", str(Path.home() / ".codex")))
    actions.add_parser("hook", help=argparse.SUPPRESS)


def read_json(path: str):
    try:
        if path == "-":
            raw = sys.stdin.read(4 * 1024 * 1024 + 1)
        else:
            with Path(path).open(encoding="utf-8") as stream:
                raw = stream.read(4 * 1024 * 1024 + 1)
        if len(raw.encode()) > 4 * 1024 * 1024:
            raise ControlError("Input exceeds the 4 MiB limit.")
        return json.loads(raw)
    except (ValueError, OSError):
        raise ControlError("Input must be a readable UTF-8 JSON document.") from None


def emit(value, as_json: bool = False) -> None:
    # JSON is also the fallback for uncommon capabilities. Common actions have
    # a compact human view; never hide a failed tool behind a success sentence.
    if not as_json and isinstance(value, dict) and value.get("schema") == "meshia.workspaces.compact.v1":
        projects = value.get("sessions", []) + value.get("team_sessions", [])
        if not projects:
            print("No projects yet. Create one with meshia project create \"Project name\".")
        for project in projects:
            print(f"{project.get('id', '')}  {project.get('name', 'Project')}  {project.get('status', '')}")
        page = value.get("page") or {}
        if page.get("next_cursor"):
            print(f"Next: meshia projects --cursor {shlex.quote(str(page['next_cursor']))}")
        return
    print(json.dumps(value, ensure_ascii=False, indent=2 if not as_json else None), flush=True)


def sync_transcript(client: ControlClient, workspace_id: str, thread_id: str | None, messages) -> dict:
    if not isinstance(messages, list) or not 1 <= len(messages) <= 200:
        raise ControlError("Transcript must contain 1–200 messages per batch.")
    prepared = []
    ids = set()
    for message in messages:
        if not isinstance(message, dict) or set(message) - {"id", "role", "content", "tool_calls", "message_parts"}:
            raise ControlError("Each transcript message accepts id, role, content, tool_calls and message_parts only.")
        try:
            message_id = str(uuid.UUID(message["id"]))
        except (KeyError, ValueError, TypeError, AttributeError):
            raise ControlError("Every transcript message requires a stable UUID id; reuse the same file to resume.") from None
        if message_id in ids or message.get("role") not in ("user", "assistant", "tool") or not isinstance(message.get("content"), str):
            raise ControlError("Transcript IDs must be unique, roles user/assistant/tool, and content text.")
        if len(message["content"]) > 100 * 1024:
            raise ControlError("Transcript message exceeds the content limit.")
        ids.add(message_id)
        prepared.append({"workspace_id": workspace_id, "message_id": message_id,
                         **{k: v for k, v in message.items() if k != "id"},
                         **({"thread_id": thread_id} if thread_id else {})})
    saved = []
    for message in prepared:
        try:
            result = client.tool("meshia_message_append", message)
        except ControlError:
            return {"ok": False, "saved_ids": saved, "uncertain_id": message["message_id"],
                    "next": "Read messages to resolve the uncertain append. Reuse the same IDs to resume safely."}
        if isinstance(result, dict) and result.get("ok") is False:
            return {"ok": False, "saved_ids": saved, "failed_id": message["message_id"], "error": result}
        if not message_receipt_matches(result, workspace_id, message["message_id"]):
            return {"ok": False, "saved_ids": saved, "uncertain_id": message["message_id"],
                    "next": "The acknowledgement did not identify the saved message. Read messages before resuming with the same IDs."}
        saved.append(message["message_id"])
    return {"ok": True, "saved_ids": saved, "saved_count": len(saved), "scope": "explicitly_supplied_transcript"}


def command_control(args: argparse.Namespace, paths: Paths) -> int:
    if args.command == "host":
        from .host import command_host
        return command_host(args, paths)
    client = ControlClient(paths)
    name = args.command
    if name == "login":
        result = client.login(args.api_url, open_browser=not args.no_browser)
    elif name == "logout":
        result = client.logout()
    elif name == "account":
        result = client.tool("meshia_account_get")
    elif name == "projects":
        result = client.tool("meshia_workspaces_list", {"limit": args.limit, **({"cursor": args.cursor} if args.cursor else {})})
    elif name == "project":
        result = client.tool("meshia_workspace_create", {"name": args.name, "workspace_total_budget_cents": args.budget_cents}) if args.action == "create" else client.tool("meshia_workspace_get", {"workspace_id": args.workspace_id})
    elif name == "tools":
        reply = client.rpc("tools/list")
        if "error" in reply:
            raise ControlError("Tool discovery failed.")
        catalog = reply["result"]["tools"]
        result = next((t for t in catalog if t["name"] == args.name), None) if args.name else catalog
        if result is None:
            raise ControlError("Tool not found; run meshia tools.")
    elif name == "call":
        arguments = read_json(args.file)
        if not isinstance(arguments, dict):
            raise ControlError("Tool arguments must be a JSON object.")
        result = client.tool(args.name, arguments)
    elif name == "sync":
        result = sync_transcript(client, args.workspace_id, args.thread_id, read_json(args.file))
    else:
        arguments = {"workspace_id": args.workspace_id}
        if getattr(args, "thread_id", None):
            arguments["thread_id"] = args.thread_id
        if name == "send":
            message = args.message if args.message is not None else sys.stdin.read(10_001)
            if not message.strip() or len(message) > 10_000:
                raise ControlError("Send requires 1–10000 characters.")
            try:
                request_id = str(uuid.UUID(args.request_id)) if args.request_id else str(uuid.uuid4())
            except ValueError:
                raise ControlError("--request-id must be a UUID.") from None
            print(f"Turn ID: {request_id} (retain for recovery)", file=sys.stderr)
            result = client.tool("meshia_agent_turn", {**arguments, "message": message, "client_message_id": request_id})
        elif name == "messages":
            result = client.tool("meshia_messages_list", {**arguments, "limit": args.limit, "offset": args.offset})
        elif name == "threads":
            result = client.tool("meshia_threads_list", arguments)
        elif name == "agents":
            if args.start and args.run_id:
                raise ControlError("Choose either --start or --run.")
            if args.start:
                plan = read_json(args.start)
                if not isinstance(plan, dict) or "workspace_id" in plan:
                    raise ControlError("Agent plan must be an object; the workspace is selected by the command.")
                result = client.tool("meshia_swarm_run_create", {**plan, **arguments})
            else:
                result = client.tool("meshia_swarm_run_get", {**arguments, "run_id": args.run_id, "detail_level": "full"}) if args.run_id else client.tool("meshia_swarm_runs_list", arguments)
        elif name == "watch":
            cursor = args.cursor
            while True:
                result = client.tool("meshia_project_updates", {**arguments, "wait_seconds": 25 if cursor else 0, **({"cursor": cursor} if cursor else {})})
                if result.get("ok") is False:
                    emit(result, args.json)
                    return 1
                if result.get("changed") or args.once:
                    emit(result, args.json)
                cursor = result["cursor"]
                if args.once:
                    return 0
        else:
            raise ControlError("Unknown control command.")
    emit(result, args.json)
    return 1 if isinstance(result, dict) and result.get("ok") is False else 0


def command_mount(args: argparse.Namespace, paths: Paths, client: ControlClient) -> int:
    # Reuse enrollment and the existing supervised service. Do not re-pair or
    # interrupt a live mount to switch accounts/projects implicitly.
    from .cli import build_parser, command_connect, command_service, command_status
    existing = ConfigStore(paths).load()
    if args.workspace_id:
        try:
            uuid.UUID(args.workspace_id)
        except ValueError:
            raise ControlError("Project ID must be a UUID.") from None
    if existing:
        if args.workspace_id and args.workspace_id != existing.session_id:
            raise ControlError("This installation is already enrolled. Use meshia open to browse its project catalog; switching the enrollment requires an explicit disconnect/re-pair.")
        if existing.lifecycle == "disconnected":
            if existing.disconnect_reason in (None, "USER_DISCONNECTED"):
                raise ControlError("The mount is parked. Run meshia connect to explicitly reconnect its existing identity.")
            raise ControlError("This device was disconnected from Meshia. Reconnect with a new pairing token from the workspace.")
    else:
        if not args.workspace_id:
            raise ControlError("Choose a project from meshia projects, then run meshia mount <project-id>.")
        value = client.authorized()
        paired = request_json(value["origin"] + "/api/connected-hosts/pairing", token=value["access_token"],
                              body={"session_id": args.workspace_id, "access_mode": "files"})
        if not isinstance(paired.get("pairing_code"), str):
            raise ControlError("Meshia did not return a pairing grant.")
        connect = build_parser().parse_args(["connect", "--enroll-only", "--native-mount", "--access", "files", "--api-url", value["origin"]])
        connect.pairing_code = paired["pairing_code"] # Memory only; never argv, logs, shell history or MCP output.
        connect.json = args.json
        if command_connect(connect, paths):
            return 1
    client.link_device_if_present()
    for action in ("install", "start"):
        service = build_parser().parse_args(["service", action])
        service.json = args.json
        if command_service(service, paths):
            return 1
    status = build_parser().parse_args(["status"])
    status.json = args.json
    return command_status(status, paths)


CONTROL_COMMANDS = ("login", "logout", "account", "projects", "project", "send", "messages", "watch", "threads", "sync", "tools", "call", "agents", "host")
