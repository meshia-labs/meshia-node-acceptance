"""Meshia object edge client (``files.meshia.io``) and scoped-token registry.

The control plane hands every attach/heartbeat receipt an ``object_edge``
grant: a short-lived, prefix-scoped Ed25519 token for the Meshia-domain object
edge. With a grant present the node moves object bytes without any signed
control call:

* reads: ``GET <url>/o/<key>`` with ``Range`` (206 + exact ``Content-Range``);
* CAS uploads: ``PUT <url>/o/<prefix>.meshiafabric/connected-host/blocks/
  sha256/<xx>/<sha256>.block`` with ``x-meshia-sha256`` (the edge verifies the
  digest); the commit (``mutate`` with ``verify_blocks`` + ``direct_blocks``)
  remains the single control call per file.

Tokens are bearer capabilities: they are never logged, never persisted, and
only their token-free metadata (host, expiry, permissions) reaches the
``meshia-node status`` snapshot on disk.
"""

from __future__ import annotations

import base64
import hashlib
import json
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Mapping

from .errors import NetworkError
from .fabric_contract_generated import cas_block_path, parse_content_range, verify_block_range_response
from .http_pool import HttpsConnectionPool
from .log import NULL_LOGGER, NodeLogger
from .util import RAW_SHA256_RE, write_private_file

OBJECT_EDGE_SCHEME = "Meshia-Object"
OBJECT_EDGE_HEADER_NAME = "x-meshia-edge"
UPLOAD_PART_RECEIPT_SCHEMA = "meshia.connected_host_fabric_upload_part_receipt.v1"
LEGACY_OBJECT_CAS_KIND = "object_cas_v1"
CONNECTED_HOST_OBJECT_CAS_KIND = "connected_host_object_cas_v1"
DEFAULT_READ_TIMEOUT_SECONDS = 5 * 60.0
DEFAULT_PUT_TIMEOUT_SECONDS = 15 * 60.0
MAX_RANGE_BYTES = 64 * 1_048_576
MAX_PUT_BYTES = 64 * 1_048_576
MAX_ERROR_BODY_BYTES = 16 * 1024
MAX_TOKEN_CHARS = 4_096
MAX_TOKEN_LIFETIME_SECONDS = 900
# A grant this close to expiry is not used for a new transfer; every
# heartbeat (30 s cadence) renews the token far earlier than this.
GRANT_USE_MARGIN_SECONDS = 20.0
_GRANT_KEYS = frozenset({"url", "token", "expires_at", "kid"})


class ObjectEdgeError(NetworkError):
    """Base class for every object-edge failure."""


class ObjectEdgeAuthExpired(ObjectEdgeError):
    """The edge rejected the token (401); a fresh heartbeat grant is needed."""


class ObjectEdgeDenied(ObjectEdgeError):
    """The edge refused the key/method for this token (403). Permanent."""


class ObjectEdgeUnavailable(ObjectEdgeError):
    """Transport failure or 5xx/429; tickets remain the fallback."""


class ObjectEdgeNotFound(ObjectEdgeError):
    """The object does not exist at the edge (404)."""


class ObjectEdgeDigestMismatch(ObjectEdgeError):
    """A definitive PUT rejection (422/4xx): the bytes or key are wrong."""


class ObjectEdgeUnprovenRange(ObjectEdgeError):
    """A legacy block needs full-object hashing before a slice can be used."""


@dataclass(frozen=True)
class ObjectEdgeGrant:
    """One parsed, token-free-loggable edge capability for a workspace."""

    url: str
    token: str
    expires_at: float
    kid: str
    prefix: str
    perms: frozenset[str]
    cas_only: bool
    max_put_bytes: int
    session_id: str
    attachment_id: str | None

    @property
    def host(self) -> str:
        return urllib.parse.urlsplit(self.url).netloc

    def remaining(self, now: float) -> float:
        return self.expires_at - now

    def usable(self, now: float, permission: str) -> bool:
        return permission in self.perms and self.remaining(now) > GRANT_USE_MARGIN_SECONDS

    def metadata(self, now: float) -> dict[str, Any]:
        """Token-free projection for status and logs."""

        return {
            "host": self.host,
            "kid": self.kid,
            "perms": sorted(self.perms),
            "expires_at": _iso(self.expires_at),
            "expires_in_seconds": max(0, int(self.remaining(now))),
        }


@dataclass(frozen=True)
class ObjectEdgeHead:
    size_bytes: int
    sha256: str | None
    etag: str | None


def _iso(epoch: float) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(epoch))


def _parse_expiry(value: object, *, now: float) -> float:
    if not isinstance(value, str) or len(value) > 64:
        raise NetworkError("Meshia returned an invalid object edge expiry.")
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)
        if parsed.tzinfo is None or parsed.utcoffset() != timedelta(0):
            raise ValueError("object edge expiry must identify UTC")
        expiry = parsed.timestamp()
    except (ValueError, OverflowError):
        raise NetworkError("Meshia returned an invalid object edge expiry.") from None
    if expiry <= now or expiry > now + MAX_TOKEN_LIFETIME_SECONDS + 60:
        raise NetworkError("The object edge grant is expired or has an excessive lifetime.")
    return expiry


def _b64url_decode(segment: str) -> bytes:
    if not segment or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_" for c in segment):
        raise NetworkError("Meshia returned a malformed object edge token.")
    padding = "=" * (-len(segment) % 4)
    try:
        return base64.urlsafe_b64decode(segment + padding)
    except (ValueError, TypeError):
        raise NetworkError("Meshia returned a malformed object edge token.") from None


def validate_object_edge_url(url: object, *, allow_insecure_loopback: bool = False) -> str:
    """Accept only a bare ``https://host[:port]`` origin (loopback http in tests)."""

    if not isinstance(url, str) or not 1 <= len(url) <= 512 or any(ord(c) <= 0x20 or ord(c) == 0x7F for c in url):
        raise NetworkError("Meshia returned an unsafe object edge URL.")
    try:
        parts = urllib.parse.urlsplit(url)
        host = (parts.hostname or "").lower()
        port = parts.port
    except ValueError:
        raise NetworkError("Meshia returned an unsafe object edge URL.") from None
    loopback_http = (
        allow_insecure_loopback
        and parts.scheme == "http"
        and host in {"localhost", "127.0.0.1", "::1"}
    )
    https = parts.scheme == "https" and bool(host) and (port is None or port == 443)
    if (
        not (loopback_http or https)
        or parts.username is not None
        or parts.password is not None
        or parts.query
        or parts.fragment
        or parts.path not in ("", "/")
    ):
        raise NetworkError("Meshia returned an unsafe object edge URL.")
    return f"{parts.scheme}://{parts.netloc}"


def parse_object_edge_grant(
    document: object,
    *,
    session_id: str,
    attachment_id: str | None,
    now: float,
    allow_insecure_loopback: bool = False,
) -> ObjectEdgeGrant:
    """Validate one ``object_edge`` receipt field (structure only; no signature).

    The node cannot verify the Ed25519 signature (it has no need to: the edge
    does). It only checks that the payload scopes what the node will use it
    for, so a corrupted or foreign grant is refused before any byte moves.
    """

    if not isinstance(document, Mapping) or set(document) != _GRANT_KEYS:
        raise NetworkError("Meshia returned an invalid object edge grant.")
    url = validate_object_edge_url(document["url"], allow_insecure_loopback=allow_insecure_loopback)
    token = document["token"]
    kid = document["kid"]
    if (
        not isinstance(token, str)
        or not 1 <= len(token) <= MAX_TOKEN_CHARS
        or token.count(".") != 2
        or not isinstance(kid, str)
        or not 1 <= len(kid) <= 64
    ):
        raise NetworkError("Meshia returned an invalid object edge grant.")
    header_segment, payload_segment, signature_segment = token.split(".")
    try:
        header = json.loads(_b64url_decode(header_segment).decode("utf-8"))
        payload = json.loads(_b64url_decode(payload_segment).decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise NetworkError("Meshia returned a malformed object edge token.") from None
    if len(_b64url_decode(signature_segment)) != 64:
        raise NetworkError("Meshia returned a malformed object edge token.")
    if (
        not isinstance(header, dict)
        or header.get("v") != 1
        or header.get("alg") != "Ed25519"
        or header.get("kid") != kid
        or not isinstance(payload, dict)
    ):
        raise NetworkError("Meshia returned an unsupported object edge token.")
    prefix = payload.get("prefix")
    perms = payload.get("perms")
    expires_at = _parse_expiry(document["expires_at"], now=now)
    exp = payload.get("exp")
    max_put = payload.get("max_put_bytes")
    if (
        payload.get("iss") != "meshia.io"
        or payload.get("sid") != session_id
        or (attachment_id is not None and payload.get("aid") not in (None, attachment_id))
        or not isinstance(prefix, str)
        or not prefix.endswith("/")
        or prefix.startswith("/")
        or ".." in prefix.split("/")
        or not isinstance(perms, list)
        or not perms
        or any(item not in ("read", "write") for item in perms)
        or "read" not in perms
        or not isinstance(payload.get("cas_only"), bool)
        or isinstance(exp, bool)
        or not isinstance(exp, int)
        or abs(exp - expires_at) > 1.0
        or isinstance(max_put, bool)
        or not isinstance(max_put, int)
        or not 0 <= max_put <= MAX_PUT_BYTES
    ):
        raise NetworkError("Meshia returned an object edge token for another scope.")
    return ObjectEdgeGrant(
        url=url,
        token=token,
        expires_at=expires_at,
        kid=kid,
        prefix=prefix,
        perms=frozenset(perms),
        cas_only=bool(payload["cas_only"]),
        max_put_bytes=max_put,
        session_id=session_id,
        attachment_id=attachment_id,
    )


# ------------------------------------------------------------------ keys


def object_edge_block_key(prefix: str, sha256: str, storage_kind: str = CONNECTED_HOST_OBJECT_CAS_KIND) -> str:
    """Canonical CAS object key for one block under the grant prefix."""
    try:
        return f"{prefix}{cas_block_path(storage_kind, sha256)}"
    except ValueError:
        raise ValueError("a CAS block key needs a supported layout and raw SHA-256 digest") from None


def object_edge_path_key(prefix: str, path: str) -> str:
    """Whole-object key for a workspace path (browser/MCP uploads)."""

    normalized = path.replace("\\", "/").strip("/")
    while "//" in normalized:
        normalized = normalized.replace("//", "/")
    if not normalized or any(part in ("", ".", "..") for part in normalized.split("/")):
        raise ValueError("a workspace path must be relative and normalized")
    return f"{prefix}{normalized}"


def _quote_key(key: str) -> str:
    return "/".join(urllib.parse.quote(part, safe="") for part in key.split("/"))


# ---------------------------------------------------------------- client


def _parse_content_range(value: object) -> tuple[int, int, int] | None:
    return parse_content_range(value)


def _read_bounded(response: Any, maximum: int) -> bytes:
    try:
        body = response.read(maximum + 1)
    except OSError:
        raise ObjectEdgeUnavailable("The Meshia object edge ended its response unexpectedly.") from None
    finally:
        response.close()
    if not isinstance(body, bytes) or len(body) > maximum:
        raise ObjectEdgeUnavailable("The Meshia object edge returned an oversized response.")
    return body


def _error_code(body: bytes) -> str:
    try:
        document = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        return ""
    code = document.get("code") if isinstance(document, dict) else None
    return code if isinstance(code, str) and len(code) <= 64 else ""


class ObjectEdgeClient:
    """Blocking, stdlib-only HTTP client for one edge origin.

    ``token_provider`` returns the current grant (or ``None``). Every request
    carries ``Authorization: Meshia-Object <token>``; the pool retries a stale
    keep-alive socket once. Callers apply their own deadline runners.
    """

    def __init__(
        self,
        url: str,
        token_provider: Callable[[], ObjectEdgeGrant | None],
        *,
        pool: HttpsConnectionPool | None = None,
        read_timeout: float = DEFAULT_READ_TIMEOUT_SECONDS,
        put_timeout: float = DEFAULT_PUT_TIMEOUT_SECONDS,
        allow_insecure_loopback: bool = False,
        now: Callable[[], float] = time.time,
    ) -> None:
        self.url = validate_object_edge_url(url, allow_insecure_loopback=allow_insecure_loopback)
        self._token_provider = token_provider
        self._pool = pool or HttpsConnectionPool(
            max_idle_per_host=16, allow_insecure_loopback=allow_insecure_loopback
        )
        self._read_timeout = float(read_timeout)
        self._put_timeout = float(put_timeout)
        self._now = now
        self._traffic_lock = threading.Lock()
        self.received_bytes = 0
        self.transmitted_bytes = 0
        self.requests = 0

    def close(self) -> None:
        self._pool.close()

    # ------------------------------------------------------------ requests

    def _grant(self, permission: str) -> ObjectEdgeGrant:
        grant = self._token_provider()
        if grant is None or grant.url != self.url:
            raise ObjectEdgeAuthExpired("No object edge grant is available for this workspace.")
        if not grant.usable(float(self._now()), permission):
            if permission not in grant.perms:
                raise ObjectEdgeDenied("The object edge grant does not permit this operation.")
            raise ObjectEdgeAuthExpired("The object edge grant is about to expire.")
        return grant

    def _open(
        self,
        method: str,
        key: str,
        *,
        grant: ObjectEdgeGrant,
        headers: Mapping[str, str],
        body: bytes | None,
        timeout: float,
    ) -> Any:
        if not key.startswith(grant.prefix):
            raise ObjectEdgeDenied("The object key is outside the grant prefix.")
        request = urllib.request.Request(
            f"{self.url}/o/{_quote_key(key)}",
            data=body,
            method=method,
            headers={
                **dict(headers),
                "authorization": f"{OBJECT_EDGE_SCHEME} {grant.token}",
                "accept": "*/*",
            },
        )
        try:
            response = self._pool.open(request, timeout=timeout)
        except OSError:
            # The request object retains the bearer token: never chain it.
            raise ObjectEdgeUnavailable("The Meshia object edge is unreachable.") from None
        with self._traffic_lock:
            self.requests += 1
        status = getattr(response, "status", None)
        if isinstance(status, int) and 200 <= status < 300:
            return response
        try:
            code = _error_code(_read_bounded(response, MAX_ERROR_BODY_BYTES))
        except ObjectEdgeError:
            code = ""
        self._raise_for_status(status, code, method)
        raise ObjectEdgeUnavailable("The Meshia object edge returned an invalid response.")

    @staticmethod
    def _raise_for_status(status: object, code: str, method: str) -> None:
        detail = f" ({code})" if code else ""
        if status == 401:
            raise ObjectEdgeAuthExpired(f"The object edge rejected the token{detail}.")
        if status == 403:
            raise ObjectEdgeDenied(f"The object edge denied the request{detail}.")
        if status == 404:
            raise ObjectEdgeNotFound(f"The object is not at the edge{detail}.")
        if status in (408, 429) or (isinstance(status, int) and status >= 500):
            raise ObjectEdgeUnavailable(f"The object edge is temporarily unavailable (HTTP {status}){detail}.")
        if status in (411, 413):
            # OBJECT_LENGTH_REQUIRED / OBJECT_TOO_LARGE: this token cannot carry
            # the block; tickets remain the lane for it.
            raise ObjectEdgeDenied(f"The object edge cannot accept this upload (HTTP {status}){detail}.")
        if method == "PUT" and isinstance(status, int) and 400 <= status < 500:
            raise ObjectEdgeDigestMismatch(f"The object edge rejected the upload (HTTP {status}){detail}.")
        raise ObjectEdgeUnavailable(f"The object edge returned HTTP {status}{detail}.")

    # ---------------------------------------------------------------- ops

    def head(self, key: str) -> ObjectEdgeHead:
        grant = self._grant("read")
        response = self._open("HEAD", key, grant=grant, headers={}, body=None, timeout=self._read_timeout)
        try:
            length = response.headers.get("content-length")
            digest = (response.headers.get("x-meshia-sha256") or "").strip().lower() or None
            etag = (response.headers.get("etag") or "").strip() or None
        finally:
            response.close()
        if length is None or not length.strip().isdigit():
            raise ObjectEdgeUnavailable("The object edge HEAD carried no content length.")
        if digest is not None and RAW_SHA256_RE.fullmatch(digest) is None:
            digest = None
        return ObjectEdgeHead(size_bytes=int(length.strip()), sha256=digest, etag=etag)

    def read_range(self, key: str, offset: int, length: int, *, total_size: int | None = None,
                   expected_sha256: str | None = None) -> bytes:
        """Return exactly ``length`` bytes at ``offset`` (206 + exact Content-Range).

        A ``200`` is accepted only for a whole-object read (offset 0 and
        ``length == total_size``). ``total_size`` (the manifest size) is
        cross-checked against ``Content-Range`` so a replaced object never
        masquerades as the manifest version.
        """

        if (
            isinstance(offset, bool)
            or isinstance(length, bool)
            or not isinstance(offset, int)
            or not isinstance(length, int)
            or offset < 0
            or not 1 <= length <= MAX_RANGE_BYTES
            or (total_size is not None and offset + length > total_size)
        ):
            raise ValueError("The object range is invalid.")
        grant = self._grant("read")
        end = offset + length - 1
        response = self._open(
            "GET",
            key,
            grant=grant,
            headers={"range": f"bytes={offset}-{end}"},
            body=None,
            timeout=self._read_timeout,
        )
        status = getattr(response, "status", None)
        if expected_sha256 is not None:
            try:
                proven = verify_block_range_response(response.headers, status,
                    sha256=expected_sha256, size=total_size, offset=offset, length=length, edge=True)
            except ValueError as error:
                response.close()
                raise ObjectEdgeDigestMismatch(str(error)) from None
            if not proven:
                response.close()
                raise ObjectEdgeUnprovenRange("The block has no provider checksum receipt.")
        content_range = _parse_content_range(response.headers.get("content-range"))
        claimed = response.headers.get("content-length")
        whole = offset == 0 and total_size is not None and length == total_size
        if status == 206:
            valid = content_range is not None and content_range[0] == offset and content_range[1] == end and (
                total_size is None or content_range[2] == total_size
            )
        elif status == 200:
            valid = whole and content_range is None
        else:
            valid = False
        if valid and claimed is not None:
            valid = claimed.strip() == str(length)
        if not valid:
            response.close()
            raise ObjectEdgeUnavailable("The object edge returned a range that does not match the request.")
        data = _read_bounded(response, length)
        if len(data) != length:
            raise ObjectEdgeUnavailable("The object edge ended its range early.")
        with self._traffic_lock:
            self.received_bytes += len(data)
        return data

    def put_cas(
        self,
        sha256: str,
        data: bytes,
        *,
        storage_kind: str = CONNECTED_HOST_OBJECT_CAS_KIND,
    ) -> dict[str, Any]:
        """PUT one immutable CAS block; returns an upload-part receipt."""

        if not isinstance(data, bytes):
            raise NetworkError("A CAS block upload must contain exact bytes.")
        digest = sha256.strip().lower()
        if RAW_SHA256_RE.fullmatch(digest) is None or hashlib.sha256(data).hexdigest() != digest:
            raise NetworkError("A CAS block upload failed local digest verification.")
        grant = self._grant("write")
        if len(data) > grant.max_put_bytes:
            raise ObjectEdgeDenied("The block exceeds the grant's maximum PUT size.")
        if grant.cas_only and storage_kind != CONNECTED_HOST_OBJECT_CAS_KIND:
            raise ObjectEdgeDenied("The grant permits canonical connected-host CAS keys only.")
        key = object_edge_block_key(grant.prefix, digest, storage_kind)
        response = self._open(
            "PUT",
            key,
            grant=grant,
            headers={
                "content-type": "application/octet-stream",
                "content-length": str(len(data)),
                "x-meshia-sha256": digest,
                "x-meshia-size-bytes": str(len(data)),
            },
            body=data,
            timeout=self._put_timeout,
        )
        status = getattr(response, "status", None)
        body = _read_bounded(response, MAX_ERROR_BODY_BYTES)
        outcome = "stored"
        if status == 200:
            outcome = "canonical_exists"
        try:
            document = json.loads(body.decode("utf-8")) if body else {}
        except (UnicodeDecodeError, ValueError):
            document = {}
        if isinstance(document, dict):
            if document.get("existing") is True:
                outcome = "canonical_exists"
            returned = document.get("sha256")
            size = document.get("size_bytes")
            if (isinstance(returned, str) and returned.lower() != digest) or (
                isinstance(size, int) and not isinstance(size, bool) and size != len(data)
            ):
                raise ObjectEdgeDigestMismatch("The object edge stored a different object than was sent.")
        with self._traffic_lock:
            self.transmitted_bytes += len(data)
        return {
            "schema": UPLOAD_PART_RECEIPT_SCHEMA,
            "sha256": digest,
            "size_bytes": len(data),
            "outcome": outcome,
        }


# -------------------------------------------------------------- registry


class ObjectEdgeRegistry:
    """Process-wide grants keyed by workspace session, fed by attach/heartbeat.

    ``disable`` records a process-lifetime fallback (tickets) for a session
    after the edge proved unusable; a later grant does not lift it, matching
    the design's "fall back for the rest of the process lifetime".
    """

    def __init__(
        self,
        *,
        status_path: Path | None = None,
        allow_insecure_loopback: bool = False,
        now: Callable[[], float] = time.time,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        self._lock = threading.Lock()
        self._grants: dict[str, ObjectEdgeGrant] = {}
        self._disabled: dict[str, str] = {}
        self._clients: dict[str, ObjectEdgeClient] = {}
        self._status_path = status_path
        self._allow_insecure_loopback = allow_insecure_loopback
        self._now = now
        self._logger = logger
        self._listeners: list[Callable[[str], None]] = []

    def configure(
        self,
        *,
        status_path: Path | None = None,
        allow_insecure_loopback: bool | None = None,
        logger: NodeLogger | None = None,
        now: Callable[[], float] | None = None,
    ) -> None:
        with self._lock:
            if status_path is not None:
                self._status_path = status_path
            if allow_insecure_loopback is not None:
                self._allow_insecure_loopback = allow_insecure_loopback
            if logger is not None:
                self._logger = logger
            if now is not None:
                self._now = now

    @property
    def allow_insecure_loopback(self) -> bool:
        return self._allow_insecure_loopback

    def add_listener(self, listener: Callable[[str], None]) -> None:
        with self._lock:
            self._listeners.append(listener)

    def observe(
        self,
        session_id: str,
        document: object,
        *,
        attachment_id: str | None = None,
    ) -> ObjectEdgeGrant | None:
        """Record the ``object_edge`` field of one receipt (``None`` clears it)."""

        now = float(self._now())
        grant: ObjectEdgeGrant | None = None
        if document is not None:
            try:
                grant = parse_object_edge_grant(
                    document,
                    session_id=session_id,
                    attachment_id=attachment_id,
                    now=now,
                    allow_insecure_loopback=self._allow_insecure_loopback,
                )
            except NetworkError as error:
                self._logger.record(
                    "object_edge_grant_rejected",
                    session_id=session_id,
                    error=str(error)[:200],
                )
                grant = None
        with self._lock:
            previous = self._grants.get(session_id)
            if grant is None:
                self._grants.pop(session_id, None)
            else:
                self._grants[session_id] = grant
            listeners = list(self._listeners)
        if grant is not None and (previous is None or previous.url != grant.url or previous.perms != grant.perms):
            self._logger.record(
                "object_edge_grant_observed",
                session_id=session_id,
                **grant.metadata(now),
            )
        elif grant is None and previous is not None:
            self._logger.record("object_edge_grant_withdrawn", session_id=session_id)
        self._persist()
        for listener in listeners:
            try:
                listener(session_id)
            except Exception:  # noqa: BLE001 - listeners must never break a heartbeat
                pass
        return grant

    def grant(self, session_id: str) -> ObjectEdgeGrant | None:
        with self._lock:
            if session_id in self._disabled:
                return None
            return self._grants.get(session_id)

    def disabled_reason(self, session_id: str) -> str | None:
        with self._lock:
            return self._disabled.get(session_id)

    def disable(self, session_id: str, reason: str) -> None:
        with self._lock:
            already = session_id in self._disabled
            self._disabled.setdefault(session_id, reason[:200])
        if not already:
            self._logger.record(
                "object_edge_disabled", session_id=session_id, reason=reason[:200]
            )
            self._persist()

    def client(self, session_id: str) -> ObjectEdgeClient | None:
        """Shared per-origin client whose token follows the session's grant."""

        grant = self.grant(session_id)
        if grant is None:
            return None
        with self._lock:
            client = self._clients.get(grant.url)
            if client is None:
                client = ObjectEdgeClient(
                    grant.url,
                    lambda: None,
                    allow_insecure_loopback=self._allow_insecure_loopback,
                    now=self._now,
                )
                self._clients[grant.url] = client
        return client

    def status_document(self) -> dict[str, Any]:
        now = float(self._now())
        with self._lock:
            sessions = {
                session_id: {
                    **grant.metadata(now),
                    **(
                        {"disabled_reason": self._disabled[session_id], "state": "unavailable"}
                        if session_id in self._disabled
                        else {"state": "ready" if grant.remaining(now) > GRANT_USE_MARGIN_SECONDS else "expired"}
                    ),
                }
                for session_id, grant in self._grants.items()
            }
            for session_id, reason in self._disabled.items():
                sessions.setdefault(session_id, {"state": "unavailable", "disabled_reason": reason})
        return {
            "schema": "meshia.node.object_edge_status.v1",
            "updated_at": _iso(now),
            "sessions": sessions,
        }

    def _persist(self) -> None:
        with self._lock:
            path = self._status_path
        if path is None:
            return
        try:
            write_private_file(
                path,
                json.dumps(self.status_document(), sort_keys=True, separators=(",", ":")).encode("utf-8"),
            )
        except OSError as error:
            self._logger.record("object_edge_status_write_failed", error=str(error)[:200])


class ObjectEdgeSession:
    """One workspace's view of the registry, used by the Fabric transport."""

    def __init__(self, registry: ObjectEdgeRegistry, session_id: str) -> None:
        self.registry = registry
        self.session_id = session_id

    def grant(self) -> ObjectEdgeGrant | None:
        return self.registry.grant(self.session_id)

    def ready(self, permission: str, now: float) -> bool:
        grant = self.grant()
        return grant is not None and grant.usable(now, permission)

    def prefix(self) -> str | None:
        grant = self.grant()
        return grant.prefix if grant is not None else None

    def client(self) -> ObjectEdgeClient | None:
        client = self.registry.client(self.session_id)
        if client is None:
            return None
        client._token_provider = self.grant  # noqa: SLF001 - the registry owns the client
        return client

    def disable(self, reason: str) -> None:
        self.registry.disable(self.session_id, reason)


_DEFAULT_REGISTRY = ObjectEdgeRegistry()


def default_registry() -> ObjectEdgeRegistry:
    return _DEFAULT_REGISTRY


def object_edge_status_path(home: Path) -> Path:
    return home / "object-edge-status.json"


def read_object_edge_status(home: Path, *, now: float | None = None) -> dict[str, Any] | None:
    """Token-free snapshot written by the daemon for ``meshia-node status``."""

    path = object_edge_status_path(home)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(raw, dict) or raw.get("schema") != "meshia.node.object_edge_status.v1":
        return None
    sessions = raw.get("sessions")
    if not isinstance(sessions, dict):
        return None
    current = time.time() if now is None else now
    for entry in sessions.values():
        if not isinstance(entry, dict):
            continue
        expires = entry.get("expires_at")
        if isinstance(expires, str) and entry.get("state") == "ready":
            try:
                parsed = datetime.fromisoformat(expires[:-1] + "+00:00").timestamp()
            except ValueError:
                continue
            remaining = int(parsed - current)
            entry["expires_in_seconds"] = max(0, remaining)
            if remaining <= GRANT_USE_MARGIN_SECONDS:
                entry["state"] = "expired"
    return raw


def format_object_edge_status(document: dict[str, Any] | None, session_id: str | None = None) -> str:
    """``files.meshia.io (token expires in 12m)`` or ``unavailable (tickets)``."""

    if not document:
        return "unavailable (tickets)"
    sessions = document.get("sessions") or {}
    entry = sessions.get(session_id) if session_id else None
    if entry is None:
        ready = [item for item in sessions.values() if isinstance(item, dict) and item.get("state") == "ready"]
        entry = ready[0] if ready else (next(iter(sessions.values()), None) if sessions else None)
    if not isinstance(entry, dict) or entry.get("state") != "ready":
        reason = entry.get("disabled_reason") if isinstance(entry, dict) else None
        return f"unavailable (tickets{'; ' + str(reason)[:60] if reason else ''})"
    seconds = int(entry.get("expires_in_seconds") or 0)
    if seconds >= 60:
        remaining = f"{seconds // 60}m"
    else:
        remaining = f"{seconds}s"
    return f"{entry.get('host')} (token expires in {remaining})"
