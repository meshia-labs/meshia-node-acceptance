"""`meshia-node doctor` — the machine-readable setup probe.

This is the surface an agent uses to decide whether a box can join a workspace:
environment, permissions, reachability, clock skew, and a machine inventory
(os, arch, python, cpu, memory, gpu, disk). It never prints secrets and never
mutates state.
"""

from __future__ import annotations

import email.utils
import os
import platform
import shutil
import stat as stat_module
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable

from . import native_execution
from .client import canonical_origin
from .config import ConfigStore, NodeConfig, Paths
from .errors import MeshiaNodeError
from .http_pool import create_https_context
from .machine import disk_free_bytes, inventory

MIN_PYTHON = (3, 11)


def _mode(path: Path) -> str | None:
    try:
        return format(stat_module.S_IMODE(os.stat(path).st_mode), "04o")
    except OSError:
        return None


def _private(path: Path, expected_mode: str) -> tuple[bool, str]:
    """(is_private, detail) — POSIX mode bits, or the DACL on Windows."""
    if not path.exists():
        return True, f"{path} not created yet"
    if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
        from .winsec import is_owner_restricted

        restricted = is_owner_restricted(path)
        return restricted, (
            f"{path} DACL {'is owner-restricted' if restricted else 'grants a broad audience'}"
        )
    mode = _mode(path)
    return mode == expected_mode, f"{path} mode={mode or 'missing'} (expected {expected_mode})"


def _check(name: str, ok: bool, detail: str) -> dict[str, Any]:
    return {"check": name, "ok": bool(ok), "detail": detail}


def _existing_parent(path: Path) -> Path:
    """Return the nearest existing directory without creating install state."""

    candidate = path
    while not candidate.exists():
        parent = candidate.parent
        if parent == candidate:
            break
        candidate = parent
    return candidate


def probe_network(origin: str, timeout: float = 6.0) -> dict[str, Any]:
    """Reachability plus clock skew, derived from the response `Date` header."""
    result: dict[str, Any] = {"origin": origin, "reachable": False}
    request = urllib.request.Request(origin + "/", method="GET")
    started = time.time()
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=create_https_context()) as reply:
            result.update(
                reachable=True,
                healthy=int(reply.status) < 500,
                status=reply.status,
            )
            served = reply.headers.get("Date")
    except urllib.error.HTTPError as error:
        result.update(
            reachable=True,
            healthy=int(error.code) < 500,
            status=error.code,
        )
        served = error.headers.get("Date") if error.headers else None
    except (urllib.error.URLError, OSError) as error:
        result.update(error=str(getattr(error, "reason", error))[:200])
        return result
    result["latency_ms"] = round((time.time() - started) * 1000, 1)
    if served:
        try:
            remote = email.utils.parsedate_to_datetime(served).timestamp()
            skew = round(time.time() - remote, 1)
            result["clock_skew_seconds"] = skew
            # The control plane rejects signed requests beyond 60s of skew.
            result["clock_skew_ok"] = abs(skew) <= 60
        except (TypeError, ValueError):
            pass
    return result


def machine_report() -> dict[str, Any]:
    machine = inventory()
    return {
        "os": machine.platform,
        "os_version": machine.platform_version,
        "arch": machine.architecture,
        "machine_family": machine.machine_family,
        "model": machine.model,
        "apple_chip": machine.apple_chip,
        "hostname": machine.hostname,
        "python": platform.python_version(),
        "python_executable": sys.executable,
        "cpu_logical": machine.cpu_logical,
        "memory_bytes": machine.memory_bytes,
        "gpu": {
            "family": machine.gpu.family,
            "count": machine.gpu.count,
            "names": list(machine.gpu.names),
            "nvidia_smi": shutil.which("nvidia-smi"),
        },
    }


def run(
    paths: Paths,
    api_url: str | None = None,
    network: bool = True,
    *,
    config_loader: Callable[[Paths], NodeConfig | None] | None = None,
) -> dict[str, Any]:
    store = ConfigStore(paths)
    config = None
    config_error = None
    try:
        config = config_loader(paths) if config_loader is not None else store.load()
    except (MeshiaNodeError, OSError) as error:
        config_error = str(error)

    checks: list[dict[str, Any]] = [
        _check(
            "python_version",
            sys.version_info[:2] >= MIN_PYTHON,
            f"{platform.python_version()} (requires >= {MIN_PYTHON[0]}.{MIN_PYTHON[1]})",
        )
    ]
    try:
        import cryptography

        checks.append(_check("cryptography", True, f"version {cryptography.__version__}"))
    except Exception as error:  # pragma: no cover - dependency always present in tests
        checks.append(_check("cryptography", False, f"import failed: {error}"))

    home_private, home_detail = _private(paths.home, "0700")
    checks.append(
        _check(
            "meshia_home",
            not paths.home.exists() or home_private,
            home_detail,
        )
    )
    key_path = paths.identity_dir / "device-key.pem"
    # A machine that has not enrolled yet simply has no key: that is a ready
    # state, not a fault. An existing key must be private to its owner.
    key_private, key_detail = _private(key_path, "0600")
    checks.append(_check("device_key", key_private, key_detail))
    config_private, config_detail = _private(paths.config_path, "0600")
    checks.append(
        _check(
            "config",
            (config is not None and config_private) if paths.config_path.exists() else True,
            config_error or config_detail,
        )
    )
    workspace = Path(config.workspace) if config else paths.default_workspace
    writable = workspace.is_dir() and os.access(workspace, os.W_OK | os.X_OK)
    checks.append(
        _check(
            "workspace",
            writable or not workspace.exists(),
            f"{workspace} "
            + ("writable" if writable else "missing (it will be created on connect)"),
        )
    )
    install_parent = _existing_parent(paths.home)
    disk_probe = workspace if workspace.exists() else install_parent
    free = disk_free_bytes(str(disk_probe))
    checks.append(
        _check("disk_space", free >= 256 * 1024 * 1024, f"{free // (1024 * 1024)} MiB free")
    )
    checks.append(
        _check(
            "no_sudo_required",
            install_parent.is_dir()
            and os.access(install_parent, os.W_OK | os.X_OK),
            f"install parent {install_parent} is writable; the node never needs root",
        )
    )
    access = config.access if config else None
    full_available = native_execution.full_available()
    workspace_available = native_execution.available()
    workspace_detail = native_execution.detail()
    selected_scope = "host" if access == "full" else "workspace" if access == "limited" else "none"
    selected_available = (
        full_available if access == "full" else workspace_available if access == "limited" else True
    )
    selected_detail = (
        "Full computer access: native execution as your OS account"
        if access == "full" else
        "Workspace only: native compute with workspace file isolation"
        if access == "limited" else
        "ordinary workspace mounts; no compute grant"
    )
    checks.append(
        _check(
            "native_execution",
            selected_available,
            f"access={access or 'not enrolled'} · "
            f"{selected_detail}; native full access {'available' if full_available else 'unavailable'}; "
            f"{native_execution.full_detail()}; "
            f"workspace-only {'available' if workspace_available else 'unavailable'}: {workspace_detail}. "
            "Remote commands also require a current owner-approved attachment.",
        )
    )

    origin = api_url or (config.api_url if config else None)
    report: dict[str, Any] = {
        "schema": "meshia.node.doctor.v1",
        "version": __import__("meshia_node").__version__,
        "machine": machine_report(),
        "paths": {
            "home": str(paths.home),
            "config": str(paths.config_path),
            "workspace": str(workspace),
            "log": str(paths.log_path),
        },
        "enrollment": (
            {
                "enrolled": True,
                "host_id": config.host_id,
                "generation": config.generation,
                "lifecycle": config.lifecycle,
                "tier": config.tier,
                "access": config.access,
                "api_url": config.api_url,
                "deployment_audience": config.deployment_audience,
            }
            if config
            else {"enrolled": False}
        ),
        "native_execution": {
            "full_available": full_available,
            "workspace_available": workspace_available,
            "workspace_mechanism": native_execution.kind(),
            "workspace_detail": workspace_detail,
            "selected_scope": selected_scope,
            "selected_scope_available": selected_available,
        },
    }
    if origin and network:
        try:
            report["network"] = probe_network(canonical_origin(origin))
            checks.append(
                _check(
                    "control_plane",
                    bool(
                        report["network"].get("reachable")
                        and report["network"].get("healthy")
                    ),
                    f"{origin} -> {report['network'].get('status', report['network'].get('error'))}",
                )
            )
            if "clock_skew_ok" in report["network"]:
                checks.append(
                    _check(
                        "clock_skew",
                        report["network"]["clock_skew_ok"],
                        f"{report['network']['clock_skew_seconds']}s (must be within 60s)",
                    )
                )
        except MeshiaNodeError as error:
            checks.append(_check("control_plane", False, str(error)))
    report["checks"] = checks
    report["ok"] = all(item["ok"] for item in checks)
    return report
