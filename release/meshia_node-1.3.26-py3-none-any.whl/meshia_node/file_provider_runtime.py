"""Read-only discovery and health for Meshia's macOS File Provider facade.

The signed host app owns domain registration.  The node never registers or
removes a domain implicitly: it only selects File Provider after the installed
host proves that the exact production domain already exists.  This keeps a
failed or incomplete app upgrade on the existing FUSE/FSKit path.
"""

from __future__ import annotations

import json
import os
import plistlib
import re
import socket
import stat
import struct
import sys
import urllib.parse
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from .file_provider_bridge import BRIDGE_SCHEMA, FileProviderBridgeAddress
from .util import run_bounded_process

FILE_PROVIDER_APP_BUNDLE_ID = "io.meshia.Meshia"
FILE_PROVIDER_EXTENSION_BUNDLE_ID = "io.meshia.Meshia.MeshiaFileProvider"
FILE_PROVIDER_DOMAIN_ID = "io.meshia.files"
FILE_PROVIDER_STATUS_SCHEMA = "meshia.file-provider.status.v1"
FILE_PROVIDER_EXTENSION_RELATIVE_PATH = Path(
    "Contents/PlugIns/MeshiaFileProvider.appex"
)
FILE_PROVIDER_HOST_RELATIVE_PATH = Path("Contents/MacOS/Meshia")
FILE_PROVIDER_STATUS_TIMEOUT_SECONDS = 5.0
FILE_PROVIDER_STATUS_MAX_BYTES = 64 * 1024
FILE_PROVIDER_SIGNATURE_TIMEOUT_SECONDS = 5.0
FILE_PROVIDER_APP_CANDIDATES = (
    Path("~/Applications/Meshia.app"),
    Path("/Applications/Meshia.app"),
)
_APP_GROUP_RE = re.compile(r"^[A-Z0-9]{10}\.io\.meshia$")
_TRUE = frozenset(("1", "true", "yes", "on"))
_FALSE = frozenset(("0", "false", "no", "off"))


@dataclass(frozen=True)
class NativeFileProviderStatus:
    supported: bool
    enabled: bool
    ready: bool
    state: str
    app_path: Path | None = None
    extension_path: Path | None = None
    app_group: str | None = None
    container_path: Path | None = None
    user_visible_url: str | None = None
    detail: str | None = None

    @property
    def bridge_address(self) -> FileProviderBridgeAddress | None:
        if not self.ready or self.container_path is None:
            return None
        return FileProviderBridgeAddress(
            self.container_path / "fp.sock", self.container_path / "fp.token"
        )

    def document(self, *, bridge_running: bool | None = None) -> dict[str, Any]:
        document = asdict(self)
        for field in ("app_path", "extension_path", "container_path"):
            value = document[field]
            document[field] = str(value) if value is not None else None
        document.update(
            {
                "domain_identifier": FILE_PROVIDER_DOMAIN_ID,
                "bridge_running": bridge_running,
                "presentation": "file-provider" if self.ready else None,
            }
        )
        return document


@dataclass(frozen=True)
class FileProviderBridgeHealth:
    """Authenticated, bounded health reported by the selected bridge."""

    running: bool
    account_wide: bool = False
    workspace_count: int | None = None


def native_file_provider_enabled(
    environment: Mapping[str, str] | None = None,
) -> bool:
    """Default on; retain the prototype flag as an explicit opt-out.

    ``MESHIA_DISABLE_FILE_PROVIDER=1`` is the direct kill switch.  Existing
    operators who set ``MESHIA_ENABLE_FILE_PROVIDER=0`` keep the same result,
    while an absent legacy flag now means automatic native discovery.
    """

    env = os.environ if environment is None else environment
    disabled = env.get("MESHIA_DISABLE_FILE_PROVIDER", "").strip().lower()
    if disabled in _TRUE:
        return False
    legacy = env.get("MESHIA_ENABLE_FILE_PROVIDER")
    if legacy is not None and legacy.strip().lower() in _FALSE:
        return False
    return True


def native_file_provider_status(
    *,
    platform_name: str | None = None,
    environment: Mapping[str, str] | None = None,
    app_candidates: Sequence[Path] | None = None,
    runner: Callable[[Sequence[str]], tuple[int, bytes, bytes] | None] | None = None,
    signature_checker: Callable[[Path, Path], str | None] | None = None,
) -> NativeFileProviderStatus:
    """Inspect the installed app and registered domain without changing either."""

    platform_value = sys.platform if platform_name is None else platform_name
    if platform_value != "darwin":
        return NativeFileProviderStatus(False, False, False, "platform_not_supported")
    if not native_file_provider_enabled(environment):
        return NativeFileProviderStatus(True, False, False, "disabled")

    candidates = app_candidates or FILE_PROVIDER_APP_CANDIDATES
    app_path = _installed_app(candidates)
    if app_path is None:
        return NativeFileProviderStatus(True, True, False, "app_missing")
    extension_path = app_path / FILE_PROVIDER_EXTENSION_RELATIVE_PATH
    if not _bundle_identifiers_are_exact(app_path, extension_path):
        return NativeFileProviderStatus(
            True,
            True,
            False,
            "bundle_invalid",
            app_path=app_path,
            extension_path=extension_path,
        )
    verified_app_group = (signature_checker or _verified_app_group)(
        app_path, extension_path
    )
    if verified_app_group is None:
        return NativeFileProviderStatus(
            True,
            True,
            False,
            "signature_invalid",
            app_path=app_path,
            extension_path=extension_path,
        )

    host = app_path / FILE_PROVIDER_HOST_RELATIVE_PATH
    invoke = runner or _run_status_host
    try:
        result = invoke((str(host), "--file-provider-status"))
    except OSError as error:
        return NativeFileProviderStatus(
            True, True, False, "status_unavailable", app_path, extension_path,
            detail=type(error).__name__,
        )
    if result is None:
        return NativeFileProviderStatus(
            True, True, False, "status_timeout", app_path, extension_path
        )
    returncode, stdout, _stderr = result
    if len(stdout) > FILE_PROVIDER_STATUS_MAX_BYTES:
        return NativeFileProviderStatus(
            True, True, False, "status_invalid", app_path, extension_path,
            detail="oversize_response",
        )
    try:
        payload = json.loads(stdout)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return NativeFileProviderStatus(
            True, True, False, "status_invalid", app_path, extension_path,
            detail="invalid_json",
        )
    if not isinstance(payload, dict):
        return NativeFileProviderStatus(
            True, True, False, "status_invalid", app_path, extension_path,
            detail="invalid_document",
        )
    parsed = _parse_host_status(
        payload, app_path, extension_path, verified_app_group
    )
    if parsed is not None:
        # Registration absence is an expected non-zero status.  Conversely,
        # never trust a nominally registered JSON response from a failed host.
        if parsed.ready and returncode != 0:
            return NativeFileProviderStatus(
                True, True, False, "status_unavailable", app_path, extension_path,
                detail="host_failed",
            )
        return parsed
    return NativeFileProviderStatus(
        True, True, False, "status_invalid", app_path, extension_path,
        detail="invalid_contract",
    )


def file_provider_bridge_health(
    address: FileProviderBridgeAddress | None,
) -> FileProviderBridgeHealth:
    """Boundedly authenticate the bridge and read its account-scope health."""

    if address is None:
        return FileProviderBridgeHealth(False)
    try:
        socket_info = address.socket_path.lstat()
        token_info = address.token_path.lstat()
        if (
            not stat.S_ISSOCK(socket_info.st_mode)
            or not stat.S_ISREG(token_info.st_mode)
            or socket_info.st_uid != os.getuid()
            or token_info.st_uid != os.getuid()
            or token_info.st_nlink != 1
            or token_info.st_mode & 0o077
            or token_info.st_size not in (64, 65)
        ):
            return FileProviderBridgeHealth(False)
        token = address.token_path.read_text(encoding="ascii").strip()
        if len(token) != 64 or any(
            character not in "0123456789abcdef" for character in token
        ):
            return FileProviderBridgeHealth(False)
        probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            probe.settimeout(0.25)
            probe.connect(str(address.socket_path))
            request = json.dumps(
                {
                    "schema": BRIDGE_SCHEMA,
                    "token": token,
                    "operation": "status",
                },
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
            probe.sendall(struct.pack(">I", len(request)) + request)
            response_size = struct.unpack(">I", _receive_exact(probe, 4))[0]
            if not 2 <= response_size <= FILE_PROVIDER_STATUS_MAX_BYTES:
                return FileProviderBridgeHealth(False)
            response = json.loads(
                _receive_exact(probe, response_size).decode("utf-8")
            )
            if (
                not isinstance(response, dict)
                or response.get("schema") != BRIDGE_SCHEMA
                or response.get("ok") is not True
            ):
                return FileProviderBridgeHealth(False)
            account_wide = response.get("account_wide") is True
            workspace_count = response.get("workspace_count")
            if account_wide and (
                not isinstance(workspace_count, int)
                or isinstance(workspace_count, bool)
                or workspace_count < 1
            ):
                return FileProviderBridgeHealth(False)
            return FileProviderBridgeHealth(
                True,
                account_wide=account_wide,
                workspace_count=(workspace_count if account_wide else None),
            )
        finally:
            probe.close()
    except (json.JSONDecodeError, OSError, UnicodeDecodeError, ValueError):
        return FileProviderBridgeHealth(False)


def file_provider_bridge_running(address: FileProviderBridgeAddress | None) -> bool:
    """Boundedly prove the same-user bridge accepts authenticated requests."""

    return file_provider_bridge_health(address).running


def _receive_exact(connection: socket.socket, size: int) -> bytes:
    result = bytearray()
    while len(result) < size:
        chunk = connection.recv(size - len(result))
        if not chunk:
            raise OSError("the File Provider bridge response ended early")
        result.extend(chunk)
    return bytes(result)


def _installed_app(candidates: Sequence[Path]) -> Path | None:
    for candidate in candidates:
        app_path = candidate.expanduser()
        if (
            (app_path / FILE_PROVIDER_HOST_RELATIVE_PATH).is_file()
            and (app_path / FILE_PROVIDER_EXTENSION_RELATIVE_PATH).is_dir()
        ):
            return app_path
    return None


def _bundle_identifiers_are_exact(app_path: Path, extension_path: Path) -> bool:
    app = _bundle_document(app_path / "Contents/Info.plist")
    extension = _bundle_document(extension_path / "Contents/Info.plist")
    extension_contract = (
        extension.get("NSExtension") if isinstance(extension, dict) else None
    )
    return bool(
        isinstance(app, dict)
        and isinstance(extension, dict)
        and isinstance(extension_contract, dict)
        and app.get("CFBundleIdentifier") == FILE_PROVIDER_APP_BUNDLE_ID
        and extension.get("CFBundleIdentifier")
        == FILE_PROVIDER_EXTENSION_BUNDLE_ID
        and extension_contract.get("NSExtensionPointIdentifier")
        == "com.apple.fileprovider-nonui"
    )


def _bundle_document(path: Path) -> dict[str, Any] | None:
    try:
        document = plistlib.loads(path.read_bytes())
    except (OSError, plistlib.InvalidFileException, ValueError):
        return None
    return document if isinstance(document, dict) else None


def _run_status_host(command: Sequence[str]) -> tuple[int, bytes, bytes] | None:
    completed = run_bounded_process(
        list(command),
        timeout_seconds=FILE_PROVIDER_STATUS_TIMEOUT_SECONDS,
        max_output_bytes=FILE_PROVIDER_STATUS_MAX_BYTES + 1,
    )
    if completed is None:
        return None
    return completed[0], completed[1].encode("utf-8"), b""


def _verified_app_group(app_path: Path, extension_path: Path) -> str | None:
    """Verify the nested signature, then require one shared app-group entitlement."""

    verified = run_bounded_process(
        ["/usr/bin/codesign", "--verify", "--deep", "--strict", str(app_path)],
        timeout_seconds=FILE_PROVIDER_SIGNATURE_TIMEOUT_SECONDS,
        max_output_bytes=8 * 1024,
        merge_stderr=True,
    )
    if verified is None or verified[0] != 0:
        return None
    app_groups = _signed_app_groups(app_path)
    extension_groups = _signed_app_groups(extension_path)
    shared = app_groups & extension_groups
    return next(iter(shared)) if len(shared) == 1 else None


def _signed_app_groups(bundle_path: Path) -> frozenset[str]:
    result = run_bounded_process(
        [
            "/usr/bin/codesign",
            "-d",
            "--entitlements",
            ":-",
            str(bundle_path),
        ],
        timeout_seconds=FILE_PROVIDER_SIGNATURE_TIMEOUT_SECONDS,
        max_output_bytes=64 * 1024,
    )
    if result is None or result[0] != 0:
        return frozenset()
    try:
        document = plistlib.loads(result[1].encode("utf-8"))
    except (plistlib.InvalidFileException, ValueError):
        return frozenset()
    groups = (
        document.get("com.apple.security.application-groups")
        if isinstance(document, dict)
        else None
    )
    if not isinstance(groups, list):
        return frozenset()
    return frozenset(
        group
        for group in groups
        if isinstance(group, str) and _APP_GROUP_RE.fullmatch(group) is not None
    )


def _parse_host_status(
    payload: Mapping[str, Any],
    app_path: Path,
    extension_path: Path,
    verified_app_group: str,
) -> NativeFileProviderStatus | None:
    schema = payload.get("schema")
    identifier = payload.get("identifier")
    registered = payload.get("registered")
    ready = payload.get("ready")
    if (
        schema != FILE_PROVIDER_STATUS_SCHEMA
        or identifier != FILE_PROVIDER_DOMAIN_ID
        or not isinstance(registered, bool)
        or not isinstance(ready, bool)
    ):
        return None
    error = payload.get("error")
    detail = error if isinstance(error, str) and error.strip() else None
    if not registered:
        # Native enumeration failures carry registered=false as a fallback;
        # that is not proof of absence.
        return NativeFileProviderStatus(
            True, True, False,
            "domain_unavailable" if detail else "domain_not_registered",
            app_path, extension_path, detail=detail,
        )
    user_enabled = payload.get("user_enabled")
    disconnected = payload.get("disconnected")
    # Old hosts only proved registration, which also succeeds for OS-disabled
    # extensions. Never cut over until current native lifecycle flags are known.
    if not isinstance(user_enabled, bool) or not isinstance(disconnected, bool):
        return None
    if not user_enabled or disconnected:
        return NativeFileProviderStatus(
            True, True, False,
            "domain_disabled" if not user_enabled else "domain_disconnected",
            app_path, extension_path, detail=detail,
        )
    if not ready or detail:
        return NativeFileProviderStatus(
            True,
            True,
            False,
            "domain_unavailable",
            app_path,
            extension_path,
            detail=detail,
        )
    app_group = payload.get("app_group")
    container_value = payload.get("container_path")
    visible = payload.get("user_visible_url")
    visible_path = _local_file_url_path(visible) if isinstance(visible, str) else None
    if (
        not isinstance(app_group, str)
        or _APP_GROUP_RE.fullmatch(app_group) is None
        or app_group != verified_app_group
        or not isinstance(container_value, str)
        or visible_path is None
    ):
        return None
    container = Path(container_value)
    expected = Path.home() / "Library" / "Group Containers" / app_group
    if not container.is_absolute() or container != expected:
        return None
    cloud_storage = Path.home() / "Library" / "CloudStorage"
    if visible_path.parent != cloud_storage:
        return None
    return NativeFileProviderStatus(
        True,
        True,
        True,
        "ready",
        app_path,
        extension_path,
        app_group,
        container,
        visible,
    )


def _local_file_url_path(value: str) -> Path | None:
    parsed = urllib.parse.urlparse(value)
    if parsed.scheme != "file" or parsed.netloc not in ("", "localhost"):
        return None
    path = Path(urllib.parse.unquote(parsed.path))
    return path if path.is_absolute() else None
