"""Platform-neutral facade over exec confinement.

`limited` access promises that an exec'd child writes only inside the
workspace. Each platform keeps that promise with a different kernel mechanism:

* Linux — Landlock (:mod:`meshia_node.landlock`), an unprivileged LSM applied
  between ``fork`` and ``exec``;
* Windows — a low-integrity-level child token (:mod:`meshia_node.winconfine`),
  the no-write-up mandatory integrity control that confined Protected-Mode IE
  and still confines browser sandboxes today;
* everything else — unavailable, and `limited` exec fails closed.

Callers (the executor's dispatch, `doctor`) go through this module so they
never have to know which mechanism a host uses; the mechanism-specific modules
stay independently testable.
"""

from __future__ import annotations

import sys

# Both mechanism modules are imported lazily inside the branches. Each one reads
# platform-specific constants at module scope (Landlock the Unix-only open flags,
# winconfine the Win32 FFI), so importing either eagerly would make this facade —
# the thing every caller goes through — carry the other platform's import risk.


def kind() -> str:
    """The mechanism this platform would use: 'landlock', 'windows-low-il', or 'none'."""
    if sys.platform == "linux":
        return "landlock"
    if sys.platform == "win32":
        return "windows-low-il"
    return "none"


def available() -> bool:
    if sys.platform == "linux":
        from . import landlock

        return landlock.available()
    if sys.platform == "win32":
        from . import winconfine  # deferred: never loads the Win32 FFI on POSIX

        return winconfine.available()
    return False


def detail() -> str:
    """Human-readable confinement status for `doctor` output and error messages."""
    if sys.platform == "linux":
        from . import landlock

        return landlock.detail()
    if sys.platform == "win32":
        from . import winconfine

        return winconfine.detail()
    return (
        f"exec confinement requires Linux (Landlock) or Windows (integrity levels); "
        f"this host is {sys.platform}"
    )


__all__ = ["available", "detail", "kind"]
