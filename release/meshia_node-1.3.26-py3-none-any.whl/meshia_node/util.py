"""Small, dependency-free helpers: digests, base64url, JSON, time, redaction."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .errors import StateError

RAW_SHA256_RE = re.compile(r"^[a-f0-9]{64}$")
TAGGED_SHA256_RE = re.compile(r"^sha256:[a-f0-9]{64}$")
UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$", re.I
)
# Canonical Meshia account identities come from PostgreSQL ``uuid`` columns.
# Some profiles predate RFC-variant-aware generators, so their database keys
# can use any hexadecimal version/variant nibble even though the text shape is
# still a UUID. Device, session, attachment, and nonce ids stay on UUID_RE.
POSTGRES_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I
)
PAIRING_CODE_RE = re.compile(r"^mesh_[A-Za-z0-9_-]{32}$")
# The control plane's capability value allowlist (web/lib/connected-hosts.ts).
CAPABILITY_VALUE_RE = re.compile(r"^[A-Za-z0-9 ._:+()-]+$")

_SECRET_HINTS = ("mesh_", "BEGIN PRIVATE KEY", "BEGIN EC PRIVATE KEY", "signature")

# Unix-only; 0 on Windows. Resolved once at import so no code path can reach a
# bare os.O_DIRECTORY, which would be an AttributeError on a Windows kernel.
_O_DIRECTORY = getattr(os, "O_DIRECTORY", 0)


def console_python() -> str:
    """Select this runtime's pipe-capable Python when the service uses Pythonw."""
    executable = sys.executable or "python3"
    if sys.platform != "win32" or Path(executable).name.lower() != "pythonw.exe":
        return executable
    windowless = Path(executable)
    console = windowless.with_name("python.exe")
    if (not windowless.is_absolute() or not console.is_file()
            or console.resolve().parent != windowless.resolve().parent):
        raise StateError("The installed Meshia runtime is missing its matching python.exe; repair the installation.")
    # Preserve the venv spelling; resolving it to a base interpreter can lose
    # this package. Never search PATH or a different prefix for a substitute.
    return str(console)


def directory_entry_identity_stat(entry: os.DirEntry[str]) -> os.stat_result:
    """Return no-follow metadata suitable for file-identity decisions.

    On Windows, ``DirEntry.stat()`` deliberately exposes zero for ``st_ino``,
    ``st_dev``, and ``st_nlink``.  Consumers that enforce single-link and
    same-file invariants must therefore take a fresh path stat.  Other
    directory scans can keep using the cheaper cached enumeration metadata.
    """

    if sys.platform == "win32":
        return os.stat(entry.path, follow_symlinks=False)
    return entry.stat(follow_symlinks=False)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def tagged_sha256(data: bytes) -> str:
    return f"sha256:{sha256_hex(data)}"


def b64url_unpadded(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64_standard(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def decode_canonical_b64(value: str) -> bytes | None:
    """Decode RFC 4648 base64 only if it is the canonical encoding of its bytes."""
    if len(value) % 4 != 0 or not re.fullmatch(
        r"(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?", value
    ):
        return None
    try:
        raw = base64.b64decode(value, validate=True)
    except Exception:
        return None
    return raw if base64.b64encode(raw).decode("ascii") == value else None


def json_bytes(value: Any) -> bytes:
    """Compact, stable JSON. The exact bytes are what gets signed."""
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def iso8601(moment: datetime | None = None) -> str:
    stamp = moment or datetime.now(timezone.utc)
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    return stamp.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def clean(value: str, limit: int = 512) -> str:
    """Strip control characters and obvious secrets before anything is logged."""
    flattened = "".join(character if character.isprintable() else " " for character in value)
    collapsed = " ".join(flattened.split())[:limit]
    for hint in _SECRET_HINTS:
        if hint in collapsed:
            return "[redacted]"
    return collapsed


def ensure_private_dir(path: Path) -> Path:
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path, 0o700)
    if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
        # chmod is a no-op for privacy on Windows; the DACL is what counts.
        # Files created beneath inherit this DACL, but inheritance alone is not
        # a security proof: the ACL operation can be unavailable and an ACL can
        # be widened after it was cached. Establish it, then verify the live
        # directory DACL on every use. The only safe fallback is to stop; state
        # can contain signing keys and remote-filesystem contents.
        from .winsec import ensure_owner_restricted

        try:
            ensure_owner_restricted(path)
        except Exception as error:
            raise StateError(
                f"Meshia could not establish and verify a private Windows DACL for {path}. "
                "It refuses to use unverified private state; repair Windows ACL support or "
                "permissions and retry."
            ) from error
    return path


def write_private_file(path: Path, data: bytes) -> None:
    """Atomically write `data` to `path` with 0600, creating 0700 parents."""
    ensure_private_dir(path.parent)
    handle, temporary = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    if _O_DIRECTORY:  # Windows has no directory descriptor to fsync
        directory = os.open(str(path.parent), os.O_RDONLY | _O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)


def bounded_int(value: Any, minimum: int, maximum: int, fallback: int) -> int:
    """Clamp an untrusted numeric payload field into a safe range."""
    if isinstance(value, bool) or not isinstance(value, int):
        return fallback
    return max(minimum, min(maximum, value))


def run_bounded_process(
    command: list[str],
    *,
    timeout_seconds: float,
    max_output_bytes: int = 4 * 1024 * 1024,
    merge_stderr: bool = False,
) -> tuple[int, str] | None:
    """Run one fixed helper and return ``(returncode, output)``, never waiting on a wedged child.

    ``subprocess.run(timeout=...)`` kills an expired child and then *waits* for
    it.  A helper that touched a dead network mount (``mount``, ``lsof``,
    ``df``) can sit in an uninterruptible kernel wait where that final wait
    never returns, which turns a health probe into the very hang it was meant
    to diagnose.  Poll instead; on expiry ask the child to die, hand reaping
    to a daemon thread, and report ``None`` so callers stay conservative.

    ``None`` also covers a spawn failure and output beyond ``max_output_bytes``.
    Output is read on a helper thread so a chatty child can never block the
    poll loop on a full pipe.
    """

    import subprocess
    import threading
    import time

    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT if merge_stderr else subprocess.DEVNULL,
            **({"creationflags": subprocess.CREATE_NO_WINDOW} if sys.platform == "win32" else {}),
        )
    except (OSError, ValueError):
        return None
    chunks: list[bytes] = []
    total = 0
    overflow = False

    def drain() -> None:
        nonlocal total, overflow
        stream = process.stdout
        if stream is None:
            return
        try:
            while True:
                chunk = stream.read(64 * 1024)
                if not chunk:
                    return
                total += len(chunk)
                if total > max_output_bytes:
                    overflow = True
                    return
                chunks.append(chunk)
        except OSError:
            return

    reader = threading.Thread(target=drain, name="meshia-bounded-capture", daemon=True)
    reader.start()
    deadline = time.monotonic() + max(0.0, timeout_seconds)
    while True:
        if process.poll() is not None:
            reader.join(timeout=max(0.0, deadline - time.monotonic()))
            break
        if time.monotonic() >= deadline:
            try:
                process.kill()
            except OSError:
                pass

            def reap() -> None:
                try:
                    process.wait()
                except OSError:
                    pass

            threading.Thread(
                target=reap, name="meshia-bounded-capture-reaper", daemon=True
            ).start()
            return None
        time.sleep(0.02)
    if overflow or reader.is_alive():
        return None
    return process.returncode, b"".join(chunks).decode("utf-8", errors="replace")


def run_bounded_capture(
    command: list[str],
    *,
    timeout_seconds: float,
    max_output_bytes: int = 4 * 1024 * 1024,
) -> str | None:
    """Return the stdout of a helper that exited 0 within the bound, else ``None``."""

    result = run_bounded_process(
        command, timeout_seconds=timeout_seconds, max_output_bytes=max_output_bytes
    )
    if result is None or result[0] != 0:
        return None
    return result[1]


def raise_file_descriptor_limit(minimum: int = 4096) -> int | None:
    """Lift this process's soft RLIMIT_NOFILE to ``minimum`` when allowed.

    launchd starts the service with a 256-descriptor soft limit; the mount
    keeps one descriptor per in-flight write session (bound 512) on top of
    the sync engine's own files, so a Finder bulk copy would hit EMFILE.
    Returns the soft limit in force afterwards, ``None`` where unsupported.
    """

    try:
        import resource
    except ImportError:  # pragma: no cover - Windows
        return None
    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    except (OSError, ValueError):  # pragma: no cover - exotic platforms
        return None
    if soft == resource.RLIM_INFINITY:
        return soft
    target = minimum if hard == resource.RLIM_INFINITY else min(minimum, hard)
    if soft >= target:
        return soft
    try:
        resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
    except (OSError, ValueError):
        return soft
    return target
