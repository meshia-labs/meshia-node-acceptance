"""Crash-described account replacement for the script installer.

The existing node keeps serving its mounted account while a one-use pairing
grant authenticates a replacement host identity and downloads one complete,
generation-consistent workspace catalog.  Activation publishes the catalog
and tiny config only after the old runner stops; account workspace state stays
partitioned by immutable account UUID.
"""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any

from .client import SignedClient, validate_api_url
from .config import ConfigStore, NodeConfig, Paths
from .enroll import enroll, recover_enrollment_claim, recover_enrollment_proof
from .errors import Disconnected, MeshiaNodeError, RemoteError, StateError
from .identity import DeviceIdentity
from .service import ConnectionLease
from .util import ensure_private_dir, iso8601, write_private_file
from .workspace_catalog import WorkspaceCatalogClient, WorkspaceCatalogStore


CUTOVER_SCHEMA = "meshia.account_cutover.v1"
REMOTE_ENROLLMENT_SCHEMA = "meshia.account_cutover.remote_enrollment.v1"
_PHASES = frozenset(
    {
        "preparing",
        "prepared",
        "activating",
        "published",
        "rolled_back",
        "committed",
    }
)
_MANAGED_NAMES = frozenset(
    {
        "candidate-config.json",
        "candidate-state.lock",
        "candidate-catalog.json",
        ".candidate-catalog.json.lock",
        "previous-config.json",
        "previous-device-key.pem",
        "remote-enrollment.json",
        "receipt.json",
        "candidate-identity",
    }
)
_IDENTITY_NAMES = frozenset({"device-key.pem", "installation-id"})


def _root(paths: Paths) -> Path:
    return paths.home / "account-cutover"


def _receipt_path(paths: Paths) -> Path:
    return _root(paths) / "receipt.json"


def _remote_enrollment_path(paths: Paths) -> Path:
    return _root(paths) / "remote-enrollment.json"


def _candidate_store(paths: Paths) -> ConfigStore:
    root = _root(paths)
    return ConfigStore(
        paths,
        config_path=root / "candidate-config.json",
        state_lock=root / "candidate-state.lock",
    )


def _candidate_catalog(paths: Paths) -> WorkspaceCatalogStore:
    return WorkspaceCatalogStore(_root(paths) / "candidate-catalog.json")


def _previous_store(paths: Paths) -> ConfigStore:
    root = _root(paths)
    return ConfigStore(
        paths,
        config_path=root / "previous-config.json",
        state_lock=root / "candidate-state.lock",
    )


def _candidate_identity(paths: Paths, installation_id: str | None = None) -> DeviceIdentity:
    identity_dir = _root(paths) / "candidate-identity"
    if identity_dir.is_symlink():
        raise StateError("The candidate identity directory is unsafe.")
    ensure_private_dir(identity_dir)
    unexpected = {item.name for item in identity_dir.iterdir()} - _IDENTITY_NAMES
    if unexpected:
        raise StateError("The candidate identity directory contains unrecognized state.")
    installation_path = identity_dir / "installation-id"
    if installation_id is not None:
        if installation_path.exists():
            if installation_path.read_text(encoding="utf-8").strip() != installation_id:
                raise StateError("The candidate identity changed during account cutover.")
        else:
            write_private_file(
                installation_path, f"{installation_id}\n".encode("utf-8")
            )
    identity = DeviceIdentity.load_or_create(identity_dir)
    if installation_id is not None and identity.installation_id != installation_id:
        raise StateError("The candidate identity has the wrong installation id.")
    return identity


def _authority(config: NodeConfig) -> dict[str, Any]:
    return {
        "account_id": config.account_id,
        "host_id": config.host_id,
        "session_id": config.session_id,
        "generation": config.generation,
    }


def _same_authority(config: NodeConfig, expected: object) -> bool:
    return isinstance(expected, dict) and _authority(config) == expected


def _save_remote_enrollment(paths: Paths, document: dict[str, Any]) -> None:
    ensure_private_dir(_root(paths))
    write_private_file(
        _remote_enrollment_path(paths),
        json.dumps(document, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    )


def _discard_remote_enrollment(paths: Paths) -> None:
    path = _remote_enrollment_path(paths)
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise StateError("The candidate remote-enrollment receipt path is unsafe.")
    try:
        path.unlink()
    except FileNotFoundError:
        pass


def _load_remote_enrollment(paths: Paths) -> dict[str, Any] | None:
    path = _remote_enrollment_path(paths)
    if not path.exists():
        return None
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise StateError("The candidate remote-enrollment receipt is unreadable.") from error
    if (
        not isinstance(document, dict)
        or document.get("schema") != REMOTE_ENROLLMENT_SCHEMA
        or document.get("phase") not in {"claiming", "claimed", "proven"}
        or not isinstance(document.get("api_url"), str)
        or not isinstance(document.get("installation_id"), str)
    ):
        raise StateError("The candidate remote-enrollment receipt is invalid.")
    if document["phase"] == "claiming":
        enrollment = document.get("enrollment")
        if (
            not isinstance(enrollment, dict)
            or enrollment.get("installation_id") != document["installation_id"]
        ):
            raise StateError("The pending candidate claim receipt is invalid.")
        return document
    if (
        not isinstance(document.get("host_id"), str)
        or not isinstance(document.get("challenge"), str)
        or not 1 <= len(document["challenge"]) <= 1024
        or not isinstance(document.get("deployment_audience"), str)
        or not document["deployment_audience"]
    ):
        raise StateError("The claimed candidate enrollment receipt is invalid.")
    # Reuse the production validators instead of maintaining a looser recovery
    # grammar. The proof helper validates host UUID and API origin before any
    # network request; DeviceIdentity validates the installation UUID below.
    if document["phase"] == "proven":
        for field in ("generation", "session_id", "account_id", "account_email"):
            if field not in document:
                raise StateError("The proven candidate enrollment receipt is incomplete.")
    return document


def _recovery_candidate_config(
    old: NodeConfig, descriptor: dict[str, Any], proven: dict[str, object]
) -> NodeConfig:
    """Build signing state solely for retiring a remotely claimed candidate."""

    return replace(
        old,
        api_url=str(descriptor["api_url"]),
        deployment_audience=str(descriptor["deployment_audience"]),
        host_id=str(proven["host_id"]),
        generation=int(proven["generation"]),
        session_id=str(proven["session_id"]),
        installation_id=str(descriptor["installation_id"]),
        workspace_name=None,
        account_id=str(proven["account_id"]),
        account_email=str(proven["account_email"]),
        workspace_adoption_pending=False,
        attachment_id=None,
        lifecycle="enrolled",
        disconnect_reason=None,
        next_sequence=1,
        next_metrics_sequence=1,
        clock_offset_seconds=0,
        enrolled_at=iso8601(),
        last_heartbeat_at=None,
        pid=None,
    )


def _active_runtime(paths: Paths) -> str:
    selector = paths.home / "runtime"
    try:
        runtime = selector.resolve(strict=True)
    except OSError as error:
        raise StateError(
            "The active runtime could not be resolved before account cutover."
        ) from error
    runtimes = (paths.home / "runtimes").resolve()
    legacy_runtime = selector.exists() and not selector.is_symlink() and selector.is_dir()
    if (
        (runtime.parent != runtimes and not legacy_runtime)
        or runtime.is_symlink()
        or not runtime.is_dir()
    ):
        raise StateError("The active runtime is not a validated immutable runtime child.")
    return str(runtime)


def _save_receipt(paths: Paths, document: dict[str, Any]) -> None:
    ensure_private_dir(_root(paths))
    write_private_file(
        _receipt_path(paths),
        json.dumps(document, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    )


def inspect(paths: Paths) -> dict[str, Any] | None:
    path = _receipt_path(paths)
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise StateError("The account-cutover recovery receipt is unreadable.") from error
    if (
        not isinstance(value, dict)
        or value.get("schema") != CUTOVER_SCHEMA
        or value.get("phase") not in _PHASES
        or not isinstance(value.get("old_authority"), dict)
        or value.get("old_lifecycle")
        not in {"enrolled", "attaching", "connected", "offline", "disconnected"}
        or not isinstance(value.get("prior_runtime"), str)
    ):
        raise StateError("The account-cutover recovery receipt is invalid.")
    return value


def _clean_candidate(paths: Paths) -> None:
    root = _root(paths)
    if not root.exists():
        return
    if root.is_symlink() or not root.is_dir():
        raise StateError("The account-cutover directory is unsafe.")
    unexpected = {item.name for item in root.iterdir()} - _MANAGED_NAMES
    if unexpected:
        raise StateError("The account-cutover directory contains unrecognized state.")
    identity_dir = root / "candidate-identity"
    if identity_dir.exists() or identity_dir.is_symlink():
        if identity_dir.is_symlink() or not identity_dir.is_dir():
            raise StateError("The account-cutover identity path is unsafe.")
        identity_unexpected = {
            item.name for item in identity_dir.iterdir()
        } - _IDENTITY_NAMES
        if identity_unexpected:
            raise StateError("The account-cutover identity contains unrecognized state.")
        for name in _IDENTITY_NAMES:
            path = identity_dir / name
            if path.is_symlink() or (path.exists() and not path.is_file()):
                raise StateError("The account-cutover identity contains an unsafe path.")
            try:
                path.unlink()
            except FileNotFoundError:
                pass
        identity_dir.rmdir()
    for name in _MANAGED_NAMES - {"candidate-identity", "receipt.json"}:
        path = root / name
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise StateError("The account-cutover state contains an unsafe path.")
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    # Receipt removal is the final local mutation. Its absence therefore never
    # describes a half-cleaned transaction.
    receipt = root / "receipt.json"
    if receipt.is_symlink() or (receipt.exists() and not receipt.is_file()):
        raise StateError("The account-cutover receipt path is unsafe.")
    try:
        receipt.unlink()
    except FileNotFoundError:
        pass
    try:
        root.rmdir()
    except FileNotFoundError:
        pass
    except OSError as error:
        raise StateError("The account-cutover directory could not be retired safely.") from error


def _retire_candidate_remote(paths: Paths) -> bool:
    candidate_store = _candidate_store(paths)
    try:
        candidate = candidate_store.load()
        if candidate is None:
            descriptor = _load_remote_enrollment(paths)
            if descriptor is None:
                # No successful claim was observed locally, so there is no
                # candidate remote authority to retire.
                return True
            old = ConfigStore(paths).require()
            identity = _candidate_identity(paths, descriptor["installation_id"])
            if descriptor["phase"] == "claiming":
                described = identity.describe()
                enrollment = descriptor["enrollment"]
                if (
                    enrollment.get("enrollment_idempotency_key")
                    != described.enrollment_idempotency_key
                    or enrollment.get("public_key") != described.public_key_spki_pem
                ):
                    raise StateError("The pending claim does not match its candidate key.")
                try:
                    claimed = recover_enrollment_claim(
                        api_url=descriptor["api_url"],
                        enrollment=enrollment,
                    )
                except RemoteError as error:
                    # M765 makes the exact PAIRING_CODE_INVALID response
                    # authoritative: a key-bound pending host would instead be
                    # replayable even after grant expiry. Every other failure
                    # remains ambiguous and durable for a later retry.
                    if (
                        error.status == 401
                        and error.remote_code == "PAIRING_CODE_INVALID"
                    ):
                        return True
                    raise
                descriptor = {
                    "schema": REMOTE_ENROLLMENT_SCHEMA,
                    "phase": "claimed",
                    "created_at": descriptor.get("created_at", iso8601()),
                    "installation_id": identity.installation_id,
                    "api_url": descriptor["api_url"],
                    **claimed,
                }
                _save_remote_enrollment(paths, descriptor)
            if descriptor["phase"] == "claimed":
                proven = recover_enrollment_proof(
                    api_url=descriptor["api_url"],
                    identity=identity,
                    host_id=descriptor["host_id"],
                    challenge=descriptor["challenge"],
                )
                descriptor.update({"phase": "proven", **proven})
                _save_remote_enrollment(paths, descriptor)
            else:
                proven = {
                    field: descriptor[field]
                    for field in (
                        "host_id",
                        "generation",
                        "session_id",
                        "account_id",
                        "account_email",
                    )
                }
            candidate = candidate_store.save(
                _recovery_candidate_config(old, descriptor, proven)
            )
        identity = _candidate_identity(paths, candidate.installation_id)
        SignedClient(candidate_store, identity).delete_empty(
            f"api/connected-hosts/{candidate.host_id}"
        )
    except Disconnected as error:
        # A missing/revoked candidate is the only terminal negative proof.
        # Origin, deployment, generation, or other authorization failures can
        # leave a live remote host and must retain recovery evidence for retry.
        return error.reason_code == "HOST_REVOKED"
    except (MeshiaNodeError, OSError):
        return False
    return True


def _finish_remote_retirement(paths: Paths, receipt: dict[str, Any]) -> bool:
    if _retire_candidate_remote(paths):
        _clean_candidate(paths)
        return True
    receipt["phase"] = "rolled_back"
    receipt["remote_retirement_pending_at"] = iso8601()
    _save_receipt(paths, receipt)
    return False


def retry_remote_retirement(paths: Paths) -> bool:
    receipt = inspect(paths)
    if receipt is None:
        return True
    if receipt["phase"] != "rolled_back":
        raise StateError("The account cutover is not awaiting remote retirement.")
    if not _same_authority(ConfigStore(paths).require(), receipt["old_authority"]):
        raise StateError("The restored account changed before candidate retirement.")
    return _finish_remote_retirement(paths, receipt)


def abort_prepared(paths: Paths) -> bool:
    receipt = inspect(paths)
    if receipt is None:
        return True
    if receipt["phase"] not in {"preparing", "prepared", "rolled_back"}:
        raise StateError(
            "An activating or committed account cutover must not be aborted."
        )
    return _finish_remote_retirement(paths, receipt)


def prepare(
    paths: Paths,
    *,
    pairing_code: str,
    api_url: str,
    tier: str,
    access: str,
    native_mount_enabled: bool,
    workspace: Path | None = None,
    adopt_existing_workspace: bool = False,
) -> NodeConfig:
    """Authenticate and fully cache the replacement without touching active config."""

    active_store = ConfigStore(paths)
    old = active_store.require()
    if inspect(paths) is not None:
        raise StateError("An account cutover is already pending recovery.")
    ensure_private_dir(_root(paths))
    receipt: dict[str, Any] = {
        "schema": CUTOVER_SCHEMA,
        "phase": "preparing",
        "created_at": iso8601(),
        "old_authority": _authority(old),
        "old_lifecycle": old.lifecycle,
        "prior_runtime": _active_runtime(paths),
    }
    _save_receipt(paths, receipt)

    active_identity = DeviceIdentity.load_or_create(paths.identity_dir)
    identity = _candidate_identity(paths, active_identity.installation_id)
    candidate_store = _candidate_store(paths)

    def observe_enrollment(phase: str, payload: object) -> None:
        if not isinstance(payload, dict):
            raise StateError("The candidate enrollment observer received invalid state.")
        if phase == "claiming":
            enrollment = payload.get("enrollment")
            if payload.get("api_url") != validate_api_url(api_url) or not isinstance(
                enrollment, dict
            ):
                raise StateError("The candidate claim observer received invalid state.")
            _save_remote_enrollment(
                paths,
                {
                    "schema": REMOTE_ENROLLMENT_SCHEMA,
                    "phase": "claiming",
                    "created_at": iso8601(),
                    "installation_id": identity.installation_id,
                    "api_url": payload["api_url"],
                    "enrollment": enrollment,
                },
            )
            return
        if phase == "claim_rejected":
            existing = _load_remote_enrollment(paths)
            if existing is None or existing["phase"] != "claiming":
                raise StateError("The rejected candidate claim was not durably armed.")
            _discard_remote_enrollment(paths)
            return
        if phase == "claimed":
            existing = _load_remote_enrollment(paths)
            if existing is None or existing["phase"] != "claiming":
                raise StateError("The candidate enrollment claim was not durably armed.")
            descriptor = {
                **payload,
                "schema": REMOTE_ENROLLMENT_SCHEMA,
                "phase": "claimed",
                "created_at": existing.get("created_at", iso8601()),
                "installation_id": identity.installation_id,
            }
            _save_remote_enrollment(paths, descriptor)
            return
        if phase != "proven":
            raise StateError("The candidate enrollment observer received an unknown phase.")
        descriptor = _load_remote_enrollment(paths)
        if descriptor is None or descriptor["phase"] != "claimed":
            raise StateError("The candidate enrollment proof has no durable claim receipt.")
        if (
            payload.get("host_id") != descriptor["host_id"]
            or payload.get("api_url") != descriptor["api_url"]
            or payload.get("deployment_audience")
            != descriptor["deployment_audience"]
        ):
            raise StateError("The candidate enrollment proof changed remote authority.")
        descriptor.update(payload)
        descriptor["phase"] = "proven"
        # Persist proof authority before its derived signing config. Recovery
        # can reconstruct the latter after a kill between these atomic writes.
        _save_remote_enrollment(paths, descriptor)
        candidate_store.save(_recovery_candidate_config(old, descriptor, payload))

    candidate = enroll(
        paths=paths,
        api_url=api_url,
        pairing_code=pairing_code,
        tier=tier,
        access=access,
        workspace=workspace or Path(old.workspace),
        adopt_existing_workspace=adopt_existing_workspace,
        native_mount_enabled=native_mount_enabled,
        store=candidate_store,
        identity=identity,
        prior_config=old,
        defer_workspace_binding=True,
        enrollment_observer=observe_enrollment,
    )
    if candidate.account_id is None or candidate.account_email is None:
        raise StateError("The replacement enrollment omitted its authenticated account identity.")
    catalog = WorkspaceCatalogClient(
        SignedClient(candidate_store, identity), candidate.host_id
    ).refresh(_candidate_catalog(paths))
    if (
        catalog.account.id != candidate.account_id
        or catalog.account.email != candidate.account_email
    ):
        raise StateError("The replacement catalog does not match its authenticated account.")

    # The active runner may advance heartbeat/request fields while preparation
    # performs network I/O, but immutable authority must remain unchanged.
    current = active_store.require()
    if not _same_authority(current, receipt["old_authority"]):
        raise StateError("The active Meshia account changed during cutover preparation.")
    receipt.update(
        {
            "phase": "prepared",
            "new_authority": _authority(candidate),
            "new_account_email": candidate.account_email,
            "catalog_generation": catalog.snapshot_generation,
        }
    )
    _save_receipt(paths, receipt)
    return candidate


def activate(paths: Paths) -> None:
    """Describe the stop/activation crash window before the old service stops."""

    receipt = inspect(paths)
    if receipt is None or receipt["phase"] != "prepared":
        raise StateError("No completely prepared account cutover is ready to activate.")
    current = ConfigStore(paths).require()
    if not _same_authority(current, receipt["old_authority"]):
        raise StateError("The active account no longer matches the prepared cutover.")
    candidate = _candidate_store(paths).require()
    catalog = _candidate_catalog(paths).load()
    if (
        catalog is None
        or candidate.account_id is None
        or catalog.account.id != candidate.account_id
        or catalog.snapshot_generation != receipt.get("catalog_generation")
        or not _same_authority(candidate, receipt.get("new_authority"))
    ):
        raise StateError("The prepared replacement identity or catalog is incomplete.")
    receipt["phase"] = "activating"
    receipt["activating_at"] = iso8601()
    receipt["old_lifecycle"] = current.lifecycle
    _save_receipt(paths, receipt)


def relocate_prior_runtime(paths: Paths, runtime: Path) -> None:
    """Record the immutable destination of a just-migrated legacy runtime."""

    receipt = inspect(paths)
    if receipt is None or receipt["phase"] != "activating":
        raise StateError("No activating account cutover can relocate its prior runtime.")
    try:
        resolved = runtime.resolve(strict=True)
        runtimes = (paths.home / "runtimes").resolve(strict=True)
    except OSError as error:
        raise StateError("The relocated prior runtime could not be resolved.") from error
    if (
        runtime.is_symlink()
        or resolved.parent != runtimes
        or not resolved.is_dir()
        or not (resolved / "bin" / "meshia-node").is_file()
    ):
        raise StateError("The relocated prior runtime is not an immutable runtime child.")
    if not _same_authority(ConfigStore(paths).require(), receipt["old_authority"]):
        raise StateError("The active account changed while relocating its prior runtime.")
    receipt["prior_runtime"] = str(resolved)
    receipt["prior_runtime_relocated_at"] = iso8601()
    _save_receipt(paths, receipt)


def publish(paths: Paths) -> NodeConfig:
    """Publish the prepared catalog and config after the old runner is stopped."""

    # Hidden installer phases remain safe when invoked directly or replayed by
    # a stale script.  The old runner owns this OS lease for its entire mount
    # lifetime, so publication cannot overlap an old-account mount.
    with ConnectionLease(paths.connection_lock):
        return _publish_stopped(paths)


def _publish_stopped(paths: Paths) -> NodeConfig:
    """Publish while holding proof that no node runner owns the mount."""

    receipt = inspect(paths)
    if receipt is None or receipt["phase"] != "activating":
        raise StateError("No activated account cutover is available to publish.")
    active_store = ConfigStore(paths)
    old = active_store.require()
    if not _same_authority(old, receipt["old_authority"]):
        raise StateError("The active account no longer matches the prepared cutover.")
    candidate = _candidate_store(paths).require()
    candidate_identity = _candidate_identity(paths, candidate.installation_id)
    active_identity = DeviceIdentity.load_or_create(paths.identity_dir)
    catalog = _candidate_catalog(paths).load()
    if (
        catalog is None
        or candidate.account_id is None
        or catalog.account.id != candidate.account_id
        or catalog.snapshot_generation != receipt.get("catalog_generation")
        or not _same_authority(candidate, receipt.get("new_authority"))
        or candidate_identity.installation_id != active_identity.installation_id
    ):
        raise StateError("The prepared replacement identity or catalog is incomplete.")

    # Snapshot the final old config only after service stop, so rollback does
    # not rewind its last signed sequence or lifecycle write.
    _previous_store(paths).save(old)
    write_private_file(
        _root(paths) / "previous-device-key.pem", active_identity.key_path.read_bytes()
    )
    WorkspaceCatalogStore(paths.account_workspace_catalog(candidate.account_id)).save(
        catalog
    )
    # Describe the rollback requirement before the active config replacement.
    # A crash on either side of that one-file publication is then recovered by
    # restoring previous-config.json (idempotently if the old config is still
    # active).
    receipt["old_lifecycle"] = old.lifecycle
    receipt["phase"] = "published"
    receipt["published_at"] = iso8601()
    _save_receipt(paths, receipt)
    write_private_file(
        active_identity.key_path, candidate_identity.key_path.read_bytes()
    )
    active_store.save(candidate)
    return candidate


def rollback(paths: Paths) -> NodeConfig | None:
    """Restore the exact stopped old config; account-scoped new state stays hidden."""

    receipt = inspect(paths)
    if receipt is None:
        return None
    if receipt["phase"] == "committed":
        raise StateError("A committed account cutover cannot be rolled back.")
    if receipt["phase"] == "rolled_back":
        previous = ConfigStore(paths).require()
        if not _same_authority(previous, receipt["old_authority"]):
            raise StateError("The restored account changed before candidate retirement.")
        _finish_remote_retirement(paths, receipt)
        return previous
    if receipt["phase"] == "published":
        with ConnectionLease(paths.connection_lock):
            previous = _previous_store(paths).require()
            if not _same_authority(previous, receipt["old_authority"]):
                raise StateError("The account-cutover rollback config has wrong authority.")
            old_key = _root(paths) / "previous-device-key.pem"
            if old_key.is_symlink() or not old_key.is_file():
                raise StateError("The prior account signing key is unavailable.")
            write_private_file(paths.identity_dir / "device-key.pem", old_key.read_bytes())
            ConfigStore(paths).save(previous)
    else:
        previous = ConfigStore(paths).require()
        if not _same_authority(previous, receipt["old_authority"]):
            raise StateError("The active account changed before cutover rollback.")
    _finish_remote_retirement(paths, receipt)
    return previous


def commit(paths: Paths) -> NodeConfig:
    """Durably mark readiness before the installer retires rollback material."""

    receipt = inspect(paths)
    if receipt is None or receipt["phase"] != "published":
        raise StateError("No published account cutover is ready to commit.")
    current = ConfigStore(paths).require()
    if not _same_authority(current, receipt.get("new_authority")):
        raise StateError("The active account does not match the published cutover.")
    if current.account_id is None:
        raise StateError("The published account cutover has no account identity.")
    catalog = WorkspaceCatalogStore(paths.account_workspace_catalog(current.account_id)).load()
    if (
        catalog is None
        or catalog.account.id != current.account_id
        or catalog.account.email != current.account_email
        or catalog.snapshot_generation != receipt.get("catalog_generation")
    ):
        raise StateError("The published account catalog is unavailable at commit.")
    receipt["phase"] = "committed"
    receipt["committed_at"] = iso8601()
    _save_receipt(paths, receipt)
    return current


def finalize(paths: Paths) -> NodeConfig:
    """Retire rollback material after a durable commit marker exists."""

    receipt = inspect(paths)
    if receipt is None or receipt["phase"] != "committed":
        raise StateError("No committed account cutover is ready to finalize.")
    current = ConfigStore(paths).require()
    if not _same_authority(current, receipt.get("new_authority")):
        raise StateError("The active account does not match the committed cutover.")
    _clean_candidate(paths)
    return current


__all__ = [
    "activate",
    "abort_prepared",
    "commit",
    "finalize",
    "inspect",
    "prepare",
    "publish",
    "relocate_prior_runtime",
    "retry_remote_retirement",
    "rollback",
]
