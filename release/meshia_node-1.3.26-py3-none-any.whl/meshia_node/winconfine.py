"""Windows exec confinement: a low-integrity child may WRITE only where labeled.

The Windows analog of :mod:`meshia_node.landlock`. Mandatory Integrity Control
(Vista+) enforces **no-write-up**: a process whose token carries the Low
integrity level (``S-1-16-4096``) cannot write, delete, or take ownership of
any object labeled Medium or higher — which is every ordinary file on the
host — while reads stay governed by the DACL alone. Give the workspace tree an
inheritable Low label (:func:`meshia_node.winsec.set_workspace_low_label`) and
the child can write beneath the workspace and nowhere else: the same promise
Landlock keeps on Linux, enforced by the same mechanism that confined
Protected-Mode Internet Explorer and today's browser sandboxes.

The token dance (all in :mod:`meshia_node.winexec`, which owns the spawn):
``OpenProcessToken`` → ``DuplicateTokenEx`` (primary) → ``SetTokenInformation``
(TokenIntegrityLevel = Low) → ``CreateProcessAsUserW``. Assigning a lowered
duplicate of the caller's *own* token needs no privilege, so the node never
requires elevation.

Known residual surface, accepted and documented:

* other **Low-labeled** locations (``%USERPROFILE%\\AppData\\LocalLow``, some
  browser cache directories) remain writable — they are designed as low-IL
  spill areas and hold nothing load-bearing;
* reads are intentionally host-wide (that *is* `limited` access: read-only
  outside the workspace) except where DACLs already deny the user;
* like Landlock's filesystem ruleset, network reach is not confined here —
  ``network: deny`` is a protocol-level capability statement, identical on
  both platforms.

This module only *probes* (side-effect-free) so `doctor` and the executor can
fail closed without spawning anything; on non-Windows platforms it reports
"unavailable" without touching any API, and the caller refuses the exec.
"""

from __future__ import annotations

import ctypes
import shutil
import sys

MARKER = "meshia-winconfine"

LOW_INTEGRITY_SID = "S-1-16-4096"
SE_GROUP_INTEGRITY = 0x00000020
TOKEN_INTEGRITY_LEVEL = 25  # TOKEN_INFORMATION_CLASS
TOKEN_DUPLICATE = 0x0002
TOKEN_QUERY = 0x0008
TOKEN_ADJUST_DEFAULT = 0x0080
TOKEN_ASSIGN_PRIMARY = 0x0001
SECURITY_IMPERSONATION = 2
TOKEN_PRIMARY = 1

_probe_cache: tuple[bool, str] | None = None


class WinconfineUnavailable(Exception):
    """Low-integrity confinement cannot contain a child on this host."""


class SidAndAttributes(ctypes.Structure):
    _fields_ = [("Sid", ctypes.c_void_p), ("Attributes", ctypes.c_ulong)]


class TokenMandatoryLabel(ctypes.Structure):
    _fields_ = [("Label", SidAndAttributes)]


def _declare_win32(advapi32: object, kernel32: object) -> None:
    """Pin restype/argtypes on every call used here.

    Without this ctypes assumes ``int`` — 32 bits — for both returns and
    arguments, so a 64-bit HANDLE is silently truncated. ``GetCurrentProcess()``
    returns the pseudo-handle ``(HANDLE)-1``; truncated to 32 bits it arrives as
    ``0x00000000FFFFFFFF`` and ``OpenProcessToken`` fails with
    ERROR_INVALID_HANDLE (6). That is exactly how this shipped once: confinement
    reported "unavailable" on every Windows host, and because `limited` access
    fails closed, exec was refused rather than run unconfined — safe, but the
    capability was dead.
    """
    kernel32.GetCurrentProcess.restype = ctypes.c_void_p  # type: ignore[attr-defined]
    kernel32.GetCurrentProcess.argtypes = []  # type: ignore[attr-defined]
    kernel32.CloseHandle.restype = ctypes.c_int  # type: ignore[attr-defined]
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]  # type: ignore[attr-defined]
    kernel32.LocalFree.restype = ctypes.c_void_p  # type: ignore[attr-defined]
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]  # type: ignore[attr-defined]

    advapi32.OpenProcessToken.restype = ctypes.c_int  # type: ignore[attr-defined]
    advapi32.OpenProcessToken.argtypes = [  # type: ignore[attr-defined]
        ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_void_p),
    ]
    advapi32.DuplicateTokenEx.restype = ctypes.c_int  # type: ignore[attr-defined]
    advapi32.DuplicateTokenEx.argtypes = [  # type: ignore[attr-defined]
        ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
        ctypes.POINTER(ctypes.c_void_p),
    ]
    advapi32.ConvertStringSidToSidW.restype = ctypes.c_int  # type: ignore[attr-defined]
    advapi32.ConvertStringSidToSidW.argtypes = [  # type: ignore[attr-defined]
        ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_void_p),
    ]
    advapi32.GetLengthSid.restype = ctypes.c_ulong  # type: ignore[attr-defined]
    advapi32.GetLengthSid.argtypes = [ctypes.c_void_p]  # type: ignore[attr-defined]
    advapi32.SetTokenInformation.restype = ctypes.c_int  # type: ignore[attr-defined]
    advapi32.SetTokenInformation.argtypes = [  # type: ignore[attr-defined]
        ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong,
    ]


def build_low_integrity_token() -> ctypes.c_void_p:
    """A primary duplicate of this process's token, lowered to Low integrity.

    The caller owns the returned handle (close with ``CloseHandle``) and the
    SID buffer lifetime is contained here: ``SetTokenInformation`` copies the
    label into the token, so nothing needs to outlive this function but the
    token handle itself.
    """
    if sys.platform != "win32":
        raise WinconfineUnavailable(f"{MARKER}: Windows-only operation on {sys.platform}")
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)  # type: ignore[attr-defined]
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    _declare_win32(advapi32, kernel32)

    def _fail(step: str) -> WinconfineUnavailable:
        return WinconfineUnavailable(f"{MARKER}: {step} failed ({ctypes.get_last_error()})")

    process_token = ctypes.c_void_p()
    if not advapi32.OpenProcessToken(
        kernel32.GetCurrentProcess(),
        TOKEN_DUPLICATE | TOKEN_QUERY | TOKEN_ADJUST_DEFAULT | TOKEN_ASSIGN_PRIMARY,
        ctypes.byref(process_token),
    ):
        raise _fail("OpenProcessToken")
    try:
        duplicate = ctypes.c_void_p()
        if not advapi32.DuplicateTokenEx(
            process_token,
            0x02000000,  # MAXIMUM_ALLOWED
            None,
            SECURITY_IMPERSONATION,
            TOKEN_PRIMARY,
            ctypes.byref(duplicate),
        ):
            raise _fail("DuplicateTokenEx")
        try:
            sid = ctypes.c_void_p()
            if not advapi32.ConvertStringSidToSidW(
                ctypes.c_wchar_p(LOW_INTEGRITY_SID), ctypes.byref(sid)
            ):
                raise _fail("ConvertStringSidToSidW")
            try:
                label = TokenMandatoryLabel()
                label.Label.Sid = sid
                label.Label.Attributes = SE_GROUP_INTEGRITY
                size = ctypes.sizeof(label) + advapi32.GetLengthSid(sid)
                if not advapi32.SetTokenInformation(
                    duplicate, TOKEN_INTEGRITY_LEVEL, ctypes.byref(label), size
                ):
                    raise _fail("SetTokenInformation(TokenIntegrityLevel)")
            finally:
                kernel32.LocalFree(sid)
        except BaseException:
            kernel32.CloseHandle(duplicate)
            raise
        return duplicate
    finally:
        kernel32.CloseHandle(process_token)


def _probe() -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, (
            f"Windows integrity-level confinement requires Windows (this host is {sys.platform})"
        )
    if shutil.which("icacls") is None:  # pragma: no cover - icacls ships with Windows
        return False, "icacls is unavailable, so the workspace cannot carry a low-IL label"
    try:  # pragma: no cover - exercised on Windows hosts
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
        token = build_low_integrity_token()
        kernel32.CloseHandle(token)
    except WinconfineUnavailable as error:  # pragma: no cover - Windows-only path
        return False, str(error)
    except Exception as error:  # pragma: no cover - defensive: broken ctypes
        return False, f"the low-integrity token probe could not run: {error}"
    return True, "Windows low-integrity (no-write-up) confinement"  # pragma: no cover


def probe() -> tuple[bool, str]:
    """Return ``(available, detail)``; cached, the answer cannot change mid-process."""
    global _probe_cache
    if _probe_cache is None:
        _probe_cache = _probe()
    return _probe_cache


def available() -> bool:
    return probe()[0]


def detail() -> str:
    return probe()[1]


__all__ = [
    "LOW_INTEGRITY_SID",
    "MARKER",
    "WinconfineUnavailable",
    "available",
    "build_low_integrity_token",
    "detail",
    "probe",
]
