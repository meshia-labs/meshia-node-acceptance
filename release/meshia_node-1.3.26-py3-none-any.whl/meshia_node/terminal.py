"""Interactive PTY sessions, speaking the pod daemon's terminal wire shapes.

A workspace user gets the same terminal against a connected host as against a
pod. The *frames* are byte-identical to the ones ``pod/daemon/server.py`` pushes
over its WebSocket::

    {"type": "terminal_output",  "data": <str>, "terminal_id": <str>}
    {"type": "terminal_history", "data": <str>, "terminal_id": <str>}

and the client-to-node messages carry the same field names the pod accepts
(``terminal_input.data``, ``terminal_resize.cols/rows``, ``terminal_close``).

Where this diverges, and why
----------------------------
The pod is reachable at a URL, so the browser opens a WebSocket to it and the
pod *pushes* output frames. A connected host is a laptop behind NAT: it has no
inbound path, and its whole protocol is the outbound signed claim/complete loop
in :mod:`meshia_node.executor`. So the node cannot push. Output frames are
buffered here and drain on the next terminal command's *result* — a
``terminal_poll`` when the client has nothing to send, or riding along with a
``terminal_input`` when it does. The frames inside are unchanged, so a relay
that owns the browser WebSocket forwards them verbatim; only the carrier
differs. Nothing about the frame shapes needs the web terminal to special-case
a connected host.

Confinement
-----------
A shell is strictly more capable than one ``exec`` argv, so it gets *at least*
the same treatment and never less:

* ``personal`` tier — refused outright, exactly as ``exec`` is.
* ``limited`` access — the PTY child is confined by the platform mechanism
  (Landlock on Linux, low-integrity token on Windows) to writing only inside
  the workspace, and additionally **denied all access to the node's own state
  directory**, so the device key backing this host's identity cannot be read
  from the shell. No mechanism available means no terminal, the same
  fail-closed rule ``exec`` follows.
* ``full`` access — unconfined, because the owner said the machine is theirs.
  This matches ``exec`` in ``full`` access.

In every mode the child's environment is :func:`executor.scrubbed_environment`
— the same allowlist that keeps tokens and node configuration out of an exec'd
child. The only difference is ``TERM``: a PTY needs a real terminfo entry, so
``TERM=xterm-256color`` replaces the ``dumb`` an argv exec gets. The node's
credential lives on disk, never in the environment, so no environment variable
can carry it into the shell.
"""

from __future__ import annotations

import codecs
import os
import re
import signal
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .errors import InvalidTask

# ---------------------------------------------------------------- pod parity
# These four mirror pod/daemon/server.py so a session behaves the same on either
# backend. Keep them in step with the pod if it ever retunes them.
MAX_INPUT_BYTES = 64 * 1024  # pod: _TERMINAL_INPUT_MAX_BYTES
MAX_HISTORY_CHARS = 120_000  # pod: _TERMINAL_HISTORY_MAX_CHARS
IDLE_TTL_SECONDS = 15 * 60  # pod: _TERMINAL_SESSION_IDLE_TTL_SECONDS
MAX_TERMINALS = 9  # pod: _MAX_TERMINALS_PER_CLIENT
TERMINAL_ID_RE = re.compile(r"^[A-Za-z0-9_.-]{1,40}$")  # pod: _TERMINAL_ID_RE

# ------------------------------------------------------------- node-only caps
# The pod pushes output the instant it reads it; a buffered transport has to say
# what happens when nobody drains. Oldest bytes go first and the loss is
# reported, because a terminal that silently skips output is worse than one that
# admits it dropped some.
MAX_PENDING_OUTPUT_BYTES = 1_048_576
# A shell nobody ever closes must not outlive the connection indefinitely.
MAX_LIFETIME_SECONDS = 12 * 60 * 60
READ_CHUNK_BYTES = 65536
KILL_GRACE_SECONDS = 3.0
DEFAULT_COLS = 80
DEFAULT_ROWS = 24
MAX_DIMENSION = 10_000

TERMINAL_COMMANDS = (
    "terminal_open",
    "terminal_input",
    "terminal_poll",
    "terminal_resize",
    "terminal_close",
)


class TerminalUnavailable(Exception):
    """No PTY mechanism on this platform."""


def available() -> bool:
    """True when this platform can back a terminal session with a real PTY."""
    if sys.platform == "win32":
        from . import winpty

        return winpty.available()
    return hasattr(os, "openpty")


def detail() -> str:
    """Human-readable PTY status, for `doctor` output and error messages."""
    if sys.platform == "win32":
        from . import winpty

        return winpty.detail()
    if hasattr(os, "openpty"):
        return f"POSIX pty ({sys.platform})"
    return f"no pty support on {sys.platform}"


def normalize_terminal_id(value: Any) -> str:
    """The pod's rule: 1-40 chars of letters, digits, dot, underscore, dash."""
    terminal_id = "default" if value in (None, "") else str(value)
    if not TERMINAL_ID_RE.fullmatch(terminal_id):
        raise InvalidTask(
            "terminal_id must be 1-40 chars: letters, numbers, dot, underscore, dash"
        )
    return terminal_id


def default_shell() -> list[str]:
    """The argv for an interactive shell on this host.

    Deliberately *not* a login shell. A login shell sources the owner's profile
    files, which would put whatever they export back into an environment this
    module just finished scrubbing; starting from the allowlist and staying
    there is what makes the environment a stated property rather than a guess.
    """
    if sys.platform == "win32":
        return [os.environ.get("COMSPEC") or r"C:\Windows\System32\cmd.exe"]
    for candidate in ("/bin/bash", "/bin/sh"):
        if os.path.exists(candidate):
            return [candidate]
    return ["/bin/sh"]


@dataclass
class _Pending:
    """Buffered output waiting for the next drain, with honest loss accounting."""

    text: str = ""
    dropped_bytes: int = 0

    def append(self, chunk: str) -> None:
        if not chunk:
            return
        self.text += chunk
        overflow = len(self.text.encode("utf-8", "replace")) - MAX_PENDING_OUTPUT_BYTES
        if overflow > 0:
            # Drop from the front: a terminal's newest output is the useful one.
            encoded = self.text.encode("utf-8", "replace")
            self.dropped_bytes += overflow
            self.text = encoded[overflow:].decode("utf-8", "replace")

    def drain(self) -> tuple[str, int]:
        text, dropped = self.text, self.dropped_bytes
        self.text, self.dropped_bytes = "", 0
        return text, dropped


@dataclass
class TerminalSession:
    """One PTY-backed shell, its reader thread, and its buffered output.

    Mirrors the pod's ``TerminalSession`` in behaviour (bounded input, bounded
    history, idle expiry, process-group teardown); it is threaded rather than
    asyncio because the node runner is a single synchronous loop.
    """

    terminal_id: str
    cwd: str
    env: dict[str, str]
    argv: list[str]
    # POSIX: a preexec callable (Landlock). Windows: the low-integrity token is
    # built by winpty from `confined_root`, since there is no fork to hook.
    confine: Callable[[], None] | None = None
    confined_root: str | None = None
    cols: int = DEFAULT_COLS
    rows: int = DEFAULT_ROWS
    clock: Callable[[], float] = time.monotonic

    process: subprocess.Popen[bytes] | None = field(default=None, init=False)
    _master_fd: int | None = field(default=None, init=False)
    _pending: _Pending = field(default_factory=_Pending, init=False)
    _history: str = field(default="", init=False)
    _reader: threading.Thread | None = field(default=None, init=False)
    _lock: threading.RLock = field(default_factory=threading.RLock, init=False)
    _closed: bool = field(default=False, init=False)
    _started_at: float = field(default=0.0, init=False)
    _touched_at: float = field(default=0.0, init=False)
    _backend: Any = field(default=None, init=False)  # winpty.ConPty on Windows

    # ------------------------------------------------------------------ start

    def start(self) -> None:
        with self._lock:
            if self.process is not None and self.process.poll() is None:
                return
            if not available():
                raise TerminalUnavailable(detail())
            self._started_at = self._touched_at = self.clock()
            if sys.platform == "win32":
                self._start_windows()
            else:
                self._start_posix()
            self._reader = threading.Thread(
                target=self._read_loop, name=f"meshia-pty-{self.terminal_id}", daemon=True
            )
            self._reader.start()

    def _start_posix(self) -> None:
        import pty

        master_fd, slave_fd = pty.openpty()
        try:
            set_winsize(slave_fd, self.cols, self.rows)
            self.process = subprocess.Popen(  # noqa: S603 - argv list, never a shell string
                self.argv,
                cwd=self.cwd,
                env=self.env,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                close_fds=True,
                preexec_fn=self._child_setup,
            )
        except BaseException:
            os.close(master_fd)
            raise
        finally:
            os.close(slave_fd)
        self._master_fd = master_fd

    def _child_setup(self) -> None:  # pragma: no cover - runs in the forked child
        """Session leader, controlling terminal, then confinement — in that order.

        Confinement goes last on purpose: it is irreversible, so everything the
        child still needs the kernel's permission for has to happen first.
        """
        os.setsid()
        try:
            import fcntl
            import termios

            fcntl.ioctl(0, termios.TIOCSCTTY, 0)
        except Exception:
            # A missing controlling terminal costs job control, not correctness.
            pass
        if self.confine is not None:
            self.confine()

    def _start_windows(self) -> None:
        from . import winpty

        self._backend = winpty.ConPty.spawn(
            self.argv,
            cwd=self.cwd,
            env=self.env,
            cols=self.cols,
            rows=self.rows,
            confined_root=self.confined_root,
        )

    # ------------------------------------------------------------------- read

    def _read_loop(self) -> None:
        decoder = codecs.getincrementaldecoder("utf-8")("replace")
        try:
            while True:
                data = self._read_chunk()
                if not data:
                    break
                decoded = decoder.decode(data)
                if decoded:
                    with self._lock:
                        self._pending.append(decoded)
                        self._history = (self._history + decoded)[-MAX_HISTORY_CHARS:]
        except (OSError, ValueError):
            pass
        finally:
            tail = decoder.decode(b"", final=True)
            if tail:
                with self._lock:
                    self._pending.append(tail)

    def _read_chunk(self) -> bytes:
        if self._backend is not None:
            return self._backend.read(READ_CHUNK_BYTES)
        fd = self._master_fd
        if fd is None:
            return b""
        try:
            return os.read(fd, READ_CHUNK_BYTES)
        except OSError:
            # A PTY master reports the slave's exit as EIO, not as EOF.
            return b""

    # ------------------------------------------------------------------ write

    def write(self, data: str) -> int:
        """Write one bounded chunk to the PTY; returns the bytes actually written.

        The cap is the pod's: a single message can never shove unbounded input
        at a shell, whether it came from a person or from a prompt-injected
        agent.

        The whole write happens under the session lock, so the descriptor cannot
        be closed and recycled underneath it. That is safe because the reader
        thread blocks in ``os.read`` *outside* the lock; only drain/resize wait,
        and only for as long as one bounded chunk takes.
        """
        import select

        encoded = data.encode("utf-8", "replace")[:MAX_INPUT_BYTES]
        with self._lock:
            self._touched_at = self.clock()
            if not self.is_running():
                return 0
            if self._backend is not None:
                return self._backend.write(encoded)
            fd = self._master_fd
            if fd is None:
                return 0
            written = 0
            remaining = memoryview(encoded)
            while remaining:
                # A shell that stopped reading must not wedge the session; give
                # up on the rest of the chunk instead of blocking forever.
                if not select.select([], [fd], [], 5.0)[1]:
                    break
                try:
                    count = os.write(fd, remaining)
                except OSError:
                    break
                written += count
                remaining = remaining[count:]
            return written

    def resize(self, cols: int, rows: int) -> None:
        cols = max(1, min(int(cols), MAX_DIMENSION))
        rows = max(1, min(int(rows), MAX_DIMENSION))
        with self._lock:
            self.cols, self.rows = cols, rows
            self._touched_at = self.clock()
            if self._backend is not None:
                self._backend.resize(cols, rows)
            elif self._master_fd is not None:
                try:
                    set_winsize(self._master_fd, cols, rows)
                except OSError:
                    pass

    # ------------------------------------------------------------------ drain

    def drain(self) -> tuple[str, int]:
        with self._lock:
            self._touched_at = self.clock()
            return self._pending.drain()

    def history(self) -> str:
        with self._lock:
            return self._history

    def has_pending(self) -> bool:
        """Undrained output — a dead shell's last words still have to reach the client."""
        with self._lock:
            return bool(self._pending.text) or self._pending.dropped_bytes > 0

    def is_running(self) -> bool:
        if self._closed:
            return False
        if self._backend is not None:
            return self._backend.is_running()
        return self.process is not None and self.process.poll() is None

    def exit_code(self) -> int | None:
        if self._backend is not None:
            return self._backend.exit_code()
        return self.process.poll() if self.process is not None else None

    def expired(self) -> bool:
        """Idle past the pod's TTL, or older than the absolute lifetime cap."""
        now = self.clock()
        return (
            now - self._touched_at >= IDLE_TTL_SECONDS
            or now - self._started_at >= MAX_LIFETIME_SECONDS
        )

    # ------------------------------------------------------------------ close

    def close(self) -> None:
        """Terminate the shell's whole process group, then release the PTY."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            backend, process, fd = self._backend, self.process, self._master_fd
            self._master_fd = None
        if backend is not None:
            backend.close()
        elif process is not None and process.poll() is None:
            _terminate_group(process)
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        reader = self._reader
        if reader is not None and reader is not threading.current_thread():
            reader.join(timeout=2.0)


def set_winsize(fd: int, cols: int, rows: int) -> None:
    """TIOCSWINSZ, the same struct layout the pod packs."""
    import fcntl
    import struct
    import termios

    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", max(1, rows), max(1, cols), 0, 0))


def _terminate_group(process: subprocess.Popen[bytes]) -> None:
    """Kill the shell and everything it started, then reap it.

    Killing the shell's *process group* is not enough. An interactive shell has
    job control, so ``sleep 120 &`` runs in a process group of its own and
    survives a ``killpg`` aimed at the shell. What every one of those jobs does
    share is the **session** the PTY child created with ``setsid``, and that
    session contains nothing but this terminal's descendants — so sweeping it is
    both sufficient and safe.
    """
    try:
        session_id = os.getsid(process.pid)
    except OSError:
        session_id = None

    for send, wait in ((signal.SIGTERM, KILL_GRACE_SECONDS), (signal.SIGKILL, 2.0)):
        try:
            os.killpg(os.getpgid(process.pid), send)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                process.send_signal(send)
            except OSError:
                pass
        if session_id is not None:
            _signal_session(session_id, send)
        try:
            process.wait(timeout=wait)
            return
        except subprocess.TimeoutExpired:
            continue


def _signal_session(session_id: int, send: int) -> None:
    """Signal every process in `session_id` except this one.

    The session was created by our own ``setsid`` in the PTY child, so its
    membership is exactly the terminal's process tree.
    """
    own_pid = os.getpid()
    for pid in _live_pids():
        if pid <= 1 or pid == own_pid:
            continue
        try:
            if os.getsid(pid) != session_id:
                continue
            os.kill(pid, send)
        except OSError:
            continue


def _live_pids() -> list[int]:
    """Every PID on the host. ``/proc`` where it exists, ``ps`` where it does not."""
    proc = "/proc"
    if os.path.isdir(proc):
        pids = []
        for entry in os.listdir(proc):
            if entry.isdigit():
                pids.append(int(entry))
        return pids
    try:
        completed = subprocess.run(  # noqa: S603 - fixed argv, no shell
            ["/bin/ps", "-A", "-o", "pid="],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    return [int(token) for token in completed.stdout.split() if token.isdigit()]


class TerminalRegistry:
    """Keyed PTY sessions behind one lock, capped like the pod's per-client map."""

    def __init__(self, max_sessions: int = MAX_TERMINALS) -> None:
        self._sessions: dict[str, TerminalSession] = {}
        self._lock = threading.RLock()
        self.max_sessions = max_sessions

    def get(self, terminal_id: str) -> TerminalSession | None:
        with self._lock:
            self._reap_locked()
            return self._sessions.get(terminal_id)

    def require(self, terminal_id: str) -> TerminalSession:
        session = self.get(terminal_id)
        if session is None:
            raise InvalidTask(f"No terminal session {terminal_id!r} is open on this host.")
        return session

    def open(self, terminal_id: str, factory: Callable[[], TerminalSession]) -> TerminalSession:
        with self._lock:
            self._reap_locked()
            existing = self._sessions.get(terminal_id)
            if existing is not None and existing.is_running():
                return existing
            if existing is not None:
                existing.close()
                self._sessions.pop(terminal_id, None)
            if len(self._sessions) >= self.max_sessions:
                raise InvalidTask(f"maximum {self.max_sessions} terminals per host")
            session = factory()
            session.start()
            self._sessions[terminal_id] = session
            return session

    def close(self, terminal_id: str) -> bool:
        with self._lock:
            session = self._sessions.pop(terminal_id, None)
        if session is None:
            return False
        session.close()
        return True

    def close_all(self) -> None:
        """Called when the node disconnects: no PTY outlives its connection."""
        with self._lock:
            sessions = list(self._sessions.values())
            self._sessions.clear()
        for session in sessions:
            session.close()

    def ids(self) -> list[str]:
        with self._lock:
            return sorted(self._sessions)

    def _reap_locked(self) -> None:
        """Drop sessions past their idle TTL or lifetime cap — and only those.

        A shell that has *exited* deliberately stays in the registry. The client
        has to be able to see ``running: false`` and collect the shell's last
        output; reaping it the instant it died would turn a normal ``exit`` into
        "no such terminal" and lose the final frames.
        """
        for terminal_id, session in list(self._sessions.items()):
            if session.expired():
                self._sessions.pop(terminal_id, None)
                session.close()


def output_frame(terminal_id: str, data: str) -> dict[str, Any]:
    """The pod's ``terminal_output`` frame, field for field."""
    return {"type": "terminal_output", "data": data, "terminal_id": terminal_id}


def history_frame(terminal_id: str, data: str) -> dict[str, Any]:
    """The pod's ``terminal_history`` frame, field for field."""
    return {"type": "terminal_history", "data": data, "terminal_id": terminal_id}


__all__ = [
    "IDLE_TTL_SECONDS",
    "MAX_HISTORY_CHARS",
    "MAX_INPUT_BYTES",
    "MAX_LIFETIME_SECONDS",
    "MAX_PENDING_OUTPUT_BYTES",
    "MAX_TERMINALS",
    "TERMINAL_COMMANDS",
    "TERMINAL_ID_RE",
    "TerminalRegistry",
    "TerminalSession",
    "TerminalUnavailable",
    "available",
    "default_shell",
    "detail",
    "history_frame",
    "normalize_terminal_id",
    "output_frame",
    "set_winsize",
]
