"""Push invalidation: one signed SSE stream from meshia.io per connected host.

The control plane relays this account's ``fabric.changed`` broadcasts (a
manifest was published, the workspace catalog advanced, an attachment changed
state) over ``GET /api/connected-hosts/<host>/events``. While that stream is
healthy the node stops polling for remote changes every 1-2 s and refreshing
the catalog every 30 s: each event wakes exactly the workspace it names, and
the periodic polls become a 60 s / 300 s backstop. The moment the stream is
down the runtime reverts to today's cadence within one tick, so push is only
ever an acceleration, never a dependency.

Everything here is stdlib: the stream is opened with the same signed envelope
and keep-alive pool as every other control call, parsed line by line per the
SSE specification, and reconnected with jittered exponential backoff (1 s to
30 s) or immediately when the server sends ``event: reconnect`` ahead of its
own execution budget. The node never sees a Supabase URL or key.
"""

from __future__ import annotations

import json
import os
import random
import re
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .client import SignedClient
from .errors import Disconnected, InvalidArgument, NetworkError, RemoteError
from .log import NULL_LOGGER, NodeLogger
from .util import iso8601, write_private_file

PUSH_EVENT_NAME = "fabric.changed"
PUSH_STREAM_PATH = "api/connected-hosts/{host_id}/events"
MIN_BACKOFF_SECONDS = 1.0
MAX_BACKOFF_SECONDS = 30.0
# Three missed 15 s pings: the server is gone, not merely quiet.
READ_TIMEOUT_SECONDS = 45.0
# The sequence lock is held only until the response headers arrive; bound
# that wait so a stalled edge cannot starve heartbeats.
CONNECT_TIMEOUT_SECONDS = 10.0
MAX_LINE_BYTES = 64 * 1024
MAX_EVENT_BYTES = 256 * 1024
MAX_REJECTION_BODY_BYTES = 64 * 1024
# Cadence while the stream is healthy (spec: 60 s remote backstop, 300 s catalog).
PUSH_REMOTE_POLL_BACKSTOP_SECONDS = 60.0
PUSH_CATALOG_REFRESH_SECONDS = 300.0
# ``status`` shows the stream as connected only while the daemon keeps
# refreshing this file; a stale file means the process died mid-stream.
PUSH_STATUS_REFRESH_SECONDS = 15.0
PUSH_STATUS_STALE_SECONDS = 60.0
UUID_RE_TEXT = "^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"

_UUID_RE = re.compile(UUID_RE_TEXT, re.IGNORECASE)


@dataclass(frozen=True)
class SseEvent:
    """One dispatched server-sent event (comments never become events)."""

    name: str
    data: str
    id: str | None = None
    retry_ms: int | None = None


class SseParser:
    """Incremental SSE line parser (https://html.spec.whatwg.org/#event-stream-interpretation)."""

    def __init__(self) -> None:
        self._event = ""
        self._data: list[str] = []
        self._id: str | None = None
        self._retry: int | None = None
        self._data_bytes = 0
        self.last_event_id: str | None = None

    def feed(self, raw_line: bytes) -> SseEvent | None:
        """Feed one line (with or without its terminator); return a finished event."""

        line = raw_line.rstrip(b"\r\n").decode("utf-8", "replace")
        if line == "":
            return self._dispatch()
        if line.startswith(":"):
            return None
        field, sep, value = line.partition(":")
        if sep and value.startswith(" "):
            value = value[1:]
        if field == "event":
            self._event = value
        elif field == "data":
            self._data_bytes += len(value) + 1
            if self._data_bytes > MAX_EVENT_BYTES:
                raise NetworkError("The Meshia push stream sent an oversized event.")
            self._data.append(value)
        elif field == "id":
            if "\x00" not in value:
                self._id = value
        elif field == "retry":
            if value.isdecimal():
                self._retry = int(value)
        return None

    def _dispatch(self) -> SseEvent | None:
        if not self._data and not self._event:
            self._reset()
            return None
        event = SseEvent(
            name=self._event or "message",
            data="\n".join(self._data),
            id=self._id,
            retry_ms=self._retry,
        )
        if self._id is not None:
            self.last_event_id = self._id
        self._reset()
        return event

    def _reset(self) -> None:
        self._event = ""
        self._data = []
        self._data_bytes = 0
        self._id = None
        self._retry = None


@dataclass(frozen=True)
class PushEvent:
    """A normalized ``fabric.changed`` payload."""

    kind: str
    session_id: str | None
    source: str
    payload: dict[str, Any]


def parse_push_event(data: str) -> PushEvent | None:
    """Coerce one ``fabric.changed`` payload; anything off-vocabulary is dropped."""

    try:
        payload = json.loads(data)
    except ValueError:
        return None
    if not isinstance(payload, dict):
        return None
    kind = payload.get("kind")
    # ``fabric_v2`` is the per-commit counters broadcast (M1767): browser, MCP
    # and pod writes commit through Fabric v2 and never publish a v1 manifest,
    # so it is the only push signal for them. It is session scoped like
    # ``manifest`` and drives the same remote-change refresh.
    if kind not in {"manifest", "catalog", "attachment", "fabric_v2"}:
        return None
    session_id = payload.get("session_id")
    if kind != "catalog":
        if not isinstance(session_id, str) or _UUID_RE.fullmatch(session_id) is None:
            return None
        session_id = session_id.lower()
    else:
        session_id = None
    source = payload.get("source")
    return PushEvent(
        kind=kind,
        session_id=session_id,
        source=source if source in {"realtime", "poll"} else "unknown",
        payload=payload,
    )


@dataclass(frozen=True)
class PushHealth:
    connected: bool
    connected_at: float | None
    last_frame_at: float | None
    source: str | None
    attempts: int
    last_error: str | None


class PushClient:
    """Own one push stream on a daemon thread and translate it into wakes."""

    def __init__(
        self,
        client: SignedClient,
        *,
        host_id: str,
        on_event: Callable[[PushEvent], None],
        on_connection: Callable[[bool], None] | None = None,
        status_path: Path | None = None,
        logger: NodeLogger = NULL_LOGGER,
        clock: Callable[[], float] = time.monotonic,
        wall_clock: Callable[[], float] = time.time,
        jitter: Callable[[], float] = random.random,
        read_timeout: float = READ_TIMEOUT_SECONDS,
        min_backoff: float = MIN_BACKOFF_SECONDS,
        max_backoff: float = MAX_BACKOFF_SECONDS,
    ) -> None:
        if not isinstance(host_id, str) or _UUID_RE.fullmatch(host_id) is None:
            raise InvalidArgument("The push stream needs the enrolled host id.")
        if not 0 < min_backoff <= max_backoff:
            raise ValueError("push backoff bounds are invalid")
        self.client = client
        self.host_id = host_id.lower()
        self.on_event = on_event
        self.on_connection = on_connection
        self.status_path = status_path
        self.logger = logger
        self._clock = clock
        self._wall_clock = wall_clock
        self._jitter = jitter
        self._read_timeout = float(read_timeout)
        self._min_backoff = float(min_backoff)
        self._max_backoff = float(max_backoff)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._reply: Any | None = None
        self._connected = False
        self._connected_at: float | None = None
        self._last_frame_at: float | None = None
        self._last_status_write = float("-inf")
        self._source: str | None = None
        self._attempts = 0
        self._last_error: str | None = None
        self._last_event_id: str | None = None

    # ---------------------------------------------------------------- lifecycle

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="meshia-push-stream", daemon=True
        )
        self._thread.start()

    def close(self) -> None:
        self._stop.set()
        self._close_reply()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=5.0)
        self._thread = None
        self._set_connected(False, error=None, final=True)

    def wake(self) -> None:
        """Drop the current stream so the loop reconnects promptly."""

        self._close_reply()

    def health(self) -> PushHealth:
        with self._lock:
            return PushHealth(
                connected=self._connected,
                connected_at=self._connected_at,
                last_frame_at=self._last_frame_at,
                source=self._source,
                attempts=self._attempts,
                last_error=self._last_error,
            )

    # -------------------------------------------------------------------- loop

    def _run(self) -> None:
        backoff = self._min_backoff
        while not self._stop.is_set():
            outcome = "error"
            try:
                outcome = self.stream_once()
            except Disconnected as error:
                # Revocation is the heartbeat's decision to act on; the stream
                # simply stays down and keeps trying at the slowest cadence.
                self._set_connected(False, error=error.reason_code or "disconnected")
                self.logger.record("push_stream_revoked", reason=error.reason_code)
                backoff = self._max_backoff
            except (NetworkError, RemoteError, OSError, ValueError) as error:
                self._set_connected(False, error=type(error).__name__)
                self.logger.record(
                    "push_stream_error",
                    error_type=type(error).__name__,
                    error=str(error)[:256],
                )
            except Exception as error:  # noqa: BLE001 - the loop must survive
                self._set_connected(False, error=type(error).__name__)
                self.logger.record(
                    "push_stream_unexpected_error",
                    error_type=type(error).__name__,
                    error=str(error)[:256],
                )
            if self._stop.is_set():
                break
            if outcome in {"reconnect", "retry"}:
                # The server asked for it (budget) or repaired our envelope:
                # come straight back with only a little jitter.
                delay = self._jitter() * 1.0 if outcome == "reconnect" else 0.0
                backoff = self._min_backoff
            elif outcome == "healthy":
                backoff = self._min_backoff
                delay = backoff * (0.5 + 0.5 * self._jitter())
            else:
                delay = backoff * (0.5 + 0.5 * self._jitter())
                backoff = min(self._max_backoff, backoff * 2)
            self._stop.wait(delay)

    def stream_once(self) -> str:
        """Open one stream and consume it to the end.

        Returns ``"reconnect"`` (server budget), ``"retry"`` (envelope repaired,
        try again now), ``"healthy"`` (the stream delivered frames before it
        ended) or ``"error"``. Raises for auth failures the client classifies.
        """

        with self._lock:
            self._attempts += 1
            last_event_id = self._last_event_id
        headers = {
            "Accept": "text/event-stream",
            "Cache-Control": "no-store",
            "Content-Type": "",
        }
        if last_event_id is not None:
            headers["Last-Event-ID"] = last_event_id
        prepared, reply = self.client.open_signed_stream(
            "GET",
            PUSH_STREAM_PATH.format(host_id=self.host_id),
            headers=headers,
            timeout=min(self._read_timeout, CONNECT_TIMEOUT_SECONDS),
        )
        settimeout = getattr(reply, "settimeout", None)
        if callable(settimeout):
            try:
                settimeout(self._read_timeout)
            except OSError:
                pass
        status = int(getattr(reply, "status", None) or getattr(reply, "code", 0) or 0)
        if status != 200:
            body = self._bounded_read(reply)
            self._release(reply)
            if self.client.observe_rejection(prepared, status, body):
                return "retry"
            return "error"  # pragma: no cover - observe_rejection raises
        content_type = str(reply.headers.get("Content-Type") or "").lower()
        if not content_type.startswith("text/event-stream"):
            # Drain a bounded body first so the keep-alive socket closes with
            # FIN rather than RST (unread bytes at close reset the peer).
            self._bounded_read(reply)
            self._release(reply)
            raise NetworkError("Meshia did not answer the push stream with text/event-stream.")
        with self._lock:
            self._reply = reply
        if self._stop.is_set():
            self._release(reply)
            return "error"
        parser = SseParser()
        frames = 0
        try:
            self._set_connected(True, error=None)
            while True:
                line = reply.readline(MAX_LINE_BYTES + 1)
                if not line:
                    break
                if len(line) > MAX_LINE_BYTES:
                    raise NetworkError("The Meshia push stream sent an oversized line.")
                frames += 1
                self._touch()
                event = parser.feed(line)
                if event is None:
                    continue
                if event.id is not None:
                    with self._lock:
                        self._last_event_id = event.id
                if event.name == "reconnect":
                    return "reconnect"
                self._handle(event)
            return "healthy" if frames else "error"
        finally:
            with self._lock:
                if self._reply is reply:
                    self._reply = None
            self._release(reply)
            self._set_connected(False, error=None)

    # ---------------------------------------------------------------- handlers

    def _handle(self, event: SseEvent) -> None:
        if event.name == PUSH_EVENT_NAME:
            parsed = parse_push_event(event.data)
            if parsed is None:
                self.logger.record("push_event_ignored", reason="unrecognized_payload")
                return
            self.logger.record(
                "push_event_received",
                kind=parsed.kind,
                session_id=parsed.session_id,
                source=parsed.source,
                event_id=event.id,
            )
            try:
                self.on_event(parsed)
            except Exception as error:  # noqa: BLE001 - a handler bug must not drop the stream
                self.logger.record(
                    "push_event_handler_failed",
                    error_type=type(error).__name__,
                    error=str(error)[:256],
                )
            return
        if event.name == "source":
            try:
                payload = json.loads(event.data)
            except ValueError:
                return
            source = payload.get("source") if isinstance(payload, dict) else None
            if source in {"realtime", "poll"}:
                with self._lock:
                    self._source = source
                self._write_status(force=True)
            return
        # ``hello`` and unknown events carry no action; liveness was recorded.

    # ------------------------------------------------------------------ state

    def _touch(self) -> None:
        with self._lock:
            self._last_frame_at = float(self._clock())
        self._write_status()

    def _set_connected(self, connected: bool, *, error: str | None, final: bool = False) -> None:
        with self._lock:
            changed = connected != self._connected
            self._connected = connected
            now = float(self._clock())
            if connected:
                self._connected_at = now
                self._last_frame_at = now
                self._last_error = None
            else:
                self._connected_at = None
                self._source = None
                if error is not None:
                    self._last_error = error
        if changed:
            self.logger.record("push_stream_connected" if connected else "push_stream_disconnected")
            callback = self.on_connection
            if callback is not None:
                try:
                    callback(connected)
                except Exception as error:  # noqa: BLE001
                    self.logger.record(
                        "push_connection_handler_failed",
                        error_type=type(error).__name__,
                        error=str(error)[:256],
                    )
        if changed or final:
            self._write_status(force=True)

    def _write_status(self, *, force: bool = False) -> None:
        path = self.status_path
        if path is None:
            return
        now = float(self._clock())
        with self._lock:
            if not force and now - self._last_status_write < PUSH_STATUS_REFRESH_SECONDS:
                return
            self._last_status_write = now
            wall = float(self._wall_clock())
            document = {
                "pid": os.getpid(),
                "connected": self._connected,
                "source": self._source,
                "attempts": self._attempts,
                "last_error": self._last_error,
                "updated_at": _stamp(wall),
                "connected_at": (
                    _stamp(wall - (now - self._connected_at))
                    if self._connected_at is not None
                    else None
                ),
                "last_frame_at": (
                    _stamp(wall - (now - self._last_frame_at))
                    if self._last_frame_at is not None
                    else None
                ),
            }
        try:
            write_private_file(
                path, json.dumps(document, indent=2, sort_keys=True).encode("utf-8")
            )
        except OSError as error:
            self.logger.record("push_status_write_failed", error=str(error)[:256])

    # -------------------------------------------------------------- transport

    def _close_reply(self) -> None:
        with self._lock:
            reply = self._reply
            self._reply = None
        if reply is not None:
            self._release(reply)

    @staticmethod
    def _release(reply: Any) -> None:
        for method_name in ("close",):
            method = getattr(reply, method_name, None)
            if callable(method):
                try:
                    method()
                except Exception:  # noqa: BLE001 - closing is best effort
                    pass

    @staticmethod
    def _bounded_read(reply: Any) -> bytes:
        try:
            return bytes(reply.read(MAX_REJECTION_BODY_BYTES) or b"")
        except Exception:  # noqa: BLE001
            return b""


class PushRuntimeBridge:
    """Translate push events and stream health into runtime wakes and cadence."""

    def __init__(
        self,
        *,
        runtime_manager: Any | None,
        coordinator: Any,
        primary_session_id: str | None,
        remote_poll_backstop_seconds: float = PUSH_REMOTE_POLL_BACKSTOP_SECONDS,
    ) -> None:
        self.runtime_manager = runtime_manager
        self.coordinator = coordinator
        self.primary_session_id = (
            primary_session_id.lower() if isinstance(primary_session_id, str) else None
        )
        self.remote_poll_backstop_seconds = float(remote_poll_backstop_seconds)

    def on_connection(self, connected: bool) -> None:
        backstop = self.remote_poll_backstop_seconds if connected else None
        manager = self.runtime_manager
        if manager is not None:
            set_healthy = getattr(manager, "set_push_healthy", None)
            if callable(set_healthy):
                set_healthy(connected, remote_poll_backstop_seconds=backstop)
                return
        setter = getattr(self.coordinator, "set_remote_poll_backstop", None)
        if callable(setter):
            setter(backstop)

    def on_event(self, event: PushEvent) -> None:
        manager = self.runtime_manager
        if event.kind == "catalog":
            if manager is not None:
                request = getattr(manager, "request_catalog_refresh", None)
                if callable(request):
                    request()
            return
        if event.session_id is None:
            return
        if manager is not None:
            notify = getattr(manager, "notify_remote_change", None)
            if callable(notify):
                notify(event.session_id)
                return
        if event.session_id == self.primary_session_id:
            request_poll = getattr(self.coordinator, "request_remote_poll", None)
            if callable(request_poll):
                request_poll()


def read_push_status(path: Path, *, now: float | None = None) -> dict[str, Any]:
    """Project the daemon's push-stream file for ``status`` (read-only)."""

    try:
        if path.stat().st_size > 16 * 1024:
            return {"available": False, "state": "polling", "connected": False}
        document = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, ValueError):
        return {"available": False, "state": "polling", "connected": False}
    if not isinstance(document, dict):
        return {"available": False, "state": "polling", "connected": False}
    updated_at = _parse_iso(document.get("updated_at"))
    last_frame_at = _parse_iso(document.get("last_frame_at"))
    moment = float(time.time() if now is None else now)
    fresh = updated_at is not None and moment - updated_at <= PUSH_STATUS_STALE_SECONDS
    connected = bool(document.get("connected")) and fresh
    age = (
        max(0, int(moment - last_frame_at))
        if connected and last_frame_at is not None
        else None
    )
    source = document.get("source")
    return {
        "available": True,
        "state": "connected" if connected else "polling",
        "connected": connected,
        "source": source if source in {"realtime", "poll"} else None,
        "last_frame_age_seconds": age,
        "pid": document.get("pid") if isinstance(document.get("pid"), int) else None,
        "last_error": (
            str(document.get("last_error"))[:128]
            if document.get("last_error") is not None
            else None
        ),
    }


def _stamp(epoch_seconds: float) -> str:
    return iso8601(datetime.fromtimestamp(max(0.0, epoch_seconds), tz=timezone.utc))


def _parse_iso(value: Any) -> float | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()
