"""Persistent, bounded working-set cache for MeshiaFabric byte ranges.

The cache deliberately stores verified ranges, not materialized workspaces.  A
caller can enumerate remote metadata without touching this module, then hydrate
only the ranges an application actually reads.  Cached content is addressed by
its own SHA-256 digest and each range record keeps the manifest response that
authorized its fetch.  Reuse keys on the immutable whole-file digest, so an
unrelated workspace generation change does not invalidate unchanged files.

There is no long-lived SQLite connection.  Every metadata transaction is
protected by Meshia's cross-platform process lock, which keeps the chunk file
and database transitions ordered across the CLI, service, and future native
filesystem adapter.  Network reads happen outside that lock.
"""

from __future__ import annotations

import errno
import hashlib
import os
import sqlite3
import stat
import threading
import time
from concurrent.futures import Future
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Iterator, Mapping, Protocol, TypeAlias

from .config import file_lock
from .fabric_contract_generated import (
    FabricFileHasher, file_digest_algorithm, block_file_sha256,
    FABRIC_BLOCK_FILE_DIGEST_ALGORITHM,
)
from .util import RAW_SHA256_RE, ensure_private_dir, write_private_file

DEFAULT_CHUNK_BYTES = 1_048_576

# A Fabric v2 head has no manifest digest by design (ordering is the identity;
# integrity moved to checkpoints). Range bindings still record which head
# admitted them, so v2 admissions are labelled with this self-describing
# marker instead of a digest. It can never collide with a real manifest digest
# (not hex), and lookups never key on it: every get() resolves by the
# immutable whole-file digest, exactly as across v1 manifest generations.
FABRIC_V2_MANIFEST_IDENTITY = "fabric-v2"

DEFAULT_MAX_CACHE_BYTES = 512 * DEFAULT_CHUNK_BYTES
DEFAULT_MAX_METADATA_BYTES = 64 * DEFAULT_CHUNK_BYTES
DEFAULT_MAX_RANGE_RECORDS = 50_000
DEFAULT_MAX_OWNER_RECORDS = 4_096
DEFAULT_OWNER_LEASE_SECONDS = 6 * 60 * 60
_SCHEMA_VERSION = 2
_LRU_TOUCH_INTERVAL_NS = 30 * 1_000_000_000
_OWNER_SWEEP_INTERVAL_NS = 60 * 1_000_000_000
_MAX_OWNER_LEASE_SECONDS = 7 * 24 * 60 * 60
_MIN_METADATA_BYTES = 256 * 1024
_DISK_ACCOUNTING_SLACK_BYTES = 64 * 1024
_DEFAULT_ALLOCATION_OVERHEAD_BYTES = 64 * DEFAULT_CHUNK_BYTES
_MAX_INTEGER = (1 << 63) - 1
# Startup is on the interactive service path.  Never enumerate an untrusted
# chunks directory into memory or walk an arbitrary number of entries before
# the node can start serving cache hits.  Remaining hygiene is continued in
# equally bounded batches as misses/status calls reach the cache.
_STARTUP_RECOVERY_SCAN_ENTRIES = 4_096
_RECOVERY_DATABASE_SCAN_ROWS = 2_048
_RECOVERY_SQL_BATCH_ROWS = 512
_ROOT_ACCOUNTING_ENTRY_LIMIT = 64
MAX_COVERING_RANGES = 64
_CACHE_DATABASE_PAGE_BYTES = 4_096
# SQLite's file format reserves the final page number even when a build accepts
# a larger integer in PRAGMA max_page_count. Clamp explicitly instead of relying
# on version-specific coercion, especially with a 64-KiB database page size.
_SQLITE_MAX_PAGE_COUNT = 4_294_967_294
_CACHE_ADMISSION_PRESSURE_ERRNOS = frozenset((errno.ENOSPC, errno.EDQUOT))


class FabricCacheError(RuntimeError):
    """Base class for local cache and range contract failures."""


class RangeVerificationError(FabricCacheError):
    """A fetched range did not match its signed manifest contract."""


class _DisposableCacheDatabaseCorrupt(RuntimeError):
    """The bounded SQLite integrity probe rejected disposable cache metadata."""


@dataclass(frozen=True)
class FetchedRange:
    """Authenticated response returned by an injected range transport."""

    data: bytes
    range_sha256: str
    manifest_generation: int
    manifest_digest: str | None


class RangeFetcher(Protocol):
    def __call__(
        self,
        path: str,
        file_sha256: str,
        file_size: int,
        offset: int,
        length: int,
    ) -> FetchedRange: ...


@dataclass(frozen=True)
class CacheStatus:
    max_bytes: int
    max_disk_bytes: int
    max_metadata_bytes: int
    max_range_records: int
    chunk_bytes: int
    content_bytes: int
    content_disk_bytes: int
    metadata_bytes: int
    disk_bytes: int
    content_count: int
    range_count: int
    pinned_owner_count: int
    dirty_owner_count: int

    @property
    def over_capacity(self) -> bool:
        return (
            self.content_bytes > self.max_bytes
            or self.disk_bytes > self.max_disk_bytes
            or self.metadata_bytes > self.max_metadata_bytes
            or self.range_count > self.max_range_records
        )


@dataclass(frozen=True)
class MaterializeReceipt:
    file_sha256: str
    size_bytes: int
    chunks_written: int


_FlightKey: TypeAlias = tuple[str, int, int, int, str]


class FabricRangeCache:
    """A verified range cache with a unique-content LRU capacity.

    ``root`` is intentionally accepted directly instead of depending on a
    particular ``Paths`` layout.  The future service/native adapters can place
    one cache per authority or workspace while sharing the same implementation.

    Logical content bytes, actual filesystem allocation, SQLite pages, range
    records, and pin owners are bounded independently.  A live owner lease is
    non-evictable; when those pins consume available capacity a new range is
    served but bypasses the cache.  A range larger than the logical cap is also
    served without insertion, so one exceptional read cannot flush a useful
    working set.
    """

    def __init__(
        self,
        root: Path | str,
        *,
        max_bytes: int = DEFAULT_MAX_CACHE_BYTES,
        chunk_bytes: int = DEFAULT_CHUNK_BYTES,
        max_disk_bytes: int | None = None,
        max_metadata_bytes: int = DEFAULT_MAX_METADATA_BYTES,
        max_range_records: int = DEFAULT_MAX_RANGE_RECORDS,
        max_owner_records: int = DEFAULT_MAX_OWNER_RECORDS,
        owner_lease_seconds: int = DEFAULT_OWNER_LEASE_SECONDS,
    ) -> None:
        if (
            isinstance(max_bytes, bool)
            or not isinstance(max_bytes, int)
            or max_bytes < 0
            or max_bytes > _MAX_INTEGER
        ):
            raise ValueError("max_bytes must be a non-negative integer")
        if (
            isinstance(chunk_bytes, bool)
            or not isinstance(chunk_bytes, int)
            or chunk_bytes < 1
            or chunk_bytes > _MAX_INTEGER
        ):
            raise ValueError("chunk_bytes must be a positive integer")
        if (
            isinstance(max_metadata_bytes, bool)
            or not isinstance(max_metadata_bytes, int)
            or not _MIN_METADATA_BYTES <= max_metadata_bytes <= _MAX_INTEGER
        ):
            raise ValueError(
                f"max_metadata_bytes must be at least {_MIN_METADATA_BYTES} bytes"
            )
        for value, name in (
            (max_range_records, "max_range_records"),
            (max_owner_records, "max_owner_records"),
        ):
            if (
                isinstance(value, bool)
                or not isinstance(value, int)
                or value < 1
                or value > _MAX_INTEGER
            ):
                raise ValueError(f"{name} must be a positive integer")
        if (
            isinstance(owner_lease_seconds, bool)
            or not isinstance(owner_lease_seconds, int)
            or not 1 <= owner_lease_seconds <= _MAX_OWNER_LEASE_SECONDS
        ):
            raise ValueError(
                f"owner_lease_seconds must be between 1 and {_MAX_OWNER_LEASE_SECONDS}"
            )
        minimum_disk_bytes = (
            2 * max_metadata_bytes + _DISK_ACCOUNTING_SLACK_BYTES
        )
        if max_disk_bytes is None:
            max_disk_bytes = (
                minimum_disk_bytes + max_bytes + _DEFAULT_ALLOCATION_OVERHEAD_BYTES
            )
        if (
            isinstance(max_disk_bytes, bool)
            or not isinstance(max_disk_bytes, int)
            or not minimum_disk_bytes <= max_disk_bytes <= _MAX_INTEGER
        ):
            raise ValueError(
                "max_disk_bytes must reserve two metadata files plus accounting slack"
            )
        self.root = Path(root)
        self.max_bytes = max_bytes
        self.chunk_bytes = chunk_bytes
        self.max_disk_bytes = max_disk_bytes
        self.max_metadata_bytes = max_metadata_bytes
        self.max_range_records = max_range_records
        self.max_owner_records = max_owner_records
        self.owner_lease_ns = owner_lease_seconds * 1_000_000_000
        # DELETE-journal SQLite can transiently use a main database plus a
        # rollback journal of comparable size.  The remainder is the hard
        # allocation budget for immutable chunk files.
        self._max_content_disk_bytes = max(
            0,
            max_disk_bytes
            - (2 * max_metadata_bytes)
            - _DISK_ACCOUNTING_SLACK_BYTES,
        )
        self.content_dir = self.root / "chunks"
        self.database_path = self.root / "ranges.sqlite3"
        self.lock_path = self.root / "cache.lock"
        self._flights_lock = threading.Lock()
        self._flights: dict[_FlightKey, Future[bytes]] = {}
        self._last_owner_sweep_ns = 0
        self._allocation_unit = 4_096
        self._recovery_scan: Iterator[os.DirEntry[str]] | None = None
        self._recovery_database_after_rowid = 0
        self._recovery_database_complete = False
        self._recovery_incomplete = True
        self._initialize()

    # --------------------------------------------------------------- public API

    def get(
        self,
        file_sha256: str,
        file_size: int,
        offset: int,
        length: int,
        *,
        manifest_generation: int,
        manifest_digest: str | None,
        expected_range_sha256: str | None = None,
    ) -> bytes | None:
        """Return one verified cached range, or ``None`` on a miss/corruption.

        Exact bindings are preferred, but a bounded chain of verified ranges
        may cover the request.  That lets one direct 4-MiB CAS block satisfy
        normal 1-MiB streaming reads (and lets four stream chunks satisfy a
        later direct-block probe) without storing the same bytes twice.

        Corrupt content is removed from every range that references it before
        a miss is returned.  It is therefore never served, and a streaming
        caller can safely repair the miss from the authenticated transport.
        """

        manifest_digest = self._manifest_identity(manifest_digest)
        self._validate_binding(
            file_sha256,
            file_size,
            offset,
            length,
            manifest_generation,
            manifest_digest,
        )
        if expected_range_sha256 is not None:
            self._validate_digest(expected_range_sha256, "expected_range_sha256")
        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                now_ns = time.time_ns()
                if now_ns - self._last_owner_sweep_ns >= _OWNER_SWEEP_INTERVAL_NS:
                    self._prune_expired_owners_locked(connection, now_ns)
                    connection.commit()
                requested_end = offset + length
                cursor = offset
                assembled = bytearray()
                touched: list[tuple[int, int, str, int]] = []
                while cursor < requested_end and len(touched) < MAX_COVERING_RANGES:
                    # Prefer the smallest single range that covers the entire
                    # remainder.  If none does, greedily take the candidate
                    # that advances furthest.  Both lookups use the immutable
                    # whole-file digest, so cross-generation reuse remains as
                    # strict as the former exact-key lookup.
                    row = connection.execute(
                        """
                        SELECT r.offset_bytes, r.length_bytes, r.range_sha256,
                               c.size_bytes, r.last_access_ns
                        FROM ranges AS r
                        JOIN contents AS c ON c.range_sha256 = r.range_sha256
                        WHERE r.file_sha256 = ? AND r.offset_bytes <= ?
                          AND r.offset_bytes + r.length_bytes >= ?
                        ORDER BY r.length_bytes ASC, r.last_access_ns DESC,
                                 r.offset_bytes DESC
                        LIMIT 1
                        """,
                        (file_sha256, cursor, requested_end),
                    ).fetchone()
                    if row is None:
                        row = connection.execute(
                            """
                            SELECT r.offset_bytes, r.length_bytes, r.range_sha256,
                                   c.size_bytes, r.last_access_ns
                            FROM ranges AS r
                            JOIN contents AS c ON c.range_sha256 = r.range_sha256
                            WHERE r.file_sha256 = ? AND r.offset_bytes <= ?
                              AND r.offset_bytes + r.length_bytes > ?
                            ORDER BY r.offset_bytes + r.length_bytes DESC,
                                     r.length_bytes ASC, r.last_access_ns DESC
                            LIMIT 1
                            """,
                            (file_sha256, cursor, cursor),
                        ).fetchone()
                    if row is None:
                        return None

                    range_offset = int(row[0])
                    range_length = int(row[1])
                    range_sha256 = str(row[2])
                    stored_size = int(row[3])
                    last_access_ns = int(row[4])
                    content_path = self._content_path(range_sha256)
                    try:
                        data = content_path.read_bytes()
                    except OSError:
                        data = b""
                    if (
                        stored_size != range_length
                        or len(data) != range_length
                        or hashlib.sha256(data).hexdigest() != range_sha256
                    ):
                        self._drop_content_locked(connection, range_sha256)
                        connection.commit()
                        self._unlink_recovery_paths([content_path])
                        return None

                    slice_start = cursor - range_offset
                    slice_end = min(range_length, requested_end - range_offset)
                    if slice_end <= slice_start:
                        raise FabricCacheError(
                            "the Fabric cache covering-range index made no progress"
                        )
                    assembled.extend(data[slice_start:slice_end])
                    cursor = range_offset + slice_end
                    touched.append(
                        (range_offset, range_length, range_sha256, last_access_ns)
                    )

                if cursor != requested_end:
                    # Coverage work is deliberately bounded; a pathological
                    # tiny-range layout falls back to one authenticated fetch.
                    return None

                result = bytes(assembled)
                exact_expected_binding = (
                    expected_range_sha256 is not None
                    and len(touched) == 1
                    and touched[0][0] == offset
                    and touched[0][1] == length
                    and touched[0][2] == expected_range_sha256
                )
                if (
                    expected_range_sha256 is not None
                    and not exact_expected_binding
                    and hashlib.sha256(result).hexdigest() != expected_range_sha256
                ):
                    # The whole-file alias is stale or the authoritative
                    # descriptor contradicts that immutable file identity.
                    # Never serve the aliased bytes and never rewrite the
                    # immutable binding under a different block digest.
                    stale_paths: list[Path] = []
                    for range_offset, range_length, range_sha256, _accessed in touched:
                        retired_path, _logical, _disk = self._delete_range_locked(
                            connection,
                            (file_sha256, range_offset, range_length, range_sha256),
                        )
                        if retired_path is not None:
                            stale_paths.append(retired_path)
                    connection.commit()
                    self._unlink_recovery_paths(stale_paths)
                    return None
                accessed_ns = time.time_ns()
                stale_touches = tuple(
                    item
                    for item in touched
                    if accessed_ns - item[3] >= _LRU_TOUCH_INTERVAL_NS
                )
                if stale_touches:
                    connection.executemany(
                        """
                        UPDATE ranges SET last_access_ns = ?
                        WHERE file_sha256 = ? AND offset_bytes = ?
                          AND length_bytes = ?
                        """,
                        (
                            (accessed_ns, file_sha256, item[0], item[1])
                            for item in stale_touches
                        ),
                    )
                    connection.executemany(
                        "UPDATE contents SET last_access_ns = ? WHERE range_sha256 = ?",
                        (
                            (accessed_ns, digest)
                            for digest in dict.fromkeys(
                                item[2] for item in stale_touches
                            )
                        ),
                    )
                    connection.commit()
                return result
        return None

    def get_content(self, range_sha256: str, length: int) -> bytes | None:
        """Return verified immutable content without requiring a range alias.

        Object-CAS manifests can repeat one digest at many file offsets (or in
        later files). The content table already deduplicates those bytes; this
        lookup lets the coordinator attach a new exact range binding without
        downloading the same CAS object again. It never trusts an unindexed
        directory entry and removes corrupt indexed content before returning a
        miss.
        """

        self._validate_digest(range_sha256, "range_sha256")
        if (
            isinstance(length, bool)
            or not isinstance(length, int)
            or not 0 <= length <= _MAX_INTEGER
        ):
            raise ValueError("length must be a non-negative integer")
        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                row = connection.execute(
                    """SELECT size_bytes, last_access_ns FROM contents
                       WHERE range_sha256 = ?""",
                    (range_sha256,),
                ).fetchone()
                if row is None or int(row[0]) != length:
                    return None
                content_path = self._content_path(range_sha256)
                try:
                    data = content_path.read_bytes()
                except OSError:
                    data = b""
                if (
                    len(data) != length
                    or hashlib.sha256(data).hexdigest() != range_sha256
                ):
                    self._drop_content_locked(connection, range_sha256)
                    connection.commit()
                    self._unlink_recovery_paths([content_path])
                    return None
                now_ns = time.time_ns()
                if now_ns - int(row[1]) >= _LRU_TOUCH_INTERVAL_NS:
                    connection.execute(
                        """UPDATE contents SET last_access_ns = ?
                           WHERE range_sha256 = ?""",
                        (now_ns, range_sha256),
                    )
                    connection.commit()
                return data

    def put(
        self,
        file_sha256: str,
        file_size: int,
        offset: int,
        data: bytes,
        range_sha256: str,
        *,
        manifest_generation: int,
        manifest_digest: str | None,
    ) -> bool:
        """Verify and cache one exact range.

        Returns ``True`` when the range remains cached.  It returns ``False``
        when the range exceeds the cap or is immediately chosen by LRU
        pressure.  In both cases the verified bytes remain available to the
        current caller.
        """

        if not isinstance(data, bytes):
            raise RangeVerificationError("a fetched Fabric range must be bytes")
        manifest_digest = self._manifest_identity(manifest_digest)
        self._validate_binding(
            file_sha256,
            file_size,
            offset,
            len(data),
            manifest_generation,
            manifest_digest,
        )
        self._validate_digest(range_sha256, "range_sha256")
        if hashlib.sha256(data).hexdigest() != range_sha256:
            raise RangeVerificationError("the fetched Fabric range failed SHA-256 verification")
        if len(data) > self.max_bytes:
            return False

        content_path = self._content_path(range_sha256)
        published_unindexed = False
        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                try:
                    now_ns = time.time_ns()
                    recovery_paths = self._continue_recovery_locked(connection)
                    connection.commit()
                    self._unlink_recovery_paths(recovery_paths)
                    if self._recovery_incomplete:
                        # Unknown directory entries may consume arbitrary real
                        # allocation.  Authenticated bytes still reach the
                        # caller, but cache admission remains closed until the
                        # bounded sweep has established an exact accounting.
                        return False
                    self._maybe_prune_expired_owners_locked(connection, now_ns)
                    paths_to_unlink: list[Path] = []
                    existing_binding = connection.execute(
                        """
                        SELECT range_sha256 FROM ranges
                        WHERE file_sha256 = ? AND offset_bytes = ? AND length_bytes = ?
                        """,
                        (file_sha256, offset, len(data)),
                    ).fetchone()
                    if (
                        existing_binding is not None
                        and str(existing_binding[0]) != range_sha256
                    ):
                        raise RangeVerificationError(
                            "an immutable Fabric range binding changed its content digest"
                        )

                    content_row = connection.execute(
                        """
                        SELECT size_bytes, disk_bytes FROM contents
                        WHERE range_sha256 = ?
                        """,
                        (range_sha256,),
                    ).fetchone()
                    if content_row is not None and not self._content_matches(
                        content_path, data, range_sha256, int(content_row[0])
                    ):
                        self._drop_content_locked(connection, range_sha256)
                        paths_to_unlink.append(content_path)
                        content_row = None
                        existing_binding = None

                    if existing_binding is None:
                        metadata_paths, admitted = self._make_range_slot_locked(
                            connection, now_ns
                        )
                        paths_to_unlink.extend(metadata_paths)
                        if not admitted:
                            connection.commit()
                            self._unlink_recovery_paths(paths_to_unlink)
                            return False

                    # Commit metadata pruning before allocating a new object.
                    # This keeps the disk high-water calculation honest and a
                    # crash merely turns an evicted range into a normal miss.
                    connection.commit()
                    self._unlink_recovery_paths(paths_to_unlink)
                    if self._recovery_incomplete:
                        return False

                    content_row = connection.execute(
                        """
                        SELECT size_bytes, disk_bytes FROM contents
                        WHERE range_sha256 = ?
                        """,
                        (range_sha256,),
                    ).fetchone()
                    if content_row is None:
                        estimated_disk_bytes = self._estimated_allocation_bytes(len(data))
                        capacity_paths, admitted = self._make_content_room_locked(
                            connection,
                            incoming_bytes=len(data),
                            incoming_disk_bytes=estimated_disk_bytes,
                            now_ns=now_ns,
                        )
                        connection.commit()
                        self._unlink_recovery_paths(capacity_paths)
                        if not admitted:
                            return False
                        if self._recovery_incomplete:
                            return False

                        # An unindexed object is never authoritative.  Removing
                        # it first avoids doubling its allocation during the
                        # atomic replacement performed by write_private_file.
                        self._unlink_recovery_paths([content_path])
                        if self._recovery_incomplete:
                            return False
                        try:
                            write_private_file(content_path, data)
                        except BaseException:
                            # ``write_private_file`` may have completed its
                            # atomic replace before a directory-fsync error.
                            # Reclaim the unpublished path on every failure,
                            # not only failures known to precede publication.
                            self._unlink_recovery_paths([content_path])
                            raise
                        published_unindexed = True
                        actual_disk_bytes = self._path_allocated_bytes(content_path)
                        logical_total, disk_total = connection.execute(
                            """
                            SELECT COALESCE(SUM(size_bytes), 0),
                                   COALESCE(SUM(disk_bytes), 0)
                            FROM contents
                            """
                        ).fetchone()
                        if (
                            int(logical_total) + len(data) > self.max_bytes
                            or int(disk_total) + actual_disk_bytes
                            > self._max_content_disk_bytes
                        ):
                            self._unlink_recovery_paths([content_path])
                            published_unindexed = False
                            return False
                        connection.execute(
                            """
                            INSERT INTO contents(
                                range_sha256, size_bytes, disk_bytes,
                                created_ns, last_access_ns
                            ) VALUES (?, ?, ?, ?, ?)
                            """,
                            (
                                range_sha256,
                                len(data),
                                actual_disk_bytes,
                                now_ns,
                                now_ns,
                            ),
                        )
                    connection.execute(
                        """
                        INSERT OR IGNORE INTO ranges(
                            file_sha256, offset_bytes, length_bytes, range_sha256,
                            manifest_generation, manifest_digest, last_access_ns
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            file_sha256,
                            offset,
                            len(data),
                            range_sha256,
                            manifest_generation,
                            manifest_digest,
                            now_ns,
                        ),
                    )
                    connection.execute(
                        "UPDATE contents SET last_access_ns = ? WHERE range_sha256 = ?",
                        (now_ns, range_sha256),
                    )
                    connection.commit()
                    published_unindexed = False
                    return True
                except sqlite3.OperationalError as error:
                    try:
                        connection.rollback()
                    except sqlite3.Error:
                        # Closing the short-lived connection is still the last
                        # rollback attempt.  Keep all admission closed until a
                        # fresh bounded DB+directory pass proves the result.
                        self._restart_recovery(database_scan=True)
                    if published_unindexed:
                        self._unlink_recovery_paths([content_path])
                        # A COMMIT can fail after SQLite has crossed an outcome
                        # boundary.  The cache is disposable, so remove the
                        # physical object and reconcile either possible DB
                        # result before admitting more bytes.
                        self._restart_recovery(database_scan=True)
                    if "full" in str(error).lower():
                        # Cache metadata exhaustion is a miss/bypass, never a
                        # failure of the authenticated read itself.
                        return False
                    raise FabricCacheError("the Fabric cache metadata write failed") from error
                except BaseException:
                    try:
                        connection.rollback()
                    except sqlite3.Error:
                        self._restart_recovery(database_scan=True)
                    if published_unindexed:
                        self._unlink_recovery_paths([content_path])
                    raise

    def pin_owner(self, owner: str, file_sha256: str, *, dirty: bool = False) -> None:
        """Protect every cached range for ``file_sha256`` on behalf of an owner.

        Dirty owners are tracked separately for observability, but both dirty
        and clean pins are non-evictable while their bounded lease is live.
        Repeating ``pin_owner`` renews the lease.  This preserves active work
        while ensuring a process crash cannot leak non-evictable cache state
        forever; durable dirty bytes remain protected by the separate staging
        journal rather than by this disposable read cache.
        """

        self._validate_owner(owner)
        self._validate_digest(file_sha256, "file_sha256")
        if not isinstance(dirty, bool):
            raise ValueError("dirty must be a boolean")
        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                now_ns = time.time_ns()
                self._prune_expired_owners_locked(connection, now_ns)
                existing = connection.execute(
                    """
                    SELECT 1 FROM owners
                    WHERE owner_id = ? AND file_sha256 = ?
                    """,
                    (owner, file_sha256),
                ).fetchone()
                if existing is None:
                    owner_count = int(
                        connection.execute("SELECT COUNT(*) FROM owners").fetchone()[0]
                    )
                    if owner_count >= self.max_owner_records:
                        raise FabricCacheError("the Fabric cache owner limit is reached")
                connection.execute(
                    """
                    INSERT INTO owners(
                        owner_id, file_sha256, dirty, updated_ns, expires_ns
                    ) VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(owner_id, file_sha256) DO UPDATE SET
                        dirty = excluded.dirty,
                        updated_ns = excluded.updated_ns,
                        expires_ns = excluded.expires_ns
                    """,
                    (
                        owner,
                        file_sha256,
                        int(dirty),
                        now_ns,
                        min(_MAX_INTEGER, now_ns + self.owner_lease_ns),
                    ),
                )
                connection.commit()

    def unpin_owner(self, owner: str, file_sha256: str) -> bool:
        """Release one owner's pin, returning whether a pin existed."""

        self._validate_owner(owner)
        self._validate_digest(file_sha256, "file_sha256")
        paths_to_unlink: list[Path] = []
        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                cursor = connection.execute(
                    "DELETE FROM owners WHERE owner_id = ? AND file_sha256 = ?",
                    (owner, file_sha256),
                )
                paths_to_unlink.extend(self._evict_to_capacity_locked(connection))
                connection.commit()
                self._unlink_recovery_paths(paths_to_unlink)
                return cursor.rowcount > 0

    def evict(self, bytes_to_free: int | None = None) -> int:
        """Evict least-recently-used unpinned content.

        With no argument, this only repairs an over-capacity cache.  With an
        explicit byte count, it attempts to free at least that many unique
        content bytes.  Shared content is counted only when its final range
        reference is removed.
        """

        if bytes_to_free is not None and (
            isinstance(bytes_to_free, bool)
            or not isinstance(bytes_to_free, int)
            or bytes_to_free < 0
        ):
            raise ValueError("bytes_to_free must be a non-negative integer")
        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                if bytes_to_free is None:
                    before = int(
                        connection.execute(
                            "SELECT COALESCE(SUM(size_bytes), 0) FROM contents"
                        ).fetchone()[0]
                    )
                    paths = self._evict_to_capacity_locked(connection)
                    after = int(
                        connection.execute(
                            "SELECT COALESCE(SUM(size_bytes), 0) FROM contents"
                        ).fetchone()[0]
                    )
                    freed = max(0, before - after)
                else:
                    paths, freed = self._evict_locked(connection, bytes_to_free)
                connection.commit()
                self._unlink_recovery_paths(paths)
        return freed

    def status(self) -> CacheStatus:
        """Return compact metadata without reading any cached content."""

        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                now_ns = time.time_ns()
                recovery_paths = self._continue_recovery_locked(connection)
                self._prune_expired_owners_locked(connection, now_ns)
                capacity_paths = self._evict_to_capacity_locked(connection)
                connection.commit()
                self._unlink_recovery_paths(recovery_paths)
                self._unlink_recovery_paths(capacity_paths)
                content_count, content_bytes = connection.execute(
                    "SELECT COUNT(*), COALESCE(SUM(size_bytes), 0) FROM contents"
                ).fetchone()
                content_disk_bytes = int(
                    connection.execute(
                        "SELECT COALESCE(SUM(disk_bytes), 0) FROM contents"
                    ).fetchone()[0]
                )
                range_count = connection.execute("SELECT COUNT(*) FROM ranges").fetchone()[0]
                pinned_count, dirty_count = connection.execute(
                    "SELECT COUNT(*), COALESCE(SUM(dirty), 0) FROM owners"
                ).fetchone()
            metadata_bytes = self._path_allocated_bytes(self.database_path)
            disk_bytes = self._root_allocated_bytes(content_disk_bytes)
        return CacheStatus(
            max_bytes=self.max_bytes,
            max_disk_bytes=self.max_disk_bytes,
            max_metadata_bytes=self.max_metadata_bytes,
            max_range_records=self.max_range_records,
            chunk_bytes=self.chunk_bytes,
            content_bytes=int(content_bytes),
            content_disk_bytes=content_disk_bytes,
            metadata_bytes=metadata_bytes,
            disk_bytes=disk_bytes,
            content_count=int(content_count),
            range_count=int(range_count),
            pinned_owner_count=int(pinned_count),
            dirty_owner_count=int(dirty_count),
        )

    def stream(
        self,
        path: str,
        file_sha256: str,
        file_size: int,
        *,
        manifest_generation: int,
        manifest_digest: str | None,
        fetch_range: RangeFetcher,
        offset: int = 0,
        length: int | None = None,
    ) -> Iterator[bytes]:
        """Yield a logical byte range using aligned, reusable cache chunks."""

        self._validate_path(path)
        self._validate_digest(file_sha256, "file_sha256")
        manifest_digest = self._manifest_identity(manifest_digest)
        self._validate_file_size(file_size)
        if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
            raise ValueError("offset must be a non-negative integer")
        if offset > file_size:
            raise ValueError("offset exceeds file size")
        if length is None:
            requested_length = file_size - offset
        elif isinstance(length, bool) or not isinstance(length, int) or length < 0:
            raise ValueError("length must be a non-negative integer")
        else:
            requested_length = length
        if offset + requested_length > file_size:
            raise ValueError("requested range exceeds file size")
        self._validate_generation(manifest_generation)
        if requested_length == 0:
            return

        requested_end = offset + requested_length
        chunk_start = (offset // self.chunk_bytes) * self.chunk_bytes
        while chunk_start < requested_end:
            chunk_length = min(self.chunk_bytes, file_size - chunk_start)
            chunk = self.read_range(
                path,
                file_sha256,
                file_size,
                chunk_start,
                chunk_length,
                manifest_generation,
                manifest_digest,
                fetch_range,
            )
            slice_start = max(offset, chunk_start) - chunk_start
            slice_end = min(requested_end, chunk_start + chunk_length) - chunk_start
            if slice_end > slice_start:
                yield chunk[slice_start:slice_end]
            chunk_start += chunk_length

    def materialize(
        self,
        path: str,
        file_sha256: str,
        file_size: int,
        *,
        manifest_generation: int,
        manifest_digest: str | None,
        fetch_range: RangeFetcher,
        sink: BinaryIO,
        block_descriptor: Mapping[str, Any] | None = None,
    ) -> MaterializeReceipt:
        """Stream one verified file into an uncommitted sink/temp writer.

        The sink is intentionally supplied by the caller.  It should not expose
        the destination until this method returns a receipt, because the whole
        file digest can only be proven after the last chunk is written.
        """

        try:
            digest = FabricFileHasher(block_descriptor)
            if file_digest_algorithm(block_descriptor) == FABRIC_BLOCK_FILE_DIGEST_ALGORITHM and block_file_sha256(block_descriptor) != file_sha256:
                raise ValueError("file identity mismatch")
        except ValueError as error:
            raise RangeVerificationError("the Fabric block descriptor does not bind its file identity") from error
        size_written = 0
        chunks_written = 0
        for chunk in self.stream(
            path,
            file_sha256,
            file_size,
            manifest_generation=manifest_generation,
            manifest_digest=manifest_digest,
            fetch_range=fetch_range,
        ):
            written = sink.write(chunk)
            if written is not None and written != len(chunk):
                raise OSError("the materialization sink accepted a partial chunk")
            try:
                digest.update(chunk)
            except ValueError as error:
                self._invalidate_file(file_sha256)
                raise RangeVerificationError("the streamed Fabric file failed block verification") from error
            size_written += len(chunk)
            chunks_written += 1
        try:
            verified_digest = digest.hexdigest()
        except ValueError as error:
            self._invalidate_file(file_sha256)
            raise RangeVerificationError("the streamed Fabric file failed block verification") from error
        if size_written != file_size or verified_digest != file_sha256:
            self._invalidate_file(file_sha256)
            raise RangeVerificationError(
                "the streamed Fabric file failed final size or SHA-256 verification"
            )
        return MaterializeReceipt(
            file_sha256=file_sha256,
            size_bytes=size_written,
            chunks_written=chunks_written,
        )

    # ------------------------------------------------------------- fetch path

    def read_range(
        self,
        path: str,
        file_sha256: str,
        file_size: int,
        offset: int,
        length: int,
        manifest_generation: int,
        manifest_digest: str | None,
        fetch_range: RangeFetcher,
    ) -> bytes:
        """Read an exact verified extent, coalescing concurrent cache misses."""
        cached = self.get(
            file_sha256,
            file_size,
            offset,
            length,
            manifest_generation=manifest_generation,
            manifest_digest=manifest_digest,
        )
        if cached is not None:
            return cached

        key: _FlightKey = (
            file_sha256,
            offset,
            length,
            manifest_generation,
            manifest_digest,
        )
        with self._flights_lock:
            future = self._flights.get(key)
            leader = future is None
            if future is None:
                future = Future()
                self._flights[key] = future
        if not leader:
            return future.result()

        try:
            fetched = fetch_range(path, file_sha256, file_size, offset, length)
            if not isinstance(fetched, FetchedRange):
                raise RangeVerificationError("the range transport returned an invalid response")
            if not isinstance(fetched.data, bytes) or len(fetched.data) != length:
                raise RangeVerificationError("the range transport returned the wrong byte count")
            if (
                isinstance(fetched.manifest_generation, bool)
                or not isinstance(fetched.manifest_generation, int)
                or fetched.manifest_generation != manifest_generation
                or fetched.manifest_digest != manifest_digest
            ):
                raise RangeVerificationError(
                    "the Fabric manifest changed while a range was being fetched"
                )
            if (
                not isinstance(fetched.range_sha256, str)
                or RAW_SHA256_RE.fullmatch(fetched.range_sha256) is None
            ):
                raise RangeVerificationError(
                    "the range transport returned an invalid content digest"
                )
            try:
                self.put(
                    file_sha256,
                    file_size,
                    offset,
                    fetched.data,
                    fetched.range_sha256,
                    manifest_generation=manifest_generation,
                    manifest_digest=manifest_digest,
                )
            except OSError as error:
                if error.errno not in _CACHE_ADMISSION_PRESSURE_ERRNOS:
                    raise
                # Range bytes and their signed manifest binding were verified
                # above. The cache is optional, so physical space/quota pressure
                # bypasses this admission without failing the authenticated read.
                # put() has already rolled back metadata and removed any content
                # whose atomic publication may have crossed its outcome boundary.
            future.set_result(fetched.data)
            return fetched.data
        except BaseException as error:
            future.set_exception(error)
            # A Future with no followers would otherwise emit an unhandled
            # exception warning during interpreter teardown.
            future.exception()
            raise
        finally:
            with self._flights_lock:
                if self._flights.get(key) is future:
                    del self._flights[key]

    # --------------------------------------------------------------- database

    def _initialize(self) -> None:
        self._ensure_real_cache_directory(self.root, "cache root")
        self._ensure_real_cache_directory(self.content_dir, "cache content directory")
        try:
            filesystem = os.statvfs(self.content_dir)
            unit = int(filesystem.f_frsize or filesystem.f_bsize)
            if 512 <= unit <= DEFAULT_CHUNK_BYTES:
                self._allocation_unit = unit
        except (AttributeError, OSError, ValueError):
            pass
        with file_lock(self.lock_path):
            self._discard_oversize_cache_locked()
            try:
                self._initialize_database_locked()
            except _DisposableCacheDatabaseCorrupt:
                self._reset_corrupt_database_locked()
                self._initialize_fresh_database_locked()
            except sqlite3.DatabaseError as error:
                if not self._is_sqlite_corruption(error):
                    raise
                self._reset_corrupt_database_locked()
                self._initialize_fresh_database_locked()

    def _initialize_fresh_database_locked(self) -> None:
        """Create once after a classified reset; never enter a reset loop."""

        try:
            self._initialize_database_locked()
        except (sqlite3.DatabaseError, _DisposableCacheDatabaseCorrupt) as error:
            raise FabricCacheError(
                "the disposable Fabric cache database could not be recreated safely"
            ) from error

    def _initialize_database_locked(self) -> None:
        with closing(self._connect(initialize=True)) as connection:
            check = connection.execute("PRAGMA quick_check(1)").fetchone()
            if check is None or tuple(check) != ("ok",):
                raise _DisposableCacheDatabaseCorrupt(
                    "the disposable Fabric cache database failed its integrity check"
                )
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version not in (0, 1, _SCHEMA_VERSION):
                raise FabricCacheError(f"unsupported Fabric cache schema {version}")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS contents(
                    range_sha256 TEXT PRIMARY KEY,
                    size_bytes INTEGER NOT NULL CHECK(size_bytes > 0),
                    disk_bytes INTEGER NOT NULL CHECK(disk_bytes > 0),
                    created_ns INTEGER NOT NULL,
                    last_access_ns INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS contents_lru
                    ON contents(last_access_ns, range_sha256);
                CREATE TABLE IF NOT EXISTS ranges(
                    file_sha256 TEXT NOT NULL,
                    offset_bytes INTEGER NOT NULL CHECK(offset_bytes >= 0),
                    length_bytes INTEGER NOT NULL CHECK(length_bytes > 0),
                    range_sha256 TEXT NOT NULL REFERENCES contents(range_sha256)
                        ON DELETE CASCADE,
                    manifest_generation INTEGER NOT NULL CHECK(manifest_generation > 0),
                    manifest_digest TEXT NOT NULL,
                    last_access_ns INTEGER NOT NULL,
                    PRIMARY KEY(
                        file_sha256, offset_bytes, length_bytes, range_sha256
                    ),
                    UNIQUE(file_sha256, offset_bytes, length_bytes)
                );
                CREATE INDEX IF NOT EXISTS ranges_lru ON ranges(last_access_ns);
                CREATE INDEX IF NOT EXISTS ranges_content ON ranges(range_sha256);
                CREATE TABLE IF NOT EXISTS owners(
                    owner_id TEXT NOT NULL,
                    file_sha256 TEXT NOT NULL,
                    dirty INTEGER NOT NULL CHECK(dirty IN (0, 1)),
                    updated_ns INTEGER NOT NULL,
                    expires_ns INTEGER NOT NULL,
                    PRIMARY KEY(owner_id, file_sha256)
                );
                """
            )
            content_columns = {
                str(row[1])
                for row in connection.execute("PRAGMA table_info(contents)").fetchall()
            }
            if "disk_bytes" not in content_columns:
                connection.execute("ALTER TABLE contents ADD COLUMN disk_bytes INTEGER")
            owner_columns = {
                str(row[1])
                for row in connection.execute("PRAGMA table_info(owners)").fetchall()
            }
            if "expires_ns" not in owner_columns:
                connection.execute("ALTER TABLE owners ADD COLUMN expires_ns INTEGER")
            connection.execute(
                """CREATE INDEX IF NOT EXISTS owners_file_expiry
                   ON owners(file_sha256, expires_ns)"""
            )
            if version < _SCHEMA_VERSION:
                now_ns = time.time_ns()
                connection.execute(
                    """
                    UPDATE owners SET expires_ns = ?
                    WHERE expires_ns IS NULL
                    """,
                    (min(_MAX_INTEGER, now_ns + self.owner_lease_ns),),
                )
            connection.execute(f"PRAGMA user_version = {_SCHEMA_VERSION}")
            recovery_paths = self._recover_locked(connection)
            now_ns = time.time_ns()
            self._prune_expired_owners_locked(connection, now_ns)
            self._trim_owner_records_locked(connection)
            trim_paths, _ = self._trim_range_records_locked(connection, now_ns)
            capacity_paths = self._evict_to_capacity_locked(connection)
            connection.commit()
            self._unlink_recovery_paths(recovery_paths)
            self._unlink_recovery_paths(trim_paths)
            self._unlink_recovery_paths(capacity_paths)
            self._last_owner_sweep_ns = now_ns
        try:
            os.chmod(self.database_path, 0o600)
        except OSError:
            pass

    def _connect(self, *, initialize: bool = False) -> sqlite3.Connection:
        if not initialize and not self.database_path.exists():
            raise FabricCacheError("the Fabric cache database is missing")
        connection = sqlite3.connect(self.database_path, timeout=30.0)
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            if initialize:
                page_size = int(connection.execute("PRAGMA page_size").fetchone()[0])
                version = int(connection.execute("PRAGMA user_version").fetchone()[0])
                has_schema = connection.execute(
                    "SELECT 1 FROM sqlite_master LIMIT 1"
                ).fetchone()
                if (
                    version == 0
                    and has_schema is None
                    and page_size != _CACHE_DATABASE_PAGE_BYTES
                ):
                    # A valid but empty 64-KiB-page file can require more than
                    # the minimum 256-KiB metadata budget merely to hold this
                    # schema. It carries no cache authority yet, so normalize it
                    # before schema creation rather than silently exceeding the
                    # configured byte cap or requiring a second restart.
                    connection.execute(
                        f"PRAGMA page_size = {_CACHE_DATABASE_PAGE_BYTES}"
                    )
                    connection.execute("VACUUM")
            connection.execute("PRAGMA journal_mode = DELETE")
            connection.execute("PRAGMA synchronous = FULL")
            connection.execute("PRAGMA temp_store = MEMORY")
            connection.execute("PRAGMA cache_size = -2048")
            page_size = int(connection.execute("PRAGMA page_size").fetchone()[0])
            page_limit = max(
                1,
                min(
                    _SQLITE_MAX_PAGE_COUNT,
                    self.max_metadata_bytes // max(1, page_size),
                ),
            )
            connection.execute(f"PRAGMA max_page_count = {page_limit}")
            return connection
        except BaseException:
            connection.close()
            raise

    @staticmethod
    def _is_sqlite_corruption(error: sqlite3.DatabaseError) -> bool:
        code = getattr(error, "sqlite_errorcode", None)
        if isinstance(code, bool) or not isinstance(code, int):
            return False
        primary = code & 0xFF
        return primary in (
            getattr(sqlite3, "SQLITE_CORRUPT", 11),
            getattr(sqlite3, "SQLITE_NOTADB", 26),
        )

    def _reset_corrupt_database_locked(self) -> None:
        """Reset only disposable range metadata after classified corruption."""

        self._restart_recovery(database_scan=True)
        failed = False
        for path in (
            self.database_path,
            Path(f"{self.database_path}-journal"),
            Path(f"{self.database_path}-wal"),
            Path(f"{self.database_path}-shm"),
        ):
            failed = not self._unlink(path) or failed
        if failed:
            raise FabricCacheError(
                "the corrupt disposable Fabric cache database could not be reset safely"
            )

    def _recover_locked(self, connection: sqlite3.Connection) -> list[Path]:
        # These should be impossible with SQLite foreign keys enabled, but
        # deleting them is cheap and keeps a manually/torn database fail-closed.
        connection.execute(
            """
            DELETE FROM ranges
            WHERE range_sha256 NOT IN (SELECT range_sha256 FROM contents)
            """
        )
        # Orphan metadata has no authorization binding and can be dropped in
        # one bounded-file transaction.  Its physical object is handled by the
        # incremental directory sweep below; no digest list is accumulated.
        connection.execute(
            """
            DELETE FROM contents AS c
            WHERE NOT EXISTS (
                SELECT 1 FROM ranges AS r WHERE r.range_sha256 = c.range_sha256
            )
            """
        )

        return self._continue_recovery_locked(connection)

    def _continue_recovery_locked(self, connection: sqlite3.Connection) -> list[Path]:
        """Inspect at most one bounded batch of cache-directory entries.

        The caller owns ``cache.lock`` and commits metadata before unlinking
        the returned paths.  An indexed digest is never scheduled for removal;
        malformed entries and unindexed immutable objects are disposable.
        """

        if not self._recovery_incomplete:
            return []
        self._assert_real_cache_directory(self.root, "cache root")
        self._assert_real_cache_directory(
            self.content_dir, "cache content directory"
        )
        if not self._recovery_database_complete:
            rows = connection.execute(
                """
                SELECT rowid, range_sha256, size_bytes FROM contents
                WHERE rowid > ?
                ORDER BY rowid ASC
                LIMIT ?
                """,
                (
                    self._recovery_database_after_rowid,
                    _RECOVERY_DATABASE_SCAN_ROWS,
                ),
            ).fetchall()
            if rows:
                self._recovery_database_after_rowid = int(rows[-1][0])
            for rowid, digest_value, size_bytes in rows:
                digest = str(digest_value)
                if RAW_SHA256_RE.fullmatch(digest) is None:
                    # Never turn a database-controlled string into a path.
                    connection.execute(
                        "DELETE FROM ranges WHERE range_sha256 IS ?",
                        (digest_value,),
                    )
                    connection.execute(
                        "DELETE FROM contents WHERE rowid = ?", (rowid,)
                    )
                    continue
                path = self._content_path(digest)
                try:
                    file_stat = path.stat(follow_symlinks=False)
                    valid_size = stat.S_ISREG(file_stat.st_mode) and file_stat.st_size == int(
                        size_bytes
                    )
                except (OSError, TypeError, ValueError):
                    valid_size = False
                if not valid_size:
                    self._drop_content_locked(connection, digest)
                else:
                    connection.execute(
                        "UPDATE contents SET disk_bytes = ? WHERE range_sha256 = ?",
                        (self._path_allocated_bytes(path), digest),
                    )
                    try:
                        os.chmod(path, 0o600)
                    except OSError:
                        pass
            if len(rows) < _RECOVERY_DATABASE_SCAN_ROWS:
                self._recovery_database_complete = True
            else:
                # Directory classification must wait until every indexed row
                # has been validated.  Otherwise a path retained early could
                # become an unaccounted orphan when a later DB page is pruned.
                return []

        if self._recovery_scan is None:
            try:
                self._recovery_scan = iter(os.scandir(self.content_dir))
            except OSError as error:
                raise FabricCacheError(
                    "the Fabric cache content directory cannot be inspected"
                ) from error

        paths_to_unlink: list[Path] = []
        digest_candidates: list[tuple[str, Path]] = []
        assert self._recovery_scan is not None
        for _ in range(_STARTUP_RECOVERY_SCAN_ENTRIES):
            try:
                entry = next(self._recovery_scan)
            except StopIteration:
                self._close_recovery_scan()
                self._recovery_incomplete = False
                break
            except OSError as error:
                self._close_recovery_scan()
                raise FabricCacheError(
                    "the Fabric cache content directory scan failed"
                ) from error

            path = Path(entry.path)
            try:
                is_link = entry.is_symlink()
                is_file = entry.is_file(follow_symlinks=False)
            except OSError:
                # A concurrently vanished entry is already clean.  Any other
                # inaccessible entry is retried by a future startup.
                continue
            if is_link:
                paths_to_unlink.append(path)
                continue
            if not is_file:
                self._close_recovery_scan()
                raise FabricCacheError(
                    "the Fabric cache content directory contains a non-file entry"
                )
            if (
                path.name.startswith(".")
                or path.name.endswith(".tmp")
                or RAW_SHA256_RE.fullmatch(path.name) is None
            ):
                paths_to_unlink.append(path)
                continue
            digest_candidates.append((path.name, path))

        # Resolve indexed membership in bounded SQL batches.  This avoids one
        # database round-trip per directory entry without recreating the old
        # unbounded all-indexed-digests set.
        for start in range(0, len(digest_candidates), _RECOVERY_SQL_BATCH_ROWS):
            candidates = digest_candidates[
                start : start + _RECOVERY_SQL_BATCH_ROWS
            ]
            placeholders = ",".join("?" for _ in candidates)
            indexed = {
                str(row[0])
                for row in connection.execute(
                    f"SELECT range_sha256 FROM contents "
                    f"WHERE range_sha256 IN ({placeholders})",
                    tuple(digest for digest, _path in candidates),
                )
            }
            paths_to_unlink.extend(
                path for digest, path in candidates if digest not in indexed
            )
        return paths_to_unlink

    def _close_recovery_scan(self) -> None:
        scan = self._recovery_scan
        self._recovery_scan = None
        close = getattr(scan, "close", None)
        if callable(close):
            close()

    def _unlink_recovery_paths(self, paths: list[Path]) -> None:
        """Keep admission closed if a classified orphan cannot be reclaimed."""

        failed = False
        for path in dict.fromkeys(paths):
            failed = not self._unlink(path) or failed
        if failed:
            # The directory's real allocation is still unknown.  Re-open the
            # scan on the next maintenance call instead of silently admitting
            # more blocks against an incomplete disk total.
            self._restart_recovery(database_scan=False)

    def _restart_recovery(self, *, database_scan: bool) -> None:
        """Fail admission closed after an uncertain metadata/file transition."""

        self._close_recovery_scan()
        self._recovery_incomplete = True
        if database_scan:
            self._recovery_database_after_rowid = 0
            self._recovery_database_complete = False

    def _discard_oversize_cache_locked(self) -> None:
        """Reset disposable metadata that predates the hard database bound."""

        try:
            oversized = self.database_path.is_symlink() or (
                self.database_path.exists()
                and self.database_path.stat().st_size > self.max_metadata_bytes
            )
        except OSError:
            oversized = True
        if not oversized:
            return
        # Do not synchronously enumerate or collect an attacker-sized chunks
        # directory.  The fresh database makes every old object unindexed and
        # the bounded recovery scan reclaims them incrementally while cache
        # admission remains closed.
        for path in (
            self.database_path,
            Path(f"{self.database_path}-journal"),
            Path(f"{self.database_path}-wal"),
            Path(f"{self.database_path}-shm"),
        ):
            self._unlink(path)

    def _ensure_real_cache_directory(self, path: Path, label: str) -> None:
        """Create a private cache directory without accepting a link/reparse point."""

        try:
            self._assert_real_cache_directory(path, label, allow_missing=True)
            ensure_private_dir(path)
            # Recheck after mkdir/chmod to fail closed across a replacement
            # race rather than beginning SQLite or chunk IO through a link.
            self._assert_real_cache_directory(path, label)
        except FabricCacheError:
            raise
        except OSError as error:
            raise FabricCacheError(f"the Fabric {label} is not a safe directory") from error

    @staticmethod
    def _assert_real_cache_directory(
        path: Path, label: str, *, allow_missing: bool = False
    ) -> None:
        try:
            path_stat = path.lstat()
        except FileNotFoundError:
            if allow_missing:
                return
            raise FabricCacheError(f"the Fabric {label} is missing") from None
        except OSError as error:
            raise FabricCacheError(f"the Fabric {label} cannot be inspected") from error
        reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
        file_attributes = int(getattr(path_stat, "st_file_attributes", 0))
        if (
            stat.S_ISLNK(path_stat.st_mode)
            or file_attributes & reparse_flag
            or not stat.S_ISDIR(path_stat.st_mode)
        ):
            raise FabricCacheError(
                f"the Fabric {label} must be a real directory, not a link"
            )

    def _prune_expired_owners_locked(
        self, connection: sqlite3.Connection, now_ns: int
    ) -> int:
        cursor = connection.execute(
            """
            DELETE FROM owners
            WHERE expires_ns IS NULL OR expires_ns <= ? OR expires_ns > ?
            """,
            (
                now_ns,
                min(
                    _MAX_INTEGER,
                    now_ns + (_MAX_OWNER_LEASE_SECONDS * 1_000_000_000),
                ),
            ),
        )
        self._last_owner_sweep_ns = now_ns
        return max(0, cursor.rowcount)

    def _maybe_prune_expired_owners_locked(
        self, connection: sqlite3.Connection, now_ns: int
    ) -> int:
        if now_ns - self._last_owner_sweep_ns < _OWNER_SWEEP_INTERVAL_NS:
            return 0
        return self._prune_expired_owners_locked(connection, now_ns)

    def _trim_owner_records_locked(self, connection: sqlite3.Connection) -> None:
        count = int(connection.execute("SELECT COUNT(*) FROM owners").fetchone()[0])
        excess = count - self.max_owner_records
        if excess <= 0:
            return
        # Pins affect only a disposable immutable read cache.  During an
        # upgrade from the formerly unbounded schema, keep dirty and recent
        # owners preferentially while restoring the hard metadata invariant.
        rows = connection.execute(
            """
            SELECT owner_id, file_sha256 FROM owners
            ORDER BY dirty ASC, updated_ns ASC, owner_id ASC, file_sha256 ASC
            LIMIT ?
            """,
            (excess,),
        ).fetchall()
        connection.executemany(
            "DELETE FROM owners WHERE owner_id = ? AND file_sha256 = ?", rows
        )

    def _make_range_slot_locked(
        self, connection: sqlite3.Connection, now_ns: int
    ) -> tuple[list[Path], bool]:
        return self._trim_range_records_locked(
            connection, now_ns, target_count=self.max_range_records - 1
        )

    def _trim_range_records_locked(
        self,
        connection: sqlite3.Connection,
        now_ns: int,
        *,
        target_count: int | None = None,
    ) -> tuple[list[Path], bool]:
        target = self.max_range_records if target_count is None else max(0, target_count)
        count = int(connection.execute("SELECT COUNT(*) FROM ranges").fetchone()[0])
        paths: list[Path] = []
        while count > target:
            candidate = self._oldest_evictable_range(connection, now_ns)
            if candidate is None:
                break
            path, _logical, _disk = self._delete_range_locked(connection, candidate)
            if path is not None:
                paths.append(path)
            count -= 1
        return paths, count <= target

    def _make_content_room_locked(
        self,
        connection: sqlite3.Connection,
        *,
        incoming_bytes: int,
        incoming_disk_bytes: int,
        now_ns: int,
    ) -> tuple[list[Path], bool]:
        logical_total, disk_total = connection.execute(
            """
            SELECT COALESCE(SUM(size_bytes), 0), COALESCE(SUM(disk_bytes), 0)
            FROM contents
            """
        ).fetchone()
        logical = int(logical_total)
        disk = int(disk_total)
        if (
            incoming_bytes > self.max_bytes
            or incoming_disk_bytes > self._max_content_disk_bytes
        ):
            return [], False
        paths: list[Path] = []
        while (
            logical + incoming_bytes > self.max_bytes
            or disk + incoming_disk_bytes > self._max_content_disk_bytes
        ):
            candidate = self._oldest_evictable_content(connection, now_ns)
            if candidate is None:
                return paths, False
            path, freed_logical, freed_disk = self._delete_content_locked(
                connection, candidate
            )
            logical -= freed_logical
            disk -= freed_disk
            if path is not None:
                paths.append(path)
        return paths, True

    def _evict_to_capacity_locked(self, connection: sqlite3.Connection) -> list[Path]:
        now_ns = time.time_ns()
        self._maybe_prune_expired_owners_locked(connection, now_ns)
        paths, _ = self._trim_range_records_locked(connection, now_ns)
        content_paths, _ = self._make_content_room_locked(
            connection,
            incoming_bytes=0,
            incoming_disk_bytes=0,
            now_ns=now_ns,
        )
        paths.extend(content_paths)
        return paths

    def _evict_locked(
        self, connection: sqlite3.Connection, bytes_to_free: int | None
    ) -> tuple[list[Path], int]:
        now_ns = time.time_ns()
        self._maybe_prune_expired_owners_locked(connection, now_ns)
        total = int(
            connection.execute("SELECT COALESCE(SUM(size_bytes), 0) FROM contents").fetchone()[0]
        )
        required = max(0, total - self.max_bytes) if bytes_to_free is None else bytes_to_free
        freed = 0
        paths: list[Path] = []
        while freed < required:
            candidate = self._oldest_evictable_content(connection, now_ns)
            if candidate is None:
                break
            path, freed_logical, _freed_disk = self._delete_content_locked(
                connection, candidate
            )
            freed += freed_logical
            if path is not None:
                paths.append(path)
        return paths, freed

    @staticmethod
    def _oldest_evictable_range(
        connection: sqlite3.Connection, now_ns: int
    ) -> sqlite3.Row | tuple[object, ...] | None:
        return connection.execute(
            """
            SELECT r.file_sha256, r.offset_bytes, r.length_bytes, r.range_sha256
            FROM ranges AS r
            WHERE NOT EXISTS (
                SELECT 1
                FROM owners AS o INDEXED BY owners_file_expiry
                WHERE o.file_sha256 = r.file_sha256 AND o.expires_ns > ?
            )
            ORDER BY r.last_access_ns ASC, r.file_sha256 ASC,
                     r.offset_bytes ASC, r.length_bytes ASC
            LIMIT 1
            """,
            (now_ns,),
        ).fetchone()

    @staticmethod
    def _oldest_evictable_content(
        connection: sqlite3.Connection, now_ns: int
    ) -> sqlite3.Row | tuple[object, ...] | None:
        """Choose one whole content object with no live pin through any alias."""

        return connection.execute(
            """
            SELECT c.range_sha256, c.size_bytes, c.disk_bytes
            FROM contents AS c
            WHERE NOT EXISTS (
                SELECT 1
                FROM ranges AS shared
                JOIN owners AS o INDEXED BY owners_file_expiry
                  ON o.file_sha256 = shared.file_sha256
                WHERE shared.range_sha256 = c.range_sha256
                  AND o.expires_ns > ?
            )
            ORDER BY c.last_access_ns ASC, c.range_sha256 ASC
            LIMIT 1
            """,
            (now_ns,),
        ).fetchone()

    def _delete_content_locked(
        self,
        connection: sqlite3.Connection,
        candidate: sqlite3.Row | tuple[object, ...],
    ) -> tuple[Path, int, int]:
        """Delete one selected object and every alias in the same transaction."""

        range_sha256, size_bytes, disk_bytes = candidate
        connection.execute(
            "DELETE FROM contents WHERE range_sha256 = ?", (range_sha256,)
        )
        return (
            self._content_path(str(range_sha256)),
            int(size_bytes),
            int(disk_bytes),
        )

    def _delete_range_locked(
        self,
        connection: sqlite3.Connection,
        candidate: sqlite3.Row | tuple[object, ...],
    ) -> tuple[Path | None, int, int]:
        file_sha256, offset, length, range_sha256 = candidate
        connection.execute(
            """
            DELETE FROM ranges
            WHERE file_sha256 = ? AND offset_bytes = ? AND length_bytes = ?
              AND range_sha256 = ?
            """,
            (file_sha256, offset, length, range_sha256),
        )
        still_referenced = connection.execute(
            "SELECT 1 FROM ranges WHERE range_sha256 = ? LIMIT 1", (range_sha256,)
        ).fetchone()
        if still_referenced is not None:
            return None, 0, 0
        row = connection.execute(
            """
            SELECT size_bytes, disk_bytes FROM contents
            WHERE range_sha256 = ?
            """,
            (range_sha256,),
        ).fetchone()
        connection.execute("DELETE FROM contents WHERE range_sha256 = ?", (range_sha256,))
        if row is None:
            return self._content_path(str(range_sha256)), 0, 0
        return (
            self._content_path(str(range_sha256)),
            int(row[0]),
            int(row[1]),
        )

    @staticmethod
    def _drop_content_locked(connection: sqlite3.Connection, range_sha256: str) -> None:
        connection.execute("DELETE FROM ranges WHERE range_sha256 = ?", (range_sha256,))
        connection.execute("DELETE FROM contents WHERE range_sha256 = ?", (range_sha256,))

    def _invalidate_file(self, file_sha256: str) -> None:
        """Drop all cached ranges after whole-file verification fails."""

        paths: list[Path] = []
        with file_lock(self.lock_path):
            with closing(self._connect()) as connection:
                candidates = connection.execute(
                    "SELECT DISTINCT range_sha256 FROM ranges WHERE file_sha256 = ?",
                    (file_sha256,),
                ).fetchall()
                connection.execute("DELETE FROM ranges WHERE file_sha256 = ?", (file_sha256,))
                for (range_sha256,) in candidates:
                    referenced = connection.execute(
                        "SELECT 1 FROM ranges WHERE range_sha256 = ? LIMIT 1", (range_sha256,)
                    ).fetchone()
                    if referenced is None:
                        connection.execute(
                            "DELETE FROM contents WHERE range_sha256 = ?", (range_sha256,)
                        )
                        paths.append(self._content_path(str(range_sha256)))
                connection.commit()
                self._unlink_recovery_paths(paths)

    # -------------------------------------------------------------- validation

    @staticmethod
    def _validate_digest(value: str, field: str) -> None:
        if not isinstance(value, str) or RAW_SHA256_RE.fullmatch(value) is None:
            raise ValueError(f"{field} must be a lowercase SHA-256 digest")

    @classmethod
    def _manifest_identity(cls, manifest_digest: str | None) -> str:
        """Normalise the manifest identity a caller binds a range to.

        ``None`` is a v2 head and maps to ``FABRIC_V2_MANIFEST_IDENTITY``; a v1
        head must be a lowercase SHA-256 digest.
        """

        if manifest_digest is None:
            return FABRIC_V2_MANIFEST_IDENTITY
        cls._validate_manifest_digest(manifest_digest)
        return manifest_digest

    @classmethod
    def _validate_manifest_digest(cls, value: str) -> None:
        if value == FABRIC_V2_MANIFEST_IDENTITY:
            return
        cls._validate_digest(value, "manifest_digest")

    @staticmethod
    def _validate_generation(value: int) -> None:
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 1
            or value > _MAX_INTEGER
        ):
            raise ValueError("manifest_generation must be a positive integer")

    @staticmethod
    def _validate_file_size(value: int) -> None:
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
            or value > _MAX_INTEGER
        ):
            raise ValueError("file_size must be a non-negative integer")

    @classmethod
    def _validate_binding(
        cls,
        file_sha256: str,
        file_size: int,
        offset: int,
        length: int,
        manifest_generation: int,
        manifest_digest: str | None,
    ) -> None:
        cls._validate_digest(file_sha256, "file_sha256")
        cls._validate_manifest_digest(manifest_digest)
        cls._validate_file_size(file_size)
        cls._validate_generation(manifest_generation)
        if (
            isinstance(offset, bool)
            or not isinstance(offset, int)
            or offset < 0
            or offset > _MAX_INTEGER
        ):
            raise ValueError("offset must be a non-negative integer")
        if isinstance(length, bool) or not isinstance(length, int) or length < 1:
            raise ValueError("length must be a positive integer")
        if offset + length > file_size:
            raise ValueError("range exceeds the immutable file size")

    @staticmethod
    def _validate_path(path: str) -> None:
        if (
            not isinstance(path, str)
            or not path
            or "\0" in path
            or len(path.encode("utf-8")) > 4096
            or path.startswith(("/", "~"))
            or "\\" in path
            or (len(path) > 1 and path[0].isalpha() and path[1] == ":")
            or any(part in ("", ".", "..") for part in path.split("/"))
        ):
            raise ValueError("path must be a non-empty workspace path")

    @staticmethod
    def _validate_owner(owner: str) -> None:
        if not isinstance(owner, str) or not owner or "\0" in owner or len(owner) > 512:
            raise ValueError("owner must be a non-empty stable identifier")

    def _content_path(self, range_sha256: str) -> Path:
        return self.content_dir / range_sha256

    @staticmethod
    def _content_matches(
        path: Path, expected: bytes, range_sha256: str, stored_size: int
    ) -> bool:
        try:
            existing = path.read_bytes()
        except OSError:
            return False
        return (
            stored_size == len(expected)
            and existing == expected
            and hashlib.sha256(existing).hexdigest() == range_sha256
        )

    def _estimated_allocation_bytes(self, size_bytes: int) -> int:
        if size_bytes <= 0:
            return 0
        return (
            (size_bytes + self._allocation_unit - 1) // self._allocation_unit
        ) * self._allocation_unit

    @staticmethod
    def _path_allocated_bytes(path: Path) -> int:
        try:
            stat = path.stat(follow_symlinks=False)
        except (FileNotFoundError, OSError):
            return 0
        if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
            try:
                import ctypes
                from ctypes import wintypes

                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                get_size = kernel32.GetCompressedFileSizeW
                get_size.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(wintypes.DWORD)]
                get_size.restype = wintypes.DWORD
                high = wintypes.DWORD()
                ctypes.set_last_error(0)
                low = int(get_size(str(path), ctypes.byref(high)))
                if low != 0xFFFFFFFF or ctypes.get_last_error() == 0:
                    return max(int(stat.st_size), (int(high.value) << 32) | low)
            except (AttributeError, OSError, ValueError):
                pass
        blocks = getattr(stat, "st_blocks", 0)
        allocated = int(blocks) * 512 if isinstance(blocks, int) and blocks > 0 else 0
        return max(int(stat.st_size), allocated)

    def _root_allocated_bytes(self, content_disk_bytes: int) -> int:
        """Measure committed allocation without walking the chunks directory."""

        if self._recovery_incomplete:
            # Unknown entries have not yet been classified/accounted.  Report
            # fail-closed over-capacity rather than hiding arbitrary storage.
            return self.max_disk_bytes + 1
        total = int(content_disk_bytes)
        visited = 0
        try:
            with os.scandir(self.root) as entries:
                for entry in entries:
                    visited += 1
                    if visited > _ROOT_ACCOUNTING_ENTRY_LIMIT:
                        return self.max_disk_bytes + 1
                    if entry.name == self.content_dir.name:
                        if not entry.is_dir(follow_symlinks=False):
                            return self.max_disk_bytes + 1
                        continue
                    total += self._path_allocated_bytes(Path(entry.path))
        except OSError:
            return self.max_disk_bytes + 1
        return total

    @staticmethod
    def _unlink(path: Path) -> bool:
        try:
            path.unlink()
            return True
        except FileNotFoundError:
            return True
        except OSError:
            # Metadata is already authoritative.  A later startup recovery will
            # retry removal of this unindexed object.
            return False
