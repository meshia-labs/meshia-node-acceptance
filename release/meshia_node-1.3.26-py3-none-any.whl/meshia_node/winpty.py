"""ConPTY: the Windows pseudoconsole behind an interactive terminal session.

POSIX gets a PTY from ``pty.openpty()`` and confines the child between ``fork``
and ``exec``. Windows has neither, so this module is the platform's own
equivalent, with the same contract :class:`meshia_node.terminal.TerminalSession`
expects — ``read``/``write``/``resize``/``close``/``is_running``/``exit_code``:

* ``CreatePseudoConsole`` (Windows 10 1809+, build 17763) wires a pair of
  anonymous pipes to a real console device, so programs that query the console
  — anything cursor-addressed — behave as they would in a terminal;
* the child is attached to it through ``PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE``
  on an ``EXTENDED_STARTUPINFO_PRESENT`` spawn, which is the only supported way
  in;
* the process goes into a **Job Object** with ``KILL_ON_JOB_CLOSE``, the same
  ``killpg`` analog :mod:`meshia_node.winexec` uses, so closing a terminal
  reaps everything the shell started;
* when ``confined_root`` is set (`limited` access) the shell runs under the
  low-integrity token from :mod:`meshia_node.winconfine`, the Landlock parity
  point — mandatory no-write-up, inherited by every descendant.

Every Win32 signature is declared before use. ctypes defaults returns and
arguments to 32-bit ``int``, which silently truncates a 64-bit HANDLE; that bug
shipped once here and disabled low-IL confinement on every Windows host (see
:func:`meshia_node.winexec._declare_win32`). ``HPCON`` is a HANDLE like any
other, so it gets the same treatment.

The Win32 FFI is loaded lazily inside functions so this module stays importable
on POSIX, where the package-wide import test exercises it.
"""

from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import threading
import uuid
from typing import Any

if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
    import msvcrt
else:
    msvcrt = None  # type: ignore[assignment]

from .errors import AccessRefused, InvalidTask

MARKER = "meshia-winpty"
TERMINATE_EXIT_CODE = 130

EXTENDED_STARTUPINFO_PRESENT = 0x00080000
CREATE_UNICODE_ENVIRONMENT = 0x00000400
STARTF_USESTDHANDLES = 0x00000100
PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE = 0x00020016
HANDLE_FLAG_INHERIT = 0x00000001
STILL_ACTIVE = 259
WAIT_TIMEOUT = 0x00000102
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9
# The minimum build with a pseudoconsole. Below it, `limited` and `full` alike
# have no terminal and the caller fails closed rather than pretending.
CONPTY_MIN_BUILD = 17763


class _Coord(ctypes.Structure):
    """``COORD`` — two SHORTs, passed to the pseudoconsole calls by value."""

    _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]


class _StartupInfoW(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("lpReserved", ctypes.c_void_p),
        ("lpDesktop", ctypes.c_void_p),
        ("lpTitle", ctypes.c_void_p),
        ("dwX", ctypes.c_ulong),
        ("dwY", ctypes.c_ulong),
        ("dwXSize", ctypes.c_ulong),
        ("dwYSize", ctypes.c_ulong),
        ("dwXCountChars", ctypes.c_ulong),
        ("dwYCountChars", ctypes.c_ulong),
        ("dwFillAttribute", ctypes.c_ulong),
        ("dwFlags", ctypes.c_ulong),
        ("wShowWindow", ctypes.c_ushort),
        ("cbReserved2", ctypes.c_ushort),
        ("lpReserved2", ctypes.c_void_p),
        ("hStdInput", ctypes.c_void_p),
        ("hStdOutput", ctypes.c_void_p),
        ("hStdError", ctypes.c_void_p),
    ]


class _StartupInfoExW(ctypes.Structure):
    _fields_ = [
        ("StartupInfo", _StartupInfoW),
        ("lpAttributeList", ctypes.c_void_p),
    ]


class _ProcessInformation(ctypes.Structure):
    _fields_ = [
        ("hProcess", ctypes.c_void_p),
        ("hThread", ctypes.c_void_p),
        ("dwProcessId", ctypes.c_ulong),
        ("dwThreadId", ctypes.c_ulong),
    ]


class _IoCounters(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_uint64),
        ("WriteOperationCount", ctypes.c_uint64),
        ("OtherOperationCount", ctypes.c_uint64),
        ("ReadTransferCount", ctypes.c_uint64),
        ("WriteTransferCount", ctypes.c_uint64),
        ("OtherTransferCount", ctypes.c_uint64),
    ]


class _JobBasicLimits(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_int64),
        ("PerJobUserTimeLimit", ctypes.c_int64),
        ("LimitFlags", ctypes.c_ulong),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", ctypes.c_ulong),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", ctypes.c_ulong),
        ("SchedulingClass", ctypes.c_ulong),
    ]


class _JobExtendedLimits(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", _JobBasicLimits),
        ("IoInfo", _IoCounters),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


def _declare_win32(kernel32: Any, advapi32: Any) -> None:
    """Pin restype/argtypes: ctypes' 32-bit default truncates 64-bit HANDLEs.

    HPCON is a HANDLE. ``CreatePseudoConsole`` returns it through an out-param,
    so the pointer must be declared or the value written back is meaningless on
    the next call. Same lesson as winexec's CreateJobObjectW.
    """
    H = ctypes.c_void_p
    kernel32.CreatePseudoConsole.restype = ctypes.c_long  # HRESULT
    kernel32.CreatePseudoConsole.argtypes = [_Coord, H, H, ctypes.c_ulong, ctypes.POINTER(H)]
    kernel32.ResizePseudoConsole.restype = ctypes.c_long
    kernel32.ResizePseudoConsole.argtypes = [H, _Coord]
    kernel32.ClosePseudoConsole.restype = None
    kernel32.ClosePseudoConsole.argtypes = [H]
    kernel32.InitializeProcThreadAttributeList.restype = ctypes.c_int
    kernel32.InitializeProcThreadAttributeList.argtypes = [
        H, ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(ctypes.c_size_t)
    ]
    kernel32.UpdateProcThreadAttribute.restype = ctypes.c_int
    kernel32.UpdateProcThreadAttribute.argtypes = [
        H, ctypes.c_ulong, ctypes.c_size_t, H, ctypes.c_size_t, H, H
    ]
    kernel32.DeleteProcThreadAttributeList.restype = None
    kernel32.DeleteProcThreadAttributeList.argtypes = [H]
    kernel32.CreateJobObjectW.restype = H
    kernel32.CreateJobObjectW.argtypes = [H, ctypes.c_wchar_p]
    kernel32.SetInformationJobObject.argtypes = [H, ctypes.c_int, H, ctypes.c_ulong]
    kernel32.AssignProcessToJobObject.argtypes = [H, H]
    kernel32.TerminateJobObject.argtypes = [H, ctypes.c_uint]
    kernel32.TerminateProcess.argtypes = [H, ctypes.c_uint]
    kernel32.WaitForSingleObject.restype = ctypes.c_ulong
    kernel32.WaitForSingleObject.argtypes = [H, ctypes.c_ulong]
    kernel32.GetExitCodeProcess.restype = ctypes.c_int
    kernel32.GetExitCodeProcess.argtypes = [H, ctypes.POINTER(ctypes.c_ulong)]
    kernel32.CloseHandle.argtypes = [H]
    kernel32.SetHandleInformation.argtypes = [H, ctypes.c_ulong, ctypes.c_ulong]
    kernel32.CreateProcessW.restype = ctypes.c_int
    advapi32.CreateProcessAsUserW.restype = ctypes.c_int


def _kernel32() -> Any:  # pragma: no cover - Windows only
    return ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]


def available() -> bool:
    """True when this host has a pseudoconsole."""
    if sys.platform != "win32":
        return False
    try:  # pragma: no cover - Windows only
        return hasattr(_kernel32(), "CreatePseudoConsole")
    except OSError:
        return False


def detail() -> str:
    """Human-readable ConPTY status for `doctor` output and error messages."""
    if sys.platform != "win32":
        return f"ConPTY requires Windows; this host is {sys.platform}"
    if available():  # pragma: no cover - Windows only
        return "ConPTY (CreatePseudoConsole)"
    return (  # pragma: no cover - Windows only
        f"this build has no pseudoconsole; ConPTY needs Windows 10 build "
        f"{CONPTY_MIN_BUILD} or newer"
    )


def _check_hresult(result: int, what: str) -> None:
    if result != 0:  # pragma: no cover - Windows only
        raise InvalidTask(f"{MARKER}: {what} failed (HRESULT 0x{result & 0xFFFFFFFF:08X})")


class ConPty:  # pragma: no cover - every method needs a real pseudoconsole
    """A live pseudoconsole and the process attached to it."""

    def __init__(
        self,
        kernel32: Any,
        pseudoconsole: ctypes.c_void_p,
        process: _ProcessInformation,
        job: ctypes.c_void_p | None,
        token: ctypes.c_void_p | None,
        read_fd: int,
        write_fd: int,
        scratch: str | None,
    ) -> None:
        self._kernel32 = kernel32
        self._pseudoconsole = pseudoconsole
        self._process = process
        self._job = job
        self._token = token
        self._read_fd = read_fd
        self._write_fd = write_fd
        self._scratch = scratch
        self._closed = False
        self._lock = threading.RLock()

    # ------------------------------------------------------------------ spawn

    @classmethod
    def spawn(
        cls,
        argv: list[str],
        *,
        cwd: str,
        env: dict[str, str],
        cols: int,
        rows: int,
        confined_root: str | None = None,
    ) -> "ConPty":
        from .winconfine import WinconfineUnavailable, build_low_integrity_token
        from .winexec import environment_block

        kernel32 = _kernel32()
        advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)  # type: ignore[attr-defined]
        if not hasattr(kernel32, "CreatePseudoConsole"):
            raise InvalidTask(f"{MARKER}: {detail()}")
        _declare_win32(kernel32, advapi32)

        child_env = dict(env)
        scratch: str | None = None
        if confined_root is not None:
            # A low-IL shell cannot write the system %TEMP% (Medium label);
            # point it inside the Low-labeled workspace, as winexec does.
            scratch = os.path.join(confined_root, f".meshia-pty-tmp-{uuid.uuid4().hex}")
            os.makedirs(scratch, exist_ok=True)
            child_env["TEMP"] = scratch
            child_env["TMP"] = scratch

        pseudoconsole = ctypes.c_void_p()
        process = _ProcessInformation()
        job: ctypes.c_void_p | None = None
        token: ctypes.c_void_p | None = None
        attribute_list: ctypes.Array[ctypes.c_char] | None = None
        # (parent end, child end) for each direction.
        input_read = input_write = output_read = output_write = -1
        try:
            input_read, input_write = os.pipe()
            output_read, output_write = os.pipe()
            size = _Coord(X=max(1, min(cols, 0x7FFF)), Y=max(1, min(rows, 0x7FFF)))
            _check_hresult(
                kernel32.CreatePseudoConsole(
                    size,
                    ctypes.c_void_p(msvcrt.get_osfhandle(input_read)),
                    ctypes.c_void_p(msvcrt.get_osfhandle(output_write)),
                    ctypes.c_ulong(0),
                    ctypes.byref(pseudoconsole),
                ),
                "CreatePseudoConsole",
            )
            # The pseudoconsole duplicated both ends it was handed; ours must go
            # or the shell's exit never surfaces as EOF on the read side.
            os.close(input_read)
            input_read = -1
            os.close(output_write)
            output_write = -1

            needed = ctypes.c_size_t(0)
            kernel32.InitializeProcThreadAttributeList(
                None, ctypes.c_ulong(1), ctypes.c_ulong(0), ctypes.byref(needed)
            )
            attribute_list = ctypes.create_string_buffer(needed.value)
            if not kernel32.InitializeProcThreadAttributeList(
                attribute_list, ctypes.c_ulong(1), ctypes.c_ulong(0), ctypes.byref(needed)
            ):
                raise InvalidTask(
                    f"{MARKER}: InitializeProcThreadAttributeList failed "
                    f"({ctypes.get_last_error()})"
                )
            if not kernel32.UpdateProcThreadAttribute(
                attribute_list,
                ctypes.c_ulong(0),
                ctypes.c_size_t(PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE),
                pseudoconsole,
                ctypes.c_size_t(ctypes.sizeof(ctypes.c_void_p)),
                None,
                None,
            ):
                raise InvalidTask(
                    f"{MARKER}: UpdateProcThreadAttribute failed ({ctypes.get_last_error()})"
                )

            startup = _StartupInfoExW()
            startup.StartupInfo.cb = ctypes.sizeof(_StartupInfoExW)
            # Explicit null standard handles make ConPTY create the child's
            # console handles. Without this flag Windows can duplicate our
            # redirected stdin/stdout/stderr even with bInheritHandles=False,
            # leaking shell output into service logs and bypassing PTY input.
            # https://github.com/microsoft/terminal/discussions/15814
            startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES
            startup.lpAttributeList = ctypes.cast(attribute_list, ctypes.c_void_p)

            if confined_root is not None:
                try:
                    token = build_low_integrity_token()
                except WinconfineUnavailable as error:
                    raise AccessRefused(f"terminal confinement unavailable ({error})") from error

            command_line = ctypes.create_unicode_buffer(subprocess.list2cmdline(argv))
            block = ctypes.create_unicode_buffer(environment_block(child_env))
            flags = EXTENDED_STARTUPINFO_PRESENT | CREATE_UNICODE_ENVIRONMENT
            # bInheritHandles must be FALSE: the pseudoconsole is the child's
            # only console, handed over through the attribute list.
            if token is not None:
                created = advapi32.CreateProcessAsUserW(
                    token, None, command_line, None, None, False, flags, block,
                    ctypes.c_wchar_p(cwd), ctypes.byref(startup), ctypes.byref(process),
                )
            else:
                created = kernel32.CreateProcessW(
                    None, command_line, None, None, False, flags, block,
                    ctypes.c_wchar_p(cwd), ctypes.byref(startup), ctypes.byref(process),
                )
            if not created:
                raise InvalidTask(
                    f"The terminal could not be started: CreateProcess failed "
                    f"({ctypes.get_last_error()})"
                )

            job = kernel32.CreateJobObjectW(None, None)
            if job:
                limits = _JobExtendedLimits()
                limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                kernel32.SetInformationJobObject(
                    job,
                    JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
                    ctypes.byref(limits),
                    ctypes.sizeof(limits),
                )
                kernel32.AssignProcessToJobObject(job, process.hProcess)

            terminal = cls(
                kernel32, pseudoconsole, process, job, token, output_read, input_write, scratch
            )
            output_read = input_write = -1  # ownership transferred
            return terminal
        except BaseException:
            for descriptor in (input_read, input_write, output_read, output_write):
                if descriptor >= 0:
                    try:
                        os.close(descriptor)
                    except OSError:
                        pass
            if pseudoconsole:
                kernel32.ClosePseudoConsole(pseudoconsole)
            for handle in (process.hThread, process.hProcess, job, token):
                if handle:
                    kernel32.CloseHandle(handle)
            if scratch is not None:
                shutil.rmtree(scratch, ignore_errors=True)
            raise
        finally:
            if attribute_list is not None:
                kernel32.DeleteProcThreadAttributeList(attribute_list)

    # -------------------------------------------------------------- transport

    def read(self, count: int) -> bytes:
        try:
            return os.read(self._read_fd, count)
        except OSError:
            return b""

    def write(self, data: bytes) -> int:
        with self._lock:
            if self._closed:
                return 0
            try:
                return os.write(self._write_fd, data)
            except OSError:
                return 0

    def resize(self, cols: int, rows: int) -> None:
        with self._lock:
            if self._closed:
                return
            self._kernel32.ResizePseudoConsole(
                self._pseudoconsole,
                _Coord(X=max(1, min(cols, 0x7FFF)), Y=max(1, min(rows, 0x7FFF))),
            )

    def is_running(self) -> bool:
        return self.exit_code() is None

    def exit_code(self) -> int | None:
        code = ctypes.c_ulong(0)
        if not self._kernel32.GetExitCodeProcess(self._process.hProcess, ctypes.byref(code)):
            return None
        if code.value == STILL_ACTIVE:
            return None
        return ctypes.c_int32(code.value).value

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
        kernel32 = self._kernel32
        if self._job:
            kernel32.TerminateJobObject(self._job, TERMINATE_EXIT_CODE)
        elif self._process.hProcess:
            kernel32.TerminateProcess(self._process.hProcess, TERMINATE_EXIT_CODE)
        if self._process.hProcess:
            kernel32.WaitForSingleObject(self._process.hProcess, ctypes.c_ulong(5000))
        # ClosePseudoConsole last: it drains and tears down the console host.
        if self._pseudoconsole:
            kernel32.ClosePseudoConsole(self._pseudoconsole)
        for descriptor in (self._read_fd, self._write_fd):
            if descriptor >= 0:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
        self._read_fd = self._write_fd = -1
        for handle in (self._process.hThread, self._process.hProcess, self._job, self._token):
            if handle:
                kernel32.CloseHandle(handle)
        if self._scratch is not None:
            shutil.rmtree(self._scratch, ignore_errors=True)


__all__ = ["CONPTY_MIN_BUILD", "MARKER", "ConPty", "available", "detail"]
