"""Windows mount occupancy without entering a potentially dead filesystem.

WinFsp drive letters are DOS-device links. Its default directory mounts are
reparse points, not MountManager volumes, so volume enumeration cannot prove
their absence. Inspect only the reparse object in a bounded helper; never
follow it or ask the filesystem on the other side for metadata.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import json
import ntpath
from pathlib import Path
import re
import sys

_DRIVE = re.compile(r"^[A-Za-z]:[\\/]?$")
_MAX_DEVICE_CHARS = 65_536
_MAX_REPARSE_BYTES = 16_384


def _dos_device_names() -> tuple[str, ...] | None:
    if sys.platform != "win32":
        return None
    try:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.QueryDosDeviceW.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD]
        kernel.QueryDosDeviceW.restype = wintypes.DWORD
        size = 1024
        while size <= _MAX_DEVICE_CHARS:
            buffer = ctypes.create_unicode_buffer(size)
            count = int(kernel.QueryDosDeviceW(None, buffer, size))
            if count:
                if count > size:
                    return None
                names = buffer[:count]
                if not names.endswith("\0"):
                    return None
                return tuple(name for name in names.split("\0") if name)
            if ctypes.get_last_error() != 122:  # ERROR_INSUFFICIENT_BUFFER
                return None
            size *= 2
    except (AttributeError, OSError, ValueError):
        return None
    return None


def mounted_drive_paths() -> set[str] | None:
    """Read current/global DOS-device names, including disconnected drives."""
    names = _dos_device_names()
    if names is None:
        return None
    return {ntpath.normcase(name[:2] + "\\") for name in names if _DRIVE.fullmatch(name)}


def _directory_registration(path: str) -> bool | None:
    """Helper-process body. A foreign or dangling reparse point is occupied.

OPEN_REPARSE_POINT applies to the final component only. Ancestors can still
be disconnected, which is why this function must never run in the service
process: its caller applies a fixed timeout and does not wait for a stuck IO.
"""
    try:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                      ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        kernel.CreateFileW.restype = wintypes.HANDLE
        kernel.DeviceIoControl.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p,
                                          wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
                                          ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
        kernel.DeviceIoControl.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        handle = kernel.CreateFileW(path, 0x80, 7, None, 3, 0x02200000, None)
        if handle == ctypes.c_void_p(-1).value or not handle:
            return False if ctypes.get_last_error() in (2, 3) else None
        try:
            buffer = ctypes.create_string_buffer(_MAX_REPARSE_BYTES)
            returned = wintypes.DWORD()
            if not kernel.DeviceIoControl(handle, 0x000900A8, None, 0, buffer,
                                          len(buffer), ctypes.byref(returned), None):
                # An existing ordinary directory is not a mount. Do not turn
                # access denial, sharing contention, or an unavailable device
                # into permission to create a second filesystem here.
                return False if ctypes.get_last_error() == 4390 else None
            if returned.value < 8 or returned.value > len(buffer):
                return None
            # Every reparse tag is occupied, including unrelated junctions,
            # symlinks, cloud placeholders, and dead WinFsp volume targets.
            return True
        finally:
            kernel.CloseHandle(handle)
    except (AttributeError, OSError, ValueError):
        return None


def mount_registration_state(path: Path | str, *, timeout_seconds: float = 3.0) -> bool | None:
    from .util import console_python, run_bounded_capture

    value = str(path)
    if not value or "\0" in value or len(value) > 32_767:
        return None
    # The extended spelling is an alias of the same local object. UNC paths
    # are deliberately unknown: no network traversal belongs in this probe.
    if value.startswith("\\\\?\\"):
        value = value[4:]
    if _DRIVE.fullmatch(value):
        drives = mounted_drive_paths()
        return None if drives is None else ntpath.normcase(value[:2] + "\\") in drives
    drive, rest = ntpath.splitdrive(value)
    if not re.fullmatch(r"[A-Za-z]:", drive) or not rest.startswith(("\\", "/")):
        return None
    normalized = ntpath.normpath(value)
    output = run_bounded_capture(
        [console_python(), "-I", str(Path(__file__).absolute()), "--directory", normalized],
        timeout_seconds=timeout_seconds, max_output_bytes=32,
    )
    if output is None:
        return None
    try:
        state = json.loads(output)
    except (TypeError, ValueError):
        return None
    return state if type(state) is bool else None


if __name__ == "__main__":
    if sys.platform != "win32" or len(sys.argv) != 3 or sys.argv[1] != "--directory":
        raise SystemExit(2)
    print(json.dumps(_directory_registration(sys.argv[2])))
