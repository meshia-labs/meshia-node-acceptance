"""Stdio adapter for clients without remote HTTP/OAuth support.

The backend owns tool schemas, authorization and execution. This process only
adds standard project resource notifications while the desktop client is open.
Closing stdio never cancels a remote project or worker.
"""
from __future__ import annotations

import concurrent.futures
import json
import re
import sys
import threading
from typing import Any

from .control import ControlClient, ControlError

PROJECT_URI = re.compile(r"^meshia://projects/([a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12})$")
MAX_LINE = 4 * 1024 * 1024


class Bridge:
    def __init__(self, client: ControlClient, output=None):
        self.client = client
        self.output = output or sys.stdout
        self.write_lock = threading.Lock()
        self.sub_lock = threading.RLock()
        self.subscriptions: dict[str, str] = {}
        self.stopped = threading.Event()

    def emit(self, message: dict) -> None:
        with self.write_lock:
            self.output.write(json.dumps(message, ensure_ascii=False) + "\n")
            self.output.flush()

    def project(self, uri: Any) -> str:
        match = PROJECT_URI.fullmatch(uri) if isinstance(uri, str) else None
        if not match:
            raise ControlError("Expected meshia://projects/<workspace UUID>.")
        return match[1]

    def snapshot(self, uri: str, cursor: str | None = None) -> dict:
        value = self.client.tool("meshia_project_updates", {
            "workspace_id": self.project(uri), **({"cursor": cursor} if cursor else {}),
        })
        if not isinstance(value, dict) or value.get("ok") is False or not isinstance(value.get("cursor"), str):
            raise ControlError("Project updates unavailable. Check account access and server version.")
        return value

    def handle(self, message: Any) -> None:
        rpc_id = message.get("id") if isinstance(message, dict) else None
        valid_id = "id" not in message if isinstance(message, dict) else False
        valid_id = valid_id or (isinstance(rpc_id, (str, int)) and not isinstance(rpc_id, bool))
        if (not isinstance(message, dict) or message.get("jsonrpc") != "2.0"
                or not isinstance(message.get("method"), str) or not valid_id):
            self.emit({"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid JSON-RPC request."}})
            return
        method = message["method"]
        if "id" not in message:
            # Accepted backend work has its own explicit cancellation tools.
            # Host lifecycle/cancel notifications never stop remote workers.
            return
        try:
            params = message.get("params", {})
            if not isinstance(params, dict):
                raise ControlError("Request parameters must be an object.")
            if method == "initialize":
                reply = self.client.rpc(method, params, request_id=rpc_id)
                if "result" in reply:
                    reply["result"]["capabilities"]["resources"]["subscribe"] = True
                    reply["result"]["instructions"] += " Subscribe to meshia://projects/<workspace UUID> for changes while this client is open. The host decides whether notifications wake its agent. Persist explicitly shared conversation messages with stable IDs; MCP cannot read the host's private chat history."
                self.emit(reply)
                return
            if method == "resources/templates/list":
                result = {"resourceTemplates": [{"uriTemplate": "meshia://projects/{workspace_id}", "name": "Meshia project", "description": "Recent conversation, activity and remote agents; subscribe for changes.", "mimeType": "application/json"}]}
            elif method in ("resources/subscribe", "resources/unsubscribe"):
                uri = params.get("uri")
                self.project(uri)
                if method == "resources/subscribe":
                    with self.sub_lock:
                        if len(self.subscriptions) >= 8 and uri not in self.subscriptions:
                            raise ControlError("Subscribe to at most eight projects per client.")
                    value = self.snapshot(uri)  # Authorization before subscription.
                    with self.sub_lock:
                        if len(self.subscriptions) >= 8 and uri not in self.subscriptions:
                            raise ControlError("Subscribe to at most eight projects per client.")
                        self.subscriptions[uri] = value["cursor"]
                else:
                    with self.sub_lock:
                        self.subscriptions.pop(uri, None)
                result = {}
            elif method == "resources/read" and PROJECT_URI.fullmatch(str(params.get("uri", ""))):
                uri = params["uri"]
                result = {"contents": [{"uri": uri, "mimeType": "application/json", "text": json.dumps(self.snapshot(uri))}]}
            else:
                self.emit(self.client.rpc(method, params, request_id=rpc_id))
                return
            self.emit({"jsonrpc": "2.0", "id": rpc_id, "result": result})
        except ControlError as error:
            self.emit({"jsonrpc": "2.0", "id": rpc_id, "error": {"code": -32000, "message": str(error)}})
        except Exception:
            self.emit({"jsonrpc": "2.0", "id": rpc_id, "error": {"code": -32603, "message": "Meshia adapter failed. Check meshia account and meshia doctor; no mutation was retried."}})

    def poll(self) -> None:
        while not self.stopped.wait(10):
            with self.sub_lock:
                subscriptions = list(self.subscriptions.items())
            for uri, cursor in subscriptions:
                if self.stopped.is_set():
                    return
                try:
                    value = self.snapshot(uri, cursor)
                    if self.stopped.is_set():
                        return
                    with self.sub_lock:
                        if self.subscriptions.get(uri) != cursor:
                            continue
                        self.subscriptions[uri] = value["cursor"]
                        if value.get("changed"):
                            self.emit({"jsonrpc": "2.0", "method": "notifications/resources/updated", "params": {"uri": uri}})
                except ControlError:
                    # Do not fabricate a completion on network failure. Future
                    # polls recheck auth; no cursor advances until a full read.
                    continue

    def serve(self, source=None) -> int:
        source = source or sys.stdin
        watcher = threading.Thread(target=self.poll, daemon=True)
        watcher.start()
        capacity = threading.BoundedSemaphore(16)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            try:
                while True:
                    line = source.readline(MAX_LINE + 1)
                    if not line:
                        break
                    if len(line.encode("utf-8")) > MAX_LINE:
                        self.emit({"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "MCP frame exceeds 4 MiB."}})
                        return 1
                    try:
                        message = json.loads(line)
                    except ValueError:
                        self.emit({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Invalid JSON."}})
                        continue
                    capacity.acquire()
                    future = pool.submit(self.handle, message)
                    future.add_done_callback(lambda _future: capacity.release())
            finally:
                self.stopped.set()
        return 0
