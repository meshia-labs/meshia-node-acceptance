"""FSKit volume management: one native macOS volume per workspace.

On macOS 26 the signed ``Meshia.app`` bundle carries ``MeshiaFSExtension``,
an FSKit module that serves a volume from a path resource. The node owns the
whole lifecycle: it runs the bridge socket (``fskit_bridge``), writes one
control directory per workspace, asks ``mount -F`` to attach that directory
as a volume under ``~/Meshia/<workspace name>``, and unmounts it when the
workspace disappears or is renamed. FUSE-T remains the transport everywhere
else and whenever the extension is not installed and enabled.
"""

from __future__ import annotations

import json
import os
import platform
import plistlib
import re
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from .errors import StateError
from .fabric_mount import (
    MOUNT_REGISTRATION_CHECK_SECONDS,
    FabricMountError,
    _run_bounded_mount_command,
    mount_registration_state,
)
from .fskit_bridge import FSKitBridgeServer, VolumeCatalog, VolumeSpec
from .log import NULL_LOGGER, NodeLogger
from .util import ensure_private_dir, run_bounded_process, write_private_file
from .workspace import split_relative

MOUNT_BACKENDS = ("auto", "fskit", "fuse-t")
FSKIT_APP_BUNDLE_ID = "io.meshia.Meshia"
FSKIT_EXTENSION_BUNDLE_ID = "io.meshia.Meshia.MeshiaFSExtension"
FSKIT_EXTENSION_POINT = "com.apple.fskit.fsmodule"
FSKIT_FS_SHORT_NAME = "meshiafs"
#: FSKit path resources (``FSPathURLResource``) exist from macOS 26.0.
FSKIT_MIN_MACOS = (26, 0)
FSKIT_APPROVAL_PROBE_TIMEOUT_SECONDS = 5.0
#: The group container the extension and the node share; the team prefix is
#: read from the installed extension's entitlements so a re-signed build
#: (another team, Developer ID) needs no code change.
DEFAULT_FSKIT_APP_GROUP = "7U59JDXQZJ.io.meshia"
FSKIT_MOUNT_STATE_SCHEMA = "meshia.fskit.mounts.v1"
VOLUME_DESCRIPTOR_SCHEMA = "meshia.fskit.volume.v1"
MOUNT_TIMEOUT_SECONDS = 30.0
_APP_CANDIDATES = ("~/Applications/Meshia.app", "/Applications/Meshia.app")
_PLUGINKIT_STATE = {"+": "enabled", "-": "disabled", "!": "unusable", "?": "unknown"}
#: Sentinel: "discover on this machine" (as opposed to an explicit ``None``).
DISCOVER: Any = object()


@dataclass(frozen=True)
class FSKitBridgeAddress:
    """Where the extension finds the bridge socket and volume descriptors."""

    socket_path: Path
    volumes_dir: Path | None = None

    def resource_dir(self, volume_id: str) -> Path:
        root = self.volumes_dir or self.socket_path.parent / "volumes"
        return root / volume_id


def fskit_group_container(app_group: str = DEFAULT_FSKIT_APP_GROUP) -> Path:
    return Path.home() / "Library" / "Group Containers" / app_group


def default_fskit_address(app_group: str | None = None) -> FSKitBridgeAddress:
    group = app_group or fskit_app_group(fskit_app_path()) or DEFAULT_FSKIT_APP_GROUP
    root = fskit_group_container(group)
    return FSKitBridgeAddress(root / "fskit.sock", root / "volumes")


def macos_version() -> tuple[int, int] | None:
    if sys.platform != "darwin":
        return None
    release = platform.mac_ver()[0]
    match = re.match(r"(\d+)\.(\d+)", release or "")
    if match is None:
        return None
    return int(match.group(1)), int(match.group(2))


def fskit_app_path() -> Path | None:
    """Return the installed ``Meshia.app`` that embeds the FSKit extension."""

    explicit = os.environ.get("MESHIA_FSKIT_APP")
    candidates = ([explicit] if explicit else []) + list(_APP_CANDIDATES)
    for candidate in candidates:
        path = Path(candidate).expanduser()
        if (path / "Contents" / "Extensions" / "MeshiaFSExtension.appex").is_dir():
            return path
    return None


def fskit_app_group(app_path: Path | None) -> str | None:
    """Read the app-group identifier the installed extension was signed with."""

    if app_path is None:
        return None
    appex = app_path / "Contents" / "Extensions" / "MeshiaFSExtension.appex"
    try:
        result = subprocess.run(
            ["/usr/bin/codesign", "-d", "--entitlements", ":-", str(appex)],
            check=False,
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0 or not result.stdout:
            return None
        document = plistlib.loads(result.stdout)
    except (OSError, subprocess.TimeoutExpired, plistlib.InvalidFileException, ValueError):
        return None
    groups = document.get("com.apple.security.application-groups")
    if isinstance(groups, list):
        for group in groups:
            if isinstance(group, str) and group.endswith(".io.meshia"):
                return group
    return None


def fskit_module_approved(
    short_name: str = FSKIT_FS_SHORT_NAME,
    *,
    runner: Callable[[list[str]], tuple[int, str]] | None = None,
) -> bool | None:
    """Ask fskitd whether the module may be used, without mounting anything.

    pluginkit election (``+``) is necessary but not sufficient: the per-user
    approval in System Settings > File System Extensions lives in fskitd.
    ``mount -d`` performs every step except the mount system call, so an
    unapproved module answers "Module <id> is disabled!" while an approved one
    proceeds to probe the (deliberately empty) resource and fails harmlessly.
    ``None`` means the probe itself could not run.
    """

    if sys.platform != "darwin" and runner is None:
        return None
    import tempfile

    with tempfile.TemporaryDirectory(prefix="meshia-fskit-probe-") as scratch:
        resource = Path(scratch) / "resource"
        mount_point = Path(scratch) / "mountpoint"
        resource.mkdir()
        mount_point.mkdir()
        command = ["/sbin/mount", "-d", "-F", "-t", short_name, str(resource), str(mount_point)]
        try:
            if runner is not None:
                _code, output = runner(command)
            else:
                # mount(8) can block on a dead network mount elsewhere on the
                # host; never join that wait from a status/doctor probe.
                completed = run_bounded_process(
                    command,
                    timeout_seconds=FSKIT_APPROVAL_PROBE_TIMEOUT_SECONDS,
                    merge_stderr=True,
                )
                if completed is None:
                    return None
                _code, output = completed
        except OSError:
            return None
    return "is disabled" not in output


FSKIT_SETTINGS_URL = (
    "x-apple.systempreferences:com.apple.ExtensionsPreferences"
    "?extensionPointIdentifier=com.apple.fskit.fsmodule"
)


def fskit_approval_notice(extension_state: str | None) -> str | None:
    """The exact user action when Meshia's module is installed but not approved.

    Only ``disabled`` gets a notice: the app and module are present, pluginkit
    knows them, and the one thing missing is the per-user toggle that only the
    user can flip. Without it the node silently keeps serving files through
    FUSE-T (a kernel NFS client that can wedge); with it there is no kernel
    client at all.
    """

    if extension_state != "disabled":
        return None
    return (
        "Meshia's file system extension is installed but not yet approved, so "
        "files are still served through FUSE-T. Enable it: run "
        f'open "{FSKIT_SETTINGS_URL}" (System Settings > General > Login Items & '
        'Extensions > File System Extensions), turn on "Meshia", then run '
        "`meshia-node service restart`."
    )


def fskit_extension_state(
    bundle_id: str = FSKIT_EXTENSION_BUNDLE_ID,
    *,
    approval: Callable[[], bool | None] | None = None,
) -> str:
    """Return ``enabled``/``disabled``/``missing``/``unknown`` for the module.

    ``enabled`` requires both the pluginkit election and fskitd's approval.
    """

    if sys.platform != "darwin":
        return "missing"
    try:
        result = subprocess.run(
            ["/usr/bin/pluginkit", "-m", "-p", FSKIT_EXTENSION_POINT, "-i", bundle_id],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"
    state = "missing"
    for line in result.stdout.splitlines():
        if bundle_id in line:
            state = _PLUGINKIT_STATE.get(line[:1], "unknown")
            break
    if state != "enabled":
        return state
    approved = (approval or fskit_module_approved)()
    if approved is None:
        return "unknown"
    return "enabled" if approved else "disabled"


@dataclass(frozen=True)
class MountBackendSelection:
    requested: str
    backend: str
    reason: str
    app_path: Path | None = None
    extension_state: str | None = None


def select_mount_backend(
    requested: str,
    *,
    platform_name: str = sys.platform,
    version: tuple[int, int] | None = None,
    app_path: Path | None | Any = DISCOVER,
    extension_state: str | None = None,
) -> MountBackendSelection:
    """Decide between FSKit and FUSE-T without touching any mount.

    ``auto`` prefers FSKit only when every prerequisite is proven; an explicit
    ``fskit`` request fails closed so a user never silently ends up on FUSE-T
    after asking for the native volume.
    """

    if requested not in MOUNT_BACKENDS:
        raise ValueError(f"mount backend must be one of {', '.join(MOUNT_BACKENDS)}")
    if requested == "fuse-t":
        return MountBackendSelection(requested, "fuse-t", "requested")
    if platform_name != "darwin":
        reason = "fskit_requires_macos"
    else:
        resolved_version = version if version is not None else macos_version()
        if resolved_version is None or resolved_version < FSKIT_MIN_MACOS:
            reason = "fskit_requires_macos_26"
        else:
            app = fskit_app_path() if app_path is DISCOVER else app_path
            if app is None:
                reason = "meshia_app_not_installed"
            else:
                state = extension_state if extension_state is not None else fskit_extension_state()
                if state == "enabled":
                    return MountBackendSelection(
                        requested, "fskit", "requested" if requested == "fskit" else "auto", app, state
                    )
                reason = f"extension_{state}"
                app_path = app
                extension_state = state
    if requested == "fskit":
        raise StateError(
            "The FSKit mount backend is unavailable: "
            + {
                "fskit_requires_macos": "FSKit volumes need macOS.",
                "fskit_requires_macos_26": "FSKit path volumes need macOS 26 or newer.",
                "meshia_app_not_installed": "install Meshia.app (~/Applications/Meshia.app) first.",
                "extension_disabled": "enable Meshia in System Settings > General > Login Items & Extensions > File System Extensions.",
                "extension_missing": "open Meshia.app once so macOS registers its file system extension.",
            }.get(reason, reason)
        )
    return MountBackendSelection(
        requested,
        "fuse-t",
        reason,
        None if app_path is DISCOVER else app_path,
        extension_state,
    )


# --------------------------------------------------------------- volumes


@dataclass(frozen=True)
class MountedVolume:
    volume_id: str
    name: str
    mount_point: Path
    resource_dir: Path


def _mount_point_for(mount_root: Path, name: str) -> Path:
    if len(split_relative(name)) != 1:
        raise ValueError("volume names must be one portable path component")
    return mount_root / name


def write_volume_descriptor(address: FSKitBridgeAddress, spec: VolumeSpec) -> Path:
    """Publish the control directory ``mount -F`` hands to the extension."""

    resource_dir = address.resource_dir(spec.volume_id)
    ensure_private_dir(resource_dir)
    write_private_file(
        resource_dir / "volume.json",
        json.dumps(
            {
                "schema": VOLUME_DESCRIPTOR_SCHEMA,
                "volume_id": spec.volume_id,
                "name": spec.name,
                "socket": str(address.socket_path),
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8"),
    )
    return resource_dir


def _default_mount(resource_dir: Path, mount_point: Path) -> bool:
    return _run_bounded_mount_command(
        [
            "/sbin/mount",
            "-F",
            "-t",
            FSKIT_FS_SHORT_NAME,
            "-o",
            "nobrowse,nosuid,nodev" if os.environ.get("MESHIA_FSKIT_NOBROWSE") else "nosuid,nodev",
            str(resource_dir),
            str(mount_point),
        ],
        timeout_seconds=MOUNT_TIMEOUT_SECONDS,
    )


def _default_unmount(mount_point: Path, *, force: bool) -> bool:
    command = ["/sbin/umount"] + (["-f"] if force else []) + [str(mount_point)]
    return _run_bounded_mount_command(command)


class FSKitVolumeManager:
    """Keep the set of mounted FSKit volumes equal to the workspace catalog."""

    def __init__(
        self,
        address: FSKitBridgeAddress,
        volumes: VolumeCatalog,
        *,
        mount_root: Path | str,
        state_path: Path | str,
        logger: NodeLogger = NULL_LOGGER,
        mount: Callable[[Path, Path], bool] = _default_mount,
        unmount: Callable[..., bool] = _default_unmount,
        registry: Callable[[Path | str], bool | None] = mount_registration_state,
    ) -> None:
        self.address = address
        self.volumes = volumes
        self.mount_root = Path(mount_root).expanduser()
        self.state_path = Path(state_path).expanduser()
        self.logger = logger
        self._mount = mount
        self._unmount = unmount
        self._registry = registry
        self._lock = threading.RLock()
        self._mounted: dict[str, MountedVolume] = {}
        self._failed: dict[str, float] = {}
        self._closed = False

    # ------------------------------------------------------------ receipts

    def mounted_volumes(self) -> tuple[MountedVolume, ...]:
        with self._lock:
            return tuple(sorted(self._mounted.values(), key=lambda v: v.name.casefold()))

    def _write_receipts(self) -> None:
        document = {
            "schema": FSKIT_MOUNT_STATE_SCHEMA,
            "owner_pid": os.getpid(),
            "mount_root": str(self.mount_root),
            "socket": str(self.address.socket_path),
            "started_at_ns": time.time_ns(),
            "volumes": {
                volume.volume_id: {
                    "name": volume.name,
                    "mount_point": str(volume.mount_point),
                    "resource_dir": str(volume.resource_dir),
                }
                for volume in self._mounted.values()
            },
        }
        write_private_file(
            self.state_path,
            json.dumps(document, sort_keys=True, separators=(",", ":")).encode("utf-8"),
        )

    def _retire_receipts(self) -> None:
        try:
            self.state_path.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            pass

    def _stale_receipts(self) -> list[MountedVolume]:
        receipts = read_fskit_mount_state(self.state_path)
        if receipts is None:
            return []
        volumes = []
        for volume_id, entry in receipts.get("volumes", {}).items():
            try:
                volumes.append(
                    MountedVolume(
                        volume_id,
                        str(entry["name"]),
                        Path(str(entry["mount_point"])),
                        Path(str(entry["resource_dir"])),
                    )
                )
            except (KeyError, TypeError):
                continue
        return volumes

    # ----------------------------------------------------------- reconcile

    def reconcile(self, *, check_registry: bool = True) -> bool:
        """Mount missing volumes, unmount removed/renamed ones. Idempotent.

        Returns ``True`` when every catalog volume is mounted afterwards.
        """

        with self._lock:
            if self._closed:
                return False
            if not self._mounted:
                # A previous service instance may have left volumes attached
                # with a bridge that no longer exists. Detach them before
                # mounting fresh so Finder never shows two generations.
                for stale in self._stale_receipts():
                    if self._registry(stale.mount_point) is not False:
                        self._detach(stale, reason="stale_receipt")
            desired = {spec.volume_id: spec for spec in self.volumes()}
            complete = True
            for volume_id, mounted in list(self._mounted.items()):
                spec = desired.get(volume_id)
                if spec is None or spec.name != mounted.name:
                    self._detach(mounted, reason="removed" if spec is None else "renamed")
                    self._mounted.pop(volume_id, None)
                elif check_registry and self._registry(mounted.mount_point) is False:
                    self.logger.record(
                        "fskit_volume_detached_externally",
                        volume=mounted.name,
                        mount_point=str(mounted.mount_point),
                    )
                    self._mounted.pop(volume_id, None)
            for volume_id, spec in desired.items():
                if volume_id in self._mounted:
                    continue
                if time.monotonic() < self._failed.get(volume_id, 0.0):
                    complete = False
                    continue
                try:
                    self._mounted[volume_id] = self._attach(spec)
                    self._failed.pop(volume_id, None)
                except (FabricMountError, OSError, ValueError) as error:
                    complete = False
                    self._failed[volume_id] = time.monotonic() + 15.0
                    self.logger.record(
                        "fskit_volume_mount_failed",
                        volume=spec.name,
                        error_type=type(error).__name__,
                        error=str(error),
                    )
            if self._mounted:
                self._write_receipts()
            else:
                self._retire_receipts()
            return complete

    def _attach(self, spec: VolumeSpec) -> MountedVolume:
        mount_point = _mount_point_for(self.mount_root, spec.name)
        if self._registry(mount_point) is True:
            raise FabricMountError(
                f"{mount_point} is already a mounted volume; Meshia will not stack on it."
            )
        self.mount_root.mkdir(mode=0o755, parents=True, exist_ok=True)
        if mount_point.exists():
            if not mount_point.is_dir():
                raise FabricMountError(f"{mount_point} exists and is not a directory.")
            if any(mount_point.iterdir()):
                raise FabricMountError(f"{mount_point} is not empty; refusing to cover it.")
        else:
            mount_point.mkdir(mode=0o755)
        resource_dir = write_volume_descriptor(self.address, spec)
        if not self._mount(resource_dir, mount_point):
            raise FabricMountError(f"mount -F failed for {spec.name}.")
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            if self._registry(mount_point) is True:
                break
            time.sleep(0.05)
        else:
            self._unmount(mount_point, force=False)
            raise FabricMountError(f"{spec.name} never appeared in the mount registry.")
        volume = MountedVolume(spec.volume_id, spec.name, mount_point, resource_dir)
        self.logger.record(
            "fskit_volume_mounted", volume=spec.name, mount_point=str(mount_point)
        )
        return volume

    def _detach(self, volume: MountedVolume, *, reason: str) -> bool:
        detached = self._registry(volume.mount_point) is False
        if not detached:
            if self._unmount(volume.mount_point, force=False):
                detached = self._registry(volume.mount_point) is False
            if not detached and self._unmount(volume.mount_point, force=True):
                detached = self._registry(volume.mount_point) is False
        if detached:
            try:
                volume.mount_point.rmdir()
            except OSError:
                pass
            shutil.rmtree(volume.resource_dir, ignore_errors=True)
        self.logger.record(
            "fskit_volume_unmounted" if detached else "fskit_volume_unmount_not_confirmed",
            volume=volume.name,
            mount_point=str(volume.mount_point),
            reason=reason,
        )
        return detached

    def close(self) -> bool:
        with self._lock:
            self._closed = True
            clean = True
            for volume in list(self._mounted.values()):
                if not self._detach(volume, reason="close"):
                    clean = False
            self._mounted.clear()
            if clean:
                self._retire_receipts()
            return clean


def read_fskit_mount_state(path: Path | str) -> dict[str, Any] | None:
    try:
        document = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(document, dict) or document.get("schema") != FSKIT_MOUNT_STATE_SCHEMA:
        return None
    if not isinstance(document.get("volumes"), dict):
        return None
    return document


class FSKitMount:
    """The service-facing mount object: bridge server plus volume manager.

    Shares ``FabricFuseMount``'s surface (``start``/``close``/``running``/
    ``require_registered``/``detached_for_process_exit``) so the service loop,
    guarded maintenance, and shutdown ordering are transport-agnostic.
    """

    def __init__(
        self,
        backend: Any,
        *,
        volumes: VolumeCatalog,
        address: FSKitBridgeAddress,
        mount_root: Path | str,
        state_path: Path | str,
        logger: NodeLogger = NULL_LOGGER,
        manager_factory: Callable[..., FSKitVolumeManager] = FSKitVolumeManager,
    ) -> None:
        self.backend = backend
        self.address = address
        self.mount_point = Path(mount_root).expanduser()
        self.logger = logger
        self.server = FSKitBridgeServer(backend, address.socket_path, volumes=volumes, logger=logger)
        self.manager = manager_factory(
            address,
            volumes,
            mount_root=self.mount_point,
            state_path=state_path,
            logger=logger,
        )
        self._topology_dirty = threading.Event()
        self._next_registration_check = 0.0
        self._started = False
        self.transport_backend = "fskit"

    @property
    def running(self) -> bool:
        return self._started and self.server.running

    @property
    def detached_for_process_exit(self) -> bool:
        return False

    def _on_namespace_change(self, path: str) -> bool:
        if path == "/" or path.count("/") == 1:
            self._topology_dirty.set()
        return True

    def start(self, *, timeout_seconds: float | None = None) -> bool:
        del timeout_seconds
        if self.running:
            return True
        self.server.start()
        try:
            install = getattr(self.backend, "set_namespace_invalidator", None)
            if callable(install):
                install(self._on_namespace_change)
            complete = self.manager.reconcile()
            if (
                not complete
                and not self.manager.mounted_volumes()
                and self.manager.volumes()
            ):
                # pluginkit election is not fskitd approval: a module the user
                # never enabled in System Settings fails every mount -F with
                # "Module … is disabled!". Fail loudly so the service can fall
                # back to FUSE-T instead of running with no mount at all.
                self.manager.close()
                raise FabricMountError(
                    "No FSKit volume could be mounted. Enable Meshia under System "
                    "Settings > General > Login Items & Extensions > File System "
                    "Extensions, or choose `meshia-node mount --backend fuse-t`."
                )
        except BaseException:
            self.server.close()
            raise
        self._started = True
        self._next_registration_check = time.monotonic() + MOUNT_REGISTRATION_CHECK_SECONDS
        self.logger.record(
            "fskit_mount_started",
            mount_root=str(self.mount_point),
            volumes=[volume.name for volume in self.manager.mounted_volumes()],
        )
        return True

    def require_registered(self) -> None:
        """Re-converge volumes; called once per maintenance tick."""

        if not self._started:
            return
        now = time.monotonic()
        dirty = self._topology_dirty.is_set()
        if not dirty and now < self._next_registration_check:
            return
        self._topology_dirty.clear()
        self._next_registration_check = now + MOUNT_REGISTRATION_CHECK_SECONDS
        self.manager.reconcile(check_registry=True)

    def close(self) -> bool:
        remove = getattr(self.backend, "set_namespace_invalidator", None)
        if callable(remove):
            remove(None)
        clean = self.manager.close()
        self.server.close()
        self.backend.close()
        self._started = False
        return clean


__all__ = [
    "DEFAULT_FSKIT_APP_GROUP",
    "FSKIT_APP_BUNDLE_ID",
    "FSKIT_EXTENSION_BUNDLE_ID",
    "FSKIT_FS_SHORT_NAME",
    "FSKIT_MIN_MACOS",
    "FSKitBridgeAddress",
    "FSKitMount",
    "FSKitVolumeManager",
    "MOUNT_BACKENDS",
    "MountBackendSelection",
    "MountedVolume",
    "default_fskit_address",
    "fskit_app_group",
    "fskit_app_path",
    "fskit_extension_state",
    "fskit_approval_notice",
    "FSKIT_SETTINGS_URL",
    "fskit_module_approved",
    "macos_version",
    "read_fskit_mount_state",
    "select_mount_backend",
    "write_volume_descriptor",
]
