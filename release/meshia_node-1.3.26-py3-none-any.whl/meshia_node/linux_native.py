"""Linux workspace compute using the host's tools and kernel namespaces.

The distro's bubblewrap builds an empty mount namespace, private PID/IPC
namespaces and a user namespace with no capabilities. Only runtime locations
and the attached workspace are mounted. IP networking stays on the host;
Landlock scopes abstract Unix sockets and signals, while inherited seccomp
denies unsafe socket domains and namespace/process-inspection escape routes. No container image,
Docker service or root daemon is involved. Landlock ABI 6 is required for IPC
scoping; filesystem enforcement comes from the separate mount namespace.
"""
from __future__ import annotations

import errno
import ctypes
import json
import os
from pathlib import Path
import platform
import signal
import stat
import struct
import subprocess
import sys
import tempfile
import threading
import time
from typing import Callable

BWRAP = Path("/usr/bin/bwrap")
KIND = "linux-namespaces-landlock"
_probe_lock = threading.Lock()
_probe_cache: tuple[tuple, float, tuple[bool, str]] | None = None

# Trusted startup before the task environment is read. Linux 6.12 / Landlock
# ABI 6 scopes abstract Unix sockets and signals to this domain; mount and IPC
# namespaces separately protect pathname sockets, metadata, SysV and POSIX IPC.
# Keep normal AF_UNIX creation available for multiprocessing/ML fd sharing.
_SCOPE_STAGE = r'''
import ctypes, json, os, sys
libc = ctypes.CDLL(None, use_errno=True)
libc.syscall.restype = ctypes.c_long
if libc.syscall(444, 0, 0, 1) < 6:
    raise RuntimeError('Linux workspace compute requires Landlock ABI 6 (kernel 6.12+)')
class Ruleset(ctypes.Structure):
    _fields_ = [('fs', ctypes.c_uint64), ('net', ctypes.c_uint64), ('scoped', ctypes.c_uint64)]
rules = Ruleset(0, 0, 3)
fd = libc.syscall(444, ctypes.byref(rules), ctypes.sizeof(rules), 0)
if fd < 0:
    raise OSError(ctypes.get_errno(), 'Landlock IPC/signal domain creation refused')
try:
    if libc.prctl(38, 1, 0, 0, 0) != 0 or libc.syscall(446, fd, 0) != 0:
        raise OSError(ctypes.get_errno(), 'Landlock IPC/signal scope refused')
finally:
    os.close(fd)
argv = json.loads(sys.argv[1])
os.execvpe(argv[0], argv, os.environ)
'''


def _helper() -> str:
    """Never resolve a task-controlled PATH or execute a writable helper."""
    for path in (BWRAP, *BWRAP.parents):
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise RuntimeError("Linux workspace compute requires the root-owned distro /usr/bin/bwrap")
    info = BWRAP.stat()
    if not stat.S_ISREG(info.st_mode) or not info.st_mode & 0o111 or info.st_mode & 0o6000:
        raise RuntimeError("Linux workspace compute requires non-setuid distro bubblewrap")
    return str(BWRAP)


def seccomp_filter(machine: str | None = None) -> bytes:
    """Classic BPF, native 64-bit ABI only; unsupported/compat ABIs fail closed.

    Numbers follow Linux asm/unistd_64.h and asm-generic/unistd.h. In particular
    reject x32 (the high syscall bit), socketcall/compat ABIs, and io_uring's
    socket opcode; otherwise an allowed IP socket syscall could be bypassed.
    clone3 returns ENOSYS so glibc falls back to filterable clone for threads.
    """
    machine = machine or platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        architecture, socket_nr, clone_nr = 0xC000003E, 41, 56
        denied = (101, 155, 165, 166, 167, 169, 172, 173, 175, 176, 246,
                  248, 249, 250, 272, 298, 303, 304, 308, 310, 311, 313,
                  321, 323, 425, 426, 427, 428, 429, 430, 431, 432, 433,
                  438, 440, 442)
    elif machine in ("aarch64", "arm64"):
        architecture, socket_nr, clone_nr = 0xC00000B7, 198, 220
        denied = (39, 40, 41, 97, 104, 105, 106, 117, 142, 217, 218, 219,
                  224, 225, 241, 264, 265, 268, 270, 271, 273, 280, 282,
                  425, 426, 427, 428, 429, 430, 431, 432, 433, 438, 440, 442)
    else:
        raise RuntimeError("Linux workspace compute requires a 64-bit x86 or ARM kernel ABI")
    code: list[tuple[int, int, int, int]] = []
    def stmt(op: int, value: int) -> None:
        code.append((op, 0, 0, value))
    def jump(value: int, yes: int, no: int) -> None:
        code.append((0x15, yes, no, value))  # BPF_JMP | BPF_JEQ | BPF_K
    deny = 0x00050000 | errno.EPERM
    stmt(0x20, 4)  # seccomp_data.arch
    jump(architecture, 1, 0)
    stmt(0x06, 0x80000000)  # KILL_PROCESS, not a recoverable ABI fallback
    stmt(0x20, 0)  # seccomp_data.nr
    code.append((0x35, 0, 1, 0x40000000))  # reject x32 and invalid signed calls
    stmt(0x06, 0x80000000)
    jump(435, 0, 1)  # clone3
    stmt(0x06, 0x00050000 | errno.ENOSYS)
    for number in denied:
        jump(number, 0, 1)
        stmt(0x06, deny)
    jump(socket_nr, 0, 6)
    stmt(0x20, 16)  # socket domain; scoped Unix or IP, never NETLINK/VSOCK
    jump(1, 3, 0)
    jump(2, 2, 0)
    jump(10, 1, 0)
    stmt(0x06, deny)
    stmt(0x06, 0x7FFF0000)
    jump(clone_nr, 0, 4)
    stmt(0x20, 16)  # clone flags: deny every CLONE_NEW* flag, retain threads
    code.append((0x45, 0, 1, 0x7E020000))  # BPF_JSET, includes CLONE_NEWCGROUP
    stmt(0x06, deny)
    stmt(0x06, 0x7FFF0000)
    stmt(0x06, 0x7FFF0000)
    return b"".join(struct.pack("=HBBI", *instruction) for instruction in code)


def _readable_roots() -> list[Path]:
    from .native_execution import runtime_read_roots
    roots: list[Path] = []
    for path in sorted((Path(p) for p in runtime_read_roots()), key=lambda p: (len(p.parts), str(p))):
        # /proc must describe the private PID namespace; device nodes come
        # from --dev and the explicit GPU list below, never a host /dev bind.
        if path == Path("/proc") or Path("/proc") in path.parents or Path("/dev") in path.parents:
            continue
        if any(parent == path or parent in path.parents for parent in roots):
            continue
        roots.append(path)
    return roots


def _devices() -> list[Path]:
    """Expose only compute accelerators, never disks, TTYs or host IPC."""
    candidates = list(Path("/dev/dri").glob("renderD*"))
    candidates += list(Path("/dev").glob("nvidia[0-9]*"))
    candidates += [Path("/dev") / name for name in ("nvidiactl", "nvidia-uvm", "nvidia-uvm-tools", "kfd")]
    candidates += list(Path("/dev/nvidia-caps").glob("nvidia-cap[0-9]*"))
    return sorted(path for path in candidates if path.exists() and stat.S_ISCHR(path.lstat().st_mode))


def _command(argv: list[str], *, workspace: Path, cwd: Path, filter_fd: int) -> list[str]:
    command = [_helper(), "--unshare-user", "--unshare-pid", "--unshare-ipc",
               "--unshare-uts", "--unshare-cgroup", "--disable-userns",
               "--assert-userns-disabled", "--cap-drop", "ALL", "--new-session",
               "--die-with-parent", "--proc", "/proc", "--dev", "/dev",
               "--tmpfs", "/dev/shm", "--tmpfs", "/tmp"]
    for path in _readable_roots():
        command += ["--ro-bind", str(path), str(path)]
    for path in _devices():
        command += ["--dev-bind", str(path), str(path)]
    # Keep the original mount path: programs and MCP see the same filenames.
    # All other data paths simply do not exist in this process's namespace.
    command += ["--bind", str(workspace), str(workspace), "--remount-ro", "/",
                "--chdir", str(cwd), "--seccomp", str(filter_fd), "--",
                sys.executable, "-I", "-c", _SCOPE_STAGE, json.dumps(argv)]
    return command


def _filter_fd() -> int:
    fd = os.memfd_create("meshia-workspace-seccomp", flags=0)
    try:
        os.write(fd, seccomp_filter())
        os.lseek(fd, 0, os.SEEK_SET)
        os.set_inheritable(fd, True)
        return fd
    except BaseException:
        os.close(fd)
        raise


def launch(argv: list[str], *, workspace: Path, cwd: Path, env: dict[str, str]) -> None:
    """Exec the fixed trusted post-policy stage; caller owns timeout/cancel."""
    fd = _filter_fd()
    try:
        command = _command(argv, workspace=workspace, cwd=cwd, filter_fd=fd)
        os.execve(command[0], command, env)
    finally:
        os.close(fd)


def run_workspace_subprocess(argv: list[str], *, workspace: Path, cwd: Path, env: dict[str, str], **options):
    from .executor import native_environment, run_bounded_subprocess
    from .native_command import _EXECUTE_STAGE, command_stdin
    from .native_execution import _workspace_environment
    fd = _filter_fd()
    try:
        command = _command([sys.executable, "-I", "-c", _EXECUTE_STAGE, *argv],
                           workspace=workspace, cwd=cwd, filter_fd=fd)
        return run_bounded_subprocess(
            command, cwd="/", env=native_environment(), pass_fds=(fd,),
            stdin=command_stdin(_workspace_environment(env, workspace), options.pop("stdin", None)),
            **options,
        )
    finally:
        os.close(fd)


def _probe() -> tuple[bool, str]:
    if sys.platform != "linux":
        return False, "Linux workspace compute requires Linux"
    try:
        _helper()
        fd = _filter_fd()
        try:
            with tempfile.TemporaryDirectory(prefix="meshia-native-probe-") as directory:
                command = _command([sys.executable, "-I", "-c", """
import ctypes, errno, os, pathlib, socket
assert ctypes.CDLL(None).prctl(39, 0, 0, 0, 0) == 1
try:
    pathlib.Path('/proc/1/root/etc/shadow').read_bytes()
except OSError as error:
    assert error.errno in (errno.EACCES, errno.EPERM, errno.ENOENT)
else:
    raise AssertionError('A host-private file was readable through procfs')
for domain in (socket.AF_INET, socket.AF_UNIX):
    with socket.socket(domain):
        pass
"""], workspace=Path(directory), cwd=Path(directory), filter_fd=fd)
                result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                        stderr=subprocess.PIPE, timeout=5, pass_fds=(fd,), check=False)
        finally:
            os.close(fd)
        if result.returncode:
            from .util import clean
            # The last traceback line carries the actual refusal, rather than
            # the interpreter's unhelpful stack header.
            reason = clean(result.stderr.decode("utf-8", "replace")[-300:], limit=300)
            return False, f"Linux workspace compute needs distro bubblewrap, user namespaces and Landlock ABI 6; the native boundary probe was refused: {reason}"
        return True, "Native Linux compute; workspace files, read-only installed tools, IP networking and isolated host IPC/processes"
    except (OSError, RuntimeError, subprocess.SubprocessError) as error:
        return False, f"Linux workspace compute needs distro bubblewrap and user namespaces/seccomp ({type(error).__name__})"


def _readiness() -> tuple[bool, str]:
    global _probe_cache
    # Retry failures shortly; do not permanently cache missing dependencies.
    try:
        info = BWRAP.stat()
        identity = (info.st_dev, info.st_ino, info.st_mtime_ns, os.getuid())
    except (OSError, AttributeError):
        identity = (None,)
    with _probe_lock:
        now = time.monotonic()
        if _probe_cache and _probe_cache[0] == identity and now < _probe_cache[1]:
            return _probe_cache[2]
        result = _probe()
        _probe_cache = (identity, now + (300 if result[0] else 15), result)
        return result


def available() -> bool:
    return _readiness()[0]


def detail() -> str:
    return _readiness()[1]


def _children(pid: int) -> set[int]:
    result: set[int] = set()
    try:
        threads = list(Path(f"/proc/{pid}/task").iterdir())
    except OSError:
        return result
    for thread in threads:
        try:
            result.update(int(value) for value in (thread / "children").read_text().split())
        except OSError:
            pass
    return result


def _kill_owned_children() -> None:
    """Freeze before descending, then kill pinned identities, including setsid.

    A subreaper adopts double-forked descendants. Only children of this helper
    are inspected; pidfds prevent signaling a reused PID. Freezing a parent
    before reading its children closes the fork-during-enumeration race.
    """
    def stop_tree(parent: int) -> None:
        for child in _children(parent):
            try:
                fd = os.pidfd_open(child)
            except ProcessLookupError:
                continue
            try:
                if child not in _children(parent):
                    continue
                signal.pidfd_send_signal(fd, signal.SIGSTOP)
                stop_tree(child)
                signal.pidfd_send_signal(fd, signal.SIGKILL)
            except ProcessLookupError:
                pass
            finally:
                os.close(fd)
    deadline = time.monotonic() + 0.4
    while True:
        stop_tree(os.getpid())
        while True:
            try:
                pid, _ = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                return
            if pid == 0:
                break
        if time.monotonic() >= deadline:
            return
        time.sleep(0.005)


def supervise(launch_command: Callable[[], None]) -> int:
    """Own the full-mode process tree without changing its OS permissions.

    Full mode gets no namespace or seccomp restriction. The small credential-
    free parent only reaps descendants on command exit/cancel, including
    ordinary daemonization; it does not undo independent OS services an owner
    deliberately creates through another service manager.
    """
    libc = ctypes.CDLL(None, use_errno=True)
    parent = os.getppid()
    stopping = False
    def stop(_signal, _frame):
        nonlocal stopping
        stopping = True
    for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(number, stop)
    # Set before fork so even immediately orphaned grandchildren are owned.
    if libc.prctl(36, 1, 0, 0, 0) != 0 or libc.prctl(1, signal.SIGTERM, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "Linux command ownership could not be established")
    if os.getppid() != parent or stopping:
        return 143
    child = os.fork()
    if child == 0:
        for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(number, signal.SIG_DFL)
        try:
            launch_command()
        except BaseException as error:
            print(f"Native command startup failed: {error}", file=sys.stderr, flush=True)
        os._exit(70)
    status = None
    try:
        while not stopping:
            waited, result = os.waitpid(child, os.WNOHANG)
            if waited:
                status = result
                break
            time.sleep(0.01)
    finally:
        _kill_owned_children()
    return 143 if status is None else os.waitstatus_to_exitcode(status)
