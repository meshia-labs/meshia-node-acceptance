"""Allow `python -m meshia_node` as an alias for the `meshia-node` console script."""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
