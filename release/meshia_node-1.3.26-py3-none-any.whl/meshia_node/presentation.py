"""Terminal presentation primitives for the human-facing Meshia CLI.

The installer has native shell implementations because it runs before Python is
available.  Once installed, this module is the canonical CLI visual language.
It deliberately keeps rendering pure: JSON output, redirected output, and tests
never inherit color or animation control sequences.
"""

from __future__ import annotations

import os
import sys
from typing import TextIO


PIXEL_MARK = ("■ ◻ ■", "◻ ■ ■")
ASCII_MARK = ("# . #", ". # #")


def _is_utf8(stream: TextIO) -> bool:
    encoding = (getattr(stream, "encoding", None) or "").lower().replace("-", "")
    return "utf8" in encoding


def interactive_terminal(stream: TextIO = sys.stdout) -> bool:
    """Return whether decorative terminal rendering is safe for ``stream``."""

    return bool(
        getattr(stream, "isatty", lambda: False)()
        and os.environ.get("TERM", "").lower() != "dumb"
        and os.environ.get("MESHIA_PLAIN", "").lower() not in {"1", "true", "yes"}
    )


def color_enabled(stream: TextIO = sys.stdout) -> bool:
    return interactive_terminal(stream) and "NO_COLOR" not in os.environ


def unicode_enabled(stream: TextIO = sys.stdout) -> bool:
    return interactive_terminal(stream) and _is_utf8(stream)


def paint(text: str, code: str, *, stream: TextIO = sys.stdout) -> str:
    if not color_enabled(stream):
        return text
    return f"\x1b[{code}m{text}\x1b[0m"


def wordmark(
    *,
    stream: TextIO = sys.stdout,
    subtitle: str = "COMPUTE, IN REACH.",
) -> str:
    """Render the compact Meshia pixel mark with a deterministic fallback."""

    mark = PIXEL_MARK if unicode_enabled(stream) else ASCII_MARK
    name = paint("M E S H I A", "1;38;5;213", stream=stream)
    detail = paint(subtitle, "38;5;110", stream=stream)
    pixels = [paint(row, "38;5;141", stream=stream) for row in mark]
    return f"{pixels[0]}   {name}\n{pixels[1]}   {detail}"


__all__ = [
    "ASCII_MARK",
    "PIXEL_MARK",
    "color_enabled",
    "interactive_terminal",
    "paint",
    "unicode_enabled",
    "wordmark",
]
