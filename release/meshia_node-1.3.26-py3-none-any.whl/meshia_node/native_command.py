"""Trusted native startup inside the command's cancellable process session.

Only authenticated route strings reach this helper. Mount opens, symlink
resolution, cwd validation and OS policy startup happen after the parent owns
the process, so an unavailable filesystem cannot evade its timeout/revocation.
No enrollment credentials, signed client or control-plane callback is loaded.
"""
from __future__ import annotations

import os
import sys

# Capture only fixed markers, including entry before the remaining imports.
# Missing entry means the child has not reported it, not a diagnosed OS cause.
if __name__ == "__main__" and len(sys.argv) == 3 and sys.argv[1] == "--workspace-read-probe":
    try:
        os.write(2, b"MESHIA_READ_PHASE:child_entry\n")
    except OSError:
        pass

import json
from pathlib import Path


WORKSPACE_READ_PHASES = frozenset({
    "before_child_entry", "child_entry", "root_import", "root_setup", "root_lstat",
    "root_open", "root_fstat", "root_lstat_after_open", "root_realpath",
    "root_lstat_after_realpath", "root_scandir", "root_readdir", "root_close", "complete",
})
_WORKSPACE_READ_PHASE_LINES = {
    b"MESHIA_READ_PHASE:" + phase.encode("ascii"): phase
    for phase in WORKSPACE_READ_PHASES if phase != "before_child_entry"
}


def workspace_read_phase(output: bytes) -> str:
    """Project bounded captured output; never retain arbitrary child text."""
    phase = "before_child_entry"
    for line in output[:512].splitlines():
        if line in _WORKSPACE_READ_PHASE_LINES:
            phase = _WORKSPACE_READ_PHASE_LINES[line]
    return phase


def _workspace_read_phase(phase: str) -> None:
    if phase not in WORKSPACE_READ_PHASES:
        raise ValueError("Invalid workspace read phase")
    try:
        os.write(2, b"MESHIA_READ_PHASE:" + phase.encode("ascii") + b"\n")
    except OSError:
        pass  # Diagnostics must not change the outcome of the actual read.


MAX_ENV_FRAME_BYTES = 1_048_576

# This fixed stage starts only after Seatbelt is installed in limited mode.
# Exact unbuffered reads leave the caller's stdin in the pipe for the command.
# In full mode the helper runs the same stage directly. Windows must wait for
# the real command: execvpe's CRT behavior exits the helper before its child,
# which would prematurely close the parent's kill-on-close Job Object.
_EXECUTE_STAGE = r'''
import json, os, subprocess, sys
def read_exact(size):
    chunks = bytearray()
    while len(chunks) < size:
        chunk = os.read(0, size - len(chunks))
        if not chunk:
            raise RuntimeError("Native command environment frame is incomplete")
        chunks.extend(chunk)
    return bytes(chunks)
size = int.from_bytes(read_exact(4), 'big')
if not 2 <= size <= 1048576:
    raise RuntimeError("Native command environment frame exceeds its bound")
values = json.loads(read_exact(size))
if not isinstance(values, dict) or any(
    not isinstance(k, str) or not k or '=' in k or '\0' in k
    or not isinstance(v, str) or '\0' in v for k, v in values.items()
):
    raise RuntimeError("Native command environment frame is invalid")
environment = dict(os.environ)
environment.update(values)
argv = sys.argv[1:]
if sys.platform == 'win32':
    # Forward only the outer launcher's three pipe handles. Explicit handles
    # keep the protocol intact when the process has no console window.
    raise SystemExit(subprocess.call(argv, env=environment, stdin=0, stdout=1, stderr=2,
                                    creationflags=subprocess.CREATE_NO_WINDOW))
os.execvpe(argv[0], argv, env=environment)
'''


def command_stdin(environment: dict[str, str], stdin: bytes | None) -> bytes:
    encoded = json.dumps(environment, ensure_ascii=False).encode("utf-8")
    if len(encoded) > MAX_ENV_FRAME_BYTES:
        from .errors import InvalidTask
        raise InvalidTask("Native command environment exceeds its transfer limit.")
    return len(encoded).to_bytes(4, "big") + encoded + (stdin or b"")


def command_argv(argv: list[str], *, root: str | None, cwd: str, access: str,
                 observer_fd: int | None = None) -> list[str]:
    from meshia_node.util import console_python

    setup = {"root": root, "cwd": cwd, "access": access}
    if observer_fd is not None:
        setup["_app_owner_fd"] = observer_fd
    return [console_python(), "-I", str(Path(__file__).absolute()), json.dumps(setup), *argv]


def workspace_read_argv(root: str) -> list[str]:
    """Use the daemon interpreter and responsibility context for mount access."""
    from meshia_node.util import console_python

    return [console_python(), "-IB", str(Path(__file__).absolute()), "--workspace-read-probe", root]


def probe_workspace_read(root: str) -> None:
    """Read one owned directory entry; never create or modify workspace data.

    Both root resolution/open and readdir belong inside the parent's bounded
    process session. In particular, a TCC-denied network mount can hang open
    instead of promptly returning a permissions error to the background node.
    """
    _workspace_read_phase("root_import")
    if sys.platform == "win32":
        from meshia_node.windows_native import workspace_directory
        _workspace_read_phase("root_setup")
        directory = workspace_directory(root)
        _workspace_read_phase("root_scandir")
        with os.scandir(directory) as entries:
            _workspace_read_phase("root_readdir")
            next(entries, None)
        return
    from meshia_node.workspace import _open_posix_workspace_root

    # Reuse the same pinned root validation as WorkspaceBoundary, with no
    # recovery/write work. Keep the descriptor until the real read completes.
    _path, canonical_root, descriptor, _ = _open_posix_workspace_root(
        root, create=False, read_phase=_workspace_read_phase,
    )
    try:
        _workspace_read_phase("root_scandir")
        with os.scandir(canonical_root) as entries:
            _workspace_read_phase("root_readdir")
            next(entries, None)
        _workspace_read_phase("root_close")
    finally:
        os.close(descriptor)


def launch(argv: list[str], *, root: str | None, cwd: str, access: str) -> None:
    from meshia_node.errors import AccessRefused, UnsafePath
    from meshia_node.util import console_python
    from meshia_node.workspace import WorkspaceBoundary

    environment = dict(os.environ)
    if access == "full" and Path(cwd).expanduser().is_absolute():
        directory = Path(cwd).expanduser()
        command = None
    elif sys.platform == "win32":
        from meshia_node import windows_native
        from meshia_node.native_execution import _workspace_environment
        from meshia_node.workspace import split_relative
        if access not in ("limited", "full") or root is None:
            raise AccessRefused("Native execution requires an owner compute grant and mounted workspace.")
        workspace = windows_native.workspace_directory(root)
        directory = (workspace.joinpath(*split_relative(cwd, allow_root=True))
                     if access == "limited" else workspace / Path(cwd).expanduser())
        if not directory.is_dir():
            raise UnsafePath("exec.cwd must be an existing directory.")
        if access == "limited":
            # WinFsp mounts have no DOS volume name. The native launcher checks
            # real open-handle NT paths before installing the AppContainer;
            # Python realpath's DOS-only check is not applicable to this mount.
            # Restore workspace defaults inside LPAC after Windows reroutes its
            # TEMP/TMP/LOCALAPPDATA to the implicit OS profile.
            stage = ("import os\nos.environ.update("
                     + repr(_workspace_environment({}, workspace)) + ")\n"
                     + _EXECUTE_STAGE)
            windows_native.launch(
                [console_python(), "-I", "-c", stage, *argv], workspace=workspace,
                cwd=directory, env=_workspace_environment(environment, workspace),
            )
            return
        command = None
    else:
        if access not in ("limited", "full") or root is None:
            raise AccessRefused("Native execution requires an owner compute grant and mounted workspace.")
        with WorkspaceBoundary(root, recover_stream_temps=False) as boundary:
            if access == "limited":
                directory = boundary.absolute(cwd, allow_root=True)
            else:
                directory = boundary.root / Path(cwd).expanduser()
            if not directory.is_dir():
                raise UnsafePath("exec.cwd must be an existing directory.")
            if access == "limited":
                from meshia_node.native_execution import (
                    _macos_profile, _workspace_environment, available, detail, runtime_read_roots,
                )
                if sys.platform == "darwin":
                    # The broker verified the signed host immediately before
                    # launchd started it. This worker still needs the real OS
                    # sandbox probe, not another assessment of its running host.
                    from meshia_node.native_execution import _macos_probe
                    ready, reason = _macos_probe()
                    if not ready:
                        raise AccessRefused(reason)
                elif not available():
                    raise AccessRefused(detail())
                environment = _workspace_environment(environment, boundary.root)
                stage = [console_python(), "-I", "-c", _EXECUTE_STAGE, *argv]
                if sys.platform == "linux":
                    from meshia_node import linux_native
                    linux_native.launch(stage, workspace=boundary.root, cwd=directory, env=environment)
                    raise RuntimeError("Linux native launcher unexpectedly returned")
                command = ["/usr/bin/sandbox-exec", "-p",
                           _macos_profile(str(boundary.root), runtime_read_roots()), "--", *stage]
            else:
                command = None
    os.chdir(directory)
    if command is not None:
        os.execvpe(command[0], command, env=environment)
    else:
        sys.argv = ["meshia-native-command", *argv]
        exec(_EXECUTE_STAGE, {"__name__": "__main__"})


def main() -> int:
    if len(sys.argv) == 3 and sys.argv[1] == "--workspace-read-probe":
        try:
            probe_workspace_read(sys.argv[2])
            _workspace_read_phase("complete")
            return 0
        except Exception as error:
            # Probe errors may include a private path. Only errno categories
            # cross this capture channel; normal command errors are unchanged.
            import errno
            seen = set()
            denied = False
            while error is not None and id(error) not in seen:
                seen.add(id(error))
                denied = denied or (isinstance(error, OSError) and error.errno in (errno.EACCES, errno.EPERM))
                error = error.__cause__ or error.__context__
            try:
                os.write(2, b"MESHIA_READ_ERROR:denied\n" if denied else b"MESHIA_READ_ERROR:unavailable\n")
            except OSError:
                pass
            return 70
    try:
        setup = json.loads(sys.argv[1])
        observer_fd = setup.pop("_app_owner_fd", None)
        if observer_fd is not None and (type(observer_fd) is not int or observer_fd < 3
                                        or sys.platform != "darwin"):
            raise ValueError("Invalid native app ownership observer")
        if sys.platform == "darwin":
            from meshia_node.macos_native import supervise
            return supervise(sys.argv[2:], setup,
                             **({"observer_fd": observer_fd} if observer_fd is not None else {}))
        if sys.platform == "linux" and setup.get("access") == "full":
            from meshia_node.linux_native import supervise
            return supervise(lambda: launch(sys.argv[2:], **setup))
        launch(sys.argv[2:], **setup)
    except Exception as error:
        print(f"Native command startup failed: {error}", file=sys.stderr)
        return 70
    return 0  # exec replaces the helper; retained for Windows implementations.


if __name__ == "__main__":
    # -I prevents workspace/PYTHONPATH module injection. Use this installed
    # helper's own package location, including isolated source acceptance.
    sys.path.insert(0, str(Path(__file__).absolute().parent.parent))
    raise SystemExit(main())
