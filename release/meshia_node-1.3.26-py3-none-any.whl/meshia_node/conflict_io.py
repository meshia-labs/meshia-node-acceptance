"""Bounded, fail-closed I/O for human-directed Fabric conflict recovery.

This module deliberately knows nothing about conflict database state or remote
resolution.  It proves one local byte source, copies it without aggregating the
file in memory, and publishes exports with create-if-absent semantics.  A caller
must establish that the conflict belongs to the active authority before passing
an active :class:`~meshia_node.workspace.WorkspaceBoundary` as fallback.
"""

from __future__ import annotations

import errno
import hashlib
import json
import os
import stat as stat_module
import sys
import unicodedata
import uuid
from contextlib import AbstractContextManager, contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator, Literal

from .errors import InvalidTask, UnsafePath
from .util import RAW_SHA256_RE
from .workspace import (
    MAX_PATH_BYTES,
    MAX_PATH_UTF16_UNITS,
    MAX_STREAM_FILE_BYTES,
    STREAM_IO_BYTES,
    FileFingerprint,
    HashedRegularFile,
    WorkspaceBoundary,
    _copy_hash_open_regular,
    split_relative,
)


_O_BINARY = getattr(os, "O_BINARY", 0)
_O_CLOEXEC = getattr(os, "O_CLOEXEC", 0)
_O_DIRECTORY = getattr(os, "O_DIRECTORY", 0)
_O_NOINHERIT = getattr(os, "O_NOINHERIT", 0)
_O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_O_NONBLOCK = getattr(os, "O_NONBLOCK", 0)
_REPARSE_POINT = getattr(stat_module, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
_EXPORT_TEMP_PREFIX = ".meshia-conflict-export-"
_MAX_IDENTITY_BYTES = 512
_MAX_KEEP_BOTH_CANDIDATE = 1_000_000
_MAX_PRESERVED_EXTENSION_BYTES = 32


@dataclass(frozen=True, slots=True)
class VerifiedConflictCopy:
    """The exact local bytes copied for one active conflict."""

    source: Literal["stage", "workspace"]
    fingerprint: FileFingerprint
    hashed: HashedRegularFile | None

    @property
    def sha256(self) -> str | None:
        return self.hashed.sha256 if self.hashed is not None else None

    @property
    def size_bytes(self) -> int:
        return self.fingerprint.size_bytes


def decode_conflict_fingerprint(value: str) -> FileFingerprint:
    """Decode one bounded durable local identity without treating it as a digest."""

    if not isinstance(value, str) or not value or len(value.encode("utf-8")) > 4_096:
        raise ValueError("expected_fingerprint must be bounded JSON")
    try:
        raw = json.loads(value)
        fingerprint = FileFingerprint(
            size_bytes=int(raw["size_bytes"]),
            mtime_ns=int(raw["mtime_ns"]),
            ctime_ns=int(raw["ctime_ns"]),
            device_id=int(raw["device_id"]),
            file_id=int(raw["file_id"]),
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise ValueError("expected_fingerprint is invalid") from error
    if min(
        fingerprint.size_bytes,
        fingerprint.mtime_ns,
        fingerprint.ctime_ns,
        fingerprint.device_id,
        fingerprint.file_id,
    ) < 0 or fingerprint.size_bytes > MAX_STREAM_FILE_BYTES:
        raise ValueError("expected_fingerprint is invalid")
    return fingerprint


def _is_reparse(info: os.stat_result) -> bool:
    return stat_module.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & _REPARSE_POINT
    )


def _same_identity(left: os.stat_result, right: os.stat_result) -> bool:
    return int(left.st_dev) == int(right.st_dev) and int(left.st_ino) == int(
        right.st_ino
    )


def _require_real_directory(info: os.stat_result, label: str) -> None:
    if _is_reparse(info) or not stat_module.S_ISDIR(info.st_mode):
        raise UnsafePath(f"{label} must be a real directory.")


def _require_private_regular(info: os.stat_result, label: str) -> None:
    if (
        _is_reparse(info)
        or not stat_module.S_ISREG(info.st_mode)
        or int(info.st_nlink) != 1
    ):
        raise UnsafePath(f"{label} must be a single-link regular file.")


def _digest(value: str) -> str:
    if not isinstance(value, str) or RAW_SHA256_RE.fullmatch(value) is None:
        raise ValueError("expected_sha256 must be a lowercase raw SHA-256 digest")
    return value


def _optional_size(value: int | None) -> int | None:
    if value is None:
        return None
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not 0 <= value <= MAX_STREAM_FILE_BYTES
    ):
        raise ValueError("expected_size must be between 0 bytes and 1 TiB")
    return value


def _stream_bounds(max_bytes: int, chunk_bytes: int) -> tuple[int, int]:
    if (
        isinstance(max_bytes, bool)
        or not isinstance(max_bytes, int)
        or not 0 <= max_bytes <= MAX_STREAM_FILE_BYTES
    ):
        raise ValueError("max_bytes must be between 0 bytes and 1 TiB")
    if (
        isinstance(chunk_bytes, bool)
        or not isinstance(chunk_bytes, int)
        or not 1 <= chunk_bytes <= 4 * 1024 * 1024
    ):
        raise ValueError("chunk_bytes must be between 1 byte and 4 MiB")
    return max_bytes, chunk_bytes


def _absolute_path(value: Path | str, label: str) -> str:
    try:
        raw = os.fspath(Path(value).expanduser())
    except (TypeError, ValueError, RuntimeError) as error:
        raise UnsafePath(f"{label} is invalid.") from error
    if not isinstance(raw, str) or not raw or "\0" in raw:
        raise UnsafePath(f"{label} is invalid.")
    return os.path.abspath(raw)


def _stage_parts(
    stage_path: Path | str, staging_root: Path | str
) -> tuple[str, list[str]]:
    root = _absolute_path(staging_root, "The staging root")
    stage = _absolute_path(stage_path, "The recorded stage path")
    try:
        relative = os.path.relpath(stage, root)
        common = os.path.commonpath((os.path.normcase(root), os.path.normcase(stage)))
    except ValueError as error:
        raise UnsafePath("The recorded stage path is outside the staging root.") from error
    if common != os.path.normcase(root):
        raise UnsafePath("The recorded stage path is outside the staging root.")
    parts = relative.split(os.sep)
    if relative in ("", ".") or any(part in ("", ".", "..") for part in parts):
        raise UnsafePath("The recorded stage path is outside the staging root.")
    return root, parts


@contextmanager
def _open_posix_private_stage(
    stage_path: Path | str, staging_root: Path | str
) -> Iterator[tuple[int, os.stat_result, Callable[[], None]]]:
    root, parts = _stage_parts(stage_path, staging_root)
    root_fd = -1
    parent_fd = -1
    descriptor = -1
    try:
        root_fd = os.open(
            root,
            os.O_RDONLY | _O_DIRECTORY | _O_NOFOLLOW | _O_CLOEXEC,
        )
        _require_real_directory(os.fstat(root_fd), "The staging root")
        parent_fd = root_fd
        root_fd = -1
        for component in parts[:-1]:
            next_fd = os.open(
                component,
                os.O_RDONLY | _O_DIRECTORY | _O_NOFOLLOW | _O_CLOEXEC,
                dir_fd=parent_fd,
            )
            try:
                _require_real_directory(
                    os.fstat(next_fd), "A staging path component"
                )
            except BaseException:
                os.close(next_fd)
                raise
            os.close(parent_fd)
            parent_fd = next_fd

        name = parts[-1]
        before = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        _require_private_regular(before, "The recorded stage")
        descriptor = os.open(
            name,
            os.O_RDONLY
            | _O_NOFOLLOW
            | _O_CLOEXEC
            | _O_NONBLOCK
            | _O_BINARY,
            dir_fd=parent_fd,
        )
        opened = os.fstat(descriptor)
        _require_private_regular(opened, "The recorded stage")
        if not _same_identity(before, opened):
            raise InvalidTask("The recorded stage changed while it was being opened.")

        def verify_current() -> None:
            current = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
            _require_private_regular(current, "The recorded stage")
            if not _same_identity(opened, current):
                raise InvalidTask("The recorded stage changed while it was being copied.")

        yield descriptor, opened, verify_current
    except OSError as error:
        raise UnsafePath("The recorded stage cannot be opened safely.") from error
    finally:
        if descriptor >= 0:
            os.close(descriptor)
        if parent_fd >= 0:
            os.close(parent_fd)
        if root_fd >= 0:
            os.close(root_fd)


@contextmanager
def _open_windows_private_stage(
    stage_path: Path | str, staging_root: Path | str
) -> Iterator[tuple[int, os.stat_result, Callable[[], None]]]:
    root, parts = _stage_parts(stage_path, staging_root)
    stage = os.path.join(root, *parts)
    descriptor = -1
    try:
        root_info = os.lstat(root)
        _require_real_directory(root_info, "The staging root")
        current = root
        for component in parts[:-1]:
            current = os.path.join(current, component)
            _require_real_directory(
                os.lstat(current), "A staging path component"
            )
        before = os.lstat(stage)
        _require_private_regular(before, "The recorded stage")
        canonical_root = os.path.normcase(os.path.realpath(root))
        canonical_stage = os.path.normcase(os.path.realpath(stage))
        try:
            if os.path.commonpath((canonical_root, canonical_stage)) != canonical_root:
                raise UnsafePath(
                    "The recorded stage path is outside the staging root."
                )
        except ValueError as error:
            raise UnsafePath(
                "The recorded stage path is outside the staging root."
            ) from error
        descriptor = os.open(
            stage,
            os.O_RDONLY | _O_BINARY | _O_NOINHERIT,
        )
        opened = os.fstat(descriptor)
        _require_private_regular(opened, "The recorded stage")
        if not _same_identity(before, opened):
            raise InvalidTask("The recorded stage changed while it was being opened.")

        def verify_current() -> None:
            current_info = os.lstat(stage)
            _require_private_regular(current_info, "The recorded stage")
            if not _same_identity(opened, current_info):
                raise InvalidTask("The recorded stage changed while it was being copied.")
            root_current = os.lstat(root)
            _require_real_directory(root_current, "The staging root")
            if not _same_identity(root_info, root_current):
                raise InvalidTask("The staging root changed while bytes were copied.")

        yield descriptor, opened, verify_current
    except OSError as error:
        raise UnsafePath("The recorded stage cannot be opened safely.") from error
    finally:
        if descriptor >= 0:
            os.close(descriptor)


def _open_private_stage(
    stage_path: Path | str, staging_root: Path | str
) -> AbstractContextManager[
    tuple[int, os.stat_result, Callable[[], None]]
]:
    if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
        return _open_windows_private_stage(stage_path, staging_root)
    return _open_posix_private_stage(stage_path, staging_root)


def _require_empty_destination(descriptor: int) -> None:
    if isinstance(descriptor, bool) or not isinstance(descriptor, int) or descriptor < 0:
        raise ValueError("destination_fd must be an open file descriptor")
    try:
        info = os.fstat(descriptor)
        offset = os.lseek(descriptor, 0, os.SEEK_CUR)
    except OSError as error:
        raise InvalidTask("The conflict-copy destination is not seekable.") from error
    if (
        not stat_module.S_ISREG(info.st_mode)
        or int(info.st_nlink) != 1
        or int(info.st_size) != 0
        or offset != 0
    ):
        raise InvalidTask(
            "The conflict-copy destination must be a new empty single-link file."
        )


def copy_verified_private_stage_to_descriptor(
    stage_path: Path | str,
    destination_fd: int,
    *,
    staging_root: Path | str,
    expected_sha256: str,
    expected_size: int | None = None,
    max_bytes: int = MAX_STREAM_FILE_BYTES,
    chunk_bytes: int = STREAM_IO_BYTES,
) -> HashedRegularFile:
    """Copy and verify one private stage without following a link.

    ``destination_fd`` must name a caller-owned, empty, single-link regular
    file.  On an integrity failure it can contain unpublished partial bytes;
    ownership and cleanup remain with the caller.
    """

    expected_sha256 = _digest(expected_sha256)
    expected_size = _optional_size(expected_size)
    max_bytes, chunk_bytes = _stream_bounds(max_bytes, chunk_bytes)
    _require_empty_destination(destination_fd)
    with _open_private_stage(stage_path, staging_root) as opened:
        source_fd, source_info, verify_current = opened
        if expected_size is not None and int(source_info.st_size) != expected_size:
            raise InvalidTask("The recorded stage size does not match the conflict.")
        hashed = _copy_hash_open_regular(
            source_fd,
            destination_fd,
            max_bytes,
            chunk_bytes,
            None,
        )
        verify_current()
    if expected_size is not None and hashed.fingerprint.size_bytes != expected_size:
        raise InvalidTask("The recorded stage size does not match the conflict.")
    if hashed.sha256 != expected_sha256:
        raise InvalidTask("The recorded stage digest does not match the conflict.")
    return hashed


def _rewind_empty_destination(descriptor: int) -> None:
    os.ftruncate(descriptor, 0)
    os.lseek(descriptor, 0, os.SEEK_SET)


def copy_active_conflict_local_to_descriptor(
    workspace: WorkspaceBoundary,
    workspace_path: str,
    destination_fd: int,
    *,
    staging_root: Path | str,
    staged_path: Path | str | None,
    expected_sha256: str | None = None,
    expected_fingerprint: str | None = None,
    expected_size: int | None = None,
    max_bytes: int = MAX_STREAM_FILE_BYTES,
    chunk_bytes: int = STREAM_IO_BYTES,
) -> VerifiedConflictCopy:
    """Copy exact local conflict bytes, preferring recorded private evidence.

    An unsafe, missing, or corrupt recorded stage is never consumed.  The sole
    fallback is the supplied *active* workspace boundary, and those visible
    bytes must independently match the conflict digest and optional size.
    """

    if (expected_sha256 is None) == (expected_fingerprint is None):
        raise ValueError(
            "exactly one of expected_sha256 or expected_fingerprint is required"
        )
    decoded_fingerprint = (
        decode_conflict_fingerprint(expected_fingerprint)
        if expected_fingerprint is not None
        else None
    )
    if expected_sha256 is not None:
        expected_sha256 = _digest(expected_sha256)
    expected_size = _optional_size(expected_size)
    max_bytes, chunk_bytes = _stream_bounds(max_bytes, chunk_bytes)
    _require_empty_destination(destination_fd)
    stage_error: BaseException | None = None
    if staged_path is not None and expected_sha256 is not None:
        try:
            hashed = copy_verified_private_stage_to_descriptor(
                staged_path,
                destination_fd,
                staging_root=staging_root,
                expected_sha256=expected_sha256,
                expected_size=expected_size,
                max_bytes=max_bytes,
                chunk_bytes=chunk_bytes,
            )
            return VerifiedConflictCopy(
                source="stage", fingerprint=hashed.fingerprint, hashed=hashed
            )
        except (InvalidTask, UnsafePath, OSError, ValueError) as error:
            stage_error = error
            _rewind_empty_destination(destination_fd)

    try:
        if decoded_fingerprint is not None:
            copied_fingerprint = workspace.copy_regular_file_identity_to_descriptor(
                workspace_path,
                destination_fd,
                expected_fingerprint=decoded_fingerprint,
                max_bytes=max_bytes,
                chunk_bytes=chunk_bytes,
            )
            hashed = None
        else:
            copied_fingerprint = None
            hashed = workspace.copy_regular_file_to_descriptor(
                workspace_path,
                destination_fd,
                max_bytes=max_bytes,
                chunk_bytes=chunk_bytes,
            )
    except (InvalidTask, UnsafePath, OSError) as error:
        raise InvalidTask(
            "No exact local bytes are available for the active conflict."
        ) from error
    if hashed is None and copied_fingerprint is None:
        raise InvalidTask(
            "No exact local bytes are available for the active conflict."
        ) from stage_error
    actual_fingerprint = (
        hashed.fingerprint if hashed is not None else copied_fingerprint
    )
    assert actual_fingerprint is not None
    if expected_size is not None and actual_fingerprint.size_bytes != expected_size:
        raise InvalidTask("The active workspace file size no longer matches the conflict.")
    if expected_sha256 is not None and (
        hashed is None or hashed.sha256 != expected_sha256
    ):
        raise InvalidTask("The active workspace file digest no longer matches the conflict.")
    return VerifiedConflictCopy(
        source="workspace", fingerprint=actual_fingerprint, hashed=hashed
    )


def _fsync_directory_descriptor(descriptor: int) -> None:
    try:
        os.fsync(descriptor)
    except OSError as error:
        unsupported = {
            errno.EINVAL,
            getattr(errno, "ENOTSUP", errno.EINVAL),
            getattr(errno, "EOPNOTSUPP", errno.EINVAL),
        }
        if error.errno not in unsupported:
            raise


def _export_posix(
    destination: str,
    copier: Callable[[int], VerifiedConflictCopy],
) -> VerifiedConflictCopy:
    parent = os.path.dirname(destination)
    name = os.path.basename(destination)
    parent_fd = os.open(
        parent,
        os.O_RDONLY | _O_DIRECTORY | _O_NOFOLLOW | _O_CLOEXEC,
    )
    temporary = f"{_EXPORT_TEMP_PREFIX}{uuid.uuid4().hex}.tmp"
    descriptor = -1
    published = False
    try:
        _require_real_directory(os.fstat(parent_fd), "The export parent")
        descriptor = os.open(
            temporary,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_CLOEXEC,
            0o600,
            dir_fd=parent_fd,
        )
        os.fchmod(descriptor, 0o600)
        result = copier(descriptor)
        os.fsync(descriptor)
        os.close(descriptor)
        descriptor = -1
        os.link(
            temporary,
            name,
            src_dir_fd=parent_fd,
            dst_dir_fd=parent_fd,
            follow_symlinks=False,
        )
        published = True
        os.unlink(temporary, dir_fd=parent_fd)
        _fsync_directory_descriptor(parent_fd)
        return result
    finally:
        if descriptor >= 0:
            os.close(descriptor)
        if not published:
            try:
                os.unlink(temporary, dir_fd=parent_fd)
            except OSError:
                pass
        os.close(parent_fd)


def _export_windows(
    destination: str,
    copier: Callable[[int], VerifiedConflictCopy],
) -> VerifiedConflictCopy:
    parent = os.path.dirname(destination)
    parent_before = os.lstat(parent)
    _require_real_directory(parent_before, "The export parent")
    temporary = os.path.join(
        parent, f"{_EXPORT_TEMP_PREFIX}{uuid.uuid4().hex}.tmp"
    )
    descriptor = -1
    published = False
    try:
        descriptor = os.open(
            temporary,
            os.O_WRONLY
            | os.O_CREAT
            | os.O_EXCL
            | _O_BINARY
            | _O_NOINHERIT,
            0o600,
        )
        result = copier(descriptor)
        os.fsync(descriptor)
        os.close(descriptor)
        descriptor = -1
        parent_current = os.lstat(parent)
        _require_real_directory(parent_current, "The export parent")
        if not _same_identity(parent_before, parent_current):
            raise InvalidTask("The export parent changed while bytes were copied.")
        if sys.platform == "win32":  # os.rename is no-clobber on Windows
            os.rename(temporary, destination)
        else:  # keeps platform-neutral Windows-path tests no-clobbering on POSIX
            os.link(temporary, destination, follow_symlinks=False)
            os.unlink(temporary)
        published = True
        return result
    finally:
        if descriptor >= 0:
            os.close(descriptor)
        if not published:
            try:
                os.unlink(temporary)
            except OSError:
                pass


def export_active_conflict_local(
    workspace: WorkspaceBoundary,
    workspace_path: str,
    destination: Path | str,
    *,
    staging_root: Path | str,
    staged_path: Path | str | None,
    expected_sha256: str | None = None,
    expected_fingerprint: str | None = None,
    expected_size: int | None = None,
    max_bytes: int = MAX_STREAM_FILE_BYTES,
    chunk_bytes: int = STREAM_IO_BYTES,
) -> VerifiedConflictCopy:
    """Verify and publish one conflict's local bytes without overwriting.

    The final destination is linked/renamed into place only after the complete
    temporary file has matched the conflict digest and optional size and has
    been flushed.  Integrity failures therefore cannot expose a final file.
    """

    target = _absolute_path(destination, "The export destination")
    if os.path.basename(target) in ("", ".", ".."):
        raise UnsafePath("The export destination must name a new file.")

    def copier(descriptor: int) -> VerifiedConflictCopy:
        return copy_active_conflict_local_to_descriptor(
            workspace,
            workspace_path,
            descriptor,
            staging_root=staging_root,
            staged_path=staged_path,
            expected_sha256=expected_sha256,
            expected_fingerprint=expected_fingerprint,
            expected_size=expected_size,
            max_bytes=max_bytes,
            chunk_bytes=chunk_bytes,
        )

    if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
        return _export_windows(target, copier)
    return _export_posix(target, copier)


def _utf16_units(value: str) -> int:
    try:
        return len(value.encode("utf-16-le")) // 2
    except UnicodeEncodeError as error:
        raise UnsafePath("Conflict paths must contain valid Unicode text.") from error


def _bounded_prefix(value: str, *, byte_limit: int, utf16_limit: int) -> str:
    prefix = value
    while prefix and (
        len(prefix.encode("utf-8")) > byte_limit
        or _utf16_units(prefix) > utf16_limit
    ):
        prefix = prefix[:-1]
    return prefix.rstrip(" .")


def keep_both_candidate_path(
    original_path: str,
    conflict_id: int,
    resolution_id: str,
    *,
    candidate: int = 0,
) -> str:
    """Return one deterministic portable adjacent path for ``keep-both``.

    The caller owns the bounded collision loop and passes successive candidate
    indexes; this function never probes or mutates the workspace namespace.
    """

    parts = split_relative(original_path)
    if (
        isinstance(conflict_id, bool)
        or not isinstance(conflict_id, int)
        or not 1 <= conflict_id <= (1 << 63) - 1
    ):
        raise ValueError("conflict_id must be a positive signed 64-bit integer")
    if (
        not isinstance(resolution_id, str)
        or not resolution_id
        or resolution_id != resolution_id.strip()
        or "\0" in resolution_id
        or len(resolution_id.encode("utf-8")) > _MAX_IDENTITY_BYTES
    ):
        raise ValueError("resolution_id must be a bounded non-empty identifier")
    if (
        isinstance(candidate, bool)
        or not isinstance(candidate, int)
        or not 0 <= candidate <= _MAX_KEEP_BOTH_CANDIDATE
    ):
        raise ValueError(
            f"candidate must be between 0 and {_MAX_KEEP_BOTH_CANDIDATE}"
        )

    original_name = parts[-1]
    dot = original_name.rfind(".")
    extension = original_name[dot:] if 0 < dot < len(original_name) - 1 else ""
    if len(extension.encode("utf-8")) > _MAX_PRESERVED_EXTENSION_BYTES:
        extension = ""
        stem = original_name
    else:
        stem = original_name[:dot] if extension else original_name
    identity = hashlib.sha256(
        f"{conflict_id}\0{resolution_id}\0{candidate}".encode("utf-8")
    ).hexdigest()[:16]
    suffix = f" (Meshia conflict {conflict_id}-{identity})"

    parent = "/".join(parts[:-1])
    parent_bytes = len(parent.encode("utf-8")) + (1 if parent else 0)
    parent_utf16 = _utf16_units(parent) + (1 if parent else 0)
    component_bytes = min(255, MAX_PATH_BYTES - parent_bytes)
    component_utf16 = MAX_PATH_UTF16_UNITS - parent_utf16
    fixed = suffix + extension
    prefix_bytes = component_bytes - len(fixed.encode("utf-8"))
    prefix_utf16 = component_utf16 - _utf16_units(fixed)
    if prefix_bytes < 1 or prefix_utf16 < 1:
        raise InvalidTask("The original path leaves no room for a keep-both name.")
    bounded_stem = _bounded_prefix(
        stem, byte_limit=prefix_bytes, utf16_limit=prefix_utf16
    )
    if not bounded_stem:
        bounded_stem = "file"
        if (
            len(bounded_stem.encode("utf-8")) > prefix_bytes
            or _utf16_units(bounded_stem) > prefix_utf16
        ):
            raise InvalidTask("The original path leaves no room for a keep-both name.")
    component = unicodedata.normalize("NFC", f"{bounded_stem}{fixed}")
    result = f"{parent}/{component}" if parent else component
    # This is the final proof for Windows devices, reserved stems, trailing
    # spaces/dots, total UTF-8/UTF-16 bounds, and the public Fabric namespace.
    split_relative(result)
    return result
