"""Bounded, crash-safe byte staging primitives for MeshiaFabric.

This module is deliberately below the signed Fabric control plane.  It only
assembles already-authorized remote blocks or snapshots one local regular file
into a private stage.  It never publishes a mutation and never changes the
workspace namespace.  A caller receives :class:`VerifiedStage` only after the
private file has been flushed, re-read, and verified.

The on-disk intent and progress records are hints, not integrity authorities.
Every reopen re-hashes the completed staged prefix (and, for an unfinished
local snapshot, revalidates the source identity) before accepting progress.
"""

from __future__ import annotations

import hashlib
import bisect
import json
import os
import queue
import re
import shutil
import stat
import threading
import time
import uuid
import weakref
from contextlib import contextmanager
from concurrent.futures import Future
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Mapping, Protocol, Sequence

from .config import file_lock
from .fabric_contract_generated import (
    FABRIC_BLOCK_FILE_DIGEST_ALGORITHM,
    FABRIC_EMPTY_SHA256,
    block_file_sha256,
)
from .fabric_staging import (
    StagingAdmissionExceeded,
    StagingAdmissionLedger,
    StagingLedgerError,
    StagingRepairRequired,
    StagingReservation,
)
from .util import RAW_SHA256_RE, directory_entry_identity_stat, ensure_private_dir

BLOCK_BYTES = 4 * 1024 * 1024
MAX_BLOCKS = 8_192
MAX_FILE_BYTES = BLOCK_BYTES * MAX_BLOCKS
# Concurrency for direct block reads. Measured against the live provider on
# 2026-08-31 with 4 MiB ranges: 1 stream = 13.6 MB/s, 4 = 56.8, 8 = 62.8,
# 16 = 42.9 (over-subscribed). Eight is the measured optimum; the resident
# bound stays modest at MAX_BATCH_BYTES = 8 x 4 MiB = 32 MiB, well inside the
# 128 MiB upload payload budget.
MAX_BATCH_BLOCKS = 8
MAX_BATCH_BYTES = BLOCK_BYTES * MAX_BATCH_BLOCKS
# One direct read task is one immutable CAS block. The write lane sizes blocks
# adaptively up to 64 MiB (a 512 MiB file ships as 32 x 16 MiB), so the read
# lane must accept what the write lane produces; a 4 MiB task cap made every
# such file unreadable anywhere but the machine that wrote it (2026-09-02).
MAX_DIRECT_TASK_BYTES = 64 * 1024 * 1024
DEFAULT_MAX_STAGING_BYTES = 8 * 1024 * 1024 * 1024
DEFAULT_MIN_FREE_BYTES = 512 * 1024 * 1024
# Transfer reservations already include the complete incoming high-water mark.
# A volume-relative reserve would unnecessarily strand tens of GiB on modern
# workstation disks, so the default cushion is the fixed bound above.
DEFAULT_MIN_FREE_FRACTION = 0.0
DEFAULT_MAX_JOBS = 256
MAX_INTENT_BYTES = 2 * 1024 * 1024
MAX_PROGRESS_BYTES = 2 * 1024 * 1024
MAX_RESERVATION_BYTES = 1024
MAX_ERROR_BYTES = 4 * 1024

REMOTE_INTENT_SCHEMA = "meshia.fabric.remote_transfer_intent.v1"
LOCAL_INTENT_SCHEMA = "meshia.fabric.local_snapshot_intent.v1"
PROGRESS_SCHEMA = "meshia.fabric.transfer_progress.v1"
RESERVATION_SCHEMA = "meshia.fabric.transfer_reservation.v1"

_JOB_KEY_RE = re.compile(r"^[a-f0-9]{64}$")
_TEMP_JOB_RE = re.compile(r"^\.[a-f0-9]{64}\.[a-f0-9]{32}\.tmp$")
_TEMP_METADATA_RE = re.compile(
    r"^\.(?:intent|reservation|progress)\.json\.[a-f0-9]{32}\.tmp$"
)
_O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_O_BINARY = getattr(os, "O_BINARY", 0)
_O_DIRECTORY = getattr(os, "O_DIRECTORY", 0)
_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)

# ``flock`` behavior for independently opened descriptors in one process is
# not identical on every supported POSIX implementation. Share an in-process
# lock by canonical transfer root as well as taking the durable file lock.
_PROCESS_RESERVATION_LOCKS_GUARD = threading.Lock()
_PROCESS_RESERVATION_LOCKS: weakref.WeakValueDictionary[str, Any] = (
    weakref.WeakValueDictionary()
)

__all__ = (
    "BLOCK_BYTES",
    "MAX_BLOCKS",
    "MAX_FILE_BYTES",
    "MAX_BATCH_BLOCKS",
    "MAX_BATCH_BYTES",
    "TransferError",
    "TransferBusy",
    "TransferIntegrityError",
    "UnsafeTransferPath",
    "StagingQuotaExceeded",
    "SourceDrift",
    "RecoveryDeferred",
    "BlockSpec",
    "ReceivedBlock",
    "SourceFingerprint",
    "VerifiedStage",
    "RecoveryReport",
    "RemoteFinalizationCandidate",
    "LocalRecoveryCandidate",
    "DirectByteTask",
    "VerifiedDirectBlock",
    "DirectBatchResult",
    "LocalBlockSource",
    "AnchoredLocalSource",
    "build_block_specs",
    "TransferStore",
    "RemoteAssemblyJob",
    "LocalSnapshotJob",
    "LocalCopyWorker",
    "DirectByteWorkerPool",
)


class TransferError(RuntimeError):
    """Base error for a bounded transfer."""


class TransferBusy(TransferError):
    """The path or serial worker already has an active job."""


class TransferIntegrityError(TransferError):
    """Bytes or durable metadata failed an integrity check."""


class UnsafeTransferPath(TransferError):
    """A source or private stage is not a single-link regular file."""


class StagingQuotaExceeded(TransferError):
    """The declared stage or current free-space reserve is not affordable."""


class SourceDrift(TransferError):
    """A local source changed while its private snapshot was being copied."""


class RecoveryDeferred(TransferError):
    """Synchronous reopen would exceed its byte budget; use ``open_async``."""

    def __init__(self, logical_path: str, durable_bytes: int, budget_bytes: int) -> None:
        super().__init__(
            f"reopening {logical_path} requires verifying {durable_bytes} bytes "
            f"outside the {budget_bytes}-byte synchronous budget"
        )
        self.logical_path = logical_path
        self.durable_bytes = durable_bytes
        self.budget_bytes = budget_bytes


@dataclass(frozen=True)
class BlockSpec:
    index: int
    offset_bytes: int
    size_bytes: int
    sha256: str


@dataclass(frozen=True)
class ReceivedBlock:
    index: int
    offset_bytes: int
    size_bytes: int
    sha256: str
    data: bytes


@dataclass(frozen=True)
class SourceFingerprint:
    device: int
    inode: int
    size_bytes: int
    modified_ns: int
    changed_ns: int


@dataclass(frozen=True)
class VerifiedStage:
    """A private verified file; possession does not authorize publication."""

    transfer_id: str
    token: str
    kind: str
    logical_path: str
    path: Path
    size_bytes: int
    sha256: str
    # Remote identity is separate from the checksum of the assembled bytes.
    file_digest: str | None = None


@dataclass(frozen=True)
class RecoveryReport:
    inspected: int
    reopened: int
    quarantined: int
    more_remaining: bool
    verified_bytes: int = 0
    deferred: int = 0


@dataclass(frozen=True)
class RemoteFinalizationCandidate:
    """One bounded remote stage eligible for coordinator-owned cleanup."""

    job_key: str
    logical_path: str
    final_path: str
    transfer_id: str
    token: str | None
    state: str
    size_bytes: int
    sha256: str | None
    file_digest: str


def _remote_file_digest(intent: Mapping[str, Any]) -> str:
    algorithm = intent.get("file_digest_algorithm", "sha256")
    if algorithm == "sha256":
        return _digest(intent.get("sha256"))
    if algorithm != FABRIC_BLOCK_FILE_DIGEST_ALGORITHM or intent.get("sha256") is not None:
        raise TransferIntegrityError("remote file digest algorithm is invalid")
    digest = _digest(intent.get("file_digest"))
    blocks = intent.get("blocks")
    if not isinstance(blocks, list):
        raise TransferIntegrityError("remote block manifest is invalid")
    descriptor = {
        "version": 1, "algorithm": "sha256",
        "total_bytes": intent.get("size_bytes"),
        "block_count": len(blocks) if blocks else 1,
        "blocks": blocks or [{"index": 0, "offset_bytes": 0, "size_bytes": 0,
                              "sha256": FABRIC_EMPTY_SHA256}],
    }
    try:
        if block_file_sha256(descriptor) != digest:
            raise ValueError("root mismatch")
    except (ValueError, TypeError) as error:
        raise TransferIntegrityError("remote block identity is invalid") from error
    return digest


@dataclass(frozen=True)
class LocalRecoveryCandidate:
    """One complete local snapshot awaiting a durable coordinator owner."""

    job_key: str
    logical_path: str
    transfer_id: str
    token: str
    state: str
    source_id: str
    source_fingerprint: SourceFingerprint
    size_bytes: int
    sha256: str
    stage_path: Path


@dataclass(frozen=True)
class DirectByteTask:
    """One direct data-plane read. ``read`` must not make signed control calls."""

    block: BlockSpec
    read: Callable[[], bytes]


@dataclass(frozen=True)
class VerifiedDirectBlock:
    block: BlockSpec
    data: bytes


@dataclass(frozen=True)
class DirectBatchResult:
    completed: tuple[VerifiedDirectBlock, ...]
    failures: Mapping[int, str]
    timed_out: tuple[int, ...]
    unstarted: tuple[int, ...]


QuotaHook = Callable[[str, int, int], None]


class LocalBlockSource(Protocol):
    """A caller-owned, anchored local source seam.

    Integrations must implement these operations through ``WorkspaceBoundary``
    (or an equivalently pinned directory descriptor), never by concatenating an
    untrusted absolute path. ``read_block`` must re-check ``expected`` before
    returning exact bytes. The durable intent stores only ``source_id``.
    """

    source_id: str

    def fingerprint(self) -> SourceFingerprint: ...

    def read_block(
        self, offset_bytes: int, size_bytes: int, expected: SourceFingerprint
    ) -> bytes: ...


@dataclass(frozen=True)
class AnchoredLocalSource:
    """Small adapter for an anchored stat/range-read implementation."""

    source_id: str
    stat_source: Callable[[], SourceFingerprint]
    read_source_block: Callable[[int, int, SourceFingerprint], bytes]

    def fingerprint(self) -> SourceFingerprint:
        return self.stat_source()

    def read_block(
        self, offset_bytes: int, size_bytes: int, expected: SourceFingerprint
    ) -> bytes:
        return self.read_source_block(offset_bytes, size_bytes, expected)


SourceResolver = Callable[[str, str], LocalBlockSource | None]


def _logical_path(value: str) -> str:
    if not isinstance(value, str) or not value or len(value.encode("utf-8")) > 4096:
        raise ValueError("logical_path must be a non-empty UTF-8 path of at most 4096 bytes")
    if "\x00" in value or "\\" in value or value.startswith("/"):
        raise ValueError("logical_path must be a portable relative path")
    parts = value.split("/")
    if any(part in ("", ".", "..") for part in parts):
        raise ValueError("logical_path contains an unsafe component")
    return "/".join(parts)


def _digest(value: str, field: str = "sha256") -> str:
    if not isinstance(value, str) or RAW_SHA256_RE.fullmatch(value) is None:
        raise ValueError(f"{field} must be a lowercase raw SHA-256 digest")
    return value


def _job_key(logical_path: str) -> str:
    return hashlib.sha256(logical_path.encode("utf-8")).hexdigest()


def _shared_reservation_owner(transfer_id: str) -> str:
    """Identify one physical transfer, including quarantined generations.

    A logical path can have both preserved quarantine evidence and a new live
    job.  Charging by the path hash aliases those two physical directories and
    undercounts disk.  The immutable transfer UUID is recorded before either
    directory is published, survives quarantine renames, and is therefore the
    correct ledger identity.
    """

    try:
        normalized = str(uuid.UUID(transfer_id))
    except (AttributeError, TypeError, ValueError):
        raise TransferIntegrityError("transfer reservation identity is invalid") from None
    if normalized != transfer_id:
        raise TransferIntegrityError("transfer reservation identity is invalid")
    return f"transfer:{normalized}"


def _reservation_record(
    transfer_id: str, size_bytes: int, path_key: str
) -> dict[str, Any]:
    checksum = hashlib.sha256(
        f"{transfer_id}\x00{size_bytes}\x00{path_key}".encode("ascii")
    ).hexdigest()
    return {
        "schema": RESERVATION_SCHEMA,
        "transfer_id": transfer_id,
        "size_bytes": size_bytes,
        "path_key": path_key,
        "checksum": checksum,
    }


def _reservation_size(value: Mapping[str, Any], path_key: str) -> int:
    transfer_id = value.get("transfer_id")
    size = value.get("size_bytes")
    if (
        value.get("schema") != RESERVATION_SCHEMA
        or not isinstance(transfer_id, str)
        or isinstance(size, bool)
        or not isinstance(size, int)
        or not 0 <= size <= MAX_FILE_BYTES
        or value.get("path_key") != path_key
        or value != _reservation_record(transfer_id, size, path_key)
    ):
        raise TransferIntegrityError("transfer reservation is invalid")
    return size


def _is_reparse(info: os.stat_result) -> bool:
    return bool(getattr(info, "st_file_attributes", 0) & _REPARSE_POINT)


def _regular_single_link(info: os.stat_result, label: str) -> None:
    if not stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode) or _is_reparse(info):
        raise UnsafeTransferPath(f"{label} must be a regular non-link file")
    if info.st_nlink != 1:
        raise UnsafeTransferPath(f"{label} must have exactly one hard link")


def _allocated_regular_bytes(info: os.stat_result) -> int:
    """Return payload allocation already reflected by filesystem ``free``."""

    _regular_single_link(info, "staging payload")
    blocks = getattr(info, "st_blocks", None)
    if isinstance(blocks, int) and blocks >= 0:
        return min(int(info.st_size), blocks * 512)
    # Windows has no portable st_blocks. Keeping this at zero preserves the
    # conservative reservation instead of guessing physical allocation.
    return 0


def _fingerprint(info: os.stat_result) -> SourceFingerprint:
    return SourceFingerprint(
        device=int(info.st_dev),
        inode=int(info.st_ino),
        size_bytes=int(info.st_size),
        modified_ns=int(info.st_mtime_ns),
        changed_ns=int(info.st_ctime_ns),
    )


def _same_fingerprint(left: SourceFingerprint, right: SourceFingerprint) -> bool:
    return left == right


def _fp_json(value: SourceFingerprint) -> dict[str, int]:
    return {
        "device": value.device,
        "inode": value.inode,
        "size_bytes": value.size_bytes,
        "modified_ns": value.modified_ns,
        "changed_ns": value.changed_ns,
    }


def _fp_from_json(value: Any) -> SourceFingerprint:
    if not isinstance(value, dict):
        raise TransferIntegrityError("source fingerprint is not an object")
    fields = ("device", "inode", "size_bytes", "modified_ns", "changed_ns")
    if any(isinstance(value.get(name), bool) or not isinstance(value.get(name), int) for name in fields):
        raise TransferIntegrityError("source fingerprint contains an invalid field")
    return SourceFingerprint(*(int(value[name]) for name in fields))


def _checked_fingerprint(value: Any) -> SourceFingerprint:
    if not isinstance(value, SourceFingerprint):
        raise UnsafeTransferPath("anchored source returned an invalid fingerprint")
    if min(value.device, value.inode, value.size_bytes, value.modified_ns, value.changed_ns) < 0:
        raise UnsafeTransferPath("anchored source fingerprint contains a negative field")
    if value.size_bytes > MAX_FILE_BYTES:
        raise StagingQuotaExceeded("local source exceeds the 32 GiB transfer ceiling")
    return value


def _source_id(value: Any) -> str:
    if not isinstance(value, str) or not value or len(value.encode("utf-8")) > 512 or "\x00" in value:
        raise ValueError("source_id must be non-empty UTF-8 of at most 512 bytes")
    return value


def _shared_reservation_lock(root: Path) -> Any:
    key = str(root.resolve(strict=True))
    with _PROCESS_RESERVATION_LOCKS_GUARD:
        lock = _PROCESS_RESERVATION_LOCKS.get(key)
        if lock is None:
            lock = threading.RLock()
            _PROCESS_RESERVATION_LOCKS[key] = lock
        return lock


def _binding_json(info: os.stat_result) -> dict[str, int]:
    return {
        "device": int(info.st_dev),
        "inode": int(info.st_ino),
        "size_bytes": int(info.st_size),
        "modified_ns": int(info.st_mtime_ns),
        "changed_ns": int(info.st_ctime_ns),
    }


def _binding_matches(value: Any, info: os.stat_result) -> bool:
    return isinstance(value, dict) and value == _binding_json(info)


def _validate_file_shape(size_bytes: int, blocks: Sequence[BlockSpec]) -> tuple[BlockSpec, ...]:
    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or not 0 <= size_bytes <= MAX_FILE_BYTES:
        raise ValueError(f"size_bytes must be between 0 and {MAX_FILE_BYTES}")
    expected_count = (size_bytes + BLOCK_BYTES - 1) // BLOCK_BYTES
    if expected_count > MAX_BLOCKS or len(blocks) != expected_count:
        raise ValueError("block count does not exactly match the declared file size")
    checked: list[BlockSpec] = []
    for index, block in enumerate(blocks):
        expected_size = min(BLOCK_BYTES, size_bytes - index * BLOCK_BYTES)
        if (
            isinstance(block.index, bool)
            or block.index != index
            or block.offset_bytes != index * BLOCK_BYTES
            or block.size_bytes != expected_size
        ):
            raise ValueError("blocks must be contiguous fixed 4 MiB blocks with an exact final tail")
        _digest(block.sha256, "block sha256")
        checked.append(block)
    return tuple(checked)


def build_block_specs(size_bytes: int, digests: Iterable[str]) -> tuple[BlockSpec, ...]:
    """Build and validate a fixed-block manifest without allocating file bytes."""

    if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or not 0 <= size_bytes <= MAX_FILE_BYTES:
        raise ValueError(f"size_bytes must be between 0 and {MAX_FILE_BYTES}")
    expected = (size_bytes + BLOCK_BYTES - 1) // BLOCK_BYTES
    values: list[BlockSpec] = []
    for index, value in enumerate(digests):
        if index >= MAX_BLOCKS:
            raise ValueError("manifest exceeds 8192 blocks")
        values.append(
            BlockSpec(
                index=index,
                offset_bytes=index * BLOCK_BYTES,
                size_bytes=min(BLOCK_BYTES, size_bytes - index * BLOCK_BYTES),
                sha256=_digest(value, "block sha256"),
            )
        )
    if len(values) != expected:
        raise ValueError("digest count does not match size_bytes")
    return _validate_file_shape(size_bytes, values)


def _fsync_dir(path: Path) -> None:
    if not _O_DIRECTORY:
        return
    descriptor = os.open(str(path), os.O_RDONLY | _O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _atomic_json(path: Path, value: Mapping[str, Any], limit: int) -> None:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(payload) > limit:
        raise TransferIntegrityError(f"{path.name} exceeds its bounded metadata limit")
    temporary = path.parent / f".{path.name}.{uuid.uuid4().hex}.tmp"
    try:
        descriptor = os.open(
            str(temporary),
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_BINARY,
            0o600,
        )
        try:
            view = memoryview(payload)
            while view:
                written = os.write(descriptor, view)
                if written <= 0:
                    raise OSError("short metadata write")
                view = view[written:]
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    _fsync_dir(path.parent)


def _read_json(path: Path, limit: int) -> dict[str, Any]:
    descriptor = os.open(str(path), os.O_RDONLY | _O_NOFOLLOW | _O_BINARY)
    try:
        info = os.fstat(descriptor)
        _regular_single_link(info, path.name)
        if not 0 <= info.st_size <= limit:
            raise TransferIntegrityError(f"{path.name} exceeds its bounded metadata limit")
        data = bytearray()
        while len(data) < info.st_size:
            chunk = os.read(descriptor, min(64 * 1024, info.st_size - len(data)))
            if not chunk:
                break
            data.extend(chunk)
        if len(data) != info.st_size:
            raise TransferIntegrityError(f"{path.name} was truncated while being read")
    finally:
        os.close(descriptor)
    try:
        value = json.loads(bytes(data).decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise TransferIntegrityError(f"{path.name} is not canonical JSON") from error
    if not isinstance(value, dict):
        raise TransferIntegrityError(f"{path.name} must contain an object")
    return value


def _open_regular(path: Path, flags: int) -> int:
    before = os.lstat(path)
    _regular_single_link(before, str(path))
    descriptor = os.open(str(path), flags | _O_NOFOLLOW | _O_BINARY)
    try:
        after = os.fstat(descriptor)
        _regular_single_link(after, str(path))
        if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
            raise UnsafeTransferPath(f"{path} changed identity while being opened")
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _opened_regular_stat(path: Path) -> os.stat_result:
    # Seal and validate with the same handle-based metadata API. On Windows,
    # Python's path stat may expose birth time as ctime while fstat exposes
    # change time; mixing them rejects an unchanged, correctly verified file.
    descriptor = _open_regular(path, os.O_RDONLY)
    try:
        return os.fstat(descriptor)
    finally:
        os.close(descriptor)


def _pread_exact(descriptor: int, size: int, offset: int) -> bytes:
    data = bytearray()
    while len(data) < size:
        if hasattr(os, "pread"):
            chunk = os.pread(descriptor, size - len(data), offset + len(data))
        else:  # pragma: no cover - Windows fallback
            os.lseek(descriptor, offset + len(data), os.SEEK_SET)
            chunk = os.read(descriptor, size - len(data))
        if not chunk:
            break
        data.extend(chunk)
    return bytes(data)


def _pwrite_all(descriptor: int, data: bytes, offset: int) -> None:
    view = memoryview(data)
    written_total = 0
    while view:
        if hasattr(os, "pwrite"):
            written = os.pwrite(descriptor, view, offset + written_total)
        else:  # pragma: no cover - Windows fallback
            os.lseek(descriptor, offset + written_total, os.SEEK_SET)
            written = os.write(descriptor, view)
        if written <= 0:
            raise OSError("short staged-data write")
        written_total += written
        view = view[written:]


def _pwrite_stage_block(descriptor: int, data: bytes, offset: int) -> None:
    """Append one block while retaining portable sparse-zero extents.

    Transfer jobs are strict contiguous-prefix writers, so extending the
    logical length over an all-zero block is byte-equivalent to writing it.
    POSIX filesystems represent that extension as a hole when supported.  The
    conservative Windows path keeps ordinary writes because sparse-file
    enablement there requires a platform control call.
    """

    if data and os.name != "nt" and data.count(0) == len(data):
        os.ftruncate(descriptor, offset + len(data))
        return
    _pwrite_all(descriptor, data, offset)


def _source_open(path: Path) -> tuple[int, SourceFingerprint]:
    descriptor = _open_regular(path, os.O_RDONLY)
    info = os.fstat(descriptor)
    return descriptor, _fingerprint(info)


def _discard_owned_temp(path: Path) -> bool:
    """Remove only an unpublished, byte-empty temp shape owned by this module."""

    if (
        path.parent.name != "jobs"
        or _TEMP_JOB_RE.fullmatch(path.name) is None
        or not path.exists()
        or path.is_symlink()
    ):
        return False
    try:
        directory_info = os.lstat(path)
    except OSError:
        return False
    if (
        not stat.S_ISDIR(directory_info.st_mode)
        or stat.S_ISLNK(directory_info.st_mode)
        or _is_reparse(directory_info)
    ):
        return False
    children: list[Path] = []
    with os.scandir(path) as entries:
        for entry in entries:
            if len(children) >= 6:
                return False
            if entry.name not in {
                "intent.json",
                "reservation.json",
                "progress.json",
                "stage.partial",
            } and _TEMP_METADATA_RE.fullmatch(entry.name) is None:
                return False
            info = entry.stat(follow_symlinks=False)
            if not stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode) or _is_reparse(info):
                return False
            if entry.name == "stage.partial" and info.st_size != 0:
                # Pre-publication creates never write payload bytes. Preserve an
                # unexpected non-empty file for explicit inspection.
                return False
            children.append(Path(entry.path))
    for child in children:
        os.unlink(child)
    os.rmdir(path)
    return True


def _transfer_io_path(path: Path) -> Path:
    """Keep owned Windows job descendants usable beyond legacy MAX_PATH.

    Normalize lexically before adding the extended prefix; resolving here
    would follow a reparse point before the caller's existing identity checks.
    The prefix changes Win32 path parsing, not the object or its permissions.
    """
    if os.name != "nt":
        return path
    absolute = os.path.abspath(path)
    if absolute.startswith("\\\\?\\"):
        return Path(absolute)
    if absolute.startswith("\\\\"):
        return Path("\\\\?\\UNC\\" + absolute[2:])
    return Path("\\\\?\\" + absolute)


class TransferStore:
    """Private bounded intent store with at most one active job per path."""

    def __init__(
        self,
        root: Path | str,
        *,
        max_staging_bytes: int = DEFAULT_MAX_STAGING_BYTES,
        min_free_bytes: int = DEFAULT_MIN_FREE_BYTES,
        min_free_fraction: float = DEFAULT_MIN_FREE_FRACTION,
        max_jobs: int = DEFAULT_MAX_JOBS,
        disk_usage: Callable[[Path], Any] = shutil.disk_usage,
        quota_hook: QuotaHook | None = None,
        source_resolver: SourceResolver | None = None,
        admission_ledger: StagingAdmissionLedger | None = None,
    ) -> None:
        for name, value, minimum in (
            ("max_staging_bytes", max_staging_bytes, 0),
            ("min_free_bytes", min_free_bytes, 0),
            ("max_jobs", max_jobs, 1),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
                raise ValueError(f"{name} must be an integer of at least {minimum}")
        if isinstance(min_free_fraction, bool) or not isinstance(min_free_fraction, (int, float)) or not 0 <= min_free_fraction < 1:
            raise ValueError("min_free_fraction must be between 0 and 1")
        requested = _transfer_io_path(Path(root).expanduser())
        if requested.exists() or requested.is_symlink():
            info = os.lstat(requested)
            if stat.S_ISLNK(info.st_mode) or _is_reparse(info) or not stat.S_ISDIR(info.st_mode):
                raise UnsafeTransferPath("transfer root must be a real directory, not a link")
        self.root = ensure_private_dir(requested)
        self.jobs_root = ensure_private_dir(self.root / "jobs")
        self.quarantine_root = ensure_private_dir(self.root / "quarantine")
        for directory, label in ((self.root, "transfer root"), (self.jobs_root, "jobs directory"), (self.quarantine_root, "quarantine directory")):
            info = os.lstat(directory)
            if stat.S_ISLNK(info.st_mode) or _is_reparse(info) or not stat.S_ISDIR(info.st_mode):
                raise UnsafeTransferPath(f"{label} must be a real directory")
        self._reservation_lock_path = self.root / "reservation.lock"
        created_lock = False
        try:
            descriptor = os.open(
                str(self._reservation_lock_path),
                os.O_RDWR
                | os.O_CREAT
                | os.O_EXCL
                | _O_NOFOLLOW
                | getattr(os, "O_CLOEXEC", 0)
                | getattr(os, "O_NOINHERIT", 0),
                0o600,
            )
            created_lock = True
        except FileExistsError:
            descriptor = _open_regular(self._reservation_lock_path, os.O_RDWR)
        try:
            lock_info = os.fstat(descriptor)
            _regular_single_link(lock_info, "transfer reservation lock")
            if lock_info.st_size == 0:
                os.write(descriptor, b"\0")
                os.fsync(descriptor)
            elif lock_info.st_size != 1:
                raise UnsafeTransferPath("transfer reservation lock has an invalid size")
            os.chmod(self._reservation_lock_path, 0o600)
        finally:
            os.close(descriptor)
        if created_lock:
            _fsync_dir(self.root)
        self.max_staging_bytes = max_staging_bytes
        self.min_free_bytes = min_free_bytes
        self.min_free_fraction = float(min_free_fraction)
        self.max_jobs = min(max_jobs, 4096)
        self._disk_usage = disk_usage
        self._quota_hook = quota_hook
        if admission_ledger is not None and not isinstance(
            admission_ledger, StagingAdmissionLedger
        ):
            raise TypeError("admission_ledger must be a StagingAdmissionLedger")
        self._admission_ledger = admission_ledger
        self._source_resolver = source_resolver
        self._sources: dict[str, LocalBlockSource] = {}
        # A source can be shared by multiple durable local-snapshot jobs. Keep
        # the reverse ownership index separate from the job-object cache: tests,
        # bounded recovery, and a lazy reopen may discard cached job objects
        # while their durable ``copying`` intents still require the source.
        self._source_jobs: dict[str, set[str]] = {}
        self._job_sources: dict[str, str] = {}
        self._source_catalog_initialized = False
        self._lock = _shared_reservation_lock(self.root)
        self._recovery_cursor: str | None = None
        self._job_cache: dict[str, RemoteAssemblyJob | LocalSnapshotJob] = {}
        self._open_worker_busy = False

    def physical_reservation(self, path: Path | str) -> StagingReservation:
        """Return the exact shared-ledger charge for one published job."""

        candidate = _transfer_io_path(Path(path))
        if candidate.parent not in (self.jobs_root, self.quarantine_root):
            raise UnsafeTransferPath("transfer reservation is outside an owned root")
        info = os.lstat(candidate)
        if (
            not stat.S_ISDIR(info.st_mode)
            or stat.S_ISLNK(info.st_mode)
            or _is_reparse(info)
        ):
            raise UnsafeTransferPath("transfer reservation is not a real directory")
        reservation = _read_json(
            candidate / "reservation.json", MAX_RESERVATION_BYTES
        )
        path_key = str(reservation.get("path_key"))
        transfer_id = str(reservation.get("transfer_id"))
        size_bytes = _reservation_size(reservation, path_key)
        committed_bytes = 0
        for payload_name in ("stage.ready", "stage.partial"):
            try:
                payload_info = os.lstat(candidate / payload_name)
            except FileNotFoundError:
                continue
            committed_bytes = _allocated_regular_bytes(payload_info)
            break
        return StagingReservation(
            owner_id=_shared_reservation_owner(transfer_id),
            kind="transfer",
            size_bytes=size_bytes,
            created_at_ns=int(info.st_mtime_ns),
            committed_bytes=min(size_bytes, committed_bytes),
        )

    def _job_dir(self, logical_path: str) -> Path:
        return self.jobs_root / _job_key(logical_path)

    @contextmanager
    def _reservation_guard(self) -> Iterator[None]:
        """Serialize quota admission through durable job publication.

        The process-shared lock covers multiple ``TransferStore`` objects, and
        the one-byte advisory lock covers independent node processes. A crashed
        owner releases the OS lock automatically; its strictly shaped,
        unpublished temp is then removed before the next quota calculation.
        """

        with self._lock:
            lock_info = os.lstat(self._reservation_lock_path)
            _regular_single_link(lock_info, "transfer reservation lock")
            if lock_info.st_size != 1:
                raise UnsafeTransferPath("transfer reservation lock has an invalid size")
            with file_lock(self._reservation_lock_path):
                # Shared-ledger creation uses one deterministic per-path temp
                # cleaned in O(1) below. Standalone stores retain their bounded
                # compatibility scavenger.
                if self._admission_ledger is None:
                    self._cleanup_abandoned_temporaries_locked()
                yield

    def _shared_temporary(self, destination: Path) -> Path:
        return self.jobs_root / f".{destination.name}.{'0' * 32}.tmp"

    def _cleanup_shared_temporary_locked(self, destination: Path) -> None:
        temporary = self._shared_temporary(destination)
        if not temporary.exists() and not temporary.is_symlink():
            return
        if not _discard_owned_temp(temporary):
            raise TransferIntegrityError(
                "an abandoned transfer creation contains unaccounted bytes"
            )
        _fsync_dir(self.jobs_root)

    def _reserve_shared(
        self, destination: Path, size_bytes: int, transfer_id: str
    ) -> str | None:
        ledger = self._admission_ledger
        if ledger is None:
            return None
        owner = _shared_reservation_owner(transfer_id)
        try:
            ledger.reserve(
                owner,
                kind="transfer",
                size_bytes=size_bytes,
                max_kind_entries=min(self.max_jobs, ledger.max_entries),
            )
        except (StagingAdmissionExceeded, StagingRepairRequired) as error:
            raise StagingQuotaExceeded(str(error)) from None
        except StagingLedgerError as error:
            raise TransferIntegrityError(
                "shared staging admission could not be proven"
            ) from error
        return owner

    def _release_shared(self, owner: str, size_bytes: int) -> None:
        ledger = self._admission_ledger
        if ledger is None:
            return
        try:
            ledger.release(owner, expected_size_bytes=size_bytes)
        except StagingLedgerError as error:
            raise TransferIntegrityError(
                "shared staging release could not be proven"
            ) from error

    def _record_shared_committed(
        self, transfer_id: str, info: os.stat_result
    ) -> None:
        ledger = self._admission_ledger
        if ledger is None:
            return
        try:
            ledger.record_committed(
                _shared_reservation_owner(transfer_id),
                allocated_bytes=_allocated_regular_bytes(info),
            )
        except StagingLedgerError as error:
            raise TransferIntegrityError(
                "shared staging allocation could not be recorded"
            ) from error

    def _cleanup_abandoned_temporaries_locked(self) -> int:
        inspected = 0
        removed = 0
        with os.scandir(self.jobs_root) as entries:
            for entry in entries:
                inspected += 1
                if inspected > self.max_jobs * 2:
                    raise StagingQuotaExceeded(
                        "transfer metadata exceeds the bounded recovery limit"
                    )
                if _TEMP_JOB_RE.fullmatch(entry.name) is None:
                    continue
                if _discard_owned_temp(Path(entry.path)):
                    removed += 1
        if removed:
            _fsync_dir(self.jobs_root)
        return removed

    def _directory_reservation(self, path: Path) -> int:
        """Account one owned job without an unbounded recursive walk."""

        try:
            reservation = _read_json(
                path / "reservation.json", MAX_RESERVATION_BYTES
            )
            path_key = path.name.split(".", 1)[0]
            if _JOB_KEY_RE.fullmatch(path_key) is not None:
                return _reservation_size(reservation, path_key)
        except (OSError, TransferError):
            pass
        # Missing or corrupt reservation metadata never grants headroom. This
        # is intentionally strict until an operator inspects and removes the
        # exact quarantine token.
        return self.max_staging_bytes

    def _active_reservations(self) -> tuple[int, int]:
        active_count = 0
        total_entries = 0
        reserved = 0
        for root, active in ((self.jobs_root, True), (self.quarantine_root, False)):
            with os.scandir(root) as entries:
                for entry in entries:
                    total_entries += 1
                    if total_entries > self.max_jobs * 2:
                        raise StagingQuotaExceeded("transfer and quarantine metadata exceed the bounded entry limit")
                    if active:
                        active_count += 1
                        if active_count > self.max_jobs:
                            raise StagingQuotaExceeded("active transfer metadata exceeds the bounded job limit")
                    if not entry.is_dir(follow_symlinks=False):
                        reserved = self.max_staging_bytes
                        continue
                    reserved = min(
                        self.max_staging_bytes,
                        reserved + self._directory_reservation(Path(entry.path)),
                    )
        return active_count, reserved

    def _check_quota(self, phase: str, additional_bytes: int, reserved_bytes: int) -> None:
        if additional_bytes < 0:
            raise ValueError("additional_bytes cannot be negative")
        if reserved_bytes + additional_bytes > self.max_staging_bytes:
            raise StagingQuotaExceeded("private staging reservation exceeds its configured byte limit")
        usage = self._disk_usage(self.root)
        required_free = max(self.min_free_bytes, int(usage.total * self.min_free_fraction))
        if additional_bytes > max(0, usage.free - required_free):
            raise StagingQuotaExceeded("private staging would consume the configured free-space reserve")
        if self._quota_hook is not None:
            self._quota_hook(phase, additional_bytes, reserved_bytes)

    def _prepare_locked(
        self, logical_path: str, size_bytes: int, transfer_id: str
    ) -> tuple[Path, str | None]:
        path = _logical_path(logical_path)
        destination = self._job_dir(path)
        if self._admission_ledger is not None:
            self._cleanup_shared_temporary_locked(destination)
        if destination.exists() or destination.is_symlink():
            try:
                progress = _read_json(destination / "progress.json", MAX_PROGRESS_BYTES)
            except (OSError, TransferError):
                self._archive(destination, "invalid-existing-job")
            else:
                if progress.get("state") not in ("ready", "cancelled", "quarantined"):
                    raise TransferBusy(f"{path} already has an active transfer")
                raise TransferBusy(
                    f"{path} has preserved {progress.get('state')} bytes; "
                    "consume_ready or remove_terminal with the exact token first"
                )
        if self._admission_ledger is not None:
            return destination, self._reserve_shared(
                destination, size_bytes, transfer_id
            )
        count, reserved = self._active_reservations()
        if count >= self.max_jobs:
            raise StagingQuotaExceeded("active transfer count reached its configured limit")
        self._check_quota("reserve", size_bytes, reserved)
        return destination, None

    def _archive(self, path: Path, reason: str) -> None:
        if not path.exists() and not path.is_symlink():
            return
        safe_reason = re.sub(r"[^a-z0-9_-]+", "-", reason.lower())[:32] or "orphan"
        try:
            info = os.lstat(path)
            if stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and not _is_reparse(info):
                quarantine_record = path / "quarantine.json"
                if not quarantine_record.exists():
                    _atomic_json(
                        quarantine_record,
                        {
                            "reason": str(reason)[:MAX_ERROR_BYTES],
                            "at_ns": time.time_ns(),
                            "removal_token": uuid.uuid4().hex,
                        },
                        MAX_ERROR_BYTES * 2,
                    )
        except (OSError, TransferError):
            pass
        destination = self.quarantine_root / f"{path.name}.{time.time_ns()}.{safe_reason}"
        os.replace(path, destination)
        for logical_path, cached in tuple(self._job_cache.items()):
            if cached.job_dir == path:
                if isinstance(cached, LocalSnapshotJob):
                    cached.source = None
                self._job_cache.pop(logical_path, None)
        # Quarantine archives are terminal evidence and cannot be reopened as
        # active jobs. Release their process-local source only after the atomic
        # move has made that fact durable.
        self._release_source_for_job(path)
        _fsync_dir(self.jobs_root)
        _fsync_dir(self.quarantine_root)

    def create_remote(
        self,
        logical_path: str,
        *,
        size_bytes: int,
        sha256: str | None = None,
        blocks: Sequence[BlockSpec],
        final_path: str | None = None,
        file_digest: str | None = None,
    ) -> "RemoteAssemblyJob":
        logical_path = _logical_path(logical_path)
        if final_path is not None:
            final_path = _logical_path(final_path)
        if (sha256 is None) == (file_digest is None):
            raise ValueError("provide either a flat checksum or a block file identity")
        sha256 = _digest(sha256) if sha256 is not None else None
        file_digest = _digest(file_digest) if file_digest is not None else None
        checked = _validate_file_shape(size_bytes, blocks)
        identity = {
            "size_bytes": size_bytes,
            "sha256": sha256,
            "blocks": [
                {"index": block.index, "offset_bytes": block.offset_bytes,
                 "size_bytes": block.size_bytes, "sha256": block.sha256}
                for block in checked
            ],
            **({"file_digest_algorithm": FABRIC_BLOCK_FILE_DIGEST_ALGORITHM,
                "file_digest": file_digest} if file_digest is not None else {}),
        }
        _remote_file_digest(identity)
        with self._reservation_guard():
            transfer_id = str(uuid.uuid4())
            destination, shared_owner = self._prepare_locked(
                logical_path, size_bytes, transfer_id
            )
            temporary = (
                self._shared_temporary(destination)
                if shared_owner is not None
                else self.jobs_root / f".{destination.name}.{uuid.uuid4().hex}.tmp"
            )
            published = False
            try:
                os.mkdir(temporary, 0o700)
                intent = {
                    "schema": REMOTE_INTENT_SCHEMA,
                    "transfer_id": transfer_id,
                    "kind": "remote_assembly",
                    "logical_path": logical_path,
                    "final_path": final_path,
                    **identity,
                    "block_bytes": BLOCK_BYTES,
                    "created_at_ns": time.time_ns(),
                }
                progress = self._new_progress(transfer_id, "remote_assembly")
                _atomic_json(temporary / "intent.json", intent, MAX_INTENT_BYTES)
                _atomic_json(
                    temporary / "reservation.json",
                    _reservation_record(transfer_id, size_bytes, destination.name),
                    MAX_RESERVATION_BYTES,
                )
                _atomic_json(temporary / "progress.json", progress, MAX_PROGRESS_BYTES)
                descriptor = os.open(str(temporary / "stage.partial"), os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_BINARY, 0o600)
                try:
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
                os.replace(temporary, destination)
                published = True
                _fsync_dir(self.jobs_root)
            except BaseException:
                if temporary.exists() and _discard_owned_temp(temporary):
                    _fsync_dir(self.jobs_root)
                if shared_owner is not None and not published:
                    self._release_shared(shared_owner, size_bytes)
                raise
        job = RemoteAssemblyJob.open(self, logical_path)
        self._job_cache[logical_path] = job
        return job

    def register_source(self, source: LocalBlockSource) -> None:
        """Register one restart-resolvable source without claiming job ownership."""

        source_id = _source_id(getattr(source, "source_id", None))
        if not callable(getattr(source, "fingerprint", None)) or not callable(
            getattr(source, "read_block", None)
        ):
            raise TypeError("local source must implement anchored fingerprint/read_block")
        with self._lock:
            self._ensure_source_job_catalog_locked()
            self._sources[source_id] = source

    @property
    def registered_source_count(self) -> int:
        """Return the bounded process-local source count for diagnostics."""

        with self._lock:
            return len(self._sources)

    def _retain_source_for_job(
        self, logical_path: str, source: LocalBlockSource
    ) -> None:
        source_id = _source_id(getattr(source, "source_id", None))
        if not callable(getattr(source, "fingerprint", None)) or not callable(
            getattr(source, "read_block", None)
        ):
            raise TypeError("local source must implement anchored fingerprint/read_block")
        job_key = _job_key(_logical_path(logical_path))
        with self._lock:
            self._ensure_source_job_catalog_locked()
            previous_source_id = self._job_sources.get(job_key)
            if previous_source_id is not None and previous_source_id != source_id:
                self._release_source_for_job_locked(job_key)
            self._sources[source_id] = source
            self._job_sources[job_key] = source_id
            self._source_jobs.setdefault(source_id, set()).add(job_key)

    def _ensure_source_job_catalog_locked(self) -> None:
        """Index durable local jobs once, without retaining any source objects.

        A fresh process may resolve only one of several jobs sharing a source.
        Cataloging their small bounded intents prevents completing that first job
        from unregistering the source needed to lazily reopen a sibling. Invalid
        metadata is left to the existing fail-closed recovery/quarantine path.
        """

        if self._source_catalog_initialized:
            return
        inspected = 0
        source_jobs: dict[str, set[str]] = {}
        job_sources: dict[str, str] = {}
        with os.scandir(self.jobs_root) as entries:
            for entry in entries:
                inspected += 1
                if inspected > self.max_jobs:
                    raise StagingQuotaExceeded(
                        "active transfer metadata exceeds the bounded job limit"
                    )
                if (
                    _JOB_KEY_RE.fullmatch(entry.name) is None
                    or not entry.is_dir(follow_symlinks=False)
                ):
                    continue
                try:
                    intent = _read_json(Path(entry.path) / "intent.json", MAX_INTENT_BYTES)
                    if intent.get("kind") != "local_snapshot":
                        continue
                    source_id = _source_id(intent.get("source_id"))
                    progress = _read_json(
                        Path(entry.path) / "progress.json", MAX_PROGRESS_BYTES
                    )
                except (OSError, TransferError, TypeError, ValueError):
                    continue
                if progress.get("state") in ("ready", "leased", "consumed"):
                    continue
                job_sources[entry.name] = source_id
                source_jobs.setdefault(source_id, set()).add(entry.name)
        self._job_sources = job_sources
        self._source_jobs = source_jobs
        self._source_catalog_initialized = True

    def _release_source_for_job(self, job_dir: Path) -> None:
        with self._lock:
            self._release_source_for_job_locked(job_dir.name)

    def _release_source_for_job_locked(self, job_key: str) -> None:
        source_id = self._job_sources.pop(job_key, None)
        if source_id is None:
            return
        jobs = self._source_jobs.get(source_id)
        if jobs is None:
            return
        jobs.discard(job_key)
        if jobs:
            return
        self._source_jobs.pop(source_id, None)
        self._sources.pop(source_id, None)

    def _resolve_source(self, source_id: str, logical_path: str) -> LocalBlockSource:
        source_id = _source_id(source_id)
        logical_path = _logical_path(logical_path)
        # Resolver recreation is intentionally serialized. It is a rare restart
        # path, and one deterministic source object must win when recovery opens
        # several jobs sharing the same anchored identity concurrently.
        with self._lock:
            self._ensure_source_job_catalog_locked()
            source = self._sources.get(source_id)
            if source is None and self._source_resolver is not None:
                source = self._source_resolver(source_id, logical_path)
                if source is not None:
                    if _source_id(getattr(source, "source_id", None)) != source_id:
                        raise UnsafeTransferPath(
                            "source resolver returned the wrong anchored identity"
                        )
                    if not callable(getattr(source, "fingerprint", None)) or not callable(
                        getattr(source, "read_block", None)
                    ):
                        raise TypeError(
                            "local source must implement anchored fingerprint/read_block"
                        )
                    self._sources[source_id] = source
            if source is None:
                raise SourceDrift("anchored local source is unavailable after restart")
            job_key = _job_key(logical_path)
            previous_source_id = self._job_sources.get(job_key)
            if previous_source_id is not None and previous_source_id != source_id:
                self._release_source_for_job_locked(job_key)
            self._job_sources[job_key] = source_id
            self._source_jobs.setdefault(source_id, set()).add(job_key)
            return source

    def create_local(
        self, logical_path: str, source: LocalBlockSource
    ) -> "LocalSnapshotJob":
        logical_path = _logical_path(logical_path)
        source_id = _source_id(source.source_id)
        if not callable(getattr(source, "fingerprint", None)) or not callable(
            getattr(source, "read_block", None)
        ):
            raise TypeError("local source must implement anchored fingerprint/read_block")
        fingerprint = _checked_fingerprint(source.fingerprint())
        with self._reservation_guard():
            transfer_id = str(uuid.uuid4())
            destination, shared_owner = self._prepare_locked(
                logical_path, fingerprint.size_bytes, transfer_id
            )
            temporary = (
                self._shared_temporary(destination)
                if shared_owner is not None
                else self.jobs_root / f".{destination.name}.{uuid.uuid4().hex}.tmp"
            )
            published = False
            try:
                os.mkdir(temporary, 0o700)
                intent = {
                    "schema": LOCAL_INTENT_SCHEMA,
                    "transfer_id": transfer_id,
                    "kind": "local_snapshot",
                    "logical_path": logical_path,
                    "source_id": source_id,
                    "source_fingerprint": _fp_json(fingerprint),
                    "size_bytes": fingerprint.size_bytes,
                    "block_bytes": BLOCK_BYTES,
                    "created_at_ns": time.time_ns(),
                }
                progress = self._new_progress(transfer_id, "local_snapshot")
                _atomic_json(temporary / "intent.json", intent, MAX_INTENT_BYTES)
                _atomic_json(
                    temporary / "reservation.json",
                    _reservation_record(
                        transfer_id, fingerprint.size_bytes, destination.name
                    ),
                    MAX_RESERVATION_BYTES,
                )
                _atomic_json(temporary / "progress.json", progress, MAX_PROGRESS_BYTES)
                descriptor = os.open(str(temporary / "stage.partial"), os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_BINARY, 0o600)
                try:
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
                os.replace(temporary, destination)
                published = True
                # The atomic publication is the first moment a durable job can
                # reference this source. Associate it while the shared process
                # lock is still held, before any concurrent reopen can observe
                # the new job.
                self._retain_source_for_job(logical_path, source)
                _fsync_dir(self.jobs_root)
            except BaseException:
                if temporary.exists() and _discard_owned_temp(temporary):
                    _fsync_dir(self.jobs_root)
                if shared_owner is not None and not published:
                    self._release_shared(shared_owner, fingerprint.size_bytes)
                raise
        job = LocalSnapshotJob.open(self, logical_path)
        self._job_cache[logical_path] = job
        return job

    @staticmethod
    def _new_progress(transfer_id: str, kind: str) -> dict[str, Any]:
        return {
            "schema": PROGRESS_SCHEMA,
            "transfer_id": transfer_id,
            "kind": kind,
            "state": "receiving" if kind == "remote_assembly" else "copying",
            "completed_blocks": 0,
            "durable_size": 0,
            "updated_at_ns": time.time_ns(),
        }

    def open(
        self,
        logical_path: str,
        *,
        max_sync_verify_bytes: int = 64 * 1024 * 1024,
    ) -> "RemoteAssemblyJob | LocalSnapshotJob":
        logical_path = _logical_path(logical_path)
        cached = self._job_cache.get(logical_path)
        if cached is not None:
            return cached
        if (
            isinstance(max_sync_verify_bytes, bool)
            or not isinstance(max_sync_verify_bytes, int)
            or max_sync_verify_bytes < 0
        ):
            raise ValueError("max_sync_verify_bytes must be a non-negative integer")
        progress = _read_json(
            self._job_dir(logical_path) / "progress.json", MAX_PROGRESS_BYTES
        )
        durable_size = progress.get("durable_size")
        if (
            isinstance(durable_size, bool)
            or not isinstance(durable_size, int)
            or not 0 <= durable_size <= MAX_FILE_BYTES
        ):
            raise TransferIntegrityError("transfer durable size is invalid")
        verification_bytes = self._stage_verification_bytes(
            self._job_dir(logical_path), durable_size
        )
        if verification_bytes > max_sync_verify_bytes:
            raise RecoveryDeferred(
                logical_path, verification_bytes, max_sync_verify_bytes
            )
        return self._open_unbounded(logical_path)

    @staticmethod
    def _stage_verification_bytes(job_dir: Path, durable_size: int) -> int:
        """Bound a reopen by every byte that recovery may synchronously read.

        Payload durability deliberately precedes the progress journal. After a
        crash, ``stage.partial`` can therefore contain one fsynced batch beyond
        ``durable_size``. Inspect the owned stage through a no-follow regular-file
        descriptor and charge its actual size without reading payload bytes.
        Exactly one partial/ready stage is valid; ambiguous or unsafe metadata
        fails closed before any verifier runs.
        """

        stage_size: int | None = None
        stage_identity: tuple[int, int] | None = None
        for name in ("stage.partial", "stage.ready"):
            path = job_dir / name
            try:
                descriptor = _open_regular(path, os.O_RDONLY)
            except FileNotFoundError:
                continue
            try:
                info = os.fstat(descriptor)
                size = int(info.st_size)
                identity = (int(info.st_dev), int(info.st_ino))
            finally:
                os.close(descriptor)
            if not 0 <= size <= MAX_FILE_BYTES:
                raise TransferIntegrityError("transfer stage size is invalid")
            if stage_size is not None:
                # Promotion atomically renames the exact same inode from
                # ``partial`` to ``ready``. If it crosses these two probes,
                # treat it as one stage rather than a fabricated collision.
                if stage_identity == identity:
                    stage_size = max(stage_size, size)
                    continue
                raise TransferIntegrityError(
                    "transfer has both a partial and ready stage"
                )
            stage_size = size
            stage_identity = identity
        if stage_size is None:
            raise TransferIntegrityError("transfer stage is missing")
        return max(durable_size, stage_size)

    def _open_unbounded(
        self, logical_path: str
    ) -> "RemoteAssemblyJob | LocalSnapshotJob":
        logical_path = _logical_path(logical_path)
        cached = self._job_cache.get(logical_path)
        if cached is not None:
            return cached
        intent = _read_json(self._job_dir(logical_path) / "intent.json", MAX_INTENT_BYTES)
        kind = intent.get("kind")
        if kind == "remote_assembly":
            job: RemoteAssemblyJob | LocalSnapshotJob = RemoteAssemblyJob.open(
                self, logical_path
            )
            self._job_cache[logical_path] = job
            return job
        if kind == "local_snapshot":
            job = LocalSnapshotJob.open(self, logical_path)
            self._job_cache[logical_path] = job
            return job
        raise TransferIntegrityError("intent has an unknown transfer kind")

    def open_async(
        self, logical_path: str
    ) -> Future["RemoteAssemblyJob | LocalSnapshotJob"]:
        """Verify a potentially huge durable prefix on one daemon I/O lane.

        The returned future is intentionally ordinary: ``result(timeout=...)``
        returns control on a stuck filesystem. At most one reopen can run, and
        this worker owns no signed control-plane dependency.
        """

        logical_path = _logical_path(logical_path)
        future: Future[RemoteAssemblyJob | LocalSnapshotJob] = Future()
        with self._lock:
            cached = self._job_cache.get(logical_path)
            if cached is not None:
                future.set_result(cached)
                return future
            if self._open_worker_busy:
                raise TransferBusy("one background transfer reopen is already running")
            self._open_worker_busy = True

        def run() -> None:
            try:
                if future.set_running_or_notify_cancel():
                    future.set_result(self._open_unbounded(logical_path))
            except BaseException as error:
                future.set_exception(error)
            finally:
                with self._lock:
                    self._open_worker_busy = False

        threading.Thread(
            target=run,
            name="meshia-transfer-reopen",
            daemon=True,
        ).start()
        return future

    def recover(
        self,
        *,
        max_entries: int = 64,
        max_verify_bytes: int = 0,
        max_seconds: float = 0.05,
    ) -> RecoveryReport:
        if isinstance(max_entries, bool) or not isinstance(max_entries, int) or not 1 <= max_entries <= self.max_jobs:
            raise ValueError("max_entries must be a positive bounded integer")
        if isinstance(max_verify_bytes, bool) or not isinstance(max_verify_bytes, int) or max_verify_bytes < 0:
            raise ValueError("max_verify_bytes must be a non-negative integer")
        if isinstance(max_seconds, bool) or not isinstance(max_seconds, (int, float)) or not 0 < max_seconds <= 5:
            raise ValueError("max_seconds must be greater than zero and at most five")
        inspected = reopened = quarantined = verified_bytes = deferred = 0
        deadline = time.monotonic() + float(max_seconds)
        # A process can die after reserving quota in a private temp directory
        # but before the atomic directory rename publishes a job. The OS releases
        # the advisory lock on death, so recovery can now prove no creator owns
        # such a strictly shaped temp and remove it before catalog accounting.
        # Keep the reservation lock through catalog capture and repair. Without
        # that, another process could create an unpublished temp immediately
        # after cleanup and have this recovery pass misclassify it as an orphan.
        with self._reservation_guard():
            candidates: list[tuple[str, Path]] = []
            with os.scandir(self.jobs_root) as entries:
                for entry in entries:
                    if len(candidates) >= self.max_jobs:
                        raise StagingQuotaExceeded("active recovery catalog exceeds the bounded job limit")
                    candidates.append((entry.name, Path(entry.path)))
            candidates.sort(key=lambda item: item[0])
            names = [item[0] for item in candidates]
            start = bisect.bisect(names, self._recovery_cursor) if self._recovery_cursor is not None else 0
            selected = candidates[start : start + max_entries]
            more = start + len(selected) < len(candidates)
            last_processed: str | None = None
            for name, path in selected:
                if time.monotonic() >= deadline:
                    more = True
                    break
                inspected += 1
                last_processed = name
                try:
                    info = os.lstat(path)
                    if not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode) or _is_reparse(info) or _JOB_KEY_RE.fullmatch(name) is None:
                        raise TransferIntegrityError("orphan transfer entry")
                    progress = _read_json(path / "progress.json", MAX_PROGRESS_BYTES)
                    if progress.get("state") == "consumed":
                        self._remove_owned_job(path)
                        reopened += 1
                        continue
                    durable_size = progress.get("durable_size")
                    if (
                        isinstance(durable_size, bool)
                        or not isinstance(durable_size, int)
                        or not 0 <= durable_size <= MAX_FILE_BYTES
                    ):
                        raise TransferIntegrityError("transfer durable size is invalid")
                    verification_bytes = self._stage_verification_bytes(
                        path, durable_size
                    )
                    if verification_bytes > max_verify_bytes - verified_bytes:
                        # Startup recovery remains bounded. The exact job is
                        # verified lazily when its path is opened for work.
                        deferred += 1
                        continue
                    intent = _read_json(path / "intent.json", MAX_INTENT_BYTES)
                    logical = _logical_path(intent.get("logical_path"))
                    if _job_key(logical) != name:
                        raise TransferIntegrityError("intent is stored under the wrong path key")
                    self.open(
                        logical,
                        max_sync_verify_bytes=max_verify_bytes - verified_bytes,
                    )
                    verified_bytes += verification_bytes
                    reopened += 1
                except RecoveryDeferred:
                    # A writer may have durably extended the stage between the
                    # metadata-only budget probe and ``open``. It remains valid
                    # lazy-recovery work, never corruption evidence.
                    deferred += 1
                    continue
                except (OSError, ValueError, TransferError) as error:
                    try:
                        _atomic_json(
                            path / "quarantine.json",
                            {
                                "reason": str(error)[:MAX_ERROR_BYTES],
                                "at_ns": time.time_ns(),
                                "removal_token": uuid.uuid4().hex,
                            },
                            MAX_ERROR_BYTES * 2,
                        )
                    except (OSError, TransferError):
                        pass
                    self._archive(path, "recovery")
                    quarantined += 1
            if last_processed is not None and (
                more or start + inspected < len(candidates)
            ):
                self._recovery_cursor = last_processed
            elif not more:
                self._recovery_cursor = None
        return RecoveryReport(
            inspected,
            reopened,
            quarantined,
            more,
            verified_bytes,
            deferred,
        )

    def page_local_recovery_candidates(
        self, *, limit: int = 16, after_job_key: str | None = None
    ) -> tuple[tuple[LocalRecoveryCandidate, ...], str | None]:
        """Read one bounded keyset page of complete local snapshot evidence.

        Discovery never opens or hashes payload bytes and never changes a
        lease. Callers must use :meth:`validate_local_recovery_candidate`
        before deduplicating; an unmatched candidate is user evidence, not
        disposable cache.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= min(self.max_jobs, 256)
        ):
            raise ValueError("limit must be between one and the bounded job limit")
        if after_job_key is not None and _JOB_KEY_RE.fullmatch(after_job_key) is None:
            raise ValueError("after_job_key is invalid")
        with self._reservation_guard():
            names = sorted(
                entry.name
                for entry in os.scandir(self.jobs_root)
                if entry.is_dir(follow_symlinks=False)
                and _JOB_KEY_RE.fullmatch(entry.name) is not None
            )
            if len(names) > self.max_jobs:
                raise StagingQuotaExceeded(
                    "active transfer metadata exceeds the bounded job limit"
                )
            start = bisect.bisect(names, after_job_key) if after_job_key else 0
            selected = names[start : start + limit]
            candidates: list[LocalRecoveryCandidate] = []
            for name in selected:
                candidate = self._read_local_recovery_candidate(
                    self.jobs_root / name, name
                )
                if candidate is not None:
                    candidates.append(candidate)
            next_after = (
                selected[-1]
                if len(selected) == limit and start + limit < len(names)
                else None
            )
            return tuple(candidates), next_after

    def _read_local_recovery_candidate(
        self, job_dir: Path, job_key: str
    ) -> LocalRecoveryCandidate | None:
        intent = _read_json(job_dir / "intent.json", MAX_INTENT_BYTES)
        if intent.get("kind") != "local_snapshot":
            return None
        reservation = _read_json(
            job_dir / "reservation.json", MAX_RESERVATION_BYTES
        )
        progress = _read_json(job_dir / "progress.json", MAX_PROGRESS_BYTES)
        state = progress.get("state")
        if state not in ("ready", "leased"):
            return None
        logical_path = _logical_path(intent.get("logical_path"))
        if _job_key(logical_path) != job_key:
            raise TransferIntegrityError(
                "local recovery candidate is stored under the wrong key"
            )
        transfer_id = str(intent.get("transfer_id"))
        try:
            normalized_transfer_id = str(uuid.UUID(transfer_id))
        except (AttributeError, TypeError, ValueError):
            raise TransferIntegrityError(
                "local recovery candidate transfer UUID is invalid"
            ) from None
        token = progress.get("token")
        size_bytes = intent.get("size_bytes")
        sha256 = _digest(progress.get("sha256"))
        source_id = _source_id(intent.get("source_id"))
        source_fingerprint = _fp_from_json(intent.get("source_fingerprint"))
        stage_path = job_dir / "stage.ready"
        descriptor = _open_regular(stage_path, os.O_RDONLY)
        try:
            stage_info = os.fstat(descriptor)
        finally:
            os.close(descriptor)
        if (
            normalized_transfer_id != transfer_id
            or progress.get("schema") != PROGRESS_SCHEMA
            or progress.get("kind") != "local_snapshot"
            or progress.get("transfer_id") != transfer_id
            or not isinstance(token, str)
            or re.fullmatch(r"[a-f0-9]{32}", token) is None
            or isinstance(size_bytes, bool)
            or not isinstance(size_bytes, int)
            or not 0 <= size_bytes <= MAX_FILE_BYTES
            or source_fingerprint.size_bytes != size_bytes
            or _reservation_size(reservation, job_key) != size_bytes
            or reservation.get("transfer_id") != transfer_id
            or stage_info.st_size != size_bytes
            or not _binding_matches(progress.get("binding"), stage_info)
        ):
            raise TransferIntegrityError(
                "local recovery candidate metadata is invalid"
            )
        return LocalRecoveryCandidate(
            job_key,
            logical_path,
            transfer_id,
            token,
            str(state),
            source_id,
            source_fingerprint,
            size_bytes,
            sha256,
            stage_path,
        )

    def validate_local_recovery_candidate(
        self,
        candidate: LocalRecoveryCandidate,
        *,
        max_sync_verify_bytes: int = 0,
    ) -> VerifiedStage:
        """Revalidate one exact candidate without ever consuming its bytes."""

        if not isinstance(candidate, LocalRecoveryCandidate):
            raise TypeError("candidate must be a LocalRecoveryCandidate")
        with self._reservation_guard():
            current = self._read_local_recovery_candidate(
                self.jobs_root / candidate.job_key, candidate.job_key
            )
            if current != candidate:
                raise TransferIntegrityError(
                    "local recovery candidate identity is stale"
                )
        opened = self.open(
            candidate.logical_path,
            max_sync_verify_bytes=max_sync_verify_bytes,
        )
        if not isinstance(opened, LocalSnapshotJob):
            raise TransferIntegrityError(
                "local recovery candidate changed transfer kind"
            )
        stage = opened.verified_stage()
        if (
            stage.transfer_id != candidate.transfer_id
            or stage.token != candidate.token
            or stage.kind != "local_snapshot"
            or stage.logical_path != candidate.logical_path
            or stage.path != candidate.stage_path
            or stage.size_bytes != candidate.size_bytes
            or stage.sha256 != candidate.sha256
        ):
            raise TransferIntegrityError(
                "local recovery candidate identity is stale"
            )
        return stage

    def page_remote_finalization_candidates(
        self, *, limit: int = 16, after_job_key: str | None = None
    ) -> tuple[tuple[RemoteFinalizationCandidate, ...], str | None]:
        """Inspect one bounded keyset page of remote cleanup candidates.

        This is read-only physical discovery. Complete stages still require
        proof of their published local/DB identity. Partial remote assemblies
        may be discarded only when the caller proves that their durable apply
        intent is absent and their exact remote object identity is obsolete.
        """

        if (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= min(self.max_jobs, 256)
        ):
            raise ValueError("limit must be between one and the bounded job limit")
        if after_job_key is not None and _JOB_KEY_RE.fullmatch(after_job_key) is None:
            raise ValueError("after_job_key is invalid")
        with self._reservation_guard():
            names = sorted(
                entry.name
                for entry in os.scandir(self.jobs_root)
                if entry.is_dir(follow_symlinks=False)
                and _JOB_KEY_RE.fullmatch(entry.name) is not None
            )
            if len(names) > self.max_jobs:
                raise StagingQuotaExceeded(
                    "active transfer metadata exceeds the bounded job limit"
                )
            start = bisect.bisect(names, after_job_key) if after_job_key else 0
            candidates: list[RemoteFinalizationCandidate] = []
            selected = names[start : start + limit]
            for name in selected:
                job_dir = self.jobs_root / name
                intent = _read_json(job_dir / "intent.json", MAX_INTENT_BYTES)
                progress = _read_json(job_dir / "progress.json", MAX_PROGRESS_BYTES)
                if intent.get("kind") != "remote_assembly":
                    continue
                final_path = intent.get("final_path")
                state = progress.get("state")
                if final_path is None or state not in (
                    "receiving",
                    "cancelled",
                    "ready",
                    "leased",
                    "consumed",
                ):
                    continue
                logical_path = _logical_path(intent.get("logical_path"))
                if _job_key(logical_path) != name:
                    raise TransferIntegrityError(
                        "remote finalization candidate is stored under the wrong key"
                    )
                final_path = _logical_path(final_path)
                transfer_id = str(intent.get("transfer_id"))
                token = progress.get("token")
                size_bytes = intent.get("size_bytes")
                file_digest = _remote_file_digest(intent)
                ready = state in ("ready", "leased", "consumed")
                sha256 = (
                    _digest(progress.get("sha256")) if ready
                    else intent.get("sha256")
                )
                if (
                    progress.get("transfer_id") != transfer_id
                    or isinstance(size_bytes, bool)
                    or not isinstance(size_bytes, int)
                    or not 0 <= size_bytes <= MAX_FILE_BYTES
                    or (
                        state in ("ready", "leased", "consumed")
                        and (
                            not isinstance(token, str)
                            or re.fullmatch(r"[a-f0-9]{32}", token) is None
                            or (intent.get("sha256") is not None
                                and sha256 != intent["sha256"])
                        )
                    )
                    or (
                        state in ("receiving", "cancelled")
                        and token is not None
                    )
                ):
                    raise TransferIntegrityError(
                        "remote finalization candidate metadata is invalid"
                    )
                candidates.append(
                    RemoteFinalizationCandidate(
                        name,
                        logical_path,
                        final_path,
                        transfer_id,
                        str(token) if token is not None else None,
                        str(state),
                        size_bytes,
                        sha256,
                        file_digest,
                    )
                )
            next_after = (
                selected[-1] if len(selected) == limit and start + limit < len(names) else None
            )
            return tuple(candidates), next_after

    def discard_abandoned_remote(
        self,
        logical_path: str,
        *,
        transfer_id: str,
        final_path: str,
        size_bytes: int,
        sha256: str | None = None,
        file_digest: str | None = None,
    ) -> bool:
        """Remove one exact obsolete partial remote assembly.

        Local snapshots are deliberately ineligible: they may be the only
        durable copy of user-authored bytes. The coordinator must separately
        prove the remote apply intent retired and this immutable remote object
        no longer owns ``final_path`` before calling this method.
        """

        logical_path = _logical_path(logical_path)
        final_path = _logical_path(final_path)
        expected_digest = _digest(file_digest if file_digest is not None else sha256)
        if (
            isinstance(size_bytes, bool)
            or not isinstance(size_bytes, int)
            or not 0 <= size_bytes <= MAX_FILE_BYTES
        ):
            raise ValueError("size_bytes is outside the transfer bound")
        try:
            normalized_transfer_id = str(uuid.UUID(transfer_id))
        except (AttributeError, TypeError, ValueError):
            raise ValueError("transfer_id is invalid") from None
        if normalized_transfer_id != transfer_id:
            raise ValueError("transfer_id is invalid")

        with self._reservation_guard():
            job_dir = self._job_dir(logical_path)
            if not job_dir.exists():
                return False
            intent = _read_json(job_dir / "intent.json", MAX_INTENT_BYTES)
            progress = _read_json(job_dir / "progress.json", MAX_PROGRESS_BYTES)
            if (
                intent.get("kind") != "remote_assembly"
                or intent.get("logical_path") != logical_path
                or intent.get("transfer_id") != transfer_id
                or intent.get("final_path") != final_path
                or intent.get("size_bytes") != size_bytes
                or _remote_file_digest(intent) != expected_digest
                or progress.get("transfer_id") != transfer_id
                or progress.get("kind") != "remote_assembly"
                or progress.get("state") not in ("receiving", "cancelled")
            ):
                raise TransferIntegrityError(
                    "abandoned remote cleanup identity is stale"
                )
            if progress.get("state") == "receiving":
                progress["state"] = "cancelled"
                progress["error"] = "remote apply intent retired before assembly completed"
                progress["updated_at_ns"] = time.time_ns()
                _atomic_json(
                    job_dir / "progress.json", progress, MAX_PROGRESS_BYTES
                )
            self._remove_owned_job(job_dir)
            return True

    def discard_finalized_remote(
        self, logical_path: str, *, transfer_id: str, token: str
    ) -> bool:
        """Best-effort exact removal after external durable publication proof."""

        logical_path = _logical_path(logical_path)
        with self._reservation_guard():
            job_dir = self._job_dir(logical_path)
            if not job_dir.exists():
                return False
            intent = _read_json(job_dir / "intent.json", MAX_INTENT_BYTES)
            progress = _read_json(job_dir / "progress.json", MAX_PROGRESS_BYTES)
            if (
                intent.get("kind") != "remote_assembly"
                or intent.get("transfer_id") != transfer_id
                or progress.get("transfer_id") != transfer_id
                or progress.get("token") != token
                or progress.get("state") not in ("ready", "leased", "consumed")
            ):
                raise TransferIntegrityError(
                    "remote finalization cleanup identity is stale"
                )
            if progress.get("state") != "consumed":
                progress["state"] = "consumed"
                _atomic_json(
                    job_dir / "progress.json", progress, MAX_PROGRESS_BYTES
                )
            self._remove_owned_job(job_dir)
            return True

    def claim_ready(self, logical_path: str, token: str) -> VerifiedStage:
        """Lease one verified stage to the namespace publisher."""

        with self._lock:
            job = self.open(logical_path)
            if job.progress.get("state") != "ready" or job.progress.get("token") != token:
                raise TransferIntegrityError("ready-stage token is stale or already claimed")
            stage = job.verified_stage()
            job.progress["state"] = "leased"
            job._write_progress()
            return stage

    def release_ready(self, logical_path: str, token: str) -> None:
        """Return a failed publication lease without discarding staged bytes."""

        with self._lock:
            job = self.open(logical_path)
            if job.progress.get("state") != "leased" or job.progress.get("token") != token:
                raise TransferIntegrityError("ready-stage lease token is stale")
            job.progress["state"] = "ready"
            job._write_progress()

    def consume_ready(self, logical_path: str, token: str) -> None:
        """Remove an exactly leased private stage after durable publication."""

        with self._reservation_guard():
            job = self.open(logical_path)
            if job.progress.get("state") != "leased" or job.progress.get("token") != token:
                raise TransferIntegrityError("ready-stage lease token is stale")
            job.verified_stage()
            job.progress["state"] = "consumed"
            job._write_progress()
            self._remove_owned_job(job.job_dir)

    def remove_terminal(self, logical_path: str, transfer_id: str) -> None:
        """Explicit manual cleanup for cancelled/quarantined private bytes."""

        with self._reservation_guard():
            job_dir = self._job_dir(_logical_path(logical_path))
            intent = _read_json(job_dir / "intent.json", MAX_INTENT_BYTES)
            progress = _read_json(job_dir / "progress.json", MAX_PROGRESS_BYTES)
            if intent.get("transfer_id") != transfer_id or progress.get("transfer_id") != transfer_id:
                raise TransferIntegrityError("terminal transfer identity is stale")
            if progress.get("state") not in ("cancelled", "quarantined"):
                raise TransferError("only cancelled or quarantined stages may be manually removed")
            self._remove_owned_job(job_dir)

    def remove_quarantine(self, archive_name: str, removal_token: str) -> None:
        """Explicitly remove one bounded recovery orphan by exact identity."""

        if not isinstance(archive_name, str) or not re.fullmatch(
            r"[A-Za-z0-9._-]{1,240}", archive_name
        ):
            raise UnsafeTransferPath("invalid quarantine archive name")
        with self._reservation_guard():
            path = self.quarantine_root / archive_name
            record = _read_json(path / "quarantine.json", MAX_ERROR_BYTES * 2)
            if record.get("removal_token") != removal_token:
                raise TransferIntegrityError("quarantine removal token is stale")
            self._remove_owned_directory(path, self.quarantine_root)

    def _remove_owned_job(self, job_dir: Path) -> None:
        if job_dir.parent != self.jobs_root or _JOB_KEY_RE.fullmatch(job_dir.name) is None:
            raise UnsafeTransferPath("refusing to remove a non-job transfer path")
        self._remove_owned_directory(job_dir, self.jobs_root)
        for logical_path, cached in tuple(self._job_cache.items()):
            if cached.job_dir == job_dir:
                if isinstance(cached, LocalSnapshotJob):
                    cached.source = None
                self._job_cache.pop(logical_path, None)
        # Directory removal is the durable proof that this job can no longer
        # reopen and ask for its source. Shared sources survive until their final
        # source-requiring job is ready, removed, or archived.
        self._release_source_for_job(job_dir)

    def _remove_owned_directory(self, job_dir: Path, expected_root: Path) -> None:
        if job_dir.parent != expected_root:
            raise UnsafeTransferPath("refusing to remove a transfer outside its owned root")
        shared_reservation: tuple[str, int] | None = None
        if self._admission_ledger is not None:
            try:
                reservation = _read_json(
                    job_dir / "reservation.json", MAX_RESERVATION_BYTES
                )
                path_key = str(reservation.get("path_key"))
                transfer_id = str(reservation.get("transfer_id"))
                shared_reservation = (
                    _shared_reservation_owner(transfer_id),
                    _reservation_size(reservation, path_key),
                )
            except (OSError, TransferError, ValueError):
                # Never release accounting from ambiguous metadata. A bounded
                # physical repair will reconcile the conservative row.
                shared_reservation = None
        allowed = {
            "intent.json",
            "reservation.json",
            "progress.json",
            "quarantine.json",
            "stage.partial",
            "stage.ready",
            # FabricSyncCoordinator may journal an upload plan/progress beside
            # a leased local snapshot while the immutable payload is owned by
            # the pending operation. They are removed only through the exact
            # ready-stage token lifecycle below.
            "stage.ready.plan.json",
            "stage.ready.progress.json",
        }
        children: list[Path] = []
        with os.scandir(job_dir) as entries:
            for entry in entries:
                if len(children) >= len(allowed) or entry.name not in allowed:
                    raise UnsafeTransferPath("owned transfer directory has an unexpected entry")
                info = directory_entry_identity_stat(entry)
                _regular_single_link(info, entry.name)
                children.append(Path(entry.path))
        # The payload goes first; a crash leaves metadata proving that this was
        # an explicitly consumed stage and bounded recovery resumes cleanup.
        children.sort(key=lambda path: 0 if path.name.startswith("stage.") else 1)
        for child in children:
            os.unlink(child)
            _fsync_dir(job_dir)
        os.rmdir(job_dir)
        _fsync_dir(expected_root)
        if shared_reservation is not None:
            self._release_shared(*shared_reservation)

    def ensure_write_capacity(self, byte_count: int) -> None:
        # Reservations were charged at intent creation. Re-check only the free
        # space reserve immediately before data I/O.
        usage = self._disk_usage(self.root)
        required_free = max(self.min_free_bytes, int(usage.total * self.min_free_fraction))
        if byte_count > max(0, usage.free - required_free):
            raise StagingQuotaExceeded("private stage no longer has enough free-space reserve")
        if self._quota_hook is not None:
            self._quota_hook("write", byte_count, 0)


class _BaseJob:
    def __init__(self, store: TransferStore, logical_path: str, intent: dict[str, Any], progress: dict[str, Any]) -> None:
        self.store = store
        self.logical_path = logical_path
        self.job_dir = store._job_dir(logical_path)
        self.intent = intent
        self.progress = progress
        self.transfer_id = str(intent["transfer_id"])
        self._lock = threading.RLock()

    @property
    def partial_path(self) -> Path:
        return self.job_dir / "stage.partial"

    @property
    def ready_path(self) -> Path:
        return self.job_dir / "stage.ready"

    def _write_progress(self) -> None:
        self.progress["updated_at_ns"] = time.time_ns()
        _atomic_json(self.job_dir / "progress.json", self.progress, MAX_PROGRESS_BYTES)

    def cancel(self, reason: str = "cancelled by caller") -> None:
        with self._lock:
            if self.progress.get("state") == "ready":
                raise TransferError("a verified stage cannot be cancelled")
            self.progress["state"] = "cancelled"
            self.progress["error"] = str(reason)[:MAX_ERROR_BYTES]
            self._write_progress()

    def _quarantine(self, reason: str) -> None:
        self.progress["state"] = "quarantined"
        self.progress["error"] = str(reason)[:MAX_ERROR_BYTES]
        try:
            self._write_progress()
        except OSError:
            pass

    def _promote(self, size_bytes: int, sha256: str) -> VerifiedStage:
        descriptor = _open_regular(self.partial_path, os.O_RDWR)
        try:
            info = os.fstat(descriptor)
            if info.st_size != size_bytes:
                raise TransferIntegrityError("complete stage has an unexpected size")
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        token = uuid.uuid4().hex
        os.replace(self.partial_path, self.ready_path)
        _fsync_dir(self.job_dir)
        ready_info = _opened_regular_stat(self.ready_path)
        self.progress.update(
            {
                "state": "ready",
                "token": token,
                "sha256": sha256,
                "durable_size": size_bytes,
                "binding": _binding_json(ready_info),
            }
        )
        self._write_progress()
        return self.verified_stage()

    def verified_stage(self) -> VerifiedStage:
        if self.progress.get("state") not in ("ready", "leased"):
            raise TransferError("transfer is not ready")
        token = self.progress.get("token")
        sha256 = self.progress.get("sha256")
        size_bytes = self.intent.get("size_bytes")
        if not isinstance(token, str) or not re.fullmatch(r"[a-f0-9]{32}", token):
            raise TransferIntegrityError("ready stage token is invalid")
        _digest(sha256)
        descriptor = _open_regular(self.ready_path, os.O_RDONLY)
        try:
            info = os.fstat(descriptor)
            if info.st_size != size_bytes or not _binding_matches(self.progress.get("binding"), info):
                raise TransferIntegrityError("ready stage no longer matches its verified stat token")
        finally:
            os.close(descriptor)
        return VerifiedStage(
            self.transfer_id, token, str(self.intent["kind"]), self.logical_path,
            self.ready_path, int(size_bytes), str(sha256),
            _remote_file_digest(self.intent) if self.intent["kind"] == "remote_assembly" else None,
        )


class RemoteAssemblyJob(_BaseJob):
    def __init__(self, store: TransferStore, logical_path: str, intent: dict[str, Any], progress: dict[str, Any], blocks: tuple[BlockSpec, ...]) -> None:
        super().__init__(store, logical_path, intent, progress)
        self.blocks = blocks

    @classmethod
    def open(cls, store: TransferStore, logical_path: str) -> "RemoteAssemblyJob":
        logical_path = _logical_path(logical_path)
        job_dir = store._job_dir(logical_path)
        intent = _read_json(job_dir / "intent.json", MAX_INTENT_BYTES)
        reservation = _read_json(
            job_dir / "reservation.json", MAX_RESERVATION_BYTES
        )
        progress = _read_json(job_dir / "progress.json", MAX_PROGRESS_BYTES)
        try:
            if intent.get("schema") != REMOTE_INTENT_SCHEMA or intent.get("kind") != "remote_assembly":
                raise TransferIntegrityError("remote intent schema is invalid")
            if intent.get("logical_path") != logical_path or progress.get("transfer_id") != intent.get("transfer_id") or progress.get("schema") != PROGRESS_SCHEMA:
                raise TransferIntegrityError("remote intent/progress identity mismatch")
            final_path = intent.get("final_path")
            if final_path is not None:
                _logical_path(final_path)
            size = intent.get("size_bytes")
            if (
                _reservation_size(reservation, job_dir.name) != size
                or reservation.get("transfer_id") != intent.get("transfer_id")
            ):
                raise TransferIntegrityError("remote reservation does not match intent")
            raw_blocks = intent.get("blocks")
            if not isinstance(raw_blocks, list):
                raise TransferIntegrityError("remote block manifest is not a list")
            blocks = tuple(BlockSpec(int(item["index"]), int(item["offset_bytes"]), int(item["size_bytes"]), str(item["sha256"])) for item in raw_blocks if isinstance(item, dict))
            if len(blocks) != len(raw_blocks):
                raise TransferIntegrityError("remote block manifest contains an invalid item")
            blocks = _validate_file_shape(size, blocks)
            _remote_file_digest(intent)
            job = cls(store, logical_path, intent, progress, blocks)
            job._recover_and_verify()
            return job
        except (KeyError, TypeError, ValueError, TransferError) as error:
            try:
                progress["state"] = "quarantined"
                progress["error"] = str(error)[:MAX_ERROR_BYTES]
                _atomic_json(job_dir / "progress.json", progress, MAX_PROGRESS_BYTES)
            except Exception:
                pass
            if isinstance(error, TransferError):
                raise
            raise TransferIntegrityError("remote transfer metadata is invalid") from error

    def _recover_and_verify(self) -> None:
        state = self.progress.get("state")
        if state not in ("receiving", "ready", "leased", "cancelled", "quarantined"):
            raise TransferIntegrityError("remote transfer state is invalid")
        completed = self.progress.get("completed_blocks")
        durable = self.progress.get("durable_size")
        if isinstance(completed, bool) or not isinstance(completed, int) or not 0 <= completed <= len(self.blocks):
            raise TransferIntegrityError("remote completed block count is invalid")
        expected_durable = min(int(self.intent["size_bytes"]), completed * BLOCK_BYTES)
        if durable != expected_durable:
            raise TransferIntegrityError("remote durable size does not match its block prefix")
        path = self.ready_path if self.ready_path.exists() else self.partial_path
        repair_tail = state == "receiving" and path == self.partial_path
        descriptor = _open_regular(path, os.O_RDWR if repair_tail else os.O_RDONLY)
        try:
            file_size = os.fstat(descriptor).st_size
            if file_size > int(self.intent["size_bytes"]) or file_size < expected_durable:
                raise TransferIntegrityError("remote stage size contradicts durable progress")
            recovered = completed
            whole_hasher = hashlib.sha256()
            for block in self.blocks:
                if block.index >= recovered and file_size < block.offset_bytes + block.size_bytes:
                    break
                data = _pread_exact(descriptor, block.size_bytes, block.offset_bytes)
                if len(data) != block.size_bytes or hashlib.sha256(data).hexdigest() != block.sha256:
                    if repair_tail and block.index >= completed:
                        break
                    raise TransferIntegrityError(f"remote staged block {block.index} is corrupt")
                whole_hasher.update(data)
                if block.index >= recovered:
                    recovered += 1
            recovered_size = min(int(self.intent["size_bytes"]), recovered * BLOCK_BYTES)
            if file_size != recovered_size:
                if not repair_tail:
                    raise TransferIntegrityError("remote stage contains a partial or unmanifested tail")
                # A crash may tear a pwrite before its progress record exists.
                # Keep the hashed prefix and discard only unjournalled bytes;
                # corruption inside the durable prefix still quarantines.
                os.ftruncate(descriptor, recovered_size)
                os.fsync(descriptor)
                self.store._record_shared_committed(self.transfer_id, os.fstat(descriptor))
            complete = recovered == len(self.blocks)
            whole_digest = whole_hasher.hexdigest()
            if complete and self.intent.get("sha256") is not None and whole_digest != self.intent["sha256"]:
                raise TransferIntegrityError("remote stage whole-file digest is invalid")
        except TransferError as error:
            self._quarantine(str(error))
            raise
        finally:
            os.close(descriptor)
        self._whole_hasher = whole_hasher
        if recovered != completed:
            self.progress.update({"completed_blocks": recovered, "durable_size": recovered_size})
            self._write_progress()
        if complete and repair_tail and self.blocks:
            # The process may die after its final data/progress fsync but
            # before the ready rename. There is no next block to drive step;
            # finish promotion here after rehashing the complete file.
            self._promote(int(self.intent["size_bytes"]), whole_digest)
            return
        if path == self.ready_path or (complete and state in ("ready", "leased")):
            if path != self.ready_path:
                raise TransferIntegrityError("ready progress exists without a ready stage")
            ready_info = _opened_regular_stat(self.ready_path)
            binding_changed = not _binding_matches(self.progress.get("binding"), ready_info)
            if state not in ("ready", "leased") or binding_changed or self.progress.get("sha256") != whole_digest:
                self.progress.update(
                    {
                        "state": "ready",
                        "token": uuid.uuid4().hex,
                        "sha256": whole_digest,
                        "binding": _binding_json(ready_info),
                    }
                )
                self._write_progress()

    def step(self, batch: Sequence[ReceivedBlock]) -> VerifiedStage | None:
        with self._lock:
            if self.progress.get("state") != "receiving":
                if self.progress.get("state") == "ready":
                    return self.verified_stage()
                raise TransferError(f"remote transfer is {self.progress.get('state')}")
            if not batch:
                if not self.blocks:
                    return self._promote(0, self._whole_hasher.hexdigest())
                raise ValueError("batch cannot be empty before transfer completion")
            if len(batch) > MAX_BATCH_BLOCKS:
                raise ValueError(
                    f"one transfer step accepts at most {MAX_BATCH_BLOCKS} blocks"
                )
            completed = int(self.progress["completed_blocks"])
            if completed + len(batch) > len(self.blocks):
                raise TransferIntegrityError("batch exceeds the manifest")
            payload_bytes = 0
            for position, received in enumerate(batch):
                expected = self.blocks[completed + position]
                if (received.index, received.offset_bytes, received.size_bytes, received.sha256) != (expected.index, expected.offset_bytes, expected.size_bytes, expected.sha256):
                    raise TransferIntegrityError("batch metadata is not the exact next manifest prefix")
                if not isinstance(received.data, bytes) or len(received.data) != expected.size_bytes:
                    raise TransferIntegrityError("block payload size is invalid")
                if hashlib.sha256(received.data).hexdigest() != expected.sha256:
                    raise TransferIntegrityError("block payload digest is invalid")
                payload_bytes += len(received.data)
            if payload_bytes > MAX_BATCH_BYTES:
                raise TransferIntegrityError("block batch exceeds the 16 MiB memory/I/O bound")
            self.store.ensure_write_capacity(payload_bytes)
            descriptor = _open_regular(self.partial_path, os.O_RDWR)
            try:
                for received in batch:
                    _pwrite_stage_block(
                        descriptor, received.data, received.offset_bytes
                    )
                # Data durability is deliberately ordered before progress.
                os.fsync(descriptor)
                self.store._record_shared_committed(
                    self.transfer_id, os.fstat(descriptor)
                )
            finally:
                os.close(descriptor)
            for received in batch:
                self._whole_hasher.update(received.data)
            completed += len(batch)
            durable_size = min(int(self.intent["size_bytes"]), completed * BLOCK_BYTES)
            self.progress.update({"completed_blocks": completed, "durable_size": durable_size})
            self._write_progress()
            if completed == len(self.blocks):
                whole_digest = self._whole_hasher.hexdigest()
                if self.intent.get("sha256") is not None and whole_digest != self.intent["sha256"]:
                    self._quarantine("complete remote stage failed whole-file digest verification")
                    raise TransferIntegrityError("complete remote stage failed whole-file digest verification")
                return self._promote(int(self.intent["size_bytes"]), whole_digest)
            return None


class LocalSnapshotJob(_BaseJob):
    def __init__(
        self,
        store: TransferStore,
        logical_path: str,
        intent: dict[str, Any],
        progress: dict[str, Any],
        source: LocalBlockSource | None,
        source_fingerprint: SourceFingerprint,
    ) -> None:
        super().__init__(store, logical_path, intent, progress)
        self.source = source
        self.source_fingerprint = source_fingerprint

    @property
    def block_count(self) -> int:
        size = int(self.intent["size_bytes"])
        return (size + BLOCK_BYTES - 1) // BLOCK_BYTES

    @classmethod
    def open(cls, store: TransferStore, logical_path: str) -> "LocalSnapshotJob":
        logical_path = _logical_path(logical_path)
        job_dir = store._job_dir(logical_path)
        intent = _read_json(job_dir / "intent.json", MAX_INTENT_BYTES)
        reservation = _read_json(
            job_dir / "reservation.json", MAX_RESERVATION_BYTES
        )
        progress = _read_json(job_dir / "progress.json", MAX_PROGRESS_BYTES)
        try:
            if intent.get("schema") != LOCAL_INTENT_SCHEMA or intent.get("kind") != "local_snapshot":
                raise TransferIntegrityError("local intent schema is invalid")
            if intent.get("logical_path") != logical_path or progress.get("transfer_id") != intent.get("transfer_id") or progress.get("schema") != PROGRESS_SCHEMA:
                raise TransferIntegrityError("local intent/progress identity mismatch")
            size = intent.get("size_bytes")
            if (
                _reservation_size(reservation, job_dir.name) != size
                or reservation.get("transfer_id") != intent.get("transfer_id")
            ):
                raise TransferIntegrityError("local reservation does not match intent")
            if isinstance(size, bool) or not isinstance(size, int) or not 0 <= size <= MAX_FILE_BYTES:
                raise TransferIntegrityError("local source size is invalid")
            source_id = _source_id(intent["source_id"])
            source_fp = _fp_from_json(intent.get("source_fingerprint"))
            if source_fp.size_bytes != size:
                raise TransferIntegrityError("local source fingerprint size mismatch")
            source = (
                None
                if progress.get("state") in ("ready", "leased")
                else store._resolve_source(source_id, logical_path)
            )
            job = cls(store, logical_path, intent, progress, source, source_fp)
            job._recover_and_verify()
            if job.progress.get("state") in ("ready", "leased"):
                # Recovery may have completed a crash window where the payload
                # rename was durable but the ready progress record was not.
                job.source = None
                store._release_source_for_job(job.job_dir)
            return job
        except (KeyError, TypeError, ValueError, TransferError) as error:
            try:
                progress["state"] = "quarantined"
                progress["error"] = str(error)[:MAX_ERROR_BYTES]
                _atomic_json(job_dir / "progress.json", progress, MAX_PROGRESS_BYTES)
            except Exception:
                pass
            if isinstance(error, TransferError):
                raise
            raise TransferIntegrityError("local snapshot metadata is invalid") from error

    def _check_source(self) -> None:
        if self.source is None:
            raise SourceDrift("anchored local source is unavailable")
        current = _checked_fingerprint(self.source.fingerprint())
        if not _same_fingerprint(current, self.source_fingerprint):
            raise SourceDrift("local source identity or metadata changed")

    def _promote(self, size_bytes: int, sha256: str) -> VerifiedStage:
        stage = super()._promote(size_bytes, sha256)
        # ``ready`` is durable before the registry is touched. A ready/leased
        # reopen deliberately uses only the immutable private stage, so this job
        # can no longer reference the caller-owned source.
        self.source = None
        self.store._release_source_for_job(self.job_dir)
        return stage

    def _read_source_block(self, offset: int, size: int) -> bytes:
        if self.source is None:
            raise SourceDrift("anchored local source is unavailable")
        data = self.source.read_block(offset, size, self.source_fingerprint)
        if not isinstance(data, bytes) or len(data) != size:
            raise SourceDrift("anchored local source returned an incomplete block")
        return data

    def _recover_and_verify(self) -> None:
        state = self.progress.get("state")
        if state not in ("copying", "ready", "leased", "cancelled", "quarantined"):
            raise TransferIntegrityError("local snapshot state is invalid")
        completed = self.progress.get("completed_blocks")
        durable = self.progress.get("durable_size")
        expected_durable = min(int(self.intent["size_bytes"]), completed * BLOCK_BYTES) if isinstance(completed, int) and not isinstance(completed, bool) else -1
        if isinstance(completed, bool) or not isinstance(completed, int) or not 0 <= completed <= self.block_count or durable != expected_durable:
            raise TransferIntegrityError("local snapshot progress is invalid")
        path = self.ready_path if self.ready_path.exists() else self.partial_path
        source_available = False
        if state != "ready" and path != self.ready_path:
            try:
                self._check_source()
                source_available = True
            except TransferError as error:
                self._quarantine(str(error))
                raise
        repair_tail = state == "copying" and path == self.partial_path and source_available
        descriptor = _open_regular(path, os.O_RDWR if repair_tail else os.O_RDONLY)
        try:
            file_size = os.fstat(descriptor).st_size
            expected_prefix = 0
            recovered = 0
            whole_hasher = hashlib.sha256()
            for index in range(completed):
                expected_size = min(BLOCK_BYTES, int(self.intent["size_bytes"]) - index * BLOCK_BYTES)
                data = _pread_exact(descriptor, expected_size, index * BLOCK_BYTES)
                source = self._read_source_block(index * BLOCK_BYTES, expected_size) if source_available else b""
                if len(data) != expected_size or (source_available and data != source):
                    raise TransferIntegrityError(f"local staged block {index} is corrupt")
                whole_hasher.update(data)
                recovered += 1
                expected_prefix += expected_size
            if file_size < expected_prefix or file_size > int(self.intent["size_bytes"]):
                raise TransferIntegrityError("local stage size contradicts durable progress")
            # Recover data fsynced just before a crash but not yet journalled by
            # comparing it with the still-identity-stable source.
            while recovered < self.block_count:
                index = recovered
                size = min(BLOCK_BYTES, int(self.intent["size_bytes"]) - index * BLOCK_BYTES)
                offset = index * BLOCK_BYTES
                if file_size < offset + size:
                    break
                staged = _pread_exact(descriptor, size, offset)
                source = self._read_source_block(offset, size) if source_available else b""
                if len(staged) != size or staged != source:
                    if repair_tail:
                        break
                    raise TransferIntegrityError("unjournalled local stage bytes do not match the source")
                whole_hasher.update(staged)
                recovered += 1
                expected_prefix += size
            if file_size != expected_prefix:
                if not repair_tail:
                    raise TransferIntegrityError("local stage contains a partial unjournalled tail")
                os.ftruncate(descriptor, expected_prefix)
                os.fsync(descriptor)
                self.store._record_shared_committed(self.transfer_id, os.fstat(descriptor))
            complete = recovered == self.block_count
            whole_digest = whole_hasher.hexdigest() if complete else None
        except TransferError as error:
            self._quarantine(str(error))
            raise
        finally:
            os.close(descriptor)
        self._whole_hasher = whole_hasher
        if recovered != completed:
            self.progress.update({"completed_blocks": recovered, "durable_size": expected_prefix})
            self._write_progress()
        if path == self.ready_path:
            if not complete:
                raise TransferIntegrityError("ready local stage is incomplete")
            ready_info = _opened_regular_stat(self.ready_path)
            binding_changed = not _binding_matches(self.progress.get("binding"), ready_info)
            if state not in ("ready", "leased") or binding_changed:
                self.progress.update(
                    {
                        "state": "ready",
                        "token": uuid.uuid4().hex,
                        "sha256": whole_digest,
                        "binding": _binding_json(ready_info),
                    }
                )
                self._write_progress()
            elif self.progress.get("sha256") != whole_digest:
                raise TransferIntegrityError("ready local snapshot digest changed")

    def step(self, *, max_blocks: int = MAX_BATCH_BLOCKS) -> VerifiedStage | None:
        if isinstance(max_blocks, bool) or not isinstance(max_blocks, int) or not 1 <= max_blocks <= MAX_BATCH_BLOCKS:
            raise ValueError(
                f"max_blocks must be between one and {MAX_BATCH_BLOCKS}"
            )
        with self._lock:
            if self.progress.get("state") != "copying":
                if self.progress.get("state") == "ready":
                    return self.verified_stage()
                raise TransferError(f"local snapshot is {self.progress.get('state')}")
            completed = int(self.progress["completed_blocks"])
            if completed == self.block_count:
                try:
                    self._check_source()
                except TransferError as error:
                    self._quarantine(str(error))
                    raise
                return self._promote(
                    int(self.intent["size_bytes"]), self._whole_hasher.hexdigest()
                )
            count = min(max_blocks, self.block_count - completed)
            try:
                self._check_source()
            except TransferError as error:
                self._quarantine(str(error))
                raise
            stage_descriptor = _open_regular(self.partial_path, os.O_RDWR)
            batch_data: list[bytes] = []
            try:
                total = 0
                for index in range(completed, completed + count):
                    offset = index * BLOCK_BYTES
                    size = min(BLOCK_BYTES, int(self.intent["size_bytes"]) - offset)
                    data = self._read_source_block(offset, size)
                    total += size
                    self.store.ensure_write_capacity(size)
                    _pwrite_stage_block(stage_descriptor, data, offset)
                    batch_data.append(data)
                self._check_source()
                # The stage is durable before any block is recorded complete.
                os.fsync(stage_descriptor)
                self.store._record_shared_committed(
                    self.transfer_id, os.fstat(stage_descriptor)
                )
            except TransferError as error:
                self._quarantine(str(error))
                raise
            finally:
                os.close(stage_descriptor)
            for data in batch_data:
                self._whole_hasher.update(data)
            completed += count
            durable = min(int(self.intent["size_bytes"]), completed * BLOCK_BYTES)
            self.progress.update({"completed_blocks": completed, "durable_size": durable})
            self._write_progress()
            if completed == self.block_count:
                try:
                    self._check_source()
                except TransferError as error:
                    self._quarantine(str(error))
                    raise
                return self._promote(
                    int(self.intent["size_bytes"]), self._whole_hasher.hexdigest()
                )
            return None

    def run_to_completion(self) -> VerifiedStage:
        while True:
            result = self.step()
            if result is not None:
                return result


class LocalCopyWorker:
    """A daemon-backed serial copy lane with exactly one outstanding job."""

    def __init__(
        self,
        *,
        blocks_per_step: int = 1,
        pace: Callable[[], None] | None = None,
    ) -> None:
        if isinstance(blocks_per_step, bool) or not isinstance(blocks_per_step, int) or not 1 <= blocks_per_step <= MAX_BATCH_BLOCKS:
            raise ValueError(
                f"blocks_per_step must be between one and {MAX_BATCH_BLOCKS}"
            )
        self.blocks_per_step = blocks_per_step
        self._pace = pace or (lambda: time.sleep(0))
        self._items: queue.Queue[
            tuple[LocalSnapshotJob, Future[VerifiedStage], threading.Event] | None
        ] = queue.Queue(maxsize=1)
        self._lock = threading.Lock()
        self._busy = False
        self._closed = False
        self._current_cancel: threading.Event | None = None
        self._stopped = threading.Event()
        self._thread = threading.Thread(target=self._run, name="meshia-local-snapshot", daemon=True)
        self._thread.start()

    def submit(
        self,
        job: LocalSnapshotJob,
        *,
        cancel_event: threading.Event | None = None,
    ) -> Future[VerifiedStage]:
        with self._lock:
            if self._closed:
                raise TransferError("local copy worker is closed")
            if self._busy:
                raise TransferBusy("local copy worker already has one outstanding job")
            self._busy = True
        future: Future[VerifiedStage] = Future()
        cancellation = cancel_event or threading.Event()
        with self._lock:
            self._current_cancel = cancellation
        self._items.put_nowait((job, future, cancellation))
        return future

    def submit_source(
        self,
        store: TransferStore,
        logical_path: str,
        source: LocalBlockSource,
    ) -> Future[VerifiedStage]:
        return self.submit(store.create_local(logical_path, source))

    def _run(self) -> None:
        try:
            while True:
                item = self._items.get()
                if item is None:
                    return
                job, future, cancellation = item
                try:
                    if future.set_running_or_notify_cancel():
                        while True:
                            if cancellation.is_set():
                                job.cancel("local copy worker cancelled")
                                raise TransferError("local copy worker cancelled")
                            result = job.step(max_blocks=self.blocks_per_step)
                            if result is not None:
                                future.set_result(result)
                                break
                            self._pace()
                except BaseException as error:
                    future.set_exception(error)
                finally:
                    with self._lock:
                        self._busy = False
                        self._current_cancel = None
                    self._items.task_done()
                with self._lock:
                    if self._closed:
                        return
        finally:
            self._stopped.set()

    def cancel_current(self) -> bool:
        """Request cooperative cancellation at the next 4 MiB block boundary."""

        with self._lock:
            if self._current_cancel is None:
                return False
            self._current_cancel.set()
            return True

    def close(self, *, timeout: float = 1.0) -> bool:
        with self._lock:
            self._closed = True
            busy = self._busy
        if not busy:
            try:
                self._items.put_nowait(None)
            except queue.Full:
                pass
        return self._stopped.wait(max(0.0, timeout))


class DirectByteWorkerPool:
    """At most ``MAX_BATCH_BLOCKS`` daemon byte readers, bounded by timeout.

    The helper owns no client, credentials, URL, or signing primitive.  Its
    callbacks are a data-plane seam only.  A stuck callback retains one of the
    slot but cannot make ``fetch_batch`` wait beyond ``timeout`` and repeated
    calls can never retain more than ``MAX_BATCH_BLOCKS`` stuck workers.
    """

    def __init__(self, *, max_workers: int = MAX_BATCH_BLOCKS) -> None:
        if isinstance(max_workers, bool) or not isinstance(max_workers, int) or not 1 <= max_workers <= MAX_BATCH_BLOCKS:
            raise ValueError(
                f"max_workers must be between one and {MAX_BATCH_BLOCKS}"
            )
        self.max_workers = max_workers
        self._slots = threading.BoundedSemaphore(max_workers)
        self._lock = threading.Lock()
        self._active = 0

    @property
    def active_workers(self) -> int:
        with self._lock:
            return self._active

    def fetch_batch(self, tasks: Sequence[DirectByteTask], *, timeout: float) -> DirectBatchResult:
        if len(tasks) > MAX_BATCH_BLOCKS:
            raise ValueError(
                f"one direct batch accepts at most {MAX_BATCH_BLOCKS} blocks"
            )
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or timeout < 0:
            raise ValueError("timeout must be a non-negative number")
        results: queue.Queue[tuple[int, VerifiedDirectBlock | None, str | None]] = queue.Queue(maxsize=len(tasks) or 1)
        started: list[int] = []
        unstarted: list[int] = []

        def run(position: int, task: DirectByteTask) -> None:
            verified: VerifiedDirectBlock | None = None
            error_text: str | None = None
            try:
                data = task.read()
                if not isinstance(data, bytes):
                    raise TransferIntegrityError("direct reader did not return bytes")
                if len(data) != task.block.size_bytes:
                    raise TransferIntegrityError("direct block size is invalid")
                if hashlib.sha256(data).hexdigest() != task.block.sha256:
                    raise TransferIntegrityError("direct block digest is invalid")
                verified = VerifiedDirectBlock(task.block, data)
            except BaseException as error:
                error_text = f"{type(error).__name__}: {error}"[:MAX_ERROR_BYTES]
            finally:
                results.put((position, verified, error_text))
                with self._lock:
                    self._active -= 1
                self._slots.release()

        for position, task in enumerate(tasks):
            if task.block.size_bytes > MAX_DIRECT_TASK_BYTES or task.block.size_bytes < 0:
                raise ValueError("direct task size must fit one CAS block (64 MiB)")
            if not self._slots.acquire(blocking=False):
                unstarted.append(position)
                continue
            with self._lock:
                self._active += 1
            started.append(position)
            threading.Thread(target=run, args=(position, task), name=f"meshia-direct-byte-{position}", daemon=True).start()

        deadline = time.monotonic() + float(timeout)
        received: dict[int, VerifiedDirectBlock] = {}
        failures: dict[int, str] = {}
        pending = set(started)
        while pending:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                position, verified, error_text = results.get(timeout=remaining)
            except queue.Empty:
                break
            pending.discard(position)
            if verified is not None:
                received[position] = verified
            else:
                failures[position] = error_text or "direct byte worker failed"
        return DirectBatchResult(
            completed=tuple(received[index] for index in sorted(received)),
            failures=failures,
            timed_out=tuple(sorted(pending)),
            unstarted=tuple(unstarted),
        )
