"""Windows file-privacy helpers: the DACL analogs of ``chmod 0700``/``0600``.

POSIX private state is a mode check away. On Windows ``os.chmod`` only toggles
the read-only attribute, so "private" must be expressed as a DACL: inheritance
removed, access granted to the owning user (plus SYSTEM and Administrators,
who could read the bytes regardless — pretending otherwise would be theater).

Three exports:

* :func:`ensure_owner_restricted` — make a file or directory private (``icacls``,
  cached per process so hot paths never re-spawn it);
* :func:`is_owner_restricted` — verify the object is owned by the current user
  and every allow ACE belongs to that user, SYSTEM, or Administrators, the
  analog of an owner-matched ``mode & 0o077 == 0``;
* :func:`set_workspace_low_label` — give the workspace tree an inheritable
  low-integrity mandatory label so a low-IL exec child (see
  :mod:`meshia_node.winconfine`) can write beneath it and nowhere else.

Everything is gated on ``sys.platform == "win32"``; on other platforms the
checks return benign values and the mutators are refused, mirroring how
:mod:`meshia_node.landlock` behaves off Linux.
"""

from __future__ import annotations

import ctypes
import os
import subprocess
import sys
from pathlib import Path

MARKER = "meshia-winsec"

SYSTEM_SID = "S-1-5-18"
ADMINISTRATORS_SID = "S-1-5-32-544"
_OWNER_RIGHTS_SID = "S-1-3-4"

# Every Windows ACE type that grants access. The simple type is parsed below.
# The object/callback/compound variants have different layouts and are not
# produced by our exact icacls grants, so their presence fails closed rather
# than risking a SID-offset parsing mistake.
_ALLOW_ACE_TYPES = frozenset((0x00, 0x04, 0x05, 0x09, 0x0B))

_restricted_cache: set[str] = set()


class WinsecUnavailable(Exception):
    """A Windows security operation was attempted off Windows or failed."""


def _require_windows() -> None:
    if sys.platform != "win32":
        raise WinsecUnavailable(f"{MARKER}: Windows-only operation on {sys.platform}")


def current_user_sid() -> str:
    """The string SID of the process owner (e.g. ``S-1-5-21-…``)."""
    _require_windows()
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)  # type: ignore[attr-defined]
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    # A 64-bit HANDLE must never be marshalled as ctypes' default 32-bit int:
    # GetCurrentProcess() returns (HANDLE)-1 and truncation makes every call fail
    # with ERROR_INVALID_HANDLE. See meshia_node.winconfine._declare_win32.
    kernel32.GetCurrentProcess.restype = ctypes.c_void_p
    kernel32.GetCurrentProcess.argtypes = []
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    advapi32.OpenProcessToken.argtypes = [
        ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_void_p)
    ]
    advapi32.GetTokenInformation.argtypes = [
        ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong,
        ctypes.POINTER(ctypes.c_ulong),
    ]
    advapi32.ConvertSidToStringSidW.argtypes = [
        ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p)
    ]
    TOKEN_QUERY = 0x0008
    token = ctypes.c_void_p()
    if not advapi32.OpenProcessToken(
        kernel32.GetCurrentProcess(), TOKEN_QUERY, ctypes.byref(token)
    ):
        raise WinsecUnavailable(f"{MARKER}: OpenProcessToken failed ({ctypes.get_last_error()})")
    try:
        needed = ctypes.c_ulong(0)
        advapi32.GetTokenInformation(token, 1, None, 0, ctypes.byref(needed))  # TokenUser
        buffer = ctypes.create_string_buffer(needed.value)
        if not advapi32.GetTokenInformation(token, 1, buffer, needed, ctypes.byref(needed)):
            raise WinsecUnavailable(
                f"{MARKER}: GetTokenInformation failed ({ctypes.get_last_error()})"
            )
        # TOKEN_USER begins with SID_AND_ATTRIBUTES; its first pointer is the SID.
        sid_pointer = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_void_p)).contents
        string_sid = ctypes.c_wchar_p()
        if not advapi32.ConvertSidToStringSidW(sid_pointer, ctypes.byref(string_sid)):
            raise WinsecUnavailable(
                f"{MARKER}: ConvertSidToStringSidW failed ({ctypes.get_last_error()})"
            )
        try:
            return str(string_sid.value)
        finally:
            kernel32.LocalFree(string_sid)
    finally:
        kernel32.CloseHandle(token)


def _run_icacls(arguments: list[str]) -> None:
    completed = subprocess.run(  # noqa: S603 - fixed binary, argv list
        ["icacls", *arguments],
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    if completed.returncode != 0:
        raise WinsecUnavailable(
            f"{MARKER}: icacls {arguments[1] if len(arguments) > 1 else ''} failed: "
            f"{(completed.stderr or completed.stdout).strip()[:300]}"
        )


def ensure_owner_restricted(path: Path | str) -> None:
    """Remove inherited ACEs and grant only the owner (+SYSTEM/Administrators).

    Idempotent and cached per process: state directories are secured once at
    startup, then every ``write_private_file`` under them inherits the
    restricted DACL for free instead of paying an ``icacls`` spawn per write.
    """
    _require_windows()
    target = str(Path(path))
    if target not in _restricted_cache:
        sid = current_user_sid()
        # icacls inheritance flags apply only to directories. On files it
        # silently omits these grants while /inheritance:r removes the old
        # ACEs, leaving an empty DACL that denies even the owning user.
        grant = "(OI)(CI)F" if Path(target).is_dir() else "F"
        _run_icacls(
            [
                target,
                "/inheritance:r",
                "/grant:r",
                f"*{sid}:{grant}",
                "/grant:r",
                f"*{SYSTEM_SID}:{grant}",  # SYSTEM
                "/grant:r",
                f"*{ADMINISTRATORS_SID}:{grant}",  # Administrators
                "/q",
            ]
        )
        # An elevated creator can leave the well-known OWNER RIGHTS allow ACE
        # behind even after inherited grants are removed. It is redundant once
        # the exact current-user grant is installed, and our privacy contract
        # intentionally permits only that user, SYSTEM, and Administrators.
        # Remove it instead of weakening the verifier's allowlist.
        _run_icacls([target, "/remove:g", f"*{_OWNER_RIGHTS_SID}", "/q"])
    # The cache avoids an expensive process spawn; it is never privacy proof.
    # Re-read the live DACL after mutation and on every cached use so every
    # direct caller—not only ensure_private_dir—fails closed if an existing
    # explicit ACE survived icacls or the object was widened later.
    if not is_owner_restricted(target):
        _restricted_cache.discard(target)
        raise WinsecUnavailable(
            f"{MARKER}: the live Windows owner/DACL is not restricted to the "
            "current user, SYSTEM, and Administrators"
        )
    _restricted_cache.add(target)


def _allow_ace_sids_are_owner_restricted(allow_sids: list[str], owner_sid: str) -> bool:
    """Pure policy seam used by the live DACL reader and cross-platform tests."""

    allowed = {owner_sid, SYSTEM_SID, ADMINISTRATORS_SID}
    # An empty DACL denies all access. Its lack of foreign grants must not
    # advertise unusable state as private: our exact owner must be granted.
    return owner_sid in allow_sids and all(sid in allowed for sid in allow_sids)


def _descriptor_sids_are_owner_restricted(
    descriptor_owner_sid: str, current_owner_sid: str, allow_sids: list[str]
) -> bool:
    """Require both current-user ownership and the exact allow-ACE policy."""

    return (
        descriptor_owner_sid == current_owner_sid
        and _allow_ace_sids_are_owner_restricted(allow_sids, current_owner_sid)
    )


def is_owner_restricted(path: Path | str) -> bool:
    """True for a current-user-owned object granting its owner and no foreign SID.

    This is the Windows analog of the POSIX ``mode & 0o077`` check: the answer
    comes from the live owner and DACL (``GetNamedSecurityInfoW``), not from a
    cache, so a foreign owner or a key widened to any other SID is caught the
    same way a wrong-owner/chmod-666 key is on Linux. Deny ACEs do not grant
    access and are therefore allowed.
    """
    if sys.platform != "win32":
        return False
    try:
        owner_sid = current_user_sid()
    except Exception:
        return False
    descriptor = _read_windows_owner_dacl(path)
    return descriptor is not None and _descriptor_sids_are_owner_restricted(
        descriptor[0], owner_sid, descriptor[1]
    )


def _read_windows_owner_dacl(
    path: Path | str | None = None, *, handle: int | None = None
) -> tuple[str, list[str], int] | None:
    """Read the live owner, allowed SIDs, and total ACE count without mutation."""

    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)  # type: ignore[attr-defined]
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    SE_FILE_OBJECT = 1
    OWNER_SECURITY_INFORMATION = 0x1
    DACL_SECURITY_INFORMATION = 0x4

    class ACL(ctypes.Structure):
        _fields_ = [
            ("AclRevision", ctypes.c_ubyte),
            ("Sbz1", ctypes.c_ubyte),
            ("AclSize", ctypes.c_ushort),
            ("AceCount", ctypes.c_ushort),
            ("Sbz2", ctypes.c_ushort),
        ]

    class ACE_HEADER(ctypes.Structure):
        _fields_ = [
            ("AceType", ctypes.c_ubyte),
            ("AceFlags", ctypes.c_ubyte),
            ("AceSize", ctypes.c_ushort),
        ]

    class ACCESS_ALLOWED_ACE(ctypes.Structure):
        _fields_ = [
            ("Header", ACE_HEADER),
            ("Mask", ctypes.c_ulong),
            ("SidStart", ctypes.c_ulong),
        ]

    # ctypes otherwise assumes C ``int`` arguments and return values. That is
    # unsafe for every pointer-bearing parameter here on 64-bit Windows and can
    # turn a valid DACL into a truncated pointer, an access violation, or a
    # false privacy result. Declare the native signatures before the first call.
    reader = advapi32.GetNamedSecurityInfoW if handle is None else advapi32.GetSecurityInfo
    reader.argtypes = [
        ctypes.c_wchar_p if handle is None else ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_ulong,
        ctypes.POINTER(ctypes.c_void_p),
        ctypes.POINTER(ctypes.c_void_p),
        ctypes.POINTER(ctypes.POINTER(ACL)),
        ctypes.POINTER(ctypes.c_void_p),
        ctypes.POINTER(ctypes.c_void_p),
    ]
    reader.restype = ctypes.c_ulong
    advapi32.GetAce.argtypes = [
        ctypes.POINTER(ACL),
        ctypes.c_ulong,
        ctypes.POINTER(ctypes.c_void_p),
    ]
    advapi32.GetAce.restype = ctypes.c_int
    advapi32.ConvertSidToStringSidW.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_wchar_p),
    ]
    advapi32.ConvertSidToStringSidW.restype = ctypes.c_int
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    dacl = ctypes.POINTER(ACL)()
    descriptor_owner = ctypes.c_void_p()
    descriptor = ctypes.c_void_p()
    status = reader(
        ctypes.c_wchar_p(str(Path(path))) if handle is None else handle,
        SE_FILE_OBJECT,
        OWNER_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION,
        ctypes.byref(descriptor_owner),
        None,
        ctypes.byref(dacl),
        None,
        ctypes.byref(descriptor),
    )
    if status != 0:
        return None
    try:
        if not descriptor_owner or not dacl:  # a NULL DACL grants everyone everything
            return None
        owner_string = ctypes.c_wchar_p()
        if not advapi32.ConvertSidToStringSidW(
            descriptor_owner, ctypes.byref(owner_string)
        ):
            return None
        try:
            descriptor_owner_sid = str(owner_string.value)
        finally:
            kernel32.LocalFree(owner_string)
        allow_sids: list[str] = []
        for index in range(dacl.contents.AceCount):
            ace_pointer = ctypes.c_void_p()
            if not advapi32.GetAce(dacl, index, ctypes.byref(ace_pointer)):
                return None
            header = ctypes.cast(ace_pointer, ctypes.POINTER(ACE_HEADER)).contents
            if header.AceType not in _ALLOW_ACE_TYPES:
                continue
            if header.AceType != 0:  # unexpected granting layout: fail closed
                return None
            ace = ctypes.cast(ace_pointer, ctypes.POINTER(ACCESS_ALLOWED_ACE)).contents
            sid_address = ctypes.addressof(ace) + ACCESS_ALLOWED_ACE.SidStart.offset
            string_sid = ctypes.c_wchar_p()
            if not advapi32.ConvertSidToStringSidW(
                ctypes.c_void_p(sid_address), ctypes.byref(string_sid)
            ):
                return None
            try:
                allow_sids.append(str(string_sid.value))
            finally:
                kernel32.LocalFree(string_sid)
        return descriptor_owner_sid, allow_sids, int(dacl.contents.AceCount)
    finally:
        kernel32.LocalFree(descriptor)


def _open_repaired_private_file(path: Path, flags: int) -> int | None:
    """Recover an owned log file damaged by the old empty-DACL grant bug.

    Pin the literal single-link file without delete sharing through the ACL
    repair and reopen. Foreign owners, reparse points, and nonempty DACLs are
    never repaired. No ownership, privilege, or inherited access is acquired.
    """
    _require_windows()
    from ctypes import wintypes
    import msvcrt

    class UnicodeString(ctypes.Structure):
        _fields_ = [
            ("length", wintypes.USHORT), ("maximum", wintypes.USHORT),
            ("buffer", ctypes.c_void_p),
        ]

    class ObjectAttributes(ctypes.Structure):
        _fields_ = [
            ("length", wintypes.ULONG), ("root", wintypes.HANDLE),
            ("name", ctypes.POINTER(UnicodeString)), ("attributes", wintypes.ULONG),
            ("security", ctypes.c_void_p), ("qos", ctypes.c_void_p),
        ]

    class IoStatus(ctypes.Structure):
        _fields_ = [("status", ctypes.c_void_p), ("information", ctypes.c_size_t)]

    class FileStandardInfo(ctypes.Structure):
        _fields_ = [
            ("allocation", ctypes.c_longlong), ("size", ctypes.c_longlong),
            ("links", wintypes.ULONG), ("delete_pending", ctypes.c_ubyte),
            ("directory", ctypes.c_ubyte),
        ]

    ntdll = ctypes.WinDLL("ntdll", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    ntdll.NtOpenFile.argtypes = [
        ctypes.POINTER(wintypes.HANDLE), wintypes.ULONG, ctypes.POINTER(ObjectAttributes),
        ctypes.POINTER(IoStatus), wintypes.ULONG, wintypes.ULONG,
    ]
    ntdll.NtOpenFile.restype = ctypes.c_long
    ntdll.NtQueryInformationFile.argtypes = [
        wintypes.HANDLE, ctypes.POINTER(IoStatus), ctypes.c_void_p,
        wintypes.ULONG, wintypes.ULONG,
    ]
    ntdll.NtQueryInformationFile.restype = ctypes.c_long
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.GetFileType.argtypes = [wintypes.HANDLE]
    kernel32.GetFileType.restype = wintypes.DWORD
    kernel32.ReOpenFile.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    ]
    kernel32.ReOpenFile.restype = wintypes.HANDLE
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [
        wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p,
    ]
    advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW.restype = wintypes.BOOL
    advapi32.GetSecurityDescriptorDacl.argtypes = [
        ctypes.c_void_p, ctypes.POINTER(wintypes.BOOL),
        ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.BOOL),
    ]
    advapi32.GetSecurityDescriptorDacl.restype = wintypes.BOOL
    advapi32.SetSecurityInfo.argtypes = [
        wintypes.HANDLE, ctypes.c_int, wintypes.DWORD, ctypes.c_void_p,
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
    ]
    advapi32.SetSecurityInfo.restype = wintypes.DWORD

    # The Win32 metadata open is denied by these empty DACLs. NtOpenFile can
    # request only the owner's existing READ_CONTROL | WRITE_DAC.
    # OBJ_DONT_REPARSE rejects traversal through any reparse point; omitting
    # delete sharing pins this exact object until the returned fd owns it.
    absolute = os.path.abspath(path)
    if absolute.startswith("\\\\?\\"):
        native_path = "\\??\\" + absolute[4:]
    elif absolute.startswith("\\\\"):
        native_path = "\\??\\UNC\\" + absolute[2:]
    else:
        native_path = "\\??\\" + absolute
    encoded = native_path.encode("utf-16-le")
    if len(encoded) > 65532 or "\x00" in native_path:
        return None
    buffer = ctypes.create_string_buffer(encoded + b"\x00\x00")
    name = UnicodeString(len(encoded), len(encoded) + 2, ctypes.cast(buffer, ctypes.c_void_p))
    attributes = ObjectAttributes(
        ctypes.sizeof(ObjectAttributes), None, ctypes.pointer(name), 0x1040, None, None,
    )
    pinned, io = wintypes.HANDLE(), IoStatus()
    if ntdll.NtOpenFile(
        ctypes.byref(pinned), 0x60000, ctypes.byref(attributes), ctypes.byref(io), 3, 0x40,
    ) != 0:
        if pinned.value not in (None, ctypes.c_void_p(-1).value):
            kernel32.CloseHandle(pinned.value)
        return None
    handle = pinned.value

    def identity(target: int) -> int | None:
        standard, index = FileStandardInfo(), ctypes.c_longlong()
        if (
            kernel32.GetFileType(target) != 1
            or ntdll.NtQueryInformationFile(
                target, ctypes.byref(io), ctypes.byref(standard), ctypes.sizeof(standard), 5,
            ) != 0
            or standard.links != 1 or standard.directory or standard.delete_pending
            or ntdll.NtQueryInformationFile(
                target, ctypes.byref(io), ctypes.byref(index), ctypes.sizeof(index), 6,
            ) != 0
        ):
            return None
        return index.value

    reopened = None
    try:
        before = identity(handle)
        if before is None:
            return None
        owner = current_user_sid()
        state = _read_windows_owner_dacl(handle=handle)
        if state is None or state[0] != owner or state[2] != 0:
            return None
        _restricted_cache.discard(str(path))
        security_descriptor, dacl = ctypes.c_void_p(), ctypes.c_void_p()
        present, defaulted = wintypes.BOOL(), wintypes.BOOL()
        sddl = f"D:P(A;;FA;;;{owner})(A;;FA;;;SY)(A;;FA;;;BA)"
        if not advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW(
            sddl, 1, ctypes.byref(security_descriptor), None,
        ):
            return None
        try:
            if (
                not advapi32.GetSecurityDescriptorDacl(
                    security_descriptor, ctypes.byref(present), ctypes.byref(dacl),
                    ctypes.byref(defaulted),
                )
                or not present or not dacl
                or advapi32.SetSecurityInfo(handle, 1, 0x80000004, None, None, dacl, None) != 0
            ):
                return None
        finally:
            kernel32.LocalFree(security_descriptor)
        state = _read_windows_owner_dacl(handle=handle)
        if state is None or state[0] != owner or state[2] != 3 or set(state[1]) != {
            owner, SYSTEM_SID, ADMINISTRATORS_SID,
        }:
            return None
        access = 0xC0000000 if flags & os.O_RDWR else (
            0x40000000 if flags & os.O_WRONLY else 0x80000000
        )
        reopened = kernel32.ReOpenFile(handle, access, 3, 0x00200000)
        if reopened in (None, ctypes.c_void_p(-1).value):
            reopened = None
            return None
        if identity(reopened) != before:
            return None
        result = msvcrt.open_osfhandle(reopened, flags & ~(os.O_CREAT | os.O_EXCL))
        reopened = None  # the CRT descriptor now owns the reopened native handle
        return result
    finally:
        if reopened is not None:
            kernel32.CloseHandle(reopened)
        kernel32.CloseHandle(handle)


def set_workspace_low_label(workspace_root: Path | str) -> None:
    """Give the workspace tree an inheritable low-integrity mandatory label.

    A low-IL exec child is blocked (no-write-up) from every medium-integrity
    object on the host; labeling the workspace low — with ``(OI)(CI)``
    inheritance so files the node hydrates later inherit it too — is what
    makes the workspace the one place that child *can* write. DACLs still
    apply on top, so this widens nothing for other users' processes.
    """
    _require_windows()
    _run_icacls([str(Path(workspace_root)), "/setintegritylevel", "(OI)(CI)Low", "/t", "/q"])


__all__ = [
    "ADMINISTRATORS_SID",
    "MARKER",
    "SYSTEM_SID",
    "WinsecUnavailable",
    "current_user_sid",
    "ensure_owner_restricted",
    "is_owner_restricted",
    "set_workspace_low_label",
]
