"""In-memory mount backend and a demo bridge for FSKit development.

``MemoryWorkspaceBackend`` speaks the exact ``FabricMountBackend`` operation
contract (label-prefixed absolute paths, integer handles, POSIX errnos) with
no network, journal, or disk. Wrapped in the real
``MultiWorkspaceMountBackend`` it exercises the production routing, handle,
and root-rename layers, which is what the FSKit bridge tests and the local
FSKit live proof need before the extension is wired to a real service.

``python -m meshia_node.fskit_demo`` serves such a backend on a socket and,
optionally, mounts each workspace as its own FSKit volume through the same
volume manager the service uses.
"""

from __future__ import annotations

import argparse
import errno
import os
import signal
import stat
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from .fabric_mount import _MACOS_QUARANTINE_XATTR, MountNode, MultiWorkspaceMountBackend
from .workspace import split_relative


class _MemoryFile:
    __slots__ = ("data", "modified_ns", "xattrs")

    def __init__(self, data: bytes = b"") -> None:
        self.data = bytearray(data)
        self.modified_ns = time.time_ns()
        self.xattrs: dict[str, bytes] = {}


class MemoryWorkspaceBackend:
    """One workspace projected from a dictionary; every rule is explicit.

    Errors are the same POSIX errnos the Fabric backend raises: ENOENT,
    EEXIST, ENOTEMPTY, EISDIR, ENOTDIR, ENOSPC (quota), EACCES (paths in
    ``read_only``), and ESTALE (paths in ``stale``, simulating a workspace
    whose remote authority moved on).
    """

    def __init__(
        self,
        name: str,
        *,
        files: dict[str, bytes] | None = None,
        quota_bytes: int = 4 * 1024**3,
        storage_root: Path | str | None = None,
    ) -> None:
        if len(split_relative(name)) != 1:
            raise ValueError("workspace name must be one portable path component")
        self.workspace_name = name
        self.quota_bytes = int(quota_bytes)
        self.storage_root = Path(storage_root) if storage_root is not None else Path.home()
        self.logger = SimpleNamespace(record=lambda *args, **kwargs: None)
        self.read_only: set[str] = set()
        self.stale: set[str] = set()
        self._lock = threading.RLock()
        self._files: dict[str, _MemoryFile] = {}
        self._directories: set[str] = set()
        self._handles: dict[int, tuple[str, bool]] = {}
        self._next_handle = 1
        self.closed = 0
        self.operations: list[tuple[str, ...]] = []
        for path, data in (files or {}).items():
            parts = split_relative(path)
            for index in range(1, len(parts)):
                self._directories.add("/".join(parts[:index]))
            self._files["/".join(parts)] = _MemoryFile(data)

    # ------------------------------------------------------------- helpers

    def set_workspace_name(self, value: str) -> None:
        self.workspace_name = value

    def set_stage_capacity(self, capacity: Any) -> None:
        del capacity

    def statfs_capacity(self) -> tuple[int, int]:
        with self._lock:
            return self.quota_bytes, self.used_bytes()

    def used_bytes(self) -> int:
        return sum(len(entry.data) for entry in self._files.values())

    def _remote(self, path: str, *, allow_workspace: bool = False) -> str | None:
        if not isinstance(path, str) or not path.startswith("/"):
            raise OSError(errno.EINVAL, "Mounted paths must be absolute.")
        if path == "/":
            if allow_workspace:
                return None
            raise OSError(errno.EISDIR, "The Meshia root is a directory.")
        parts = split_relative(path[1:])
        if parts[0] != self.workspace_name:
            raise OSError(errno.ENOENT, "The workspace does not exist.")
        if len(parts) == 1:
            if allow_workspace:
                return None
            raise OSError(errno.EISDIR, "The workspace root is a directory.")
        remote = "/".join(parts[1:])
        if remote in self.stale or any(remote.startswith(s + "/") for s in self.stale):
            raise OSError(errno.ESTALE, "The workspace authority moved on.")
        return remote

    def _is_directory(self, remote: str) -> bool:
        if remote in self._directories:
            return True
        prefix = remote + "/"
        return any(name.startswith(prefix) for name in self._files) or any(
            name.startswith(prefix) for name in self._directories
        )

    def _require_parent(self, remote: str) -> None:
        parent = remote.rpartition("/")[0]
        if parent and not self._is_directory(parent):
            raise OSError(errno.ENOENT, "The parent directory does not exist.")
        if parent in self._files:
            raise OSError(errno.ENOTDIR, "The parent is a file.")

    def _require_writable(self, remote: str) -> None:
        if remote in self.read_only or any(
            remote.startswith(prefix + "/") for prefix in self.read_only
        ):
            raise OSError(errno.EACCES, "The path is read-only.")

    def _mtime(self) -> int:
        with self._lock:
            return max((entry.modified_ns for entry in self._files.values()), default=1)

    # ---------------------------------------------------------- operations

    def getattr(self, path: str) -> MountNode:
        with self._lock:
            remote = self._remote(path, allow_workspace=True)
            if remote is None:
                return MountNode(path, True, 0, self._mtime())
            entry = self._files.get(remote)
            if entry is not None:
                return MountNode(path, False, len(entry.data), entry.modified_ns, None)
            if self._is_directory(remote):
                return MountNode(path, True, 0, self._mtime())
            raise OSError(errno.ENOENT, "The mounted item does not exist.")

    def listdir(self, path: str) -> tuple[str, ...]:
        with self._lock:
            if path == "/":
                return (self.workspace_name,)
            node = self.getattr(path)
            if not node.is_directory:
                raise OSError(errno.ENOTDIR, "The mounted item is not a directory.")
            remote = self._remote(path, allow_workspace=True)
            prefix = "" if remote is None else remote + "/"
            names: set[str] = set()
            for candidate in list(self._files) + list(self._directories):
                if candidate.startswith(prefix) and candidate != remote:
                    rest = candidate[len(prefix):]
                    names.add(rest.split("/", 1)[0])
            return tuple(sorted(names))

    def open(self, path: str, flags: int, *, create: bool = False) -> int:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            writable = bool(flags & (os.O_WRONLY | os.O_RDWR))
            entry = self._files.get(remote)
            if entry is None:
                if remote in self._directories or self._is_directory(remote):
                    raise OSError(errno.EISDIR, "The mounted item is a directory.")
                if not (create or flags & os.O_CREAT):
                    raise OSError(errno.ENOENT, "The mounted file does not exist.")
                self._require_parent(remote)
                self._require_writable(remote)
                entry = _MemoryFile()
                self._files[remote] = entry
                self.operations.append(("create", remote))
            elif flags & os.O_EXCL and flags & os.O_CREAT:
                raise OSError(errno.EEXIST, "The mounted file already exists.")
            if writable:
                self._require_writable(remote)
            handle = self._next_handle
            self._next_handle += 1
            self._handles[handle] = (remote, writable)
            return handle

    def _entry(self, handle: int, *, writable: bool = False) -> tuple[str, _MemoryFile]:
        try:
            remote, can_write = self._handles[handle]
        except KeyError:
            raise OSError(errno.EBADF, "The mounted handle is closed.") from None
        if writable and not can_write:
            raise OSError(errno.EBADF, "The handle is read-only.")
        entry = self._files.get(remote)
        if entry is None:
            raise OSError(errno.ESTALE, "The mounted file was removed.")
        return remote, entry

    def read(self, handle: int, offset: int, size: int) -> bytes:
        with self._lock:
            _remote, entry = self._entry(handle)
            return bytes(entry.data[offset : offset + size])

    def write(self, handle: int, offset: int, data: bytes) -> int:
        with self._lock:
            _remote, entry = self._entry(handle, writable=True)
            growth = max(0, offset + len(data) - len(entry.data))
            if self.used_bytes() + growth > self.quota_bytes:
                raise OSError(errno.ENOSPC, "The workspace quota is exhausted.")
            if offset > len(entry.data):
                entry.data.extend(b"\0" * (offset - len(entry.data)))
            entry.data[offset : offset + len(data)] = data
            entry.modified_ns = time.time_ns()
            return len(data)

    def truncate(self, path: str, length: int, *, handle: int | None = None) -> None:
        with self._lock:
            if handle is not None:
                remote, entry = self._entry(handle, writable=True)
            else:
                remote = self._remote(path)
                assert remote is not None
                self._require_writable(remote)
                found = self._files.get(remote)
                if found is None:
                    if self._is_directory(remote):
                        raise OSError(errno.EISDIR, "Directories cannot be truncated.")
                    raise OSError(errno.ENOENT, "The mounted file does not exist.")
                entry = found
            if length > len(entry.data):
                if self.used_bytes() + length - len(entry.data) > self.quota_bytes:
                    raise OSError(errno.ENOSPC, "The workspace quota is exhausted.")
                entry.data.extend(b"\0" * (length - len(entry.data)))
            else:
                del entry.data[length:]
            entry.modified_ns = time.time_ns()
            self.operations.append(("truncate", remote, str(length)))

    def fsync(self, handle: int) -> None:
        with self._lock:
            self._entry(handle)

    def flush(self, handle: int) -> None:
        with self._lock:
            self._entry(handle)

    def release(self, handle: int) -> None:
        with self._lock:
            self._handles.pop(handle, None)

    def unlink(self, path: str) -> None:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            self._require_writable(remote)
            if remote not in self._files:
                if self._is_directory(remote):
                    raise OSError(errno.EISDIR, "The mounted item is a directory.")
                raise OSError(errno.ENOENT, "The mounted file does not exist.")
            del self._files[remote]
            self.operations.append(("unlink", remote))

    def mkdir(self, path: str) -> None:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            self._require_writable(remote)
            if remote in self._files or self._is_directory(remote):
                raise OSError(errno.EEXIST, "The mounted item already exists.")
            self._require_parent(remote)
            self._directories.add(remote)
            self.operations.append(("mkdir", remote))

    def rmdir(self, path: str) -> None:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            self._require_writable(remote)
            if remote in self._files:
                raise OSError(errno.ENOTDIR, "The mounted item is a file.")
            if not self._is_directory(remote):
                raise OSError(errno.ENOENT, "The mounted directory does not exist.")
            if self.listdir(path):
                raise OSError(errno.ENOTEMPTY, "The mounted directory is not empty.")
            self._directories.discard(remote)
            self.operations.append(("rmdir", remote))

    def rename(self, source_path: str, destination_path: str) -> None:
        with self._lock:
            if source_path == f"/{self.workspace_name}":
                parts = split_relative(destination_path[1:])
                if len(parts) != 1:
                    raise OSError(errno.EXDEV, "Workspace roots cannot be nested.")
                self.operations.append(("rename_root", self.workspace_name, parts[0]))
                self.workspace_name = parts[0]
                return
            source = self._remote(source_path)
            destination = self._remote(destination_path)
            assert source is not None and destination is not None
            self._require_writable(source)
            self._require_writable(destination)
            self._require_parent(destination)
            if source in self._files:
                if self._is_directory(destination):
                    raise OSError(errno.EISDIR, "The destination is a directory.")
                self._files[destination] = self._files.pop(source)
                for handle, (remote, writable) in list(self._handles.items()):
                    if remote == source:
                        self._handles[handle] = (destination, writable)
            elif self._is_directory(source):
                if destination in self._files:
                    raise OSError(errno.ENOTDIR, "The destination is a file.")
                if self._is_directory(destination) and self.listdir(destination_path):
                    raise OSError(errno.ENOTEMPTY, "The destination is not empty.")
                prefix = source + "/"
                for name in list(self._files):
                    if name.startswith(prefix):
                        self._files[destination + name[len(source):]] = self._files.pop(name)
                for name in list(self._directories):
                    if name == source or name.startswith(prefix):
                        self._directories.discard(name)
                        self._directories.add(destination + name[len(source):])
            else:
                raise OSError(errno.ENOENT, "The mounted item does not exist.")
            self.operations.append(("rename", source, destination))

    def getxattr(self, path: str, name: str, position: int = 0) -> bytes:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            entry = self._files.get(remote)
            if entry is None or name not in entry.xattrs:
                raise OSError(getattr(errno, "ENOATTR", errno.ENODATA), "No such attribute.")
            return entry.xattrs[name][position:]

    def listxattr(self, path: str) -> list[str]:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            entry = self._files.get(remote)
            return sorted(entry.xattrs) if entry is not None else []

    def setxattr(self, path: str, name: str, value: bytes, options: int, position: int = 0) -> None:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            if name != _MACOS_QUARANTINE_XATTR:
                raise OSError(errno.ENOTSUP, "The extended attribute is unsupported.")
            entry = self._files.get(remote)
            if entry is None:
                raise OSError(errno.ENOTSUP, "Directory xattrs are unsupported.")
            entry.xattrs[name] = bytes(value)

    def removexattr(self, path: str, name: str) -> None:
        with self._lock:
            remote = self._remote(path)
            assert remote is not None
            entry = self._files.get(remote)
            if entry is None or name not in entry.xattrs:
                raise OSError(getattr(errno, "ENOATTR", errno.ENODATA), "No such attribute.")
            del entry.xattrs[name]

    def close(self) -> None:
        self.closed += 1

    # ---------------------------------------------------------- inspection

    def snapshot(self) -> dict[str, bytes]:
        with self._lock:
            return {name: bytes(entry.data) for name, entry in self._files.items()}


def memory_mount_backend(
    storage_root: Path | str,
    workspaces: dict[str, MemoryWorkspaceBackend],
    *,
    logger: Any = None,
) -> MultiWorkspaceMountBackend:
    """Wrap memory workspaces in the production multi-workspace router."""

    if logger is None:
        return MultiWorkspaceMountBackend(storage_root, workspaces)
    return MultiWorkspaceMountBackend(storage_root, workspaces, logger=logger)


def _parse_size(value: str) -> int:
    units = {"": 1, "b": 1, "k": 1024, "kib": 1024, "m": 1024**2, "mib": 1024**2,
             "g": 1024**3, "gib": 1024**3, "t": 1024**4, "tib": 1024**4}
    text = value.strip().lower()
    number = text.rstrip("kmgtib")
    unit = text[len(number):]
    if unit not in units:
        raise argparse.ArgumentTypeError(f"unknown size unit in {value!r}")
    return int(float(number) * units[unit])


def _parse_volume(value: str) -> tuple[str, int]:
    name, _sep, size = value.partition(":")
    return name, _parse_size(size or "4GiB")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m meshia_node.fskit_demo",
        description="Serve in-memory workspaces over the FSKit bridge socket.",
    )
    parser.add_argument("--socket", help="Bridge socket path (default: the app-group socket).")
    parser.add_argument(
        "--volume",
        action="append",
        type=_parse_volume,
        metavar="NAME[:QUOTA]",
        help="A workspace volume with its quota, e.g. Research:4GiB (repeatable).",
    )
    parser.add_argument(
        "--seed-bytes",
        type=_parse_size,
        default=_parse_size("64MiB"),
        help="Size of the seeded benchmark file in every volume (default 64MiB).",
    )
    parser.add_argument(
        "--mount-root",
        help="Mount each volume as an FSKit volume under this directory.",
    )
    parser.add_argument(
        "--state",
        help="Mount receipt path for the volume manager (default under the mount root).",
    )
    args = parser.parse_args(argv)
    from .fskit_mount import FSKitBridgeAddress, FSKitVolumeManager, default_fskit_address

    address = (
        FSKitBridgeAddress(Path(args.socket).expanduser())
        if args.socket
        else default_fskit_address()
    )
    volumes = args.volume or [("Research", _parse_size("4GiB")), ("Papers", _parse_size("1GiB"))]
    seed = os.urandom(1024 * 1024) * max(1, args.seed_bytes // (1024 * 1024))
    workspaces = {
        name: MemoryWorkspaceBackend(
            name,
            quota_bytes=quota,
            files={
                "README.md": f"# {name}\n\nIn-memory Meshia demo workspace.\n".encode(),
                "bench/random-64MiB.bin": seed[: args.seed_bytes],
                "notes/todo.txt": b"- prove FSKit\n",
            },
        )
        for name, quota in volumes
    }
    from .fskit_bridge import FSKitBridgeServer
    from .log import NodeLogger

    logger = NodeLogger(path=None, echo=sys.stderr)
    root = Path(args.mount_root).expanduser() if args.mount_root else Path.home() / "MeshiaFS-demo"
    backend = memory_mount_backend(root.parent, workspaces, logger=logger)
    server = FSKitBridgeServer(backend, address.socket_path, logger=logger)
    server.start()
    print(f"bridge: {address.socket_path}", flush=True)
    manager: FSKitVolumeManager | None = None
    if args.mount_root:
        manager = FSKitVolumeManager(
            address,
            server.volumes,
            mount_root=root,
            state_path=Path(args.state).expanduser() if args.state else root.parent / f".{root.name}.fskit-state.json",
            logger=logger,
        )
        mounted = manager.reconcile()
        for volume in manager.mounted_volumes():
            print(f"mounted: {volume.name} -> {volume.mount_point}", flush=True)
        if not mounted:
            print("no volumes mounted", flush=True)
    stop = threading.Event()

    def _stop(*_signal: object) -> None:
        stop.set()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)
    try:
        while not stop.wait(1.0):
            if manager is not None:
                manager.reconcile()
    finally:
        if manager is not None:
            manager.close()
        server.close()
        backend.close()
        print("stopped", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
