"""Landlock confinement: an exec'd child may WRITE only under the workspace.

`limited` access means the session orchestrator can run code on this machine but
that code must not be able to modify anything outside the synchronized
workspace. Path checks in :mod:`meshia_node.workspace` cover what the *node*
does; they say nothing about what an exec'd child does with its own syscalls.
Landlock (Linux 5.13+, an unprivileged LSM) is what actually contains the child.
The ordinary policy grants the full access set beneath the workspace and only
the read-ish subset beneath ``/``. When private node-state roots must be hidden,
the read grant is instead split across the filesystem hierarchies around those
roots, with the workspace added back explicitly. This is an allowlist because
rules encountered in one Landlock layer are additive: a narrow rule cannot
subtract access granted by a broader ``/`` rule. The restriction is installed
with ``landlock_restrict_self`` in the forked child just before ``exec``, is
inherited by everything the child spawns, and can never be dropped.

There are no libc wrappers for the three ``landlock_*`` syscalls, so this module
issues them through ``ctypes`` + ``syscall(2)``. Everything is gated on
``sys.platform == "linux"`` and a known architecture *before* any raw syscall is
attempted — issuing syscall 444 on a non-Linux kernel would mean something else
entirely, so on macOS this module reports "unavailable" without touching the
kernel at all, and the caller fails closed.

Reference: Documentation/userspace-api/landlock.rst and
include/uapi/linux/landlock.h.
"""

from __future__ import annotations

import ctypes
import errno
import os
import platform
import stat
import sys
from typing import Callable, Sequence

# Every error surfaced from this module is tagged, so a confinement failure stays
# identifiable in a node log or a command result once it has been flattened to a
# string. CPython reduces any preexec_fn exception to a generic message, so the
# executor forwards the real reason over its own status pipe rather than relying
# on this; the tag is what makes that reason unambiguous when it arrives.
MARKER = "meshia-landlock"

PR_SET_NO_NEW_PRIVS = 38
LANDLOCK_CREATE_RULESET_VERSION = 1 << 0
LANDLOCK_RULE_PATH_BENEATH = 1

# --------------------------------------------------------------- access bits
# include/uapi/linux/landlock.h. The ABI version that introduced each bit is in
# the trailing comment; anything newer than the running kernel must be masked
# off or landlock_create_ruleset() rejects the whole ruleset with EINVAL.
ACCESS_FS_EXECUTE = 1 << 0  # ABI 1
ACCESS_FS_WRITE_FILE = 1 << 1
ACCESS_FS_READ_FILE = 1 << 2
ACCESS_FS_READ_DIR = 1 << 3
ACCESS_FS_REMOVE_DIR = 1 << 4
ACCESS_FS_REMOVE_FILE = 1 << 5
ACCESS_FS_MAKE_CHAR = 1 << 6
ACCESS_FS_MAKE_DIR = 1 << 7
ACCESS_FS_MAKE_REG = 1 << 8
ACCESS_FS_MAKE_SOCK = 1 << 9
ACCESS_FS_MAKE_FIFO = 1 << 10
ACCESS_FS_MAKE_BLOCK = 1 << 11
ACCESS_FS_MAKE_SYM = 1 << 12
ACCESS_FS_REFER = 1 << 13  # ABI 2
ACCESS_FS_TRUNCATE = 1 << 14  # ABI 3
ACCESS_FS_IOCTL_DEV = 1 << 15  # ABI 5

# Accesses that only observe the filesystem. `EXECUTE` is here because reading a
# program in order to run it is a read; confinement is about writes. `IOCTL_DEV`
# is here because a device ioctl is not a filesystem mutation, and denying it
# breaks ordinary things (terminal queries) for no containment gain.
READ_ONLY_ACCESS = ACCESS_FS_EXECUTE | ACCESS_FS_READ_FILE | ACCESS_FS_READ_DIR | ACCESS_FS_IOCTL_DEV

# Accesses that change the filesystem. These are granted beneath the workspace
# and nowhere else, which is the whole point of `limited` access.
WRITE_ACCESS = (
    ACCESS_FS_WRITE_FILE
    | ACCESS_FS_REMOVE_DIR
    | ACCESS_FS_REMOVE_FILE
    | ACCESS_FS_MAKE_CHAR
    | ACCESS_FS_MAKE_DIR
    | ACCESS_FS_MAKE_REG
    | ACCESS_FS_MAKE_SOCK
    | ACCESS_FS_MAKE_FIFO
    | ACCESS_FS_MAKE_BLOCK
    | ACCESS_FS_MAKE_SYM
    | ACCESS_FS_REFER
    | ACCESS_FS_TRUNCATE
)
ALL_ACCESS = READ_ONLY_ACCESS | WRITE_ACCESS
_FILE_ACCESS = (
    ACCESS_FS_EXECUTE
    | ACCESS_FS_WRITE_FILE
    | ACCESS_FS_READ_FILE
    | ACCESS_FS_TRUNCATE
    | ACCESS_FS_IOCTL_DEV
)

# Highest filesystem access bit each ABI understands. ABI 4 added networking and
# ABI 6 added scoping, neither of which adds a filesystem bit.
_ACCESS_FS_MASK_BY_ABI = {
    1: (1 << 13) - 1,  # …MAKE_SYM
    2: (1 << 14) - 1,  # …REFER
    3: (1 << 15) - 1,  # …TRUNCATE
    4: (1 << 15) - 1,
}
_ACCESS_FS_MASK_LATEST = (1 << 16) - 1  # ABI 5+ …IOCTL_DEV

# (create_ruleset, add_rule, restrict_self). Landlock landed in one slot on the
# generic syscall table, so both supported architectures share these numbers.
_SYSCALL_NUMBERS: dict[str, tuple[int, int, int]] = {
    "x86_64": (444, 445, 446),
    "amd64": (444, 445, 446),
    "aarch64": (444, 445, 446),
    "arm64": (444, 445, 446),
}

_UNSUPPORTED_ERRNOS = (errno.ENOSYS, errno.EOPNOTSUPP, errno.EPERM, errno.EINVAL)

# Landlock only needs a reference to the directory, not access to it, which is
# exactly what O_PATH is for. The fallback keeps this importable off Linux (where
# `apply` never runs anyway) rather than raising at module scope.
_RULE_OPEN_FLAGS = (
    getattr(os, "O_PATH", os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    | getattr(os, "O_CLOEXEC", 0)
)


class LandlockUnavailable(Exception):
    """Landlock cannot confine a child on this host."""


class _RulesetAttr(ctypes.Structure):
    """``struct landlock_ruleset_attr``, truncated to its first field.

    The kernel accepts any size at or beyond ``offsetofend(handled_access_fs)``
    and zero-fills the rest, so an 8-byte attribute is valid on every ABI and we
    never have to grow this struct to match a newer kernel.
    """

    _fields_ = [("handled_access_fs", ctypes.c_uint64)]


class _PathBeneathAttr(ctypes.Structure):
    """``struct landlock_path_beneath_attr``.

    The UAPI declares this ``packed`` (size 12), while ctypes' natural layout
    pads it to 16. That is harmless and deliberately left alone: the kernel
    ``copy_from_user``s exactly its own 12 bytes, and both layouts put
    ``allowed_access`` at offset 0 and ``parent_fd`` at offset 8, so the bytes the
    kernel reads are identical. Setting ``_pack_`` would only add trailing-padding
    differences the kernel never looks at — and would drag in the ``_layout_``
    ambiguity ctypes now warns about.
    """

    _fields_ = [("allowed_access", ctypes.c_uint64), ("parent_fd", ctypes.c_int32)]


_libc_handle: ctypes.CDLL | None = None
_probe_cache: tuple[int | None, str] | None = None


def _libc() -> ctypes.CDLL:
    global _libc_handle
    if _libc_handle is None:
        handle = ctypes.CDLL(None, use_errno=True)
        handle.syscall.restype = ctypes.c_long
        handle.prctl.restype = ctypes.c_int
        _libc_handle = handle
    return _libc_handle


def _syscall_numbers() -> tuple[int, int, int] | None:
    """Syscall triple for this host, or None when raw syscalls are not safe."""
    if sys.platform != "linux":
        return None
    return _SYSCALL_NUMBERS.get(platform.machine().lower())


def _syscall(number: int, *arguments: object) -> int:
    result = _libc().syscall(ctypes.c_long(number), *arguments)
    if result < 0:
        code = ctypes.get_errno()
        raise OSError(code, f"{MARKER}: syscall {number} failed: {os.strerror(code)}")
    return int(result)


def access_fs_mask(abi: int) -> int:
    """The filesystem accesses `abi` understands."""
    return _ACCESS_FS_MASK_BY_ABI.get(abi, _ACCESS_FS_MASK_LATEST)


def probe() -> tuple[int | None, str]:
    """Return ``(abi_version, detail)``; ``abi_version`` is None when unusable.

    The ABI query is a side-effect-free ``landlock_create_ruleset(NULL, 0,
    LANDLOCK_CREATE_RULESET_VERSION)``: it allocates no ruleset and returns the
    version the kernel supports. Cached, because the answer cannot change while
    the process lives.
    """
    global _probe_cache
    if _probe_cache is not None:
        return _probe_cache
    _probe_cache = _probe()
    return _probe_cache


def _probe() -> tuple[int | None, str]:
    numbers = _syscall_numbers()
    if numbers is None:
        return None, (
            f"Landlock requires Linux on x86_64 or aarch64 "
            f"(this host is {sys.platform}/{platform.machine() or 'unknown'})"
        )
    try:
        abi = _syscall(
            numbers[0],
            None,
            ctypes.c_size_t(0),
            ctypes.c_uint32(LANDLOCK_CREATE_RULESET_VERSION),
        )
    except OSError as error:
        if error.errno == errno.ENOSYS:
            return None, "the kernel has no Landlock syscalls (requires Linux 5.13 or newer)"
        if error.errno in _UNSUPPORTED_ERRNOS:
            return None, f"Landlock is present but disabled ({os.strerror(error.errno or 0)})"
        return None, f"the Landlock ABI probe failed: {error}"
    except Exception as error:  # pragma: no cover - defensive: broken libc/ctypes
        return None, f"the Landlock ABI probe could not run: {error}"
    if abi < 1:
        return None, f"the kernel reported an unusable Landlock ABI ({abi})"
    return abi, f"Landlock ABI {abi}"


def available() -> bool:
    return probe()[0] is not None


def detail() -> str:
    """Human-readable Landlock status, usable in `doctor` output and errors."""
    return probe()[1]


def _add_path_rule(ruleset_fd: int, add_rule: int, path: str, allowed_access: int) -> None:
    """Grant the type-compatible subset of `allowed_access` beneath `path`."""
    try:
        parent_fd = os.open(path, _RULE_OPEN_FLAGS)
    except OSError as error:
        raise OSError(
            error.errno or errno.EACCES, f"{MARKER}: cannot open {path} for a rule: {error}"
        ) from error
    try:
        if not stat.S_ISDIR(os.fstat(parent_fd).st_mode):
            # Directory namespace rights make landlock_add_rule(EINVAL) for a
            # regular-file parent. Complement partitions can contain sibling
            # files, so retain only the rights the kernel defines for files.
            allowed_access &= _FILE_ACCESS
        attribute = _PathBeneathAttr(allowed_access=allowed_access, parent_fd=parent_fd)
        _syscall(add_rule, ctypes.c_int(ruleset_fd), ctypes.c_int(LANDLOCK_RULE_PATH_BENEATH),
                 ctypes.byref(attribute), ctypes.c_uint32(0))
    finally:
        os.close(parent_fd)


def _contains_path(parent: str, child: str) -> bool:
    """Whether canonical absolute `parent` contains canonical absolute `child`."""

    try:
        return os.path.commonpath((parent, child)) == parent
    except ValueError:
        return False


def _readable_roots_excluding(
    denied_roots: Sequence[str], *, tree_root: str = "/"
) -> tuple[str, ...]:
    """Partition `tree_root` into readable hierarchies outside `denied_roots`.

    Landlock grants from overlapping rules in one layer are a union, so adding a
    narrow rule with fewer rights cannot revoke the read grant from a broader
    root rule. The safe expression of "read everything except this subtree" is
    therefore to grant each sibling hierarchy while descending only through the
    ancestors of a denied root. The walk is performed in the parent process by
    :func:`confiner`; the forked child only issues async-safe-ish syscalls.

    A disappearing entry later makes rule installation fail closed. A new
    sibling outside an already-granted hierarchy stays unreadable for that one
    child, which is conservative and bounded to the command's lifetime.
    """

    root = os.path.realpath(os.path.abspath(tree_root))
    denied = tuple(
        dict.fromkeys(
            os.path.realpath(os.path.abspath(path))
            for path in denied_roots
            if os.path.exists(path)
        )
    )
    relevant = tuple(path for path in denied if _contains_path(root, path))
    if not relevant:
        return (root,)

    allowed: set[str] = set()
    pending = [root]
    visited: set[str] = set()
    while pending:
        parent = pending.pop()
        if parent in visited:
            continue
        visited.add(parent)
        if any(parent == blocked for blocked in relevant):
            continue
        try:
            entries = tuple(os.scandir(parent))
        except OSError as error:
            raise LandlockUnavailable(
                f"{MARKER}: cannot partition readable hierarchy {parent}: {error}"
            ) from error
        for entry in entries:
            candidate = os.path.realpath(entry.path)
            if any(_contains_path(blocked, candidate) for blocked in relevant):
                # The entry is the denied root or an alias into it.
                continue
            descendants = tuple(
                blocked for blocked in relevant if _contains_path(candidate, blocked)
            )
            if descendants:
                if not os.path.isdir(candidate):
                    raise LandlockUnavailable(
                        f"{MARKER}: denied hierarchy crosses non-directory {candidate}"
                    )
                pending.append(candidate)
            else:
                allowed.add(candidate)
    return tuple(sorted(allowed))


def _apply_prepared(
    workspace_root: str, readable_roots: Sequence[str]
) -> None:
    """Confine this thread: writes only beneath `workspace_root`, reads anywhere.

    `readable_roots` is either ``("/",)`` or the complement partition prepared
    around the node's private state. The workspace is always granted separately
    so the default workspace may remain nested beneath the otherwise-unreadable
    node home.

    Call this in the forked child, after ``fork`` and before ``exec``. It never
    returns a "partially applied" state: either the ruleset is enforced or an
    exception is raised, and every message carries :data:`MARKER` so the parent
    can tell a confinement failure from an ordinary spawn failure.
    """
    numbers = _syscall_numbers()
    abi, why = probe()
    if abi is None or numbers is None:
        raise LandlockUnavailable(f"{MARKER}: {why}")
    create_ruleset, add_rule, restrict_self = numbers

    # landlock_restrict_self() requires no_new_privs (or CAP_SYS_ADMIN), and we
    # want it regardless: it also stops the child gaining privilege via setuid.
    if _libc().prctl(ctypes.c_int(PR_SET_NO_NEW_PRIVS), ctypes.c_ulong(1),
                     ctypes.c_ulong(0), ctypes.c_ulong(0), ctypes.c_ulong(0)) != 0:
        code = ctypes.get_errno()
        raise OSError(code, f"{MARKER}: PR_SET_NO_NEW_PRIVS failed: {os.strerror(code)}")

    handled = ALL_ACCESS & access_fs_mask(abi)
    attribute = _RulesetAttr(handled_access_fs=handled)
    ruleset_fd = _syscall(
        create_ruleset,
        ctypes.byref(attribute),
        ctypes.c_size_t(ctypes.sizeof(attribute)),
        ctypes.c_uint32(0),
    )
    try:
        # Anything handled but not granted on a path is denied there. REFER is
        # granted on the workspace so renames *within* it keep working.
        for readable in readable_roots:
            _add_path_rule(
                ruleset_fd, add_rule, readable, READ_ONLY_ACCESS & handled
            )
        _add_path_rule(ruleset_fd, add_rule, workspace_root, handled)
        _syscall(restrict_self, ctypes.c_int(ruleset_fd), ctypes.c_uint32(0))
    finally:
        os.close(ruleset_fd)


def _prepare_policy(
    workspace_root: str, denied_roots: Sequence[str]
) -> tuple[str, tuple[str, ...]]:
    workspace = os.path.realpath(os.path.abspath(workspace_root))
    denied = tuple(
        os.path.realpath(os.path.abspath(path))
        for path in denied_roots
        if os.path.exists(path)
    )
    if any(_contains_path(workspace, blocked) for blocked in denied):
        raise LandlockUnavailable(
            f"{MARKER}: workspace cannot contain a denied node-state root"
        )
    return workspace, _readable_roots_excluding(denied)


def apply(workspace_root: str, denied_roots: Sequence[str] = ()) -> None:
    """Prepare and install a confinement policy in the current thread."""

    workspace, readable = _prepare_policy(workspace_root, denied_roots)
    _apply_prepared(workspace, readable)


def confiner(workspace_root: str, denied_roots: Sequence[str] = ()) -> Callable[[], None]:
    """A zero-argument closure suitable for ``subprocess`` ``preexec_fn``."""
    root, readable = _prepare_policy(workspace_root, denied_roots)

    def confine() -> None:  # pragma: no cover - runs in the forked child
        _apply_prepared(root, readable)

    return confine


__all__ = [
    "ALL_ACCESS",
    "MARKER",
    "READ_ONLY_ACCESS",
    "WRITE_ACCESS",
    "LandlockUnavailable",
    "access_fs_mask",
    "apply",
    "available",
    "confiner",
    "detail",
    "probe",
]
