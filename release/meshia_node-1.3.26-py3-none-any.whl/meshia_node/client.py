"""Signed-request client for connected-host protocol v1.

The signed bytes are UTF-8, no trailing newline (node/PROTOCOL.md)::

    meshia-device-request-v1
    <deployment audience>
    <expected HTTPS origin>
    <UPPERCASE METHOD>
    <normalized percent-encoded path and sorted query>
    <unix timestamp in seconds>
    <positive monotonic sequence>
    <lowercase SHA-256 hex of the exact body bytes>

Everything here mirrors ``web/lib/connected-host-auth.ts``: the same RFC 3986
unreserved set, the same query ordering, the same header names, and the same
"advance the sequence before the request starts" rule. Requests are serialised
process-wide *and* cross-process so sequences reach the server in order —
skipped sequences are fine, out-of-order ones are rejected.
"""

from __future__ import annotations

import json
import math
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from concurrent.futures import Future, TimeoutError as FutureTimeout
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from typing import Any

from .config import ConfigStore, NodeConfig, file_lock
from .http_pool import HttpsConnectionPool
from .errors import Disconnected, InvalidArgument, NetworkError, RemoteError
from .identity import KEY_ALGORITHM, DeviceIdentity
from .util import clean, json_bytes, sha256_hex

PROTOCOL_VERSION = "meshia-device-request-v1"
LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})
MAX_CLOCK_SKEW_SECONDS = 60
DEFAULT_TIMEOUT_SECONDS = 20.0
# Keep the node's allocation bound identical to the control plane's largest
# accepted JSON response.  Content-Length is only a preflight optimization: a
# peer can omit or lie about it, so every body is still read with a hard cap.
MAX_JSON_RESPONSE_BYTES = 1_450_000
MAX_RETRY_AFTER_SECONDS = 86_400
# Codes that mean "stop, this host/attachment is no longer authoritative".
REVOCATION_CODES = (
    "ATTACHMENT_INACTIVE",
    "HOST_GENERATION_STALE",
    "HOST_REVOKED",
    "WORKSPACE_STORAGE_DELETED",
    "WORKSPACE_STORAGE_DISABLED",
    "WORKSPACE_STORAGE_SUPERSEDED",
)


class _BoundedDeadlineRunner:
    """Absolute wall-clock fence around stdlib's inactivity-only timeout.

    ``urllib`` forwards its timeout to sockets, where a peer can keep a call
    alive indefinitely by trickling bytes. A timed-out syscall cannot be
    cancelled portably, so at most four daemon calls may remain underneath the
    process-wide fence; later requests fail fast instead of accumulating
    threads or holding the coordinator.
    """

    def __init__(self, max_active: int = 4) -> None:
        self._slots = threading.BoundedSemaphore(max_active)

    def run(self, function: Any, *, timeout: float) -> Any:
        if not self._slots.acquire(blocking=False):
            raise NetworkError(
                "Meshia HTTP deadline workers are still occupied by prior requests."
            )
        deadline = time.monotonic() + timeout
        future: Future[Any] = Future()

        def execute() -> None:
            try:
                if future.set_running_or_notify_cancel():
                    result = function()
                    # The caller may be descheduled before it starts waiting.
                    # A response completed after the budget is still too late.
                    if time.monotonic() >= deadline:
                        raise FutureTimeout()
                    future.set_result(result)
            except BaseException as error:
                future.set_exception(error)
            finally:
                self._slots.release()

        threading.Thread(
            target=execute, name="meshia-http-deadline", daemon=True
        ).start()
        try:
            return future.result(timeout=max(0.0, deadline - time.monotonic()))
        except FutureTimeout:
            raise NetworkError(
                "Meshia HTTP request exceeded its absolute wall-clock deadline."
            ) from None


_HTTP_DEADLINES = _BoundedDeadlineRunner()


def canonical_origin(url: str) -> str:
    """`scheme://host[:port]`, matching JavaScript's ``new URL(u).origin``."""
    parts = urllib.parse.urlsplit(url)
    scheme = (parts.scheme or "").lower()
    host = (parts.hostname or "").lower()
    if not scheme or not host:
        raise InvalidArgument(f"{url!r} is not a usable control-plane origin.")
    loopback = host in LOOPBACK_HOSTS
    if scheme != "https" and not (scheme == "http" and loopback):
        raise InvalidArgument(
            "Signed requests require HTTPS except on the local development loopback."
        )
    try:
        port = parts.port
    except ValueError as error:  # pragma: no cover - urlsplit guards most cases
        raise InvalidArgument(f"{url!r} has an invalid port.") from error
    if ":" in host:
        host = f"[{host}]"
    default_port = 443 if scheme == "https" else 80
    suffix = "" if port is None or port == default_port else f":{port}"
    return f"{scheme}://{host}{suffix}"


def validate_api_url(url: str) -> str:
    """Accept only a bare origin — the server binds enrollments to `origin`."""
    parts = urllib.parse.urlsplit(url.rstrip("/") or url)
    if parts.path not in ("", "/") or parts.query or parts.fragment:
        raise InvalidArgument("--api-url must be a bare origin such as https://meshia.example.")
    return canonical_origin(url)


def _rfc3986(value: str) -> str:
    # Python leaves exactly A-Za-z0-9_.-~ unquoted, which is the same unreserved
    # set the control plane produces via encodeURIComponent + !'()* escaping.
    return urllib.parse.quote(value, safe="", encoding="utf-8")


def canonical_path_and_query(path: str, query: str = "") -> str:
    """Normalize + validate a path/query exactly as the server re-derives it."""
    segments = path.split("/")
    normalized: list[str] = []
    for index, segment in enumerate(segments):
        if not segment:
            if index == 0 or (index == len(segments) - 1 and len(segments) == 2):
                normalized.append("")
                continue
            raise InvalidArgument("Signed request path is not canonical.")
        decoded = urllib.parse.unquote(segment, errors="strict")
        if (
            decoded in (".", "..")
            or "/" in decoded
            or "\\" in decoded
            or any(ord(character) < 0x20 or 0x7F <= ord(character) <= 0x9F for character in decoded)
            or _rfc3986(decoded) != segment
        ):
            raise InvalidArgument("Signed request path is not canonical.")
        normalized.append(segment)
    joined = "/".join(normalized) or "/"
    pairs = urllib.parse.parse_qsl(query, keep_blank_values=True, strict_parsing=bool(query))
    encoded = sorted((_rfc3986(key), _rfc3986(value)) for key, value in pairs)
    tail = "&".join(f"{key}={value}" for key, value in encoded)
    return f"{joined}?{tail}" if tail else joined


def canonical_request(
    *,
    deployment_audience: str,
    expected_https_origin: str,
    method: str,
    path_and_query: str,
    timestamp: int,
    sequence: int,
    body_sha256: str,
) -> bytes:
    return "\n".join(
        (
            PROTOCOL_VERSION,
            deployment_audience,
            expected_https_origin,
            method.upper(),
            path_and_query,
            str(timestamp),
            str(sequence),
            body_sha256,
        )
    ).encode("utf-8")


@dataclass(frozen=True)
class Response:
    status: int
    body: bytes
    # Preserve only the normalized scheduling hint. Raw response headers may
    # contain provider or proxy data and must never cross the transport seam.
    retry_after_seconds: float | None = None

    def json(self) -> Any:
        if not self.body:
            return None
        try:
            return json.loads(self.body.decode("utf-8"))
        except ValueError as error:
            raise NetworkError("Meshia returned a malformed JSON response.") from error


def _remote_document(body: bytes) -> dict[str, Any] | None:
    try:
        document = json.loads(body.decode("utf-8"))
    except Exception:
        return None
    return document if isinstance(document, dict) else None


def _remote_code(body: bytes) -> str | None:
    document = _remote_document(body)
    if document is None:
        return None
    code = document.get("code") if isinstance(document, dict) else None
    return code if isinstance(code, str) else None


def _read_response_body(reply: Any) -> bytes:
    """Read one control-plane response without trusting its framing metadata."""
    claimed_length = reply.headers.get("Content-Length")
    if claimed_length is not None:
        normalized_length = claimed_length.strip()
        if not normalized_length.isascii() or not normalized_length.isdecimal():
            raise NetworkError("Meshia returned an invalid HTTP response length.")
        significant_length = normalized_length.lstrip("0") or "0"
        maximum_length = str(MAX_JSON_RESPONSE_BYTES)
        if len(significant_length) > len(maximum_length) or (
            len(significant_length) == len(maximum_length)
            and significant_length > maximum_length
        ):
            raise NetworkError("Meshia returned an oversized HTTP response.")

    body = reply.read(MAX_JSON_RESPONSE_BYTES + 1)
    if len(body) > MAX_JSON_RESPONSE_BYTES:
        raise NetworkError("Meshia returned an oversized HTTP response.")
    return body


def _parse_retry_after(status: int, headers: Any, *, now: float) -> float | None:
    """Normalize one RFC Retry-After value without retaining raw headers.

    The connected-host limiter emits delta-seconds, while accepting an IMF-fixdate
    keeps the transport standards-compliant through ordinary HTTP proxies. Bad,
    duplicate, or excessively distant hints are ignored so an untrusted response
    cannot suppress the node indefinitely.
    """

    if status != 429:
        return None
    get_all = getattr(headers, "get_all", None)
    if callable(get_all):
        values = get_all("Retry-After", [])
    else:
        value = headers.get("Retry-After")
        values = [] if value is None else [value]
    if len(values) != 1 or not isinstance(values[0], str):
        return None
    value = values[0].strip()
    if not value or len(value) > 128 or not value.isascii():
        return None
    if value.isdecimal():
        significant = value.lstrip("0") or "0"
        ceiling = str(MAX_RETRY_AFTER_SECONDS)
        if len(significant) > len(ceiling) or (
            len(significant) == len(ceiling) and significant > ceiling
        ):
            return None
        return float(int(value))
    try:
        retry_at = parsedate_to_datetime(value)
        if retry_at.tzinfo is None:
            return None
        seconds = max(0, math.ceil(retry_at.timestamp() - now))
    except (OverflowError, TypeError, ValueError):
        return None
    return float(seconds) if seconds <= MAX_RETRY_AFTER_SECONDS else None


_CONTROL_POOL = HttpsConnectionPool(allow_insecure_loopback=True)


def _pooled_opener(request: urllib.request.Request, *, timeout: float) -> Any:
    return _CONTROL_POOL.open(request, timeout=timeout)


class HttpTransport:
    """Thin stdlib transport with explicit timeouts. No third-party HTTP stack."""

    def __init__(
        self,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        *,
        now: Any = time.time,
        opener: Any | None = None,
    ) -> None:
        if (
            isinstance(timeout, bool)
            or not isinstance(timeout, (int, float))
            or not math.isfinite(float(timeout))
            or timeout <= 0
        ):
            raise ValueError("timeout must be a positive finite number")
        self.timeout = float(timeout)
        self._now = now
        # ``opener(request, timeout=...)`` returns an HTTPResponse-like reply.
        # Production reuses TLS connections to the control plane; tests inject
        # a fake. Loopback HTTP (the fake control plane) also goes through the
        # pool so its keep-alive behaviour is exercised.
        self._opener = opener or _pooled_opener

    def open_stream(
        self, method: str, url: str, headers: dict[str, str], *, timeout: float
    ) -> Any:
        """Open one long-lived reply (SSE) and hand the caller the raw reply.

        Unlike ``send`` this never buffers the body: the caller reads lines
        until the server closes and must ``close()`` the reply. ``timeout`` is
        the per-read socket timeout, so a silent server surfaces as an error
        instead of a hang.
        """

        request = urllib.request.Request(url=url, data=None, method=method.upper())
        for name, value in headers.items():
            request.add_header(name, value)
        try:
            return self._opener(request, timeout=timeout)
        except urllib.error.HTTPError as error:
            return error
        except urllib.error.URLError as error:
            raise NetworkError(
                f"Meshia is temporarily unreachable: {clean(str(error.reason))}"
            ) from error
        except OSError as error:
            raise NetworkError(
                f"Meshia is temporarily unreachable: {clean(str(error))}"
            ) from error

    def send(
        self,
        method: str,
        url: str,
        body: bytes | None,
        headers: dict[str, str],
        *,
        timeout: float | None = None,
    ) -> Response:
        """Send one request under this transport's deadline, or ``timeout``.

        A per-call budget lets a long-running control call (a batched commit
        the server may take minutes to persist) outlive the default 20 s
        fence without loosening it for every other signed request.
        """

        if timeout is not None and (
            isinstance(timeout, bool)
            or not isinstance(timeout, (int, float))
            or not math.isfinite(float(timeout))
            or timeout <= 0
        ):
            raise ValueError("timeout must be a positive finite number")
        budget = float(timeout) if timeout is not None else self.timeout
        request = urllib.request.Request(url=url, data=body, method=method.upper())
        for name, value in headers.items():
            request.add_header(name, value)
        def blocking_request() -> Response:
            try:
                with self._opener(request, timeout=budget) as reply:
                    return Response(
                        status=reply.status,
                        body=_read_response_body(reply),
                        retry_after_seconds=_parse_retry_after(
                            reply.status, reply.headers, now=float(self._now())
                        ),
                    )
            except urllib.error.HTTPError as error:
                with error:
                    return Response(
                        status=error.code,
                        body=_read_response_body(error),
                        retry_after_seconds=_parse_retry_after(
                            error.code, error.headers, now=float(self._now())
                        ),
                    )
            except urllib.error.URLError as error:
                raise NetworkError(
                    f"Meshia is temporarily unreachable: {clean(str(error.reason))}"
                ) from error
            except OSError as error:
                raise NetworkError(
                    f"Meshia is temporarily unreachable: {clean(str(error))}"
                ) from error

        return _HTTP_DEADLINES.run(blocking_request, timeout=budget)


class EnrollmentClient:
    """Unsigned enrollment endpoints: the only requests made before a host id."""

    def __init__(self, api_url: str, transport: HttpTransport | None = None) -> None:
        self.origin = validate_api_url(api_url)
        self.transport = transport or HttpTransport()

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = json_bytes(payload)
        response = self.transport.send(
            "POST",
            f"{self.origin}/{path.lstrip('/')}",
            body,
            {"Content-Type": "application/json", "Accept": "application/json"},
        )
        if not 200 <= response.status < 300:
            raise RemoteError(
                response.status,
                _remote_code(response.body),
                f"Meshia enrollment failed (HTTP {response.status}): "
                f"{clean(response.body.decode('utf-8', 'replace'))}",
            )
        document = response.json()
        if not isinstance(document, dict):
            raise NetworkError("Meshia returned an unexpected enrollment response.")
        return document


@dataclass(frozen=True)
class PreparedRequest:
    """One signed envelope: the caller transports it, the client repairs it."""

    method: str
    url: str
    headers: dict[str, str]
    request_id: str
    sequence: int
    local_timestamp: int


class SignedClient:
    """Serialised, sequence-advancing, signed control-plane client."""

    def __init__(
        self,
        store: ConfigStore,
        identity: DeviceIdentity,
        transport: HttpTransport | None = None,
        now: Any = time.time,
        *,
        monotonic: Any = time.monotonic,
    ) -> None:
        self.store = store
        self.identity = identity
        self.transport = transport or HttpTransport()
        self._now = now
        self._monotonic = monotonic
        self._lock = threading.Lock()
        # Retry-After is authority for the authenticated host, not merely the
        # route that happened to exhaust its budget. Keep the deadline process
        # local and monotonic: raw response metadata never crosses HttpTransport,
        # and a wall-clock correction cannot shorten or extend the cooldown.
        self._rate_limit_until = 0.0

    # ------------------------------------------------------------------ helpers

    def _headers(
        self,
        config: NodeConfig,
        timestamp: int,
        sequence: int,
        signature: str,
        request_id: str | None = None,
    ) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Meshia-Host-Id": config.host_id,
            "X-Meshia-Host-Generation": str(config.generation),
            "X-Meshia-Key-Algorithm": KEY_ALGORITHM,
            "X-Meshia-Timestamp": str(timestamp),
            "X-Meshia-Sequence": str(sequence),
            "X-Meshia-Signature": signature,
        }
        if request_id is not None:
            headers["X-Meshia-Request-Id"] = request_id
        return headers

    # ------------------------------------------------------------------ request

    def _monotonic_now(self) -> float:
        value = self._monotonic()
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(float(value))
            or value < 0
        ):
            raise NetworkError("The signed-request monotonic clock is invalid.")
        return float(value)

    def _rate_limit_remaining_unlocked(self) -> float:
        return max(0.0, self._rate_limit_until - self._monotonic_now())

    @property
    def rate_limit_remaining_seconds(self) -> float:
        """Return the host cooldown without allocating a sequence or doing I/O."""

        with self._lock:
            return self._rate_limit_remaining_unlocked()

    @staticmethod
    def _local_rate_limit_error(remaining: float) -> RemoteError:
        return RemoteError(
            429,
            "RATE_LIMITED",
            "Signed control requests are cooling down after a server rate limit.",
            retry_after_seconds=remaining,
        )

    def _observe_rate_limit_unlocked(self, error: RemoteError) -> None:
        # HttpTransport supplies this field only after strict, bounded 429
        # normalization. Missing/malformed hints deliberately do not invent a
        # host cooldown; the caller's ordinary transient backoff remains active.
        if (
            error.status != 429
            or error.retry_after_seconds is None
            or error.retry_after_seconds <= 0
        ):
            return
        self._rate_limit_until = max(
            self._rate_limit_until,
            self._monotonic_now() + error.retry_after_seconds,
        )

    @staticmethod
    def _validate_path(path: str) -> str:
        relative = path.lstrip("/")
        if not relative.startswith("api/") or ".." in relative:
            raise InvalidArgument("Invalid connected-host API path.")
        return relative

    def _sign_unlocked(
        self, method: str, relative: str, payload: bytes
    ) -> PreparedRequest:
        """Allocate one sequence and sign it; callers hold both request locks."""

        request_id = str(uuid.uuid4())
        config, sequence = self.store.allocate_sequence()
        transport_origin = canonical_origin(config.api_url)
        # Behind a reverse proxy the public origin the control plane binds
        # enrollments to (and rebuilds the signed string from) can differ
        # from the transport URL. MESHIA_SIGNING_ORIGIN lets the node sign
        # that public origin while still connecting via api_url. Absent it,
        # the two are identical (the direct, non-proxied case).
        signing_override = os.environ.get("MESHIA_SIGNING_ORIGIN", "").strip()
        signing_origin = (
            canonical_origin(signing_override)
            if signing_override
            else transport_origin
        )
        url_path, _, query = relative.partition("?")
        path_and_query = canonical_path_and_query(f"/{url_path}", query)
        local_timestamp = int(self._now())
        timestamp = local_timestamp + config.clock_offset_seconds
        if not 1 <= timestamp < 10**16:
            raise NetworkError("The corrected signed-request clock is invalid.")
        signature = self.identity.sign_b64url(
            canonical_request(
                deployment_audience=config.deployment_audience,
                expected_https_origin=signing_origin,
                method=method,
                path_and_query=path_and_query,
                timestamp=timestamp,
                sequence=sequence,
                body_sha256=sha256_hex(payload),
            )
        )
        return PreparedRequest(
            method=method.upper(),
            url=f"{transport_origin}{path_and_query}",
            headers=self._headers(config, timestamp, sequence, signature, request_id),
            request_id=request_id,
            sequence=sequence,
            local_timestamp=local_timestamp,
        )

    def prepare_request(
        self, method: str, path: str, body: bytes | None = None
    ) -> PreparedRequest:
        """Sign one request for a caller that owns its own transport.

        The long-lived push stream cannot go through ``request`` (which
        buffers a bounded JSON body and holds the sequence lock for the whole
        exchange), so it takes a signed envelope here and opens the stream
        itself. Sequence allocation still happens under both locks, so a
        stream open never reorders sequences against ordinary calls.
        """

        relative = self._validate_path(path)
        payload = body if body is not None else b""
        with self._lock:
            remaining = self._rate_limit_remaining_unlocked()
            if remaining > 0:
                raise self._local_rate_limit_error(remaining)
            with file_lock(self.store.paths.request_lock):
                remaining = self._rate_limit_remaining_unlocked()
                if remaining > 0:
                    raise self._local_rate_limit_error(remaining)
                return self._sign_unlocked(method, relative, payload)

    def open_signed_stream(
        self,
        method: str,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float,
    ) -> tuple[PreparedRequest, Any]:
        """Sign and open one streaming reply without releasing the sequence lock.

        The server consumes a sequence when it authenticates the request, so a
        second request signed after this one but delivered first would make
        this one SEQUENCE_REPLAYED. Holding both locks until the response
        headers arrive (bounded by ``timeout``) keeps delivery order equal to
        allocation order, exactly like ``request``.
        """

        relative = self._validate_path(path)
        with self._lock:
            remaining = self._rate_limit_remaining_unlocked()
            if remaining > 0:
                raise self._local_rate_limit_error(remaining)
            with file_lock(self.store.paths.request_lock):
                remaining = self._rate_limit_remaining_unlocked()
                if remaining > 0:
                    raise self._local_rate_limit_error(remaining)
                prepared = self._sign_unlocked(method, relative, b"")
                merged = dict(prepared.headers)
                for name, value in (headers or {}).items():
                    # An empty value removes a default header (e.g. the JSON
                    # Content-Type a body-less stream open must not send).
                    if value == "":
                        merged.pop(name, None)
                    else:
                        merged[name] = value
                try:
                    reply = self.transport.open_stream(
                        method, prepared.url, merged, timeout=timeout
                    )
                except NetworkError as error:
                    raise NetworkError(
                        f"{error} (request_id={prepared.request_id})"
                    ) from error
                return prepared, reply

    def observe_rejection(
        self, prepared: PreparedRequest, status: int, body: bytes
    ) -> bool:
        """Apply the server's envelope repair hints for a self-transported reply.

        Returns ``True`` when the caller may retry immediately (clock offset or
        sequence advanced). Raises ``Disconnected`` for revocation codes and
        ``RemoteError`` otherwise, exactly like ``request``.
        """

        try:
            self._interpret(
                Response(status=status, body=body), request_id=prepared.request_id
            )
        except RemoteError as error:
            with self._lock:
                self._observe_rate_limit_unlocked(error)
                if self._repair_control_envelope(
                    error,
                    rejected_sequence=prepared.sequence,
                    local_timestamp=prepared.local_timestamp,
                ):
                    return True
            raise
        return False

    def request(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        *,
        timeout: float | None = None,
    ) -> Response:
        relative = self._validate_path(path)
        payload = body if body is not None else b""
        # Serialise in-process and across processes: the sequence must reach the
        # server in the order it was allocated.
        with self._lock:
            remaining = self._rate_limit_remaining_unlocked()
            if remaining > 0:
                raise self._local_rate_limit_error(remaining)
            with file_lock(self.store.paths.request_lock):
                # File-lock acquisition can be delayed by another process. Check
                # again immediately before the durable sequence allocation.
                remaining = self._rate_limit_remaining_unlocked()
                if remaining > 0:
                    raise self._local_rate_limit_error(remaining)
                for attempt in range(2):
                    prepared = self._sign_unlocked(method, relative, payload)
                    request_id = prepared.request_id
                    try:
                        response = self.transport.send(
                            method,
                            prepared.url,
                            body,
                            prepared.headers,
                            **({"timeout": timeout} if timeout is not None else {}),
                        )
                    except NetworkError as error:
                        raise NetworkError(f"{error} (request_id={request_id})") from error
                    try:
                        return self._interpret(response, request_id=request_id)
                    except RemoteError as error:
                        self._observe_rate_limit_unlocked(error)
                        if attempt == 0 and self._repair_control_envelope(
                            error,
                            rejected_sequence=prepared.sequence,
                            local_timestamp=prepared.local_timestamp,
                        ):
                            continue
                        raise
        raise AssertionError("bounded signed-request retry exhausted")  # pragma: no cover

    def _repair_control_envelope(
        self,
        error: RemoteError,
        *,
        rejected_sequence: int,
        local_timestamp: int,
    ) -> bool:
        """Apply exact HTTPS-server recovery hints for pre-route auth failures."""

        details = error.details
        if not isinstance(details, dict):
            return False
        if error.status == 401 and error.remote_code == "TIMESTAMP_OUT_OF_RANGE":
            server_time = details.get("server_time")
            if (
                isinstance(server_time, bool)
                or not isinstance(server_time, int)
                or not 1 <= server_time < 10**16
            ):
                return False
            self.store.set_clock_offset_seconds(server_time - local_timestamp)
            return True
        if error.status == 409 and error.remote_code == "SEQUENCE_REPLAYED":
            next_sequence = details.get("next_sequence")
            if (
                isinstance(next_sequence, bool)
                or not isinstance(next_sequence, int)
                or not rejected_sequence < next_sequence < 10**16
            ):
                return False
            self.store.advance_sequence_to(next_sequence)
            return True
        return False

    def _interpret(self, response: Response, request_id: str | None = None) -> Response:
        if 200 <= response.status < 300:
            return response
        code = _remote_code(response.body)
        if response.status in (403, 410) or (
            response.status == 409 and code in REVOCATION_CODES
        ):
            if code == "WORKSPACE_STORAGE_DELETED":
                message = (
                    "This workspace's remote Files storage was deleted. "
                    "Connect again from a workspace with available Files."
                )
            elif code == "WORKSPACE_STORAGE_DISABLED":
                message = (
                    "This workspace does not have remote Files storage enabled. "
                    "Connect again from a workspace with available Files."
                )
            else:
                message = "This host's remote authority was revoked or advanced."
            raise Disconnected(message, reason_code=code)
        raise RemoteError(
            response.status,
            code,
            f"Meshia request failed (HTTP {response.status}): "
            f"{clean(response.body.decode('utf-8', 'replace'))}"
            f"{f' (request_id={request_id})' if request_id else ''}",
            details=_remote_document(response.body),
            retry_after_seconds=response.retry_after_seconds,
        )

    # ----------------------------------------------------------------- verb API

    def post_json(
        self, path: str, payload: dict[str, Any], *, timeout: float | None = None
    ) -> Any:
        return self.request("POST", path, json_bytes(payload), timeout=timeout).json()

    def post_empty(self, path: str) -> Response:
        """POST with the literal `{}` body the empty-body routes require."""
        return self.request("POST", path, b"{}")

    def delete_empty(self, path: str) -> Response:
        """DELETE with a zero-byte body (the forget route rejects any body)."""
        return self.request("DELETE", path, None)
