"""Direct object-range reads with parallel readahead for the native mount.

Browser and MCP uploads are stored as whole objects under the workspace's
private prefix with no CAS block map.  Without this lane the mount reads them
through the serialized signed range lane: one 1 MiB base64 control call per
chunk, measured at 0.14-0.4 MB/s.  Here the coordinator asks the control plane
for one short-lived ``object_read`` GET ticket per file and then streams
aligned units straight from object storage, several in flight, admitting every
verified unit to the shared :class:`FabricRangeCache` so the kernel's small
follow-up reads are served locally.

The reader never owns sync truth: it reads immutable ``(digest, size)``
identities that the coordinator has already pinned to an exact manifest head,
and every failure degrades to the existing lanes for that one read.
"""

from __future__ import annotations

import hashlib
import queue
import threading
import time
from collections import OrderedDict
from concurrent.futures import Future
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol, Sequence

from .errors import NetworkError, RemoteError
from .object_edge import ObjectEdgeNotFound
from .fabric import (
    MAX_DIRECT_BLOCK_BYTES,
    OBJECT_RANGE_MAX_ACTIVE,
    OBJECT_READ_TICKET_SCHEMA,
    parse_direct_ticket_expiry,
)
from .fabric_cache import FabricRangeCache
from .log import NULL_LOGGER, NodeLogger

OBJECT_READ_UNIT_BYTES = 4 * 1024 * 1024
OBJECT_READ_MAX_PARALLEL = 6
OBJECT_READAHEAD_INITIAL_BYTES = 8 * 1024 * 1024
OBJECT_READAHEAD_MAX_BYTES = 32 * 1024 * 1024
OBJECT_TICKET_TTL_SECONDS = 300
OBJECT_TICKET_REFRESH_HEADROOM_SECONDS = 10.0
# Refresh in the background well before the demand path would have to wait.
OBJECT_TICKET_BACKGROUND_REFRESH_SECONDS = 30.0
OBJECT_READ_UNSUPPORTED_TTL_SECONDS = 60.0
OBJECT_READ_FAILURE_COOLDOWN_SECONDS = 30.0
OBJECT_READ_STREAM_PROBE_BYTES = 256 * 1024
# Below one cache chunk the single signed range call is cheaper than a ticket
# plus a transfer, and it keeps Finder's mass thumbnail opens off the ticket
# lane entirely. Open-time warming is reserved for files where the ticket
# round trip is a visible share of the first read.
OBJECT_READ_MIN_BYTES = 1024 * 1024
OBJECT_WARM_MIN_BYTES = 8 * 1024 * 1024
OBJECT_WARM_MAX_INFLIGHT = 2
# Probe-sized reads (QuickLook headers, Finder metadata) fetch a small unit so
# first-byte latency on slow links is not a whole streaming unit.
OBJECT_READ_PROBE_UNIT_BYTES = 512 * 1024
OBJECT_READ_UNIT_TIMEOUT_SECONDS = 180.0
OBJECT_READ_UNSUPPORTED_CODE = "FABRIC_OBJECT_READ_UNSUPPORTED"
OBJECT_READ_BATCH_SCHEMA = "meshia.connected_host_fabric_object_read_ticket_batch.v1"
OBJECT_READ_MAX_BATCH = 32
_MAX_TRACKED_FILES = 256
_STALE_HEAD_CODES = frozenset({"FABRIC_BLOCK_READ_CURSOR_STALE", "FABRIC_MANIFEST_CHANGED"})
_CACHE_PRESSURE_ERRNOS = frozenset({28, 122, 27})  # ENOSPC, EDQUOT, EFBIG


class ObjectReadUnavailable(Exception):
    """The direct lane cannot serve this read; use another lane."""


class ObjectReadStale(Exception):
    """The manifest head moved while the ticket was being issued."""


class _ObjectTransport(Protocol):
    def object_read(self, payload: dict[str, Any]) -> dict[str, Any]: ...
    def download_object_range(
        self, ticket: Mapping[str, Any], offset: int, length: int
    ) -> bytes: ...


class _EntryLike(Protocol):
    path: str
    size_bytes: int
    digest: str


class _HeadLike(Protocol):
    generation: int
    digest: str


@dataclass(frozen=True)
class _Ticket:
    document: Mapping[str, Any]
    expires_at: float
    generation: int
    manifest_digest: str


@dataclass
class _StreamState:
    next_offset: int
    window_bytes: int


class _UnitPool:
    """Bounded daemon workers; never blocks interpreter exit."""

    def __init__(self, max_workers: int) -> None:
        if max_workers < 1:
            raise ValueError("max_workers must be positive")
        self._max_workers = max_workers
        self._queue: queue.Queue[Callable[[], None] | None] = queue.Queue()
        self._lock = threading.Lock()
        self._threads: list[threading.Thread] = []
        self._idle = 0
        self._closed = False

    def submit(self, job: Callable[[], None]) -> None:
        with self._lock:
            if self._closed:
                raise RuntimeError("the object read pool is closed")
            self._queue.put(job)
            if self._idle == 0 and len(self._threads) < self._max_workers:
                thread = threading.Thread(
                    target=self._run,
                    name=f"meshia-object-read-{len(self._threads)}",
                    daemon=True,
                )
                self._threads.append(thread)
                thread.start()

    def _run(self) -> None:
        while True:
            with self._lock:
                self._idle += 1
            try:
                job = self._queue.get()
            finally:
                with self._lock:
                    self._idle -= 1
            if job is None:
                return
            try:
                job()
            except BaseException:  # pragma: no cover - jobs report via futures
                pass

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            threads = list(self._threads)
        for _thread in threads:
            self._queue.put(None)


class DirectObjectReader:
    """Serve immutable object ranges through presigned tickets with readahead."""

    def __init__(
        self,
        *,
        transport: _ObjectTransport,
        cache: FabricRangeCache,
        request_ticket: Callable[[dict[str, Any]], dict[str, Any]],
        attachment_id: str,
        request_ticket_batch: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
        workspace: str,
        now: Callable[[], float] = time.time,
        logger: NodeLogger = NULL_LOGGER,
        unit_bytes: int = OBJECT_READ_UNIT_BYTES,
        max_parallel: int = OBJECT_READ_MAX_PARALLEL,
        readahead_initial_bytes: int = OBJECT_READAHEAD_INITIAL_BYTES,
        readahead_max_bytes: int = OBJECT_READAHEAD_MAX_BYTES,
        unit_timeout_seconds: float = OBJECT_READ_UNIT_TIMEOUT_SECONDS,
    ) -> None:
        if not 1 <= unit_bytes <= MAX_DIRECT_BLOCK_BYTES:
            raise ValueError("unit_bytes must fit one direct transfer")
        if not 1 <= max_parallel <= OBJECT_RANGE_MAX_ACTIVE:
            raise ValueError("max_parallel must fit the object-range deadline slots")
        if readahead_initial_bytes < 0 or readahead_max_bytes < readahead_initial_bytes:
            raise ValueError("readahead window bounds are inconsistent")
        self.transport = transport
        self.cache = cache
        self._request_ticket = request_ticket
        self._request_ticket_batch = request_ticket_batch
        self._attachment_id = attachment_id
        self._workspace = workspace
        self._now = now
        self._logger = logger
        self.unit_bytes = unit_bytes
        self.readahead_initial_bytes = readahead_initial_bytes
        self.readahead_max_bytes = readahead_max_bytes
        self._unit_timeout = float(unit_timeout_seconds)
        self._pool = _UnitPool(max_parallel)
        self._lock = threading.Lock()
        self._tickets: OrderedDict[str, _Ticket] = OrderedDict()
        self._streams: OrderedDict[str, _StreamState] = OrderedDict()
        self._unsupported_until: OrderedDict[str, float] = OrderedDict()
        self._flights: dict[tuple[str, int], Future[bytes]] = {}
        self._warming: dict[str, Future[_Ticket]] = {}
        # Files the Meshia object edge could not serve (404: scaffold, packed,
        # replaced); they use signed tickets for a bounded time.
        self._edge_unsupported_until: OrderedDict[str, float] = OrderedDict()

    # ------------------------------------------------------------------ public

    @staticmethod
    def transport_supported(transport: object) -> bool:
        return callable(getattr(transport, "object_read", None)) and callable(
            getattr(transport, "download_object_range", None)
        )

    def close(self) -> None:
        self._pool.close()

    @staticmethod
    def serves(entry: _EntryLike) -> bool:
        """Whether the direct lane is worth a ticket for this entry."""

        return entry.size_bytes >= OBJECT_READ_MIN_BYTES

    def warm(self, entry: _EntryLike, head: _HeadLike) -> bool:
        """Request the file's ticket in the background (e.g. at open time).

        Returns ``True`` when a warm was scheduled. Small files, files whose
        ticket is already fresh, cooling-down files, and more than
        ``OBJECT_WARM_MAX_INFLIGHT`` concurrent warms are skipped so a burst
        of opens cannot flood the serialized signed lane.
        """

        if entry.size_bytes < OBJECT_WARM_MIN_BYTES:
            return False
        now = float(self._now())
        with self._lock:
            cached = self._tickets.get(entry.digest)
            if (
                cached is not None
                and cached.generation == head.generation
                and cached.manifest_digest == head.digest
                and cached.expires_at - now > OBJECT_TICKET_REFRESH_HEADROOM_SECONDS
            ):
                return False
            until = self._unsupported_until.get(entry.digest)
            if until is not None and until > now:
                return False
            if entry.digest in self._warming or len(self._warming) >= OBJECT_WARM_MAX_INFLIGHT:
                return False
            future: Future[_Ticket] = Future()
            self._warming[entry.digest] = future

        def job() -> None:
            try:
                future.set_result(self._ticket_for(entry, head, float(self._now())))
            except BaseException as error:  # noqa: BLE001 - joined by demand reads
                future.set_exception(error)
                future.exception()
            finally:
                with self._lock:
                    if self._warming.get(entry.digest) is future:
                        self._warming.pop(entry.digest, None)

        try:
            self._pool.submit(job)
        except RuntimeError:
            with self._lock:
                self._warming.pop(entry.digest, None)
            return False
        return True

    def read(self, entry: _EntryLike, head: _HeadLike, offset: int, length: int) -> bytes:
        """Return exactly ``length`` bytes at ``offset`` or raise a lane error.

        Raises :class:`ObjectReadUnavailable` when this lane cannot serve the
        read (unsupported entry, network failure, cooling down) and
        :class:`ObjectReadStale` when the control plane reports that the
        manifest head moved.
        """

        if offset < 0 or length < 0 or offset + length > entry.size_bytes:
            raise ValueError("the requested range exceeds the file")
        if length == 0:
            return b""
        now = float(self._now())
        with self._lock:
            until = self._unsupported_until.get(entry.digest)
            if until is not None and until > now:
                raise ObjectReadUnavailable("object reads are cooling down for this file")
            if until is not None:
                self._unsupported_until.pop(entry.digest, None)
        probe = length < OBJECT_READ_STREAM_PROBE_BYTES
        unit_bytes = min(self.unit_bytes, OBJECT_READ_PROBE_UNIT_BYTES) if probe else self.unit_bytes
        units = self._units(entry.size_bytes, offset, length, unit_bytes)
        # Sequential-stream detection decides the readahead window before any
        # network work so the prefetch can start alongside the demand fetch.
        with self._lock:
            state = self._streams.get(entry.digest)
            sequential = state is not None and (
                state.next_offset - self.unit_bytes <= offset <= state.next_offset + self.unit_bytes
            )
            if sequential and state is not None:
                window = min(self.readahead_max_bytes, max(state.window_bytes * 2, self.readahead_initial_bytes))
            else:
                # A file's first read at offset 0, or any first read that is
                # itself streaming-sized, is treated as a stream start so the
                # kernel's next request finds bytes already in flight. Small
                # probes (Finder metadata, QuickLook headers) stay cheap.
                window = (
                    self.readahead_initial_bytes
                    if offset == 0 or (state is None and length >= OBJECT_READ_STREAM_PROBE_BYTES)
                    else 0
                )
            self._streams[entry.digest] = _StreamState(
                next_offset=offset + length, window_bytes=window
            )
            self._streams.move_to_end(entry.digest)
            while len(self._streams) > _MAX_TRACKED_FILES:
                self._streams.popitem(last=False)
        ticket = self._ticket_for(entry, head, now)
        if ticket.expires_at - now < OBJECT_TICKET_BACKGROUND_REFRESH_SECONDS:
            # Renew off the demand path so a long stream never stalls on a
            # signed round trip when its ticket nears expiry.
            self._refresh_in_background(entry, head)
        futures = [self._ensure_unit(entry, head, ticket, start, size) for start, size in units]
        out = bytearray()
        for (start, size), future in zip(units, futures):
            try:
                data = future.result(timeout=self._unit_timeout)
            except Exception as first_error:  # noqa: BLE001 - retry once in the foreground
                # A unit can lose a transient race (deadline slot, connection
                # reset). One inline retry keeps a demand read on the fast
                # lane; a second failure demotes the file for a bounded time.
                try:
                    if self._is_edge_ticket(ticket) and isinstance(first_error, ObjectEdgeNotFound):
                        raise first_error
                    data = self._ensure_unit(entry, head, ticket, start, size).result(
                        timeout=self._unit_timeout
                    )
                except Exception as error:  # noqa: BLE001 - every failure demotes the lane
                    self._forget_ticket(entry.digest, ticket)
                    if self._is_edge_ticket(ticket):
                        # The edge could not serve this file (missing object,
                        # replaced bytes, or an edge fault the transport has
                        # already parked). Retry once through a signed ticket
                        # instead of cooling the file down.
                        self._remember_edge_unsupported(entry.digest, float(self._now()))
                        self._logger.record(
                            "fabric_object_read_edge_fallback",
                            path=entry.path,
                            offset_bytes=start,
                            length_bytes=size,
                            error=f"{type(error).__name__}: {error}"[:240],
                        )
                        signed = self._ticket_for(entry, head, float(self._now()))
                        if not self._is_edge_ticket(signed):
                            futures = [
                                self._ensure_unit(entry, head, signed, unit_start, unit_size)
                                for unit_start, unit_size in units
                            ]
                            ticket = signed
                            out = bytearray()
                            for (unit_start, unit_size), unit_future in zip(units, futures):
                                unit_data = unit_future.result(timeout=self._unit_timeout)
                                slice_start = max(offset, unit_start) - unit_start
                                slice_end = min(offset + length, unit_start + unit_size) - unit_start
                                out += unit_data[slice_start:slice_end]
                            if len(out) != length:
                                raise ObjectReadUnavailable(
                                    "direct object read assembled the wrong byte count"
                                ) from error
                            return bytes(out)
                    self._remember_cooldown(
                        entry.digest, float(self._now()), OBJECT_READ_FAILURE_COOLDOWN_SECONDS
                    )
                    self._logger.record(
                        "fabric_object_read_fallback",
                        path=entry.path,
                        offset_bytes=start,
                        length_bytes=size,
                        error=f"{type(error).__name__}: {error}"[:240],
                        first_error=f"{type(first_error).__name__}: {first_error}"[:240],
                    )
                    raise ObjectReadUnavailable(
                        f"direct object read failed: {type(error).__name__}"
                    ) from error
            slice_start = max(offset, start) - start
            slice_end = min(offset + length, start + size) - start
            out += data[slice_start:slice_end]
        if len(out) != length:
            raise ObjectReadUnavailable("direct object read assembled the wrong byte count")
        if window > 0:
            # Readahead starts only once the demand bytes are in hand, so the
            # caller's own unit never shares the link with its prefetch; the
            # kernel's next sequential request then finds these in flight.
            request_end = offset + length
            for start, size in self._units(
                entry.size_bytes,
                request_end,
                min(window, entry.size_bytes - request_end),
                self.unit_bytes,
            ):
                if start >= request_end:
                    self._ensure_unit(entry, head, ticket, start, size)
        return bytes(out)

    # --------------------------------------------------------------- internals

    def _units(
        self, size_bytes: int, offset: int, length: int, unit_bytes: int | None = None
    ) -> list[tuple[int, int]]:
        unit = unit_bytes or self.unit_bytes
        if length <= 0:
            return []
        end = min(size_bytes, offset + length)
        start = (offset // unit) * unit
        units: list[tuple[int, int]] = []
        while start < end:
            units.append((start, min(unit, size_bytes - start)))
            start += unit
        return units

    def _ticket_for(self, entry: _EntryLike, head: _HeadLike, now: float) -> _Ticket:
        with self._lock:
            warming = self._warming.get(entry.digest)
        if warming is not None and not warming.done() and threading.current_thread().name.startswith("meshia-object-read"):
            warming = None  # the warm job itself must not wait on its own future
        if warming is not None:
            # A demand read joins the open-time warm instead of queueing a
            # second signed call behind it.
            try:
                joined = warming.result(timeout=self._unit_timeout)
            except Exception:  # noqa: BLE001 - fall through to a fresh request
                joined = None
            if (
                joined is not None
                and joined.generation == head.generation
                and joined.manifest_digest == head.digest
                and joined.expires_at - now > OBJECT_TICKET_REFRESH_HEADROOM_SECONDS
            ):
                return joined
        with self._lock:
            cached = self._tickets.get(entry.digest)
            if (
                cached is not None
                and cached.generation == head.generation
                and cached.manifest_digest == head.digest
                and cached.expires_at - now > OBJECT_TICKET_REFRESH_HEADROOM_SECONDS
            ):
                self._tickets.move_to_end(entry.digest)
                return cached
            reason = (
                "no_ticket"
                if cached is None
                else "head_changed"
                if (cached.generation, cached.manifest_digest) != (head.generation, head.digest)
                else f"expiring:{int(cached.expires_at - now)}s"
            )
        edge_ticket = self._edge_ticket(entry, head, now)
        if edge_ticket is not None:
            with self._lock:
                self._tickets[entry.digest] = edge_ticket
                self._tickets.move_to_end(entry.digest)
                while len(self._tickets) > _MAX_TRACKED_FILES:
                    self._tickets.popitem(last=False)
            return edge_ticket
        payload = {
            "attachment_id": self._attachment_id,
            "workspace": self._workspace,
            "operation": "object_read",
            "path": entry.path,
            "manifest_generation": head.generation,
            "manifest_digest": head.digest,
            "ttl_seconds": OBJECT_TICKET_TTL_SECONDS,
        }
        try:
            try:
                document = self._request_ticket(payload)
            except RemoteError as error:
                if error.status != 409 or error.remote_code != "FABRIC_BLOCK_TICKET_AUTHORITY_STALE":
                    raise
                # The lease margin can move between issuance and the server's
                # post-presign recheck (heartbeat renewal race). One immediate
                # retry resolves it; it is never a reason to cool the file down.
                document = self._request_ticket(payload)
        except RemoteError as error:
            if error.status == 409 and error.remote_code in _STALE_HEAD_CODES:
                raise ObjectReadStale(str(error)) from error
            if error.status == 409 and error.remote_code == "FABRIC_BLOCK_TICKET_AUTHORITY_STALE":
                self._logger.record(
                    "fabric_object_read_fallback", path=entry.path, error="ticket authority stale twice"
                )
                raise ObjectReadUnavailable("object ticket authority is stale") from error
            if error.status == 409 and error.remote_code == OBJECT_READ_UNSUPPORTED_CODE:
                self._remember_unsupported(entry.digest, now)
                self._logger.record(
                    "fabric_object_read_unsupported", path=entry.path, size_bytes=entry.size_bytes
                )
                raise ObjectReadUnavailable("object reads are unsupported for this file") from error
            self._remember_cooldown(entry.digest, now, OBJECT_READ_FAILURE_COOLDOWN_SECONDS)
            self._logger.record(
                "fabric_object_read_fallback",
                path=entry.path,
                error=f"ticket {error.status} {error.remote_code}"[:240],
            )
            raise ObjectReadUnavailable(f"object ticket request failed: {error.remote_code}") from error
        except NetworkError as error:
            self._logger.record(
                "fabric_object_read_fallback", path=entry.path, error=str(error)[:240]
            )
            raise ObjectReadUnavailable("object ticket request failed") from error
        ticket = self._validate_ticket(document, entry, head, now)
        with self._lock:
            self._tickets[entry.digest] = ticket
            self._tickets.move_to_end(entry.digest)
            while len(self._tickets) > _MAX_TRACKED_FILES:
                self._tickets.popitem(last=False)
        self._logger.record(
            "fabric_object_read_ticket_issued",
            path=entry.path,
            size_bytes=entry.size_bytes,
            ttl_seconds=max(0, int(ticket.expires_at - now)),
            reason=reason,
            reader=f"{id(self):x}",
        )
        return ticket

    def _edge_ticket(self, entry: _EntryLike, head: _HeadLike, now: float) -> _Ticket | None:
        """A Meshia object edge descriptor for ``entry`` (no control call), or None."""

        mint = getattr(self.transport, "edge_object_ticket", None)
        if not callable(mint):
            return None
        with self._lock:
            until = self._edge_unsupported_until.get(entry.digest)
            if until is not None and until > now:
                return None
            if until is not None:
                self._edge_unsupported_until.pop(entry.digest, None)
        try:
            document = mint(path=entry.path, sha256=entry.digest, size_bytes=entry.size_bytes)
        except Exception:  # noqa: BLE001 - never let the edge break the signed lane
            return None
        if not isinstance(document, Mapping) or not isinstance(document.get("expires_at"), str):
            return None
        try:
            expires_at = parse_direct_ticket_expiry(document["expires_at"], now=now)
        except NetworkError:
            return None
        return _Ticket(
            document=dict(document),
            expires_at=expires_at,
            generation=head.generation,
            manifest_digest=head.digest,
        )

    @staticmethod
    def _is_edge_ticket(ticket: _Ticket) -> bool:
        return ticket.document.get("via") == "edge"

    def _remember_edge_unsupported(self, digest: str, now: float) -> None:
        with self._lock:
            self._edge_unsupported_until[digest] = now + OBJECT_READ_UNSUPPORTED_TTL_SECONDS
            self._edge_unsupported_until.move_to_end(digest)
            while len(self._edge_unsupported_until) > _MAX_TRACKED_FILES:
                self._edge_unsupported_until.popitem(last=False)

    def _validate_ticket(
        self, document: object, entry: _EntryLike, head: _HeadLike, now: float
    ) -> _Ticket:
        if (
            not isinstance(document, Mapping)
            or document.get("schema") != OBJECT_READ_TICKET_SCHEMA
            or document.get("operation") != "object_read"
            or document.get("path") != entry.path
            or document.get("sha256") != entry.digest
            or document.get("size_bytes") != entry.size_bytes
            or document.get("manifest_generation") != head.generation
            or document.get("manifest_digest") != head.digest
        ):
            raise ObjectReadUnavailable("Meshia returned an object ticket for another file")
        try:
            expires_at = parse_direct_ticket_expiry(document.get("expires_at"), now=now)
        except NetworkError as error:
            raise ObjectReadUnavailable("Meshia returned an invalid object ticket expiry") from error
        return _Ticket(
            document={
                key: value
                for key, value in document.items()
                if key in {"schema", "operation", "path", "sha256", "size_bytes", "url", "headers", "expires_at", "manifest_generation", "manifest_digest"}
            },
            expires_at=expires_at,
            generation=head.generation,
            manifest_digest=head.digest,
        )

    def warm_many(self, entries: Sequence[_EntryLike], head: _HeadLike) -> int:
        """Ticket a folder's large plain objects with one signed call.

        Returns the number of files scheduled. Entries below the warm
        threshold, already fresh, cooling down, or already warming are
        skipped; without batch transport support the first eligible entry
        is warmed on its own.
        """

        now = float(self._now())
        eligible: list[_EntryLike] = []
        futures: list[Future[_Ticket]] = []
        with self._lock:
            for entry in entries:
                if len(eligible) >= OBJECT_READ_MAX_BATCH:
                    break
                if entry.size_bytes < OBJECT_WARM_MIN_BYTES:
                    continue
                cached = self._tickets.get(entry.digest)
                if (
                    cached is not None
                    and cached.generation == head.generation
                    and cached.manifest_digest == head.digest
                    and cached.expires_at - now > OBJECT_TICKET_REFRESH_HEADROOM_SECONDS
                ):
                    continue
                until = self._unsupported_until.get(entry.digest)
                if until is not None and until > now:
                    continue
                if entry.digest in self._warming or any(item.digest == entry.digest for item in eligible):
                    continue
                eligible.append(entry)
            if not eligible:
                return 0
            if self._request_ticket_batch is None or len(eligible) == 1:
                first = eligible[0]
                eligible = []
            else:
                first = None
                for entry in eligible:
                    future: Future[_Ticket] = Future()
                    self._warming[entry.digest] = future
                    futures.append(future)
        if first is not None:
            return 1 if self.warm(first, head) else 0
        batch = list(eligible)

        def job() -> None:
            issued: dict[str, _Ticket] = {}
            failure: BaseException | None = None
            try:
                issued = self._request_batch(batch, head, float(self._now()))
            except BaseException as error:  # noqa: BLE001 - joined by demand reads
                failure = error
            for entry, future in zip(batch, futures):
                ticket = issued.get(entry.digest)
                if ticket is not None:
                    future.set_result(ticket)
                else:
                    future.set_exception(
                        failure or ObjectReadUnavailable("the batch did not ticket this file")
                    )
                    future.exception()
                with self._lock:
                    if self._warming.get(entry.digest) is future:
                        self._warming.pop(entry.digest, None)

        try:
            self._pool.submit(job)
        except RuntimeError:
            with self._lock:
                for entry in batch:
                    self._warming.pop(entry.digest, None)
            return 0
        return len(batch)

    def _request_batch(
        self, batch: Sequence[_EntryLike], head: _HeadLike, now: float
    ) -> dict[str, _Ticket]:
        assert self._request_ticket_batch is not None
        payload = {
            "attachment_id": self._attachment_id,
            "workspace": self._workspace,
            "operation": "object_read_batch",
            "paths": [entry.path for entry in batch],
            "manifest_generation": head.generation,
            "manifest_digest": head.digest,
            "ttl_seconds": OBJECT_TICKET_TTL_SECONDS,
        }
        try:
            document = self._request_ticket_batch(payload)
        except RemoteError as error:
            if error.status == 409 and error.remote_code in _STALE_HEAD_CODES:
                raise ObjectReadStale(str(error)) from error
            self._logger.record(
                "fabric_object_read_fallback",
                path=batch[0].path,
                error=f"ticket batch {error.status} {error.remote_code}"[:240],
            )
            raise ObjectReadUnavailable("object ticket batch failed") from error
        except NetworkError as error:
            raise ObjectReadUnavailable("object ticket batch failed") from error
        if (
            not isinstance(document, Mapping)
            or document.get("schema") != OBJECT_READ_BATCH_SCHEMA
            or document.get("operation") != "object_read_batch"
            or document.get("manifest_generation") != head.generation
            or document.get("manifest_digest") != head.digest
            or not isinstance(document.get("tickets"), list)
            or not isinstance(document.get("skipped"), list)
        ):
            raise ObjectReadUnavailable("Meshia returned an invalid object ticket batch")
        by_path = {entry.path: entry for entry in batch}
        issued: dict[str, _Ticket] = {}
        for raw in document["tickets"]:
            if not isinstance(raw, Mapping):
                continue
            entry = by_path.get(str(raw.get("path")))
            if entry is None:
                continue
            try:
                ticket = self._validate_ticket(
                    {**raw, "schema": OBJECT_READ_TICKET_SCHEMA, "operation": "object_read",
                     "manifest_generation": head.generation, "manifest_digest": head.digest},
                    entry,
                    head,
                    now,
                )
            except ObjectReadUnavailable:
                continue
            issued[entry.digest] = ticket
        with self._lock:
            for digest, ticket in issued.items():
                self._tickets[digest] = ticket
                self._tickets.move_to_end(digest)
            while len(self._tickets) > _MAX_TRACKED_FILES:
                self._tickets.popitem(last=False)
        for raw in document["skipped"]:
            if not isinstance(raw, Mapping):
                continue
            entry = by_path.get(str(raw.get("path")))
            if entry is not None and raw.get("code") == OBJECT_READ_UNSUPPORTED_CODE:
                self._remember_unsupported(entry.digest, now)
        self._logger.record(
            "fabric_object_read_ticket_batch",
            requested=len(batch),
            issued=len(issued),
            skipped=len(document["skipped"]),
            ttl_seconds=(
                max(0, int(min(ticket.expires_at for ticket in issued.values()) - now))
                if issued
                else 0
            ),
            reader=f"{id(self):x}",
        )
        return issued

    def _refresh_in_background(self, entry: _EntryLike, head: _HeadLike) -> bool:
        with self._lock:
            if entry.digest in self._warming:
                return False
            future: Future[_Ticket] = Future()
            self._warming[entry.digest] = future

        def job() -> None:
            try:
                # Bypass the freshness short-circuit: the caller already knows
                # the cached ticket is inside the refresh window.
                with self._lock:
                    self._tickets.pop(entry.digest, None)
                future.set_result(self._ticket_for(entry, head, float(self._now())))
            except BaseException as error:  # noqa: BLE001 - joined by demand reads
                future.set_exception(error)
                future.exception()
            finally:
                with self._lock:
                    if self._warming.get(entry.digest) is future:
                        self._warming.pop(entry.digest, None)

        try:
            self._pool.submit(job)
        except RuntimeError:
            with self._lock:
                self._warming.pop(entry.digest, None)
            return False
        return True

    def _remember_unsupported(self, digest: str, now: float) -> None:
        self._remember_cooldown(digest, now, OBJECT_READ_UNSUPPORTED_TTL_SECONDS)

    def _remember_cooldown(self, digest: str, now: float, seconds: float) -> None:
        with self._lock:
            self._unsupported_until[digest] = now + seconds
            self._unsupported_until.move_to_end(digest)
            while len(self._unsupported_until) > _MAX_TRACKED_FILES:
                self._unsupported_until.popitem(last=False)

    def _forget_ticket(self, digest: str, ticket: _Ticket) -> None:
        with self._lock:
            if self._tickets.get(digest) is ticket:
                self._tickets.pop(digest, None)

    def _ensure_unit(
        self, entry: _EntryLike, head: _HeadLike, ticket: _Ticket, start: int, size: int
    ) -> Future[bytes]:
        key = (entry.digest, start)
        with self._lock:
            inflight = self._flights.get(key)
        if inflight is not None:
            return inflight
        cached = self.cache.get(
            entry.digest,
            entry.size_bytes,
            start,
            size,
            manifest_generation=head.generation,
            manifest_digest=head.digest,
        )
        if cached is not None:
            done: Future[bytes] = Future()
            done.set_result(cached)
            return done
        future: Future[bytes] = Future()
        with self._lock:
            inflight = self._flights.get(key)
            if inflight is not None:
                return inflight
            self._flights[key] = future

        def job() -> None:
            try:
                data = self.transport.download_object_range(ticket.document, start, size)
                if not isinstance(data, bytes) or len(data) != size:
                    raise NetworkError("the object range transport returned the wrong byte count")
                range_sha256 = hashlib.sha256(data).hexdigest()
                try:
                    self.cache.put(
                        entry.digest,
                        entry.size_bytes,
                        start,
                        data,
                        range_sha256,
                        manifest_generation=head.generation,
                        manifest_digest=head.digest,
                    )
                except OSError as error:
                    if error.errno not in _CACHE_PRESSURE_ERRNOS:
                        raise
                future.set_result(data)
            except BaseException as error:  # noqa: BLE001 - reported through the future
                future.set_exception(error)
                future.exception()
            finally:
                with self._lock:
                    if self._flights.get(key) is future:
                        self._flights.pop(key, None)

        try:
            self._pool.submit(job)
        except RuntimeError as error:
            with self._lock:
                self._flights.pop(key, None)
            future.set_exception(error)
            future.exception()
        return future
