"""Keep-alive HTTPS connection pool for the node's HTTP paths.

``urllib.request.urlopen`` opens a fresh TCP+TLS connection for every request,
which cost a full handshake (150-300 ms measured) on every signed control call
and on every 4 MiB object range. This pool keeps a bounded set of idle
``http.client`` connections per host and reuses them. A safe read on a reused
connection that fails before a response is retried once on a fresh socket,
because a server may have closed an idle keep-alive connection at any time.
Mutations are never replayed here: a lost response may follow a durable write,
so their owning protocol must read back or otherwise resolve the ambiguity.

The pool never follows redirects (``http.client`` cannot), never reuses a
connection whose response was not fully consumed, and returns the standard
``HTTPResponse`` surface (``status``, ``headers``, ``read``, ``close``) so the
existing bounded-body readers stay unchanged.
"""

from __future__ import annotations

import http.client
import os
import socket
import ssl
import threading
import time
import urllib.parse
import urllib.request
from collections import OrderedDict, deque
from typing import Any

import truststore

DEFAULT_MAX_IDLE_PER_HOST = 8
DEFAULT_IDLE_SECONDS = 45.0
_MAX_TRACKED_HOSTS = 16


def create_https_context() -> ssl.SSLContext:
    """Verify certificates using native trust, or an explicit custom CA set.

    Windows' native chain engine can retrieve trusted missing issuers; merely
    copying the currently cached Windows roots into OpenSSL cannot. Keep this
    context local to Meshia's HTTP clients rather than replacing global ssl.
    Explicit CA paths remain exclusive overrides and invalid paths fail closed.
    """

    cafile = os.environ.get("SSL_CERT_FILE") or None
    capath = os.environ.get("SSL_CERT_DIR") or None
    if cafile is not None or capath is not None:
        return ssl.create_default_context(cafile=cafile, capath=capath)
    return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


class _PooledReply:
    """``HTTPResponse`` view that recycles its connection on a clean close."""

    def __init__(
        self,
        response: http.client.HTTPResponse,
        connection: http.client.HTTPConnection,
        release: Any,
        transport_socket: socket.socket | None,
    ) -> None:
        self._response = response
        self._connection = connection
        self._release = release
        self._released = False
        self._transport_socket = transport_socket
        self._read_lock = threading.Lock()
        self._close_lock = threading.Lock()

    @property
    def status(self) -> int:
        return int(self._response.status)

    @property
    def headers(self) -> http.client.HTTPMessage:
        return self._response.headers

    def read(self, amount: int | None = None) -> bytes:
        with self._read_lock:
            if self._released:
                return b""
            value = self._response.read(amount) if amount is not None else self._response.read()
            return b"" if self._released else value

    def readline(self, limit: int = -1) -> bytes:
        with self._read_lock:
            if self._released:
                return b""
            value = self._response.readline(limit)
            return b"" if self._released else value

    def settimeout(self, seconds: float | None) -> None:
        """Adjust the socket read timeout after the response headers arrived."""

        sock = self._transport_socket
        if sock is not None:
            sock.settimeout(seconds)

    def close(self) -> None:
        with self._close_lock:
            if self._released:
                return
            self._released = True
        # HTTPResponse.close clears fp before closing its BufferedReader. A
        # concurrent chunked readline can then dereference None inside peek.
        # Interrupt the owned socket first, leaving response state exclusively
        # with its reader until that read returns; only then close/release it.
        reading = not self._read_lock.acquire(blocking=False)
        if reading:
            sock = self._transport_socket
            if sock is not None:
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
            self._read_lock.acquire()
        reusable = False
        try:
            try:
                reusable = not reading and self._response.isclosed() and not self._response.will_close
            except Exception:  # noqa: BLE001 - never let accounting break a close
                reusable = False
            try:
                self._response.close()
            except Exception:  # noqa: BLE001
                reusable = False
        finally:
            self._read_lock.release()
        self._release(self._connection, reusable)

    def __enter__(self) -> "_PooledReply":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._response, name)


class HttpsConnectionPool:
    """Bounded keep-alive pool with stale-socket retry for safe reads only."""

    def __init__(
        self,
        *,
        max_idle_per_host: int = DEFAULT_MAX_IDLE_PER_HOST,
        idle_seconds: float = DEFAULT_IDLE_SECONDS,
        allow_insecure_loopback: bool = False,
        now: Any = time.monotonic,
    ) -> None:
        if max_idle_per_host < 1:
            raise ValueError("max_idle_per_host must be positive")
        if idle_seconds <= 0:
            raise ValueError("idle_seconds must be positive")
        self._max_idle = max_idle_per_host
        self._idle_seconds = float(idle_seconds)
        self._allow_insecure_loopback = allow_insecure_loopback
        self._now = now
        self._lock = threading.Lock()
        self._idle: OrderedDict[tuple[str, str, int], deque[tuple[http.client.HTTPConnection, float]]] = (
            OrderedDict()
        )
        self._context = create_https_context()
        self.reused_requests = 0
        self.fresh_requests = 0

    # ------------------------------------------------------------ connections

    def _key(self, url: str) -> tuple[str, str, int, str]:
        parts = urllib.parse.urlsplit(url)
        host = (parts.hostname or "").lower()
        if parts.scheme == "https":
            port = parts.port or 443
        elif (
            parts.scheme == "http"
            and self._allow_insecure_loopback
            and host in {"localhost", "127.0.0.1", "::1"}
        ):
            port = parts.port or 80
        else:
            raise OSError(f"unsupported URL scheme for pooled HTTP: {parts.scheme or 'none'}")
        if not host:
            raise OSError("pooled HTTP request has no host")
        target = parts.path or "/"
        if parts.query:
            target = f"{target}?{parts.query}"
        return parts.scheme, host, port, target

    def _connect(self, scheme: str, host: str, port: int, timeout: float) -> http.client.HTTPConnection:
        if scheme == "https":
            return http.client.HTTPSConnection(host, port, timeout=timeout, context=self._context)
        return http.client.HTTPConnection(host, port, timeout=timeout)

    def _take_idle(self, key: tuple[str, str, int]) -> http.client.HTTPConnection | None:
        now = float(self._now())
        with self._lock:
            bucket = self._idle.get(key)
            while bucket:
                connection, parked_at = bucket.pop()
                if now - parked_at <= self._idle_seconds and connection.sock is not None:
                    return connection
                try:
                    connection.close()
                except Exception:  # noqa: BLE001
                    pass
            return None

    def _release(self, key: tuple[str, str, int], connection: http.client.HTTPConnection, reusable: bool) -> None:
        if not reusable or connection.sock is None:
            try:
                connection.close()
            except Exception:  # noqa: BLE001
                pass
            return
        with self._lock:
            bucket = self._idle.get(key)
            if bucket is None:
                bucket = deque()
                self._idle[key] = bucket
                while len(self._idle) > _MAX_TRACKED_HOSTS:
                    _stale_key, stale = self._idle.popitem(last=False)
                    for stale_connection, _at in stale:
                        try:
                            stale_connection.close()
                        except Exception:  # noqa: BLE001
                            pass
            self._idle.move_to_end(key)
            if len(bucket) >= self._max_idle:
                oldest, _at = bucket.popleft()
                try:
                    oldest.close()
                except Exception:  # noqa: BLE001
                    pass
            bucket.append((connection, float(self._now())))

    # ------------------------------------------------------------------ open

    def open(self, request: urllib.request.Request, *, timeout: float) -> _PooledReply:
        """Send one ``urllib.request.Request`` and return a pooled reply.

        Raises ``OSError`` for every transport failure (a stale keep-alive
        socket is retried once on a fresh connection first).
        """

        scheme, host, port, target = self._key(request.full_url)
        key = (scheme, host, port)
        headers = {name: value for name, value in request.header_items()}
        body = request.data
        method = request.get_method()
        attempts = 0
        while True:
            reused = True
            connection = self._take_idle(key)
            if connection is None:
                reused = False
                connection = self._connect(scheme, host, port, timeout)
            else:
                try:
                    if connection.sock is not None:
                        connection.sock.settimeout(timeout)
                except OSError:
                    connection.close()
                    connection = self._connect(scheme, host, port, timeout)
                    reused = False
            attempts += 1
            try:
                connection.request(method, target, body=body, headers=headers)
                # getresponse can detach a Connection: close socket from the
                # connection while the live response still owns its file view.
                transport_socket = connection.sock
                response = connection.getresponse()
            except (http.client.HTTPException, OSError, ssl.SSLError) as error:
                try:
                    connection.close()
                except Exception:  # noqa: BLE001
                    pass
                if reused and attempts < 2 and method in {"GET", "HEAD"}:
                    continue
                if isinstance(error, OSError):
                    raise
                raise OSError(f"pooled HTTP request failed: {type(error).__name__}") from error
            if reused:
                self.reused_requests += 1
            else:
                self.fresh_requests += 1
            return _PooledReply(
                response,
                connection,
                lambda conn, reusable, key=key: self._release(key, conn, reusable),
                transport_socket,
            )

    def close(self) -> None:
        with self._lock:
            buckets = list(self._idle.values())
            self._idle.clear()
        for bucket in buckets:
            for connection, _at in bucket:
                try:
                    connection.close()
                except Exception:  # noqa: BLE001
                    pass
