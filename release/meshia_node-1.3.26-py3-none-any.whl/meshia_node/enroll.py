"""Pairing → enroll → prove, then a persisted 0600 config.

Field names here are the contract. They must match ``normalizeEnrollment`` in
web/lib/connected-hosts.ts and the enroll/prove routes exactly; the local
validation below is a fail-fast mirror of the server's own checks so a bad
probe result surfaces as a clear message instead of a 400.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping

from .client import EnrollmentClient, HttpTransport, validate_api_url
from .config import DEFAULT_ACCESS_MODE, ConfigStore, NodeConfig, Paths
from .errors import (
    AccessRefused,
    InvalidArgument,
    NetworkError,
    RemoteError,
    WorkspaceAdoptionRequired,
    WorkspaceClaimInvalid,
)
from .identity import KEY_ALGORITHM, PUBLIC_KEY_FORMAT, DeviceIdentity
from .machine import MachineInventory, capabilities, inventory
from .util import CAPABILITY_VALUE_RE, PAIRING_CODE_RE, POSTGRES_UUID_RE, UUID_RE, iso8601
from .workspace import (
    WorkspaceRootClaim,
    bind_workspace_root_claim,
    claim_workspace_root,
    rebind_workspace_root_claim,
    validate_workspace_root_claim,
    workspace_root_claim_status,
)

ENROLL_PATH = "api/connected-hosts/enroll"
PROVE_PATH = "api/connected-hosts/enroll/prove"
EnrollmentObserver = Callable[[str, Mapping[str, object]], None]
ALLOWED_CAPABILITIES = frozenset(
    {
        "executor",
        "filesystem",
        "outside_workspace",
        "task_network",
        "gpu_utilization",
        "key_protection",
        "release_tier",
        "machine_family",
        "apple_chip",
        "cpu_logical",
        "memory_bytes",
        "gpu_family",
        "gpu_count",
        "app_protocol",
    }
)
_MACHINE_FAMILIES = frozenset({"apple_silicon", "x86_64", "arm64", "unknown"})
_GPU_FAMILIES = frozenset({"apple_integrated", "nvidia", "amd", "intel", "none", "unknown"})
_BOUNDED = {"cpu_logical": 1024, "memory_bytes": 2**51, "gpu_count": 256}


def validate_capabilities(values: dict[str, str]) -> dict[str, str]:
    """Local mirror of the control plane's capability allowlist."""
    if len(values) > len(ALLOWED_CAPABILITIES):
        raise InvalidArgument("Too many capability keys.")
    for key, value in values.items():
        if key not in ALLOWED_CAPABILITIES:
            raise InvalidArgument(f"Capability {key!r} is not on the connected-host allowlist.")
        if not isinstance(value, str) or not 1 <= len(value) <= 96 or not CAPABILITY_VALUE_RE.match(value):
            raise InvalidArgument(f"Capability {key!r} has an unsupported value.")
    for key, maximum in _BOUNDED.items():
        raw = values.get(key)
        if raw is None:
            continue
        if not raw.isdigit() or (len(raw) > 1 and raw[0] == "0") or int(raw) > maximum:
            raise InvalidArgument(f"Capability {key!r} must be a bounded canonical integer.")
    if values.get("machine_family") not in (None, *_MACHINE_FAMILIES):
        raise InvalidArgument("machine_family is unsupported.")
    if values.get("gpu_family") not in (None, *_GPU_FAMILIES):
        raise InvalidArgument("gpu_family is unsupported.")
    if values.get("app_protocol") not in (None, "http-stream-v1"):
        raise InvalidArgument("app_protocol is unsupported.")
    return values


def build_enrollment(
    *,
    pairing_code: str,
    identity: DeviceIdentity,
    machine: MachineInventory,
    tier: str,
    display_name: str | None = None,
) -> dict[str, Any]:
    if not PAIRING_CODE_RE.match(pairing_code):
        raise InvalidArgument("The pairing code is invalid or expired.")
    described = identity.describe()
    return {
        "pairing_code": pairing_code,
        "display_name": (display_name or machine.display_name)[:96],
        # These two strings are what the workspace shows for the machine, so they
        # must describe the real host: a Windows box reported as "linux" is
        # visible misinformation in the customer's compute panel.
        "platform": machine.platform[:64],
        "architecture": machine.architecture[:64],
        "installation_id": described.installation_id,
        "capabilities": validate_capabilities(capabilities(machine, tier)),
        "enrollment_idempotency_key": described.enrollment_idempotency_key,
        "key_algorithm": KEY_ALGORITHM,
        "public_key_format": PUBLIC_KEY_FORMAT,
        "public_key": described.public_key_spki_pem,
    }


def enroll(
    *,
    paths: Paths,
    api_url: str,
    pairing_code: str,
    tier: str = "compute",
    access: str = DEFAULT_ACCESS_MODE,
    workspace: Path | str | None = None,
    workspace_claim: WorkspaceRootClaim | None = None,
    adopt_existing_workspace: bool = False,
    native_mount_enabled: bool = True,
    display_name: str | None = None,
    transport: HttpTransport | None = None,
    store: ConfigStore | None = None,
    identity: DeviceIdentity | None = None,
    prior_config: NodeConfig | None = None,
    defer_workspace_binding: bool = False,
    enrollment_observer: EnrollmentObserver | None = None,
) -> NodeConfig:
    """Run the full enrollment ceremony and persist ``~/.meshia/config.json``."""
    origin = validate_api_url(api_url)
    if access in ("limited", "full"):
        from . import native_execution
        available, detail = (
            (native_execution.available, native_execution.detail) if access == "limited"
            else (native_execution.full_available, native_execution.full_detail)
        )
        if not available():
            # A selected mode that the OS cannot run or supervise must fail before the
            # one-use claim or any device identity/workspace mutation. This
            # also protects direct callers and staged account replacements.
            raise AccessRefused(detail())
    destination_store = store or ConfigStore(paths)
    if prior_config is None:
        prior_config = ConfigStore(paths).load()
    workspace_root = Path(workspace).expanduser() if workspace else paths.default_workspace
    if workspace_claim is None:
        # Direct callers receive the same first-use fail-closed behavior as the
        # CLI. Inspect before creating the device key or building the network
        # client so rejecting a non-empty root cannot partially enroll a node.
        status = workspace_root_claim_status(workspace_root)
        if status.state == "invalid":
            raise WorkspaceClaimInvalid(
                status.reason or "The workspace ownership marker is invalid."
            )
        if status.requires_adoption and not adopt_existing_workspace:
            raise WorkspaceAdoptionRequired(
                "The selected workspace is non-empty and requires explicit adoption."
            )
    identity = identity or DeviceIdentity.load_or_create(paths.identity_dir)
    described = identity.describe()
    if workspace_claim is None:
        workspace_claim = claim_workspace_root(
            workspace_root,
            installation_id=described.installation_id,
            adopt=adopt_existing_workspace,
        )
    else:
        workspace_claim = validate_workspace_root_claim(
            workspace_root,
            installation_id=described.installation_id,
            workspace_id=workspace_claim.workspace_id,
            require_bound=False,
        )
    machine = inventory()
    client = EnrollmentClient(origin, transport=transport)

    enrollment = build_enrollment(
        pairing_code=pairing_code,
        identity=identity,
        machine=machine,
        tier=tier,
        display_name=display_name,
    )
    if enrollment_observer is not None:
        # Account cutover persists this exact one-use request privately before
        # the remote claim. If the RPC commits but its response is lost, a
        # recovery process can replay the idempotent claim and retire the host.
        enrollment_observer(
            "claiming",
            {"api_url": origin, "enrollment": enrollment},
        )
    try:
        claimed = recover_enrollment_claim(
            api_url=origin,
            enrollment=enrollment,
            client=client,
        )
    except RemoteError as error:
        # A non-retryable HTTP rejection proves the claim did not publish a
        # usable host. Let transactional callers discard their preflight
        # request rather than retrying an invalid one forever. Transport,
        # conflict, throttling, and 5xx outcomes remain ambiguous and durable.
        if enrollment_observer is not None and not error.retryable:
            enrollment_observer(
                "claim_rejected",
                {
                    "api_url": origin,
                    "status": error.status,
                    "remote_code": error.remote_code,
                },
            )
        raise
    host_id = str(claimed["host_id"])
    challenge = str(claimed["challenge"])
    audience = str(claimed["deployment_audience"])
    if enrollment_observer is not None:
        enrollment_observer(
            "claimed",
            {
                "api_url": origin,
                "host_id": host_id,
                "challenge": challenge,
                "deployment_audience": audience,
            },
        )

    proven = recover_enrollment_proof(
        api_url=origin,
        identity=identity,
        host_id=host_id,
        challenge=challenge,
        client=client,
    )
    session_id = str(proven["session_id"])
    account_id = str(proven["account_id"])
    account_email = str(proven["account_email"])
    generation = int(proven["generation"])
    if enrollment_observer is not None:
        enrollment_observer(
            "proven",
            {
                "api_url": origin,
                "host_id": host_id,
                "deployment_audience": audience,
                "generation": generation,
                "session_id": session_id,
                "account_id": account_id,
                "account_email": account_email,
            },
        )

    # A re-pair can select a different account or workspace. Never bind the
    # previous authority's materialized root to the new session: cached clean
    # bytes and pending local edits remain evidence owned by the old scope.
    if prior_config is not None and (
        prior_config.account_id is None
        or prior_config.account_id != account_id
        or prior_config.session_id != session_id
    ):
        workspace_claim = claim_workspace_root(
            paths.account_workspace_state(account_id, session_id).workspace,
            installation_id=described.installation_id,
        )

    config = NodeConfig(
        api_url=origin,
        deployment_audience=audience,
        host_id=host_id,
        generation=generation,
        session_id=session_id,
        workspace=workspace_claim.canonical_root,
        installation_id=described.installation_id,
        workspace_id=workspace_claim.workspace_id,
        account_email=account_email,
        account_id=account_id,
        workspace_adoption_pending=workspace_claim.adoption_pending,
        native_mount_enabled=native_mount_enabled,
        tier=tier,
        # The access mode is a local enforcement setting, not part of the
        # enrollment contract: the control plane learns it from the attach
        # permission profile and can override it on any heartbeat.
        access=access,
        display_name=enrollment["display_name"],
        attachment_id=None,
        lifecycle="enrolled",
        # A fresh generation starts a fresh sequence space on the server.
        next_sequence=1,
        next_metrics_sequence=1,
        enrolled_at=iso8601(),
    )
    persisted = destination_store.save(config)
    # Account-cutover preparation persists its config outside the active store
    # while the old runner may still hold this root open.  In that mode the
    # marker must remain under the old authority until publication and service
    # activation; startup already repairs the exact config/marker CAS window.
    # Ordinary enrollment binds after config save, making its cross-file crash
    # window recoverable for the same reason.
    if defer_workspace_binding:
        return persisted
    if workspace_claim.is_bound:
        assert workspace_claim.host_id is not None
        assert workspace_claim.session_id is not None
        rebind_workspace_root_claim(
            workspace_claim.canonical_root,
            installation_id=described.installation_id,
            workspace_id=workspace_claim.workspace_id,
            expected_host_id=workspace_claim.host_id,
            expected_session_id=workspace_claim.session_id,
            host_id=host_id,
            session_id=session_id,
        )
    else:
        bind_workspace_root_claim(
            workspace_claim.canonical_root,
            installation_id=described.installation_id,
            workspace_id=workspace_claim.workspace_id,
            host_id=host_id,
            session_id=session_id,
        )
    return persisted


def recover_enrollment_claim(
    *,
    api_url: str,
    enrollment: Mapping[str, object],
    client: EnrollmentClient | None = None,
) -> dict[str, str]:
    """Perform or idempotently replay one exact pairing claim request."""

    origin = validate_api_url(api_url)
    request = dict(enrollment)
    pairing_code = request.get("pairing_code")
    if not isinstance(pairing_code, str) or PAIRING_CODE_RE.fullmatch(pairing_code) is None:
        raise NetworkError("The saved enrollment claim is invalid.")
    transport = client or EnrollmentClient(origin)
    claimed = transport.post(ENROLL_PATH, request)
    host_id = str(claimed.get("host_id", ""))
    challenge = str(claimed.get("proof_challenge", ""))
    audience = str(claimed.get("deployment_audience", ""))
    if not UUID_RE.fullmatch(host_id) or not challenge or not audience:
        raise NetworkError("Meshia returned an incomplete enrollment response.")
    return {
        "host_id": host_id,
        "challenge": challenge,
        "deployment_audience": audience,
    }


def recover_enrollment_proof(
    *,
    api_url: str,
    identity: DeviceIdentity,
    host_id: str,
    challenge: str,
    client: EnrollmentClient | None = None,
) -> dict[str, object]:
    """Complete or idempotently recover one claimed host proof."""

    origin = validate_api_url(api_url)
    if UUID_RE.fullmatch(host_id) is None or not challenge:
        raise NetworkError("The saved enrollment proof claim is invalid.")
    transport = client or EnrollmentClient(origin)
    proven = transport.post(
        PROVE_PATH,
        {"host_id": host_id, "signature": identity.enrollment_proof(host_id, challenge)},
    )
    session_id = str(proven.get("session_id", ""))
    account_id = str(proven.get("account_id", ""))
    account_email = proven.get("account_email")
    generation = proven.get("generation")
    if not UUID_RE.match(session_id):
        raise NetworkError("The pairing proof returned an invalid session scope.")
    if POSTGRES_UUID_RE.fullmatch(account_id) is None:
        raise NetworkError("The pairing proof returned an invalid account identity.")
    if not isinstance(generation, int) or isinstance(generation, bool) or generation < 1:
        raise NetworkError("The pairing proof returned an invalid host generation.")
    if str(proven.get("host_id", host_id)) != host_id:
        raise NetworkError("The pairing proof returned a mismatched host id.")
    if (
        not isinstance(account_email, str)
        or not 3 <= len(account_email.encode("utf-8")) <= 320
        or "@" not in account_email
        or any(ord(character) < 33 for character in account_email)
    ):
        raise NetworkError("The pairing proof returned an invalid account identity.")
    return {
        "host_id": host_id,
        "generation": generation,
        "session_id": session_id,
        "account_id": account_id,
        "account_email": account_email,
    }
