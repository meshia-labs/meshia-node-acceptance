"""Small safety shim around Watchdog's native event ingress.

Watchdog 6 uses an unbounded dispatcher queue on every platform. Its macOS
FSEvents emitter receives stream-loss flags but does not surface them as
filesystem events, and its Windows emitter does not distinguish an active
zero-byte notification result from an ordinary empty event list. This module
bounds the dispatcher queue and, for the pinned Watchdog implementation, turns
those raw loss signals into one fail-closed callback. Reconciliation remains
owned by ``FabricWatch`` and the synchronization coordinator.

Watchdog 6 discards Linux ``IN_Q_OVERFLOW`` records inside its private parser,
before a safe emitter hook can observe them. The Linux predicate documents that
upstream seam; Linux parity requires an upstream change or maintained fork.
"""

from __future__ import annotations

import inspect
import queue
import threading
from dataclasses import dataclass
from importlib import metadata
from types import MethodType
from typing import Callable, Iterable

try:  # Packaged dependency; guarded for the scanner-only recovery import path.
    from watchdog.observers.api import EventDispatcher, EventQueue
except ImportError:  # pragma: no cover - exercised only by damaged installations
    EventDispatcher = None  # type: ignore[assignment,misc]
    EventQueue = None  # type: ignore[assignment,misc]


_SUPPORTED_WATCHDOG_NATIVE_HOOK_VERSIONS = frozenset(("6.0.0",))
_FSEVENTS_LOSS_ATTRIBUTES = (
    "must_scan_subdirs",
    "is_user_dropped",
    "is_kernel_dropped",
    "is_event_ids_wrapped",
    "is_root_changed",
)
INOTIFY_QUEUE_OVERFLOW_MASK = 0x00004000
WINDOWS_ERROR_NOTIFY_ENUM_DIR = 1022


@dataclass(frozen=True, slots=True)
class NativeIngressSnapshot:
    depth: int
    capacity: int
    blocked: bool
    last_loss: str | None


class NativeLossGate:
    """Latch one loss epoch until authoritative recovery acknowledges it."""

    def __init__(self, on_loss: Callable[[str], None]) -> None:
        self._on_loss = on_loss
        self._lock = threading.Lock()
        self._blocked = False
        self._last_loss: str | None = None

    @property
    def blocked(self) -> bool:
        with self._lock:
            return self._blocked

    @property
    def last_loss(self) -> str | None:
        with self._lock:
            return self._last_loss

    def report(self, reason: str) -> bool:
        """Report at most one callback for the current loss epoch."""

        with self._lock:
            if self._blocked:
                return False
            self._blocked = True
            self._last_loss = reason
        self._on_loss(reason)
        return True

    def reset(self) -> None:
        with self._lock:
            self._blocked = False


if EventQueue is not None:

    class BoundedNativeEventQueue(EventQueue):  # type: ignore[misc]
        """Non-blocking Watchdog ingress with a single loss watermark."""

        def __init__(self, maxsize: int, gate: NativeLossGate) -> None:
            super().__init__(maxsize=maxsize)
            self._meshia_gate = gate

        def put(  # type: ignore[override]
            self,
            item: object,
            block: bool = True,
            timeout: float | None = None,
        ) -> None:
            # Never admit more partial hints after loss. The dispatcher stop
            # sentinel remains useful because it wakes an otherwise idle get.
            stop_event = (
                EventDispatcher.stop_event if EventDispatcher is not None else None
            )
            if item is not stop_event and self._meshia_gate.blocked:
                return
            try:
                super().put(item, block=False)
            except queue.Full:
                if item is not stop_event:
                    self._meshia_gate.report("watchdog_ingress_queue_full")

else:

    class BoundedNativeEventQueue(queue.Queue[object]):
        """Test/recovery equivalent when Watchdog itself is unavailable."""

        def __init__(self, maxsize: int, gate: NativeLossGate) -> None:
            super().__init__(maxsize=maxsize)
            self._meshia_gate = gate
            self._last_item: object | None = None

        def put(  # type: ignore[override]
            self,
            item: object,
            block: bool = True,
            timeout: float | None = None,
        ) -> None:
            del block, timeout
            if self._meshia_gate.blocked:
                return
            with self.mutex:
                if self._last_item is not None and item == self._last_item:
                    return
            try:
                super().put(item, block=False)
            except queue.Full:
                self._meshia_gate.report("watchdog_ingress_queue_full")

        def _put(self, item: object) -> None:
            super()._put(item)
            self._last_item = item

        def _get(self) -> object:
            item = super()._get()
            if item is self._last_item:
                self._last_item = None
            return item


def configure_observer_ingress(
    observer: object,
    *,
    max_events: int,
    on_loss: Callable[[str], None],
) -> NativeLossGate:
    """Replace Watchdog's queue before ``schedule`` creates an emitter."""

    if max_events < 1:
        raise ValueError("max_events must be positive")
    gate = NativeLossGate(on_loss)
    event_queue = BoundedNativeEventQueue(max_events, gate)
    setattr(observer, "_event_queue", event_queue)
    setattr(observer, "_meshia_native_loss_gate", gate)
    return gate


def attach_fsevents_loss_hook(observer: object, *, max_raw_events: int) -> bool:
    """Install validated Watchdog 6 native loss hooks where safely exposed.

    The historical name is retained for the packaged call site. macOS exposes
    raw FSEvents flags and Windows exposes an active empty notification result.
    Watchdog 6 drops Linux ``IN_Q_OVERFLOW`` inside its private low-level parser
    before an emitter hook can observe it; supporting that seam requires an
    upstream change or maintained emitter fork and is deliberately not faked.
    """

    observer_module = type(observer).__module__.lower()
    if (
        "read_directory_changes" in observer_module
        or "windows" in observer_module
    ):
        return _attach_windows_loss_hook(observer)
    if "fsevents" not in observer_module:
        return True
    if _watchdog_version() not in _SUPPORTED_WATCHDOG_NATIVE_HOOK_VERSIONS:
        return False
    gate = getattr(observer, "_meshia_native_loss_gate", None)
    if not isinstance(gate, NativeLossGate):
        return False
    try:
        emitters = tuple(getattr(observer, "emitters"))
    except Exception:
        return False
    if not emitters:
        return False
    for emitter in emitters:
        if "fsevents" not in type(emitter).__module__.lower():
            return False
        original = getattr(emitter, "queue_events", None)
        if not callable(original) or getattr(emitter, "_meshia_loss_hook", False):
            return False
        try:
            parameters = tuple(inspect.signature(original).parameters)
        except (TypeError, ValueError):
            return False
        if parameters[:2] != ("timeout", "events"):
            return False

    for emitter in emitters:
        original = getattr(emitter, "queue_events")

        def guarded_queue_events(
            _emitter: object,
            timeout: float,
            events: list[object],
            *args: object,
            _original: Callable[..., object] = original,
            **kwargs: object,
        ) -> object | None:
            if gate.blocked:
                return None
            if len(events) > max_raw_events:
                gate.report("fsevents_raw_batch_too_large")
                return None
            if fsevents_batch_requires_recovery(events):
                gate.report("fsevents_stream_loss")
                return None
            return _original(timeout, events, *args, **kwargs)

        setattr(emitter, "queue_events", MethodType(guarded_queue_events, emitter))
        setattr(emitter, "_meshia_loss_hook", True)
    return True


def _attach_windows_loss_hook(observer: object) -> bool:
    if _watchdog_version() not in _SUPPORTED_WATCHDOG_NATIVE_HOOK_VERSIONS:
        return False
    gate = getattr(observer, "_meshia_native_loss_gate", None)
    if not isinstance(gate, NativeLossGate):
        return False
    try:
        emitters = tuple(getattr(observer, "emitters"))
    except Exception:
        return False
    if not emitters:
        return False
    for emitter in emitters:
        module = type(emitter).__module__.lower()
        original = getattr(emitter, "_read_events", None)
        if (
            "read_directory_changes" not in module
            or not callable(original)
            or getattr(emitter, "_meshia_loss_hook", False)
        ):
            return False
        try:
            if inspect.signature(original).parameters:
                return False
        except (TypeError, ValueError):
            return False

    for emitter in emitters:
        original = getattr(emitter, "_read_events")

        def guarded_read_events(
            _emitter: object,
            *,
            _original: Callable[..., object] = original,
        ) -> object:
            events = _original()
            active = bool(
                getattr(_emitter, "should_keep_running", lambda: False)()
            ) and getattr(_emitter, "_whandle", None) is not None
            if (
                isinstance(events, list)
                and not events
                and windows_result_requires_recovery(
                    bytes_returned=0,
                    error_code=None,
                    active=active,
                )
            ):
                gate.report("windows_notification_buffer_discarded")
            return events

        setattr(emitter, "_read_events", MethodType(guarded_read_events, emitter))
        setattr(emitter, "_meshia_loss_hook", True)
    return True


def reset_observer_loss(observer: object | None) -> None:
    gate = getattr(observer, "_meshia_native_loss_gate", None)
    if isinstance(gate, NativeLossGate):
        gate.reset()


def observer_ingress_snapshot(observer: object | None) -> NativeIngressSnapshot:
    if observer is None:
        return NativeIngressSnapshot(0, 0, False, None)
    gate = getattr(observer, "_meshia_native_loss_gate", None)
    event_queue = getattr(observer, "_event_queue", None)
    depth = _nonnegative_int_call(event_queue, "qsize")
    capacity = max(0, int(getattr(event_queue, "maxsize", 0) or 0))
    if not isinstance(gate, NativeLossGate):
        return NativeIngressSnapshot(depth, capacity, False, None)
    return NativeIngressSnapshot(depth, capacity, gate.blocked, gate.last_loss)


def native_backend_name(observer: object | None) -> str:
    if observer is None:
        return "fallback"
    module = type(observer).__module__.lower()
    if "fsevents" in module:
        return "fsevents"
    if "kqueue" in module:
        return "kqueue"
    if "inotify" in module:
        return "inotify"
    if "read_directory_changes" in module or "windows" in module:
        return "read_directory_changes"
    return "native"


def fsevents_batch_requires_recovery(events: Iterable[object]) -> bool:
    return any(
        any(bool(getattr(event, attribute, False)) for attribute in _FSEVENTS_LOSS_ATTRIBUTES)
        for event in events
    )


def inotify_mask_requires_recovery(mask_or_event: int | object) -> bool:
    """Linux seam: ``IN_Q_OVERFLOW`` currently disappears inside Watchdog."""

    try:
        mask = int(getattr(mask_or_event, "mask", mask_or_event))
    except (TypeError, ValueError):
        return True
    return bool(mask & INOTIFY_QUEUE_OVERFLOW_MASK)


def windows_result_requires_recovery(
    *, bytes_returned: int | None, error_code: int | None, active: bool = True
) -> bool:
    """Windows seam for ReadDirectoryChangesW's discarded-buffer signals."""

    if not active:
        return False
    return error_code is not None or bytes_returned is None or bytes_returned == 0


def _watchdog_version() -> str | None:
    try:
        return metadata.version("watchdog")
    except metadata.PackageNotFoundError:
        return None


def _nonnegative_int_call(target: object, name: str) -> int:
    try:
        return max(0, int(getattr(target, name)()))
    except (AttributeError, TypeError, ValueError):
        return 0


__all__ = [
    "BoundedNativeEventQueue",
    "NativeIngressSnapshot",
    "NativeLossGate",
    "attach_fsevents_loss_hook",
    "configure_observer_ingress",
    "fsevents_batch_requires_recovery",
    "inotify_mask_requires_recovery",
    "native_backend_name",
    "observer_ingress_snapshot",
    "reset_observer_loss",
    "windows_result_requires_recovery",
]
