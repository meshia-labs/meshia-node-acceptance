"""Persisted node state: paths, the config document, and cross-process locks.

The signed-request sequence lives here because it must advance **before** a
request goes on the wire and must never be reused (PROTOCOL.md); an exclusively
locked read-modify-write is what makes that safe across the CLI and the runner
loops — ``flock`` on POSIX, ``msvcrt.locking`` byte-range locks on Windows.
"""

from __future__ import annotations

import contextlib
import json
import os
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator, Literal, TypeVar

if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
    import msvcrt
else:
    import fcntl

from .errors import StateError
from .util import POSTGRES_UUID_RE, UUID_RE, ensure_private_dir, iso8601, write_private_file

Lifecycle = Literal["enrolled", "attaching", "connected", "offline", "disconnected"]
Tier = Literal["personal", "compute"]
# Account sign-in mounts files. An explicit compute grant selects workspace-only
# native execution (limited) or unrestricted native execution (full).
AccessMode = Literal["files", "limited", "full"]
MOUNT_BACKENDS = ("auto", "fskit", "fuse-t")
LIFECYCLES: tuple[str, ...] = ("enrolled", "attaching", "connected", "offline", "disconnected")
TIERS: tuple[str, ...] = ("personal", "compute")
ACCESS_MODES: tuple[str, ...] = ("files", "limited", "full")
CONNECT_ACCESS_MODES: tuple[str, ...] = ACCESS_MODES
DEFAULT_ACCESS_MODE = "files"
SCHEMA_VERSION = 1

T = TypeVar("T")


def default_home() -> Path:
    override = os.environ.get("MESHIA_HOME")
    return Path(override).expanduser() if override else Path.home() / ".meshia"


@dataclass(frozen=True)
class Paths:
    home: Path

    @classmethod
    def resolve(cls, home: Path | str | None = None) -> "Paths":
        return cls(Path(home).expanduser() if home else default_home())

    @property
    def identity_dir(self) -> Path:
        return self.home / "identity"

    @property
    def config_path(self) -> Path:
        return self.home / "config.json"

    @property
    def locks_dir(self) -> Path:
        return self.home / "locks"

    @property
    def state_lock(self) -> Path:
        return self.locks_dir / "state.lock"

    @property
    def request_lock(self) -> Path:
        return self.locks_dir / "signed-request.lock"

    @property
    def connection_lock(self) -> Path:
        """Cross-process authority for the one live attachment runner."""
        return self.locks_dir / "connection.lock"

    @property
    def outbox_dir(self) -> Path:
        return self.home / "outbox"

    @property
    def fabric_state(self) -> Path:
        """Legacy eager-sync state retained while installs migrate in place."""
        return self.home / "fabric-state.json"

    @property
    def fabric_db_path(self) -> Path:
        return self.home / "fabric.db"

    @property
    def fabric_cache_dir(self) -> Path:
        return self.home / "cache" / "fabric"

    @property
    def fabric_staging_dir(self) -> Path:
        return self.home / "staging" / "fabric"

    @property
    def fabric_mount_dir(self) -> Path:
        """Stable user-facing POSIX mount point.

        The native transport is an implementation detail.  Keeping the mount
        at ``~/Meshia`` gives Finder and Linux file managers one ordinary,
        memorable entry instead of exposing the private runtime tree under
        ``~/.meshia``.  Portable/test homes stay self-contained.
        """

        if self.home.expanduser() == Path.home() / ".meshia":
            return Path.home() / "Meshia"
        return self.home / "mounts" / "Meshia"

    @property
    def fabric_mount_state_path(self) -> Path:
        """Bounded mount receipt, including the drive selected on Windows."""

        return self.home / "mount-state.json"

    @property
    def push_status_path(self) -> Path:
        """Bounded push-stream health the daemon refreshes for ``status``."""

        return self.home / "push-status.json"

    @property
    def fskit_mount_state_path(self) -> Path:
        """Per-volume receipts written by the FSKit volume manager (macOS)."""

        return self.home / "fskit-mounts.json"

    @property
    def default_workspace(self) -> Path:
        # This is the private write-back working set, not the user-facing
        # mounted namespace.  Keeping it below Meshia home prevents a fresh
        # install from trying to mount over its own authoritative local stages.
        # An already-persisted workspace is never routed through this default.
        return self.home / "workspace"

    @property
    def accounts_dir(self) -> Path:
        return self.home / "accounts"

    def account_workspace_catalog(self, account_id: str) -> Path:
        """Return the private last-authenticated catalog for one account."""

        if not isinstance(account_id, str) or POSTGRES_UUID_RE.fullmatch(account_id) is None:
            raise StateError("account_id must be a UUID.")
        return self.accounts_dir / account_id / "workspace-catalog.json"

    @property
    def workspace_state_locations(self) -> Path:
        """Authenticated mapping for the one retained pre-account state tree."""

        return self.home / "workspace-state-locations.json"

    @property
    def workspace_state_locations_lock(self) -> Path:
        return self.locks_dir / "workspace-state-locations.lock"

    def account_workspace_state(
        self, account_id: str, session_id: str
    ) -> "WorkspaceStatePaths":
        """Return an authority-scoped local working set for one workspace."""

        for label, value, pattern in (
            ("account_id", account_id, POSTGRES_UUID_RE),
            ("session_id", session_id, UUID_RE),
        ):
            if not isinstance(value, str) or pattern.fullmatch(value) is None:
                raise StateError(f"{label} must be a UUID.")
        root = self.accounts_dir / account_id / "workspaces" / session_id
        return WorkspaceStatePaths(
            root=root,
            workspace=root / "materialized-root",
            database=root / "fabric.db",
            cache=root / "cache",
            staging=root / "staging",
        )

    @property
    def legacy_workspace_state(self) -> "WorkspaceStatePaths":
        """The pre-catalog singleton layout, retained without moving evidence."""

        return WorkspaceStatePaths(
            root=self.home,
            workspace=self.default_workspace,
            database=self.fabric_db_path,
            cache=self.fabric_cache_dir,
            staging=self.fabric_staging_dir,
        )

    @property
    def log_path(self) -> Path:
        return self.home / "node.log"


@dataclass(frozen=True)
class WorkspaceStatePaths:
    """Private state for exactly one account/workspace authority."""

    root: Path
    workspace: Path
    database: Path
    cache: Path
    staging: Path


@contextlib.contextmanager
def file_lock(path: Path) -> Iterator[None]:
    """Exclusive advisory lock, held for the duration of the block."""
    ensure_private_dir(path.parent)
    flags = os.O_CREAT | os.O_RDWR
    flags |= getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOINHERIT", 0)
    descriptor = os.open(str(path), flags, 0o600)
    try:
        if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
            # LK_LOCK waits ~10s then raises; loop so the lock is truly blocking.
            # The lock is positional, so seek to the first byte on both sides.
            while True:
                try:
                    os.lseek(descriptor, 0, os.SEEK_SET)
                    msvcrt.locking(descriptor, msvcrt.LK_LOCK, 1)
                    break
                except OSError:
                    time.sleep(0.05)
            try:
                yield
            finally:
                try:
                    os.lseek(descriptor, 0, os.SEEK_SET)
                    msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
        else:
            fcntl.flock(descriptor, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
    finally:
        os.close(descriptor)


@dataclass
class NodeConfig:
    api_url: str
    deployment_audience: str
    host_id: str
    generation: int
    session_id: str
    workspace: str
    # ``workspace_id`` binds the path to the private on-root ownership marker;
    # the installation id independently fences a copied marker/config pair.
    # Both remain nullable solely so pre-marker installs can be migrated under
    # the exact prior Fabric authority rather than being silently adopted.
    installation_id: str | None = None
    workspace_id: str | None = None
    workspace_name: str | None = None
    account_email: str | None = None
    account_id: str | None = None
    workspace_adoption_pending: bool = False
    native_mount_enabled: bool = True
    # File Provider is selected first on macOS when the signed app and domain
    # are ready. ``mount_backend`` chooses only the safe fallback: ``auto``
    # prefers FSKit on macOS 26 when enabled, else FUSE-T. See fskit_mount.
    mount_backend: str = "auto"
    tier: str = "personal"
    access: str = DEFAULT_ACCESS_MODE
    display_name: str = "meshia-node"
    attachment_id: str | None = None
    lifecycle: str = "enrolled"
    disconnect_reason: str | None = None
    next_sequence: int = 1
    next_metrics_sequence: int = 1
    clock_offset_seconds: int = 0
    enrolled_at: str = field(default_factory=iso8601)
    last_heartbeat_at: str | None = None
    pid: int | None = None
    schema_version: int = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.lifecycle not in LIFECYCLES:
            raise StateError(f"Unknown lifecycle state {self.lifecycle!r}.")
        if self.tier not in TIERS:
            raise StateError(f"Unknown tier {self.tier!r}.")
        if self.access not in ACCESS_MODES:
            raise StateError(f"Unknown access mode {self.access!r}.")
        if self.next_sequence < 1 or self.next_metrics_sequence < 1:
            raise StateError("Persisted sequences must be positive.")
        for label, value, pattern in (
            ("installation_id", self.installation_id, UUID_RE),
            ("workspace_id", self.workspace_id, UUID_RE),
            ("account_id", self.account_id, POSTGRES_UUID_RE),
        ):
            if value is not None and (
                not isinstance(value, str) or pattern.fullmatch(value) is None
            ):
                raise StateError(f"Persisted {label} must be a UUID.")
        if self.workspace_name is not None and (
            not isinstance(self.workspace_name, str)
            or not self.workspace_name.strip()
            or len(self.workspace_name.encode("utf-8")) > 1_024
            or "\x00" in self.workspace_name
        ):
            raise StateError("Persisted workspace_name is invalid.")
        if self.account_email is not None and (
            not isinstance(self.account_email, str)
            or not 3 <= len(self.account_email.encode("utf-8")) <= 320
            or "@" not in self.account_email
            or any(ord(character) < 33 for character in self.account_email)
        ):
            raise StateError("Persisted account_email is invalid.")
        if self.disconnect_reason is not None and (
            not isinstance(self.disconnect_reason, str)
            or not 2 <= len(self.disconnect_reason) <= 64
            or not self.disconnect_reason[0].isupper()
            or any(
                not (character.isupper() or character.isdigit() or character == "_")
                for character in self.disconnect_reason
            )
        ):
            raise StateError("Persisted disconnect reason is invalid.")
        if not isinstance(self.workspace_adoption_pending, bool):
            raise StateError("Persisted workspace adoption state must be a boolean.")
        if not isinstance(self.native_mount_enabled, bool):
            raise StateError("Persisted native mount setting must be a boolean.")
        if self.mount_backend not in MOUNT_BACKENDS:
            raise StateError(
                "Persisted mount backend must be one of " + ", ".join(MOUNT_BACKENDS) + "."
            )
        if self.workspace_adoption_pending and self.workspace_id is None:
            raise StateError("A pending workspace adoption must identify its root claim.")
        if (
            isinstance(self.clock_offset_seconds, bool)
            or not isinstance(self.clock_offset_seconds, int)
            or abs(self.clock_offset_seconds) >= 10**11
        ):
            raise StateError("Persisted clock correction is outside the safe range.")

    def to_json(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_json(cls, document: dict[str, Any]) -> "NodeConfig":
        known = {key: document[key] for key in cls.__dataclass_fields__ if key in document}
        return cls(**known)


class ConfigStore:
    """Reads/writes ``~/.meshia/config.json`` (0600) under a process-wide lock."""

    def __init__(
        self,
        paths: Paths,
        *,
        config_path: Path | str | None = None,
        state_lock: Path | str | None = None,
    ) -> None:
        self.paths = paths
        # Account replacement is prepared while the current runner is still
        # serving the old account.  Its signed sequence and candidate config
        # therefore need a private publication target without inventing a
        # second Paths authority (workspace/cache paths must remain scoped to
        # the real Meshia home).  Ordinary callers retain the exact old paths.
        self.config_path = (
            Path(config_path) if config_path is not None else paths.config_path
        )
        self.state_lock = Path(state_lock) if state_lock is not None else paths.state_lock

    # ------------------------------------------------------------------ storage

    def exists(self) -> bool:
        return self.config_path.exists()

    def load(self) -> NodeConfig | None:
        with file_lock(self.state_lock):
            return self._load_unlocked()

    def require(self) -> NodeConfig:
        config = self.load()
        if config is None:
            raise StateError("This machine is not enrolled. Run `meshia-node connect <pairing-code>`.")
        return config

    def save(self, config: NodeConfig) -> NodeConfig:
        with file_lock(self.state_lock):
            self._save_unlocked(config)
            return config

    def update(self, mutate: Callable[[NodeConfig], T]) -> tuple[NodeConfig, T]:
        """Atomic read-modify-write; returns the persisted config and the result."""
        with file_lock(self.state_lock):
            config = self._load_unlocked()
            if config is None:
                raise StateError("This machine is not enrolled.")
            result = mutate(config)
            self._save_unlocked(config)
            return config, result

    def allocate_sequence(self) -> tuple[NodeConfig, int]:
        """Consume the next signed-request sequence. Must precede the request."""
        return self.update(_take_request_sequence)

    def allocate_metrics_sequence(self) -> tuple[NodeConfig, int]:
        return self.update(_take_metrics_sequence)

    def advance_sequence_to(self, next_sequence: int) -> NodeConfig:
        """Atomically skip to a server-proven unused request sequence."""

        if (
            isinstance(next_sequence, bool)
            or not isinstance(next_sequence, int)
            or not 1 <= next_sequence < 10**16
        ):
            raise StateError("The repaired request sequence is outside the safe range.")

        def advance(config: NodeConfig) -> None:
            config.next_sequence = max(config.next_sequence, next_sequence)

        return self.update(advance)[0]

    def set_clock_offset_seconds(self, offset_seconds: int) -> NodeConfig:
        """Persist an HTTPS-server-derived correction for signed timestamps."""

        if (
            isinstance(offset_seconds, bool)
            or not isinstance(offset_seconds, int)
            or abs(offset_seconds) >= 10**11
        ):
            raise StateError("The repaired clock correction is outside the safe range.")

        def update_offset(config: NodeConfig) -> None:
            config.clock_offset_seconds = offset_seconds

        return self.update(update_offset)[0]

    def erase(self) -> None:
        with file_lock(self.state_lock):
            if self.config_path.exists():
                self.config_path.unlink()
            # Keep Fabric metadata, cached clean bytes and especially staged or
            # pending edits. A later enrollment fences the old authority in the
            # SQLite journal; deleting it here would turn `forget` into a local
            # data-loss operation. The v1 state is likewise harmless evidence.

    # ---------------------------------------------------------------- internals

    def _load_unlocked(self) -> NodeConfig | None:
        path = self.config_path
        if not path.exists():
            return None
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise StateError(f"The node configuration at {path} is unreadable.") from error
        if not isinstance(document, dict):
            raise StateError(f"The node configuration at {path} is not a JSON object.")
        return NodeConfig.from_json(document)

    def _save_unlocked(self, config: NodeConfig) -> None:
        ensure_private_dir(self.config_path.parent)
        payload = json.dumps(config.to_json(), indent=2, sort_keys=True).encode("utf-8")
        write_private_file(self.config_path, payload)


def _take_request_sequence(config: NodeConfig) -> int:
    sequence = config.next_sequence
    if sequence >= 10**16:
        raise StateError("The signed-request sequence is exhausted; re-enroll this host.")
    config.next_sequence = sequence + 1
    return sequence


def _take_metrics_sequence(config: NodeConfig) -> int:
    sequence = config.next_metrics_sequence
    config.next_metrics_sequence = sequence + 1
    return sequence
