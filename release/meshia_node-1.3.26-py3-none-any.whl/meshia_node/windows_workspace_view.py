"""Lease a WinFsp view containing exactly one authenticated workspace.

The user's main volume contains every account workspace. FUSE's FileSecurity
is volume-wide, so it must never grant an AppContainer access to that catalog.
This view borrows the selected live Fabric owner; it is not a copy/cache or an
independent sync engine. The command's existing runtime lease stays held until
its process Job ends and the last view lease has unmounted.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import logging
import ntpath
from pathlib import Path
import threading
import time
from typing import Any, Iterator

from .config import file_lock
from .errors import StateError
from .fabric_mount import FabricFuseMount
from .util import ensure_private_dir
from .windows_native import create_profile, identity, revoke_runtime_grants
from .windows_mount import mounted_drive_paths
from .workspace import split_relative


class _BorrowedBackend:
    def __init__(self, owner: Any) -> None:
        self._owner = owner

    def __getattr__(self, name: str) -> Any:
        # The public mount keeps its own notification/compute icon sinks.
        if name in ("set_namespace_invalidator", "set_compute_icon_sink"):
            raise AttributeError(name)
        return getattr(self._owner, name)

    def close(self) -> None:
        # Lifetime belongs to the authenticated runtime lease held by caller.
        pass


@dataclass
class _View:
    owner: Any
    name: str
    mount: FabricFuseMount
    root: Path
    profile_root: Path
    leases: int = 1


_lock = threading.RLock()
_views: dict[Path, _View] = {}
_drive_lock = Path.home() / ".meshia/locks/native-workspace-mount.lock"


def _retire(view_key: Path, view: _View) -> None:
    """Hold the caller's authoritative runtime lease until Windows detaches."""
    attempts = 0
    while True:
        try:
            if view.mount.close():
                break
        except BaseException:
            # The enclosing ExitStack must not release the borrowed owner
            # while its kernel view can still receive filesystem operations.
            pass
        attempts += 1
        if attempts in (1, 5) or attempts % 30 == 0:
            logging.getLogger(__name__).warning(
                "Holding isolated workspace owner until Windows releases its mount (attempt %d)", attempts)
        time.sleep(1)
    # Once Windows detached there is no kernel owner left to retain. An ACL
    # cleanup error must not strand a zero-lease registry entry indefinitely.
    _views.pop(view_key, None)
    revoke_runtime_grants(view.profile_root)


def security_descriptor(workspace: Path) -> str:
    user, package = identity(workspace)
    return (f"O:{user}G:{user}D:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;FA;;;{user})"
            f"(A;;0x1301bf;;;{package})S:(ML;;NW;;;LW)")


@contextmanager
def lease(owner: Any, *, workspace_name: str, session_id: str,
          state_home: Path) -> Iterator[Path]:
    if len(split_relative(workspace_name)) != 1 or len(split_relative(session_id)) != 1:
        raise StateError("Windows execution view requires one authenticated workspace route.")
    # A selected per-workspace backend must not be replaced by the account
    # catalog adapter. It owns exactly one name and never another workspace.
    if getattr(owner, "workspace_name", None) != workspace_name:
        raise StateError("Windows execution view does not match its leased workspace owner.")
    # Keep the execution principal tied to its authenticated session, never
    # to a reusable drive letter. WinFsp's FileSecurity supplies that exact
    # SID to the native launcher even though cwd is on a disposable drive.
    view_key = state_home / "native-workspaces" / session_id
    profile_root = view_key / workspace_name
    with _lock:
        view = _views.get(view_key)
        if view is not None and view.leases == 0:
            raise StateError("The Windows workspace view is still being released.")
        if view is not None:
            if view.owner is not owner or view.name != workspace_name:
                raise StateError("The Windows workspace view authority changed while commands are running.")
            if not view.mount.running:
                raise StateError("The Windows workspace view detached during execution.")
            view.leases += 1
        else:
            # Hold one current-user lock through registry admission and mount
            # readiness so other Meshia processes cannot select the same drive.
            # QueryDosDevice includes unavailable/foreign mappings; never enter
            # their filesystems or replace them. Fabric also rechecks admission.
            with file_lock(_drive_lock):
                occupied = mounted_drive_paths()
                if occupied is None:
                    raise StateError("Windows could not inspect available workspace drive letters.")
                mount_point = next((Path(f"{letter}:\\") for letter in "ZYXWVUTSRQPONMLKJIHGFED"
                                    if ntpath.normcase(f"{letter}:\\") not in occupied), None)
                if mount_point is None:
                    raise StateError("Windows has no free drive letter for workspace compute.")
                ensure_private_dir(view_key.parent)
                create_profile(profile_root)
                try:
                    mount = FabricFuseMount(_BorrowedBackend(owner), mount_point,
                        windows_workspace_security=security_descriptor(profile_root))
                except BaseException:
                    revoke_runtime_grants(profile_root)
                    raise
                view = _View(owner, workspace_name, mount, mount_point / workspace_name,
                             profile_root, leases=0)
                _views[view_key] = view
                try:
                    if not mount.start(timeout_seconds=20):
                        raise StateError("Windows could not mount its isolated workspace view.")
                except BaseException:
                    _retire(view_key, view)
                    raise
                view.leases = 1
    try:
        yield view.root
    finally:
        with _lock:
            view.leases -= 1
            if view.leases == 0:
                with file_lock(_drive_lock):
                    _retire(view_key, view)
