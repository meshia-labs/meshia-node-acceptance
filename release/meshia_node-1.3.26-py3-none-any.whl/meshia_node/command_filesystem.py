"""Typed commands over the existing shared filesystem owner, not its cache.

The runtime supplies a leased backend and an independently verified public
execution boundary. This adapter never constructs a backend, starts recovery,
or owns its lifetime. Host IO and compiler scratch remain outside this layer.
"""

from __future__ import annotations

import os
import base64
import binascii
import hashlib
import json
from collections import deque
from pathlib import Path
from typing import Any, Protocol

from .errors import InvalidTask, StateError
from .util import UUID_RE
from .workspace import TAGGED_SHA256_RE, WorkspaceBoundary, split_relative

# The command RPC imposes a 2 MiB payload budget inside its 4 MiB frame.
# Reserve explicit room for the response flags and request/response envelope.
MAX_COMMAND_LIST_JSON_BYTES = 2 * 1024 * 1024 - 4096


class CommandFilesystem(Protocol):
    @property
    def native_execution_root(self) -> Path: ...

    @property
    def root(self) -> Path: ...

    def absolute(self, path: str, allow_root: bool = False) -> Path: ...

    def read_file(self, path: str, max_bytes: int) -> tuple[bytes, bool]: ...

    def list(self, path: str, max_entries: int, recursive: bool = False) -> tuple[list[str], bool]: ...

    def write_file(self, path: str, data: bytes, *, create_parents: bool = False,
                   overwrite: bool = True, expected_sha256: str | None = None) -> dict[str, Any] | None: ...


class _ExecutionFilesystem:
    execution_workspace: WorkspaceBoundary | None

    @property
    def native_execution_root(self) -> Path:
        """Authenticated route; the timed native child validates its OS path."""
        if self.execution_workspace is None:
            raise StateError("The shared workspace is not mounted for command execution.")
        return self.execution_workspace.root

    @property
    def root(self) -> Path:
        if self.execution_workspace is None:
            raise StateError("The shared workspace is not mounted for command execution.")
        return self.execution_workspace.absolute(".", allow_root=True)

    def absolute(self, path: str, allow_root: bool = False) -> Path:
        if self.execution_workspace is None:
            raise StateError("The shared workspace is not mounted for command execution.")
        return self.execution_workspace.absolute(path, allow_root=allow_root)


class BackendCommandFilesystem(_ExecutionFilesystem):
    """One session's typed IO, with an optional verified mounted exec root.

``backend`` may be the sole in-process owner or its existing authenticated
process proxy. The runtime must hold its session lease until the command ends.
``execution_workspace`` is never the private materialized backing directory.
"""

    def __init__(self, backend: Any, workspace_name: str,
                 execution_workspace: WorkspaceBoundary | None = None) -> None:
        if len(split_relative(workspace_name)) != 1:
            raise InvalidTask("A command workspace must have one catalog label.")
        self.backend = backend
        self.workspace_name = workspace_name
        self.execution_workspace = execution_workspace

    def _path(self, path: str, *, allow_root: bool = False) -> str:
        parts = split_relative(path, allow_root=allow_root)
        return "/" + "/".join((self.workspace_name, *parts))

    def read_file(self, path: str, max_bytes: int) -> tuple[bytes, bool]:
        if type(max_bytes) is not int or not 1 <= max_bytes <= 1_000_000:
            raise InvalidTask("read_file max_bytes is outside the allowed range.")
        handle = self.backend.open(self._path(path), os.O_RDONLY)
        try:
            data = self.backend.read(handle, 0, max_bytes + 1)
            return data[:max_bytes], len(data) > max_bytes
        finally:
            self.backend.release(handle)

    def list(self, path: str = ".", max_entries: int = 1_000,
             recursive: bool = False) -> tuple[list[str], bool]:
        if type(max_entries) is not int or not 1 <= max_entries <= 10_000:
            raise InvalidTask("list max_entries is outside the allowed range.")
        pending = deque(((self._path(path, allow_root=True), ""),))
        entries: list[str] = []
        encoded_bytes = 2  # JSON array brackets; leave room for RPC envelope.
        while pending:
            parent, prefix = pending.popleft()
            for name, node in self.backend.listdir_entries(parent):
                # A corrupt proxy response must not inject another workspace
                # or an escaping path into the next recursive request.
                if len(split_relative(name)) != 1:
                    raise StateError("The shared directory returned an invalid child name.")
                if len(entries) == max_entries:
                    return entries, True
                relative = prefix + name
                entry = relative + "/" if node.is_directory else relative
                entry_bytes = len(json.dumps(entry, ensure_ascii=True)) + 2
                if encoded_bytes + entry_bytes > MAX_COMMAND_LIST_JSON_BYTES:
                    return entries, True
                entries.append(entry)
                encoded_bytes += entry_bytes
                if recursive and node.is_directory:
                    pending.append((parent + "/" + name, relative + "/"))
        return entries, False

    def write_file(self, path: str, data: bytes, *, create_parents: bool = False,
                   overwrite: bool = True, expected_sha256: str | None = None) -> dict[str, Any]:
        if not overwrite:
            raise InvalidTask("Typed command writes require overwrite semantics.")
        if not isinstance(data, bytes) or len(data) > 1_000_000:
            raise InvalidTask("Typed command writes must contain at most 1 MB of bytes.")
        if expected_sha256 is not None and (
            not isinstance(expected_sha256, str)
            or TAGGED_SHA256_RE.fullmatch(expected_sha256) is None
        ):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        # This owner operation validates the shared preimage and atomically
        # stages replacement bytes. Never emulate it with open(O_TRUNC): that
        # would alter the destination before CAS and journal partial failures.
        public_path = self._path(path)
        receipt = self.backend.command_write(public_path, data,
                                            expected_sha256=expected_sha256,
                                            create_parents=create_parents)
        return _write_receipt(receipt, path, data, public_path=public_path)


def _write_receipt(value: Any, path: str, data: bytes,
                   *, public_path: str | None = None) -> dict[str, Any]:
    """A local journal acknowledgement is not a remote publication receipt."""
    if not isinstance(value, dict):
        raise StateError("The shared command write acknowledgement is invalid.")
    actual_path = value.get("path")
    if not isinstance(actual_path, str) or not actual_path.startswith("/"):
        raise StateError("The shared command write acknowledgement has no public path.")
    parts = split_relative(actual_path[1:])
    expected_parts = split_relative(path)
    if (parts[1:] != expected_parts
            or (public_path is not None and actual_path != public_path)
            or type(value.get("size_bytes")) is not int
            or value["size_bytes"] != len(data)
            or value.get("sha256") != hashlib.sha256(data).hexdigest()
            or value.get("publication") not in ("journaled", "unchanged")):
        raise StateError("The shared command write acknowledgement does not match its bytes.")
    mutation = value.get("mutation_id")
    if ((mutation is not None and (not isinstance(mutation, str) or UUID_RE.fullmatch(mutation) is None))
            or (value["publication"] == "journaled" and mutation is None)):
        raise StateError("The shared command write acknowledgement has no journal identity.")
    return {key: value.get(key) for key in ("path", "sha256", "size_bytes", "mutation_id", "publication")}


def _decode_bytes(value: Any, limit: int) -> bytes:
    if not isinstance(value, str) or len(value) > 4 * ((limit + 2) // 3):
        raise InvalidTask("The shared command byte frame exceeds its limit.")
    try:
        data = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error) as error:
        raise InvalidTask("The shared command byte frame is invalid.") from error
    if len(data) > limit:
        raise InvalidTask("The shared command byte frame exceeds its limit.")
    return data


def execute_backend_command(backend: Any, workspace_name: str, operation: str,
                            **kwargs: Any) -> dict[str, Any]:
    """Strict bounded worker dispatch, reusing the same sole-owner adapter."""
    accepted = {
        "read": {"path", "max_bytes"},
        "list": {"path", "max_entries", "recursive"},
        "write": {"path", "data_base64", "expected_sha256", "create_parents"},
    }
    if operation not in accepted or not set(kwargs) <= accepted[operation]:
        raise InvalidTask("The shared command operation is invalid.")
    path = kwargs.get("path")
    if not isinstance(path, str):
        raise InvalidTask("The shared command path must be a string.")
    adapter = BackendCommandFilesystem(backend, workspace_name)
    if operation == "read":
        data, truncated = adapter.read_file(path, kwargs.get("max_bytes"))
        return {"data_base64": base64.b64encode(data).decode("ascii"), "truncated": truncated}
    if operation == "list":
        recursive = kwargs.get("recursive", False)
        if not isinstance(recursive, bool):
            raise InvalidTask("The shared command recursive flag is invalid.")
        entries, truncated = adapter.list(path, kwargs.get("max_entries"), recursive)
        return {"entries": entries, "truncated": truncated}
    create_parents = kwargs.get("create_parents", False)
    if not isinstance(create_parents, bool):
        raise InvalidTask("The shared command parent flag is invalid.")
    receipt = adapter.write_file(path, _decode_bytes(kwargs.get("data_base64"), 1_000_000),
                                 expected_sha256=kwargs.get("expected_sha256"),
                                 create_parents=create_parents)
    return {**receipt, "filesystem_journaled": True}


class RPCCommandFilesystem(_ExecutionFilesystem):
    """Typed IO forwarded to the existing split mount owner, without recovery."""

    def __init__(self, server: Any, session_id: str,
                 execution_workspace: WorkspaceBoundary | None = None) -> None:
        self.server = server
        self.session_id = session_id
        self.execution_workspace = execution_workspace

    def read_file(self, path: str, max_bytes: int) -> tuple[bytes, bool]:
        split_relative(path)
        if type(max_bytes) is not int or not 1 <= max_bytes <= 1_000_000:
            raise InvalidTask("read_file max_bytes is outside the allowed range.")
        result = self.server.command_filesystem(self.session_id, "read", path=path, max_bytes=max_bytes)
        if not isinstance(result, dict) or type(result.get("truncated")) is not bool:
            raise StateError("The shared command read acknowledgement is invalid.")
        return _decode_bytes(result.get("data_base64"), max_bytes), result["truncated"]

    def list(self, path: str = ".", max_entries: int = 1_000,
             recursive: bool = False) -> tuple[list[str], bool]:
        split_relative(path, allow_root=True)
        if type(max_entries) is not int or not 1 <= max_entries <= 10_000:
            raise InvalidTask("list max_entries is outside the allowed range.")
        result = self.server.command_filesystem(self.session_id, "list", path=path,
                                               max_entries=max_entries, recursive=recursive)
        if (not isinstance(result, dict) or type(result.get("truncated")) is not bool
                or not isinstance(result.get("entries"), list)
                or len(result["entries"]) > max_entries):
            raise StateError("The shared command listing acknowledgement is invalid.")
        for name in result["entries"]:
            if not isinstance(name, str):
                raise StateError("The shared command listing acknowledgement is invalid.")
            split_relative(name[:-1] if name.endswith("/") else name)
        return result["entries"], result["truncated"]

    def write_file(self, path: str, data: bytes, *, create_parents: bool = False,
                   overwrite: bool = True, expected_sha256: str | None = None) -> dict[str, Any]:
        split_relative(path)
        if not overwrite or not isinstance(data, bytes) or len(data) > 1_000_000:
            raise InvalidTask("Typed command writes must contain at most 1 MB of replacement bytes.")
        if expected_sha256 is not None and (
            not isinstance(expected_sha256, str)
            or TAGGED_SHA256_RE.fullmatch(expected_sha256) is None
        ):
            raise InvalidTask("expected_sha256 must be a tagged lowercase SHA-256 digest.")
        result = self.server.command_filesystem(self.session_id, "write", path=path,
            data_base64=base64.b64encode(data).decode("ascii"),
            expected_sha256=expected_sha256, create_parents=create_parents)
        if not isinstance(result, dict) or result.get("filesystem_journaled") is not True:
            raise StateError("The shared command write was not durably journaled.")
        return _write_receipt(result, path, data)
