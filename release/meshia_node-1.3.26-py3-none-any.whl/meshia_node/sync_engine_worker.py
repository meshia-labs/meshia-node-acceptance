"""Mount worker process and its supervisor.

Topology: the existing daemon stays the **engine** -- it keeps the transport,
authority, coordinators and polling, i.e. all the state that is expensive to
move -- and spawns a **mount worker** child that owns only the FUSE loop, its
own ``FabricDatabase`` handles and the CAS caches. The child is deliberately
the simple one, so supervision lives in the parent and a crashed child costs a
remount rather than a resync.

The mount is tied to the child's lifetime on purpose. If the child dies, the
filesystem disappears instead of serving stale metadata from a process whose
engine is gone -- fail closed, then restart.

Two shapes exist: ``single`` (the legacy one-workspace mount, one backend) and
``multi`` (the account-wide ``~/Meshia`` root, ``MultiWorkspaceMountBackend``
with one lazily activated backend per workspace, projected by the engine).

Stopping is graceful by construction. FUSE-T's kernel SMB client wedges
uninterruptibly if its helper dies with requests in flight, so the worker
never exits under a live mount: SIGTERM and a closed engine link both lead to
``FabricFuseMount.close`` retried until the OS mount table proves the detach,
and the supervisor's kill grace is longer than that retry budget.
"""

from __future__ import annotations

import errno
import json
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

from .errors import StateError
from .log import NULL_LOGGER, NodeLogger

# A crashing worker must not spin. Backoff grows to a ceiling, and a worker
# that survives this long is treated as healthy, resetting the sequence.
RESTART_BACKOFF_SECONDS = (0.5, 1.0, 2.0, 5.0, 10.0)
HEALTHY_AFTER_SECONDS = 60.0
# The worker's own unmount budget, then the supervisor's kill grace above it.
# Killing a worker with the mount attached is the one thing to avoid, so the
# supervisor waits out the whole unmount retry window before escalating. Both
# sit inside the service's launchd ExitTimeOut (30 s): past that, launchd
# kills the whole process group anyway, and a detach that has not happened in
# 20 s is not going to happen by waiting.
WORKER_UNMOUNT_RETRY_SECONDS = 1.0
WORKER_UNMOUNT_DEADLINE_SECONDS = 20.0
STOP_GRACE_SECONDS = WORKER_UNMOUNT_DEADLINE_SECONDS + 5.0
# The child polls for parent liveness so an orphan cannot outlive the engine
# holding a mount nobody supervises.
PARENT_WATCH_INTERVAL_SECONDS = 2.0
# The worker's FUSE loop ended without a stop request and the OS mount table
# no longer lists the mount: an operator released it (`mount --release`, the
# installer before a swap). The supervisor must NOT remount behind them; the
# engine reports it and exits so launchd recreates the service, exactly as
# the in-process mount guard did.
MOUNT_RELEASED_EXIT_CODE = 3


class MountWorkerSpec:
    """Everything the worker needs; deliberately no credentials or transport."""

    def __init__(
        self,
        *,
        home: str,
        mount_point: str,
        mode: str = "single",
        database_path: str | None = None,
        cache_path: str | None = None,
        workspace_root: str | None = None,
        workspace_name: str | None = None,
        session_id: str | None = None,
        storage_root: str | None = None,
        mount_state_path: str | None = None,
        fuse_t_transport_backend: str | None = None,
    ) -> None:
        if mode not in ("single", "multi"):
            raise ValueError("mode must be single or multi")
        if mode == "single" and not (
            database_path and cache_path and workspace_root and workspace_name
        ):
            raise ValueError("a single-workspace worker needs its workspace state")
        self.home = home
        self.mode = mode
        self.database_path = database_path
        self.cache_path = cache_path
        self.workspace_root = workspace_root
        self.workspace_name = workspace_name
        self.session_id = session_id
        self.storage_root = storage_root or home
        self.mount_point = mount_point
        self.mount_state_path = mount_state_path
        self.fuse_t_transport_backend = fuse_t_transport_backend

    def to_json(self) -> str:
        return json.dumps(self.__dict__, separators=(",", ":"))

    @classmethod
    def from_json(cls, blob: str) -> "MountWorkerSpec":
        return cls(**json.loads(blob))


def _install_worker_signal_handlers(stop: threading.Event, logger: NodeLogger) -> None:
    def handler(signum: int, _frame: Any) -> None:
        logger.record("mount_worker_stop_requested", signal=signum)
        stop.set()

    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        try:
            signal.signal(getattr(signal, name), handler)
        except (ValueError, AttributeError, OSError):  # pragma: no cover - non-main thread
            pass


def _unmount_until_released(mount: Any, logger: NodeLogger) -> bool:
    """Detach the native mount, retrying until the OS agrees or the budget ends."""

    deadline = time.monotonic() + WORKER_UNMOUNT_DEADLINE_SECONDS
    attempts = 0
    while True:
        attempts += 1
        try:
            released = bool(mount.close())
        except Exception as error:  # noqa: BLE001 - keep retrying the detach
            released = False
            logger.record(
                "mount_worker_unmount_retry_failed",
                attempts=attempts,
                error_type=type(error).__name__,
                error=str(error)[:200],
            )
        if released or bool(getattr(mount, "detached_for_process_exit", False)):
            logger.record("mount_worker_unmounted", attempts=attempts)
            return True
        if time.monotonic() >= deadline:
            logger.record("mount_worker_unmount_deadline", attempts=attempts)
            return False
        time.sleep(WORKER_UNMOUNT_RETRY_SECONDS)


def _mount_released_externally(mount_point: str) -> bool:
    """True when the OS mount table proves the mount is gone."""

    try:
        from .fabric_mount import mount_registration_state

        return mount_registration_state(Path(mount_point)) is False
    except Exception:  # noqa: BLE001 - unknown means "not proven released"
        return False


def run_mount_worker(
    spec: MountWorkerSpec,
    *,
    logger: NodeLogger = NULL_LOGGER,
    stop_event: threading.Event | None = None,
) -> int:
    """Child entry point: mount, serve, and exit when the engine goes away."""

    from .fabric_mount import FabricFuseMount
    from .sync_engine_split import connect_engine

    stop = stop_event or threading.Event()
    _install_worker_signal_handlers(stop, logger)
    link = connect_engine(spec.home)
    manager: Any = None
    closers: list[Any] = []
    try:
        if spec.mode == "multi":
            from .mount_worker_runtime import MountWorkerWorkspaceManager

            manager = MountWorkerWorkspaceManager(
                link,
                storage_root=spec.storage_root,
                fuse_t_transport_backend=spec.fuse_t_transport_backend,
                logger=logger,
            )
            manager.pull_topology()
            backend: Any = manager.mount_backend
        else:
            from .fabric_cache import FabricRangeCache
            from .fabric_db import FabricDatabase
            from .fabric_mount import FabricMountBackend
            from .sync_engine_split import LocalCacheReader
            from .workspace import WorkspaceBoundary

            assert spec.database_path and spec.cache_path
            assert spec.workspace_root and spec.workspace_name
            database = FabricDatabase(Path(spec.database_path))
            closers.append(database.close)
            cache = FabricRangeCache(Path(spec.cache_path))
            workspace = WorkspaceBoundary(Path(spec.workspace_root))
            closers.append(workspace.close)
            proxy = link.proxy(None, local_reader=LocalCacheReader(database, cache))
            backend = FabricMountBackend(
                database,
                proxy,  # type: ignore[arg-type] - the proxy is the coordinator surface
                workspace,
                spec.workspace_name,
                logger=logger,
                fuse_t_transport_backend=spec.fuse_t_transport_backend,
            )

            def command_filesystem(
                session_id: str, operation: str, **arguments: Any
            ) -> dict[str, Any]:
                from .command_filesystem import execute_backend_command

                if not spec.session_id or session_id != spec.session_id:
                    raise OSError(errno.ENOENT, "The workspace is not served by this mount.")
                return execute_backend_command(
                    backend, spec.workspace_name, operation, **arguments
                )

            link.install_filesystem_command_handler(command_filesystem)
        mount = FabricFuseMount(
            backend,
            spec.mount_point,
            state_path=spec.mount_state_path,
            logger=logger,
        )
        logger.record(
            "mount_worker_starting", mount_point=str(spec.mount_point), mode=spec.mode
        )
        started = mount.start()
        if not started:
            logger.record("mount_worker_mount_not_started")
            return 1
        parent_pid = os.getppid()
        exit_code = 0
        try:
            while not stop.is_set():
                if stop.wait(PARENT_WATCH_INTERVAL_SECONDS):
                    break
                if link.closed:
                    logger.record("mount_worker_engine_link_closed")
                    break
                if os.getppid() != parent_pid:
                    logger.record("mount_worker_orphaned", original_parent=parent_pid)
                    break
                if not mount.running:
                    released = _mount_released_externally(spec.mount_point)
                    logger.record(
                        "mount_worker_mount_stopped", released_externally=released
                    )
                    exit_code = MOUNT_RELEASED_EXIT_CODE if released else 1
                    break
        except KeyboardInterrupt:
            pass
        finally:
            # Unmount before exiting: a mount outliving its worker would serve
            # a namespace with no engine behind it, and a worker exiting under
            # a live FUSE-T mount wedges the kernel client.
            if not _unmount_until_released(mount, logger):
                exit_code = 2
        return exit_code
    finally:
        if manager is not None:
            try:
                manager.close()
            except Exception as error:  # noqa: BLE001 - teardown must not mask the exit
                logger.record("mount_worker_manager_close_failed", error=str(error)[:200])
        for close in reversed(closers):
            try:
                close()
            except Exception:  # noqa: BLE001
                pass
        link.close()


class MountWorkerSupervisor:
    """Parent-side lifecycle: spawn, watch, restart with backoff, stop."""

    def __init__(
        self,
        spec: MountWorkerSpec,
        *,
        logger: NodeLogger = NULL_LOGGER,
        spawn: Any = None,
    ) -> None:
        self._spec = spec
        self._logger = logger
        self._spawn = spawn or self._spawn_subprocess
        self._process: Any = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._restarts = 0
        self._thread: threading.Thread | None = None
        self._released_externally = threading.Event()

    @property
    def restarts(self) -> int:
        return self._restarts

    @property
    def released_externally(self) -> bool:
        """The worker reported its mount released by an operator; not restarted."""

        return self._released_externally.is_set()

    def require_mounted(self) -> None:
        """Raise the in-process mount guard's error once the mount was released."""

        if self._released_externally.is_set():
            raise StateError(
                "The native Meshia mount was disconnected outside Meshia; "
                "the service will recreate it."
            )

    @property
    def worker_pid(self) -> int | None:
        with self._lock:
            process = self._process
        if process is None:
            return None
        pid = getattr(process, "pid", None)
        return int(pid) if isinstance(pid, int) and process.poll() is None else None

    def _spawn_subprocess(self) -> Any:
        # The service itself runs through the runtime's launcher; the worker
        # reuses the engine's interpreter and package, and names the same
        # state home explicitly so it never resolves a different one.
        return subprocess.Popen(
            [
                sys.executable,
                "-m",
                "meshia_node.cli",
                "--home",
                self._spec.home,
                "_mount-worker",
                "--spec",
                self._spec.to_json(),
            ],
            stdin=subprocess.DEVNULL,
        )

    def start(self) -> None:
        with self._lock:
            if self._thread is not None:
                return
            self._thread = threading.Thread(
                target=self._supervise, name="meshia-mount-supervisor", daemon=True
            )
            self._thread.start()

    def _supervise(self) -> None:
        attempt = 0
        while not self._stop.is_set():
            started = time.monotonic()
            try:
                with self._lock:
                    if self._stop.is_set():
                        return
                    self._process = self._spawn()
            except Exception as error:  # noqa: BLE001 - report and back off
                self._logger.record("mount_worker_spawn_failed", error=str(error)[:200])
                if self._stop.wait(RESTART_BACKOFF_SECONDS[-1]):
                    return
                continue
            code = self._wait_for_exit()
            if self._stop.is_set():
                return
            lived = time.monotonic() - started
            if code == MOUNT_RELEASED_EXIT_CODE:
                self._logger.record("mount_worker_released_externally")
                self._released_externally.set()
                return
            self._restarts += 1
            # A worker that ran long enough was healthy; treat this as a fresh
            # failure rather than escalating a backoff earned much earlier.
            attempt = 0 if lived >= HEALTHY_AFTER_SECONDS else attempt + 1
            delay = RESTART_BACKOFF_SECONDS[
                min(attempt, len(RESTART_BACKOFF_SECONDS) - 1)
            ]
            self._logger.record(
                "mount_worker_exited",
                exit_code=code,
                lived_seconds=round(lived, 2),
                restart_in_seconds=delay,
                restarts=self._restarts,
            )
            if self._stop.wait(delay):
                return

    def _wait_for_exit(self) -> int | None:
        process = self._process
        if process is None:
            return None
        while not self._stop.is_set():
            code = process.poll()
            if code is not None:
                return code
            time.sleep(0.1)
        return None

    def stop(self) -> bool:
        self._stop.set()
        with self._lock:
            process = self._process
        if process is not None and process.poll() is None:
            try:
                process.send_signal(signal.SIGTERM)
            except Exception:  # noqa: BLE001
                pass
            deadline = time.monotonic() + STOP_GRACE_SECONDS
            while time.monotonic() < deadline and process.poll() is None:
                time.sleep(0.05)
            if process.poll() is None:
                self._logger.record("mount_worker_killed_after_grace")
                try:
                    process.kill()
                except Exception:  # noqa: BLE001
                    pass
        thread = self._thread
        if thread is not None:
            thread.join(timeout=STOP_GRACE_SECONDS)
        self._thread = None
        # A worker can exit2 after its detach deadline while Linux retains a
        # disconnected FUSE mount. Process exit is never mount-absence proof.
        detached = process is None or (
            process.poll() is not None and _mount_released_externally(self._spec.mount_point)
        )
        if not detached:
            self._logger.record("mount_worker_stop_incomplete", mount_point=self._spec.mount_point)
        else:
            with self._lock:
                if self._process is process:
                    self._process = None
        return detached
