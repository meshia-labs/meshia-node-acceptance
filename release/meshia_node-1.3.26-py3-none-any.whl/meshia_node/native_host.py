"""Verify and stage Meshia's optional, distribution-signed macOS service host.

The release manifest authenticates the archive's publisher/checksum. Apple then
verifies its Developer ID signature and notarization. Activation invokes only
the verified host's fixed LaunchServices registration mode. Archive operations
never execute bundled code; this module never signs, grants permissions, or
replaces an existing runtime artifact.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path, PurePosixPath
import plistlib
import re
import stat
import sys
import tempfile
import unicodedata
import zipfile

if not __package__:  # Publisher gate: python path/to/native_host.py verify archive.zip
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from meshia_node.util import run_bounded_process


BUNDLE_NAME = "Meshia Node.app"
BUNDLE_IDENTIFIER = "io.meshia.node"
EXECUTABLE_NAME = "MeshiaNode"
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_EXPANDED_BYTES = 128 * 1024 * 1024
MAX_MEMBERS = 2048
APPLE_TOOL_TIMEOUT_SECONDS = 30.0
REGISTRATION_TIMEOUT_SECONDS = 10.0
DEVELOPER_ID_REQUIREMENT = (
    'anchor apple generic and certificate 1[field.1.2.840.113635.100.6.2.6] exists '
    'and certificate leaf[field.1.2.840.113635.100.6.1.13] exists '
    f'and identifier "{BUNDLE_IDENTIFIER}"'
)


class NativeHostError(ValueError):
    """An optional native host is present but cannot be trusted for execution."""


def account_home() -> Path:
    import pwd

    if os.getuid() == 0 or os.getuid() != os.geteuid():
        raise NativeHostError("Meshia Node requires the installing, non-root macOS account.")
    return Path(pwd.getpwuid(os.getuid()).pw_dir)


def _require_macos() -> None:
    if sys.platform != "darwin":
        raise NativeHostError("Meshia Node native host verification requires macOS.")


def _owned_path(path: Path, *, directory: bool) -> os.stat_result:
    metadata = path.lstat()
    correct_type = stat.S_ISDIR if directory else stat.S_ISREG
    if (not correct_type(metadata.st_mode) or metadata.st_uid != os.getuid()
            or metadata.st_mode & (stat.S_IWGRP | stat.S_IWOTH | stat.S_ISUID | stat.S_ISGID)):
        raise NativeHostError("Meshia Node artifact must contain only owned, safely writable regular files and directories.")
    return metadata


def _apple_tool(*command: str, merge_stderr: bool = True) -> str:
    result = run_bounded_process(
        list(command), timeout_seconds=APPLE_TOOL_TIMEOUT_SECONDS,
        max_output_bytes=64 * 1024, merge_stderr=merge_stderr,
    )
    if result is None or result[0] != 0:
        raise NativeHostError(f"Meshia Node verification failed or timed out: {Path(command[0]).name} {command[1]}.")
    return result[1]


def _verify_apple_distribution(app: Path, *, publisher: bool = False) -> None:
    _apple_tool("/usr/bin/codesign", "--verify", "--deep", "--strict", "--all-architectures", str(app))
    for architecture in ("arm64", "x86_64"):
        # codesign treats a plain requirement argument as a filename. The '='
        # prefix selects inline requirement source without changing the predicate.
        _apple_tool("/usr/bin/codesign", "--verify", "--strict", "--architecture", architecture,
                    "--test-requirement", "=" + DEVELOPER_ID_REQUIREMENT, str(app))
        details = _apple_tool("/usr/bin/codesign", "--display", "--verbose=4",
                              "--architecture", architecture, str(app))
        if not re.search(r"^CodeDirectory .*flags=0x[0-9a-f]+\([^\n)]*\bruntime\b", details, re.M):
            raise NativeHostError("Meshia Node requires hardened runtime in both architectures.")
        if not re.search(r"^Timestamp=.+$", details, re.M):
            raise NativeHostError("Meshia Node requires a secure signing timestamp.")
        entitlement_bytes = _apple_tool(
            "/usr/bin/codesign", "--display", "--entitlements", ":-",
            "--architecture", architecture, str(app), merge_stderr=False,
        ).encode("utf-8")
        try:
            entitlements = plistlib.loads(entitlement_bytes) if entitlement_bytes.strip() else {}
        except ValueError as error:
            raise NativeHostError("Meshia Node signed entitlements are unreadable.") from error
        if not isinstance(entitlements, dict) or any(entitlements.get(key) for key in (
            "com.apple.security.app-sandbox", "com.apple.security.inherit",
            "com.apple.security.get-task-allow", "get-task-allow",
        )):
            raise NativeHostError("Meshia Node requires unsandboxed distribution entitlements without debugger access.")
    _apple_tool("/usr/sbin/spctl", "--assess", "--type", "execute", str(app))
    if publisher:
        # The release gate proves the ticket in the exact published archive.
        # Customers verify that archive's manifest SHA, signature and Gatekeeper
        # acceptance using system tools; they never need Xcode's stapler tool.
        _apple_tool("/usr/bin/xcrun", "stapler", "validate", str(app))


def verify_bundle(app: Path, *, publisher: bool = False) -> Path:
    """Return the verified executable, without executing any bundled code."""
    _require_macos()
    if app.name != BUNDLE_NAME:
        raise NativeHostError("Meshia Node bundle must have its fixed product name.")
    _owned_path(app, directory=True)
    count = total = 0
    for root, directories, files in os.walk(app, followlinks=False):
        for name in directories + files:
            path = Path(root) / name
            metadata = _owned_path(path, directory=name in directories)
            count += 1
            total += metadata.st_size if name in files else 0
            if count > MAX_MEMBERS or total > MAX_EXPANDED_BYTES:
                raise NativeHostError("Meshia Node bundle exceeds the distribution size limit.")
    info_path = app / "Contents" / "Info.plist"
    if _owned_path(info_path, directory=False).st_size > 64 * 1024:
        raise NativeHostError("Meshia Node bundle metadata is too large.")
    try:
        info = plistlib.loads(info_path.read_bytes())
    except (ValueError, plistlib.InvalidFileException) as error:
        raise NativeHostError("Meshia Node bundle metadata is invalid.") from error
    if (not isinstance(info, dict) or info.get("CFBundleIdentifier") != BUNDLE_IDENTIFIER
            or info.get("CFBundleExecutable") != EXECUTABLE_NAME
            or info.get("CFBundlePackageType") != "APPL"):
        raise NativeHostError("Meshia Node bundle identity is invalid.")
    executable = app / "Contents" / "MacOS" / EXECUTABLE_NAME
    if not _owned_path(executable, directory=False).st_mode & stat.S_IXUSR:
        raise NativeHostError("Meshia Node native executable is not executable.")
    with executable.open("rb") as stream:
        # Universal or single-slice Mach-O; Apple verifies the required slices.
        if stream.read(4) not in (b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca", b"\xca\xfe\xba\xbf",
                                  b"\xbf\xba\xfe\xca", b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf"):
            raise NativeHostError("Meshia Node host must be a native Mach-O executable.")
    _verify_apple_distribution(app, publisher=publisher)
    return executable


def expected_host(console: Path, home: Path) -> Path | None:
    """The fixed eligible identity, without approving or executing its contents."""
    if sys.platform != "darwin" or home != account_home() / ".meshia":
        return None
    return console.parent.parent / "native" / BUNDLE_NAME / "Contents" / "MacOS" / EXECUTABLE_NAME


def discover_host(console: Path, home: Path) -> Path | None:
    """Verify the optional app immediately before an activation."""
    expected = expected_host(console, home)
    if expected is None:
        return None
    runtime = console.parent.parent
    app = runtime / "native" / BUNDLE_NAME
    # lexists also sees dangling links: an invalid present artifact must fail.
    if not os.path.lexists(app):
        if os.path.lexists(app.parent):
            _owned_path(app.parent, directory=True)
        return None
    for directory in (runtime, console.parent, app.parent):
        _owned_path(directory, directory=True)
    return verify_bundle(app)


def register_verified_host(executable: Path) -> None:
    """Register the just-verified app with LaunchServices before activation."""
    _require_macos()
    result = run_bounded_process(
        [str(executable), "--register"], timeout_seconds=REGISTRATION_TIMEOUT_SECONDS,
        max_output_bytes=4096, merge_stderr=False,
    )
    if result is None or result[0] != 0:
        raise NativeHostError("Meshia Node LaunchServices registration failed or timed out.")


def _process_executable(pid: int) -> Path | None:
    """Read the kernel's executable path, never a caller-supplied environment hint."""
    import ctypes

    try:
        library = ctypes.CDLL("/usr/lib/libproc.dylib")
        probe = library.proc_pidpath
        probe.argtypes = (ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32)
        probe.restype = ctypes.c_int
        buffer = ctypes.create_string_buffer(4096)
        if probe(pid, buffer, len(buffer)) <= 0:
            return None
        return Path(os.fsdecode(buffer.value))
    except (OSError, AttributeError, ValueError):
        return None


def running_host_identity(console: Path, home: Path) -> tuple[Path, int] | None:
    """Capture the real native parent; activation owns distribution verification."""
    expected = expected_host(console, home)
    if expected is None:
        return None
    parent = os.getppid()
    if parent <= 1 or _process_executable(parent) != expected:
        return None
    if os.getppid() != parent:
        return None
    return expected, parent


def _process_parent(pid: int) -> int | None:
    result = run_bounded_process(
        ["/bin/ps", "-p", str(pid), "-o", "ppid="],
        timeout_seconds=2.0, max_output_bytes=64, merge_stderr=False,
    )
    if result is None or result[0] != 0 or not result[1].strip().isdigit():
        return None
    return int(result[1].strip())


def owns_runner(pid: int, parent: int | None, executable: Path) -> bool:
    """Read the live parent relationship without launching any bundled code."""
    return bool(
        sys.platform == "darwin" and isinstance(parent, int) and not isinstance(parent, bool)
        and parent > 1 and pid > 1 and pid != parent
        and _process_parent(pid) == parent
        and _process_executable(parent) == executable
    )


def _validate_archive(archive: zipfile.ZipFile) -> None:
    members = archive.infolist()
    if not members or len(members) > MAX_MEMBERS:
        raise NativeHostError("Meshia Node archive has an invalid entry count.")
    seen: dict[str, bool] = {}
    total = 0
    for member in members:
        name = member.filename
        path = PurePosixPath(name)
        canonical = unicodedata.normalize("NFC", path.as_posix()).casefold()
        mode = member.external_attr >> 16
        is_directory = member.is_dir()
        if (not path.parts or path.parts[0] != BUNDLE_NAME or path.is_absolute()
                or ".." in path.parts or "\\" in name or "\x00" in member.orig_filename
                or path.as_posix() != name.rstrip("/") or canonical in seen
                or member.flag_bits & 1
                or stat.S_IFMT(mode) not in (0, stat.S_IFDIR if is_directory else stat.S_IFREG)
                or mode & (stat.S_IWGRP | stat.S_IWOTH | stat.S_ISUID | stat.S_ISGID)):
            raise NativeHostError("Meshia Node archive contains an unsafe or duplicate entry.")
        seen[canonical] = is_directory
        total += member.file_size
        if total > MAX_EXPANDED_BYTES:
            raise NativeHostError("Meshia Node archive exceeds the expanded size limit.")
    for name in seen:
        for parent in PurePosixPath(name).parents:
            if seen.get(str(parent)) is False:
                raise NativeHostError("Meshia Node archive contains a file/directory collision.")


def _extract_verified(archive_path: Path, temporary: Path, *, publisher: bool = False) -> Path:
    # Verify and extract one private snapshot; do not reopen a caller-replaceable
    # archive after validating its directory. Never trust ditto with unsafe paths.
    snapshot = temporary / "archive.zip"
    nofollow = getattr(os, "O_NOFOLLOW", None)
    if nofollow is None:
        raise NativeHostError("Meshia Node archive verification needs no-follow file support.")
    descriptor = os.open(archive_path, os.O_RDONLY | nofollow)
    with os.fdopen(descriptor, "rb") as source:
        metadata = os.fstat(source.fileno())
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > MAX_ARCHIVE_BYTES:
            raise NativeHostError("Meshia Node archive must be a bounded regular file.")
        with snapshot.open("xb") as destination:
            copied = 0
            while chunk := source.read(1024 * 1024):
                copied += len(chunk)
                if copied > MAX_ARCHIVE_BYTES:
                    raise NativeHostError("Meshia Node archive exceeds the size limit.")
                destination.write(chunk)
    extracted = temporary / "extracted"
    extracted.mkdir(mode=0o700)
    with zipfile.ZipFile(snapshot) as archive:
        _validate_archive(archive)
        # One parser validates and extracts exact members. The strict archive
        # contains no AppleDouble/link metadata; actual stapler validation below
        # remains mandatory after extraction.
        for member in archive.infolist():
            destination = extracted.joinpath(*PurePosixPath(member.filename).parts)
            if member.is_dir():
                destination.mkdir(mode=0o700, parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with archive.open(member) as source, destination.open("xb") as target:
                copied = 0
                while chunk := source.read(1024 * 1024):
                    copied += len(chunk)
                    if copied > member.file_size:
                        raise NativeHostError("Meshia Node archive entry exceeds its declared size.")
                    target.write(chunk)
            mode = (member.external_attr >> 16) & 0o777
            destination.chmod(mode or 0o600)
    app = extracted / BUNDLE_NAME
    verify_bundle(app, publisher=publisher)
    return app


def verify_archive(archive_path: Path) -> None:
    _require_macos()
    with tempfile.TemporaryDirectory(prefix="meshia-native-verify-") as temporary:
        _extract_verified(archive_path, Path(temporary), publisher=True)


def stage_archive(archive_path: Path, runtime: Path) -> Path:
    _require_macos()
    if not runtime.is_absolute() or runtime != runtime.resolve():
        raise NativeHostError("Meshia Node candidate runtime must be an exact absolute directory.")
    _owned_path(runtime, directory=True)
    native = runtime / "native"
    if os.path.lexists(native):
        raise NativeHostError("Meshia Node candidate already contains a native destination; refusing to replace it.")
    with tempfile.TemporaryDirectory(prefix=".meshia-native-stage-", dir=runtime) as temporary:
        app = _extract_verified(archive_path, Path(temporary))
        # Claim the destination exclusively after all verification. rename of the
        # app publishes the whole verified bundle atomically on the same volume.
        native.mkdir(mode=0o700)
        try:
            app.rename(native / BUNDLE_NAME)
        except BaseException:
            native.rmdir()
            raise
    return native / BUNDLE_NAME


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("verify").add_argument("archive", type=Path)
    commands.add_parser("check").add_argument("bundle", type=Path)
    stage = commands.add_parser("stage")
    stage.add_argument("archive", type=Path)
    stage.add_argument("runtime", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "stage":
            stage_archive(args.archive, args.runtime)
        elif args.command == "check":
            verify_bundle(args.bundle)
        else:
            verify_archive(args.archive)
    except (NativeHostError, OSError, ValueError, zipfile.BadZipFile) as error:
        print(f"Meshia Node native host: {error}", file=sys.stderr)
        return 1
    print("Meshia Node native host verified" + (" and staged." if args.command == "stage" else "."))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
