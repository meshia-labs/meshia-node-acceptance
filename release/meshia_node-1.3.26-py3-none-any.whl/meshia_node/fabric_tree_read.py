"""Immutable tree reads through the installed client's existing range cache."""
from __future__ import annotations

import hashlib
import copy
from typing import Callable, Iterator

from .fabric_cache import FabricRangeCache, FetchedRange
from .fabric_contract_generated import FileTree, Node, decode_node, parse_file_tree_descriptor, file_tree_identity_bytes


class FabricTreeReader:
    """Resolve bounded windows and carry only their metadata ancestry to transport.

    The object adapter validates provider range receipts (or hashes a complete
    object). Tree metadata is independently hashed before following references.
    Immutable object extents reuse the same cache across roots and file paths.
    """
    def __init__(self, descriptor, digest: str, size: int, *, cache: FabricRangeCache, generation: int,
                 fetch: Callable[[str, int, int, int, tuple[bytes, ...]], bytes],
                 check: Callable[[], None] | None = None):
        parsed_size, root = parse_file_tree_descriptor(descriptor)
        if parsed_size != size or hashlib.sha256(file_tree_identity_bytes(descriptor)).hexdigest() != digest:
            raise ValueError("The tree descriptor does not bind its file identity")
        self._descriptor = FileTree(size, root, load_node=None, read_object=None, put_object=None).descriptor(descriptor["storage"]["kind"])
        self.size, self.cache, self.fetch = size, cache, fetch
        self.generation = generation
        self.check = check
        self._last: tuple[int, bytes] = (0, b"")

    @property
    def descriptor(self):
        if self.check is not None:
            self.check()
        return copy.deepcopy(self._descriptor)

    def read(self, offset: int, length: int) -> bytes:
        if (type(offset) is not int or type(length) is not int or offset < 0
                or length < 0 or length > 1024 * 1024 or offset + length > self.size):
            raise ValueError("The tree read requires a bounded file range")
        if self.check is not None:
            self.check()
        start, cached = self._last
        if start <= offset and offset + length <= start + len(cached):
            data = cached[offset - start:offset - start + length]
        else:
            data = self._window(offset, length)
            self._last = (offset, data)
        if self.check is not None:
            self.check()
        return data

    def stream(self, offset: int, length: int) -> Iterator[bytes]:
        if (type(offset) is not int or type(length) is not int or offset < 0
                or length < 0 or offset + length > self.size):
            raise ValueError("The tree read range exceeds the file")
        for start in range(offset, offset + length, 1024 * 1024):
            count = min(1024 * 1024, offset + length - start)
            yield self.read(start, count)
        if self.check is not None:
            self.check()

    def _window(self, offset: int, length: int) -> bytes:
        # Rebuild ancestry from the root per window. A full-file stream never
        # accumulates a file-wide map; cached node bytes need no network read.
        size, root = parse_file_tree_descriptor(self.descriptor)
        paths = {}
        if root is not None:
            paths[(root.sha256, root.size if isinstance(root, Node) else root.object_size,
                   "node" if isinstance(root, Node) else "data")] = (
                (), self.descriptor["tree"]["height"])

        def read(digest, object_size, start, count, kind="data"):
            ancestors, _ = paths[(digest, object_size, kind)]
            def fetch(_path, _digest, _size, low, high):
                data = self.fetch(digest, object_size, low, high, ancestors)
                if kind == "node" and (len(data) != object_size or hashlib.sha256(data).hexdigest() != digest):
                    raise ValueError("The tree metadata failed its immutable identity")
                return FetchedRange(data, hashlib.sha256(data).hexdigest(), self.generation, None)
            return self.cache.read_range("tree-object", digest, object_size, start, count, self.generation, None, fetch)

        def load(digest, object_size):
            ancestors, height = paths[(digest, object_size, "node")]
            data = read(digest, object_size, 0, object_size, "node")
            if len(data) != object_size or hashlib.sha256(data).hexdigest() != digest:
                raise ValueError("The tree metadata failed its immutable identity")
            children = decode_node(data, height)
            for child in children:
                if child is not None:
                    key = (child.sha256, child.size if isinstance(child, Node) else child.object_size,
                           "node" if isinstance(child, Node) else "data")
                    paths.setdefault(key, (ancestors + (data,), height - 1))
            return data

        tree = FileTree(size, root, load_node=load, read_object=read, put_object=None)
        return tree.read(offset, length)
