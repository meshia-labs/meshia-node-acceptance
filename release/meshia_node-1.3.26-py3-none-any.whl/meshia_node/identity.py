"""Device identity: a P-256 signing key that never leaves this machine.

Parity notes with ``Sources/MeshiaCore/DeviceIdentity.swift``:

* public key is exported as RFC 5480 SPKI PEM (``public_key_format: spki-pem``);
* signatures are ECDSA-SHA256, strict-DER, **low-S normalised**, then unpadded
  base64url — the control plane rejects high-S and non-minimal DER
  (``isStrictLowSP256Signature`` in web/lib/connected-host-auth.ts);
* ``enrollment_idempotency_key`` is derived deterministically from the SPKI
  digest so a retried enrollment is idempotent for the same key;
* ``installation_id`` is a persisted random UUID.
"""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils as asym_utils

from .errors import StateError
from .util import b64url_unpadded, ensure_private_dir, sha256_hex, write_private_file

ENROLLMENT_PROOF_PREFIX = "meshia.connected-host-enrollment-proof.v1"
KEY_ALGORITHM = "p256-sha256"
PUBLIC_KEY_FORMAT = "spki-pem"
# How the private key is protected at rest, reported in enrollment capabilities.
KEY_PROTECTION = (
    "windows_file_key_owner_dacl" if os.name == "nt" else "posix_file_key_0600"
)
_P256_ORDER = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551


@dataclass(frozen=True)
class IdentityDescription:
    public_key_spki_pem: str
    public_key_sha256: str
    key_id: str
    enrollment_idempotency_key: str
    installation_id: str
    protection: str


def _deterministic_uuid(digest: bytes) -> str:
    """Shape 16 digest bytes into a v5-flagged UUID string (matches Swift)."""
    value = bytearray(digest[:16])
    value[6] = (value[6] & 0x0F) | 0x50
    value[8] = (value[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(value)))


def normalize_low_s(der: bytes) -> bytes:
    """Re-encode a DER ECDSA signature with S in the lower half of the order."""
    r, s = asym_utils.decode_dss_signature(der)
    if s > _P256_ORDER // 2:
        s = _P256_ORDER - s
    return asym_utils.encode_dss_signature(r, s)


class DeviceIdentity:
    """Owns the on-disk private key. The key bytes never leave this process."""

    def __init__(self, key: ec.EllipticCurvePrivateKey, key_path: Path, installation_id: str) -> None:
        self._key = key
        self.key_path = key_path
        self.installation_id = installation_id

    # ---------------------------------------------------------------- lifecycle

    @classmethod
    def load_or_create(cls, identity_dir: Path) -> "DeviceIdentity":
        ensure_private_dir(identity_dir)
        key_path = identity_dir / "device-key.pem"
        if key_path.exists():
            cls._require_private_mode(key_path)
            loaded = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
            if not isinstance(loaded, ec.EllipticCurvePrivateKey) or not isinstance(
                loaded.curve, ec.SECP256R1
            ):
                raise StateError("The stored device key is not a P-256 private key.")
            key = loaded
        else:
            key = ec.generate_private_key(ec.SECP256R1())
            write_private_file(
                key_path,
                key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption(),
                ),
            )
            try:
                # The enrollment capability may only claim protected key
                # storage after the newly-created file itself passes the same
                # live permission check used for an existing key. A private
                # parent DACL is necessary but not sufficient proof because a
                # file ACL can be changed independently.
                cls._require_private_mode(key_path)
            except BaseException:
                # Never leave a freshly-generated, unverified signing key on
                # disk. Existing keys are deliberately left intact so an ACL
                # repair can recover the same enrolled device identity.
                try:
                    key_path.unlink()
                except OSError:
                    pass
                raise
        return cls(key, key_path, cls._installation_id(identity_dir))

    @staticmethod
    def _installation_id(identity_dir: Path) -> str:
        path = identity_dir / "installation-id"
        if path.exists():
            candidate = path.read_text(encoding="utf-8").strip()
            try:
                return str(uuid.UUID(candidate))
            except ValueError:
                pass
        value = str(uuid.uuid4())
        write_private_file(path, f"{value}\n".encode("utf-8"))
        return value

    @staticmethod
    def _require_private_mode(path: Path) -> None:
        if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
            # POSIX mode bits are synthetic on Windows (a regular file reports
            # 0666); privacy is the DACL, so that is what gets verified.
            from .winsec import is_owner_restricted

            try:
                restricted = is_owner_restricted(path)
            except Exception as error:
                raise StateError(
                    f"Meshia could not verify the private Windows DACL for the device key "
                    f"at {path}. It refuses to use an unverified signing key; repair Windows "
                    "ACL support or permissions and retry."
                ) from error
            if not restricted:
                raise StateError(
                    f"The device key at {path} does not have a verified private Windows "
                    "DACL. Meshia refuses to use it; repair the file ACL or run "
                    "`meshia-node forget` and re-enroll."
                )
            return
        mode = os.stat(path).st_mode & 0o777
        if mode & 0o077:
            raise StateError(
                f"The device key at {path} is group/world accessible (mode {mode:04o}); "
                "run `meshia-node forget` and re-enroll."
            )

    @staticmethod
    def erase(identity_dir: Path) -> None:
        for name in ("device-key.pem", "installation-id"):
            target = identity_dir / name
            if target.exists():
                target.unlink()

    # ------------------------------------------------------------------- public

    def public_key_spki_pem(self) -> str:
        return self._key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("ascii")

    def public_key_spki_der(self) -> bytes:
        return self._key.public_key().public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def describe(self) -> IdentityDescription:
        digest_hex = sha256_hex(self.public_key_spki_der())
        digest = bytes.fromhex(digest_hex)
        return IdentityDescription(
            public_key_spki_pem=self.public_key_spki_pem(),
            public_key_sha256=f"sha256:{digest_hex}",
            key_id=digest_hex[:32],
            enrollment_idempotency_key=_deterministic_uuid(digest),
            installation_id=self.installation_id,
            protection=KEY_PROTECTION,
        )

    # ------------------------------------------------------------------ signing

    def sign(self, payload: bytes) -> bytes:
        """ECDSA-SHA256 over `payload`, returned as strict low-S DER."""
        return normalize_low_s(self._key.sign(payload, ec.ECDSA(hashes.SHA256())))

    def sign_b64url(self, payload: bytes) -> str:
        return b64url_unpadded(self.sign(payload))

    def enrollment_proof(self, host_id: str, challenge: str) -> str:
        payload = "\n".join((ENROLLMENT_PROOF_PREFIX, host_id, challenge)).encode("utf-8")
        return self.sign_b64url(payload)
