"""Mount-local Finder custom-icon phantoms for running-compute workspaces.

A workspace root whose compute is running renders with a green folder icon.
macOS asks for exactly two things to honour a custom folder icon:

* the folder's ``com.apple.FinderInfo`` carries ``kHasCustomIcon``; and
* the folder contains an invisible ``Icon\\r`` file whose resource fork holds
  an ``icns`` family.

Both are synthesized here and served entirely inside the FUSE adapter. They
are **phantoms**: no byte of them reaches a workspace backend, the sync
engine, the journal, or the provider, and they are withheld from ``readdir``
so directory scans (Finder copy, ``cp -R``, ``rsync``, ``du``) never see
them. Finder resolves ``Icon\\r`` by name, which is all this needs.

FUSE-T reaches macOS through SMB, where extended attributes may arrive either
natively or as AppleDouble ``._`` sidecars depending on what the client
negotiates. Both spellings are served so the icon does not depend on that
negotiation:

===========================  ==================================================
``/<ws>``                    ``com.apple.FinderInfo`` with ``kHasCustomIcon``
``/._<ws>``                  AppleDouble sidecar carrying the same FinderInfo
``/<ws>/Icon\\r``             empty data fork; FinderInfo with ``kIsInvisible``
                             and ``com.apple.ResourceFork`` with the icns
``/<ws>/._Icon\\r``           AppleDouble sidecar carrying both of those
===========================  ==================================================

Everything is immutable and precomputed once per process; per-workspace state
is a small set of labels plus a transition stamp used to bump the root's
timestamps so Finder repaints.
"""

from __future__ import annotations

import plistlib
import struct
import threading
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import Enum
from typing import Iterable

from .compute_icon_asset import GREEN_FOLDER_ICNS

__all__ = [
    "COMPUTE_ICON_FILE_NAME",
    "ComputeIconPhantom",
    "ComputeIconPhantomKind",
    "ComputeIconPhantoms",
    "FINDER_INFO_XATTR",
    "GREEN_TAG_LABEL",
    "RESOURCE_FORK_XATTR",
    "USER_TAGS_XATTR",
    "decode_tags",
    "encode_tags",
]

#: The classic custom-icon file name: ``Icon`` followed by a carriage return.
COMPUTE_ICON_FILE_NAME = "Icon\r"
_APPLEDOUBLE_PREFIX = "._"

FINDER_INFO_XATTR = "com.apple.FinderInfo"
RESOURCE_FORK_XATTR = "com.apple.ResourceFork"
#: Finder's user-tag xattr. On the FUSE-T SMB transport this is the only
#: colour mechanism that actually reaches Finder: the custom-icon path needs
#: named streams, which FUSE-T 1.2.7 disables (``nonamedattr``), whereas smbfs
#: stores and reads tags through an AppleDouble sidecar. Verified on the live
#: mount: writing this attribute produced a real ``._<name>`` sidecar and
#: ``xattr -l`` read the value straight back.
USER_TAGS_XATTR = "com.apple.metadata:_kMDItemUserTags"
#: Finder encodes a tag as "<name>\n<colour index>"; 2 is green.
GREEN_TAG_LABEL = "Green\n2"

# Finder flags live at offset 8 of FinderInfo for both files (FInfo.fdFlags)
# and folders (DInfo.frFlags).
_FINDER_FLAGS_OFFSET = 8
_K_IS_INVISIBLE = 0x4000
_K_HAS_CUSTOM_ICON = 0x0400
_FINDER_INFO_BYTES = 32

# ``icns`` resources live at this well-known id in a custom-icon resource fork.
_ICNS_RESOURCE_TYPE = b"icns"
_ICNS_RESOURCE_ID = -16455

_APPLEDOUBLE_ATTR_MAGIC = b"ATTR"
_APPLEDOUBLE_MAGIC = 0x00051607
_APPLEDOUBLE_VERSION_2 = 0x00020000
_APPLEDOUBLE_FINDER_INFO_ENTRY = 9
_APPLEDOUBLE_RESOURCE_FORK_ENTRY = 2


def _finder_info(flags: int) -> bytes:
    info = bytearray(_FINDER_INFO_BYTES)
    struct.pack_into(">H", info, _FINDER_FLAGS_OFFSET, flags)
    return bytes(info)


#: Folder FinderInfo advertising a custom icon.
_DIRECTORY_FINDER_INFO = _finder_info(_K_HAS_CUSTOM_ICON)
#: ``Icon\r`` FinderInfo: invisible, and itself custom-icon bearing.
_ICON_FILE_FINDER_INFO = _finder_info(_K_IS_INVISIBLE | _K_HAS_CUSTOM_ICON)


def encode_tags(labels: Sequence[str]) -> bytes:
    """Encode Finder tag labels as the binary plist the xattr carries."""

    return plistlib.dumps(list(labels), fmt=plistlib.FMT_BINARY)


def decode_tags(value: bytes) -> tuple[str, ...]:
    """Decode a tag xattr, tolerating anything that is not a string array."""

    try:
        decoded = plistlib.loads(value)
    except Exception:  # noqa: BLE001 - any malformed client value is "no tags"
        return ()
    if not isinstance(decoded, list):
        return ()
    return tuple(item for item in decoded if isinstance(item, str))


def _finder_info_entry(
    finder_info: bytes,
    attributes: Mapping[str, bytes],
    *,
    base: int,
) -> bytes:
    """Build the AppleDouble FinderInfo entry, optionally carrying xattrs.

    Exact mirror of the reader in
    ``fabric_mount._discardable_appledouble_finder_info``: 32 bytes of
    FinderInfo, zero padding to a 4-byte boundary, a 36-byte ``ATTR`` header,
    4-byte aligned ``offset/length/flags/namelen/name`` entries, then a
    contiguous value area. Every offset the header stores is absolute within
    the AppleDouble document, so ``base`` is the document offset at which this
    entry begins.
    """

    if len(finder_info) != _FINDER_INFO_BYTES:
        raise ValueError("FinderInfo must be exactly 32 bytes.")
    if not attributes:
        return finder_info

    finder_end = base + _FINDER_INFO_BYTES
    attributes_at = (finder_end + 3) & ~3
    names = sorted(attributes)

    cursor = attributes_at + 36
    for name in names:
        encoded = name.encode("utf-8") + b"\0"
        cursor = (cursor + 11 + len(encoded) + 3) & ~3
    data_start = cursor

    entries = b""
    values = b""
    value_at = data_start
    written = attributes_at + 36
    for name in names:
        value = attributes[name]
        encoded = name.encode("utf-8") + b"\0"
        entries += struct.pack(">IIHB", value_at, len(value), 0, len(encoded))
        entries += encoded
        written += 11 + len(encoded)
        padding = ((written + 3) & ~3) - written
        entries += bytes(padding)
        written += padding
        values += value
        value_at += len(value)

    entry_end = data_start + len(values)
    header = (
        _APPLEDOUBLE_ATTR_MAGIC
        + struct.pack(">IIII", 0, entry_end, data_start, len(values))
        + bytes(12)
        + struct.pack(">HH", 0, len(names))
    )
    return (
        finder_info
        + bytes(attributes_at - finder_end)
        + header
        + entries
        + values
    )


def _resource_fork(payload: bytes) -> bytes:
    """Wrap ``payload`` as a single ``icns`` resource in a resource fork.

    The layout is the classic Resource Manager one: a 256-byte header, the
    data area (each resource prefixed with a big-endian length), then a map
    holding one type entry and one reference entry with no names.
    """

    data = struct.pack(">I", len(payload)) + payload
    data_offset = 256
    map_offset = data_offset + len(data)

    type_list_offset = 28  # from the start of the map
    reference_list_offset = type_list_offset + 2 + 8  # count + one type entry
    name_list_offset = reference_list_offset + 12  # one reference entry
    resource_map = (
        bytes(16)  # reserved copy of the header
        + bytes(4)  # reserved next-map handle
        + bytes(2)  # reserved file reference
        + struct.pack(">H", 0)  # fork attributes
        + struct.pack(">HH", type_list_offset, name_list_offset)
        + struct.pack(">H", 0)  # one type, stored as count - 1
        + _ICNS_RESOURCE_TYPE
        + struct.pack(">HH", 0, reference_list_offset - type_list_offset)
        + struct.pack(">hH", _ICNS_RESOURCE_ID, 0xFFFF)  # id, no name
        + bytes([0])  # resource attributes
        + (0).to_bytes(3, "big")  # offset of this resource within the data area
        + bytes(4)  # reserved handle
    )
    header = struct.pack(
        ">IIII", data_offset, map_offset, len(data), len(resource_map)
    )
    return header + bytes(256 - len(header)) + data + resource_map


_ICON_RESOURCE_FORK = _resource_fork(GREEN_FOLDER_ICNS)


#: The resource fork macOS itself writes into a ``._`` sidecar that exists
#: only to carry extended attributes (XNU ``init_empty_resource_fork``): a
#: 286-byte Resource Manager header with no resources, tagged in its system
#: data so readers know it is ignorable.
_RF_EMPTY_TAG = b"This resource fork intentionally left blank   \0"
_RF_FIRST_RESOURCE = 256
_RF_NULL_MAP_LENGTH = 30
_EMPTY_RESOURCE_FORK = (
    struct.pack(">IIII", _RF_FIRST_RESOURCE, _RF_FIRST_RESOURCE, 0, _RF_NULL_MAP_LENGTH)
    + _RF_EMPTY_TAG.ljust(112, b"\0")  # systemData
    + bytes(128)  # appData
    + struct.pack(">IIII", _RF_FIRST_RESOURCE, _RF_FIRST_RESOURCE, 0, _RF_NULL_MAP_LENGTH)
    + struct.pack(">IHBB", 0, 0, 0, 0)  # mh_Next, mh_RefNum, mh_Attr, mh_InMemoryAttr
    + struct.pack(">HHH", _RF_NULL_MAP_LENGTH - 2, _RF_NULL_MAP_LENGTH, 0xFFFF)
)
assert len(_EMPTY_RESOURCE_FORK) == 286


def _appledouble(
    finder_info: bytes,
    resource_fork: bytes = b"",
    attributes: Mapping[str, bytes] | None = None,
) -> bytes:
    """Build an AppleDouble v2 document carrying FinderInfo (+ fork, + xattrs).

    smbfs stores extended attributes for a path in its ``._`` sidecar on this
    transport, so a synthesized sidecar is how a Finder tag reaches Finder.

    The document must have the exact shape the macOS AppleDouble reader
    (XNU ``vfs_xattr.c`` ``get_xattrinfo``) accepts before it will look for
    extended attributes at all: exactly two entries, FinderInfo first at file
    offset 50 and a resource fork second, with the ``ATTR`` header at offset
    84. A one-entry document with FinderInfo at offset 38 is a valid
    AppleDouble file whose xattrs macOS silently never reads, so a sidecar
    without a real fork carries the same empty fork macOS writes.
    """

    entry_count = 2
    header = struct.pack(">II", _APPLEDOUBLE_MAGIC, _APPLEDOUBLE_VERSION_2) + bytes(16)
    header += struct.pack(">H", entry_count)
    base = len(header) + 12 * entry_count
    assert base == 50, "FinderInfo must sit where the macOS reader expects it"
    finder_entry = _finder_info_entry(finder_info, attributes or {}, base=base)

    entries: list[tuple[int, bytes]] = [
        (_APPLEDOUBLE_FINDER_INFO_ENTRY, finder_entry),
        (_APPLEDOUBLE_RESOURCE_FORK_ENTRY, resource_fork or _EMPTY_RESOURCE_FORK),
    ]
    offset = base
    descriptors = b""
    payload = b""
    for entry_id, blob in entries:
        descriptors += struct.pack(">III", entry_id, offset, len(blob))
        payload += blob
        offset += len(blob)
    return header + descriptors + payload


GREEN_TAG_VALUE = encode_tags((GREEN_TAG_LABEL,))


def _root_sidecar(tags: bytes) -> bytes:
    return _appledouble(
        _DIRECTORY_FINDER_INFO, attributes={USER_TAGS_XATTR: tags}
    )


_DIRECTORY_SIDECAR = _root_sidecar(GREEN_TAG_VALUE)
_ICON_SIDECAR = _appledouble(_ICON_FILE_FINDER_INFO, _ICON_RESOURCE_FORK)


class ComputeIconPhantomKind(Enum):
    """Which synthesized entry a path resolves to."""

    #: ``/<ws>/Icon\r`` -- empty data fork, invisible, custom-icon bearing.
    ICON_FILE = "icon_file"
    #: ``/<ws>/._Icon\r`` -- AppleDouble sidecar for the icon file.
    ICON_SIDECAR = "icon_sidecar"
    #: ``/._<ws>`` -- AppleDouble sidecar for the workspace root directory.
    ROOT_SIDECAR = "root_sidecar"


@dataclass(frozen=True)
class ComputeIconPhantom:
    """One synthesized entry, resolved from a mount path."""

    kind: ComputeIconPhantomKind
    label: str
    contents: bytes
    finder_info: bytes

    @property
    def size(self) -> int:
        return len(self.contents)

    def xattrs(self) -> dict[str, bytes]:
        if self.kind is ComputeIconPhantomKind.ICON_FILE:
            return {
                FINDER_INFO_XATTR: self.finder_info,
                RESOURCE_FORK_XATTR: _ICON_RESOURCE_FORK,
            }
        return {}


class ComputeIconPhantoms:
    """Registry of workspace roots whose compute is running.

    Thread-safe and lock-light: reads take an immutable ``frozenset`` snapshot
    so FUSE callbacks never block on a transition.
    """

    def __init__(self, *, enabled: bool = True) -> None:
        self._enabled = bool(enabled)
        self._lock = threading.Lock()
        self._running: frozenset[str] = frozenset()
        self._stamps: dict[str, int] = {}
        # Tags the user set on a workspace root while we were synthesizing.
        # Green is additive: the user's own tags are merged with it while
        # compute runs and are exactly what remains once it stops, so turning
        # compute on and off never destroys a tag the user chose.
        self._user_tags: dict[str, tuple[str, ...]] = {}

    @property
    def enabled(self) -> bool:
        return self._enabled

    def running_labels(self) -> frozenset[str]:
        return self._running

    def is_running(self, label: str) -> bool:
        return self._enabled and label in self._running

    def set_running(self, labels: Iterable[str]) -> tuple[str, ...]:
        """Replace the running set; return the labels whose state changed.

        Each changed label gets a fresh timestamp stamp so its root directory
        reports new ``mtime``/``ctime`` values -- Finder repaints a directory
        whose attributes moved, and ignores one whose have not.
        """

        if not self._enabled:
            return ()
        requested = frozenset(str(label) for label in labels if str(label))
        with self._lock:
            previous = self._running
            if requested == previous:
                return ()
            changed = tuple(sorted(requested ^ previous))
            stamp = time.time_ns()
            for label in changed:
                self._stamps[label] = stamp
            # Forget stamps for labels that vanished from the catalog entirely
            # so the map cannot grow without bound across account cutovers.
            for label in tuple(self._stamps):
                if label not in requested and label not in previous:
                    self._stamps.pop(label, None)
            self._running = requested
            return changed

    def root_tags(self, label: str) -> tuple[str, ...]:
        """Tags to report for a workspace root: user tags plus green if running."""

        user = self._user_tags.get(label, ())
        if not self.is_running(label):
            return user
        if GREEN_TAG_LABEL in user:
            return user
        return (*user, GREEN_TAG_LABEL)

    def set_user_tags(self, label: str, tags: Iterable[str]) -> None:
        """Record the user's own tags, never storing our synthesized green."""

        kept = tuple(tag for tag in tags if tag != GREEN_TAG_LABEL)
        with self._lock:
            if kept:
                self._user_tags[label] = kept
            else:
                self._user_tags.pop(label, None)

    def root_tags_value(self, label: str) -> bytes:
        return encode_tags(self.root_tags(label))

    def root_timestamp_ns(self, label: str, default: int) -> int:
        """Return the timestamp a workspace root should report."""

        if not self._enabled:
            return default
        stamp = self._stamps.get(label)
        if stamp is None:
            return default
        return max(stamp, default)

    # -- path resolution ----------------------------------------------------

    @staticmethod
    def _split(path: str) -> tuple[str, ...]:
        return tuple(part for part in path.split("/") if part)

    def phantom_paths(self, label: str) -> tuple[str, ...]:
        """Every synthesized path belonging to one workspace root."""

        return (
            f"/{label}",
            f"/{_APPLEDOUBLE_PREFIX}{label}",
            f"/{label}/{COMPUTE_ICON_FILE_NAME}",
            f"/{label}/{_APPLEDOUBLE_PREFIX}{COMPUTE_ICON_FILE_NAME}",
        )

    def classify(self, path: str) -> ComputeIconPhantom | None:
        """Resolve ``path`` to a phantom, or ``None`` for a real path.

        Only paths under a *running* workspace root resolve; everything else
        -- including the same names under a stopped workspace -- is left to
        the real backend so a user's own ``Icon\\r`` file still works.
        """

        if not self._enabled:
            return None
        running = self._running
        if not running:
            return None
        parts = self._split(path)
        if len(parts) == 1:
            name = parts[0]
            if name.startswith(_APPLEDOUBLE_PREFIX):
                label = name[len(_APPLEDOUBLE_PREFIX) :]
                if label in running:
                    return ComputeIconPhantom(
                        kind=ComputeIconPhantomKind.ROOT_SIDECAR,
                        label=label,
                        contents=_root_sidecar(self.root_tags_value(label)),
                        finder_info=_DIRECTORY_FINDER_INFO,
                    )
            return None
        if len(parts) != 2:
            return None
        label, name = parts
        if label not in running:
            return None
        if name == COMPUTE_ICON_FILE_NAME:
            return ComputeIconPhantom(
                kind=ComputeIconPhantomKind.ICON_FILE,
                label=label,
                contents=b"",
                finder_info=_ICON_FILE_FINDER_INFO,
            )
        if name == f"{_APPLEDOUBLE_PREFIX}{COMPUTE_ICON_FILE_NAME}":
            return ComputeIconPhantom(
                kind=ComputeIconPhantomKind.ICON_SIDECAR,
                label=label,
                contents=_ICON_SIDECAR,
                finder_info=_ICON_FILE_FINDER_INFO,
            )
        return None

    def directory_finder_info(self, path: str) -> bytes | None:
        """FinderInfo for a *running* workspace root directory, else ``None``."""

        if not self._enabled:
            return None
        parts = self._split(path)
        if len(parts) != 1 or parts[0] not in self._running:
            return None
        return _DIRECTORY_FINDER_INFO

    def root_label(self, path: str) -> str | None:
        """The workspace label when ``path`` is a top-level root, else None."""

        if not self._enabled:
            return None
        parts = self._split(path)
        if len(parts) != 1:
            return None
        return parts[0]

    def directory_xattrs(self, path: str) -> dict[str, bytes] | None:
        """Synthesized xattrs for a *running* workspace root directory.

        The green Finder tag is what actually colours the folder on the SMB
        transport; FinderInfo rides along for the custom-icon path used by
        transports that support named streams.
        """

        if self.directory_finder_info(path) is None:
            return None
        label = self._split(path)[0]
        return {
            FINDER_INFO_XATTR: _DIRECTORY_FINDER_INFO,
            USER_TAGS_XATTR: self.root_tags_value(label),
        }

    def hidden_names(self, path: str) -> frozenset[str]:
        """Names to withhold from ``readdir`` for ``path``.

        Phantoms resolve by name only. Keeping them out of directory listings
        is what guarantees a folder copy, ``rsync``, or any sync-driving scan
        can never observe -- let alone upload -- them.
        """

        if not self._enabled or not self._running:
            return frozenset()
        parts = self._split(path)
        if not parts:
            return frozenset(
                f"{_APPLEDOUBLE_PREFIX}{label}" for label in self._running
            )
        if len(parts) == 1 and parts[0] in self._running:
            return frozenset(
                {
                    COMPUTE_ICON_FILE_NAME,
                    f"{_APPLEDOUBLE_PREFIX}{COMPUTE_ICON_FILE_NAME}",
                }
            )
        return frozenset()
