"""Sealed delivery of workspace environment variables to this node process.

Wire shape
----------
The node asks for a named set over an ordinary **signed** request (so the
control plane knows which host is asking, at which generation, under which
attachment), and includes a freshly generated X25519 public key::

    POST api/connected-hosts/<host_id>/task-environment
    {"attachment_id": ..., "names": [...],
     "recipient_algorithm": "x25519",
     "recipient_public_key": "<base64url, unpadded>"}

The control plane applies its own policy first — key allowlisting *and* the
value-level control-plane-secret comparison in ``customer-runtime-env-policy.ts``
— then seals whatever survives::

    {"schema": "meshia.connected_host.task_environment.v1",
     "sender_public_key": "<base64url, unpadded>",
     "sealed_base64": "<base64 of nonce||tag||ciphertext>",
     "names": [...]}

Construction
------------
``AES-256-GCM`` with a 12-byte nonce and the ``nonce || tag || ciphertext``
layout, matching ``encryptValue`` in ``web/lib/env-vars.ts`` so the codebase has
one envelope shape rather than two. The *key* is where this differs from the
at-rest helper: it is derived per request, never stored, and never the
control-plane master key::

    shared  = X25519(ephemeral_private, peer_public)
    salt    = SHA-256(recipient_public || sender_public)
    key     = HKDF-SHA256(shared, salt, info=CONTEXT, length=32)
    CONTEXT = "meshia-node-task-env-v1\\n<host_id>\\n<generation>\\n"
              "<attachment_id>\\n<recipient_public_key>"

``CONTEXT`` is also the GCM associated data, so it is authenticated rather than
merely mixed in. Both sides derive it from values they already agree on: the
node from its own config and the key pair it just generated, the server from the
verified signed-request headers and body.

What the seal is and is not for
-------------------------------
It is **not** a defence against the person who owns the host. They have root,
the ephemeral private key is in this process's memory, and the plaintext is in a
child process's environment a moment later. Nothing here changes that, and the
design does not pretend otherwise.

What it does buy, concretely:

* **End-to-end confidentiality past an intermediary.** The node explicitly
  supports deployment behind a TLS-terminating reverse proxy — that is what
  ``MESHIA_SIGNING_ORIGIN`` in :mod:`meshia_node.client` exists for. Anything
  that terminates TLS, or merely logs response bodies, sees ciphertext.
* **A single-use, non-transferable envelope.** Ephemeral keys on both sides mean
  a recorded response cannot be replayed, and the AAD binding means an envelope
  captured for one host cannot be opened by another, nor by the same host after
  a generation bump or on a different attachment. That is the "scoped and
  useless off-platform" property, applied to the delivery itself.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .errors import NetworkError
from .task_env import EnvironmentRefused, vet_workspace_environment
from .util import b64url_unpadded, decode_canonical_b64

BASE64URL_RE = re.compile(r"^[A-Za-z0-9_-]+$")
SEAL_CONTEXT_PREFIX = "meshia-node-task-env-v1"
TASK_ENVIRONMENT_SCHEMA = "meshia.connected_host.task_environment.v1"
RECIPIENT_ALGORITHM = "x25519"
NONCE_BYTES = 12
TAG_BYTES = 16
X25519_KEY_BYTES = 32
# A sealed set is bounded well below the vetted total so a hostile or broken
# control plane cannot make the node allocate without limit before vetting.
MAX_SEALED_BYTES = 512 * 1024


def seal_context(
    *, host_id: str, generation: int, attachment_id: str, recipient_public_key_b64url: str
) -> bytes:
    """The HKDF info string and GCM associated data. Both sides derive this.

    The recipient's ephemeral public key is the freshness term: it is random per
    delivery and it arrives inside the *signed* request body, so the server binds
    the envelope to a key only this host could have asked with. Binding the
    signed-request sequence instead would be circular — the node cannot learn
    which sequence :class:`~meshia_node.client.SignedClient` allocated, and
    letting the server echo one back would bind the envelope to whatever the
    server chose rather than to something the node committed to.
    """
    return "\n".join(
        (
            SEAL_CONTEXT_PREFIX,
            host_id,
            str(generation),
            attachment_id,
            recipient_public_key_b64url,
        )
    ).encode("utf-8")


def derive_key(shared_secret: bytes, recipient_public: bytes, sender_public: bytes, context: bytes) -> bytes:
    """HKDF-SHA256 over the X25519 shared secret, salted with both public keys."""
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=hashlib.sha256(recipient_public + sender_public).digest(),
        info=context,
    ).derive(shared_secret)


@dataclass(frozen=True)
class SealedEnvelope:
    sender_public_key: bytes
    sealed: bytes


class EnvelopeRecipient:
    """One ephemeral X25519 key pair, used for exactly one delivery.

    The private key stays in this object and this object is discarded after a
    single :meth:`open`; nothing about it is persisted, so a delivery cannot be
    re-opened later even from this same machine.
    """

    def __init__(self, private_key: X25519PrivateKey | None = None) -> None:
        self._private = private_key or X25519PrivateKey.generate()

    @property
    def public_key_bytes(self) -> bytes:
        from cryptography.hazmat.primitives import serialization

        return self._private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    def public_key_b64url(self) -> str:
        return b64url_unpadded(self.public_key_bytes)

    def request_body(self, attachment_id: str, names: list[str]) -> dict[str, Any]:
        return {
            "attachment_id": attachment_id,
            "names": list(names),
            "recipient_algorithm": RECIPIENT_ALGORITHM,
            "recipient_public_key": self.public_key_b64url(),
        }

    def open(self, envelope: SealedEnvelope, context: bytes) -> dict[str, str]:
        """Unseal and vet. Returns the variables; raises on anything suspect."""
        if len(envelope.sender_public_key) != X25519_KEY_BYTES:
            raise NetworkError("The task-environment envelope carried a malformed sender key.")
        if len(envelope.sealed) < NONCE_BYTES + TAG_BYTES:
            raise NetworkError("The task-environment envelope is too short to be a sealed payload.")
        if len(envelope.sealed) > MAX_SEALED_BYTES:
            raise NetworkError("The task-environment envelope exceeds the accepted size.")
        try:
            peer = X25519PublicKey.from_public_bytes(envelope.sender_public_key)
            shared = self._private.exchange(peer)
        except Exception as error:  # pragma: no cover - defensive
            raise NetworkError("The task-environment key agreement failed.") from error
        key = derive_key(shared, self.public_key_bytes, envelope.sender_public_key, context)
        nonce = envelope.sealed[:NONCE_BYTES]
        tag = envelope.sealed[NONCE_BYTES : NONCE_BYTES + TAG_BYTES]
        ciphertext = envelope.sealed[NONCE_BYTES + TAG_BYTES :]
        try:
            # `cryptography` wants tag-trailing; the wire layout is tag-leading to
            # match encryptValue, so re-join in the order AESGCM expects.
            plaintext = AESGCM(key).decrypt(nonce, ciphertext + tag, context)
        except InvalidTag as error:
            # Wrong host, wrong generation, wrong attachment, a replayed
            # envelope, or a tampered one — all of them land here, and all of
            # them mean "do not inject anything".
            raise NetworkError(
                "The task-environment envelope did not authenticate for this host."
            ) from error
        try:
            document = json.loads(plaintext.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as error:
            raise NetworkError("The task-environment envelope held malformed JSON.") from error
        return vet_workspace_environment(document)


def parse_envelope(document: Any) -> SealedEnvelope:
    """Structurally validate a control-plane response before any crypto runs."""
    if not isinstance(document, dict):
        raise NetworkError("The task-environment response is not a JSON object.")
    if document.get("schema") != TASK_ENVIRONMENT_SCHEMA:
        raise NetworkError("The task-environment response carried an unknown schema.")
    sender = document.get("sender_public_key")
    sealed = document.get("sealed_base64")
    if not isinstance(sender, str) or not isinstance(sealed, str):
        raise NetworkError("The task-environment response is missing its sealed fields.")
    # `base64.urlsafe_b64decode` silently discards characters outside the
    # alphabet, so "!!!" would decode to b"" rather than raise. Check the
    # charset explicitly — the same rule the control plane applies to every
    # base64url header field.
    if not BASE64URL_RE.match(sender):
        raise NetworkError("The task-environment sender key is not base64url.")
    padding = "=" * (-len(sender) % 4)
    try:
        sender_bytes = base64.urlsafe_b64decode(sender + padding)
    except Exception as error:
        raise NetworkError("The task-environment sender key is not base64url.") from error
    # Bound the *encoded* length first: checking after decoding would mean the
    # allocation this limit exists to prevent has already happened.
    if len(sealed) > (MAX_SEALED_BYTES * 4) // 3 + 4:
        raise NetworkError("The task-environment envelope exceeds the accepted size.")
    sealed_bytes = decode_canonical_b64(sealed)
    if sealed_bytes is None:
        raise NetworkError("The task-environment payload is not canonical base64.")
    if len(sealed_bytes) > MAX_SEALED_BYTES:
        raise NetworkError("The task-environment envelope exceeds the accepted size.")
    return SealedEnvelope(sender_public_key=sender_bytes, sealed=sealed_bytes)


class TaskEnvironmentFetcher:
    """Fetches and unseals a named variable set for one command.

    This is the object :mod:`meshia_node.cli` hands the executor as a plain
    callable, which is why the executor still holds no credentials of its own:
    it can ask for names, and it gets values back, but it has no way to reach
    the signing key or the control plane on its own.

    Nothing is cached. A second command asking for the same names does a second
    delivery with a second key pair, so a value is never retained past the
    command that needed it.
    """

    def __init__(self, client: Any, store: Any, logger: Any = None,
                 *, command_authority: tuple[str, int, str] | None = None) -> None:
        self.client = client
        self.store = store
        self.logger = logger
        self.command_authority = command_authority

    def __call__(self, names: list[str]) -> dict[str, str]:
        return self.fetch(names)

    def fetch(self, names: list[str]) -> dict[str, str]:
        if not names:
            return {}
        config = self.store.require()
        attachment_id = config.attachment_id or ""
        if self.command_authority is not None:
            host_id, generation, attachment_id = self.command_authority
            if config.host_id != host_id or config.generation != generation:
                raise NetworkError("The command's device authority changed.")
        if not attachment_id:
            raise NetworkError(
                "Workspace environment requires an active attachment; this host has none."
            )
        recipient = EnvelopeRecipient()
        document = self.client.post_json(
            f"api/connected-hosts/{config.host_id}/task-environment",
            recipient.request_body(attachment_id, names),
        )
        envelope = parse_envelope(document)
        context = seal_context(
            host_id=config.host_id,
            generation=config.generation,
            attachment_id=attachment_id,
            recipient_public_key_b64url=recipient.public_key_b64url(),
        )
        delivered = recipient.open(envelope, context)
        check_delivered_subset(delivered, names)
        if self.logger is not None:
            # Names only. A value has never been written to the log, and the
            # redacting logger would not save us if one were.
            from .task_env import redacted_summary

            self.logger.record(
                "task_environment_delivered",
                requested=len(names),
                delivered=redacted_summary(delivered),
            )
        return delivered


def check_delivered_subset(delivered: dict[str, str], requested: list[str]) -> None:
    """Refuse anything the command did not ask for.

    Fewer than requested is normal — the server drops variables its own policy
    rejects, and a workspace need not define every name a task asks for. *More*
    than requested is not: it would mean a task received workspace secrets it
    never declared, which is the blanket delivery this design exists to avoid.
    """
    extra = sorted(set(delivered) - set(requested))
    if extra:
        raise EnvironmentRefused(
            "Workspace environment refused: the control plane delivered "
            f"{len(extra)} variable(s) this command did not request ({', '.join(extra[:5])})."
        )
