"""Error taxonomy shared by every module.

Mirrors ``MeshiaNodeError`` in the Swift node so the retry/disconnect decisions
made by the runner match the proven macOS behaviour.
"""

from __future__ import annotations

import errno
from typing import Any, Mapping


class MeshiaNodeError(Exception):
    """Base class for every locally raised node failure."""

    code = "MESHIA_NODE_ERROR"


class InvalidArgument(MeshiaNodeError):
    code = "INVALID_ARGUMENT"


class InvalidTask(MeshiaNodeError):
    code = "INVALID_TASK"


class UnsafePath(MeshiaNodeError):
    """A path escaped, or tried to escape, its containment root."""

    code = "UNSAFE_PATH"


class RetentionCapacityUnavailable(BlockingIOError):
    """A bounded retained-inode slot is temporarily unavailable.

    This is an explicit retry signal, not evidence that the namespace raced or
    that local bytes should be republished.  It remains a ``BlockingIOError``
    so low-level callers keep the conventional ``EAGAIN`` contract.
    """

    def __init__(self) -> None:
        super().__init__(
            errno.EAGAIN,
            "The retained remote-cleanup owner bound is busy.",
        )


class TierRefused(MeshiaNodeError):
    """A `personal`-tier node refused a compute-only operation locally."""

    code = "LOCAL_TIER_REFUSED"


class AccessRefused(MeshiaNodeError):
    """A `limited`-access node refused a host-scope write or an unconfinable exec.

    Distinct from :class:`TierRefused` because the owner can clear it by moving
    the machine to `full` access, whereas a tier refusal needs a re-enrollment.
    """

    code = "LOCAL_ACCESS_REFUSED"


class StateError(MeshiaNodeError):
    code = "STATE_ERROR"


class WorkspaceAdoptionRequired(StateError):
    """A non-empty local root needs an explicit ownership decision."""

    code = "WORKSPACE_ADOPTION_REQUIRED"


class WorkspaceClaimInvalid(StateError):
    """The private root marker is missing, unsafe, corrupt, or mismatched."""

    code = "WORKSPACE_CLAIM_INVALID"


class NetworkError(MeshiaNodeError):
    code = "NETWORK_UNAVAILABLE"


class Disconnected(MeshiaNodeError):
    """The control plane revoked this host, generation, or attachment."""

    code = "DISCONNECTED"

    def __init__(
        self,
        message: str = "This host is disconnected.",
        *,
        reason_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.reason_code = reason_code


class RemoteError(MeshiaNodeError):
    """A non-2xx control-plane response that is not a revocation."""

    code = "REMOTE_ERROR"

    def __init__(
        self,
        status: int,
        code: str | None,
        message: str,
        *,
        details: Mapping[str, Any] | None = None,
        retry_after_seconds: float | None = None,
    ) -> None:
        super().__init__(message)
        if retry_after_seconds is not None and (
            isinstance(retry_after_seconds, bool)
            or not isinstance(retry_after_seconds, (int, float))
            or not 0 <= retry_after_seconds <= 86_400
        ):
            raise ValueError("retry_after_seconds must be between 0 and 86400.")
        self.status = status
        self.remote_code = code
        self.details = dict(details) if details is not None else None
        self.retry_after_seconds = (
            float(retry_after_seconds) if retry_after_seconds is not None else None
        )

    @property
    def retryable(self) -> bool:
        return self.status in (408, 409, 429) or self.status >= 500
