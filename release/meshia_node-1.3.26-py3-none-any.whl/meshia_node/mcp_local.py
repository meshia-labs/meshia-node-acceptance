"""One JSON-RPC exchange with a **local stdio** MCP server on this host.

Why this exists at all, and why it is this small
------------------------------------------------

The control plane's MCP support (``pod/daemon/mesh/mcp_manager.py``) is entirely
*remote HTTP* MCP: it discovers tools with a ``tools/list`` POST over HTTPS,
dispatches with ``tools/call``, and reads bearer tokens out of the pod process
environment by name (``MESHIA_MCP_<ID>_TOKEN``). Two consequences follow, and
they decide the whole shape of this module.

**Remote MCP needs nothing here.** A remote server is reachable from our
backend, the manager already runs there, and the agent already sees those tools
whether or not a node is attached to the session. Re-implementing that on a
customer-owned host would move a live credential onto a machine whose owner is
assumed hostile, in exchange for no capability at all. So the remote case is
refused here, explicitly, rather than left merely unimplemented — see
:func:`build_request`.

**Local stdio MCP needs something, and nothing existed.** A server that has to
run *on the host* — one that reads local files, reaches a network only that
machine can reach, or drives local hardware — cannot be run from the backend by
definition. That is the one case with a real reason to execute node-side, and
it is what this module does.

Stateless by construction
-------------------------

An MCP conversation is ``initialize`` → ``notifications/initialized`` → a
request. This module writes all three frames, closes stdin, and reads the
answer, so one command is one complete conversation and the server process is
gone before the command completes. There is no session table, no long-lived
child, no lease to resurrect after a node restart, and no orphan to reap — the
existing :func:`~meshia_node.executor.run_bounded_subprocess` guarantees
(timeout, process-group kill, output caps, Landlock confinement in `limited`
access) apply unchanged because this *is* that function.

The cost is real and worth stating: a server that keeps state between calls (an
open transaction, a cursor) will not work through this path. That is a
deliberate trade — persistent host-side process state is the part most likely to
become a hole, and no known connector needs it.

Credentials
-----------

There is no credential channel here. A local server that needs authentication
must receive it through the ordinary workspace-environment path
(``payload["env"]``, see :mod:`meshia_node.task_env`), which means the workspace
owner named that variable deliberately and understands it is being handed to a
machine they have decided to trust.

The refusals cover both halves of the definition, because covering only one
covered nothing: rejecting ``url``/``auth``-style *keys* is useless while
``argv`` can express the same thing — ``["npx", "mcp-remote", "https://…",
"--header", "Authorization: …"]`` is a remote server and a credential at once.
So argv is checked too.

What that is *not* is a proof. A secret can be a bare token with no recognisable
shape, and argv is visible to any local user through the process table anyway,
which is the standing reason not to put secrets there. The enforced property is
narrower and worth stating exactly: **the node has no channel that carries an
MCP credential to it**, and the obvious ways to hand it one anyway are refused.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from .errors import InvalidTask
from .util import bounded_int, clean

PROTOCOL_VERSION = "2024-11-05"
CLIENT_NAME = "meshia-node"
DEFAULT_TIMEOUT_SECONDS = 60
MAX_TIMEOUT_SECONDS = 300
DEFAULT_MAX_OUTPUT_BYTES = 262_144
MAX_OUTPUT_BYTES_CAP = 1_048_576
MAX_ARGV_ITEMS = 64
MAX_ARGV_ITEM_BYTES = 4096
MAX_PARAMS_BYTES = 262_144
INITIALIZE_ID = 1
CALL_ID = 2

# Methods worth reaching from a hostile-host relay. `tools/list` and
# `tools/call` are the whole point; `prompts/*` and `resources/*` are omitted
# because nothing consumes them yet and an unused method is an unused attack
# surface. Widen this list when something actually needs it.
ALLOWED_METHODS = ("tools/list", "tools/call")

# A local stdio server is fully described by these two fields. The definition is
# closed rather than open: an unrecognised key is refused instead of ignored, so
# a credential nested under some future-looking name (``options``, ``config``)
# cannot ride along as inert payload waiting for a later reader to honour it.
ALLOWED_SERVER_KEYS = ("argv", "cwd")

# Any of these in a server definition means the caller is trying to hand the
# node either a remote endpoint or a credential. Both are refusals, not
# warnings, and both are checked before the closed-schema check purely so the
# error says *why*. Matched case-insensitively against the definition's keys.
REMOTE_TRANSPORT_KEYS = ("url", "endpoint", "uri", "host", "transport", "sse", "http")
CREDENTIAL_KEYS = (
    "auth",
    "authorization",
    "token",
    "auth_token",
    "access_token",
    "bearer",
    "credential",
    "credentials",
    "api_key",
    "apikey",
    "secret",
    "password",
    "headers",
    "auth_token_env",
)


def _looks_like_a_credential(item: str) -> bool:
    """Shapes that are unambiguously an inline secret rather than an argument."""
    lowered = item.lower()
    return (
        "authorization:" in lowered
        or "proxy-authorization:" in lowered
        or lowered.startswith("bearer ")
        or "bearer " in lowered
        and ":" in lowered  # a header value pasted whole
    )


@dataclass(frozen=True)
class McpRequest:
    argv: list[str]
    cwd: str
    method: str
    params: dict[str, Any]
    timeout_seconds: int
    max_output_bytes: int

    def stdin_frames(self) -> bytes:
        """The full conversation, newline-delimited, written in one go.

        Buffering the whole exchange up front is what makes this a one-shot: the
        server reads three frames, answers, sees EOF and exits.
        """
        frames = [
            {
                "jsonrpc": "2.0",
                "id": INITIALIZE_ID,
                "method": "initialize",
                "params": {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": {"name": CLIENT_NAME, "version": "1"},
                },
            },
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            {"jsonrpc": "2.0", "id": CALL_ID, "method": self.method, "params": self.params},
        ]
        return b"".join(
            json.dumps(frame, separators=(",", ":")).encode("utf-8") + b"\n" for frame in frames
        )


def build_request(payload: dict[str, Any]) -> McpRequest:
    """Validate an ``mcp_call`` payload into a launchable local request."""
    server = payload.get("server")
    if not isinstance(server, dict):
        raise InvalidTask("mcp_call.server must be a JSON object describing a local stdio server.")

    # Refuse the remote and credentialed shapes by name, before anything else,
    # so the failure message says *why* rather than "argv missing".
    present = {str(key).lower() for key in server}
    remote = sorted(present & set(REMOTE_TRANSPORT_KEYS))
    if remote:
        raise InvalidTask(
            f"mcp_call refuses remote MCP servers on a connected host (saw {', '.join(remote)}). "
            "Remote and authenticated MCP servers are managed by the control plane, which is "
            "where their credentials stay."
        )
    credentialed = sorted(present & set(CREDENTIAL_KEYS))
    if credentialed:
        raise InvalidTask(
            f"mcp_call refuses a server definition carrying credentials (saw "
            f"{', '.join(credentialed)}). A local server that needs a secret must receive it "
            "through the workspace environment, which the workspace owner controls explicitly."
        )

    unknown = sorted(present - set(ALLOWED_SERVER_KEYS))
    if unknown:
        raise InvalidTask(
            f"mcp_call.server accepts only {', '.join(ALLOWED_SERVER_KEYS)}; "
            f"refused unknown field(s) {', '.join(unknown)}."
        )

    argv = server.get("argv")
    if not isinstance(argv, list) or not argv or len(argv) > MAX_ARGV_ITEMS:
        raise InvalidTask("mcp_call.server.argv must be a non-empty list of at most 64 strings.")
    for item in argv:
        if not isinstance(item, str) or "\0" in item or len(item.encode("utf-8")) > MAX_ARGV_ITEM_BYTES:
            raise InvalidTask("mcp_call.server.argv entries must be NUL-free strings under 4 KiB.")

    # Without this the field checks above guard nothing: `argv` alone expresses
    # both refused shapes at once, e.g.
    #   ["npx", "mcp-remote", "https://x/mcp", "--header", "Authorization: ..."]
    # which is a remote server *and* a credential, smuggled past a key denylist
    # that only ever inspected key names. Rejecting an HTTP(S) URL in argv is
    # what makes "local only" true rather than merely stated.
    #
    # It is still not a proof. A secret can be a bare token with no recognisable
    # shape, and argv is visible to any local user through the process table
    # anyway — which is the standing reason not to pass secrets there. The
    # supported way to give a local server a secret is the workspace
    # environment, and that is enforced; this check just closes the obvious door.
    for item in argv:
        lowered = item.lower()
        if "http://" in lowered or "https://" in lowered:
            raise InvalidTask(
                "mcp_call.server.argv must not contain an HTTP(S) URL: that describes a remote "
                "MCP server, which the control plane manages so its credentials never reach a host."
            )
        if _looks_like_a_credential(item):
            raise InvalidTask(
                "mcp_call.server.argv must not carry an authorization header or bearer token. "
                "A local server that needs a secret receives it through the workspace environment."
            )

    raw_cwd = server.get("cwd")
    if raw_cwd is not None and not isinstance(raw_cwd, str):
        raise InvalidTask("mcp_call.server.cwd must be a string when present.")
    cwd = "." if raw_cwd in (None, "") else str(raw_cwd)

    method = payload.get("method", "tools/list")
    if method not in ALLOWED_METHODS:
        raise InvalidTask(
            f"mcp_call.method must be one of {', '.join(ALLOWED_METHODS)}; "
            f"got {clean(str(method), 48)!r}."
        )
    params = payload.get("params")
    if params is None:
        params = {}
    if not isinstance(params, dict):
        raise InvalidTask("mcp_call.params must be a JSON object when present.")
    try:
        encoded = json.dumps(params).encode("utf-8")
    except (TypeError, ValueError) as error:
        raise InvalidTask("mcp_call.params must be JSON-serialisable.") from error
    if len(encoded) > MAX_PARAMS_BYTES:
        raise InvalidTask(f"mcp_call.params must be at most {MAX_PARAMS_BYTES} bytes.")

    return McpRequest(
        argv=list(argv),
        cwd=cwd,
        method=method,
        params=params,
        timeout_seconds=bounded_int(
            payload.get("timeout_seconds"), 1, MAX_TIMEOUT_SECONDS, DEFAULT_TIMEOUT_SECONDS
        ),
        max_output_bytes=bounded_int(
            payload.get("max_output_bytes"), 1, MAX_OUTPUT_BYTES_CAP, DEFAULT_MAX_OUTPUT_BYTES
        ),
    )


def interpret_response(
    output: bytes, *, exit_code: int, truncated: bool, method: str
) -> Any:
    """Pick the answer frame out of the server's stdout.

    Servers interleave their own logging with protocol frames, and some write
    banners before the first response, so every line is tried and non-JSON ones
    are skipped rather than treated as a protocol violation.
    """
    from .executor import CommandOutcome

    answer: dict[str, Any] | None = None
    for line in output.splitlines():
        line = line.strip()
        if not line.startswith(b"{"):
            continue
        try:
            frame = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            continue
        if isinstance(frame, dict) and frame.get("id") == CALL_ID:
            answer = frame
            break

    if answer is None:
        return CommandOutcome(
            status="failed",
            output=output,
            exit_code=exit_code,
            truncated=truncated,
            message=(
                "The MCP server produced no response frame for this request."
                if not truncated
                else "The MCP server's response was truncated before a response frame appeared."
            ),
            extra={"mcp_method": method},
        )

    if "error" in answer:
        error = answer.get("error")
        message = error.get("message") if isinstance(error, dict) else None
        return CommandOutcome(
            status="failed",
            output=json.dumps(answer).encode("utf-8"),
            exit_code=exit_code,
            truncated=truncated,
            message=f"The MCP server returned an error: {clean(str(message or error))}",
            extra={"mcp_method": method, "mcp_error": True},
        )

    return CommandOutcome(
        status="succeeded",
        output=json.dumps(answer.get("result")).encode("utf-8"),
        exit_code=exit_code,
        truncated=truncated,
        extra={"mcp_method": method, "mcp_error": False},
    )
