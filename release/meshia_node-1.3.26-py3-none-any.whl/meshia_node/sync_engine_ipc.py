"""Duplex IPC between the FUSE mount process and the sync engine process.

Why this exists: any GIL-releasing call on a FUSE callback path pays the
contention tax of whatever else shares the interpreter. Measured on the real
``FabricMountBackend.getattr`` path, one lookup costs 66 us alone, 17,557 us
beside four interpreter-bound threads, and 67 us beside the same work in
separate processes. Moving the sync engine out of the mount's interpreter is
worth ~265x on the hot path.

Design notes that matter for correctness:

* **Duplex, not client/server.** Traffic is mostly mount->engine (staging,
  wake, warm), but ``set_mount_cleanup_fence`` runs the other way: the engine
  asks the mount whether an open description still references a path. One
  socket carries both directions, with request ids to pair replies.
* **Every call is bounded.** A FUSE callback must never block indefinitely on
  a peer, so requests carry a timeout and a saturated queue fails fast rather
  than queueing without limit.
* **Absence is a safe answer, not an error.** The cleanup fence already
  documents that a missing provider is "unknown evidence, not proof", so a
  dead or unreachable peer degrades to *do not reclaim*. Staging calls, by
  contrast, must fail loudly: silently dropping a write would lose data.
"""

from __future__ import annotations

import hashlib
import json
import os
import socket
import struct
import tempfile
import threading
import uuid
from collections.abc import Callable, Mapping
from concurrent.futures import ThreadPoolExecutor
from typing import Any

_LENGTH = struct.Struct("!I")
# A control frame is small; anything larger indicates a framing bug or a
# hostile peer, and reading it would be an unbounded allocation.
MAX_FRAME_BYTES = 4 * 1024 * 1024
DEFAULT_TIMEOUT_SECONDS = 30.0
# Bound on requests awaiting a reply. Reached only if the peer has stopped
# draining, in which case failing fast beats growing without limit.
MAX_PENDING_REQUESTS = 512
# Inbound handlers run off the reader thread. A handler may itself call back
# into the peer (the engine runs the mount's ``publish_local_namespace`` closure
# while it holds the coordinator's namespace stripe), and that reply can only
# be delivered by a reader that is not blocked inside the handler. The pool is
# bounded so a folder drop cannot spawn a thread per staged file.
MAX_HANDLER_THREADS = 32


class IpcError(RuntimeError):
    """The peer could not be reached, answered an error, or timed out."""


class IpcUnavailable(IpcError):
    """The peer is not connected. Callers decide whether that is fatal."""


class IpcRemoteError(IpcError):
    """The peer's handler raised.

    ``errno`` and ``error_type`` carry enough of the original exception for the
    caller to re-raise the same *class* of failure -- the mount relies on
    EAGAIN/EBUSY/ESTALE/ENOENT from the coordinator to choose between deferring,
    retrying and failing a Finder operation, and a flat EIO would erase that.
    """

    def __init__(
        self,
        message: str,
        *,
        error_type: str | None = None,
        errno: int | None = None,
    ) -> None:
        super().__init__(message)
        self.error_type = error_type
        self.errno = errno


def _send_frame(sock: socket.socket, payload: Mapping[str, Any]) -> None:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    if len(body) > MAX_FRAME_BYTES:
        raise IpcError("control frame exceeds its bound")
    sock.sendall(_LENGTH.pack(len(body)) + body)


def _recv_exactly(sock: socket.socket, count: int) -> bytes | None:
    chunks: list[bytes] = []
    remaining = count
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            return None
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _recv_frame(sock: socket.socket) -> dict[str, Any] | None:
    header = _recv_exactly(sock, _LENGTH.size)
    if header is None:
        return None
    (size,) = _LENGTH.unpack(header)
    if size > MAX_FRAME_BYTES:
        raise IpcError("peer announced an oversized frame")
    body = _recv_exactly(sock, size)
    if body is None:
        return None
    return json.loads(body.decode("utf-8"))


class IpcEndpoint:
    """One end of the duplex link: dispatches inbound calls, awaits replies."""

    def __init__(
        self,
        sock: socket.socket,
        handlers: Mapping[str, Callable[..., Any]],
        *,
        on_close: Callable[[], None] | None = None,
        start_reader: bool = True,
    ) -> None:
        self._sock = sock
        self._handlers = dict(handlers)
        self._on_close = on_close
        self._send_lock = threading.Lock()
        self._pending: dict[str, tuple[threading.Event, list[Any]]] = {}
        self._pending_lock = threading.Lock()
        self._closed = threading.Event()
        self._reader = threading.Thread(
            target=self._read_loop, name="meshia-ipc-reader", daemon=True
        )
        self._reader_started = False
        self._reader_start_lock = threading.Lock()
        self._pool: ThreadPoolExecutor | None = None
        self._pool_lock = threading.Lock()
        if start_reader:
            self.start()

    @property
    def closed(self) -> bool:
        return self._closed.is_set()

    def register_handler(self, method: str, handler: Callable[..., Any]) -> None:
        """Expose one more inbound method; the owner adds handlers as it grows."""

        self._handlers[method] = handler

    def start(self) -> None:
        """Start dispatch only after the owner has published this endpoint."""

        with self._reader_start_lock:
            if self._reader_started or self._closed.is_set():
                return
            self._reader_started = True
            self._reader.start()

    def call(
        self, method: str, /, *, timeout: float = DEFAULT_TIMEOUT_SECONDS, **kwargs: Any
    ) -> Any:
        """Invoke ``method`` on the peer and wait for its reply."""

        if self._closed.is_set():
            raise IpcUnavailable(f"the peer is not connected ({method})")
        request_id = uuid.uuid4().hex
        event = threading.Event()
        slot: list[Any] = []
        with self._pending_lock:
            if len(self._pending) >= MAX_PENDING_REQUESTS:
                raise IpcError("too many in-flight control requests")
            self._pending[request_id] = (event, slot)
        try:
            with self._send_lock:
                _send_frame(
                    self._sock, {"id": request_id, "method": method, "args": kwargs}
                )
        except (OSError, IpcError) as error:
            with self._pending_lock:
                self._pending.pop(request_id, None)
            raise IpcUnavailable(f"the peer went away ({method})") from error
        if not event.wait(timeout):
            with self._pending_lock:
                self._pending.pop(request_id, None)
            raise IpcError(f"the peer did not answer within {timeout}s ({method})")
        with self._pending_lock:
            self._pending.pop(request_id, None)
        if not slot:
            raise IpcUnavailable(f"the peer closed before answering ({method})")
        outcome = slot[0]
        if isinstance(outcome, dict) and "error" in outcome:
            raw_errno = outcome.get("errno")
            raise IpcRemoteError(
                str(outcome["error"]),
                error_type=(
                    str(outcome["error_type"])
                    if outcome.get("error_type") is not None
                    else None
                ),
                errno=(
                    int(raw_errno)
                    if isinstance(raw_errno, int) and not isinstance(raw_errno, bool)
                    else None
                ),
            )
        return outcome.get("value") if isinstance(outcome, dict) else None

    def notify(self, method: str, /, **kwargs: Any) -> None:
        """Fire-and-forget. Never raises: signals are best-effort by design."""

        if self._closed.is_set():
            return
        try:
            with self._send_lock:
                _send_frame(self._sock, {"method": method, "args": kwargs})
        except (OSError, IpcError):
            pass

    def close(self) -> None:
        if self._closed.is_set():
            return
        self._closed.set()
        try:
            self._sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self._sock.close()
        except OSError:
            pass
        self._release_waiters()
        self._shutdown_pool()
        if self._on_close is not None:
            self._on_close()

    def _shutdown_pool(self) -> None:
        with self._pool_lock:
            pool = self._pool
            self._pool = None
        if pool is not None:
            # Never wait: a handler may be blocked on a call to the very peer
            # that just went away, and its own timeout will release it.
            pool.shutdown(wait=False)

    def _release_waiters(self) -> None:
        with self._pending_lock:
            waiters = list(self._pending.values())
            self._pending.clear()
        for event, _slot in waiters:
            event.set()

    def _read_loop(self) -> None:
        try:
            while not self._closed.is_set():
                frame = _recv_frame(self._sock)
                if frame is None:
                    break
                if "method" in frame:
                    self._dispatch(frame)
                else:
                    self._resolve(frame)
        except (OSError, IpcError, ValueError):
            pass
        finally:
            self._closed.set()
            self._release_waiters()
            self._shutdown_pool()
            if self._on_close is not None:
                self._on_close()

    def _resolve(self, frame: Mapping[str, Any]) -> None:
        request_id = str(frame.get("id", ""))
        with self._pending_lock:
            entry = self._pending.get(request_id)
        if entry is None:
            return
        event, slot = entry
        slot.append(dict(frame))
        event.set()

    def _dispatch(self, frame: Mapping[str, Any]) -> None:
        method = str(frame.get("method", ""))
        request_id = frame.get("id")
        handler = self._handlers.get(method)
        if handler is None:
            if request_id is not None:
                self._reply(request_id, error=f"unknown method {method}")
            return
        args = frame.get("args") or {}
        if not isinstance(args, dict):
            if request_id is not None:
                self._reply(request_id, error="args must be an object")
            return
        # Handlers never run on the reader thread: a coordinator call can take
        # a lock for as long as an upload wave, and the engine's staging
        # handlers call back into the mount mid-flight. Keeping the reader free
        # is what lets those nested replies arrive.
        with self._pool_lock:
            if self._closed.is_set():
                return
            if self._pool is None:
                self._pool = ThreadPoolExecutor(
                    max_workers=MAX_HANDLER_THREADS,
                    thread_name_prefix="meshia-ipc-handler",
                )
            pool = self._pool
        try:
            pool.submit(self._run_handler, handler, args, request_id)
        except RuntimeError:
            # The pool was shut down between the check and the submit.
            if request_id is not None:
                self._reply(request_id, error="the peer is closing")

    def _run_handler(
        self,
        handler: Callable[..., Any],
        args: dict[str, Any],
        request_id: Any,
    ) -> None:
        try:
            value = handler(**args)
        except Exception as error:  # noqa: BLE001 - reported to the peer
            if request_id is not None:
                number = getattr(error, "errno", None)
                self._reply(
                    request_id,
                    error=f"{type(error).__name__}: {error}",
                    error_type=type(error).__name__,
                    errno=(
                        int(number)
                        if isinstance(number, int) and not isinstance(number, bool)
                        else None
                    ),
                )
            return
        if request_id is not None:
            self._reply(request_id, value=value)

    def _reply(
        self,
        request_id: Any,
        *,
        value: Any = None,
        error: str | None = None,
        error_type: str | None = None,
        errno: int | None = None,
    ) -> None:
        payload: dict[str, Any] = {"id": request_id}
        if error is not None:
            payload["error"] = error
            if error_type is not None:
                payload["error_type"] = error_type
            if errno is not None:
                payload["errno"] = errno
        else:
            payload["value"] = value
        try:
            with self._send_lock:
                try:
                    _send_frame(self._sock, payload)
                except (TypeError, ValueError) as encode_error:
                    # A handler returned something JSON cannot carry. Answer
                    # with an error rather than leaving the caller to time out.
                    _send_frame(
                        self._sock,
                        {
                            "id": request_id,
                            "error": f"unserializable reply: {encode_error}",
                            "error_type": "TypeError",
                        },
                    )
        except (OSError, IpcError):
            self._closed.set()


def socket_path(home: os.PathLike[str] | str) -> str:
    """Unix socket for this node home.

    macOS caps ``sun_path`` at 104 bytes and a node home can sit under a deep
    path (pytest tmp dirs and per-user TMPDIRs both overflow it), so the socket
    lives beside the home only when that fits and otherwise under the system
    temp dir under a name derived from the home. The name is deterministic, so
    a mount process finds the same socket the engine bound without sharing
    anything but the home path.
    """

    preferred = os.path.join(str(home), "sync-engine.sock")
    # sockaddr_un is 104 on Darwin, 108 on Linux; stay inside the smaller.
    if len(preferred.encode("utf-8")) < 100:
        return preferred
    digest = hashlib.sha256(os.path.abspath(str(home)).encode("utf-8")).hexdigest()[:16]
    return os.path.join(tempfile.gettempdir(), f"meshia-engine-{digest}.sock")


def listen(path: str) -> socket.socket:
    try:
        os.unlink(path)
    except FileNotFoundError:
        pass
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(path)
    os.chmod(path, 0o600)
    server.listen(4)
    return server


def connect(path: str, *, timeout: float = 5.0) -> socket.socket:
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.settimeout(timeout)
    client.connect(path)
    client.settimeout(None)
    return client
