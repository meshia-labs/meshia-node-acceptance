"""Run the Windows user service without allocating a console window."""

from __future__ import annotations

from contextlib import ExitStack
import os
from pathlib import Path
import re
import sys
from typing import Sequence


def _failure_frames(error: Exception) -> dict[str, str]:
    """Bounded package source locations only: no exception text or locals."""
    root = os.path.normcase(os.path.abspath(os.path.dirname(__file__)))
    locations = []
    trace = error.__traceback__
    for _ in range(64):
        if trace is None:
            break
        code = trace.tb_frame.f_code
        filename = os.path.normcase(os.path.abspath(code.co_filename))
        module = trace.tb_frame.f_globals.get("__name__")
        stem = os.path.splitext(os.path.basename(filename))[0]
        if (os.path.dirname(filename) == root
                and isinstance(module, str) and module == "meshia_node." + stem
                and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", stem)
                and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", code.co_name)):
            locations.append(f"{module}:{code.co_name}:{trace.tb_lineno}")
        trace = trace.tb_next
    return {f"source_frame_{index}": location for index, location in enumerate(locations[-8:])}


def main(argv: Sequence[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if (len(arguments) != 5 or arguments[1] != "--home"
            or arguments[3:] != ["service", "run"]):
        return 2
    executable = Path(arguments[0])
    python_directory = Path(sys.executable).resolve().parent
    console_directory = executable.resolve().parent
    if (not executable.is_absolute() or not executable.is_file()
            or executable.name.lower() not in ("meshia-node.exe", "meshia.exe")
            or not (console_directory == python_directory
                or (console_directory.name.lower() == "scripts"
                    and console_directory.parent == python_directory))):
        return 2

    # Pythonw has no console streams. Libraries may still write to them; the
    # existing private, redacting NodeLogger remains the diagnostic authority.
    from .cli import main as run_cli
    from .config import Paths
    from .log import NodeLogger

    previous_argv = sys.argv
    previous_streams = {name: getattr(sys, name) for name in ("stdin", "stdout", "stderr")}
    logger = NodeLogger(path=Paths.resolve(arguments[2]).log_path, quiet=True)
    with ExitStack() as stack:
        try:
            sys.argv = arguments
            for name, previous in previous_streams.items():
                if previous is None:
                    setattr(sys, name, stack.enter_context(open(os.devnull, "r" if name == "stdin" else "w")))
            result = run_cli(arguments[1:])
            if result:
                logger.record("windowless_service_exited", exit_code=result)
            return result
        except Exception as error:
            logger.record("windowless_service_failed", error=type(error).__name__, **_failure_frames(error))
            return 1
        finally:
            sys.argv = previous_argv
            for name, previous in previous_streams.items():
                setattr(sys, name, previous)


if __name__ == "__main__":
    raise SystemExit(main())
