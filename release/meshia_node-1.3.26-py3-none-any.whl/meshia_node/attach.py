"""Attachment lifecycle: attach, heartbeat, metrics, and the foreground runner.

The runner is a single serialised loop (like the Swift ``ConnectionRunner``):
heartbeat every 30s, metrics every 15s, independently paced command claims,
and local Fabric maintenance. One loop means one ordering for signed-request
sequences — no thread interleaving can produce an out-of-order sequence.
"""

from __future__ import annotations

import random
import sys
import threading
import time
from typing import Any, Callable, TypeVar

from .client import SignedClient
from .config import ACCESS_MODES, DEFAULT_ACCESS_MODE, ConfigStore, NodeConfig
from .errors import Disconnected, MeshiaNodeError, NetworkError, RemoteError, StateError
from .log import NULL_LOGGER, NodeLogger
from .machine import ProcessSampler
from .object_edge import ObjectEdgeRegistry, default_registry
from .util import POSTGRES_UUID_RE, UUID_RE, iso8601

HEARTBEAT_INTERVAL_SECONDS = 30.0
METRICS_INTERVAL_SECONDS = 15.0
ACTIVE_COMMAND_POLL_SECONDS = 2.0
COMMAND_READINESS_POLL_SECONDS = 1.0
IDLE_POLL_SECONDS = 1.5
MAX_IDLE_POLL_SECONDS = 6.0
DEGRADED_BACKOFF_BASE_SECONDS = 5.0
MAX_DEGRADED_BACKOFF_SECONDS = 30.0
ATTACHMENT_LEASE_SECONDS = 90.0
RATE_LIMIT_RECOVERY_YIELD_SECONDS = 1.0
HEARTBEAT_WORKER_STOP_TIMEOUT_SECONDS = 25.0
# File mounts keep workspace authority. Full access additionally permits native
# commands with the installing OS user's file and network permissions.
WORKSPACE_FILES_PERMISSION_PROFILE = {
    "workspace": "read_write",
    "outside_workspace": "none",
    "network": "deny",
}
PERSONAL_PERMISSION_PROFILE = WORKSPACE_FILES_PERMISSION_PROFILE
ACCESS_PERMISSION_PROFILES = {
    "files": WORKSPACE_FILES_PERMISSION_PROFILE,
    "limited": {
        "workspace": "read_write", "outside_workspace": "none", "network": "allow", "exec": "workspace",
    },
    "full": {
        "workspace": "read_write",
        "outside_workspace": "read_write",
        "network": "allow",
        "exec": "host",
    },
}
PERMISSION_PROFILES = {
    "personal": PERSONAL_PERMISSION_PROFILE,
    "compute": WORKSPACE_FILES_PERMISSION_PROFILE,
}
PERMISSION_PROFILE = PERSONAL_PERMISSION_PROFILE
WORKSPACE_STORAGE_TERMINAL_CODES = frozenset({
    "WORKSPACE_STORAGE_DELETED", "WORKSPACE_STORAGE_DISABLED", "WORKSPACE_STORAGE_SUPERSEDED",
})


def can_recover_account_storage(config: NodeConfig) -> bool:
    """A workspace retirement does not revoke an authenticated account device."""
    return bool(
        config.account_id is not None
        and config.lifecycle == "disconnected"
        and config.disconnect_reason in WORKSPACE_STORAGE_TERMINAL_CODES
    )


def _control_storage_error(
    document: Any, config: NodeConfig, *, opted_in: bool,
) -> Disconnected | None:
    """Validate the explicit control-only receipt before accepting its lease."""
    if not isinstance(document, dict):
        return None
    storage = document.get("workspace_storage")
    unavailable = isinstance(storage, dict) and storage.get("state") == "unavailable"
    if document.get("control_only") is not True and not unavailable:
        return None
    code = storage.get("code") if isinstance(storage, dict) else None
    if (
        not opted_in or document.get("control_only") is not True or not unavailable
        or not isinstance(code, str) or code not in WORKSPACE_STORAGE_TERMINAL_CODES
        or config.account_id is None or document.get("account_id") != config.account_id
        or document.get("object_edge") is not None
    ):
        raise NetworkError("Meshia returned an invalid account control receipt.")
    return Disconnected("The selected workspace no longer has Files authority.", reason_code=code)


def permission_profile(tier: str, access: str = DEFAULT_ACCESS_MODE) -> dict[str, str]:
    """Return the narrow authority for a file-only or compute connection."""
    if tier == "personal":
        return dict(WORKSPACE_FILES_PERMISSION_PROFILE)
    effective = access if access in ACCESS_MODES else DEFAULT_ACCESS_MODE
    return dict(ACCESS_PERMISSION_PROFILES[effective])

T = TypeVar("T")


def retry(
    operation: Callable[[], T],
    attempts: int = 3,
    delay: float = 0.25,
    sleep: Callable[[float], None] = time.sleep,
) -> T:
    """Retry transient failures; revocation and 4xx-permanent errors propagate."""
    wait = delay
    for attempt in range(1, attempts + 1):
        try:
            return operation()
        except Disconnected:
            raise
        except RemoteError as error:
            if attempt >= attempts or not error.retryable:
                raise
        except NetworkError:
            if attempt >= attempts:
                raise
        sleep(wait)
        wait = min(wait * 2, 2.0)
    raise NetworkError("Meshia is temporarily unreachable.")  # pragma: no cover


def attach(
    client: SignedClient,
    store: ConfigStore,
    mount_name: str = "workspace",
    *,
    object_edge_registry: ObjectEdgeRegistry | None = None,
    on_workspace_storage_unavailable: Callable[[Disconnected], None] | None = None,
) -> str:
    """Bind this host to its pairing session and return the attachment id."""
    config = store.require()
    account_control = config.account_id is not None and on_workspace_storage_unavailable is not None
    if config.lifecycle == "disconnected" and not (
        account_control and can_recover_account_storage(config)
    ):
        raise Disconnected(
            "This host is parked. Run `meshia-node connect` explicitly before attaching again."
        )
    if not UUID_RE.match(config.session_id):
        raise Disconnected("This enrollment has no session scope; pair again.")
    profile = permission_profile(config.tier, config.access)
    def begin(current: NodeConfig) -> None:
        if current.lifecycle == "disconnected" and not (
            account_control and can_recover_account_storage(current)
            and current.disconnect_reason == config.disconnect_reason
        ):
            raise Disconnected()
        current.lifecycle = "attaching"

    store.update(begin)
    document = client.post_json(
        f"api/connected-hosts/{config.host_id}/attach",
        {
            "session_id": config.session_id,
            "mount_name": mount_name,
            "permissions": profile,
            "account_control": account_control,
        },
    )
    attachment = (document or {}).get("attachment") if isinstance(document, dict) else None
    attachment_id = str((attachment or {}).get("id", ""))
    if not UUID_RE.match(attachment_id):
        raise NetworkError("Meshia returned an invalid attachment receipt.")
    workspace_name = document.get("workspace_name") if isinstance(document, dict) else None
    account_id = document.get("account_id") if isinstance(document, dict) else None
    account_email = document.get("account_email") if isinstance(document, dict) else None
    if workspace_name is not None and (
        not isinstance(workspace_name, str)
        or not workspace_name.strip()
        or len(workspace_name.encode("utf-8")) > 1_024
        or "\x00" in workspace_name
    ):
        raise NetworkError("Meshia returned an invalid workspace display name.")
    if account_email is not None and (
        not isinstance(account_email, str)
        or not 3 <= len(account_email.encode("utf-8")) <= 320
        or "@" not in account_email
        or any(ord(character) < 33 for character in account_email)
    ):
        raise NetworkError("Meshia returned an invalid account identity.")
    if account_id is not None and (
        not isinstance(account_id, str) or POSTGRES_UUID_RE.fullmatch(account_id) is None
    ):
        raise NetworkError("Meshia returned an invalid account identity.")
    storage_error = _control_storage_error(document, config, opted_in=account_control)
    if storage_error is not None:
        assert on_workspace_storage_unavailable is not None
        on_workspace_storage_unavailable(storage_error)
    # Meshia object edge grant (optional): scoped bytes lane for this session.
    (object_edge_registry or default_registry()).observe(
        config.session_id,
        document.get("object_edge") if isinstance(document, dict) else None,
        attachment_id=attachment_id,
    )

    def _bind(current: NodeConfig) -> None:
        if current.lifecycle == "disconnected":
            raise Disconnected()
        current.attachment_id = attachment_id
        current.disconnect_reason = None
        if isinstance(workspace_name, str):
            current.workspace_name = workspace_name.strip()
        if isinstance(account_email, str):
            current.account_email = account_email
        if isinstance(account_id, str):
            if current.account_id not in (None, account_id):
                raise Disconnected("Meshia account authority changed during attachment.")
            current.account_id = account_id
        current.lifecycle = "attaching"
        current.last_heartbeat_at = None

    store.update(_bind)
    return attachment_id


def heartbeat(
    client: SignedClient,
    store: ConfigStore,
    *,
    object_edge_registry: ObjectEdgeRegistry | None = None,
    workspace_execution: bool = False,
    on_workspace_storage_unavailable: Callable[[Disconnected], None] | None = None,
) -> str | None:
    """Renew the attachment lease and adopt the server-authoritative mode."""
    config = store.require()
    if not config.attachment_id:
        raise Disconnected("An active attachment is required for heartbeat.")
    account_control = config.account_id is not None and on_workspace_storage_unavailable is not None
    document = client.post_json(
        f"api/connected-hosts/{config.host_id}/heartbeat",
        {"attachment_id": config.attachment_id, "workspace_commands": True,
         "workspace_execution": workspace_execution is True,
         "native_execution": sys.platform in ("darwin", "linux", "win32"),
         **({"app_protocol": "http-stream-v1"} if sys.platform in ("darwin", "linux", "win32") else {}),
         "account_control": account_control},
    )
    reported = document.get("access_mode") if isinstance(document, dict) else None
    access = reported if reported in ACCESS_MODES else None
    workspace_name = document.get("workspace_name") if isinstance(document, dict) else None
    account_id = document.get("account_id") if isinstance(document, dict) else None
    account_email = document.get("account_email") if isinstance(document, dict) else None
    if workspace_name is not None and (
        not isinstance(workspace_name, str)
        or not workspace_name.strip()
        or len(workspace_name.encode("utf-8")) > 1_024
        or "\x00" in workspace_name
    ):
        raise NetworkError("Meshia returned an invalid workspace display name.")
    if account_email is not None and (
        not isinstance(account_email, str)
        or not 3 <= len(account_email.encode("utf-8")) <= 320
        or "@" not in account_email
        or any(ord(character) < 33 for character in account_email)
    ):
        raise NetworkError("Meshia returned an invalid account identity.")
    if account_id is not None and (
        not isinstance(account_id, str) or POSTGRES_UUID_RE.fullmatch(account_id) is None
    ):
        raise NetworkError("Meshia returned an invalid account identity.")
    storage_error = _control_storage_error(document, config, opted_in=account_control)
    if storage_error is not None:
        assert on_workspace_storage_unavailable is not None
        on_workspace_storage_unavailable(storage_error)
    # Every heartbeat renews the object edge grant (or withdraws it).
    (object_edge_registry or default_registry()).observe(
        config.session_id,
        document.get("object_edge") if isinstance(document, dict) else None,
        attachment_id=config.attachment_id,
    )

    def _mark(current: NodeConfig) -> None:
        if current.lifecycle == "disconnected":
            raise Disconnected()
        current.lifecycle = "connected"
        current.last_heartbeat_at = iso8601()
        if access is not None:
            current.access = access
        if isinstance(workspace_name, str):
            current.workspace_name = workspace_name.strip()
        if isinstance(account_email, str):
            current.account_email = account_email
        if isinstance(account_id, str):
            if current.account_id not in (None, account_id):
                raise Disconnected("Meshia account authority changed during heartbeat.")
            current.account_id = account_id
        current.disconnect_reason = None

    store.update(_mark)
    return access


def rename_workspace(
    client: SignedClient,
    store: ConfigStore,
    expected_name: str,
    new_name: str,
) -> str:
    """Rename the attached workspace under optimistic server authority."""

    config = store.require()
    if not config.attachment_id:
        raise Disconnected("An active attachment is required to rename a workspace.")
    document = client.post_json(
        f"api/connected-hosts/{config.host_id}/workspace",
        {
            "attachment_id": config.attachment_id,
            "session_id": config.session_id,
            "expected_name": expected_name,
            "new_name": new_name,
        },
    )
    accepted = document.get("workspace_name") if isinstance(document, dict) else None
    if (
        not isinstance(accepted, str)
        or accepted != new_name
        or not accepted.strip()
        or len(accepted.encode("utf-8")) > 400
        or "\x00" in accepted
    ):
        raise NetworkError("Meshia returned an invalid workspace rename receipt.")

    def _commit(current: NodeConfig) -> None:
        if (
            current.attachment_id != config.attachment_id
            or current.session_id != config.session_id
        ):
            raise Disconnected("Workspace attachment authority changed during rename.")
        if current.workspace_name not in (expected_name, accepted):
            raise StateError("Workspace name changed during rename; refreshing from Meshia.")
        current.workspace_name = accepted

    store.update(_commit)
    return accepted


def metrics_body(
    store: ConfigStore, sampler: ProcessSampler, traffic: tuple[int, int] | None = None
) -> dict[str, Any]:
    config, sequence = store.allocate_metrics_sequence()
    cpu_percent, resident = sampler.sample()
    received, transmitted = traffic or (0, 0)
    return {
        "attachment_id": config.attachment_id,
        "sample_sequence": sequence,
        "observed_at": iso8601(),
        "task_cpu_percent": cpu_percent,
        "task_memory_bytes": resident,
        "fabric_rx_bytes": received,
        "fabric_tx_bytes": transmitted,
        # Connected-host v1 rejects any non-empty GPU array.
        "gpu": [],
    }


def post_metrics(
    client: SignedClient, store: ConfigStore, sampler: ProcessSampler, traffic: tuple[int, int] | None = None
) -> None:
    config = store.require()
    client.post_json(f"api/connected-hosts/{config.host_id}/metrics", metrics_body(store, sampler, traffic))


def disconnect(client: SignedClient, store: ConfigStore) -> None:
    """Release the remote attachment, then park the local state.

    The disconnect receipt carries the authoritative generation. If the server
    advanced it, adopt it and restart the sequence space — a new generation gets
    a fresh sequence counter, so reusing the old one would replay.
    """
    config = store.require()
    receipt: Any = None
    try:
        receipt = client.post_empty(f"api/connected-hosts/{config.host_id}/disconnect").json()
    finally:
        generation = receipt.get("generation") if isinstance(receipt, dict) else None

        def _park(current: NodeConfig) -> None:
            current.lifecycle = "disconnected"
            current.attachment_id = None
            current.disconnect_reason = "USER_DISCONNECTED"
            if (
                isinstance(generation, int)
                and not isinstance(generation, bool)
                and generation > current.generation
            ):
                current.generation = generation
                current.next_sequence = 1

        store.update(_park)


def forget_remote(client: SignedClient, store: ConfigStore) -> None:
    """Best-effort remote revocation; the local erase happens regardless."""
    config = store.require()
    client.delete_empty(f"api/connected-hosts/{config.host_id}")


class NodeRunner:
    """Foreground supervision loop for an attached host."""

    def __init__(
        self,
        store: ConfigStore,
        client: SignedClient,
        command_loop: Any,
        logger: NodeLogger = NULL_LOGGER,
        sampler: ProcessSampler | None = None,
        traffic: Callable[[], tuple[int, int]] | None = None,
        sleep: Callable[[float], None] = time.sleep,
        now: Callable[[], float] = time.monotonic,
        jitter: Callable[[], float] = random.random,
        on_access_mode: Callable[[str], None] | None = None,
        on_command_readiness: Callable[
            [bool, str | None, int | None], bool | None
        ]
        | None = None,
        on_runtime_health: Callable[[dict[str, Any]], bool | None] | None = None,
        maintenance: Any | None = None,
        wait: Callable[[float], bool | None] | None = None,
        independent_heartbeat: bool = False,
        workspace_execution: Callable[[], bool] | None = None,
        on_workspace_storage_unavailable: Callable[[Disconnected], None] | None = None,
        account_command_claim_ready: Callable[[], bool] | None = None,
    ) -> None:
        self.store = store
        self.client = client
        self.command_loop = command_loop
        self.logger = logger
        self.sampler = sampler or ProcessSampler()
        self.traffic = traffic
        self._sleep = sleep
        self._now = now
        self._jitter = jitter
        self._stop = False
        self._wake_event = threading.Event()
        self.maintenance = maintenance
        candidate_wait = getattr(maintenance, "wait", None) if maintenance is not None else None
        self._wait_callback = wait or (candidate_wait if callable(candidate_wait) else None)
        # Lets the live executor follow the server-authoritative attachment
        # mode without requiring a reconnect.
        self.on_access_mode = on_access_mode
        self.on_command_readiness = on_command_readiness
        self.on_runtime_health = on_runtime_health
        self._account_command_claim_ready = account_command_claim_ready
        self._access: str | None = None
        self._command_readiness_snapshot: tuple[bool, str | None, int | None] | None = None
        self._degraded_operations: set[str] = set()
        self._failure_streaks: dict[str, int] = {}
        self._authority_offline = False
        self._last_heartbeat_success = 0.0
        self._rate_limit_recovery_pending = False
        self._last_errors: dict[str, dict[str, str]] = {}
        self._maintenance_started = False
        self._independent_heartbeat = bool(independent_heartbeat and maintenance is not None)
        self._workspace_execution = workspace_execution
        self._on_workspace_storage_unavailable = on_workspace_storage_unavailable
        self._heartbeat_worker_stop = threading.Event()
        # A heartbeat can change the executor's effective access mode. Keep
        # command claim + preparation ordered with that observation: the
        # worker owns this gate from request start until its result is
        # published, and the supervision thread owns it while synchronizing
        # the result and admitting a claim.
        self._heartbeat_access_gate = threading.Lock()
        self._heartbeat_worker_lock = threading.Lock()
        self._heartbeat_worker: threading.Thread | None = None
        self._heartbeat_worker_generation = 0
        self._heartbeat_worker_consumed_generation = 0
        self._heartbeat_worker_result: tuple[
            BaseException | None, float, bool, str | None
        ] | None = None
        self._heartbeat_worker_next_due = float("inf")
        completion_wakeup = getattr(self.command_loop, "set_completion_wakeup", None)
        if callable(completion_wakeup):
            completion_wakeup(self._wake)

    def _wake(self) -> None:
        """Interrupt either local wait without performing any signed operation."""
        self._wake_event.set()
        wake = getattr(self.maintenance, "wake", None) if self.maintenance is not None else None
        if callable(wake):
            wake()

    def stop(self) -> None:
        self._stop = True
        # Idempotent: maintenance may have been swapped or arrives late.
        self._arm_maintenance_stop_check()
        self._heartbeat_worker_stop.set()
        cancel = getattr(self.command_loop, "cancel", None)
        if callable(cancel):
            cancel()
        self._wake()

    def _wait_for(self, seconds: float) -> bool:
        """Wait without making shutdown sit behind a long retry sleep.

        A Fabric coordinator may supply a watcher-backed ``wait(timeout)``.
        Those waits are sliced to half a second unless it also exposes
        ``wake()``, so the runner remains responsive even with a minimal
        callback. Tests and other callers that inject ``sleep`` keep their
        deterministic one-call timing behavior.
        """
        if seconds <= 0 or self._stop:
            return self._stop
        if self._wait_callback is not None:
            remaining = seconds
            wake = getattr(self.maintenance, "wake", None) if self.maintenance is not None else None
            slice_limit = seconds if callable(wake) else min(0.5, seconds)
            while remaining > 0 and not self._stop:
                interval = min(slice_limit, remaining)
                before = self._now()
                if bool(self._wait_callback(interval)):
                    return True
                elapsed = max(0.0, self._now() - before)
                # A test callback may not advance its fake clock. Still make
                # bounded progress instead of spinning forever.
                remaining -= elapsed if elapsed > 0 else interval
            return self._stop
        if self._sleep is time.sleep:
            return self._wake_event.wait(seconds)
        self._sleep(seconds)
        return self._stop

    def _maintenance_poll_once(self) -> bool:
        if self.maintenance is None:
            return False
        poll = getattr(self.maintenance, "poll_once", self.maintenance)
        if not callable(poll):
            raise TypeError("maintenance must be callable or expose poll_once().")
        return bool(poll())

    def _start_maintenance_once(self) -> None:
        """Arm an optional collector only after the first heartbeat attempt.

        Production Fabric exposes ``start()`` to seed its bounded durable
        baseline and arm the native watcher. Keeping that work inside the
        runner means the process can publish a live heartbeat before startup
        reconciliation; older test doubles and other maintenance callbacks do
        not need to implement the hook.
        """

        if self._maintenance_started:
            return
        self._arm_maintenance_stop_check()
        start = getattr(self.maintenance, "start", None)
        if callable(start):
            start()
        self._maintenance_started = True

    def _arm_maintenance_stop_check(self) -> None:
        """Let maintenance yield between phases once a stop was requested.

        A stop request used to be honoured only after a full maintenance
        turn -- 29-35 s under hydration (2026-09-02/03), which is what made
        the installer's mount release expire and refuse. Collectors that
        expose ``set_stop_check`` consult this predicate between their phases
        and return early; a bare callable maintenance keeps its old behaviour.
        """

        arm = getattr(self.maintenance, "set_stop_check", None) if self.maintenance is not None else None
        if callable(arm):
            arm(lambda: bool(self._stop))

    def _start_independent_heartbeat(self, first_due: float) -> None:
        """Keep the lease live while synchronous maintenance owns the main loop.

        SignedClient already serializes every request in process and across
        processes. One bounded daemon can therefore renew the lease during a
        large startup scan without reordering Fabric or command traffic. It
        retains only its latest result and is joined before runner teardown.
        """

        if not self._independent_heartbeat or self._heartbeat_worker is not None:
            return
        self._heartbeat_worker_stop.clear()
        with self._heartbeat_worker_lock:
            self._heartbeat_worker_next_due = max(self._now(), first_due)

        def keep_lease() -> None:
            def park_offline(current: NodeConfig) -> None:
                if current.lifecycle != "disconnected":
                    current.lifecycle = "offline"

            failure_streak = 0
            last_success = self._last_heartbeat_success
            lease_parked = False
            while not self._heartbeat_worker_stop.is_set():
                with self._heartbeat_worker_lock:
                    due = self._heartbeat_worker_next_due
                if self._heartbeat_worker_stop.wait(max(0.0, due - self._now())):
                    return
                reported_access: str | None = None
                self._heartbeat_access_gate.acquire()
                try:
                    reported_access = self._request_pulse()
                except Disconnected as error:
                    moment = self._now()
                    try:
                        self.store.update(
                            lambda current: setattr(
                                current, "lifecycle", "disconnected"
                            )
                        )
                    except MeshiaNodeError:
                        pass
                    with self._heartbeat_worker_lock:
                        self._heartbeat_worker_generation += 1
                        self._heartbeat_worker_result = (error, moment, True, None)
                        self._heartbeat_worker_next_due = float("inf")
                    return
                except (NetworkError, RemoteError) as error:
                    failure_streak += 1
                    ceiling = min(
                        DEGRADED_BACKOFF_BASE_SECONDS
                        * (2 ** min(failure_streak - 1, 16)),
                        MAX_DEGRADED_BACKOFF_SECONDS,
                    )
                    unit = min(1.0, max(0.0, float(self._jitter())))
                    retry_in = ceiling * (0.5 + 0.5 * unit)
                    if (
                        isinstance(error, RemoteError)
                        and error.status == 429
                        and error.retry_after_seconds is not None
                    ):
                        retry_in = max(retry_in, error.retry_after_seconds)
                    moment = self._now()
                    lease_expired = (
                        moment - last_success >= ATTACHMENT_LEASE_SECONDS
                    )
                    if lease_expired and not lease_parked:
                        try:
                            self.store.update(park_offline)
                        except MeshiaNodeError:
                            pass
                        lease_parked = True
                    with self._heartbeat_worker_lock:
                        self._heartbeat_worker_generation += 1
                        self._heartbeat_worker_result = (
                            error,
                            moment,
                            lease_expired,
                            None,
                        )
                        self._heartbeat_worker_next_due = moment + retry_in
                except BaseException as error:
                    moment = self._now()
                    try:
                        self.store.update(park_offline)
                    except MeshiaNodeError:
                        pass
                    with self._heartbeat_worker_lock:
                        self._heartbeat_worker_generation += 1
                        self._heartbeat_worker_result = (error, moment, True, None)
                        self._heartbeat_worker_next_due = float("inf")
                    return
                else:
                    if self._heartbeat_worker_stop.is_set():
                        try:
                            self.store.update(park_offline)
                        except MeshiaNodeError:
                            pass
                        return
                    failure_streak = 0
                    moment = self._now()
                    last_success = moment
                    lease_parked = False
                    with self._heartbeat_worker_lock:
                        self._heartbeat_worker_generation += 1
                        self._heartbeat_worker_result = (
                            None,
                            moment,
                            False,
                            reported_access,
                        )
                        self._heartbeat_worker_next_due = (
                            moment + HEARTBEAT_INTERVAL_SECONDS
                        )
                finally:
                    self._heartbeat_access_gate.release()

        worker = threading.Thread(
            target=keep_lease,
            name="meshia-heartbeat-lease",
            daemon=True,
        )
        self._heartbeat_worker = worker
        worker.start()

    def _sync_independent_heartbeat(self) -> tuple[bool, float]:
        """Merge the worker's latest bounded result on the serialized loop."""

        if self._heartbeat_worker is None:
            return "heartbeat" in self._degraded_operations, float("inf")
        with self._heartbeat_worker_lock:
            generation = self._heartbeat_worker_generation
            result = self._heartbeat_worker_result
            next_due = self._heartbeat_worker_next_due
        if generation == self._heartbeat_worker_consumed_generation or result is None:
            return "heartbeat" in self._degraded_operations, next_due
        self._heartbeat_worker_consumed_generation = generation
        error, observed_at, lease_expired, reported_access = result
        if error is None:
            self._apply_reported_access(reported_access)
            self._last_heartbeat_success = observed_at
            self._recover("heartbeat")
            self._authority_offline = False
            return False, next_due
        if isinstance(error, Disconnected):
            raise error
        if not isinstance(error, (NetworkError, RemoteError)):
            raise error
        retry_in = self._degrade(error, "heartbeat")
        if isinstance(error, RemoteError) and error.status == 429:
            self._rate_limit_recovery_pending = True
        if lease_expired:
            self._mark_authority_offline(error, retry_in)
        return True, next_due

    def _stop_independent_heartbeat(self) -> None:
        worker = self._heartbeat_worker
        if worker is None:
            return
        self._heartbeat_worker_stop.set()
        worker.join(timeout=HEARTBEAT_WORKER_STOP_TIMEOUT_SECONDS)
        if worker.is_alive():
            self.logger.record("heartbeat_worker_stop_deferred")
            return
        self._heartbeat_worker = None

    def _maintenance_poll_delay(self) -> float:
        """Return the coordinator's next due interval when it exposes one."""

        if self.maintenance is None:
            return float("inf")
        candidate = getattr(self.maintenance, "next_poll_delay", None)
        if candidate is None:
            return float("inf")
        value = candidate() if callable(candidate) else candidate
        try:
            delay = float(value)
        except (TypeError, ValueError):
            return float("inf")
        if delay != delay:  # NaN must not turn the supervision loop into a spin.
            return float("inf")
        return max(0.0, delay)

    def _host_rate_limit_remaining(self) -> float:
        """Read SignedClient's monotonic host cooldown without making a request."""

        candidate = getattr(self.client, "rate_limit_remaining_seconds", 0.0)
        value = candidate() if callable(candidate) else candidate
        try:
            delay = float(value)
        except (TypeError, ValueError):
            return 0.0
        if delay != delay or delay == float("inf") or delay == float("-inf"):
            return 0.0
        return max(0.0, delay)

    def _command_readiness(self) -> tuple[bool, str | None, int | None]:
        """Read one atomic Fabric readiness snapshot, failing closed on drift."""

        if self.maintenance is None:
            return True, None, None
        try:
            candidate = getattr(self.maintenance, "command_readiness", None)
            if candidate is not None:
                value = candidate() if callable(candidate) else candidate
                if not isinstance(value, tuple) or len(value) != 3:
                    return False, "sync_error", None
                ready, reason, generation = value
                if not isinstance(ready, bool):
                    return False, "sync_error", None
                if reason is not None and not isinstance(reason, str):
                    return False, "sync_error", None
                if generation is not None and (
                    not isinstance(generation, int) or isinstance(generation, bool)
                ):
                    return False, "sync_error", None
                return ready, reason, generation

            legacy = getattr(self.maintenance, "ready_for_commands", None)
            if legacy is None:
                # Maintenance test doubles predating the readiness contract do
                # not gate commands. Production Fabric always exposes one of
                # the two attributes above.
                return True, None, None
            ready = legacy() if callable(legacy) else legacy
            if not isinstance(ready, bool):
                return False, "sync_error", None
            return ready, None, None
        except Exception:
            return False, "sync_error", None

    def _report_command_readiness(
        self, snapshot: tuple[bool, str | None, int | None]
    ) -> bool:
        """Publish readiness and return the effective command-claim decision.

        The callback may persist a safety boundary (for example completing a
        first-use workspace adoption marker). Its failure or explicit ``False``
        must veto this tick's claim and remain retryable on the identical next
        snapshot. Cache only a successfully published observation.
        """

        if snapshot == self._command_readiness_snapshot:
            return snapshot[0]
        if self.on_command_readiness is None:
            self._command_readiness_snapshot = snapshot
            return snapshot[0]
        try:
            accepted = self.on_command_readiness(*snapshot)
        except Exception as error:
            self.logger.record(
                "command_readiness_callback_failed",
                error_type=type(error).__name__,
            )
            return False
        if accepted is False:
            self.logger.record("command_readiness_callback_deferred")
            return False
        self._command_readiness_snapshot = snapshot
        return snapshot[0]

    def _can_claim_account_commands(self, readiness: tuple[bool, str | None, int | None]) -> bool:
        # Account queues carry their own exact workspace/grant authority. The
        # original enrollment's deleted workspace must not starve those queues,
        # nor may this discovery capability mark that workspace command-safe.
        current = self.store.require()
        if (self._account_command_claim_ready is None or self._stop
            or self._authority_offline or current.lifecycle != "connected"
            or current.account_id is None or current.workspace_adoption_pending
            or readiness != (False, "workspace_unavailable", None)
            or self._command_readiness_snapshot != readiness):
            return False
        try:
            return self._account_command_claim_ready() is True
        except Exception:
            return False

    def _next_scheduled_wait(
        self,
        *,
        next_command_poll: float,
        next_heartbeat: float,
        next_metrics: float,
    ) -> float:
        """Wait only until the earliest independently scheduled activity."""

        now = self._now()
        return min(
            max(0.0, next_command_poll - now),
            max(0.0, next_heartbeat - now),
            max(0.0, next_metrics - now),
            self._maintenance_poll_delay(),
        )

    def _request_pulse(self) -> str | None:
        """Renew the lease and return the server's reported access mode."""

        if self._on_workspace_storage_unavailable is not None:
            return heartbeat(
                self.client, self.store,
                workspace_execution=(self._workspace_execution() if self._workspace_execution is not None else False),
                on_workspace_storage_unavailable=self._on_workspace_storage_unavailable,
            )
        if self._workspace_execution is not None:
            return heartbeat(self.client, self.store, workspace_execution=self._workspace_execution())
        return heartbeat(self.client, self.store)

    def _apply_reported_access(self, reported: str | None) -> None:
        """Adopt one recognized server-authoritative heartbeat mode."""

        if reported not in ACCESS_MODES or reported == self._access:
            return
        self._access = reported
        self.logger.record("access_mode_changed", access=reported)
        if self.on_access_mode is not None:
            self.on_access_mode(reported)

    def _pulse(self) -> None:
        """One heartbeat, adopting any access-mode change the server reports."""

        self._apply_reported_access(self._request_pulse())

    @staticmethod
    def _error_fields(error: MeshiaNodeError, operation: str) -> dict[str, Any]:
        fields: dict[str, Any] = {
            "operation": operation,
            "error_code": error.code,
            "detail": str(error),
        }
        if isinstance(error, RemoteError):
            fields["http_status"] = error.status
            fields["remote_code"] = error.remote_code
        return fields

    def _next_backoff(self, operation: str) -> tuple[int, float]:
        streak = self._failure_streaks.get(operation, 0) + 1
        self._failure_streaks[operation] = streak
        ceiling = min(
            DEGRADED_BACKOFF_BASE_SECONDS * (2 ** (streak - 1)),
            MAX_DEGRADED_BACKOFF_SECONDS,
        )
        # Equal jitter avoids both a zero-delay retry storm and synchronized
        # fleets hammering a recovering database at the maximum interval.
        unit = min(1.0, max(0.0, float(self._jitter())))
        return streak, ceiling * (0.5 + 0.5 * unit)

    def _degrade(self, error: MeshiaNodeError, operation: str) -> float:
        streak, local_retry = self._next_backoff(operation)
        remote_retry = (
            error.retry_after_seconds
            if isinstance(error, RemoteError)
            and error.status == 429
            and error.retry_after_seconds is not None
            else 0.0
        )
        retry_in = max(local_retry, remote_retry)
        fields = {
            **self._error_fields(error, operation),
            "consecutive_failures": streak,
            "retry_in_seconds": round(retry_in, 3),
        }
        if operation not in self._degraded_operations:
            self._degraded_operations.add(operation)
            self.logger.record("connection_degraded", **fields)
        else:
            self.logger.record("connection_retry_scheduled", **fields)
        # Reinsert so dictionary order is also recency order. The runtime
        # projection publishes only the latest bounded item.
        self._last_errors.pop(operation, None)
        self._last_errors[operation] = {
            "operation": operation[:64],
            "code": error.code[:64],
            "detail": str(error)[:256],
        }
        return retry_in

    def _recover(self, operation: str) -> None:
        recovered = operation in self._degraded_operations
        consecutive_failures = self._failure_streaks.pop(operation, 0)
        self._degraded_operations.discard(operation)
        self._last_errors.pop(operation, None)
        prior_state = "degraded"
        if operation == "heartbeat" and self._authority_offline:
            self._authority_offline = False
            recovered = True
            prior_state = "offline"
        if recovered:
            self.logger.record(
                "connection_recovered",
                operation=operation,
                prior_state=prior_state,
                consecutive_failures=consecutive_failures,
                **({"lease_status": "renewed"} if operation == "heartbeat" else {}),
            )

    def _report_runtime_health(
        self,
        *,
        command_safe: bool,
        command_reason: str | None,
        head_generation: int | None,
    ) -> None:
        """Publish one bounded live snapshot; observability never claims work."""

        if self.on_runtime_health is None:
            return
        config = self.store.require()
        runtime_ready = config.lifecycle == "connected" and not self._authority_offline
        if runtime_ready:
            runtime_reason = "ready"
        elif self._authority_offline:
            runtime_reason = "attachment_lease_expired"
        elif config.lifecycle == "attaching":
            runtime_reason = "initial_heartbeat"
        else:
            runtime_reason = f"lifecycle_{config.lifecycle}"[:128]
        last_error = next(reversed(self._last_errors.values()), None)
        snapshot: dict[str, Any] = {
            "runtime_ready": runtime_ready,
            "runtime_readiness_reason": runtime_reason,
            "command_safe": command_safe,
            "command_safety_reason": command_reason
            or ("ready" if command_safe else "not_ready"),
            "fabric_head_generation": head_generation,
            "degraded_operations": tuple(sorted(self._degraded_operations))[:8],
            "last_error": dict(last_error) if last_error is not None else None,
        }
        try:
            self.on_runtime_health(snapshot)
        except Exception as error:
            self.logger.record(
                "runtime_health_callback_failed",
                error_type=type(error).__name__,
                error=str(error)[:512],
            )

    def _mark_authority_offline(self, error: MeshiaNodeError, retry_in: float) -> None:
        self.store.update(lambda current: setattr(current, "lifecycle", "offline"))
        if not self._authority_offline:
            self._authority_offline = True
            heartbeat_age = max(0.0, self._now() - self._last_heartbeat_success)
            self.logger.record(
                "connection_offline",
                **self._error_fields(error, "heartbeat_lease"),
                lease_status="expired",
                lease_exhausted=True,
                attachment_lease_seconds=ATTACHMENT_LEASE_SECONDS,
                last_heartbeat_age_seconds=round(heartbeat_age, 3),
                retry_in_seconds=round(retry_in, 3),
            )

    def run(self, max_iterations: int | None = None) -> None:
        config = self.store.require()
        self._access = config.access if config.access in ACCESS_MODES else DEFAULT_ACCESS_MODE
        if self.on_access_mode is not None:
            self.on_access_mode(self._access)
        self._degraded_operations.clear()
        self._failure_streaks.clear()
        self._authority_offline = False
        self._rate_limit_recovery_pending = False
        self._last_errors.clear()
        self._maintenance_started = False
        self._heartbeat_worker_stop.clear()
        self._heartbeat_worker = None
        self._heartbeat_worker_generation = 0
        self._heartbeat_worker_consumed_generation = 0
        self._heartbeat_worker_result = None
        self._heartbeat_worker_next_due = float("inf")
        # A freshly attached process starts with a live server lease. A
        # transient heartbeat failure is degradation until that lease window is
        # actually exhausted; command-claim failures never invalidate it.
        self._last_heartbeat_success = self._now()
        self.logger.record(
            "connection_started",
            host_id=config.host_id,
            attachment_id=config.attachment_id,
            generation=config.generation,
            access=config.access,
        )
        next_heartbeat = 0.0
        next_metrics = 0.0
        next_command_poll = 0.0
        idle_poll = IDLE_POLL_SECONDS
        iterations = 0
        runtime_ready_published = False
        inactive_lease_recovery_attempted = False
        try:
            while not self._stop and (max_iterations is None or iterations < max_iterations):
                iterations += 1
                try:
                    # Clear only before polling both local and remote queues. An
                    # event arriving during either poll remains set and avoids
                    # the following idle wait.
                    self._wake_event.clear()
                    if self._stop:
                        break
                    if (self.store.require()).lifecycle == "disconnected":
                        raise Disconnected()
                    moment = self._now()
                    cooldown = self._host_rate_limit_remaining()
                    signed_blocked = cooldown > 0
                    signed_retry_deadline = moment + cooldown
                    if signed_blocked:
                        self._rate_limit_recovery_pending = True
                    recovery_probe_consumed = False
                    background_heartbeat_degraded, background_heartbeat_due = (
                        self._sync_independent_heartbeat()
                    )
                    if self._heartbeat_worker is not None:
                        next_heartbeat = background_heartbeat_due
                    heartbeat_degraded = bool(
                        "heartbeat" in self._degraded_operations
                        or background_heartbeat_degraded
                    )
                    if self._heartbeat_worker is not None and heartbeat_degraded:
                        signed_blocked = True
                        signed_retry_deadline = max(
                            signed_retry_deadline, next_heartbeat
                        )
                    if self._heartbeat_worker is None and moment >= next_heartbeat:
                        if signed_blocked:
                            next_heartbeat = max(
                                next_heartbeat, signed_retry_deadline
                            )
                        else:
                            try:
                                # The outer runner is the retry authority. Three
                                # nested 20-second attempts can burn most of the
                                # 90-second lease and create a burst during a fast
                                # 503; make one bounded request, then back off.
                                self._pulse()
                            except (NetworkError, RemoteError) as error:
                                retry_in = self._degrade(error, "heartbeat")
                                if isinstance(error, RemoteError) and error.status == 429:
                                    self._rate_limit_recovery_pending = True
                                now = self._now()
                                if (
                                    now - self._last_heartbeat_success
                                    >= ATTACHMENT_LEASE_SECONDS
                                ):
                                    self._mark_authority_offline(error, retry_in)
                                next_heartbeat = now + retry_in
                                signed_blocked = True
                                signed_retry_deadline = max(
                                    signed_retry_deadline, next_heartbeat
                                )
                                heartbeat_degraded = True
                            else:
                                self._last_heartbeat_success = self._now()
                                self._recover("heartbeat")
                                heartbeat_degraded = False
                                next_heartbeat = (
                                    self._now() + HEARTBEAT_INTERVAL_SECONDS
                                )
                                if not runtime_ready_published:
                                    # Publish liveness immediately after the
                                    # first successful lease renewal. Fabric
                                    # has not started its baseline/reconcile
                                    # yet, so command claims stay explicitly
                                    # parked behind startup_reconcile.
                                    startup_readiness = self._command_readiness()
                                    self._report_runtime_health(
                                        command_safe=False,
                                        command_reason="startup_reconcile",
                                        head_generation=startup_readiness[2],
                                    )
                                    runtime_ready_published = True
                                if self._rate_limit_recovery_pending:
                                    # The first eligible signed probe gets the
                                    # heartbeat lane. Yield before metrics,
                                    # Fabric control, or command traffic bursts.
                                    self._rate_limit_recovery_pending = False
                                    recovery_probe_consumed = True
                                    signed_blocked = True
                                    signed_retry_deadline = max(
                                        signed_retry_deadline,
                                        self._now()
                                        + RATE_LIMIT_RECOVERY_YIELD_SECONDS,
                                    )

                    # A heartbeat failure gates later signed work until the
                    # runner renews the lease. Local Fabric maintenance below is
                    # still polled so watcher/staging work can make progress.
                    now = self._now()
                    cooldown = self._host_rate_limit_remaining()
                    if cooldown > 0:
                        signed_blocked = True
                        signed_retry_deadline = max(
                            signed_retry_deadline, now + cooldown
                        )
                    if now >= next_metrics:
                        if signed_blocked or heartbeat_degraded:
                            next_metrics = max(
                                next_metrics,
                                signed_retry_deadline,
                                next_heartbeat if heartbeat_degraded else now,
                            )
                        else:
                            try:
                                post_metrics(
                                    self.client,
                                    self.store,
                                    self.sampler,
                                    self.traffic() if self.traffic else None,
                                )
                            except RemoteError as error:
                                if error.status == 429:
                                    retry_in = self._degrade(error, "metrics")
                                    self._rate_limit_recovery_pending = True
                                    next_metrics = self._now() + retry_in
                                    signed_blocked = True
                                    signed_retry_deadline = max(
                                        signed_retry_deadline, next_metrics
                                    )
                                else:
                                    self.logger.record(
                                        "metrics_deferred", error_code=error.code
                                    )
                                    next_metrics = (
                                        self._now() + METRICS_INTERVAL_SECONDS
                                    )
                            except MeshiaNodeError as error:
                                if isinstance(error, Disconnected):
                                    raise
                                self.logger.record(
                                    "metrics_deferred", error_code=error.code
                                )
                                next_metrics = self._now() + METRICS_INTERVAL_SECONDS
                            else:
                                self._recover("metrics")
                                next_metrics = self._now() + METRICS_INTERVAL_SECONDS
                                if self._rate_limit_recovery_pending:
                                    self._rate_limit_recovery_pending = False
                                    recovery_probe_consumed = True
                                    signed_blocked = True
                                    signed_retry_deadline = max(
                                        signed_retry_deadline,
                                        self._now()
                                        + RATE_LIMIT_RECOVERY_YIELD_SECONDS,
                                    )

                    # Reconcile before deciding whether the workspace is safe
                    # for a newly claimed command. Heartbeat, metrics, deferred
                    # completions, and maintenance remain live while the gate
                    # is closed.
                    if not recovery_probe_consumed:
                        try:
                            self._start_independent_heartbeat(next_heartbeat)
                            self._start_maintenance_once()
                            self._maintenance_poll_once()
                        except (NetworkError, RemoteError) as error:
                            retry_in = self._degrade(error, "fabric_poll")
                            if isinstance(error, RemoteError) and error.status == 429:
                                self._rate_limit_recovery_pending = True
                            signed_blocked = True
                            signed_retry_deadline = max(
                                signed_retry_deadline, self._now() + retry_in
                            )
                        else:
                            self._recover("fabric_poll")

                    background_heartbeat_degraded, background_heartbeat_due = (
                        self._sync_independent_heartbeat()
                    )
                    if self._heartbeat_worker is not None:
                        next_heartbeat = background_heartbeat_due
                    heartbeat_degraded = bool(
                        "heartbeat" in self._degraded_operations
                        or background_heartbeat_degraded
                    )
                    if self._heartbeat_worker is not None and heartbeat_degraded:
                        signed_blocked = True
                        signed_retry_deadline = max(
                            signed_retry_deadline, next_heartbeat
                        )

                    readiness = self._command_readiness()
                    ready_for_commands = self._report_command_readiness(readiness)
                    self._report_runtime_health(
                        command_safe=ready_for_commands,
                        command_reason=(
                            readiness[1]
                            if ready_for_commands or readiness[1] is not None
                            else "readiness_publication_deferred"
                        ),
                        head_generation=readiness[2],
                    )
                    now = self._now()
                    cooldown = self._host_rate_limit_remaining()
                    if cooldown > 0:
                        signed_blocked = True
                        signed_retry_deadline = max(
                            signed_retry_deadline, now + cooldown
                        )
                    # A local worker finishing is not a new claim. Reap its
                    # result promptly on this same serial lane, while keeping
                    # remote failure/cooldown deadlines authoritative. Merely
                    # waking for Fabric changes cannot accelerate claims.
                    completion_ready = (
                        bool(getattr(self.command_loop, "has_completed_command", False))
                        and not signed_blocked
                        and not heartbeat_degraded
                        and "command_poll" not in self._degraded_operations
                    )
                    if now >= next_command_poll or completion_ready:
                        if signed_blocked or heartbeat_degraded:
                            # Reap a completed local worker without claiming. Its
                            # outbox flush is guarded by the same SignedClient and
                            # therefore fails fast without sequence/network use.
                            has_active = getattr(
                                self.command_loop, "has_active_command", False
                            )
                            if bool(has_active):
                                poll_without_claim = getattr(
                                    self.command_loop, "poll_without_claim", None
                                )
                                if callable(poll_without_claim):
                                    poll_without_claim()
                            next_command_poll = max(
                                next_command_poll,
                                signed_retry_deadline,
                                next_heartbeat if heartbeat_degraded else now,
                            )
                            idle_poll = IDLE_POLL_SECONDS
                            claimed = False
                        else:
                            claim_ready = ready_for_commands or self._can_claim_account_commands(readiness)
                            claim_access_synchronized = claim_ready
                            claim_access_gate_acquired = False
                            try:
                                if (
                                    claim_ready
                                    and self._heartbeat_worker is not None
                                ):
                                    # Never wait behind heartbeat I/O on the
                                    # supervision lane. If a refresh is in
                                    # flight, park claims for this tick. Once
                                    # acquired, keep the gate through claim and
                                    # preparation so no newer access result can
                                    # race the executor's enforcement point.
                                    claim_access_gate_acquired = (
                                        self._heartbeat_access_gate.acquire(
                                            blocking=False
                                        )
                                    )
                                    claim_access_synchronized = (
                                        claim_access_gate_acquired
                                    )
                                    if claim_access_gate_acquired:
                                        (
                                            background_heartbeat_degraded,
                                            background_heartbeat_due,
                                        ) = self._sync_independent_heartbeat()
                                        next_heartbeat = background_heartbeat_due
                                        heartbeat_degraded = bool(
                                            "heartbeat"
                                            in self._degraded_operations
                                            or background_heartbeat_degraded
                                        )
                                        if heartbeat_degraded:
                                            claim_access_synchronized = False
                                            signed_blocked = True
                                            signed_retry_deadline = max(
                                                signed_retry_deadline,
                                                next_heartbeat,
                                            )
                                if claim_access_synchronized:
                                    claimed = bool(self.command_loop.poll_once())
                                else:
                                    # Existing work may finish while recovery closes
                                    # the claim gate. Reap and durably flush it, but
                                    # never make a second claim until the atomic
                                    # readiness snapshot turns true.
                                    poll_without_claim = getattr(
                                        self.command_loop, "poll_without_claim", None
                                    )
                                    claimed = (
                                        bool(poll_without_claim())
                                        if callable(poll_without_claim)
                                        else False
                                    )
                            except (NetworkError, RemoteError) as error:
                                # A claim can be an ambiguous mutation: never replay
                                # it. Keep its absolute deadline independent from
                                # Fabric watcher wakeups and heartbeat scheduling.
                                retry_in = self._degrade(error, "command_poll")
                                if isinstance(error, RemoteError) and error.status == 429:
                                    self._rate_limit_recovery_pending = True
                                next_command_poll = self._now() + retry_in
                                idle_poll = IDLE_POLL_SECONDS
                            else:
                                if claim_access_synchronized:
                                    self._recover("command_poll")
                                    if claimed:
                                        idle_poll = IDLE_POLL_SECONDS
                                        # Only live bounded app streams request
                                        # faster continuation. Ordinary command
                                        # fairness and rate cooldowns stay in
                                        # their existing lane/gates.
                                        active_poll = getattr(self.command_loop, "recommended_poll_seconds", ACTIVE_COMMAND_POLL_SECONDS)
                                        if type(active_poll) not in (int, float) or not 0.5 <= active_poll <= ACTIVE_COMMAND_POLL_SECONDS:
                                            active_poll = ACTIVE_COMMAND_POLL_SECONDS
                                        next_command_poll = (
                                            self._now() + active_poll
                                        )
                                    else:
                                        next_command_poll = self._now() + idle_poll
                                        idle_poll = min(
                                            idle_poll * 2, MAX_IDLE_POLL_SECONDS
                                        )
                                else:
                                    idle_poll = IDLE_POLL_SECONDS
                                    next_command_poll = (
                                        self._now() + COMMAND_READINESS_POLL_SECONDS
                                    )
                            finally:
                                if claim_access_gate_acquired:
                                    self._heartbeat_access_gate.release()
                    self._wait_for(
                        self._next_scheduled_wait(
                            next_command_poll=next_command_poll,
                            next_heartbeat=(
                                float("inf")
                                if self._heartbeat_worker is not None
                                else next_heartbeat
                            ),
                            next_metrics=next_metrics,
                        )
                    )
                    inactive_lease_recovery_attempted = False
                except Disconnected as error:
                    if (
                        error.reason_code != "ATTACHMENT_INACTIVE"
                        or inactive_lease_recovery_attempted
                        or self.store.require().lifecycle == "disconnected"
                    ):
                        raise
                    # A Mac can resume with an expired server lease before its
                    # monotonic heartbeat timer becomes due. A signed heartbeat
                    # renews only this still-active attachment and generation;
                    # a removed attachment or revoked host must still fail closed.
                    # Do not reattach or replay the rejected operation here.
                    inactive_lease_recovery_attempted = True
                    with self._heartbeat_access_gate:
                        self._sync_independent_heartbeat()
                        self._pulse()
                        self._last_heartbeat_success = self._now()
                        self._recover("heartbeat")
                        next_heartbeat = self._now() + HEARTBEAT_INTERVAL_SECONDS
                    self.logger.record("attachment_lease_recovered")
        finally:
            self._stop_independent_heartbeat()
            close_command_loop = getattr(self.command_loop, "close", None)
            if callable(close_command_loop):
                try:
                    close_command_loop()
                except Exception as error:  # pragma: no cover - defensive cleanup
                    self.logger.record(
                        "command_worker_close_failed",
                        error_type=type(error).__name__,
                    )

            def _park(current: NodeConfig) -> None:
                if current.lifecycle not in ("disconnected",):
                    current.lifecycle = "offline"

            try:
                self.store.update(_park)
            except MeshiaNodeError:  # pragma: no cover - config already erased
                pass
