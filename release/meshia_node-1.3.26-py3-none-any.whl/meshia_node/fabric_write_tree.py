"""Durable byte edits over an immutable Fabric file tree.

The journal owns changed data and index nodes. Unchanged objects remain in the
original CAS layout and are read through the caller's immutable source lease.
SQLite commits the new root with its objects, so reopening never mistakes a
sparse local inode for a complete file. Publication snapshots retain their root
while subsequent writes continue, and release reclaims superseded local bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import stat
import threading
import uuid
from pathlib import Path
from typing import Callable, Iterator
from urllib.parse import quote

from .fabric_contract_generated import (
    DataRange, FileTree, Node, decode_node, block_file_identity_bytes, parse_file_tree_descriptor,
    FABRIC_BASE_BLOCK_BYTES, FABRIC_FILE_TREE_ALGORITHM,
    FABRIC_FILE_TREE_PAGE_BYTES, FABRIC_V2_MAX_FILE_BYTES, FABRIC_CAS_PATH_PREFIX_BY_STORAGE_KIND,
)

_PAGE = FABRIC_FILE_TREE_PAGE_BYTES
_MAX_WRITE = FABRIC_BASE_BLOCK_BYTES
_SCHEMA = """
CREATE TABLE properties (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE objects (
  kind TEXT NOT NULL CHECK(kind IN ('data','node')),
  digest TEXT NOT NULL, size INTEGER NOT NULL, height INTEGER NOT NULL,
  data BLOB NOT NULL, page_hashes BLOB NOT NULL,
  refs INTEGER NOT NULL CHECK(refs >= 0),
  PRIMARY KEY(kind,digest), CHECK(length(data)=size),
  CHECK(length(page_hashes)=((size+4095)/4096)*32));
CREATE TABLE edges (
  parent TEXT NOT NULL, kind TEXT NOT NULL, digest TEXT NOT NULL,
  PRIMARY KEY(parent,kind,digest));
CREATE INDEX edge_child ON edges(kind,digest);
CREATE TABLE roots (
  name TEXT PRIMARY KEY, descriptor TEXT NOT NULL,
  kind TEXT, digest TEXT, height INTEGER NOT NULL);
"""


def _json(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _identity(ref):
    if ref is None:
        return None, None
    return ("node" if isinstance(ref, Node) else "data"), ref.sha256


def _validate_descriptor(descriptor):
    try:
        storage = descriptor.get("storage")
        if (not isinstance(storage, dict) or set(storage) != {"kind"}
                or not isinstance(storage["kind"], str)
                or storage["kind"] not in FABRIC_CAS_PATH_PREFIX_BY_STORAGE_KIND):
            raise ValueError("Invalid source object layout")
        if descriptor.get("file_digest_algorithm") == FABRIC_FILE_TREE_ALGORITHM:
            parse_file_tree_descriptor(descriptor)
        else:
            block_file_identity_bytes(descriptor)
    except (AttributeError, KeyError, TypeError, ValueError) as error:
        raise ValueError("The write journal source descriptor is invalid") from error


class FileTreeJournal:
    """One private, recoverable write session; no network or namespace authority.

    ``read_source`` must be bound to the original immutable file version and
    verify provider range receipts. The opaque ``identity`` binds recovery to
    the caller's workspace, path and write intent. It is never an access grant.
    """

    def __init__(self, path: Path, *, identity: str,
                 read_source: Callable[[str, str, int, int, int], bytes],
                 base: dict | None = None, create: bool = False):
        if not isinstance(identity, str) or not 1 <= len(identity.encode()) <= 4096:
            raise ValueError("The write journal identity is invalid")
        if base is not None:
            _validate_descriptor(base)
        self.path = Path(path)
        self._lock = threading.RLock()
        self._source = read_source
        self._db = None
        parent = self.path.parent.lstat()
        if (not stat.S_ISDIR(parent.st_mode) or stat.S_ISLNK(parent.st_mode)
                or (os.name != "nt" and (parent.st_mode & 0o077
                    or parent.st_uid != os.getuid()))):
            raise ValueError("The write journal requires a private owned directory")
        if create:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY
                         | getattr(os, "O_NOFOLLOW", 0), 0o600)
            os.close(fd)
        before = self.path.lstat()
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or (os.name != "nt" and (before.st_mode & 0o077
                    or before.st_uid != os.getuid()))):
            raise ValueError("The write journal is not a private regular file")
        try:
            self._db = sqlite3.connect("file:" + quote(str(self.path.absolute())) + "?mode=rw",
                                       uri=True, isolation_level=None, check_same_thread=False)
            after = self.path.lstat()
            if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
                raise ValueError("The write journal changed while opening")
            self._db.execute("PRAGMA trusted_schema=OFF")
            if not create:
                stored = dict(self._db.execute("SELECT key,value FROM properties WHERE key IN ('identity','schema')"))
                if stored.get("identity") != identity:
                    raise ValueError("The write journal belongs to another write intent")
                if stored.get("schema") != "1":
                    raise ValueError("The write journal schema is invalid")
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=FULL")
            self._db.execute("PRAGMA temp_store=FILE")
            self._db.execute("PRAGMA cache_size=-2048")
            if create:
                self._db.executescript(_SCHEMA)
                self._db.execute("BEGIN IMMEDIATE")
                try:
                    self._db.execute("INSERT INTO properties VALUES ('identity',?)", (identity,))
                    self._db.execute("INSERT INTO properties VALUES ('schema','1')")
                    original = (FileTree(0, None, **self._adapters()).descriptor()
                                if base is None else base)
                    self._storage = original["storage"]["kind"]
                    self._db.execute("INSERT INTO properties VALUES ('storage',?)", (self._storage,))
                    self._db.execute("INSERT INTO properties VALUES ('source',?)", (_json(original),))
                    if original.get("file_digest_algorithm") == FABRIC_FILE_TREE_ALGORITHM:
                        tree = FileTree.from_descriptor(original, **self._adapters())
                    else:
                        tree = FileTree.from_blocks(original, **self._adapters())
                    self._replace_root("base", tree)
                    self._replace_root("current", tree)
                    self._collect_unused()
                    self._db.execute("COMMIT")
                except BaseException:
                    self._rollback()
                    raise
            stored = self._db.execute("SELECT value FROM properties WHERE key='identity'").fetchone()
            if stored != (identity,):
                raise ValueError("The write journal belongs to another write intent")
            self._storage = self._db.execute("SELECT value FROM properties WHERE key='storage'").fetchone()[0]
            # Keep the original wire descriptor as well as the converted tree.
            # A flat-file source has a different digest from its tree index;
            # recovery must renew the original version's authority.
            source_descriptor = self.source_descriptor()
            if base is not None and source_descriptor != base:
                raise ValueError("The write journal has a different immutable source")
            self._tree("current")
            if create and os.name != "nt":
                # FULL protects the transaction; the directory entry also has
                # to survive a crash before a caller can acknowledge creation.
                parent_fd = os.open(self.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
                try:
                    os.fsync(parent_fd)
                finally:
                    os.close(parent_fd)
        except BaseException:
            self.close()
            raise

    def close(self) -> None:
        with self._lock:
            if self._db is not None:
                self._db.close()
                self._db = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _adapters(self):
        return dict(load_node=lambda digest, size: self._read_object("node", digest, size, 0, size),
                    read_object=lambda digest, size, start, count: self._read_object("data", digest, size, start, count),
                    put_object=self._put)

    def _rollback(self):
        # SQLite can already have rolled back after an IO or full-disk error.
        # Preserve that original failure instead of masking it with a second
        # "no transaction is active" exception.
        if self._db.in_transaction:
            self._db.execute("ROLLBACK")

    def _read_object(self, kind, digest, size, offset, count):
        row = self._db.execute("SELECT rowid,size FROM objects WHERE kind=? AND digest=?", (kind, digest)).fetchone()
        if row is not None:
            if row[1] != size or not 0 <= offset <= offset + count <= size:
                raise ValueError("The local write journal object failed verification")
            if not count:
                return b""
            # Incremental BLOB IO reads only the touched pages. SELECT data
            # would hydrate and hash a whole 4 MiB object for every tiny dirty
            # read, losing the demand-paging benefit inside the local journal.
            low = offset // _PAGE * _PAGE
            high = min(size, (offset + count + _PAGE - 1) // _PAGE * _PAGE)
            with self._db.blobopen("objects", "data", row[0], readonly=True) as blob:
                blob.seek(low)
                data = blob.read(high - low)
            if len(data) != high - low:
                raise ValueError("The local write journal object was truncated")
            if low == 0 and high == size:
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError("The local write journal object failed verification")
            else:
                pages = (len(data) + _PAGE - 1) // _PAGE
                with self._db.blobopen("objects", "page_hashes", row[0], readonly=True) as blob:
                    blob.seek(low // _PAGE * 32)
                    hashes = blob.read(pages * 32)
                if len(hashes) != pages * 32 or any(
                    hashlib.sha256(data[at:at + _PAGE]).digest() != hashes[index * 32:(index + 1) * 32]
                    for index, at in enumerate(range(0, len(data), _PAGE))
                ):
                    raise ValueError("The local write journal page failed verification")
            return data[offset - low:offset - low + count]
        data = self._source(kind, digest, size, offset, count)
        if not isinstance(data, bytes) or len(data) != count:
            raise ValueError("The immutable write source returned an invalid range")
        return data

    def _put(self, kind, data):
        if kind not in {"data", "node"} or not isinstance(data, bytes):
            raise ValueError("Invalid write journal object")
        if not 0 < len(data) <= (_PAGE if kind == "node" else _MAX_WRITE):
            raise ValueError("The write journal object exceeds its byte bound")
        height = data[4] if kind == "node" and len(data) > 4 else 0
        children = decode_node(data, height) if kind == "node" else ()
        digest = hashlib.sha256(data).hexdigest()
        previous = self._db.execute("SELECT size,data FROM objects WHERE kind=? AND digest=?", (kind, digest)).fetchone()
        if previous is not None:
            if previous != (len(data), data):
                raise ValueError("Conflicting immutable write journal object")
            return digest
        refs = self._db.execute("SELECT (SELECT count(*) FROM edges WHERE kind=? AND digest=?) + "
                                "(SELECT count(*) FROM roots WHERE kind=? AND digest=?)",
                                (kind, digest, kind, digest)).fetchone()[0]
        view = memoryview(data)
        page_hashes = b"".join(hashlib.sha256(view[at:at + _PAGE]).digest()
                               for at in range(0, len(data), _PAGE))
        self._db.execute("INSERT INTO objects VALUES (?,?,?,?,?,?,?)",
                         (kind, digest, len(data), height, data, page_hashes, refs))
        for child_kind, child_digest in {_identity(child) for child in children if child is not None}:
            self._db.execute("INSERT INTO edges VALUES (?,?,?)", (digest, child_kind, child_digest))
            self._db.execute("UPDATE objects SET refs=refs+1 WHERE kind=? AND digest=?", (child_kind, child_digest))
        return digest

    def _tree(self, name):
        row = self._db.execute("SELECT descriptor,kind,digest,height FROM roots WHERE name=?", (name,)).fetchone()
        if row is None:
            raise ValueError("The write journal snapshot is unavailable")
        descriptor = json.loads(row[0])
        tree = FileTree.from_descriptor(descriptor, **self._adapters())
        if descriptor["storage"]["kind"] != self._storage or (*_identity(tree.root), tree.height) != row[1:]:
            raise ValueError("The write journal root changed identity")
        return tree

    def _replace_root(self, name, tree):
        old = self._db.execute("SELECT kind,digest FROM roots WHERE name=?", (name,)).fetchone()
        kind, digest = _identity(tree.root)
        self._db.execute("INSERT INTO roots VALUES (?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET "
                         "descriptor=excluded.descriptor,kind=excluded.kind,digest=excluded.digest,height=excluded.height",
                         (name, _json(tree.descriptor(self._storage)), kind, digest, tree.height))
        if old is not None:
            self._db.execute("UPDATE objects SET refs=refs-1 WHERE kind=? AND digest=?", old)
        self._db.execute("UPDATE objects SET refs=refs+1 WHERE kind=? AND digest=?", (kind, digest))

    def _collect_unused(self):
        while True:
            rows = self._db.execute("SELECT kind,digest FROM objects WHERE refs=0 LIMIT 64").fetchall()
            if not rows:
                return
            for kind, digest in rows:
                if kind == "node":
                    for child in self._db.execute("SELECT kind,digest FROM edges WHERE parent=?", (digest,)).fetchall():
                        self._db.execute("UPDATE objects SET refs=refs-1 WHERE kind=? AND digest=?", child)
                    self._db.execute("DELETE FROM edges WHERE parent=?", (digest,))
                self._db.execute("DELETE FROM objects WHERE kind=? AND digest=? AND refs=0", (kind, digest))

    def _change(self, transform):
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                tree = transform(self._tree("current"))
                self._replace_root("current", tree)
                self._collect_unused()
                self._db.execute("COMMIT")
            except BaseException:
                self._rollback()
                raise

    def descriptor(self, snapshot="current") -> dict:
        with self._lock:
            return self._tree(snapshot).descriptor(self._storage)

    def source_descriptor(self) -> dict:
        with self._lock:
            row = self._db.execute("SELECT value FROM properties WHERE key='source'").fetchone()
            if row is None:
                raise ValueError("The write journal lost its immutable source")
            descriptor = json.loads(row[0])
            _validate_descriptor(descriptor)
            if descriptor["storage"]["kind"] != self._storage:
                raise ValueError("The write journal source changed object layout")
            return descriptor

    def read(self, offset: int, count: int, *, snapshot="current") -> bytes:
        with self._lock:
            # Recovery/publication can open a second connection. Pin this SQL
            # read version so its root and object bytes cannot straddle a
            # concurrent root replacement and garbage collection.
            self._db.execute("BEGIN")
            try:
                return self._tree(snapshot).read(offset, count)
            finally:
                self._rollback()

    def write(self, offset: int, data: bytes) -> int:
        if (type(offset) is not int or offset < 0 or not isinstance(data, bytes)
                or len(data) > _MAX_WRITE or offset + len(data) > FABRIC_V2_MAX_FILE_BYTES):
            raise ValueError("The write requires a bounded file range")
        if not data:
            return 0
        def edit(tree):
            end = offset + len(data)
            tree = tree.truncate(max(tree.size, end))
            low = offset // _PAGE * _PAGE
            high = min(tree.size, (end + _PAGE - 1) // _PAGE * _PAGE)
            if low < offset and end < high and high - low <= _PAGE:
                # One small edit needs both sides of the same page. Fetch
                # that page once instead of paying two serialized source
                # requests to avoid downloading a few overwritten bytes.
                previous = tree.read(low, high - low)
                content = previous[:offset - low] + data + previous[end - low:]
            else:
                content = tree.read(low, offset - low) + data + tree.read(end, high - end)
            for at in range(0, len(content), _MAX_WRITE):
                part = content[at:at + _MAX_WRITE]
                digest = self._put("data", part)
                tree = tree.replace_pages(low + at, DataRange(digest, len(part), 0, len(part)))
            return tree
        self._change(edit)
        return len(data)

    def truncate(self, size: int) -> None:
        if type(size) is not int or not 0 <= size <= FABRIC_V2_MAX_FILE_BYTES:
            raise ValueError("The truncate size is invalid")
        self._change(lambda tree: tree.truncate(size))

    def retain(self) -> str:
        name = "snapshot:" + uuid.uuid4().hex
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                self._replace_root(name, self._tree("current"))
                self._db.execute("COMMIT")
            except BaseException:
                self._rollback()
                raise
        return name

    def release(self, snapshot: str) -> None:
        if not isinstance(snapshot, str) or not snapshot.startswith("snapshot:"):
            raise ValueError("Only retained write snapshots can be released")
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                row = self._db.execute("DELETE FROM roots WHERE name=? RETURNING kind,digest", (snapshot,)).fetchone()
                if row is None:
                    raise ValueError("The write journal snapshot is unavailable")
                self._db.execute("UPDATE objects SET refs=refs-1 WHERE kind=? AND digest=?", row)
                self._collect_unused()
                self._db.execute("COMMIT")
            except BaseException:
                self._rollback()
                raise

    def objects(self, snapshot: str) -> Iterator[tuple[str, str, bytes]]:
        """Yield exact retained-snapshot objects in child-before-parent order.

        The recursive query spills metadata to SQLite's bounded disk-backed
        temporary store. Payload is fetched one object at a time, never sorted
        or accumulated with the full reachability result.
        """
        if not isinstance(snapshot, str) or not snapshot.startswith("snapshot:"):
            raise ValueError("Publication requires a retained write snapshot")
        with self._lock:
            tree = self._tree(snapshot)
            cursor = self._db.execute("""WITH RECURSIVE reachable(kind,digest) AS (
                SELECT ?,? UNION SELECT edge.kind,edge.digest FROM reachable r
                JOIN edges edge ON r.kind='node' AND edge.parent=r.digest)
                SELECT o.kind,o.digest,o.size FROM reachable r JOIN objects o
                ON o.kind=r.kind AND o.digest=r.digest ORDER BY o.height,o.digest""", _identity(tree.root))
        try:
            while True:
                with self._lock:
                    self._tree(snapshot)  # A released capture may not keep reading.
                    row = cursor.fetchone()
                    if row is None:
                        return
                    kind, digest, size = row
                    data = self._read_object(kind, digest, size, 0, size)
                yield kind, digest, data
        finally:
            with self._lock:
                if self._db is not None:
                    cursor.close()

    def local_bytes(self) -> int:
        """Live object payload bytes; excludes SQLite and page-hash overhead."""
        with self._lock:
            return self._db.execute("SELECT coalesce(sum(size),0) FROM objects").fetchone()[0]
