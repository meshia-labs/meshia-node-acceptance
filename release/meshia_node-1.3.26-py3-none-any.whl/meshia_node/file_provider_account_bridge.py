"""Account-wide native File Provider facade over lazy workspace runtimes.

One macOS File Provider domain named ``Meshia`` represents the complete signed
workspace catalog.  Root enumeration is metadata-only and never activates a
workspace.  Every item below a workspace carries an opaque workspace routing
token plus the workspace bridge's durable opaque item id; no path is accepted
as routing authority.

The account bridge deliberately reuses ``FabricFileProviderBridge`` as the
per-workspace protocol implementation.  A request is proxied through a private
socketpair while ``WorkspaceRuntimeManager`` pins that exact runtime, allowing
the account layer to translate identifiers without weakening the existing
streaming, conflict, descriptor, and mutation-readiness contracts.
"""

from __future__ import annotations

import array
import errno
import hashlib
import json
import os
import secrets
import socket
import stat
import struct
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from .errors import InvalidTask, StateError, UnsafePath
from .fabric_mount import tune_interpreter_for_mount_callbacks
from .file_provider_bridge import (
    BRIDGE_SCHEMA,
    MAX_CONNECTIONS,
    MAX_RESPONSE_METADATA_BYTES,
    STREAM_CHUNK_BYTES,
    FabricFileProviderBridge,
    FileProviderBridgeAddress,
    FileProviderBridgeError,
    FileProviderConflict,
    _fit_enumeration_response,
    _receive_exact,
    _receive_file_descriptor,
    _receive_json_frame,
    _send_json_frame,
)
from .log import NULL_LOGGER, NodeLogger
from .util import ensure_private_dir, write_private_file
from .workspace_runtime import (
    FileProviderCatalogProjection,
    FileProviderWorkspaceProjection,
    WorkspaceRuntime,
    WorkspaceRuntimeManager,
)

_WORKSPACE_IDENTIFIER_PREFIX = "item-workspace-"
_NESTED_IDENTIFIER_PREFIX = "item-route-"
_MUTATION_OPERATIONS = frozenset(
    {"write", "write_fd", "create_directory", "delete", "move"}
)
_IDENTIFIER_FIELDS = (
    "identifier",
    "container_identifier",
    "parent_identifier",
    "destination_parent_identifier",
    "replaces_identifier",
)


@dataclass(frozen=True)
class _ResolvedIdentifier:
    session_id: str | None
    inner_identifier: str
    is_workspace_root: bool = False


WorkspaceBridgeFactory = Callable[
    [WorkspaceRuntime, str, FileProviderBridgeAddress], FabricFileProviderBridge
]


class AccountFileProviderBridge:
    """Same-user Unix socket facade for one complete account catalog."""

    account_wide = True

    def __init__(
        self,
        runtime_manager: WorkspaceRuntimeManager,
        address: FileProviderBridgeAddress,
        *,
        workspace_bridge_factory: WorkspaceBridgeFactory | None = None,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        if not runtime_manager.file_provider_account_wide:
            raise ValueError("runtime_manager must provide an account-wide catalog")
        if address.socket_path.parent != address.token_path.parent:
            raise ValueError(
                "the File Provider socket and token must share one directory"
            )
        self.runtime_manager = runtime_manager
        self.address = address
        self.logger = logger
        self._workspace_bridge_factory = (
            workspace_bridge_factory or self._default_workspace_bridge
        )
        self._listener: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stopped = threading.Event()
        self._connections = threading.BoundedSemaphore(MAX_CONNECTIONS)
        self._token = ""
        self._socket_identity: tuple[int, int] | None = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        if not hasattr(socket, "AF_UNIX"):
            raise FileProviderBridgeError("Unix sockets are unavailable")
        root = ensure_private_dir(self.address.socket_path.parent)
        self._token = self._load_or_create_token()
        self._remove_stale_socket(root)
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            listener.bind(str(self.address.socket_path))
            os.chmod(self.address.socket_path, 0o600)
            info = self.address.socket_path.lstat()
            self._socket_identity = (info.st_dev, info.st_ino)
            listener.listen(MAX_CONNECTIONS)
            listener.settimeout(0.5)
        except BaseException:
            listener.close()
            raise
        self._listener = listener
        self._stopped.clear()
        applied_interval = tune_interpreter_for_mount_callbacks()
        if applied_interval is not None:
            self.logger.record(
                "file_provider_bridge_gil_interval_tuned",
                interval=applied_interval,
            )
        self._thread = threading.Thread(
            target=self._serve,
            name="meshia-account-file-provider-bridge",
            daemon=True,
        )
        self._thread.start()
        self.logger.record(
            "file_provider_account_bridge_started",
            socket_path=str(self.address.socket_path),
        )

    def close(self) -> None:
        self._stopped.set()
        listener, self._listener = self._listener, None
        if listener is not None:
            listener.close()
        thread, self._thread = self._thread, None
        if thread is not None:
            thread.join(timeout=2.0)
        try:
            info = self.address.socket_path.lstat()
            identity = self._socket_identity
            if (
                identity is not None
                and stat.S_ISSOCK(info.st_mode)
                and info.st_uid == os.getuid()
                and (info.st_dev, info.st_ino) == identity
            ):
                self.address.socket_path.unlink()
        except (FileNotFoundError, OSError):
            pass
        self._socket_identity = None

    def _load_or_create_token(self) -> str:
        path = self.address.token_path
        try:
            info = path.lstat()
            token = path.read_text(encoding="ascii").strip()
            if (
                not stat.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or info.st_uid != os.getuid()
                or info.st_mode & 0o077
                or len(token) != 64
                or any(character not in "0123456789abcdef" for character in token)
            ):
                raise FileProviderBridgeError("the File Provider token is unsafe")
            return token
        except FileNotFoundError:
            token = secrets.token_hex(32)
            write_private_file(path, (token + "\n").encode("ascii"))
            return token

    def _remove_stale_socket(self, root: Path) -> None:
        path = self.address.socket_path
        try:
            info = path.lstat()
        except FileNotFoundError:
            return
        if (
            path.parent.resolve(strict=True) != root.resolve(strict=True)
            or not stat.S_ISSOCK(info.st_mode)
            or info.st_uid != os.getuid()
        ):
            raise FileProviderBridgeError("the File Provider socket path is unsafe")
        probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            probe.settimeout(0.25)
            probe.connect(str(path))
        except (ConnectionRefusedError, FileNotFoundError):
            pass
        except OSError as error:
            raise FileProviderBridgeError(
                "the existing File Provider socket could not be verified"
            ) from error
        else:
            raise FileProviderBridgeError("the File Provider bridge is already active")
        finally:
            probe.close()
        path.unlink()

    def _serve(self) -> None:
        while not self._stopped.is_set():
            listener = self._listener
            if listener is None:
                return
            try:
                connection, _address = listener.accept()
            except TimeoutError:
                continue
            except OSError:
                if self._stopped.is_set():
                    return
                continue
            if not self._connections.acquire(blocking=False):
                connection.close()
                continue
            threading.Thread(
                target=self._handle_connection,
                args=(connection,),
                name="meshia-account-file-provider-request",
                daemon=True,
            ).start()

    def _handle_connection(self, connection: socket.socket) -> None:
        try:
            connection.settimeout(120.0)
            FabricFileProviderBridge._require_same_user(connection)
            request = _receive_json_frame(connection)
            if not secrets.compare_digest(str(request.get("token", "")), self._token):
                raise FileProviderBridgeError("authentication failed")
            self.dispatch(connection, request)
        except (
            FileProviderBridgeError,
            InvalidTask,
            StateError,
            UnsafePath,
            ValueError,
        ) as error:
            self._safe_error(connection, error)
        except OSError as error:
            if error.errno not in {errno.EPIPE, errno.ECONNRESET, errno.EBADF}:
                self._safe_error(connection, error)
        except json.JSONDecodeError:
            pass
        finally:
            connection.close()
            self._connections.release()

    def dispatch(self, connection: socket.socket, request: Mapping[str, Any]) -> None:
        """Dispatch one authenticated request; public for focused protocol tests."""

        operation = request.get("operation")
        if not isinstance(operation, str):
            raise FileProviderBridgeError("the File Provider operation is invalid")
        projection = self.runtime_manager.file_provider_catalog_projection()
        if operation == "status":
            container_identifier = request.get("container_identifier")
            if container_identifier in (None, "root"):
                _send_json_frame(
                    connection,
                    self._account_status_document(projection),
                )
                return
        if operation == "enumerate" and self._is_account_root_request(
            projection, request
        ):
            self._enumerate_root(connection, request, projection)
            return
        if operation == "resolve":
            resolved = self._resolve_identifier(projection, request.get("identifier"))
            if resolved.session_id is None:
                _send_json_frame(
                    connection,
                    {"schema": BRIDGE_SCHEMA, "ok": True, "item": self._root_item()},
                )
                return
            if resolved.is_workspace_root:
                workspace = self._workspace_by_session(projection, resolved.session_id)
                _send_json_frame(
                    connection,
                    {
                        "schema": BRIDGE_SCHEMA,
                        "ok": True,
                        "item": self._workspace_item(projection, workspace),
                    },
                )
                return
        if operation == "move":
            source = self._resolve_identifier(projection, request.get("identifier"))
            if source.is_workspace_root:
                self._rename_workspace_root(connection, request, projection, source)
                return

        session_id = self._request_session(projection, request)
        require_mutation_ready = operation in _MUTATION_OPERATIONS
        self.runtime_manager.run_file_provider_operation(
            session_id,
            lambda runtime, current: self._dispatch_workspace(
                connection, request, projection.account_id, runtime, current
            ),
            require_mutation_ready=require_mutation_ready,
        )

    @staticmethod
    def _is_account_root_request(
        projection: FileProviderCatalogProjection,
        request: Mapping[str, Any],
    ) -> bool:
        identifier = request.get("container_identifier")
        if identifier is None:
            return request.get("container", "") == ""
        resolved = AccountFileProviderBridge._resolve_identifier(
            projection, identifier
        )
        return resolved.session_id is None

    def _enumerate_root(
        self,
        connection: socket.socket,
        request: Mapping[str, Any],
        projection: FileProviderCatalogProjection,
    ) -> None:
        generation = request.get("generation")
        if generation is not None and generation != projection.generation:
            raise FileProviderConflict(
                "the File Provider catalog enumeration generation advanced"
            )
        limit = request.get("limit", 200)
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 999:
            raise FileProviderBridgeError("limit must be between 1 and 999")
        after = request.get("after_name")
        if after is not None and not isinstance(after, str):
            raise FileProviderBridgeError("after_name must be a string or null")
        candidates = tuple(
            item
            for item in projection.workspaces
            if after is None or (item.name.casefold(), item.name) > (after.casefold(), after)
        )
        page = candidates[:limit]
        has_more = len(candidates) > limit
        _send_json_frame(
            connection,
            _fit_enumeration_response(
                {
                    "schema": BRIDGE_SCHEMA,
                    "ok": True,
                    "items": [
                        self._workspace_item(projection, item) for item in page
                    ],
                    "next_after_name": page[-1].name if has_more and page else None,
                    "has_more": has_more,
                    "generation": projection.generation,
                    "manifest_digest": self._catalog_digest(projection),
                },
            ),
        )

    def _rename_workspace_root(
        self,
        connection: socket.socket,
        request: Mapping[str, Any],
        projection: FileProviderCatalogProjection,
        source: _ResolvedIdentifier,
    ) -> None:
        destination = self._resolve_identifier(
            projection, request.get("destination_parent_identifier")
        )
        if destination.session_id is not None:
            raise FileProviderBridgeError(
                "a workspace can only be renamed at the Meshia root"
            )
        filename = request.get("filename")
        if not isinstance(filename, str):
            raise FileProviderBridgeError("filename must be one portable path component")
        assert source.session_id is not None
        current = self._workspace_by_session(projection, source.session_id)
        self.runtime_manager.rename_workspace_root(
            source.session_id, current.name, filename
        )
        updated_projection = self.runtime_manager.file_provider_catalog_projection()
        updated = self._workspace_by_session(updated_projection, source.session_id)
        _send_json_frame(
            connection,
            {
                "schema": BRIDGE_SCHEMA,
                "ok": True,
                "item": self._workspace_item(updated_projection, updated),
                "mutation_id": None,
                "queued": False,
            },
        )

    def _request_session(
        self,
        projection: FileProviderCatalogProjection,
        request: Mapping[str, Any],
    ) -> str:
        routed: list[_ResolvedIdentifier] = []
        for field in _IDENTIFIER_FIELDS:
            value = request.get(field)
            if value is not None:
                routed.append(self._resolve_identifier(projection, value))
        sessions = {item.session_id for item in routed if item.session_id is not None}
        if len(sessions) != 1:
            if len(sessions) > 1:
                raise FileProviderBridgeError(
                    "cross-workspace File Provider mutations are unsupported"
                )
            raise FileProviderBridgeError(
                "the File Provider request has no workspace identifier"
            )
        session_id = next(iter(sessions))
        if any(
            item.session_id is None
            for item in routed
            if request.get("operation") != "enumerate"
        ):
            raise FileProviderBridgeError(
                "the Meshia root cannot be used as a workspace item parent"
            )
        assert session_id is not None
        return session_id

    def _dispatch_workspace(
        self,
        connection: socket.socket,
        request: Mapping[str, Any],
        account_id: str,
        runtime: WorkspaceRuntime,
        current: FileProviderWorkspaceProjection,
    ) -> None:
        stable_name = "workspace-" + self._route_token(account_id, current.session_id)[:24]
        bridge = self._workspace_bridge_factory(runtime, stable_name, self.address)
        try:
            inner_root = bridge._workspace_item()["identifier"]
            routed_request = dict(request)
            routed_request.pop("token", None)
            for field in _IDENTIFIER_FIELDS:
                value = routed_request.get(field)
                if value is None:
                    continue
                resolved = self._resolve_identifier(
                    self.runtime_manager.file_provider_catalog_projection(), value
                )
                if resolved.session_id != current.session_id:
                    raise FileProviderBridgeError(
                        "the File Provider identifier belongs to another workspace"
                    )
                routed_request[field] = (
                    inner_root if resolved.is_workspace_root else resolved.inner_identifier
                )
            for field in ("path", "container", "replaces_path"):
                if field in routed_request and routed_request[field] not in (None, ""):
                    raise FileProviderBridgeError(
                        "path-based File Provider routing is unsupported"
                    )
            self._proxy_workspace_request(
                connection,
                routed_request,
                bridge,
                account_id,
                current,
                inner_root,
            )
        finally:
            bridge.close()

    def _proxy_workspace_request(
        self,
        connection: socket.socket,
        request: Mapping[str, Any],
        bridge: FabricFileProviderBridge,
        account_id: str,
        current: FileProviderWorkspaceProjection,
        inner_root: str,
    ) -> None:
        worker_end, router_end = socket.socketpair()

        def run() -> None:
            try:
                bridge._dispatch(worker_end, request)
            except (
                FileProviderBridgeError,
                InvalidTask,
                StateError,
                UnsafePath,
                ValueError,
            ) as error:
                self._safe_error(worker_end, error)
            except BaseException:
                self._safe_error(
                    worker_end,
                    FileProviderBridgeError(
                        "the File Provider workspace request failed"
                    ),
                )
            finally:
                worker_end.close()

        worker = threading.Thread(
            target=run,
            name="meshia-file-provider-workspace-request",
            daemon=True,
        )
        worker.start()
        try:
            operation = request.get("operation")
            if operation == "write":
                payload_bytes = request.get("payload_bytes")
                if isinstance(payload_bytes, bool) or not isinstance(payload_bytes, int):
                    raise FileProviderBridgeError("payload_bytes is invalid")
                self._relay_exact(connection, router_end, payload_bytes)
            elif operation == "write_fd":
                descriptor = _receive_file_descriptor(connection)
                try:
                    rights = array.array("i", [descriptor])
                    sent = router_end.sendmsg(
                        [b"F"], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, rights)]
                    )
                    if sent != 1:
                        raise FileProviderBridgeError(
                            "the File Provider descriptor relay ended early"
                        )
                finally:
                    os.close(descriptor)

            response = self._receive_response_frame(router_end)
            rewritten = self._rewrite_response(
                response, account_id, current, inner_root
            )
            if isinstance(rewritten.get("items"), list):
                rewritten = _fit_enumeration_response(rewritten)
            _send_json_frame(connection, rewritten)
            payload_bytes = response.get("payload_bytes", 0)
            if isinstance(payload_bytes, int) and payload_bytes > 0:
                self._relay_exact(router_end, connection, payload_bytes)
        finally:
            router_end.close()
            worker.join(timeout=2.0)
        if worker.is_alive():
            raise FileProviderBridgeError(
                "the File Provider workspace request did not finish"
            )

    @staticmethod
    def _receive_response_frame(connection: socket.socket) -> Mapping[str, Any]:
        length = struct.unpack(">I", _receive_exact(connection, 4))[0]
        if not 2 <= length <= MAX_RESPONSE_METADATA_BYTES:
            raise FileProviderBridgeError(
                "the File Provider workspace response is too large"
            )
        value = json.loads(_receive_exact(connection, length).decode("utf-8"))
        if not isinstance(value, Mapping):
            raise FileProviderBridgeError(
                "the File Provider workspace response is not an object"
            )
        return value

    @staticmethod
    def _relay_exact(source: socket.socket, destination: socket.socket, size: int) -> None:
        if size < 0:
            raise FileProviderBridgeError("the File Provider payload size is invalid")
        remaining = size
        while remaining:
            chunk = source.recv(min(STREAM_CHUNK_BYTES, remaining))
            if not chunk:
                raise FileProviderBridgeError(
                    "the File Provider payload ended early"
                )
            destination.sendall(chunk)
            remaining -= len(chunk)

    def _rewrite_response(
        self,
        response: Mapping[str, Any],
        account_id: str,
        workspace: FileProviderWorkspaceProjection,
        inner_root: str,
    ) -> dict[str, Any]:
        result = dict(response)
        if isinstance(result.get("item"), Mapping):
            result["item"] = self._rewrite_item(
                result["item"], account_id, workspace, inner_root
            )
        if isinstance(result.get("items"), list):
            result["items"] = [
                self._rewrite_item(item, account_id, workspace, inner_root)
                if isinstance(item, Mapping)
                else item
                for item in result["items"]
            ]
        deleted = result.get("deleted_identifier")
        if isinstance(deleted, str):
            result["deleted_identifier"] = self._public_identifier(
                account_id, workspace.session_id, deleted, inner_root
            )
        return result

    def _rewrite_item(
        self,
        item: Mapping[str, Any],
        account_id: str,
        workspace: FileProviderWorkspaceProjection,
        inner_root: str,
    ) -> dict[str, Any]:
        value = dict(item)
        identifier = value.get("identifier")
        parent = value.get("parent_identifier")
        if not isinstance(identifier, str):
            raise FileProviderBridgeError("the workspace item identifier is invalid")
        value["identifier"] = self._public_identifier(
            account_id, workspace.session_id, identifier, inner_root
        )
        if isinstance(parent, str):
            value["parent_identifier"] = self._public_identifier(
                account_id, workspace.session_id, parent, inner_root
            )
        path = value.get("path")
        if isinstance(path, str):
            _prefix, separator, tail = path.partition("/")
            value["path"] = workspace.name + (separator + tail if separator else "")
        return value

    @classmethod
    def _public_identifier(
        cls,
        account_id: str,
        session_id: str,
        inner_identifier: str,
        inner_root: str,
    ) -> str:
        token = cls._route_token(account_id, session_id)
        if inner_identifier == inner_root:
            return _WORKSPACE_IDENTIFIER_PREFIX + token
        if not inner_identifier.startswith("item-"):
            raise FileProviderBridgeError("the workspace returned an invalid item id")
        return _NESTED_IDENTIFIER_PREFIX + token + "-" + inner_identifier[5:]

    @classmethod
    def _resolve_identifier(
        cls,
        projection: FileProviderCatalogProjection,
        value: object,
    ) -> _ResolvedIdentifier:
        if value == "root":
            return _ResolvedIdentifier(None, "root")
        if not isinstance(value, str) or len(value) > 128:
            raise FileProviderBridgeError("the File Provider identifier is invalid")
        routes = {
            cls._route_token(projection.account_id, item.session_id): item.session_id
            for item in projection.workspaces
        }
        if value.startswith(_WORKSPACE_IDENTIFIER_PREFIX):
            token = value[len(_WORKSPACE_IDENTIFIER_PREFIX) :]
            session_id = routes.get(token)
            if session_id is None:
                raise FileProviderBridgeError(
                    "the File Provider workspace no longer exists"
                )
            return _ResolvedIdentifier(session_id, "", True)
        if value.startswith(_NESTED_IDENTIFIER_PREFIX):
            tail = value[len(_NESTED_IDENTIFIER_PREFIX) :]
            token, separator, inner = tail.partition("-")
            session_id = routes.get(token)
            if not separator or session_id is None or not inner:
                raise FileProviderBridgeError(
                    "the File Provider routed item is invalid"
                )
            return _ResolvedIdentifier(session_id, "item-" + inner)
        raise FileProviderBridgeError("the File Provider identifier is invalid")

    @staticmethod
    def _route_token(account_id: str, session_id: str) -> str:
        return hashlib.sha256(
            account_id.encode("utf-8") + b"\0" + session_id.encode("utf-8")
        ).hexdigest()

    @staticmethod
    def _workspace_by_session(
        projection: FileProviderCatalogProjection, session_id: str
    ) -> FileProviderWorkspaceProjection:
        for item in projection.workspaces:
            if item.session_id == session_id:
                return item
        raise FileProviderBridgeError("the File Provider workspace no longer exists")

    @classmethod
    def _workspace_item(
        cls,
        projection: FileProviderCatalogProjection,
        workspace: FileProviderWorkspaceProjection,
    ) -> dict[str, Any]:
        identifier = _WORKSPACE_IDENTIFIER_PREFIX + cls._route_token(
            projection.account_id, workspace.session_id
        )
        version_input = (
            f"{identifier}\0{workspace.name}\0{workspace.name_revision}"
            f"\0{workspace.modified_at or ''}"
        )
        metadata = hashlib.sha256(
            version_input.encode("utf-8")
        ).hexdigest()
        return {
            "identifier": identifier,
            "parent_identifier": "root",
            "filename": workspace.name,
            "path": workspace.name,
            "kind": "directory",
            "size_bytes": 0,
            "content_version": identifier,
            "metadata_version": metadata,
            "modified_at": workspace.modified_at,
            "pending": False,
        }

    @staticmethod
    def _root_item() -> dict[str, Any]:
        return {
            "identifier": "root",
            "parent_identifier": None,
            "filename": "Meshia",
            "path": "",
            "kind": "directory",
            "size_bytes": 0,
            "content_version": "root",
            "metadata_version": "account-root-v1",
            "pending": False,
        }

    @staticmethod
    def _catalog_digest(projection: FileProviderCatalogProjection) -> str:
        return AccountFileProviderBridge._composite_catalog_digest(projection, ())

    def _account_status_document(
        self, projection: FileProviderCatalogProjection
    ) -> dict[str, Any]:
        """Return a global change token without cold-activating catalog roots.

        The catalog generation changes on every committed manifest publish.
        Active child heads are included as an additional low-latency signal so
        a coordinator that has already observed a remote head can wake macOS
        before the next catalog refresh. ``activate=False`` is essential: a
        one-second File Provider status poll must never hydrate all workspaces.
        """

        revisions: list[tuple[str, int, str | None]] = []
        visible = {item.session_id for item in projection.workspaces}
        for session_id in self.runtime_manager.file_provider_active_session_ids():
            if session_id not in visible:
                continue
            revision = self.runtime_manager.run_pinned(
                session_id,
                self._active_runtime_revision,
                require_visible=True,
                activate=False,
            )
            if revision is not None:
                revisions.append((session_id, revision[0], revision[1]))
        return {
            "schema": BRIDGE_SCHEMA,
            "ok": True,
            "workspace": "Meshia",
            "generation": projection.generation,
            "manifest_digest": self._composite_catalog_digest(
                projection, tuple(revisions)
            ),
            "account_wide": True,
            "workspace_count": len(projection.workspaces),
            "active_workspace_count": len(revisions),
        }

    @staticmethod
    def _active_runtime_revision(
        runtime: WorkspaceRuntime,
    ) -> tuple[int, str | None] | None:
        database = getattr(runtime.backend, "database", None)
        if database is None:
            return None
        head = database.get_remote_manifest_head()
        if head is None:
            return None
        return int(head.generation), (
            str(head.digest) if head.digest is not None else None
        )

    @staticmethod
    def _composite_catalog_digest(
        projection: FileProviderCatalogProjection,
        active_revisions: tuple[tuple[str, int, str | None], ...],
    ) -> str:
        return hashlib.sha256(
            json.dumps(
                {
                    "account_id": projection.account_id,
                    "generation": projection.generation,
                    "workspaces": [
                        [item.session_id, item.name, item.name_revision]
                        for item in projection.workspaces
                    ],
                    "active_workspace_revisions": sorted(active_revisions),
                },
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()

    @staticmethod
    def _default_workspace_bridge(
        runtime: WorkspaceRuntime,
        stable_name: str,
        address: FileProviderBridgeAddress,
    ) -> FabricFileProviderBridge:
        backend = runtime.backend
        database = getattr(backend, "database", None)
        workspace = getattr(backend, "workspace", None)
        if database is None or workspace is None:
            raise StateError(
                "The workspace runtime cannot serve native File Provider requests."
            )
        return FabricFileProviderBridge(
            database,
            runtime.coordinator,
            workspace,
            stable_name,
            address,
        )

    @staticmethod
    def _safe_error(connection: socket.socket, error: BaseException) -> None:
        try:
            _send_json_frame(
                connection,
                {
                    "schema": BRIDGE_SCHEMA,
                    "ok": False,
                    "error": type(error).__name__,
                    "message": str(error)[:1_000],
                },
            )
        except OSError:
            pass
