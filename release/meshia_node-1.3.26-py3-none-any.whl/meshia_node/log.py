"""Structured, redacting, bounded event log.

Text passes through a bounded normalizer which strips control characters and
blanks credentials based on both field name and value shape. Arbitrary objects
are never stringified. Secrets never reach the log or stdout.

The node can run continuously as a user service, so its persistent log is a
small rotating journal rather than an unbounded append-only file. Rotation is
serialized between threads and, where the platform permits, processes. Logging
remains best-effort: an unavailable lock or filesystem never blocks node work.
"""

from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
from pathlib import Path
from typing import Any, ClassVar, TextIO

from .util import clean, ensure_private_dir, iso8601


DEFAULT_MAX_BYTES = 4 * 1024 * 1024
DEFAULT_BACKUP_COUNT = 3
MAX_BACKUP_COUNT = 5
LOCK_WAIT_SECONDS = 0.05
LOCK_RETRY_SECONDS = 0.005
MAX_EVENT_CHARS = 64
MAX_FIELD_COUNT = 32
MAX_FIELD_KEY_CHARS = 48
MAX_FIELD_VALUE_CHARS = 256
# ``clean`` intentionally normalizes whitespace before applying its output
# limit. Feeding it an unbounded attacker-controlled string would therefore do
# unbounded work even though only 256 characters can reach a log. Scan enough
# source text for useful diagnostics while putting a hard ceiling on that work.
MAX_RAW_TEXT_CHARS = 2 * 1024

_BINARY = getattr(os, "O_BINARY", 0)

# Field *names* are a stronger signal than values: an opaque random token does
# not necessarily look secret. Normalize punctuation and case so variants such
# as ``Authorization``, ``accessToken``, ``X_MESHIA_SIGNATURE``, and
# ``client-secret`` are all denied before their values are inspected or
# stringified. A little over-redaction is preferable to credential disclosure.
_SECRET_KEY_PARTS = (
    "apikey",
    "accesskey",
    "auth",
    "bearer",
    "cookie",
    "credential",
    "jwt",
    "pairingcode",
    "passphrase",
    "passwd",
    "password",
    "privatekey",
    "pwd",
    "secret",
    "signature",
    "token",
)
_JWT_RE = re.compile(
    r"(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]{2,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"
)
_AUTH_VALUE_RE = re.compile(
    r"(?:\b(?:basic|bearer)\s+[A-Za-z0-9._~+/=-]+"
    r"|(?:^|[^A-Za-z0-9])(?:api[-_ ]?key|authorization|jwt|pass(?:word|phrase)?"
    r"|secret|signature|(?:access|refresh|id)[-_ ]?token|token)"
    r"\s*[:=]\s*\S+)",
    re.IGNORECASE,
)
_PRIVATE_KEY_MARKERS = (
    "begin private key",
    "begin ec private key",
    "begin openssh private key",
    "begin rsa private key",
)
_RESERVED_FIELDS = frozenset(("at", "event", "_fields_omitted"))


def _make_private_path(path: Path) -> bool:
    if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
        # chmod does not express privacy on Windows. Repair the explicit DACL;
        # fresh files also inherit the already-restricted Meshia home DACL.
        from .winsec import ensure_owner_restricted

        try:
            ensure_owner_restricted(path)
            return True
        except Exception:
            # Includes a failed/timed-out icacls spawn. Persistence is
            # observability and must fail closed without stopping node work.
            return False
    try:
        os.chmod(path, 0o600)
        return True
    except OSError:
        return False


def _make_private_fd(descriptor: int, path: Path) -> bool:
    """Make an open log artifact private, failing closed on permission errors."""
    if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
        return _make_private_path(path)
    try:
        os.fchmod(descriptor, 0o600)
        return True
    except (AttributeError, OSError):  # pragma: no cover - nonstandard POSIX
        return False


def _open_private_file(path: Path, flags: int) -> int:
    try:
        return os.open(str(path), flags, 0o600)
    except PermissionError:
        if os.name == "nt":  # pragma: no cover - native branch tested separately
            from .winsec import _open_repaired_private_file

            try:
                descriptor = _open_repaired_private_file(path, flags)
            except Exception:
                descriptor = None
            if descriptor is not None:
                return descriptor
        raise


def _write_all(descriptor: int, data: bytes) -> None:
    view = memoryview(data)
    while view:
        written = os.write(descriptor, view)
        if written <= 0:  # Defensive: os.write normally raises instead.
            raise OSError("log write made no progress")
        view = view[written:]


def _bounded_text(value: str, limit: int) -> str:
    """Normalize a bounded prefix and redact value-shaped credentials.

    This helper accepts only an actual ``str``. Callers deliberately avoid
    invoking arbitrary ``__str__`` implementations in the node's hot path.
    """
    source = value[:MAX_RAW_TEXT_CHARS]
    lowered = source.casefold()
    if (
        "mesh_" in lowered
        or "signature" in lowered
        or "private key" in lowered
        or any(marker in lowered for marker in _PRIVATE_KEY_MARKERS)
        or _JWT_RE.search(source) is not None
        or _AUTH_VALUE_RE.search(source) is not None
    ):
        return "[redacted]"
    # Keep the existing control-character/whitespace policy, but only after
    # bounding the input passed to it.
    return clean(source, limit)


def _bounded_key(key: str) -> str:
    # Keyword argument keys are strings, but use an exact-type check so a str
    # subclass cannot smuggle work through an overridden conversion method.
    if type(key) is not str:
        return ""
    return clean(key[:MAX_RAW_TEXT_CHARS], MAX_FIELD_KEY_CHARS)


def _secret_field(key: str) -> bool:
    # Bound before case-folding/normalizing. This is intentionally substring
    # based: diagnostic field names are a tiny controlled vocabulary and a
    # false-positive redaction is safe.
    if len(key) > MAX_FIELD_KEY_CHARS:
        # The displayed key would be truncated and could hide a secret suffix.
        # Fail closed instead of attaching an opaque value to an ambiguous key.
        return True
    compact = "".join(
        character
        for character in key[:MAX_RAW_TEXT_CHARS].casefold()
        if character.isalnum()
    )
    return any(part in compact for part in _SECRET_KEY_PARTS)


def _bounded_value(value: Any) -> str:
    """Return bounded log text without running caller-controlled code."""
    value_type = type(value)
    if value_type is str:
        return _bounded_text(value, MAX_FIELD_VALUE_CHARS)
    if value_type is bytes:
        return _bounded_text(
            value[:MAX_RAW_TEXT_CHARS].decode("utf-8", errors="replace"),
            MAX_FIELD_VALUE_CHARS,
        )
    if value_type is bytearray:
        return _bounded_text(
            bytes(value[:MAX_RAW_TEXT_CHARS]).decode("utf-8", errors="replace"),
            MAX_FIELD_VALUE_CHARS,
        )
    if value_type is bool:
        return "True" if value else "False"
    if value_type is int:
        # Decimal conversion of a giant integer is needlessly expensive and
        # may itself raise under Python's integer-string safety limit.
        return str(value) if value.bit_length() <= 256 else "[oversized integer omitted]"
    if value_type is float:
        return str(value)
    # Containers can hide credentials and user objects can execute or block in
    # __str__. The logger needs neither; callers should extract a small scalar.
    return "[unsupported value omitted]"


class NodeLogger:
    """Write redacted JSON events to stderr and a bounded private journal.

    ``max_bytes`` and ``backup_count`` are optional so the original constructor
    contract remains intact. At the defaults, persistent logging consumes at
    most 16 MiB across ``node.log`` and its three backups (plus a one-byte lock
    file). A caller may retain fewer backups, but never more than five.
    """

    _path_locks_guard: ClassVar[threading.Lock] = threading.Lock()
    _path_locks: ClassVar[dict[str, threading.RLock]] = {}

    def __init__(
        self,
        path: Path | None = None,
        echo: TextIO | None = None,
        quiet: bool = False,
        max_bytes: int = DEFAULT_MAX_BYTES,
        backup_count: int = DEFAULT_BACKUP_COUNT,
    ) -> None:
        self.path = path
        self.echo = echo if echo is not None else sys.stderr
        self.quiet = quiet
        self.max_bytes = max(1, int(max_bytes))
        self.backup_count = max(0, min(MAX_BACKUP_COUNT, int(backup_count)))
        self._artifacts_prepared = False

    def record(self, event: str, **fields: Any) -> None:
        try:
            safe_event = (
                _bounded_text(event, MAX_EVENT_CHARS)
                if type(event) is str
                else "[invalid event omitted]"
            )
            entry: dict[str, str | int] = {"at": iso8601(), "event": safe_event}
            examined = 0
            skipped = 0
            for key, value in fields.items():
                if examined >= MAX_FIELD_COUNT:
                    break
                examined += 1
                if value is None:
                    continue
                safe_key = _bounded_key(key)
                if not safe_key or safe_key in _RESERVED_FIELDS or safe_key in entry:
                    skipped += 1
                    continue
                # Test the original bounded key so truncation cannot remove a
                # secret-bearing suffix before classification.
                entry[safe_key] = "[redacted]" if _secret_field(key) else _bounded_value(value)
            omitted = max(0, len(fields) - examined) + skipped
            if omitted:
                entry["_fields_omitted"] = omitted
            line = json.dumps(entry, sort_keys=True)
        except Exception:
            # A broken diagnostic object must not affect reconciliation.
            return

        if self.path is not None:
            try:
                encoded = self._bounded_record(entry, line)
                if encoded is not None:
                    self._persist(encoded)
            except Exception:
                # Logging is observability, never a reason to stop the node.
                pass
        if not self.quiet and self.echo is not None:
            try:
                print(line, file=self.echo, flush=True)
            except Exception:
                # stderr can disappear during service-manager shutdown, and a
                # caller-provided stream can be closed or otherwise broken.
                pass

    def _bounded_record(self, entry: dict[str, str | int], line: str) -> bytes | None:
        encoded = (line + "\n").encode("utf-8")
        if len(encoded) <= self.max_bytes:
            return encoded

        # A pathological caller can supply thousands of distinct fields even
        # though each value is bounded. Preserve the event without allowing one
        # entry to violate the journal cap. The original, already-redacted line
        # is still eligible for the configured echo stream.
        compact = json.dumps(
            {
                "at": entry["at"],
                "event": entry["event"],
                "detail": "[fields omitted: entry exceeds log byte limit]",
            },
            sort_keys=True,
        )
        encoded = (compact + "\n").encode("utf-8")
        return encoded if len(encoded) <= self.max_bytes else None

    @classmethod
    def _thread_lock_for(cls, path: Path) -> threading.RLock:
        key = os.path.abspath(os.fspath(path))
        with cls._path_locks_guard:
            lock = cls._path_locks.get(key)
            if lock is None:
                lock = threading.RLock()
                cls._path_locks[key] = lock
            return lock

    def _persist(self, encoded: bytes) -> None:
        assert self.path is not None
        ensure_private_dir(self.path.parent)
        thread_lock = self._thread_lock_for(self.path)
        deadline = time.monotonic() + LOCK_WAIT_SECONDS
        if not thread_lock.acquire(timeout=LOCK_WAIT_SECONDS):
            return
        try:
            locked = self._acquire_process_lock(deadline)
            if locked is None:
                # Skipping one file record is safer than racing rotation and
                # corrupting or unbounding the journal. Echo behavior is intact.
                return
            descriptor, lock_kind = locked
            try:
                if not self._artifacts_prepared:
                    self._prepare_existing_artifacts()
                    self._artifacts_prepared = True
                try:
                    current_size = self.path.stat().st_size
                except FileNotFoundError:
                    current_size = 0
                if current_size + len(encoded) > self.max_bytes:
                    self._rotate()
                self._append(encoded)
            finally:
                self._release_process_lock(descriptor, lock_kind)
        finally:
            thread_lock.release()

    def _lock_path(self) -> Path:
        assert self.path is not None
        return self.path.with_name(f"{self.path.name}.lock")

    def _acquire_process_lock(self, deadline: float) -> tuple[int, str] | None:
        """Acquire a short-lived advisory lock shared by all node processes."""
        lock_path = self._lock_path()
        try:
            descriptor = _open_private_file(
                lock_path,
                os.O_RDWR | os.O_CREAT | _BINARY,
            )
        except OSError:
            return None
        if not _make_private_fd(descriptor, lock_path):
            os.close(descriptor)
            return None

        if os.name == "nt":  # pragma: no cover - exercised on Windows hosts
            try:
                import msvcrt

                if os.fstat(descriptor).st_size == 0:
                    _write_all(descriptor, b"\0")
                os.lseek(descriptor, 0, os.SEEK_SET)
                while True:
                    try:
                        msvcrt.locking(descriptor, msvcrt.LK_NBLCK, 1)
                        return descriptor, "windows"
                    except OSError:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            break
                        time.sleep(min(LOCK_RETRY_SECONDS, remaining))
            except OSError:
                pass
            os.close(descriptor)
            return None

        try:
            import fcntl

            while True:
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    return descriptor, "posix"
                except (BlockingIOError, InterruptedError):
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    time.sleep(min(LOCK_RETRY_SECONDS, remaining))
            os.close(descriptor)
            return None
        except (ImportError, OSError):  # pragma: no cover - exotic platforms
            os.close(descriptor)
            return None

    @staticmethod
    def _release_process_lock(descriptor: int, lock_kind: str) -> None:
        try:
            if lock_kind == "windows":  # pragma: no cover - Windows only
                import msvcrt

                os.lseek(descriptor, 0, os.SEEK_SET)
                msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(descriptor, fcntl.LOCK_UN)
        except (ImportError, OSError):
            pass
        finally:
            os.close(descriptor)

    def _append(self, encoded: bytes) -> None:
        assert self.path is not None
        descriptor = _open_private_file(
            self.path,
            os.O_WRONLY | os.O_CREAT | os.O_APPEND | _BINARY,
        )
        try:
            if not _make_private_fd(descriptor, self.path):
                raise OSError("could not restrict log permissions")
            _write_all(descriptor, encoded)
        finally:
            os.close(descriptor)

    def _backup_path(self, index: int) -> Path:
        assert self.path is not None
        return self.path.with_name(f"{self.path.name}.{index}")

    def _prepare_existing_artifacts(self) -> None:
        """Privatize retained files and prune leftovers from older settings."""
        assert self.path is not None
        if self.path.exists():
            self._repair_active_tail()
        for index in range(1, MAX_BACKUP_COUNT + 1):
            backup = self._backup_path(index)
            temporary = backup.with_name(f".{backup.name}.trim")
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass
            if not backup.exists():
                continue
            if index <= self.backup_count:
                self._bound_backup(backup)
            else:
                backup.unlink()

    def _repair_active_tail(self) -> None:
        """Drop a crash-truncated JSONL tail before appending a new record."""
        assert self.path is not None
        descriptor = _open_private_file(self.path, os.O_RDWR | _BINARY)
        try:
            if not _make_private_fd(descriptor, self.path):
                raise OSError("could not restrict log permissions")
            size = os.fstat(descriptor).st_size
            if size == 0:
                return
            os.lseek(descriptor, size - 1, os.SEEK_SET)
            if os.read(descriptor, 1) == b"\n":
                return

            cursor = size
            while cursor > 0:
                chunk_size = min(cursor, 64 * 1024)
                cursor -= chunk_size
                os.lseek(descriptor, cursor, os.SEEK_SET)
                chunk = os.read(descriptor, chunk_size)
                newline = chunk.rfind(b"\n")
                if newline >= 0:
                    os.ftruncate(descriptor, cursor + newline + 1)
                    return
            os.ftruncate(descriptor, 0)
        finally:
            os.close(descriptor)

    def _rotate(self) -> None:
        """Rotate under the process lock, then enforce bounds and permissions."""
        assert self.path is not None
        if self.backup_count == 0:
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
            return

        oldest = self._backup_path(self.backup_count)
        try:
            oldest.unlink()
        except FileNotFoundError:
            pass

        for index in range(self.backup_count - 1, 0, -1):
            source = self._backup_path(index)
            if source.exists():
                os.replace(source, self._backup_path(index + 1))

        if self.path.exists():
            os.replace(self.path, self._backup_path(1))

        # An upgrade may encounter the old unbounded node.log or permissive
        # backups. Retain only complete tail records and make every artifact
        # private immediately, rather than waiting for several rotations.
        for index in range(1, self.backup_count + 1):
            backup = self._backup_path(index)
            if backup.exists():
                self._bound_backup(backup)

    def _bound_backup(self, path: Path) -> None:
        if path.stat().st_size > self.max_bytes:
            self._rewrite_with_bounded_tail(path)
            if not path.exists():
                return
        if not _make_private_path(path):
            # Do not retain a persistent log that cannot be made private.
            try:
                path.unlink()
            except OSError:
                pass

    def _rewrite_with_bounded_tail(self, path: Path) -> None:
        size = path.stat().st_size
        offset = max(0, size - self.max_bytes)
        with os.fdopen(_open_private_file(path, os.O_RDONLY | _BINARY), "rb") as stream:
            stream.seek(offset)
            tail = stream.read(self.max_bytes)

        if offset:
            newline = tail.find(b"\n")
            tail = tail[newline + 1 :] if newline >= 0 else b""
        if tail and not tail.endswith(b"\n"):
            newline = tail.rfind(b"\n")
            tail = tail[: newline + 1] if newline >= 0 else b""

        if not tail:
            path.unlink()
            return

        temporary_path = path.with_name(f".{path.name}.trim")
        descriptor = os.open(
            str(temporary_path),
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC | _BINARY,
            0o600,
        )
        try:
            if not _make_private_fd(descriptor, temporary_path):
                raise OSError("could not restrict rotated log permissions")
            _write_all(descriptor, tail)
            os.close(descriptor)
            descriptor = -1
            os.replace(temporary_path, path)
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass


NULL_LOGGER = NodeLogger(path=None, echo=None, quiet=True)
