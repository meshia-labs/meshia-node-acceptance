"""Unix-socket RPC bridge between the macOS FSKit extension and the mount backend.

The signed ``MeshiaFSExtension.appex`` is a thin, policy-free adapter: every
FSKit volume operation becomes one framed request on this socket and the
reply is mapped straight back to a POSIX errno or a result. All namespace,
staging, quota, and publication policy stays in ``fabric_mount`` exactly as
it does for the FUSE-T transport; this module only speaks the wire format and
routes each volume to its workspace backend route.

Wire format (``meshia.fskit.bridge.v1``)
----------------------------------------

Every message is one *header frame*: a 4-byte big-endian length followed by
that many bytes of UTF-8 JSON (an object). When the object carries an integer
``payload_bytes`` field, exactly that many raw bytes follow the header frame
with no additional length prefix; that raw frame carries read/write data and
xattr values so bulk bytes never pass through JSON or base64.

A connection is bound to one volume by its first request (``hello``). Handles
are scoped to the volume, not the connection, so the extension may drive one
handle from any connection in its pool. When the last connection of a volume
closes (extension exit, crash, unmount) every handle that volume still owns
is released so a dead extension can never pin a write session open.
"""

from __future__ import annotations

import errno
import json
import os
import shutil
import socket
import stat
import struct
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from .errors import InvalidTask, StateError, UnsafePath
from .fabric_mount import (
    tune_interpreter_for_mount_callbacks,
    MAX_DIRECTORY_ENTRIES,
    MOUNT_ADAPTER_ERRORS,
    MOUNT_IO_BYTES,
    MOUNT_MIN_FREE_BYTES,
    MountNode,
    _discardable_macos_xattr,
    _ENOATTR,
    _MACOS_QUARANTINE_XATTR,
    mount_error_report,
)
from .log import NULL_LOGGER, NodeLogger
from .util import ensure_private_dir
from .workspace import split_relative

BRIDGE_SCHEMA = "meshia.fskit.bridge.v1"
BRIDGE_PROTOCOL = 1
#: A request header is small: paths, names, and a handful of integers.
MAX_REQUEST_HEADER_BYTES = 1024 * 1024
#: Directory listings for the largest supported directory still fit here.
MAX_RESPONSE_HEADER_BYTES = 64 * 1024 * 1024
#: One raw data frame. FSKit issues reads/writes far below this; the bridge
#: splits any larger request into ``MOUNT_IO_BYTES`` backend calls.
MAX_PAYLOAD_BYTES = 16 * 1024 * 1024
MAX_XATTR_BYTES = 1024 * 1024
MAX_CONNECTIONS = 128
CONNECTION_IDLE_TIMEOUT_SECONDS = 600.0
#: The FSKit root item identifier is fixed by the kernel.
ROOT_ITEM_ID = 2
_RESERVED_ITEM_IDS = 16
_APPLEDOUBLE_PREFIX = "._"
_XATTR_POLICIES = ("set", "create", "replace", "delete")
_OPEN_MODES = {
    "r": os.O_RDONLY,
    "w": os.O_WRONLY,
    "rw": os.O_RDWR,
}


class FSKitBridgeError(RuntimeError):
    """A malformed or unauthenticated bridge request; the connection closes."""


@dataclass(frozen=True)
class VolumeSpec:
    """One FSKit volume: a stable identity plus the current workspace label."""

    volume_id: str
    name: str

    def __post_init__(self) -> None:
        if not isinstance(self.volume_id, str) or not self.volume_id:
            raise ValueError("volume_id must be a non-empty string")
        if any(character in self.volume_id for character in "/\0"):
            raise ValueError("volume_id must not contain path separators")
        if len(split_relative(self.name)) != 1:
            raise ValueError("volume name must be one portable path component")


VolumeCatalog = Callable[[], Sequence[VolumeSpec]]


def backend_volume_catalog(backend: Any) -> VolumeCatalog:
    """Project every top-level backend route as a volume named after itself.

    Used when no workspace runtime manager exists (tests, the in-memory demo,
    and the legacy single-workspace service shape). Catalog-managed services
    supply session-id keyed specs so renames keep a stable volume identity.
    """

    def volumes() -> Sequence[VolumeSpec]:
        return tuple(VolumeSpec(label, label) for label in backend.listdir("/"))

    return volumes


def item_identifier(volume_path: str) -> int:
    """Derive a stable 64-bit item id from a volume-relative path.

    The root is the kernel's fixed root id. Every other id is a path hash
    kept away from the reserved low identifiers and the sign bit.
    """

    if volume_path == "/":
        return ROOT_ITEM_ID
    import hashlib

    digest = hashlib.sha256(volume_path.encode("utf-8")).digest()[:8]
    value = int.from_bytes(digest, "big") & 0x7FFF_FFFF_FFFF_FFFF
    if value < _RESERVED_ITEM_IDS:
        value += _RESERVED_ITEM_IDS
    return value


def node_attributes(node: MountNode, volume_path: str) -> dict[str, Any]:
    """Serialize one backend node as the wire attribute object."""

    stats = node.stat()
    return {
        "type": "directory" if node.is_directory else "file",
        "size": int(node.size_bytes),
        "mtime_ns": int(node.modified_ns),
        "mode": int(stats["st_mode"]) & 0o7777,
        "nlink": int(stats["st_nlink"]),
        "uid": int(stats["st_uid"]),
        "gid": int(stats["st_gid"]),
        "ino": item_identifier(volume_path),
        "blksize": MOUNT_IO_BYTES,
    }


def _volume_path(value: object) -> str:
    """Validate one volume-relative absolute path from the extension."""

    if not isinstance(value, str) or not value.startswith("/"):
        raise OSError(errno.EINVAL, "Bridge paths must be absolute.")
    if value == "/":
        return "/"
    try:
        parts = split_relative(value[1:])
    except (InvalidTask, UnsafePath) as error:
        raise OSError(errno.EINVAL, str(error)) from error
    return "/" + "/".join(parts)


def _deny_appledouble(volume_path: str) -> None:
    """FSKit stores xattrs natively; never let a ``._`` sidecar land remotely."""

    name = volume_path.rsplit("/", 1)[-1]
    if name.startswith(_APPLEDOUBLE_PREFIX):
        raise OSError(
            errno.EPERM, "AppleDouble sidecar files are not stored in Meshia."
        )


def _integer(value: object, field: str, *, minimum: int = 0, maximum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise OSError(errno.EINVAL, f"{field} must be an integer >= {minimum}.")
    if maximum is not None and value > maximum:
        raise OSError(errno.EINVAL, f"{field} must be <= {maximum}.")
    return value


def _optional_integer(request: Mapping[str, Any], field: str, **bounds: Any) -> int | None:
    value = request.get(field)
    if value is None:
        return None
    return _integer(value, field, **bounds)


def _string(value: object, field: str, *, maximum: int = 4096) -> str:
    if not isinstance(value, str) or not value or len(value) > maximum:
        raise OSError(errno.EINVAL, f"{field} must be a bounded non-empty string.")
    return value


class _VolumeSession:
    """Handles and connection count for one volume across its connection pool."""

    def __init__(self, volume_id: str) -> None:
        self.volume_id = volume_id
        self.connections = 0
        self.handles: set[int] = set()


class FSKitBridgeServer:
    """Serve every FSKit volume of one mount backend on one Unix socket."""

    def __init__(
        self,
        backend: Any,
        socket_path: Path | str,
        *,
        volumes: VolumeCatalog | None = None,
        logger: NodeLogger = NULL_LOGGER,
        max_connections: int = MAX_CONNECTIONS,
    ) -> None:
        self.backend = backend
        self.socket_path = Path(socket_path).expanduser()
        self.volumes = volumes or backend_volume_catalog(backend)
        self.logger = logger
        self._listener: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stopped = threading.Event()
        self._connections = threading.BoundedSemaphore(max_connections)
        self._lock = threading.Lock()
        self._sessions: dict[str, _VolumeSession] = {}
        self._workers: set[threading.Thread] = set()
        self._socket_identity: tuple[int, int] | None = None

    # ----------------------------------------------------------- lifecycle

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        if not hasattr(socket, "AF_UNIX"):
            raise FSKitBridgeError("Unix sockets are unavailable on this platform")
        path = str(self.socket_path)
        if len(path.encode("utf-8")) >= 100:
            # Darwin's sockaddr_un holds 104 bytes including the terminator.
            raise FSKitBridgeError("the FSKit bridge socket path is too long")
        ensure_private_dir(self.socket_path.parent)
        self._remove_stale_socket()
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            listener.bind(path)
            os.chmod(self.socket_path, 0o600)
            info = self.socket_path.lstat()
            self._socket_identity = (info.st_dev, info.st_ino)
            listener.listen(64)
            listener.settimeout(0.5)
        except BaseException:
            listener.close()
            raise
        self._listener = listener
        self._stopped.clear()
        # The bridge dispatch loop answers filesystem callbacks from worker
        # threads inside the node process; without a short interpreter switch
        # interval those tiny slices starve behind the sync engine's
        # interpreter-bound work exactly like the FUSE loop did (2026-08-30).
        applied_interval = tune_interpreter_for_mount_callbacks()
        if applied_interval is not None:
            self.logger.record(
                "fskit_bridge_gil_interval_tuned", interval=applied_interval
            )
        self._thread = threading.Thread(
            target=self._serve, name="meshia-fskit-bridge", daemon=True
        )
        self._thread.start()
        self.logger.record("fskit_bridge_started", socket_path=path)

    def close(self) -> None:
        self._stopped.set()
        listener, self._listener = self._listener, None
        if listener is not None:
            listener.close()
        thread, self._thread = self._thread, None
        if thread is not None:
            thread.join(timeout=2.0)
        with self._lock:
            workers = tuple(self._workers)
        for worker in workers:
            worker.join(timeout=2.0)
        # Any connection that did not drain in time still owns its handles;
        # release them here so backend close never waits on a dead extension.
        with self._lock:
            sessions = tuple(self._sessions.values())
            self._sessions.clear()
        for session in sessions:
            self._release_all(session)
        try:
            info = self.socket_path.lstat()
            if (
                self._socket_identity is not None
                and stat.S_ISSOCK(info.st_mode)
                and (info.st_dev, info.st_ino) == self._socket_identity
            ):
                self.socket_path.unlink()
        except OSError:
            pass
        self._socket_identity = None
        self.logger.record("fskit_bridge_stopped", socket_path=str(self.socket_path))

    def _remove_stale_socket(self) -> None:
        path = self.socket_path
        try:
            info = path.lstat()
        except FileNotFoundError:
            return
        if not stat.S_ISSOCK(info.st_mode) or info.st_uid != os.getuid():
            raise FSKitBridgeError("the FSKit bridge socket path is unsafe")
        probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            probe.settimeout(0.25)
            probe.connect(str(path))
        except (ConnectionRefusedError, FileNotFoundError):
            pass
        except OSError as error:
            raise FSKitBridgeError(
                "the existing FSKit bridge socket could not be verified"
            ) from error
        else:
            raise FSKitBridgeError("an FSKit bridge is already serving this socket")
        finally:
            probe.close()
        path.unlink()

    def _serve(self) -> None:
        while not self._stopped.is_set():
            listener = self._listener
            if listener is None:
                return
            try:
                connection, _address = listener.accept()
            except TimeoutError:
                continue
            except OSError:
                if self._stopped.is_set():
                    return
                continue
            if not self._connections.acquire(blocking=False):
                connection.close()
                self.logger.record("fskit_bridge_connection_refused", reason="limit")
                continue
            worker = threading.Thread(
                target=self._handle_connection,
                args=(connection,),
                name="meshia-fskit-connection",
                daemon=True,
            )
            with self._lock:
                self._workers.add(worker)
            worker.start()

    # ----------------------------------------------------------- sessions

    def _bind(self, volume_id: str) -> _VolumeSession:
        with self._lock:
            session = self._sessions.get(volume_id)
            if session is None:
                session = _VolumeSession(volume_id)
                self._sessions[volume_id] = session
            session.connections += 1
            return session

    def _unbind(self, session: _VolumeSession) -> None:
        with self._lock:
            session.connections -= 1
            if session.connections > 0:
                return
            self._sessions.pop(session.volume_id, None)
        self._release_all(session)

    def _release_all(self, session: _VolumeSession) -> None:
        with self._lock:
            handles = tuple(session.handles)
            session.handles.clear()
        for handle in handles:
            try:
                self.backend.release(handle)
            except Exception as error:  # noqa: BLE001 - best-effort cleanup
                self.logger.record(
                    "fskit_bridge_release_failed",
                    handle=handle,
                    error_type=type(error).__name__,
                    error=str(error),
                )

    def _volume_name(self, volume_id: str) -> str:
        for spec in self.volumes():
            if spec.volume_id == volume_id:
                return spec.name
        raise OSError(errno.ESTALE, "The workspace volume is no longer attached.")

    # ----------------------------------------------------------- connection

    @staticmethod
    def _require_same_user(connection: socket.socket) -> None:
        getpeereid = getattr(connection, "getpeereid", None)
        if callable(getpeereid):
            peer_uid, _peer_gid = getpeereid()
            if peer_uid != os.getuid():
                raise FSKitBridgeError("the FSKit bridge peer user is invalid")
            return
        so_peercred = getattr(socket, "SO_PEERCRED", None)
        if so_peercred is not None:
            credentials = connection.getsockopt(socket.SOL_SOCKET, so_peercred, 12)
            _pid, peer_uid, _peer_gid = struct.unpack("3i", credentials)
            if peer_uid != os.getuid():
                raise FSKitBridgeError("the FSKit bridge peer user is invalid")

    def _handle_connection(self, connection: socket.socket) -> None:
        session: _VolumeSession | None = None
        try:
            connection.settimeout(CONNECTION_IDLE_TIMEOUT_SECONDS)
            self._require_same_user(connection)
            while not self._stopped.is_set():
                try:
                    request = _receive_header(connection, MAX_REQUEST_HEADER_BYTES)
                except _ConnectionClosed:
                    return
                operation = request.get("op")
                request_id = request.get("id")
                payload: bytes | None = None
                declared = request.get("payload_bytes")
                if declared is not None:
                    size = _integer(declared, "payload_bytes", maximum=MAX_PAYLOAD_BYTES)
                    payload = _receive_exact(connection, size)
                try:
                    if operation == "hello":
                        if session is not None:
                            raise OSError(errno.EINVAL, "The connection is already bound.")
                        volume_id = _string(request.get("volume"), "volume", maximum=256)
                        protocol = request.get("protocol")
                        if protocol != BRIDGE_PROTOCOL:
                            raise OSError(
                                errno.EPROTONOSUPPORT,
                                f"Unsupported bridge protocol {protocol!r}.",
                            )
                        name = self._volume_name(volume_id)
                        session = self._bind(volume_id)
                        response = {
                            "protocol": BRIDGE_PROTOCOL,
                            "volume": {"id": volume_id, "name": name},
                            "io_bytes": MOUNT_IO_BYTES,
                            "max_payload_bytes": MAX_PAYLOAD_BYTES,
                            "attrs": self._getattr(name, "/"),
                        }
                    elif operation == "volumes":
                        response = {
                            "volumes": [
                                {"id": spec.volume_id, "name": spec.name}
                                for spec in self.volumes()
                            ]
                        }
                    elif session is None:
                        raise OSError(errno.EINVAL, "Send hello before volume operations.")
                    else:
                        response = self._dispatch(session, operation, request, payload)
                except MOUNT_ADAPTER_ERRORS as error:
                    number, report = mount_error_report(
                        error, operation=str(operation)
                    )
                    if report is not None:
                        self.logger.record("fskit_bridge_operation_failed", **report)
                    _send_header(
                        connection,
                        {
                            "schema": BRIDGE_SCHEMA,
                            "id": request_id,
                            "ok": False,
                            "errno": number,
                            "code": errno.errorcode.get(number, "EIO"),
                            "message": str(error)[:1_000],
                        },
                    )
                    continue
                data = response.pop("_payload", None)
                document = {"schema": BRIDGE_SCHEMA, "id": request_id, "ok": True, **response}
                if data is not None:
                    document["payload_bytes"] = len(data)
                _send_header(connection, document)
                if data is not None:
                    connection.sendall(data)
        except (FSKitBridgeError, OSError, json.JSONDecodeError, ValueError) as error:
            self.logger.record(
                "fskit_bridge_connection_closed",
                error_type=type(error).__name__,
                error=str(error)[:500],
            )
        finally:
            try:
                connection.close()
            except OSError:
                pass
            if session is not None:
                self._unbind(session)
            with self._lock:
                self._workers.discard(threading.current_thread())
            self._connections.release()

    # ----------------------------------------------------------- operations

    def _backend_path(self, name: str, volume_path: str) -> str:
        return f"/{name}" if volume_path == "/" else f"/{name}{volume_path}"

    def _getattr(self, name: str, volume_path: str) -> dict[str, Any]:
        node = self.backend.getattr(self._backend_path(name, volume_path))
        return node_attributes(node, volume_path)

    def _open(
        self,
        session: _VolumeSession,
        name: str,
        volume_path: str,
        flags: int,
        *,
        create: bool,
    ) -> int:
        handle = int(
            self.backend.open(self._backend_path(name, volume_path), flags, create=create)
        )
        with self._lock:
            session.handles.add(handle)
        return handle

    def _require_handle(self, session: _VolumeSession, request: Mapping[str, Any]) -> int:
        handle = _integer(request.get("handle"), "handle", minimum=1)
        with self._lock:
            if handle not in session.handles:
                raise OSError(errno.EBADF, "The bridge handle is not open on this volume.")
        return handle

    def _dispatch(
        self,
        session: _VolumeSession,
        operation: object,
        request: Mapping[str, Any],
        payload: bytes | None,
    ) -> dict[str, Any]:
        name = self._volume_name(session.volume_id)
        backend = self.backend
        if operation in ("getattr", "lookup"):
            path = _volume_path(request.get("path"))
            return {"attrs": self._getattr(name, path)}
        if operation == "readdir":
            path = _volume_path(request.get("path"))
            names = backend.listdir(self._backend_path(name, path))
            if len(names) > MAX_DIRECTORY_ENTRIES:
                raise OSError(errno.EOVERFLOW, "The directory is too large.")
            entries = []
            prefix = "" if path == "/" else path
            for child in names:
                child_path = f"{prefix}/{child}"
                try:
                    attrs = self._getattr(name, child_path)
                except OSError as error:
                    if error.errno == errno.ENOENT:
                        continue  # concurrently removed
                    raise
                entries.append({"name": child, "attrs": attrs})
            return {"entries": entries}
        if operation == "open":
            path = _volume_path(request.get("path"))
            mode = request.get("mode", "r")
            if mode not in _OPEN_MODES:
                raise OSError(errno.EINVAL, "mode must be r, w, or rw.")
            flags = _OPEN_MODES[mode]
            create = bool(request.get("create", False))
            if create:
                _deny_appledouble(path)
                flags |= os.O_CREAT
                if bool(request.get("exclusive", False)):
                    flags |= os.O_EXCL
            handle = self._open(session, name, path, flags, create=create)
            return {"handle": handle, "attrs": self._getattr(name, path)}
        if operation == "create":
            path = _volume_path(request.get("path"))
            _deny_appledouble(path)
            kind = request.get("type", "file")
            if kind == "directory":
                backend.mkdir(self._backend_path(name, path))
                return {"attrs": self._getattr(name, path)}
            if kind != "file":
                raise OSError(errno.ENOTSUP, "Only files and directories can be created.")
            handle = self._open(
                session, name, path, os.O_RDWR | os.O_CREAT | os.O_EXCL, create=True
            )
            return {"handle": handle, "attrs": self._getattr(name, path)}
        if operation == "read":
            handle = self._require_handle(session, request)
            offset = _integer(request.get("offset"), "offset")
            length = _integer(request.get("length"), "length", maximum=MAX_PAYLOAD_BYTES)
            chunks: list[bytes] = []
            remaining = length
            cursor = offset
            while remaining > 0:
                want = min(remaining, MOUNT_IO_BYTES)
                chunk = bytes(backend.read(handle, cursor, want))
                if not chunk:
                    break
                chunks.append(chunk)
                cursor += len(chunk)
                remaining -= len(chunk)
                if len(chunk) < want:
                    break  # end of file
            return {"_payload": b"".join(chunks)}
        if operation == "write":
            handle = self._require_handle(session, request)
            offset = _integer(request.get("offset"), "offset")
            if payload is None:
                raise OSError(errno.EINVAL, "write requires payload_bytes.")
            view = memoryview(payload)
            written = 0
            while written < len(view):
                chunk = view[written : written + MOUNT_IO_BYTES]
                count = int(backend.write(handle, offset + written, bytes(chunk)))
                if count <= 0:
                    raise OSError(errno.EIO, "The backend accepted no bytes.")
                written += count
            return {"written": written}
        if operation == "truncate":
            path = _volume_path(request.get("path"))
            length = _integer(request.get("length"), "length")
            handle = _optional_integer(request, "handle", minimum=1)
            if handle is not None:
                self._require_handle(session, {"handle": handle})
            backend.truncate(self._backend_path(name, path), length, handle=handle)
            return {"attrs": self._getattr(name, path)}
        if operation == "setattr":
            return self._setattr(session, name, request)
        if operation == "fsync":
            handle = self._require_handle(session, request)
            backend.fsync(handle)
            return {}
        if operation == "flush":
            handle = self._require_handle(session, request)
            backend.flush(handle)
            return {}
        if operation == "release":
            handle = self._require_handle(session, request)
            with self._lock:
                session.handles.discard(handle)
            backend.release(handle)
            return {}
        if operation == "sync":
            with self._lock:
                handles = tuple(session.handles)
            for handle in handles:
                backend.fsync(handle)
            return {}
        if operation == "unlink":
            path = _volume_path(request.get("path"))
            backend.unlink(self._backend_path(name, path))
            return {}
        if operation == "mkdir":
            path = _volume_path(request.get("path"))
            _deny_appledouble(path)
            backend.mkdir(self._backend_path(name, path))
            return {"attrs": self._getattr(name, path)}
        if operation == "rmdir":
            path = _volume_path(request.get("path"))
            backend.rmdir(self._backend_path(name, path))
            return {}
        if operation == "rename":
            source = _volume_path(request.get("source"))
            destination = _volume_path(request.get("destination"))
            if source == "/" or destination == "/":
                raise OSError(errno.EPERM, "The volume root cannot be renamed here.")
            _deny_appledouble(destination)
            backend.rename(
                self._backend_path(name, source), self._backend_path(name, destination)
            )
            return {}
        if operation == "rename_volume":
            new_name = _string(request.get("name"), "name", maximum=255)
            if len(split_relative(new_name)) != 1:
                raise OSError(errno.EINVAL, "The volume name must be one path component.")
            backend.rename(f"/{name}", f"/{new_name}")
            try:
                current = self._volume_name(session.volume_id)
            except OSError:
                # A label-keyed catalog re-keys the volume on rename; the
                # session's old identity is now stale but the rename landed.
                current = new_name
            return {"name": current}
        if operation == "statfs":
            return {"statfs": self._statfs(name)}
        if operation == "getxattr":
            path = _volume_path(request.get("path"))
            xattr = _string(request.get("name"), "name", maximum=255)
            value = bytes(backend.getxattr(self._backend_path(name, path), xattr, 0))
            return {"_payload": value}
        if operation == "listxattr":
            path = _volume_path(request.get("path"))
            names = list(backend.listxattr(self._backend_path(name, path)))
            return {"names": names}
        if operation == "setxattr":
            path = _volume_path(request.get("path"))
            xattr = _string(request.get("name"), "name", maximum=255)
            policy = request.get("policy", "set")
            if policy not in _XATTR_POLICIES:
                raise OSError(errno.EINVAL, "Unknown xattr policy.")
            target = self._backend_path(name, path)
            if policy == "delete":
                if xattr == _MACOS_QUARANTINE_XATTR:
                    backend.removexattr(target, xattr)
                elif _discardable_macos_xattr(xattr):
                    backend.getattr(target)
                else:
                    raise OSError(_ENOATTR, "The extended attribute does not exist.")
                return {}
            value = payload if payload is not None else b""
            if len(value) > MAX_XATTR_BYTES:
                raise OSError(errno.E2BIG, "The extended attribute is too large.")
            # Finder's quarantine marker is security-relevant and must follow
            # the exact staged inode through publication. Other cosmetic
            # Finder hints are acknowledged; application-owned xattrs remain
            # explicit ENOTSUP failures rather than being silently discarded.
            if xattr == _MACOS_QUARANTINE_XATTR:
                options = 0
                if policy == "create":
                    options |= getattr(os, "XATTR_CREATE", 2)
                elif policy == "replace":
                    options |= getattr(os, "XATTR_REPLACE", 4)
                backend.setxattr(target, xattr, value, options, 0)
            elif _discardable_macos_xattr(xattr):
                backend.getattr(target)
            else:
                raise OSError(errno.ENOTSUP, "The extended attribute is unsupported.")
            return {}
        raise OSError(errno.ENOSYS, f"Unknown bridge operation {operation!r}.")

    def _setattr(
        self, session: _VolumeSession, name: str, request: Mapping[str, Any]
    ) -> dict[str, Any]:
        path = _volume_path(request.get("path"))
        target = self._backend_path(name, path)
        handle = _optional_integer(request, "handle", minimum=1)
        if handle is not None:
            self._require_handle(session, {"handle": handle})
        consumed: list[str] = []
        size = _optional_integer(request, "size")
        uid = _optional_integer(request, "uid")
        gid = _optional_integer(request, "gid")
        if uid is not None and uid != os.getuid():
            raise OSError(errno.EPERM, "Meshia files always belong to the mounting user.")
        if gid is not None and gid != os.getgid():
            raise OSError(errno.EPERM, "Meshia files always belong to the mounting group.")
        if size is not None:
            node = self.backend.getattr(target)
            if node.is_directory:
                raise OSError(errno.EISDIR, "Directories cannot be truncated.")
            if size != node.size_bytes:
                self.backend.truncate(target, size, handle=handle)
            consumed.append("size")
        else:
            # Fabric is a per-user content projection rather than a POSIX
            # metadata store. Finder/cp finish a copy by replaying mode and
            # timestamps; acknowledge those hints after proving the target
            # exists, exactly as the FUSE adapter does.
            self.backend.getattr(target)
        for field in ("mode", "flags", "atime_ns", "mtime_ns", "ctime_ns", "birthtime_ns"):
            if request.get(field) is not None:
                consumed.append(field)
        if uid is not None:
            consumed.append("uid")
        if gid is not None:
            consumed.append("gid")
        return {"consumed": consumed, "attrs": self._getattr(name, path)}

    def _statfs(self, name: str) -> dict[str, int]:
        backend = self.backend
        local_capacity = getattr(backend, "local_stage_statfs", None)
        local: tuple[int, int] | None = (
            local_capacity() if callable(local_capacity) else None
        )
        capacity = getattr(backend, "statfs_capacity", None)
        remote: tuple[int, int] | None = None
        if callable(capacity):
            try:
                remote = capacity(f"/{name}")
            except TypeError:
                remote = capacity()
        if remote is not None:
            total_bytes, used_bytes = remote
            remote_free = max(0, total_bytes - used_bytes)
            available = remote_free
            if local is not None:
                _local_total, local_safe = local
                available = min(remote_free, local_safe)
            return {
                "block_size": MOUNT_IO_BYTES,
                "io_size": MOUNT_IO_BYTES,
                "total_bytes": int(total_bytes),
                "free_bytes": int(remote_free),
                "available_bytes": int(available),
                "used_bytes": int(used_bytes),
                "total_files": MAX_DIRECTORY_ENTRIES,
                "free_files": MAX_DIRECTORY_ENTRIES,
            }
        storage_root = getattr(backend, "storage_root", None)
        if local is None:
            usage = shutil.disk_usage(storage_root or Path.home())
            local_total = int(usage.total)
            local_safe = max(0, int(usage.free) - MOUNT_MIN_FREE_BYTES)
        else:
            local_total, local_safe = local
        return {
            "block_size": MOUNT_IO_BYTES,
            "io_size": MOUNT_IO_BYTES,
            "total_bytes": int(local_total),
            "free_bytes": int(local_safe),
            "available_bytes": int(local_safe),
            "used_bytes": int(max(0, local_total - local_safe)),
            "total_files": MAX_DIRECTORY_ENTRIES,
            "free_files": MAX_DIRECTORY_ENTRIES,
        }


# ------------------------------------------------------------------ framing


class _ConnectionClosed(Exception):
    """The peer closed the socket between requests (a normal end of session)."""


def _receive_exact(connection: socket.socket, size: int) -> bytes:
    result = bytearray()
    while len(result) < size:
        chunk = connection.recv(min(size - len(result), 1024 * 1024))
        if not chunk:
            raise FSKitBridgeError("the bridge frame ended early")
        result.extend(chunk)
    return bytes(result)


def _receive_header(connection: socket.socket, limit: int) -> Mapping[str, Any]:
    prefix = bytearray()
    while len(prefix) < 4:
        chunk = connection.recv(4 - len(prefix))
        if not chunk:
            if prefix:
                raise FSKitBridgeError("the bridge frame ended early")
            raise _ConnectionClosed()
        prefix.extend(chunk)
    length = struct.unpack(">I", prefix)[0]
    if not 2 <= length <= limit:
        raise FSKitBridgeError("the bridge header frame is out of bounds")
    document = json.loads(_receive_exact(connection, length).decode("utf-8"))
    if not isinstance(document, Mapping):
        raise FSKitBridgeError("the bridge header is not an object")
    return document


def _send_header(connection: socket.socket, document: Mapping[str, Any]) -> None:
    payload = json.dumps(
        document, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    if len(payload) > MAX_RESPONSE_HEADER_BYTES:
        raise FSKitBridgeError("the bridge response is too large")
    connection.sendall(struct.pack(">I", len(payload)) + payload)


class FSKitBridgeClient:
    """Minimal synchronous client used by tests and the node's own probes.

    The Swift extension implements the same framing; keeping a Python client
    in the package lets ``meshia-node`` verify a live bridge without FSKit.
    """

    def __init__(self, socket_path: Path | str, *, timeout: float = 30.0) -> None:
        self.socket_path = str(Path(socket_path).expanduser())
        self._socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._socket.settimeout(timeout)
        self._socket.connect(self.socket_path)
        self._next_id = 1

    def close(self) -> None:
        try:
            self._socket.close()
        except OSError:
            pass

    def __enter__(self) -> "FSKitBridgeClient":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def call(
        self, op: str, payload: bytes | None = None, **fields: Any
    ) -> tuple[Mapping[str, Any], bytes | None]:
        """Send one request and return ``(response, payload)``.

        Raises ``OSError`` with the bridge errno when the operation failed.
        """

        document: dict[str, Any] = {"op": op, "id": self._next_id, **fields}
        self._next_id += 1
        if payload is not None:
            document["payload_bytes"] = len(payload)
        _send_header(self._socket, document)
        if payload is not None:
            self._socket.sendall(payload)
        response = _receive_header(self._socket, MAX_RESPONSE_HEADER_BYTES)
        if response.get("schema") != BRIDGE_SCHEMA:
            raise FSKitBridgeError("unexpected bridge schema")
        if not response.get("ok"):
            number = int(response.get("errno") or errno.EIO)
            raise OSError(number, str(response.get("message") or errno.errorcode.get(number, "EIO")))
        data: bytes | None = None
        declared = response.get("payload_bytes")
        if declared is not None:
            data = _receive_exact(self._socket, int(declared))
        return response, data

    def hello(self, volume_id: str) -> Mapping[str, Any]:
        response, _ = self.call("hello", volume=volume_id, protocol=BRIDGE_PROTOCOL)
        return response


__all__ = [
    "BRIDGE_PROTOCOL",
    "BRIDGE_SCHEMA",
    "FSKitBridgeClient",
    "FSKitBridgeError",
    "FSKitBridgeServer",
    "MAX_PAYLOAD_BYTES",
    "ROOT_ITEM_ID",
    "VolumeSpec",
    "backend_volume_catalog",
    "item_identifier",
    "node_attributes",
]
