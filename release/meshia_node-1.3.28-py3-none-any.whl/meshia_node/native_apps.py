"""HTTP apps owned by a connected node's existing native execution lane.

The workspace lab-app registry is display metadata, never process authority.
Live ownership, reserved sockets and renewable grants stay in memory; restarting
the node cannot adopt a PID, listener or launch command from workspace files.
"""
from __future__ import annotations

import base64
import binascii
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from datetime import datetime
import http.client
import hashlib
import json
from pathlib import Path
import re
import socket
import threading
import time
from typing import Any
import uuid

from .errors import Disconnected, MeshiaNodeError, UnsafePath
from .executor import CommandOutcome, CompletionOutbox
from .native_app_http import (AppError, AppResponse, MAX_CHUNK_BYTES, MAX_RESPONSE_BYTES,
                              TOMBSTONE_SECONDS)
from .native_app_websocket import AppWebSocket, MAX_MESSAGE_BYTES
from .native_app_upload import AppUpload, MAX_UPLOAD_BYTES
from .util import POSTGRES_UUID_RE, iso8601

APP_COMMANDS = ("app_control", "app_http")
HTTP_OPERATIONS = ("open", "read", "close", "write")
WS_OPERATIONS = ("ws_open", "ws_send", "ws_read", "ws_close")
APP_PROTOCOL = "http-stream-v1"
CAPABILITIES = {"http": True, "sse": True, "websocket": True,
                "response_bytes": MAX_RESPONSE_BYTES, "chunk_bytes": MAX_CHUNK_BYTES,
                "request_bytes": MAX_UPLOAD_BYTES, "request_chunk_bytes": MAX_CHUNK_BYTES,
                "websocket_message_bytes": MAX_MESSAGE_BYTES}
MAX_APPS = 4
MAX_HTTP_REQUESTS = 4
STREAM_POLL_SECONDS = 0.5
ORDINARY_POLL_SECONDS = 2.0
MAX_REQUEST_BYTES = 256 * 1024
MAX_REGISTRY_BYTES = 256 * 1024
HTTP_SECONDS = 10
GRANT_SECONDS = 15
APP_ID = re.compile(r"[a-z0-9][a-z0-9-]{1,63}\Z")
HEADER_NAME = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+\Z")
REQUEST_HEADERS = frozenset({"accept", "accept-language", "content-type", "if-none-match",
    "if-modified-since", "range", "if-range", "cache-control", "last-event-id",
    "cookie", "origin", "referer", "x-csrftoken", "x-csrf-token", "x-xsrf-token", "x-requested-with",
    "host", "x-forwarded-host", "x-forwarded-proto"})
RESPONSE_HEADERS = frozenset({"content-type", "content-language", "content-disposition",
    "cache-control", "etag", "last-modified", "expires", "vary", "accept-ranges", "content-range", "content-length", "location"})


def require(condition, message, code="APP_REQUEST_INVALID", status=400):
    if not condition:
        raise AppError(code, message, status)


def app_id(value):
    require(isinstance(value, str) and APP_ID.fullmatch(value), "Invalid app_id.")
    return value


def port_number(value):
    require(type(value) is int and 9000 <= value <= 9099, "App ports must be in 9000–9099.")
    return value


def utc_seconds(value):
    require(isinstance(value, str) and len(value) <= 64, "App command has no expiry.")
    try:
        instant = datetime.fromisoformat(value.replace("Z", "+00:00"))
        require(instant.utcoffset() is not None, "App command expiry must include UTC offset.")
        return instant.timestamp()
    except ValueError:
        raise AppError("APP_REQUEST_INVALID", "Invalid app command expiry.") from None


@dataclass(frozen=True)
class AppFence:
    host_id: str
    host_generation: int
    session_id: str
    attachment_id: str
    attachment_connection_generation: int
    access_revision: int
    access_mode: str

    @classmethod
    def from_command(cls, command, config):
        payload = command.get("payload")
        require(isinstance(payload, dict), "App payload must be an object.")
        kind = command.get("command_type")
        require(kind in APP_COMMANDS and payload.get("schema") == f"meshia.connected_host_{kind}.v1",
                "Unsupported native app protocol.")
        common = {"schema", "host_generation", "attachment_id", "attachment_connection_generation", "access_revision"}
        allowed = common | {"operation", "arguments"}
        if kind == "app_http":
            require(payload.get("operation") in HTTP_OPERATIONS + WS_OPERATIONS, "Unsupported app stream operation.")
            allowed = common | {"app_id", "instance_id", "port", "operation", "stream_id"}
            if payload["operation"] == "open":
                allowed |= {"method", "path", "query", "headers", "body_base64", "body_staged"}
            elif payload["operation"] == "read":
                allowed |= {"sequence", "max_bytes"}
            elif payload["operation"] == "write":
                allowed |= {"sequence", "body_base64", "end_of_body"}
            elif payload["operation"] == "ws_open":
                allowed |= {"path", "query", "headers", "subprotocols"}
            elif payload["operation"] == "ws_send":
                allowed |= {"sequence", "message_type", "body_base64", "end_of_message"}
            elif payload["operation"] == "ws_read":
                allowed |= {"sequence", "max_bytes"}
            elif payload["operation"] == "ws_close":
                allowed |= {"close_code", "close_reason"}
        require(set(payload) <= allowed, "Unknown app command field.")
        require(command.get("host_id") == config.host_id
                and type(command.get("host_generation")) is int
                and command["host_generation"] == config.generation
                and payload.get("host_generation") == config.generation,
                "App belongs to another device generation.", "APP_AUTHORITY_CHANGED", 403)
        for name in ("session_id", "attachment_id"):
            value = command.get(name)
            require(isinstance(value, str) and POSTGRES_UUID_RE.fullmatch(value),
                    "App has no exact workspace attachment.")
        require(payload.get("attachment_id") == command["attachment_id"],
                "App attachment changed.", "APP_AUTHORITY_CHANGED", 403)
        for name in ("host_generation", "attachment_connection_generation", "access_revision"):
            require(type(payload.get(name)) is int and payload[name] >= (0 if name == "access_revision" else 1),
                    "App has no valid authority revision.")
            if name in command:
                require(command[name] == payload[name], "App authority revision differs.", "APP_AUTHORITY_CHANGED", 403)
        access = command.get("access_mode")
        require(access in ("limited", "full") and command.get("execution_scope") ==
                ("host" if access == "full" else "workspace"),
                "Apps require Workspace only or Full native compute access.", "APP_ACCESS_REFUSED", 403)
        expiry = utc_seconds(command.get("expires_at"))
        require(time.time() < expiry <= time.time() + 31,
                "App command is expired or its deadline is invalid.", "APP_REQUEST_EXPIRED", 410)
        require(type(command.get("supervision_seconds")) is int and command["supervision_seconds"] == GRANT_SECONDS,
                "App command has no bounded authority.", "APP_AUTHORITY_CHANGED", 403)
        return cls(config.host_id, config.generation, command["session_id"], command["attachment_id"],
                   payload["attachment_connection_generation"], payload["access_revision"], access)

    def fields(self):
        return {name: getattr(self, name) for name in (
            "host_id", "host_generation", "attachment_id", "attachment_connection_generation", "access_revision")}

    def active(self, name, instance):
        return {"session_id": self.session_id, **{key: value for key, value in self.fields().items()
                if key not in ("host_id", "host_generation")}, "app_id": name, "instance_id": instance}


@dataclass
class _Reservation:
    fence: AppFence
    lease: dict
    socket: socket.socket
    deadline: float


@dataclass
class _App:
    fence: AppFence
    app_id: str
    instance_id: str
    port: int
    executor: Any
    owner: Any
    deadline: float
    public: dict
    thread: threading.Thread | None = None
    done: threading.Event = field(default_factory=threading.Event)
    stopped: threading.Event = field(default_factory=threading.Event)
    sockets: set = field(default_factory=set)
    ready: bool = False
    startup_failure: str | None = None

    def active(self):
        return self.fence.active(self.app_id, self.instance_id)


class NativeApps:
    def __init__(self, *, owner_factory=None):
        if owner_factory is None:
            from .app_process import AppProcessOwner
            owner_factory = AppProcessOwner
        self.owner_factory = owner_factory
        self._lock = threading.RLock()
        self._apps: dict[tuple[str, str], _App] = {}
        self._reservations: dict[tuple[str, str], _Reservation] = {}
        self._streams: dict[str, AppResponse | AppWebSocket | AppUpload] = {}
        self._closed = threading.Event()
        self._timer = threading.Thread(target=self._watch, name="meshia-app-authority", daemon=True)
        self._timer.start()

    @property
    def has_open_streams(self):
        with self._lock:
            return any(self._stream_active(stream) for stream in self._streams.values())

    @staticmethod
    def _stream_active(stream):
        return not stream.closed and not getattr(stream, "finished", False)

    @contextmanager
    def _files(self, executor):
        if executor.command_filesystem is not None:
            with executor.command_filesystem() as filesystem:
                yield filesystem
        else:
            yield executor.workspace

    @staticmethod
    def _path(fence):
        return f".gpu-hub-internal/lab-apps/connected_host-{fence.host_id}.json"

    def _load(self, executor, fence):
        with self._files(executor) as files:
            try:
                data, truncated = files.read_file(self._path(fence), MAX_REGISTRY_BYTES)
            except FileNotFoundError:
                return {"apps": {}, "port_leases": {}}
            except UnsafePath:
                # Standalone workspace reads treat a missing parent like any
                # other unsafe walk. The existing create-only writer safely
                # creates missing parents but still refuses links/escapes and
                # cannot overwrite an existing registry.
                files.write_file(self._path(fence), b'{"apps":{},"port_leases":{}}',
                                 create_parents=True, overwrite=False)
                data, truncated = files.read_file(self._path(fence), MAX_REGISTRY_BYTES)
        require(not truncated, "App registry exceeds its bound.")
        try:
            state = json.loads(data)
        except (ValueError, UnicodeError):
            raise AppError("APP_REGISTRY_INVALID", "The workspace app registry is invalid.") from None
        require(isinstance(state, dict) and all(isinstance(state.get(key), dict)
                and len(state[key]) <= 256 for key in ("apps", "port_leases")), "Invalid app registry.")
        return state

    def _save(self, executor, fence, state):
        encoded = json.dumps(state, sort_keys=True).encode()
        require(len(encoded) <= MAX_REGISTRY_BYTES, "App registry exceeds its bound.")
        with self._files(executor) as files:
            files.write_file(self._path(fence), encoded, create_parents=True, overwrite=True)

    @staticmethod
    def _result(status, **fields):
        return {"schema": "meshia.connected_host_app_control_result.v1", "status": status,
                "capabilities": dict(CAPABILITIES), **fields}

    def retains(self, executor):
        with self._lock:
            return any(app.executor is executor and not app.done.is_set() for app in self._apps.values())

    def active(self):
        with self._lock:
            return [app.active() for app in self._apps.values() if not app.stopped.is_set() and not app.done.is_set()]

    def renew(self, receipts, started, requested):
        require(isinstance(receipts, list) and len(receipts) <= MAX_APPS,
                "App supervision response is invalid.", "APP_AUTHORITY_CHANGED", 403)
        with self._lock:
            for identity in requested:
                app = self._apps.get((identity["session_id"], identity["app_id"]))
                if app is None or app.instance_id != identity["instance_id"]:
                    continue
                matches = [item for item in receipts if isinstance(item, dict)
                           and all(item.get(key) == value for key, value in identity.items())]
                if (len(matches) != 1 or matches[0].get("continue") is not True
                        or matches[0].get("supervision_seconds") != GRANT_SECONDS
                        or started + GRANT_SECONDS <= time.monotonic() or app.stopped.is_set()):
                    self._stop(app)
                else:
                    app.deadline = started + GRANT_SECONDS

    def _stop(self, app):
        if app.stopped.is_set():
            return
        app.stopped.set()
        app.ready = False
        app.executor.close()  # Retained native ownership; never look up a PID by port.
        for stream in self._streams.values():
            if stream.app is app:
                stream.close(AppError("APP_AUTHORITY_CHANGED", "App response authority ended.", 403))
        for connection in list(app.sockets):
            try:
                connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            connection.close()

    def cancel(self):
        self._closed.set()
        self.revoke()

    def revoke(self):
        """Retire current authority without disabling later owner-approved apps."""
        with self._lock:
            for app in self._apps.values():
                self._stop(app)
            for lease in self._reservations.values():
                lease.socket.close()
            self._reservations.clear()

    def close(self):
        self.cancel()
        self._timer.join(timeout=1)
        deadline = time.monotonic() + 8
        with self._lock:
            apps = list(self._apps.values())
            streams = list(self._streams.values())
        for app in apps:
            if app.thread is not None:
                app.thread.join(timeout=max(0, deadline - time.monotonic()))
        for stream in streams:
            stream.close()
            for name in ("reader", "watch"):
                worker = getattr(stream, name, None)
                if worker is not None:
                    worker.join(timeout=max(0, deadline - time.monotonic()))

    def _watch(self):
        while not self._closed.wait(0.05):
            with self._lock:
                for stream_id, stream in list(self._streams.items()):
                    stream.expire(time.monotonic())
                    if stream.closed_at is not None and time.monotonic() >= stream.closed_at + TOMBSTONE_SECONDS:
                        del self._streams[stream_id]
                for app in list(self._apps.values()):
                    if time.monotonic() >= app.deadline or app.done.is_set():
                        self._stop(app)
                    if app.done.is_set():
                        self._apps.pop((app.fence.session_id, app.app_id), None)
                for key, lease in list(self._reservations.items()):
                    if time.monotonic() >= lease.deadline:
                        lease.socket.close()
                        del self._reservations[key]

    def control(self, command, fence, executor, prepared, started):
        require(not self._closed.is_set(), "Node app control is closed.", "APP_NOT_RUNNING", 410)
        payload = command["payload"]
        operation, arguments = payload.get("operation"), payload.get("arguments")
        require(isinstance(arguments, dict), "App arguments must be an object.")
        if operation in ("unregister_lab_app", "release_lab_app_port"):
            return self._remove(operation, app_id(arguments.get("app_id")), fence, executor)
        if operation == "register_lab_app":
            # Check before loading metadata: its ordinary mutation lease may
            # otherwise wait through an unrelated startup/adoption recovery.
            self._wait_for_launch_workspace(arguments, fence, executor, prepared, started)
        # Only the one control worker accesses durable display metadata.
        state = self._load(executor, fence)
        require(not executor._closed and not self._closed.is_set(), "App control authority ended.", "APP_AUTHORITY_CHANGED", 403)
        if operation == "list_lab_apps":
            # Workspace metadata is user-editable. Return only the private
            # live instance, never attributes adopted from that document.
            with self._lock:
                visible = [{"app_id": app.app_id, **self._public_entry(app.public)}
                           for app in self._apps.values() if app.fence == fence and app.ready
                           and not app.stopped.is_set() and not app.done.is_set()]
            for name, entry in state["apps"].items():
                if not isinstance(entry, dict) or not APP_ID.fullmatch(name):
                    continue
                entry["status"] = "stopped"
            for entry in visible:
                state["apps"][entry["app_id"]] = {key: value for key, value in entry.items() if key != "app_id"}
            self._save(executor, fence, state)
            return self._result("listed", apps=visible)
        name = app_id(arguments.get("app_id"))
        key = (fence.session_id, name)
        if operation == "reserve_lab_app_port":
            requested = arguments.get("requested_port")
            title = arguments.get("title", name)
            require(isinstance(title, str) and len(title) <= 200, "App title exceeds its bound.")
            if requested is not None:
                port_number(requested)
            with self._lock:
                require(not executor._closed and not self._closed.is_set(), "App control authority ended.", "APP_AUTHORITY_CHANGED", 403)
                existing = self._reservations.get(key)
                if existing and existing.fence == fence:
                    return self._result("reserved", lease=dict(existing.lease))
                if existing:
                    existing.socket.close()
                    del self._reservations[key]
                require(key not in self._apps or self._apps[key].done.is_set(), "Unregister this app before reserving its port.")
                require(len(self._reservations) + sum(not app.done.is_set() for app in self._apps.values()) < MAX_APPS,
                        "This device already owns four app ports.", "APP_BUSY", 503)
                held = None
                for port in ([requested] if requested is not None else range(9000, 9100)):
                    candidate = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    try:
                        candidate.bind(("127.0.0.1", port))
                        held = candidate
                        break
                    except OSError:
                        candidate.close()
                require(held is not None, "No unused app port is available.", "APP_PORT_UNAVAILABLE", 409)
                stamp = iso8601()
                lease = {"app_id": name, "port": port, "title": title or name,
                         "status": "reserved", "created_at": stamp, "updated_at": stamp, **fence.fields()}
                reservation = _Reservation(fence, lease, held, time.monotonic() + 120)
                self._reservations[key] = reservation
            try:
                state["port_leases"][name] = lease
                self._save(executor, fence, state)
            except BaseException:
                with self._lock:
                    self._reservations.pop(key, None)
                    held.close()
                raise
            return self._result("reserved", lease=dict(lease))
        if operation == "register_lab_app":
            return self._register(command, fence, executor, prepared, started, state, name)
        raise AppError("APP_REQUEST_INVALID", "Unsupported app control operation.")

    def _remove(self, operation, name, fence, executor):
        # User-editable registry corruption or a transient workspace failure
        # cannot prevent cancellation of an in-memory owned process.
        key = (fence.session_id, name)
        with self._lock:
            require(not executor._closed and not self._closed.is_set(),
                    "App control authority ended.", "APP_AUTHORITY_CHANGED", 403)
            app = self._apps.get(key)
            if operation == "release_lab_app_port":
                require(app is None or app.done.is_set(), "Unregister the running app before releasing its port.")
            if app is not None:
                self._stop(app)
            reservation = self._reservations.pop(key, None)
            if reservation:
                reservation.socket.close()
        if app is not None:
            require(app.done.wait(8), "App process cleanup has not finished.", "APP_CLEANUP_PENDING", 503)
            with self._lock:
                self._apps.pop(key, None)
        removed, registry_updated = app is not None or reservation is not None, False
        try:
            state = self._load(executor, fence)
            removed = state["port_leases"].pop(name, None) is not None or removed
            if operation == "unregister_lab_app":
                removed = state["apps"].pop(name, None) is not None or removed
            self._save(executor, fence, state)
            registry_updated = True
        except (MeshiaNodeError, OSError):
            # Preserve the malformed/unavailable document and report the
            # metadata limitation. Later list uses only private ownership.
            pass
        return self._result(("removed" if operation == "unregister_lab_app" else "released") if removed else "noop",
                            app_id=name, cleanup={"owned_process_stopped": app is None or app.done.is_set(),
                                                 "registry_updated": registry_updated})

    @staticmethod
    def _public_entry(entry):
        allowed = ("title", "description", "mode", "public", "workspace_tab", "chat_inline", "updated_at", "created_at",
                   "registration_id", "port", "proxy_base_path", "host_id", "host_generation", "attachment_id",
                   "attachment_connection_generation", "access_revision", "instance_id", "status", "protocol")
        return {key: entry[key] for key in allowed if key in entry}

    def _wait_for_launch_workspace(self, args, fence, executor, prepared, started):
        require(prepared is not None, "App launch was not prepared on the signed lane.")
        probe = executor.native_execution_readiness
        # Full host execution with an absolute cwd does not use the workspace
        # execution root. Its existing command-filesystem authority lease still
        # runs, but publication does not fence that host path.
        if probe is None or (executor.access == "full"
                             and Path(prepared.payload.get("cwd") or ".").expanduser().is_absolute()):
            return
        name, port = app_id(args.get("app_id")), port_number(args.get("port"))
        deadline = min(started + HTTP_SECONDS, started + GRANT_SECONDS)
        while True:
            with self._lock:
                require(not self._closed.is_set() and not executor._closed
                        and started + GRANT_SECONDS > time.monotonic(),
                        "App control authority ended.", "APP_AUTHORITY_CHANGED", 403)
                reservation = self._reservations.get((fence.session_id, name))
                require(reservation is not None and reservation.fence == fence
                        and reservation.lease["port"] == port and reservation.deadline > time.monotonic(),
                        "Reserve this exact app port under its current permission before registration.",
                        "APP_PORT_NOT_RESERVED", 409)
            require(time.monotonic() < deadline,
                    "Workspace publication did not finish before app startup. The port remains reserved.",
                    "APP_WORKSPACE_NOT_READY", 503)
            try:
                ready = probe()
            except (MeshiaNodeError, OSError) as error:
                raise AppError("APP_WORKSPACE_UNAVAILABLE",
                               "The selected workspace is not ready for app execution. The port remains reserved.", 409) from error
            require(not self._closed.is_set() and not executor._closed,
                    "App control authority ended.", "APP_AUTHORITY_CHANGED", 403)
            require(time.monotonic() < deadline,
                    "Workspace publication did not finish before app startup. The port remains reserved.",
                    "APP_WORKSPACE_NOT_READY", 503)
            if ready is True:
                return
            require(ready is False, "The selected workspace returned invalid execution readiness.",
                    "APP_WORKSPACE_UNAVAILABLE", 409)
            self._closed.wait(min(.05, max(0, deadline - time.monotonic())))

    def _register(self, command, fence, executor, prepared, started, state, name):
        args = command["payload"]["arguments"]
        port = port_number(args.get("port"))
        require(args.get("mode", "proxy") == "proxy" and args.get("public", False) is False
                and args.get("chat_inline", False) is False and args.get("proxy_base_path", "/") == "/",
                "Native app registration supports private HTTP proxy apps at base path / only.")
        require(prepared is not None, "App launch was not prepared on the signed lane.")
        title, description = args.get("title", name), args.get("description", "")
        require(isinstance(title, str) and len(title) <= 200 and isinstance(description, str) and len(description) <= 2000
                and type(args.get("workspace_tab", False)) is bool, "App metadata exceeds its bounds.")
        # Recheck after registry read, while the reservation is still held.
        # execute_prepared independently checks its root again after launch.
        self._wait_for_launch_workspace(args, fence, executor, prepared, started)
        with self._lock:
            require(not self._closed.is_set() and not executor._closed and started + GRANT_SECONDS > time.monotonic(),
                    "Initial app execution grant expired.", "APP_AUTHORITY_CHANGED", 403)
            reservation = self._reservations.get((fence.session_id, name))
            require(reservation is not None and reservation.fence == fence and reservation.lease["port"] == port
                    and reservation.deadline > time.monotonic()
                    and state["port_leases"].get(name) == reservation.lease,
                    "Reserve this exact app port under its current permission before registration.", "APP_PORT_NOT_RESERVED", 409)
            require(time.monotonic() < started + HTTP_SECONDS,
                    "App startup deadline expired before process creation. The port remains reserved.",
                    "APP_START_TIMEOUT", 504)
            instance = str(uuid.uuid4())
            stamp = iso8601()
            entry = {"title": title or name, "description": description, "mode": "proxy", "public": False,
                     "workspace_tab": args.get("workspace_tab", False), "chat_inline": False, "created_at": stamp,
                     "updated_at": stamp, "registration_id": uuid.uuid4().hex, "port": port, "proxy_base_path": "/",
                     **fence.fields(), "instance_id": instance, "status": "launching", "protocol": "http_stream"}
            owner = self.owner_factory()
            app = _App(fence, name, instance, port, executor, owner, started + GRANT_SECONDS, entry)
            executor.process_owner = owner
            self._apps[(fence.session_id, name)] = app
            del self._reservations[(fence.session_id, name)]
            reservation.socket.close()
        state["apps"][name] = entry
        state["port_leases"][name] = {**reservation.lease, "status": "registered", "updated_at": stamp}
        def execute():
            try:
                outcome = executor.execute_prepared(prepared)
                if type(outcome.exit_code) is int and -(2**31) <= outcome.exit_code < 2**32:
                    app.startup_failure = f"exit code {outcome.exit_code}"
                else:
                    app.startup_failure = "COMMAND_EXITED"
            except Exception as error:
                # Preserve a useful category, never exception text, workload
                # output or a traceback that could contain paths/credentials.
                code = getattr(error, "code", None)
                app.startup_failure = code if code in (
                    "STATE_ERROR", "INVALID_TASK", "UNSAFE_PATH", "LOCAL_ACCESS_REFUSED",
                    "LOCAL_TIER_REFUSED", "DISCONNECTED", "WORKSPACE_ADOPTION_REQUIRED",
                    "WORKSPACE_CLAIM_INVALID", "NETWORK_UNAVAILABLE",
                ) else "OS_ERROR" if isinstance(error, OSError) else "INTERNAL_ERROR"
            finally:
                executor.close()
                owner.close()
                app.done.set()
        try:
            # Launching authority is already retained in memory. Journaling
            # display metadata here would make our own write close the shared
            # execution-readiness gate before the child obtains its root.
            # Publish the ready entry only after authenticating its listener.
            app.thread = threading.Thread(target=execute, name="meshia-app-" + name, daemon=True)
            app.thread.start()
            deadline = min(started + HTTP_SECONDS, app.deadline)
            def check_startup():
                require(not app.done.is_set() and not app.stopped.is_set(),
                        "App exited before opening its owned port."
                        + (f" ({app.startup_failure})" if app.startup_failure else ""), "APP_START_FAILED", 502)
                require(time.monotonic() < deadline, "App did not open its owned port before the startup deadline.", "APP_START_TIMEOUT", 504)
                require(time.monotonic() < app.deadline and not self._closed.is_set(),
                        "App execution authority expired during startup.", "APP_AUTHORITY_CHANGED", 403)
            while True:
                check_startup()
                try:
                    with owner.connect(port, deadline=deadline, check=check_startup) as connection:
                        owner.verify_connection(connection, port, deadline=deadline, check=check_startup)
                    break
                except (OSError, MeshiaNodeError):
                    time.sleep(min(.05, max(0, deadline-time.monotonic())))
            with self._lock:
                require(not app.stopped.is_set() and time.monotonic() < app.deadline,
                        "App execution authority expired during startup.", "APP_AUTHORITY_CHANGED", 403)
                app.ready = True
                entry["status"] = "ready"
            self._save(executor, fence, state)
            return self._result("registered", app={"app_id": name, **entry})
        except BaseException:
            with self._lock:
                self._stop(app)
            if app.thread is None:
                owner.close()
                app.done.set()
            entry["status"] = "error"
            raise

    def http(self, payload, fence):
        name, port = app_id(payload.get("app_id")), port_number(payload.get("port"))
        operation, stream_id = payload.get("operation"), payload.get("stream_id")
        require(operation in HTTP_OPERATIONS + WS_OPERATIONS, "Unsupported app stream operation.")
        require(isinstance(stream_id, str) and POSTGRES_UUID_RE.fullmatch(stream_id), "Invalid app stream ID.")
        with self._lock:
            app = self._apps.get((fence.session_id, name))
            require(app is not None and app.fence == fence and app.port == port
                    and app.instance_id == payload.get("instance_id") and app.ready
                    and not app.stopped.is_set() and not app.done.is_set()
                    and time.monotonic() < app.deadline,
                    "The exact registered app is not running under this authority.", "APP_NOT_RUNNING", 410)
            stream = self._streams.get(stream_id)
            require(stream is None or stream.app is app, "Stream belongs to a different app instance.", "APP_AUTHORITY_CHANGED", 403)
        if operation in WS_OPERATIONS:
            return self._websocket(payload, app)
        if operation == "write":
            return self._write_upload(payload, app)
        require(stream is None or isinstance(stream, (AppResponse, AppUpload)), "Stream uses a different app protocol.", "APP_STREAM_REQUEST_CHANGED", 409)
        if operation == "close":
            with self._lock:
                stream = self._streams.get(stream_id)
                require(stream is None or stream.app is app, "Stream belongs to a different app instance.", "APP_AUTHORITY_CHANGED", 403)
                require(stream is None or isinstance(stream, (AppResponse, AppUpload)), "Stream uses a different app protocol.", "APP_STREAM_REQUEST_CHANGED", 409)
                if stream is None:
                    # A close may overtake an open whose queue outcome was
                    # ambiguous. Retain the tombstone so it cannot open later.
                    require(len(self._streams) < 128, "App stream history is busy; retry shortly.", "APP_BUSY", 503)
                    stream = self._streams[stream_id] = AppResponse(stream_id, app, None)
                stream.close()
            return {"schema": "meshia.connected_host_app_http_result.v1", "operation": "close",
                    "stream_id": stream_id, "instance_id": app.instance_id, "closed": True}
        if operation == "read":
            require(stream is not None, "App response stream is unavailable.", "APP_STREAM_CLOSED", 410)
            require(isinstance(stream, AppResponse), "Open the staged app request before reading its response.", "APP_UPLOAD_INCOMPLETE", 409)
            return stream.read(payload.get("sequence"), payload.get("max_bytes"))

        method = payload.get("method")
        require(method in ("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"),
                "Only HTTP request methods are supported.", "APP_PROTOCOL_UNSUPPORTED", 501)
        path, query = payload.get("path", "/"), payload.get("query", "")
        require(isinstance(path, str) and path.startswith("/") and not path.startswith("//")
                and isinstance(query, str) and len(path) + len(query) <= 8192
                and not any(ord(c) < 32 or ord(c) == 127 or c in "#\\" for c in path + query)
                and "?" not in path, "App request must use a bounded relative path and query.")
        headers = payload.get("headers", {})
        require(isinstance(headers, dict) and len(headers) <= 32, "Invalid app HTTP headers.")
        outgoing = {}
        for key, value in headers.items():
            require(isinstance(key, str) and HEADER_NAME.fullmatch(key) and isinstance(value, str)
                    and len(value) <= 8192 and not any(ord(c) < 32 or ord(c) == 127 for c in value), "Invalid app HTTP header.")
            key = key.lower()
            require(key not in outgoing, "Duplicate app HTTP header.")
            require(key not in ("upgrade", "sec-websocket-key", "sec-websocket-version"),
                    "Use the app WebSocket operation for upgrades.", "APP_PROTOCOL_UNSUPPORTED", 501)
            require(key in REQUEST_HEADERS, "This header is not forwarded to native apps.")
            outgoing[key] = value
        require(sum(len(key) + len(value) for key, value in outgoing.items()) <= 16384, "App headers exceed their bound.")
        staged = "body_staged" in payload
        require(not staged or payload["body_staged"] is True and "body_base64" not in payload,
                "Staged requests require body_staged:true and no inline body.")
        encoded = payload.get("body_base64", "")
        require(isinstance(encoded, str) and len(encoded) <= ((MAX_REQUEST_BYTES + 2) // 3) * 4, "App body exceeds its bound.", "APP_BODY_TOO_LARGE", 413)
        try:
            body = base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error):
            raise AppError("APP_REQUEST_INVALID", "App body must be standard base64.") from None
        require(len(body) <= MAX_REQUEST_BYTES, "App body exceeds its bound.", "APP_BODY_TOO_LARGE", 413)
        fingerprint = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        with self._lock:
            stream = self._streams.get(stream_id)
            if stream is not None:
                require(stream.app is app, "Stream belongs to a different app instance.", "APP_AUTHORITY_CHANGED", 403)
                require(isinstance(stream, (AppResponse, AppUpload)), "Stream uses a different app protocol.", "APP_STREAM_REQUEST_CHANGED", 409)
                require(not stream.closed, "This app response is closed.", "APP_STREAM_CLOSED", 410)
                if isinstance(stream, AppUpload):
                    require(staged, "Open this request using its completed staged body.", "APP_STREAM_REQUEST_CHANGED", 409)
                    upload = stream
                    body, digest = upload.take()
                    fingerprint = hashlib.sha256((fingerprint + digest).encode()).hexdigest()
                    stream = self._streams[stream_id] = AppResponse(stream_id, app, fingerprint)
                    stream.upload = upload
                    stream.upload_digest = digest
                    replay = False
                else:
                    require(staged == (stream.upload is not None), "A retried open must preserve its body source.", "APP_STREAM_REQUEST_CHANGED", 409)
                    if staged:
                        fingerprint = hashlib.sha256((fingerprint + stream.upload_digest).encode()).hexdigest()
                    require(stream.fingerprint == fingerprint, "A retried open must preserve its exact request.", "APP_STREAM_REQUEST_CHANGED", 409)
                    replay = True
            else:
                require(not staged, "Stage the complete app request body before opening it.", "APP_UPLOAD_INCOMPLETE", 409)
                require(sum(self._stream_active(item) for item in self._streams.values()) < MAX_HTTP_REQUESTS
                        and len(self._streams) < 128, "This device already owns four HTTP response streams.", "APP_BUSY", 503)
                stream = self._streams[stream_id] = AppResponse(stream_id, app, fingerprint)
                replay = False
        if replay:
            return stream.metadata()
        deadline = min(stream.deadline, app.deadline)
        def check_open():
            with stream.condition:
                stream._check()
                require(not app.done.is_set() and app.fence == fence,
                        "App response authority changed.", "APP_AUTHORITY_CHANGED", 403)
                require(time.monotonic() < deadline,
                        "App response headers timed out.", "APP_HTTP_TIMEOUT", 504)
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=HTTP_SECONDS)
        # Only the retained owner may supply a socket. Never reconnect directly
        # if cancellation clears it between opening and writing the request.
        connection.auto_open = 0
        guard_socket = None
        try:
            check_open()
            connection.timeout = deadline-time.monotonic()
            stream.set_connection(connection)
            connection.sock = app.owner.connect(port, deadline=deadline, check=check_open)
            guard_socket = connection.sock
            with stream.condition:
                stream.socket = guard_socket
                stream._check()
            with self._lock:
                require(not app.stopped.is_set() and time.monotonic() < app.deadline, "App grant expired.", "APP_AUTHORITY_CHANGED", 403)
                app.sockets.add(guard_socket)
            app.owner.verify_connection(guard_socket, port, deadline=deadline, check=check_open)
            check_open()
            guard_socket.settimeout(deadline-time.monotonic())
            outgoing.update({"accept-encoding": "identity", "connection": "close"})
            connection.request(method, path + ("?" + query if query else ""), body=body, headers=outgoing)
            check_open()
            guard_socket.settimeout(deadline-time.monotonic())
            response = connection.getresponse()
            with stream.condition:
                stream.response = response
                stream._check()
            check_open()
            response_headers = response.getheaders()
            require(response.status != 101 and not any(key.lower() == "upgrade" for key, _ in response_headers),
                    "Use the app WebSocket operation for upgrades.", "APP_PROTOCOL_UNSUPPORTED", 501)
            require(len(response_headers) <= 64 and sum(len(k)+len(v) for k,v in response_headers) <= 16384,
                    "App response headers exceed their bound.", "APP_BODY_TOO_LARGE", 502)
            require(all(HEADER_NAME.fullmatch(key) and not any(ord(c) < 32 or ord(c) == 127 for c in value)
                        for key, value in response_headers), "Invalid app response header.", "APP_HTTP_UNAVAILABLE", 502)
            require(not response.getheader("content-encoding") or response.getheader("content-encoding").lower() == "identity",
                    "App must honor identity encoding for bounded HTTP streaming.", "APP_PROTOCOL_UNSUPPORTED", 501)
            length = response.getheader("content-length")
            if length is not None:
                require(re.fullmatch(r"[0-9]+", length), "Invalid app response length.", "APP_HTTP_UNAVAILABLE", 502)
                require(int(length) <= MAX_RESPONSE_BYTES or method == "HEAD" or response.status in (204, 205, 304),
                        "App response exceeds the 64 MiB transfer limit.", "APP_RESPONSE_TOO_LARGE", 413)
            safe_headers = {key.lower(): value for key, value in response_headers if key.lower() in RESPONSE_HEADERS}
            # HEAD/304 length describes the representation, not transferred
            # bytes. The bounded stream owns framing for responses with bodies.
            if not ((method == "HEAD" and response.status not in (204, 205)) or response.status == 304):
                safe_headers.pop("content-length", None)
            cookies = response.headers.get_all("Set-Cookie", [])
            require(len(cookies) <= 32, "App response has too many cookies.", "APP_HTTP_UNAVAILABLE", 502)
            stream.publish(response, safe_headers, head=method == "HEAD", set_cookies=cookies)
            return stream.metadata()
        except MeshiaNodeError as error:
            stream.close(error)
            raise
        except (OSError, ValueError, UnicodeError, http.client.HTTPException):
            error = stream.error or AppError("APP_HTTP_UNAVAILABLE", "Native app HTTP response is unavailable.", 502)
            stream.close(error)
            raise error from None
        finally:
            if stream.closed:
                connection.close()
            # The app's retained stream table owns cancellation after publish.
            # Do not grow its legacy socket set for every completed request.
            if guard_socket is not None:
                with self._lock:
                    app.sockets.discard(guard_socket)

    def _write_upload(self, payload, app):
        stream_id = payload["stream_id"]
        created = False
        with self._lock:
            stream = self._streams.get(stream_id)
            require(stream is None or stream.app is app, "Stream belongs to a different app instance.", "APP_AUTHORITY_CHANGED", 403)
            if stream is None:
                require(type(payload.get("sequence")) is int and payload["sequence"] == 0,
                        "The first upload chunk must use sequence zero.", "APP_STREAM_SEQUENCE_INVALID", 409)
                require(sum(self._stream_active(item) for item in self._streams.values()) < MAX_HTTP_REQUESTS
                        and len(self._streams) < 128, "This device already owns four app response streams.", "APP_BUSY", 503)
                stream = self._streams[stream_id] = AppUpload(stream_id, app)
                created = True
            require(not stream.closed, "This app upload is closed.", "APP_STREAM_CLOSED", 410)
            upload = stream.upload if isinstance(stream, AppResponse) else stream
            require(isinstance(upload, AppUpload), "Stream uses a different app protocol.", "APP_STREAM_REQUEST_CHANGED", 409)
        try:
            return upload.write(payload.get("sequence"), payload.get("body_base64"), payload.get("end_of_body"))
        except MeshiaNodeError as error:
            if created:
                upload.close(error)
            raise

    def _websocket(self, payload, app):
        operation, stream_id = payload["operation"], payload["stream_id"]
        fingerprint = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        with self._lock:
            stream = self._streams.get(stream_id)
            require(stream is None or stream.app is app, "Stream belongs to a different app instance.", "APP_AUTHORITY_CHANGED", 403)
            require(stream is None or isinstance(stream, AppWebSocket), "Stream uses a different app protocol.", "APP_STREAM_REQUEST_CHANGED", 409)
            if operation == "ws_close":
                new_tombstone = stream is None
                if stream is None:
                    require(len(self._streams) < 128, "App stream history is busy; retry shortly.", "APP_BUSY", 503)
                    stream = self._streams[stream_id] = AppWebSocket(stream_id, app, None)
                try:
                    return stream.close(close_code=payload.get("close_code", 1000), close_reason=payload.get("close_reason", ""))
                except MeshiaNodeError as error:
                    if new_tombstone:
                        stream.close(error)
                    raise
            if operation != "ws_open":
                require(stream is not None, "App WebSocket is unavailable.", "APP_WEBSOCKET_CLOSED", 410)
                create = False
            elif stream is not None:
                require(not stream.closed, "This app WebSocket is closed.", "APP_WEBSOCKET_CLOSED", 410)
                require(stream.fingerprint == fingerprint, "A retried open must preserve its exact request.", "APP_STREAM_REQUEST_CHANGED", 409)
                create = False
            else:
                # Admission rejection is definitive: no socket, retained entry,
                # or upstream bytes exist, so the web may retry APP_BUSY safely.
                require(sum(self._stream_active(item) for item in self._streams.values()) < MAX_HTTP_REQUESTS
                        and len(self._streams) < 128, "This device already owns four app response streams.", "APP_BUSY", 503)
                stream = self._streams[stream_id] = AppWebSocket(stream_id, app, fingerprint)
                create = True
        if operation == "ws_send":
            return stream.send(payload.get("sequence"), payload.get("message_type"),
                               payload.get("body_base64"), payload.get("end_of_message"))
        if operation == "ws_read":
            return stream.read(payload.get("sequence"), payload.get("max_bytes"))
        if not create:
            return stream.metadata()
        owned_socket = None
        try:
            remaining = min(stream.created + HTTP_SECONDS, app.deadline) - time.monotonic()
            require(remaining > 0, "App WebSocket opening timed out.", "APP_WEBSOCKET_TIMEOUT", 504)
            owned_socket = app.owner.connect(app.port, deadline=time.monotonic()+remaining)
            return stream.open(owned_socket, payload.get("path", "/"), payload.get("query", ""),
                               headers=payload.get("headers", {}), subprotocols=payload.get("subprotocols", []))
        except MeshiaNodeError as error:
            stream.close(error)
            raise
        except OSError:
            error = AppError("APP_WEBSOCKET_UNAVAILABLE", "The owned app WebSocket is unavailable.", 502)
            stream.close(error)
            raise error from None
        finally:
            if stream.closed and owned_socket is not None:
                owned_socket.close()


@dataclass
class _Request:
    command: dict
    fence: AppFence
    executor: Any
    started_at: str
    prepared: Any = None
    result: dict | None = None
    error: MeshiaNodeError | None = None
    done: threading.Event = field(default_factory=threading.Event)


class AppLoop:
    """Independent local app workers, on the existing serial signed queue lane."""
    def __init__(self, store, client, executor_factory, *, apps=None, logger=None):
        self.store, self.client, self.executor_factory = store, client, executor_factory
        self.apps = apps or NativeApps()
        self.outbox = CompletionOutbox(store.paths.outbox_dir)
        self.requests: list[_Request] = []
        self._last_app_claim = None
        self._closed = False
        self._wake = lambda: None

    def set_completion_wakeup(self, wake):
        self._wake = wake or (lambda: None)

    def cancel(self):
        self._closed = True
        self.revoke()
        self.apps.cancel()

    def revoke(self):
        self._last_app_claim = None
        self.apps.revoke()
        for request in self.requests:
            request.executor.close()

    def close(self):
        self.cancel()
        self.apps.close()
        for request in self.requests:
            request.done.wait(1)
        self._drain()

    @property
    def has_completed_command(self):
        return any(item.done.is_set() for item in self.requests)

    @property
    def has_active_command(self):
        return bool(self.requests or self.apps.active())

    @property
    def has_recent_work(self):
        return bool(self.requests or self._last_app_claim is not None
                    and time.monotonic() - self._last_app_claim < ORDINARY_POLL_SECONDS)

    def _drain(self):
        # A worker wakeup often precedes its siblings by a few milliseconds.
        # Coalesce that one bounded burst before persisting/acknowledging it,
        # rather than spending one signed RPC per small browser asset. Never
        # wait without an already-completed result, or beyond one shared 100ms
        # deadline; ownership timers and the ordinary supervision lane remain
        # independent of these local worker events.
        if not self._closed and any(item.done.is_set() for item in self.requests):
            until = time.monotonic() + .1
            for item in self.requests:
                if sum(task.done.is_set() for task in self.requests) >= 4:
                    break
                if not item.done.is_set():
                    item.done.wait(max(0, until - time.monotonic()))
        for task in list(self.requests):
            if not task.done.is_set():
                continue
            outcome = CommandOutcome("succeeded", extra=task.result)
            error_code = None
            if task.error is not None:
                error_code = task.error.code
                outcome = CommandOutcome("failed", message=str(task.error), extra={"error_code": error_code,
                    "http_status": getattr(task.error, "status", 500)})
            command = task.command
            path = f"api/connected-hosts/{task.fence.host_id}/commands/{command['id']}/complete"
            self.outbox.save(command["id"], path, {"claim_token": command["claim_token"], "status": outcome.status,
                "result": outcome.result_payload(task.started_at, iso8601()), "error_code": error_code},
                app_command_type=command["command_type"])
            self.requests.remove(task)

    def poll_without_claim(self):
        self._drain()
        return self.has_active_command

    def poll_once(self):
        self._drain()
        if self._closed:
            return False
        config = self.store.require()
        active = self.apps.active()
        started = time.monotonic()
        try:
            response = self.client.post_json(f"api/connected-hosts/{config.host_id}/commands/claim", {
                "workspace_commands": True, "native_execution": True, "app_commands": True,
                "app_protocol": APP_PROTOCOL, "active_apps": active})
        except Disconnected:
            self.cancel()
            raise
        require(isinstance(response, dict), "Invalid app claim response.")
        self.apps.renew(response.get("app_supervision", []), started, active)
        if active and not self.apps.active():
            self._last_app_claim = None
        commands = response.get("commands")
        require(isinstance(commands, list) and len(commands) <= 4, "Invalid app command batch.")
        require(all(isinstance(command, dict) and all(isinstance(command.get(key), str)
                and POSTGRES_UUID_RE.fullmatch(command[key]) for key in ("id", "claim_token"))
                for command in commands), "Invalid app command identity.")
        require(all(command.get("command_type") in ("app_control", "app_http") for command in commands),
                "Invalid app command type.")
        require(len({command["id"] for command in commands}) == len(commands), "Duplicate app command identity.")
        if commands:
            self._last_app_claim = time.monotonic()
        for command in commands:
            self._dispatch(command, config, started)
        return bool(commands) or self.has_active_command

    def _dispatch(self, command, config, started):
        pending = self.outbox.load(command["id"])
        if pending is not None:
            body = dict(pending["body"], claim_token=command["claim_token"])
            self.outbox.save(command["id"], pending["path"], body, app_command_type=command["command_type"])
            return True
        # There must never be two side effects for the same retried claim.
        if any(item.command["id"] == command["id"] for item in self.requests):
            return True
        executor = None
        try:
            fence = AppFence.from_command(command, config)
            executor = self.executor_factory(command)
            kind = command["command_type"]
            busy = sum(item.command["command_type"] == kind and not item.done.is_set() for item in self.requests)
            require(busy < (MAX_HTTP_REQUESTS if kind == "app_http" else 1), "Native app request slots are occupied.", "APP_BUSY", 503)
            task = _Request(command, fence, executor, iso8601())
            if kind == "app_control" and command["payload"].get("operation") == "register_lab_app":
                args = command["payload"].get("arguments")
                require(isinstance(args, dict), "App registration arguments must be an object.")
                task.prepared = executor.prepare_remote("exec", {"argv": args.get("launch_argv"),
                    "cwd": args.get("cwd", "."), "max_output_bytes": 65536})
                task.prepared = replace(task.prepared, environment=({"PORT": str(port_number(args.get("port")))}, ()))
        except MeshiaNodeError as error:
            if executor is not None:
                executor.close()
            outcome = CommandOutcome("failed", message=str(error), extra={"error_code": error.code,
                "http_status": getattr(error, "status", 403)})
            self.outbox.save(command["id"], f"api/connected-hosts/{config.host_id}/commands/{command['id']}/complete", {
                "claim_token": command["claim_token"], "status": "failed", "result": outcome.result_payload(iso8601(), iso8601()), "error_code": error.code},
                app_command_type=command["command_type"])
            return True
        def execute():
            try:
                require(time.time() < utc_seconds(command["expires_at"]), "App command expired before local dispatch.", "APP_REQUEST_EXPIRED", 410)
                task.result = (self.apps.http(command["payload"], task.fence) if kind == "app_http" else
                    self.apps.control(command, task.fence, task.executor, task.prepared, started))
            except MeshiaNodeError as error:
                task.error = error
            except Exception:
                task.error = AppError("APP_OPERATION_FAILED", "Native app operation failed.", 502)
            finally:
                if not self.apps.retains(task.executor):
                    task.executor.close()
                task.done.set()
                self._wake()
        self.requests.append(task)
        threading.Thread(target=execute, name="meshia-" + kind, daemon=True).start()
        return True


class AppCommandLane:
    """Compose native app work without changing normal command supervision."""
    def __init__(self, commands, apps):
        self.commands, self.apps = commands, apps
        self._next_ordinary_poll = 0.0

    @property
    def recommended_poll_seconds(self):
        manager = getattr(self.apps, "apps", None)
        streaming = manager is not None and manager.has_open_streams
        return STREAM_POLL_SECONDS if streaming or getattr(self.apps, "has_recent_work", False) else ORDINARY_POLL_SECONDS

    def set_completion_wakeup(self, wake):
        self.commands.set_completion_wakeup(wake)
        self.apps.set_completion_wakeup(wake)

    @property
    def has_completed_command(self):
        return self.commands.has_completed_command or self.apps.has_completed_command

    @property
    def has_active_command(self):
        return self.commands.has_active_command or self.apps.has_active_command

    def poll_once(self):
        # App completions share the ordinary outbox. Renew due compute work
        # before that flush-first path, otherwise a busy preview can starve
        # an unrelated research command until its independent timer expires.
        self.commands._supervise_active()
        if getattr(self.apps, "has_completed_command", False) or getattr(self.commands, "has_completed_command", False):
            # The next browser cursor cannot arrive until this result is sent.
            # Do not spend another signed request claiming its still-empty queue.
            app_work = self.apps.poll_without_claim()
            return self._poll_ordinary() or app_work
        try:
            app_work = self.apps.poll_once()
        except Disconnected:
            self.cancel()
            raise
        except MeshiaNodeError:
            # The same serial signer is used for both claims, but an app-lane
            # failure must not withhold a live research command's supervision.
            self._poll_ordinary()
            raise
        return self._poll_ordinary() or app_work

    def _poll_ordinary(self):
        # Completion wakeups can be continuous during a browser asset burst.
        # They still honor the ordinary claim clock without another app claim.
        now = time.monotonic()
        if now < self._next_ordinary_poll:
            return self.commands.poll_without_claim()
        self._next_ordinary_poll = now + ORDINARY_POLL_SECONDS
        return self.commands.poll_once()

    def poll_without_claim(self):
        self.commands._supervise_active()
        app_work = self.apps.poll_without_claim()
        return self.commands.poll_without_claim() or app_work

    def cancel(self):
        self.apps.cancel()
        self.commands.cancel()

    def close(self):
        try:
            self.apps.close()
        finally:
            self.commands.close()
