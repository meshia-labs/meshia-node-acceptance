"""Lazy account-scoped runtime orchestration for the native ``Meshia`` mount.

The control-plane catalog is the only source of visible workspace roots.  A
root is represented by a cheap proxy until an operation below that root needs
its independent Fabric runtime.  The runtime factory continues to own all
per-workspace databases, caches, staging ledgers, watchers, coordinators, and
``FabricMountBackend`` instances; this module only reconciles their lifecycle.

No control-plane or runtime-factory call is made while the mount namespace lock
is held.  ``MultiWorkspaceMountBackend`` pins a route and releases that lock
before invoking a proxy, and every potentially blocking call below similarly
runs outside this manager's state lock.
"""

from __future__ import annotations

import errno
import hashlib
import math
import os
import threading
import time
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import datetime
from typing import Any, Callable, Iterator, Mapping, Protocol

from .errors import (
    Disconnected,
    InvalidArgument,
    NetworkError,
    RemoteError,
    StateError,
)
from .fabric_mount import (
    MountNode,
    MultiWorkspaceMountBackend,
    _RemoteQuotaCapacity,
)
from .fskit_bridge import VolumeSpec
from .log import NULL_LOGGER, NodeLogger
from .workspace_catalog import (
    AccountIdentity,
    AttachmentHeartbeatRef,
    AttachmentLease,
    WorkspaceCatalogClient,
    WorkspaceCatalogEntry,
    WorkspaceCatalogSnapshot,
    WorkspaceCatalogStore,
    WorkspaceStorage,
    catalog_restart_required,
    portable_workspace_name,
)

DEFAULT_MAX_ACTIVE_WORKSPACES = 8
# A mount operation whose cold activation loses a CATALOG_CHANGED race retries
# after the scheduled refresh instead of failing the Finder operation.
CATALOG_RESTART_ATTEMPTS = 3
CATALOG_RESTART_BACKOFF_SECONDS = 0.2
DEFAULT_CATALOG_REFRESH_SECONDS = 30.0
# While a push stream reports catalog changes the periodic refresh is only a
# backstop; a push-requested refresh is still coalesced so a burst of manifest
# publishes (each bumps the catalog generation) costs one signed call.
PUSH_CATALOG_REFRESH_SECONDS = 300.0
PUSH_CATALOG_REFRESH_COALESCE_SECONDS = 5.0
# A catalog refresh is one serialized signed call; while a workspace still
# has urgent work (a push-driven remote poll followed by its apply, or a
# native write mid-commit) the refresh yields so the user-visible step is not
# delayed by a capacity/rename projection. It never yields longer than this.
PUSH_CATALOG_REFRESH_URGENT_GRACE_SECONDS = 30.0
DEFAULT_HEARTBEAT_SECONDS = 15.0
DEFAULT_FIRST_MUTATION_READY_WAIT_SECONDS = 8.0
LEASE_EXPIRY_SKEW_SECONDS = 30.0
_FIRST_MUTATION_ACTIVATION_FENCES = frozenset(
    {
        # Every cold coordinator with a staging ledger starts in repair, then
        # scans its local snapshots. These are bounded startup phases, not an
        # authority change: wait for their real readiness without bypassing it.
        "staging_repair",
        "no_head",
        "local_snapshot_recovery",
        "manifest_load",
        "startup_reconcile",
        "intent_restore",
        "overflow_recovery",
    }
)
_NEW_MUTATION_RECOVERY_FENCES = frozenset(
    {
        "attachment_rebind",
        "authority_adoption",
        "staging_repair",
        "no_head",
        "retired_evidence_recovery",
        "manifest_load",
        "startup_reconcile",
        "local_snapshot_recovery",
        "overflow_recovery",
        "intent_restore",
        "workspace_authority_refresh",
    }
)

_TERMINAL_STORAGE_CODES = frozenset({
    "WORKSPACE_STORAGE_DELETED", "WORKSPACE_STORAGE_DISABLED",
    "WORKSPACE_STORAGE_SUPERSEDED",
})


class AccountConfig(Protocol):
    """The immutable account fields required from ``NodeConfig``."""

    account_id: str | None
    account_email: str | None
    session_id: str


@dataclass(frozen=True)
class WorkspaceRuntime:
    """One factory-owned Fabric runtime and its bounded lifecycle hooks.

    ``safe_to_close`` must be a cheap, non-networking snapshot.  It should be
    false while the runtime has work that cannot yet be represented durably.
    ``close_runtime`` must preserve all already-durable pending evidence.
    """

    backend: Any
    coordinator: Any
    safe_to_close: Callable[[], bool]
    close_runtime: Callable[[], None]
    refresh_authority: Callable[[WorkspaceCatalogEntry], None] | None = None
    attachment_id: str | None = None
    has_runnable_work: Callable[[], bool] | None = None

    def can_close(self) -> bool:
        return bool(self.safe_to_close())

    def can_evict(self) -> bool:
        return bool(
            not (self.has_runnable_work and self.has_runnable_work())
            and self.safe_to_close()
        )

    def close(self) -> None:
        self.close_runtime()


WorkspaceRuntimeFactory = Callable[
    [WorkspaceCatalogEntry, str], WorkspaceRuntime
]


@dataclass(frozen=True)
class FileProviderWorkspaceProjection:
    """One catalog-visible root in the account-wide File Provider domain.

    ``session_id`` is routing authority and never a pathname. ``name`` is the
    current portable catalog projection and may change without changing the
    File Provider item identity derived from the immutable session id.
    """

    session_id: str
    name: str
    name_revision: int
    access: str
    modified_at: str | None


@dataclass(frozen=True)
class FileProviderCatalogProjection:
    """Atomic catalog view used to enumerate the native domain root."""

    account_id: str
    generation: int
    workspaces: tuple[FileProviderWorkspaceProjection, ...]


@dataclass(frozen=True)
class StartupRecoveryScan:
    """Bounded local evidence that needs a lazy runtime after restart.

    ``session_ids`` contains only exact, account-scoped journals with runnable
    local publication work. ``unavailable_workspace_count`` and ``saturated``
    deliberately keep startup operational while making an incomplete scan
    fail health closed instead of silently leaving uploads dormant.
    """

    session_ids: tuple[str, ...] = ()
    unavailable_workspace_count: int = 0
    saturated: bool = False


StartupRecoveryScanner = Callable[[frozenset[str], int], StartupRecoveryScan]


@dataclass
class _ActiveRuntime:
    runtime: WorkspaceRuntime
    last_used: float
    authority_attachment_id: str | None
    active_calls: int = 0
    open_handles: int = 0
    first_mutation_wait_available: bool = False
    waited_fence_generation: tuple[str, object] | None = None
    mutation_wait_deadline: float | None = None


class _LazyWorkspaceBackend:
    """A ``FabricMountBackend``-shaped proxy that does no work at mount root."""

    def __init__(
        self,
        manager: "WorkspaceRuntimeManager",
        session_id: str,
        workspace_name: str,
        storage: WorkspaceStorage,
        catalog_generation: int,
    ) -> None:
        self._manager = manager
        self._session_id = session_id
        self._name_lock = threading.Lock()
        self._workspace_name = workspace_name
        self._storage = storage
        self._catalog_generation = catalog_generation
        self._remote_quota = _RemoteQuotaCapacity()
        self._remote_quota.update_catalog(
            catalog_generation=catalog_generation,
            quota_bytes=storage.quota_bytes,
            used_bytes=storage.used_bytes,
            reserved_bytes=storage.reserved_bytes,
        )
        self._stage_capacity: Any | None = None

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def workspace_storage(self) -> WorkspaceStorage:
        with self._name_lock:
            return self._storage

    @property
    def catalog_generation(self) -> int:
        with self._name_lock:
            return self._catalog_generation

    @property
    def workspace_name(self) -> str:
        with self._name_lock:
            return self._workspace_name

    def set_workspace_name(self, value: str) -> None:
        with self._name_lock:
            self._workspace_name = value

    def set_workspace_storage(
        self, value: WorkspaceStorage, *, catalog_generation: int
    ) -> None:
        with self._name_lock:
            self._storage = value
            self._catalog_generation = catalog_generation
        self._remote_quota.update_catalog(
            catalog_generation=catalog_generation,
            quota_bytes=value.quota_bytes,
            used_bytes=value.used_bytes,
            reserved_bytes=value.reserved_bytes,
        )

    def set_stage_capacity(self, capacity: Any) -> None:
        """Carry the mount-wide local admission fence through lazy activation."""

        # MultiWorkspaceMountBackend owns one immutable capacity object for its
        # whole lifetime and reapplies it on every catalog projection.  Avoid
        # taking the activation lock for that overwhelmingly common no-op: a
        # cold activation may itself be waiting for the projection to finish.
        with self._name_lock:
            if self._stage_capacity is capacity:
                return
        with self._manager._activation_lock:  # noqa: SLF001 - lifecycle pair
            with self._name_lock:
                if self._stage_capacity is capacity:
                    return
                self._stage_capacity = capacity
            with self._manager._lock:  # noqa: SLF001 - lifecycle pair
                active = self._manager._active.get(self._session_id)  # noqa: SLF001
            if active is not None:
                setter = getattr(active.runtime.backend, "set_stage_capacity", None)
                if not callable(setter):
                    raise StateError("The workspace backend cannot share stage capacity.")
                setter(capacity)

    @property
    def stage_capacity(self) -> Any | None:
        with self._name_lock:
            return self._stage_capacity

    def statfs_capacity(self) -> tuple[int, int] | None:
        """Return authoritative remote quota and used bytes without activation."""

        return self._remote_quota.snapshot()

    @property
    def remote_quota(self) -> _RemoteQuotaCapacity:
        return self._remote_quota

    def _call(
        self,
        operation: str,
        *args: Any,
        require_visible: bool = True,
        require_mutation_ready: bool = False,
        **kwargs: Any,
    ) -> Any:
        return self._manager.run_pinned(
            self._session_id,
            lambda runtime: getattr(runtime.backend, operation)(*args, **kwargs),
            require_visible=require_visible,
            require_mutation_ready=require_mutation_ready,
        )

    def getattr(self, path: str) -> MountNode:
        return self._call("getattr", path)

    def listdir(self, path: str) -> tuple[str, ...]:
        return self._call("listdir", path)

    def listdir_entries(self, path: str) -> tuple[tuple[str, MountNode], ...]:
        # readdir-plus. This proxy forwards an explicit method per operation
        # because each carries distinct runtime-borrow semantics (visibility
        # fences, mutation-ready gates, handle recording); a blanket __getattr__
        # would apply the wrong ones to a future write/handle method. So new
        # mount-surface methods MUST be added here. Omitting this one made every
        # workspace readdir raise AttributeError inside _call, which -- not being
        # a MOUNT_ADAPTER_ERROR -- escaped untranslated and fusepy rendered as a
        # silent EACCES. It reads like listdir: a visible workspace, no mutation.
        return self._call("listdir_entries", path)

    def open(self, path: str, flags: int, *, create: bool = False) -> int:
        try:
            active = self._manager._borrow_runtime(  # noqa: SLF001
                self._session_id, require_visible=True
            )
        except (
            Disconnected,
            InvalidArgument,
            NetworkError,
            RemoteError,
            StateError,
        ) as error:
            raise self._manager._mount_error(error, self._session_id) from error  # noqa: SLF001
        try:
            try:
                self._manager._require_new_mutation_ready(  # noqa: SLF001
                    self._session_id, active, namespace_only=True
                )
                writable = bool(
                    create
                    or flags & (os.O_CREAT | os.O_TRUNC | os.O_APPEND)
                    or flags & (os.O_WRONLY | os.O_RDWR)
                )
                if writable:
                    self._manager._require_new_mutation_ready(  # noqa: SLF001
                        self._session_id, active
                    )
                handle = active.runtime.backend.open(path, flags, create=create)
            except (
                Disconnected,
                InvalidArgument,
                NetworkError,
                RemoteError,
                StateError,
            ) as error:
                raise self._manager._mount_error(error, self._session_id) from error  # noqa: SLF001
            try:
                self._manager._record_open_handle(self._session_id, active)  # noqa: SLF001
            except BaseException:
                # Shutdown may fence new handles after the backend open but
                # before global-handle publication. Never leak that local fd.
                active.runtime.backend.release(handle)
                raise
            return handle
        finally:
            self._manager._return_runtime(self._session_id, active)  # noqa: SLF001

    def read(self, handle: int, offset: int, size: int) -> bytes:
        return self._call(
            "read", handle, offset, size, require_visible=False
        )

    def write(self, handle: int, offset: int, data: bytes) -> int:
        return self._call(
            "write", handle, offset, data, require_visible=False
        )

    def truncate(
        self, path: str, length: int, *, handle: int | None = None
    ) -> None:
        if handle is None:
            self._call(
                "truncate", path, length, require_mutation_ready=True
            )
            return
        self._call(
            "truncate",
            path,
            length,
            handle=handle,
            require_visible=False,
        )

    def fsync(self, handle: int) -> None:
        self._call("fsync", handle, require_visible=False)

    def flush(self, handle: int) -> None:
        self._call("flush", handle, require_visible=False)

    def release(self, handle: int) -> None:
        try:
            active = self._manager._borrow_runtime(  # noqa: SLF001
                self._session_id,
                require_visible=False,
                allow_fenced_handle=True,
                release_retired_handle=True,
            )
        except (Disconnected, InvalidArgument, NetworkError, RemoteError, StateError) as error:
            raise self._manager._mount_error(error, self._session_id) from error  # noqa: SLF001
        try:
            try:
                active.runtime.backend.release(handle)
            except (Disconnected, InvalidArgument, NetworkError, RemoteError, StateError) as error:
                raise self._manager._mount_error(error, self._session_id) from error  # noqa: SLF001
        finally:
            self._manager._record_closed_handle(self._session_id, active)  # noqa: SLF001
            self._manager._return_runtime(self._session_id, active)  # noqa: SLF001

    def unlink(self, path: str) -> None:
        try:
            active = self._manager._borrow_runtime(  # noqa: SLF001
                self._session_id, require_visible=True
            )
        except (
            Disconnected,
            InvalidArgument,
            NetworkError,
            RemoteError,
            StateError,
        ) as error:
            raise self._manager._mount_error(error, self._session_id) from error  # noqa: SLF001
        try:
            try:
                self._manager._require_new_mutation_ready(  # noqa: SLF001
                    self._session_id, active
                )
            except OSError as error:
                if error.errno != errno.EAGAIN:
                    raise
                # FUSE-T 1.2.7 discards transient unlink errors during SMB
                # CLOSE. The callback itself is deletion authority, so retain
                # that intent locally and let Fabric retry it after recovery.
                active.runtime.backend.defer_unlink(path)
                self._manager.wake()
                return
            try:
                active.runtime.backend.unlink(path)
            except OSError as error:
                if error.errno != errno.EAGAIN:
                    raise
                # Admission can also advance between the readiness check and
                # the coordinator handoff. Retain that same explicit unlink;
                # the old SMB bridge will otherwise acknowledge and discard it.
                active.runtime.backend.defer_unlink(path)
                self._manager.wake()
                return
            except (
                Disconnected,
                InvalidArgument,
                NetworkError,
                RemoteError,
                StateError,
            ) as error:
                raise self._manager._mount_error(error, self._session_id) from error  # noqa: SLF001
        finally:
            self._manager._return_runtime(self._session_id, active)  # noqa: SLF001

    def mkdir(self, path: str) -> None:
        self._call("mkdir", path, require_mutation_ready=True)

    def rmdir(self, path: str) -> None:
        self._call("rmdir", path, require_mutation_ready=True)

    def getxattr(self, path: str, name: str, position: int = 0) -> bytes:
        return bytes(self._call("getxattr", path, name, position))

    def listxattr(self, path: str) -> list[str]:
        return list(self._call("listxattr", path))

    def setxattr(
        self,
        path: str,
        name: str,
        value: bytes,
        options: int,
        position: int = 0,
    ) -> None:
        self._call(
            "setxattr",
            path,
            name,
            value,
            options,
            position,
            require_mutation_ready=True,
        )

    def removexattr(self, path: str, name: str) -> None:
        self._call(
            "removexattr", path, name, require_mutation_ready=True
        )

    def set_times(self, path: str, times: Any | None = None) -> None:
        self._call("set_times", path, times, require_mutation_ready=True)

    def rename(self, source: str, destination: str) -> None:
        if source == f"/{self.workspace_name}" and destination.count("/") == 1:
            try:
                self._manager._rename_workspace_root(  # noqa: SLF001
                    self._session_id, self.workspace_name, destination[1:]
                )
            except (Disconnected, InvalidArgument, NetworkError, RemoteError, StateError) as error:
                raise self._manager._mount_error(error, self._session_id) from error  # noqa: SLF001
            return
        self._call(
            "rename", source, destination, require_mutation_ready=True
        )

    def close(self) -> None:
        # Route retirement is not necessarily process shutdown.  Open handles
        # are pinned by MultiWorkspaceMountBackend; pending durable work can be
        # retained until its runtime reports that an idle close is safe.
        self._manager._route_retired(self._session_id, self)  # noqa: SLF001


class WorkspaceRuntimeManager:
    """Project and maintain one authenticated account's workspace runtimes."""

    def __init__(
        self,
        *,
        config: AccountConfig,
        catalog_client: WorkspaceCatalogClient,
        catalog_store: WorkspaceCatalogStore,
        mount_backend: MultiWorkspaceMountBackend,
        runtime_factory: WorkspaceRuntimeFactory,
        primary_session_id: str | None = None,
        primary_runtime: WorkspaceRuntime | None = None,
        primary_storage_error: Disconnected | None = None,
        batch_heartbeat_primary: bool = False,
        max_active_workspaces: int = DEFAULT_MAX_ACTIVE_WORKSPACES,
        startup_recovery_scanner: StartupRecoveryScanner | None = None,
        catalog_refresh_seconds: float = DEFAULT_CATALOG_REFRESH_SECONDS,
        heartbeat_seconds: float = DEFAULT_HEARTBEAT_SECONDS,
        first_mutation_ready_wait_seconds: float = (
            DEFAULT_FIRST_MUTATION_READY_WAIT_SECONDS
        ),
        clock: Callable[[], float] = time.monotonic,
        wall_clock: Callable[[], float] = time.time,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        if (
            isinstance(max_active_workspaces, bool)
            or not isinstance(max_active_workspaces, int)
            or max_active_workspaces < 1
        ):
            raise ValueError("max_active_workspaces must be a positive integer")
        for label, value in (
            ("catalog_refresh_seconds", catalog_refresh_seconds),
            ("heartbeat_seconds", heartbeat_seconds),
        ):
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or value <= 0
            ):
                raise ValueError(f"{label} must be positive")
        if (
            isinstance(first_mutation_ready_wait_seconds, bool)
            or not isinstance(first_mutation_ready_wait_seconds, (int, float))
            or not math.isfinite(first_mutation_ready_wait_seconds)
            or first_mutation_ready_wait_seconds < 0
        ):
            raise ValueError(
                "first_mutation_ready_wait_seconds must be finite and non-negative"
            )

        if (primary_storage_error is not None
                and primary_storage_error.reason_code not in _TERMINAL_STORAGE_CODES):
            raise primary_storage_error

        self.config = config
        self.catalog_client = catalog_client
        self.catalog_store = catalog_store
        self.mount_backend = mount_backend
        self.runtime_factory = runtime_factory
        self.primary_session_id = primary_session_id or config.session_id
        self.batch_heartbeat_primary = bool(batch_heartbeat_primary)
        # An injected primary remains owned by NodeRunner unless this manager
        # was explicitly asked to heartbeat it. A lazily-created primary has
        # no external authority owner, so the catalog manager must always
        # maintain its lease even if a caller retained the default flag.
        self._catalog_owns_primary = (
            primary_runtime is None or self.batch_heartbeat_primary
        )
        self.max_active_workspaces = max_active_workspaces
        self.startup_recovery_scanner = startup_recovery_scanner
        self.catalog_refresh_seconds = float(catalog_refresh_seconds)
        self.heartbeat_seconds = float(heartbeat_seconds)
        self.first_mutation_ready_wait_seconds = float(
            first_mutation_ready_wait_seconds
        )
        self._clock = clock
        self._wall_clock = wall_clock
        self.logger = logger

        self._lock = threading.RLock()
        self._activation_lock = threading.RLock()
        self._state_condition = threading.Condition(self._lock)
        self._wake_condition = threading.Condition()
        self._wake_generation = 0
        self._consumed_wake_generation = 0
        self._urgent_sessions: deque[str] = deque()
        self._urgent_session_members: set[str] = set()
        self._snapshot: WorkspaceCatalogSnapshot | None = None
        self._entries: dict[str, WorkspaceCatalogEntry] = {}
        self._labels: dict[str, str] = {}
        self._proxies: dict[str, _LazyWorkspaceBackend] = {}
        self._active: dict[str, _ActiveRuntime] = {}
        # Exact session IDs, bounded by the signed catalog's workspace bound.
        # A visible lazy route that failed construction must degrade aggregate
        # health even though it has no active coordinator to report itself.
        self._activation_unavailable: set[str] = set()
        self._pending_primary_runtime = primary_runtime
        self._primary_storage_error = primary_storage_error
        self._pending_authority: dict[str, WorkspaceCatalogEntry] = {}
        self._retired_storage_generations: dict[str, int] = {}
        self._retired_storage_runtimes: set[str] = set()
        self._storage_projection_pending = False
        # A failed replacement construction gets at most one attempt per
        # manager turn. This prevents the heartbeat/install path and the later
        # pending-authority sweeps from immediately hammering the same broken
        # root several times before the mount can observe its EAGAIN fence.
        self._authority_recreate_deferred: set[str] = set()
        self._startup_recovery_active: set[str] = set()
        self._startup_recovery_unavailable_count = 0
        self._startup_recovery_scan_saturated = False
        self._prepared = False
        self._started = False
        self._closed = False
        self._projection_inflight = False
        self._rename_inflight = False
        self._poll_cursor: str | None = None
        self._state_version = 0
        self._readiness_version = 0
        self._next_catalog_refresh = 0.0
        self._next_heartbeat = 0.0
        self._last_catalog_refresh_at = float("-inf")
        self._push_healthy = False
        self._push_remote_poll_backstop: float | None = None
        # Armed by NodeRunner: once a stop is requested every phase below
        # yields instead of starting the next signed call or child poll.
        self._stop_check: Callable[[], bool] | None = None
        if primary_runtime is not None:
            self._bind_runtime_wake(primary_runtime, self.primary_session_id)

    def set_stop_check(self, callback: Callable[[], bool] | None) -> None:
        """Install the runner's stop predicate and hand it to every coordinator."""

        if callback is not None and not callable(callback):
            raise TypeError("stop check must be callable")
        with self._lock:
            self._stop_check = callback
            coordinators = tuple(
                active.runtime.coordinator for active in self._active.values()
            )
            pending_primary = self._pending_primary_runtime
        if pending_primary is not None:
            coordinators = coordinators + (pending_primary.coordinator,)
        for coordinator in coordinators:
            self._forward_stop_check(coordinator)

    def _forward_stop_check(self, coordinator: Any) -> None:
        setter = getattr(coordinator, "set_stop_check", None)
        if callable(setter):
            with self._lock:
                callback = self._stop_check
            setter(callback)

    def stop_requested(self) -> bool:
        with self._lock:
            callback = self._stop_check
        if callback is None:
            return False
        try:
            return bool(callback())
        except Exception:  # noqa: BLE001 - a broken predicate must not stop maintenance
            return False

    def _notify_child_wake(self, session_id: str | None = None) -> None:
        """Wake the manager and retain which child owns urgent work."""

        with self._lock:
            if (
                session_id is not None
                and session_id not in self._urgent_session_members
            ):
                self._urgent_sessions.append(session_id)
                self._urgent_session_members.add(session_id)
        with self._wake_condition:
            self._wake_generation += 1
            self._wake_condition.notify_all()

    def _bind_runtime_wake(
        self, runtime: WorkspaceRuntime, session_id: str
    ) -> None:
        setter = getattr(runtime.coordinator, "set_wake_callback", None)
        if callable(setter):
            setter(
                lambda session_id=session_id: self._notify_child_wake(session_id)
            )
        self._forward_stop_check(runtime.coordinator)
        # A runtime activated while the push stream is healthy inherits the
        # stretched idle cadence immediately.
        with self._lock:
            backstop = self._push_remote_poll_backstop if self._push_healthy else None
        if backstop is not None:
            set_backstop = getattr(runtime.coordinator, "set_remote_poll_backstop", None)
            if callable(set_backstop):
                set_backstop(backstop)

    def _catalog_refresh_interval(self) -> float:
        return PUSH_CATALOG_REFRESH_SECONDS if self._push_healthy else self.catalog_refresh_seconds

    @property
    def push_healthy(self) -> bool:
        with self._lock:
            return self._push_healthy

    def set_push_healthy(
        self, healthy: bool, *, remote_poll_backstop_seconds: float | None = None
    ) -> None:
        """Switch every collector between push-backstop and polling cadence.

        Losing the stream clamps the pending catalog deadline to today's
        interval and clears each coordinator's backstop, so the whole account
        is back on the polling cadence within one manager tick.
        """

        healthy = bool(healthy)
        backstop = (
            float(remote_poll_backstop_seconds)
            if healthy and remote_poll_backstop_seconds is not None
            else None
        )
        now = float(self._clock())
        with self._lock:
            changed = healthy != self._push_healthy or backstop != self._push_remote_poll_backstop
            self._push_healthy = healthy
            self._push_remote_poll_backstop = backstop
            if not healthy:
                self._next_catalog_refresh = min(
                    self._next_catalog_refresh, now + self.catalog_refresh_seconds
                )
            coordinators = tuple(
                active.runtime.coordinator for active in self._active.values()
            )
            pending_primary = self._pending_primary_runtime
        if pending_primary is not None:
            coordinators = coordinators + (pending_primary.coordinator,)
        for coordinator in coordinators:
            set_backstop = getattr(coordinator, "set_remote_poll_backstop", None)
            if callable(set_backstop):
                try:
                    set_backstop(backstop)
                except ValueError:
                    continue
        if changed:
            self.logger.record(
                "workspace_push_cadence", healthy=healthy, remote_poll_backstop=backstop
            )
            self._notify_child_wake()

    def notify_remote_change(self, session_id: str) -> None:
        """A push event named ``session_id``: poll its remote state on the next turn."""

        with self._lock:
            active = self._active.get(session_id)
        if active is None:
            # Not activated locally: nothing cached to invalidate; the catalog
            # projection is refreshed by its own event.
            return
        request_poll = getattr(active.runtime.coordinator, "request_remote_poll", None)
        if callable(request_poll):
            request_poll()
        else:
            wake = getattr(active.runtime.coordinator, "wake", None)
            if callable(wake):
                wake()
        self._notify_child_wake(session_id)

    def request_catalog_refresh(self) -> None:
        """A push event advanced the catalog: refresh now, coalescing bursts."""

        now = float(self._clock())
        with self._lock:
            earliest = max(
                now, self._last_catalog_refresh_at + PUSH_CATALOG_REFRESH_COALESCE_SECONDS
            )
            self._next_catalog_refresh = min(self._next_catalog_refresh, earliest)
        self._notify_child_wake()

    def volume_specs(self) -> tuple[VolumeSpec, ...]:
        """Project the visible catalog as session-id keyed FSKit volumes."""

        with self._lock:
            labels = dict(self._labels)
        return tuple(
            VolumeSpec(session_id, label)
            for session_id, label in sorted(labels.items(), key=lambda item: item[1].casefold())
        )

    @property
    def snapshot(self) -> WorkspaceCatalogSnapshot | None:
        with self._lock:
            return self._snapshot

    @property
    def file_provider_account_wide(self) -> bool:
        """Prove this manager presents the complete authenticated catalog.

        Runtime cutover uses this explicit capability instead of guessing from
        a bridge type or the number of currently visible workspaces.
        """

        return True

    def file_provider_catalog_projection(self) -> FileProviderCatalogProjection:
        """Return one atomic, activation-free account root projection.

        The persisted/live catalog is already installed atomically. Copy its
        immutable values while holding the manager lock so a File Provider
        enumeration cannot mix labels from two generations. Merely listing
        Meshia never activates a workspace runtime.
        """

        with self._lock:
            if self._closed:
                raise StateError("The workspace runtime manager is closed.")
            snapshot = self._snapshot
            entries = dict(self._entries)
            labels = dict(self._labels)
        if snapshot is None:
            raise StateError("The authenticated workspace catalog is unavailable.")
        account_id = self.config.account_id
        if account_id is None or snapshot.account.id != account_id:
            raise StateError("The workspace catalog account is unavailable.")
        workspaces = tuple(
            FileProviderWorkspaceProjection(
                session_id=session_id,
                name=labels[session_id],
                name_revision=entry.name_revision,
                access=entry.access,
                modified_at=entry.modified_at,
            )
            for session_id, entry in sorted(
                entries.items(),
                key=lambda item: (labels[item[0]].casefold(), labels[item[0]], item[0]),
            )
        )
        return FileProviderCatalogProjection(
            account_id=account_id,
            generation=snapshot.snapshot_generation,
            workspaces=workspaces,
        )

    def file_provider_active_session_ids(self) -> tuple[str, ...]:
        """Snapshot visible active routes without activating dormant roots."""

        with self._lock:
            if self._closed:
                raise StateError("The workspace runtime manager is closed.")
            return tuple(
                sorted(
                    session_id
                    for session_id in self._active
                    if session_id in self._entries
                )
            )

    def run_file_provider_operation(
        self,
        session_id: str,
        operation: Callable[[WorkspaceRuntime, FileProviderWorkspaceProjection], Any],
        *,
        require_mutation_ready: bool = False,
    ) -> Any:
        """Run one native request against an exact, visible, pinned runtime.

        The projection passed to the callback is re-read inside the runtime
        pin, so a retired workspace cannot be reached through a stale root or
        nested item identifier. New writes additionally use the same recovery
        and authority fences as Finder operations on the legacy mount.
        """

        def invoke(runtime: WorkspaceRuntime) -> Any:
            with self._lock:
                entry = self._entries.get(session_id)
                label = self._labels.get(session_id)
            if entry is None or label is None:
                raise OSError(errno.ENOENT, "The workspace is no longer available.")
            return operation(
                runtime,
                FileProviderWorkspaceProjection(
                    session_id=session_id,
                    name=label,
                    name_revision=entry.name_revision,
                    access=entry.access,
                    modified_at=entry.modified_at,
                ),
            )

        return self.run_pinned(
            session_id,
            invoke,
            require_visible=True,
            require_mutation_ready=require_mutation_ready,
        )

    @property
    def active_workspace_count(self) -> int:
        with self._lock:
            return len(self._active)

    @property
    def next_poll_delay(self) -> float:
        """Expose the earliest child or catalog deadline to the service loop."""

        now = float(self._clock())
        with self._lock:
            if self._closed:
                return float("inf")
            if self._urgent_sessions:
                return 0.0
            delays = [
                max(0.0, self._next_catalog_refresh - now),
                max(0.0, self._next_heartbeat - now),
            ]
            coordinators = tuple(
                active.runtime.coordinator
                for session_id, active in self._active.items()
                if session_id not in self._retired_storage_runtimes
            )
        for coordinator in coordinators:
            try:
                candidate = getattr(coordinator, "next_poll_delay", None)
                value = candidate() if callable(candidate) else candidate
                delay = float(value)
            except (AttributeError, TypeError, ValueError):
                continue
            if delay == delay and delay != float("inf"):
                delays.append(max(0.0, delay))
        return min(delays, default=float("inf"))

    def staging_readiness_snapshot(self) -> dict[str, int | bool]:
        """Aggregate O(1) staging readiness across active workspace runtimes."""

        with self._lock:
            active = tuple(self._active.values())
            attachment_rebind = sum(
                session_id in self._active
                for session_id in self._pending_authority
            )
            startup_recovery_active = len(self._startup_recovery_active)
            startup_recovery_unavailable = self._startup_recovery_unavailable_count
            startup_recovery_saturated = self._startup_recovery_scan_saturated
            activation_unavailable = len(self._activation_unavailable)
        repair_pending = 0
        over_capacity = 0
        unavailable = 0
        for item in active:
            candidate = getattr(
                item.runtime.coordinator, "staging_readiness_snapshot", None
            )
            if not callable(candidate):
                continue
            try:
                ready, over = candidate()
            except BaseException:
                unavailable += 1
                continue
            repair_pending += int(not bool(ready))
            over_capacity += int(bool(over))
        unavailable += startup_recovery_unavailable + activation_unavailable
        return {
            "active_workspace_count": len(active),
            "repair_pending_workspace_count": repair_pending,
            "over_capacity_workspace_count": over_capacity,
            "attachment_rebind_workspace_count": attachment_rebind,
            "health_unavailable_workspace_count": unavailable,
            "startup_recovery_active_workspace_count": startup_recovery_active,
            "startup_recovery_scan_saturated": startup_recovery_saturated,
            "all_active_workspaces_ready": not (
                repair_pending
                or over_capacity
                or attachment_rebind
                or unavailable
                or startup_recovery_active
                or startup_recovery_saturated
            ),
        }

    def _activate_startup_recovery(self) -> None:
        """Start bounded runtimes for exact dormant journals with local work."""

        scanner = self.startup_recovery_scanner
        if scanner is None:
            return
        with self._lock:
            if self._closed:
                return
            visible = frozenset(self._entries)
        try:
            scan = scanner(visible, self.max_active_workspaces)
            if (
                len(scan.session_ids) > self.max_active_workspaces
                or scan.unavailable_workspace_count < 0
            ):
                raise StateError("The startup recovery scan is invalid or unbounded.")
        except Exception as error:
            with self._lock:
                self._startup_recovery_unavailable_count = max(
                    1, self._startup_recovery_unavailable_count
                )
            self.logger.record(
                "workspace_startup_recovery_scan_failed",
                error_type=type(error).__name__,
            )
            return

        with self._lock:
            self._startup_recovery_scan_saturated = scan.saturated
            self._startup_recovery_unavailable_count = (
                scan.unavailable_workspace_count
            )
        activated = 0
        for session_id in scan.session_ids:
            try:
                # Mount dispatch and maintenance share this re-entrant lock,
                # making activation plus the recovery pin one atomic decision.
                with self._activation_lock:
                    with self._lock:
                        if session_id not in self._entries:
                            self._startup_recovery_unavailable_count += 1
                            continue
                        if session_id in self._active:
                            newly_pinned = session_id not in self._startup_recovery_active
                            self._startup_recovery_active.add(session_id)
                            activated += int(newly_pinned)
                            continue
                    active = self._borrow_runtime(
                        session_id, require_visible=True, touch=False
                    )
                    self._return_runtime(session_id, active, touch=False)
                    with self._lock:
                        self._startup_recovery_active.add(session_id)
            except Exception as error:
                if isinstance(error, OSError) and error.errno == errno.EBUSY:
                    with self._lock:
                        self._startup_recovery_scan_saturated = True
                    break
                with self._lock:
                    self._startup_recovery_unavailable_count += 1
                self.logger.record(
                    "workspace_startup_recovery_activation_failed",
                    session_id=session_id,
                    error_type=type(error).__name__,
                )
                continue
            activated += 1
        if activated:
            self.logger.record(
                "workspace_startup_recovery_discovered",
                workspace_count=activated,
            )

    def _refresh_startup_recovery(self) -> bool:
        """Release convergence pins without closing otherwise reusable runtimes."""

        with self._lock:
            candidates = tuple(sorted(self._startup_recovery_active))
        released = False
        for session_id in candidates:
            with self._lock:
                active = self._active.get(session_id)
            if active is None:
                with self._lock:
                    self._startup_recovery_active.discard(session_id)
                released = True
                continue
            try:
                health = active.runtime.coordinator.health_snapshot()
            except Exception:
                continue
            if bool(health.sync_converged):
                with self._lock:
                    self._startup_recovery_active.discard(session_id)
                released = True
        return released

    def _retry_incomplete_startup_recovery(self, *, released: bool) -> None:
        """Reuse convergence cadence to drain or recheck a bounded scan."""

        with self._lock:
            incomplete = bool(
                self._startup_recovery_scan_saturated
                or self._startup_recovery_unavailable_count
            )
        if incomplete and released:
            self._activate_startup_recovery()

    @property
    def command_readiness(self) -> tuple[bool, str | None, int | None]:
        """Delegate command admission only to the configured primary runtime."""

        with self._activation_lock:
            with self._lock:
                if self.primary_session_id not in self._entries:
                    return (False, "workspace_unavailable", None)
                if self.primary_session_id in self._pending_authority:
                    return (False, "attachment_rebind", None)
                active = self._active.get(self.primary_session_id)
                if active is None:
                    reason = (
                        "workspace_inactive"
                        if self.primary_session_id in self._entries
                        else "workspace_unavailable"
                    )
                    return (False, reason, None)
                active.active_calls += 1
            try:
                readiness = active.runtime.coordinator.command_readiness
                if not (
                    isinstance(readiness, tuple)
                    and len(readiness) == 3
                    and isinstance(readiness[0], bool)
                ):
                    raise StateError(
                        "The primary workspace returned invalid command readiness."
                    )
                return readiness
            finally:
                self._return_runtime(self.primary_session_id, active)

    def can_claim_workspace_commands(self) -> bool:
        """Allow account queue discovery, not execution in an arbitrary target.

        Every claimed command must still borrow its exact visible runtime and
        pass attachment, recovery and execution readiness inside that lease.
        The original enrollment workspace's telemetry stays independent.
        """
        with self._lock:
            return bool(
                self._started and not self._closed and not self.stop_requested()
                and not self._projection_inflight
                and self._snapshot is not None
                and self.config.account_id is not None
                and self._snapshot.account.id == self.config.account_id
                and self._entries
            )

    def _expected_identity(self) -> str:
        account_id = self.config.account_id
        if not isinstance(account_id, str) or not account_id:
            raise Disconnected(
                "This installation has no authenticated Meshia account identity.",
                reason_code="ACCOUNT_IDENTITY_MISSING",
            )
        return account_id

    def _validate_account(self, account: AccountIdentity) -> None:
        expected_id = self._expected_identity()
        if account.id != expected_id:
            raise Disconnected(
                "The workspace catalog belongs to a different Meshia account.",
                reason_code="ACCOUNT_MISMATCH",
            )
        configured_email = self.config.account_email
        if (
            isinstance(configured_email, str)
            and configured_email
            and account.email.casefold() != configured_email.casefold()
        ):
            # UUID is immutable authority. Email is display metadata and may
            # legitimately change without disconnecting the mounted account.
            self.logger.record("workspace_account_email_refreshed")

    def retire_workspace_storage(self, session_id: str, error: BaseException) -> bool:
        """Fence one rejected binding without revoking the mounted account."""

        if not isinstance(error, Disconnected) or error.reason_code not in _TERMINAL_STORAGE_CODES:
            return False
        with self._state_condition:
            entry = self._entries.get(session_id)
            if entry is None and self._snapshot is not None:
                entry = next((item for item in self._snapshot.workspaces
                              if item.session_id == session_id), None)
            if entry is None and session_id != self.primary_session_id:
                return False
            if (session_id == self.primary_session_id and (
                    self._snapshot is None
                    or (entry is None and session_id not in self._retired_storage_generations))):
                self._primary_storage_error = error
            self._retired_storage_generations[session_id] = max(
                self._retired_storage_generations.get(session_id, 0),
                entry.storage.binding_generation if entry is not None else 0,
            )
            if (session_id in self._active or (
                    session_id == self.primary_session_id
                    and self._pending_primary_runtime is not None)):
                self._retired_storage_runtimes.add(session_id)
            self._entries.pop(session_id, None)
            self._labels.pop(session_id, None)
            self._pending_authority.pop(session_id, None)
            self._activation_unavailable.discard(session_id)
            self._state_version += 1
            self._storage_projection_pending = True
            self._next_catalog_refresh = 0.0
            self._state_condition.notify_all()
        # Topology replacement waits for maintenance: this can run under a
        # native callback's topology lock. Owned handles/journals stay intact.
        self.wake()
        return True

    def _mount_error(self, error: BaseException, session_id: str | None = None) -> OSError:
        """Map control-plane failures onto stable native filesystem errors."""

        if session_id is not None and self.retire_workspace_storage(session_id, error):
            return OSError(errno.ESTALE, str(error))
        if isinstance(error, Disconnected):
            # A root rename is called while the mount owns its topology lock;
            # recursively replacing topology here would deadlock. Fence all
            # new backend access immediately and wake maintenance to remove the
            # now-inert visible labels outside that callback.
            with self._state_condition:
                self._snapshot = None
                self._entries = {}
                self._labels = {}
                self._activation_unavailable.clear()
                self._state_version += 1
                self._next_catalog_refresh = 0.0
            self.wake()
            return OSError(errno.EACCES, str(error))
        if isinstance(error, InvalidArgument):
            return OSError(errno.EINVAL, str(error))
        if isinstance(error, (NetworkError, RemoteError)):
            if (
                isinstance(error, RemoteError)
                and error.status == 409
                and error.remote_code
                in {"ATTACHMENT_INACTIVE", "CATALOG_CHANGED", "WORKSPACE_STORAGE_UNAVAILABLE"}
            ):
                with self._lock:
                    self._next_catalog_refresh = 0.0
                self.wake()
            return OSError(errno.EAGAIN, str(error))
        return OSError(errno.EIO, str(error))

    def _hide_projection(self) -> None:
        with self._state_condition:
            while self._projection_inflight or self._rename_inflight:
                self._state_condition.wait()
            self._projection_inflight = True
            self._snapshot = None
            self._entries = {}
            self._labels = {}
            self._activation_unavailable.clear()
            self._state_version += 1
        try:
            self.mount_backend.replace_workspaces({})
        finally:
            with self._state_condition:
                self._projection_inflight = False
                self._state_condition.notify_all()

    def _install_snapshot(
        self,
        snapshot: WorkspaceCatalogSnapshot,
        *,
        expected_state_version: int | None = None,
        authoritative_attachments: bool = True,
        authoritative_storage: bool = False,
    ) -> bool:
        """Atomically replace the complete visible projection, never a page.

        A persisted catalog is safe for immediate names and quota projection,
        but its attachment leases may predate the service's just-renewed primary
        authority. Only catalog-owned runtimes may follow attachment changes;
        NodeRunner's injected primary keeps its independently renewed authority
        even when a live catalog response temporarily trails it.
        """

        try:
            self._validate_account(snapshot.account)
        except Disconnected:
            self._hide_projection()
            raise

        projected = snapshot.projected
        entries = {item.workspace.session_id: item.workspace for item in projected}
        labels = {
            item.workspace.session_id: item.component_name for item in projected
        }
        restore: WorkspaceCatalogSnapshot | None = None
        previous_state: tuple[
            WorkspaceCatalogSnapshot | None,
            dict[str, WorkspaceCatalogEntry],
            dict[str, str],
            dict[str, WorkspaceCatalogEntry],
        ]
        adopted_primary: WorkspaceRuntime | None = None
        adopted_primary_proxy: _LazyWorkspaceBackend | None = None
        authority_changed: tuple[str, ...] = ()
        with self._state_condition:
            while self._projection_inflight or self._rename_inflight:
                self._state_condition.wait()
            if self._closed:
                raise StateError("The workspace runtime manager is closed.")
            current = self._snapshot
            current_generation = (
                current.snapshot_generation if current is not None else 0
            )
            state_advanced = (
                expected_state_version is not None
                and expected_state_version != self._state_version
            )
            if current is not None and (
                snapshot.snapshot_generation < current_generation
                or (
                    state_advanced
                    and snapshot.snapshot_generation <= current_generation
                )
            ):
                restore = current
                # Fence root rename until the stale client-side store write is
                # repaired, otherwise a newer rename receipt could land
                # between this decision and save and then be overwritten.
                self._projection_inflight = True
                proxies = {}
                active_name_updates = []
                previous_state = (
                    current,
                    self._entries,
                    self._labels,
                    self._pending_authority,
                )
            else:
                if self._primary_storage_error is not None:
                    # The primary attach already rejected Files authority.
                    # Fence even the cached projection before its first route
                    # or injected runtime can be published or started.
                    primary_entry = next((item for item in snapshot.workspaces
                                          if item.session_id == self.primary_session_id), None)
                    self._retired_storage_generations[self.primary_session_id] = max(
                        self._retired_storage_generations.get(self.primary_session_id, 0),
                        primary_entry.storage.binding_generation if primary_entry is not None else 0,
                    )
                    if self._pending_primary_runtime is not None:
                        self._retired_storage_runtimes.add(self.primary_session_id)
                    if primary_entry is not None:
                        self._primary_storage_error = None
                # Only a complete authenticated refresh may admit a strictly
                # newer storage binding. Cached catalogs and heartbeat/rename
                # receipts cannot resurrect the binding that rejected us.
                entries = {
                    session_id: entry for session_id, entry in entries.items()
                    if session_id not in self._retired_storage_generations
                    or (
                        entry.storage.binding_generation
                        > self._retired_storage_generations[session_id]
                        and (authoritative_storage or (
                            session_id in self._entries
                            and self._entries[session_id].storage.binding_generation
                            == entry.storage.binding_generation
                        ))
                    )
                }
                labels = {session_id: label for session_id, label in labels.items()
                          if session_id in entries}
                self._projection_inflight = True
                proxies: dict[str, _LazyWorkspaceBackend] = {}
                active_name_updates: list[tuple[Any, str]] = []
                for session_id, entry in entries.items():
                    label = labels[session_id]
                    proxy = self._proxies.get(session_id)
                    if proxy is None:
                        proxy = _LazyWorkspaceBackend(
                            self,
                            session_id,
                            label,
                            entry.storage,
                            snapshot.snapshot_generation,
                        )
                        self._proxies[session_id] = proxy
                    else:
                        proxy.set_workspace_name(label)
                        proxy.set_workspace_storage(
                            entry.storage,
                            catalog_generation=snapshot.snapshot_generation,
                        )
                    proxies[label] = proxy
                    active = self._active.get(session_id)
                    if active is not None:
                        active_name_updates.append((active.runtime.backend, label))
                previous_state = (
                    current,
                    self._entries,
                    self._labels,
                    self._pending_authority,
                )
                self._snapshot = snapshot
                self._entries = entries
                self._labels = labels
                pending_authority = {
                    session_id: entries[session_id]
                    for session_id in self._pending_authority
                    if session_id in entries
                }
                changed_ids: list[str] = []
                for session_id, active in self._active.items():
                    entry = entries.get(session_id)
                    if entry is not None and session_id in self._retired_storage_runtimes:
                        pending_authority[session_id] = entry
                        changed_ids.append(session_id)
                        continue
                    attachment_id = (
                        entry.attachment.id
                        if entry is not None and entry.attachment is not None
                        else None
                    )
                    if (
                        authoritative_attachments
                        and (
                            self._catalog_owns_primary
                            or session_id != self.primary_session_id
                        )
                        and entry is not None
                        and attachment_id is not None
                        and attachment_id != active.authority_attachment_id
                    ):
                        pending_authority[session_id] = entry
                        changed_ids.append(session_id)
                self._pending_authority = pending_authority
                authority_changed = tuple(changed_ids)
                if (
                    self._pending_primary_runtime is not None
                    and self.primary_session_id in entries
                    and self.primary_session_id not in self._active
                    and self.primary_session_id in self._retired_storage_runtimes
                ):
                    # Bootstrap rejected this runtime's storage before it
                    # could be adopted. Keep its journal inert; a successor
                    # must pass the same drain/recreate gate as an active one.
                    self._pending_authority[self.primary_session_id] = entries[
                        self.primary_session_id
                    ]
                    authority_changed = (*authority_changed, self.primary_session_id)
                elif (
                    self._pending_primary_runtime is not None
                    and self.primary_session_id in entries
                    and self.primary_session_id not in self._active
                ):
                    adopted_primary = self._pending_primary_runtime
                    adopted_primary_proxy = self._proxies[self.primary_session_id]
                    self._pending_primary_runtime = None
                    self._active[self.primary_session_id] = _ActiveRuntime(
                        runtime=adopted_primary,
                        last_used=float(self._clock()),
                        authority_attachment_id=(
                            adopted_primary.attachment_id
                            or (
                                entries[self.primary_session_id].attachment.id
                                if entries[self.primary_session_id].attachment
                                is not None
                                else None
                            )
                        ),
                    )
                    target_attachment = entries[
                        self.primary_session_id
                    ].attachment
                    if (
                        authoritative_attachments
                        and self._catalog_owns_primary
                        and target_attachment is not None
                        and adopted_primary.attachment_id != target_attachment.id
                    ):
                        self._pending_authority[
                            self.primary_session_id
                        ] = entries[self.primary_session_id]
                        authority_changed = (
                            *authority_changed,
                            self.primary_session_id,
                        )
                    active_name_updates.append(
                        (adopted_primary.backend, labels[self.primary_session_id])
                    )
                self._state_version += 1

        if restore is not None:
            # WorkspaceCatalogClient may have persisted an older in-flight
            # response. Restore the newer accepted snapshot before returning.
            try:
                self.catalog_store.save(restore)
            finally:
                with self._state_condition:
                    self._projection_inflight = False
                    self._state_condition.notify_all()
            return False

        try:
            # These local-only calls deliberately run with no manager lock.
            if adopted_primary is not None and adopted_primary_proxy is not None:
                quota_setter = getattr(adopted_primary.backend, "set_remote_quota", None)
                if not callable(quota_setter):
                    raise StateError(
                        "The primary workspace backend cannot enforce remote quota."
                    )
                quota_setter(adopted_primary_proxy.remote_quota)
            for backend, label in active_name_updates:
                if backend.workspace_name != label:
                    backend.set_workspace_name(label)
            self.mount_backend.replace_workspaces(proxies)
            self._publish_compute_icons(entries, labels)
            self._publish_workspace_modified(entries, labels)
        except BaseException:
            with self._state_condition:
                (
                    self._snapshot,
                    self._entries,
                    self._labels,
                    self._pending_authority,
                ) = previous_state
                if adopted_primary is not None:
                    self._active.pop(self.primary_session_id, None)
                    self._pending_primary_runtime = adopted_primary
                self._state_version += 1
            raise
        else:
            with self._lock:
                # Failures are meaningful only while their signed workspace
                # remains visible. The catalog itself provides the hard bound
                # on this per-workspace (never per-path) health evidence.
                self._activation_unavailable.intersection_update(entries)
        finally:
            with self._state_condition:
                self._projection_inflight = False
                self._state_condition.notify_all()
        for session_id in authority_changed:
            self._complete_pending_authority_if_drained(session_id)
        # The primary is a command route, not account-wide Files authority.
        # Missing entries stay inaccessible through the normal route fence;
        # command_readiness also rejects a missing primary. Keep the remaining
        # authenticated projection mounted and let safe retirement drain state.
        return True

    @staticmethod
    def _is_transient(error: BaseException) -> bool:
        return isinstance(error, NetworkError) or (
            isinstance(error, RemoteError) and error.retryable
        )

    def _publish_workspace_modified(
        self,
        entries: Mapping[str, WorkspaceCatalogEntry],
        labels: Mapping[str, str],
    ) -> None:
        """Tell the mount when each workspace root's content last changed.

        The multi-workspace root answers getattr for every workspace folder
        without activating its runtime, so the only modification time it can
        report cheaply is the one the catalog carries (M1790). Never fatal: a
        folder date is cosmetic and must not fail a catalog projection.
        """

        publish = getattr(self.mount_backend, "set_workspace_modified", None)
        if not callable(publish):
            return
        modified: dict[str, int] = {}
        for session_id, entry in entries.items():
            label = labels.get(session_id)
            if label is None:
                continue
            try:
                stamp = entry.modified_ns
            except ValueError:
                continue
            if stamp is not None and stamp > 0:
                modified[label] = stamp
        try:
            publish(modified)
        except Exception as error:  # pragma: no cover - defensive
            self.logger.record(
                "fabric_mount_workspace_modified_publish_failed",
                error_type=type(error).__name__,
                error=str(error)[:256],
            )

    def _publish_compute_icons(
        self,
        entries: Mapping[str, WorkspaceCatalogEntry],
        labels: Mapping[str, str],
    ) -> None:
        """Tell the mount which workspace roots are open on Meshia (green).

        Open means the session is live and unfenced, regardless of compute
        (``WorkspaceCatalogEntry.compute_running``). Catalog projection is the
        single point where both the open set and the mount labels are known,
        and a push ``catalog`` event refreshes it on the next service turn
        (at most ``PUSH_CATALOG_REFRESH_COALESCE_SECONDS`` after the previous
        refresh), so a workspace turns green within seconds of opening.
        Never fatal: an icon is cosmetic and must not fail a catalog
        projection.
        """

        publish = getattr(self.mount_backend, "set_compute_running", None)
        if not callable(publish):
            return
        running = tuple(
            labels[session_id]
            for session_id, entry in entries.items()
            if entry.compute_running and session_id in labels
        )
        try:
            publish(running)
        except Exception as error:  # pragma: no cover - defensive
            self.logger.record(
                "fabric_mount_compute_icons_publish_failed",
                error=str(error),
                error_type=type(error).__name__,
            )

    def _refresh_catalog(self, *, cached: WorkspaceCatalogSnapshot | None) -> bool:
        previous = self.catalog_store.load()
        with self._lock:
            expected_state_version = self._state_version
        try:
            refreshed = self.catalog_client.refresh(self.catalog_store)
            accepted = self._install_snapshot(
                refreshed,
                expected_state_version=expected_state_version,
                authoritative_storage=True,
            )
            return accepted and refreshed != cached
        except BaseException as error:
            # WorkspaceCatalogClient persists only complete snapshots, but an
            # account mismatch is a manager-level authority check.  Do not let
            # a signed response for a different account poison this account's
            # last known-good offline projection.
            if (
                isinstance(error, Disconnected)
                and error.reason_code == "ACCOUNT_MISMATCH"
                and previous is not None
            ):
                try:
                    self._validate_account(previous.account)
                except Disconnected:
                    pass
                else:
                    self.catalog_store.save(previous)
            if cached is None or not self._is_transient(error):
                if isinstance(error, Disconnected):
                    self._hide_projection()
                raise
            self.logger.record(
                "workspace_catalog_refresh_deferred", error_code=type(error).__name__
            )
            return False

    def prepare_mount(self) -> None:
        """Project authenticated roots without starting workspace collectors."""

        with self._lock:
            if self._closed:
                raise StateError("The workspace runtime manager is closed.")
            if self._prepared:
                return
            self._prepared = True
        try:
            cached = self.catalog_store.load()
            if cached is not None:
                self._install_snapshot(
                    cached,
                    authoritative_attachments=False,
                )
            self._refresh_catalog(cached=cached)
        except BaseException:
            with self._lock:
                self._prepared = False
            raise
        now = float(self._clock())
        with self._lock:
            self._last_catalog_refresh_at = now
            self._next_catalog_refresh = now + self._catalog_refresh_interval()
            self._next_heartbeat = now + self.heartbeat_seconds

    def start(self) -> None:
        """Arm every active collector after the runner renews its first lease."""

        self.prepare_mount()
        with self._lock:
            if self._started:
                return
        self._activate_startup_recovery()
        with self._lock:
            active = tuple(item for session_id, item in self._active.items()
                           if session_id not in self._retired_storage_runtimes)
        for item in active:
            start = getattr(item.runtime.coordinator, "start", None)
            if callable(start):
                start()
        with self._lock:
            if self._closed:
                raise StateError("The workspace runtime manager is closed.")
            self._started = True

    def _snapshot_entry(self, session_id: str) -> WorkspaceCatalogEntry:
        with self._lock:
            entry = self._entries.get(session_id)
        if entry is None:
            raise OSError(errno.ENOENT, "The workspace is no longer available.")
        return entry

    def _replace_snapshot_entry(
        self,
        session_id: str,
        update: Callable[[WorkspaceCatalogEntry], WorkspaceCatalogEntry],
        *,
        reproject: bool = True,
    ) -> WorkspaceCatalogEntry:
        """Persist a complete updated snapshot before making it visible."""

        for _attempt in range(4):
            with self._lock:
                snapshot = self._snapshot
                current = self._entries.get(session_id)
                expected_state_version = self._state_version
            if snapshot is None or current is None:
                raise OSError(errno.ENOENT, "The workspace is no longer available.")
            updated_entry = update(current)
            updated_snapshot = replace(
                snapshot,
                workspaces=tuple(
                    updated_entry if item.session_id == session_id else item
                    for item in snapshot.workspaces
                ),
            )
            self.catalog_store.save(updated_snapshot)
            if reproject:
                if self._install_snapshot(
                    updated_snapshot,
                    expected_state_version=expected_state_version,
                ):
                    return updated_entry
            else:
                # Root rename is invoked while MultiWorkspaceMountBackend owns
                # its topology lock.  Persisting an attach receipt here is
                # safe, but recursively replacing mount topology would
                # deadlock.  Attach does not change a generation-fenced
                # catalog label; the root rename below rekeys that route.
                with self._state_condition:
                    if self._state_version != expected_state_version:
                        continue
                    self._snapshot = updated_snapshot
                    self._entries = {**self._entries, session_id: updated_entry}
                    self._state_version += 1
                    return updated_entry
        raise OSError(
            errno.EAGAIN,
            "The workspace catalog changed while its attachment was recorded.",
        )

    def _lease_reusable(self, lease: AttachmentLease) -> bool:
        try:
            expires_at = datetime.fromisoformat(
                lease.lease_expires_at.replace("Z", "+00:00")
            ).timestamp()
        except (OverflowError, ValueError):
            return False
        return expires_at > float(self._wall_clock()) + LEASE_EXPIRY_SKEW_SECONDS

    def _ensure_attachment(
        self, session_id: str, *, reproject: bool = True
    ) -> WorkspaceCatalogEntry:
        entry = self._snapshot_entry(session_id)
        if entry.attachment is not None and self._lease_reusable(entry.attachment):
            return entry
        with self._lock:
            snapshot = self._snapshot
        if snapshot is None:
            raise OSError(errno.ENOENT, "The workspace is no longer available.")

        batch = self.catalog_client.attach_workspaces(
            catalog_generation=snapshot.snapshot_generation,
            workspace_ids=(session_id,),
        )
        self._validate_account(batch.account)
        receipt = batch.attachments[0]

        def apply(current: WorkspaceCatalogEntry) -> WorkspaceCatalogEntry:
            if current.name_revision > receipt.name_revision:
                raise StateError("Meshia returned a stale workspace attachment name.")
            return replace(
                current,
                name=receipt.workspace_name,
                name_revision=receipt.name_revision,
                storage=receipt.workspace_storage,
                attachment=receipt.attachment,
            )

        return self._replace_snapshot_entry(
            session_id, apply, reproject=reproject
        )

    def _evict_one_for_capacity(self, protected_session_id: str) -> None:
        with self._lock:
            candidates = sorted(
                (
                    (session_id, active)
                    for session_id, active in self._active.items()
                    if session_id != protected_session_id
                    and session_id != self.primary_session_id
                    and session_id not in self._startup_recovery_active
                    and session_id not in self._pending_authority
                    and active.active_calls == 0
                    and active.open_handles == 0
                ),
                key=lambda item: (item[1].last_used, item[0]),
            )
        for session_id, active in candidates:
            try:
                safe = active.runtime.can_evict()
            except BaseException as error:
                safe = False
                self.logger.record(
                    "workspace_runtime_close_probe_failed",
                    session_id=session_id,
                    error=str(error),
                )
            if not safe:
                continue
            with self._lock:
                if self._active.get(session_id) is not active:
                    continue
                if (
                    session_id in self._startup_recovery_active
                    or session_id in self._pending_authority
                    or active.active_calls
                    or active.open_handles
                ):
                    continue
                self._active.pop(session_id)
            active.runtime.close()
            return
        raise OSError(
            errno.EBUSY,
            "All active workspace runtimes have open or unreconciled work.",
        )

    def _activate_runtime(
        self,
        session_id: str,
        *,
        allow_first_mutation_wait: bool = False,
    ) -> _ActiveRuntime:
        try:
            active = self._activate_runtime_untracked(
                session_id,
                allow_first_mutation_wait=allow_first_mutation_wait,
            )
        except BaseException:
            with self._lock:
                if not self._closed and session_id in self._entries:
                    self._activation_unavailable.add(session_id)
            raise
        with self._lock:
            self._activation_unavailable.discard(session_id)
        return active

    def _activate_runtime_untracked(
        self,
        session_id: str,
        *,
        allow_first_mutation_wait: bool,
    ) -> _ActiveRuntime:
        """Construct one runtime; the tracked wrapper owns health evidence."""

        entry = self._ensure_attachment(session_id)
        with self._lock:
            label = self._labels.get(session_id)
        if label is None:
            raise OSError(errno.ENOENT, "The workspace is no longer available.")
        runtime = self.runtime_factory(entry, label)
        self._bind_runtime_wake(runtime, session_id)
        with self._lock:
            should_start = self._started
            proxy = self._proxies.get(session_id)
        try:
            if runtime.backend.workspace_name != label:
                runtime.backend.set_workspace_name(label)
            capacity = proxy.stage_capacity if proxy is not None else None
            if capacity is not None:
                setter = getattr(runtime.backend, "set_stage_capacity", None)
                if not callable(setter):
                    raise StateError("The workspace backend cannot share stage capacity.")
                setter(capacity)
            quota_setter = getattr(runtime.backend, "set_remote_quota", None)
            if proxy is not None:
                if not callable(quota_setter):
                    raise StateError("The workspace backend cannot enforce remote quota.")
                quota_setter(proxy.remote_quota)
            start = getattr(runtime.coordinator, "start", None)
            if should_start and callable(start):
                start()
        except BaseException:
            runtime.close()
            raise
        active = _ActiveRuntime(
            runtime=runtime,
            last_used=float(self._clock()),
            authority_attachment_id=(
                entry.attachment.id if entry.attachment is not None else None
            ),
            first_mutation_wait_available=allow_first_mutation_wait,
        )
        with self._lock:
            if self._closed or session_id not in self._entries:
                stale = True
            else:
                stale = False
                self._active[session_id] = active
        if stale:
            runtime.close()
            raise OSError(errno.ENOENT, "The workspace is no longer available.")
        return active

    def _borrow_runtime(
        self,
        session_id: str,
        *,
        require_visible: bool,
        touch: bool = True,
        allow_fenced_handle: bool = False,
        release_retired_handle: bool = False,
    ) -> _ActiveRuntime:
        # The activation lock protects construction/eviction, not ordinary
        # calls into an already-published runtime.  Pin that fast path under
        # the topology lock so a slow cold workspace cannot stall unrelated
        # active workspace I/O.
        active = self._pin_active_runtime(
            session_id,
            require_visible=require_visible,
            touch=touch,
            allow_fenced_handle=allow_fenced_handle,
            release_retired_handle=release_retired_handle,
        )
        if active is not None:
            return active
        with self._activation_lock:
            active = self._pin_active_runtime(
                session_id,
                require_visible=require_visible,
                touch=touch,
                allow_fenced_handle=allow_fenced_handle,
                release_retired_handle=release_retired_handle,
            )
            if active is not None:
                return active
            with self._lock:
                at_capacity = len(self._active) >= self.max_active_workspaces
            if at_capacity:
                self._evict_one_for_capacity(session_id)
            active = self._activate_runtime(
                session_id,
                allow_first_mutation_wait=require_visible,
            )
            with self._lock:
                if self._active.get(session_id) is not active:
                    raise OSError(errno.ESTALE, "The workspace runtime was retired.")
                active.active_calls += 1
                if touch:
                    active.last_used = float(self._clock())
                return active

    def _pin_active_runtime(
        self,
        session_id: str,
        *,
        require_visible: bool,
        touch: bool,
        allow_fenced_handle: bool,
        release_retired_handle: bool = False,
    ) -> _ActiveRuntime | None:
        """Pin one published runtime without entering the cold-start lane."""

        with self._lock:
            if session_id in self._retired_storage_runtimes and not release_retired_handle:
                raise OSError(errno.ESTALE, "The workspace storage was retired.")
            if self._closed and require_visible:
                raise OSError(errno.EIO, "The workspace runtime manager is closed.")
            if require_visible and session_id not in self._entries:
                raise OSError(errno.ENOENT, "The workspace is no longer available.")
            if require_visible and session_id in self._pending_authority:
                raise OSError(
                    errno.EAGAIN,
                    "The workspace attachment is being rebound; retry shortly.",
                )
            active = self._active.get(session_id)
            if active is None:
                if not require_visible:
                    raise OSError(errno.ESTALE, "The workspace runtime was retired.")
                return None
            if not require_visible and (
                session_id not in self._entries
                or session_id in self._pending_authority
            ):
                # Maintenance operates from snapshots that can become stale
                # before their turn. Existing handles retain their runtime pin
                # until release, but a stale coordinator poll must never start
                # after catalog removal or an attachment-rebind fence.
                if not (allow_fenced_handle and active.open_handles):
                    raise OSError(
                        errno.ESTALE,
                        "The workspace runtime authority changed.",
                    )
            active.active_calls += 1
            if touch:
                active.last_used = float(self._clock())
            return active

    def _return_runtime(
        self, session_id: str, active: _ActiveRuntime, *, touch: bool = True
    ) -> None:
        with self._lock:
            if active.active_calls > 0:
                active.active_calls -= 1
            if touch:
                active.last_used = float(self._clock())
            authority_drained = bool(
                session_id in self._pending_authority
                and self._active.get(session_id) is active
                and not active.active_calls
                and not active.open_handles
            )
        if authority_drained:
            # The pending transition is already its durable completion queue.
            # Never put a returning filesystem call behind the serialized cold
            # activation lane: if it is busy, wake manager maintenance and let
            # the catalog owner or next bounded poll drain the transition.
            self._complete_pending_authority_if_drained(
                session_id,
                wait_for_activation=False,
            )

    def _require_new_mutation_ready(
        self, session_id: str, active: _ActiveRuntime, *, wait: bool = True, namespace_only: bool = False
    ) -> None:
        """Fence new writes during local authority-recovery transitions.

        Reads and operations on already-open handles remain available. This
        check deliberately runs after lazy activation because constructing the
        coordinator can discover a durable host-generation adoption fence.
        """

        wait_deadline: float | None = None
        observed_readiness_version = 0
        while True:
            with self._state_condition:
                if self._active.get(session_id) is not active:
                    raise OSError(
                        errno.ESTALE, "The workspace runtime was retired."
                    )
                if session_id in self._pending_authority:
                    raise OSError(
                        errno.EAGAIN,
                        "The workspace attachment is being rebound; retry shortly.",
                    )
                observed_readiness_version = self._readiness_version
            if namespace_only and getattr(active.runtime.coordinator, "namespace_ready", True):
                return
            readiness = active.runtime.coordinator.command_readiness
            if not (
                isinstance(readiness, tuple)
                and len(readiness) == 3
                and isinstance(readiness[0], bool)
            ):
                raise OSError(
                    errno.EIO, "The workspace returned invalid readiness."
                )
            ready, reason, _generation = readiness
            if ready or (not namespace_only and reason not in _NEW_MUTATION_RECOVERY_FENCES):
                with self._lock:
                    active.first_mutation_wait_available = False
                    active.waited_fence_generation = None
                    active.mutation_wait_deadline = None
                return
            if not wait or reason not in _FIRST_MUTATION_ACTIVATION_FENCES:
                # Re-evaluate on every wake: a startup wait must stop if an
                # attachment/adoption/evidence fence appears mid-grace.
                self._notify_child_wake(session_id)
                raise OSError(
                    errno.EAGAIN,
                    f"The workspace is reconciling ({reason}); retry shortly.",
                )

            if wait_deadline is None:
                with self._lock:
                    fence_generation = (reason, _generation)
                    if (
                        active.first_mutation_wait_available
                        or active.waited_fence_generation != fence_generation
                    ):
                        active.mutation_wait_deadline = (
                            time.monotonic() + self.first_mutation_ready_wait_seconds
                        )
                    can_wait = bool(
                        self._active.get(session_id) is active
                        and self.first_mutation_ready_wait_seconds > 0
                        and active.mutation_wait_deadline is not None
                        and time.monotonic() < active.mutation_wait_deadline
                    )
                    # Concurrent Finder metadata and final rename calls share
                    # one bounded recovery deadline. Rejecting the second
                    # caller while the first waits interrupts an active copy.
                    # Expired recovery still fails promptly on later retries;
                    # authority repair remains an immediate fence above.
                    active.first_mutation_wait_available = False
                    active.waited_fence_generation = fence_generation
                    wait_deadline = active.mutation_wait_deadline
                if not can_wait:
                    self._notify_child_wake(session_id)
                    raise OSError(
                        errno.EAGAIN,
                        f"The workspace is reconciling ({reason}); retry shortly.",
                    )
                wake = getattr(active.runtime.coordinator, "wake", None)
                if callable(wake):
                    wake()
                else:
                    self._notify_child_wake(session_id)

            assert wait_deadline is not None
            remaining = wait_deadline - time.monotonic()
            if remaining <= 0:
                raise OSError(
                    errno.EAGAIN,
                    f"The workspace is reconciling ({reason}); retry shortly.",
                )
            with self._state_condition:
                self._state_condition.wait_for(
                    lambda: (
                        self._readiness_version != observed_readiness_version
                        or self._closed
                        or self._active.get(session_id) is not active
                        or session_id in self._pending_authority
                    ),
                    timeout=remaining,
                )

    def run_pinned(
        self,
        session_id: str,
        operation: Callable[[WorkspaceRuntime], Any],
        *,
        require_visible: bool = True,
        require_mutation_ready: bool = False,
        allow_fenced_handle: bool | None = None,
        activate: bool = True,
    ) -> Any:
        """Run ``operation`` against one pinned runtime under the mount fences.

        This is the single admission path for a mounted operation whether the
        FUSE loop shares this process (``_LazyWorkspaceBackend``) or runs in
        the split-mode mount worker (``MultiWorkspaceEngineServer``): lazy
        activation with the CATALOG_CHANGED retry, the visibility fence, the
        mutation-ready fence, and control-plane errors mapped onto errnos.

        ``activate=False`` is for best-effort signals (wake, access hints): a
        workspace the engine has already evicted gets ``None``, never a cold
        activation on its behalf.
        """

        with self.lease_runtime(
            session_id,
            require_visible=require_visible,
            require_mutation_ready=require_mutation_ready,
            allow_fenced_handle=allow_fenced_handle,
            activate=activate,
        ) as runtime:
            return None if runtime is None else operation(runtime)

    @contextmanager
    def lease_runtime(
        self,
        session_id: str,
        *,
        require_visible: bool = True,
        require_mutation_ready: bool = False,
        wait_for_mutation_ready: bool = True,
        allow_fenced_handle: bool | None = None,
        activate: bool = True,
    ) -> Iterator[WorkspaceRuntime | None]:
        """Hold the existing admission pin for one complete command or request.

        This is the same authority/visibility/recovery boundary as run_pinned;
        callers cannot obtain a second owner or keep an unpinned runtime after
        the context exits. Inactive best-effort leases yield None.
        """

        if allow_fenced_handle is None:
            allow_fenced_handle = not require_visible
        if not activate:
            try:
                active = self._pin_active_runtime(
                    session_id,
                    require_visible=False,
                    touch=True,
                    allow_fenced_handle=True,
                )
            except OSError:
                yield None
                return
            if active is None:
                yield None
                return
            try:
                yield active.runtime
            finally:
                self._return_runtime(session_id, active)
            return
        for attempt in range(CATALOG_RESTART_ATTEMPTS):
            try:
                active = self._borrow_runtime(
                    session_id,
                    require_visible=require_visible,
                    allow_fenced_handle=allow_fenced_handle,
                )
                break
            except (
                Disconnected,
                InvalidArgument,
                NetworkError,
                RemoteError,
                StateError,
            ) as error:
                mount_error = self._mount_error(error, session_id)
                # A signed 409 CATALOG_CHANGED during cold activation means the
                # catalog moved under us; _mount_error already scheduled the
                # refresh. Surfacing it (EAGAIN) made Finder fail a folder
                # listing outright (2026-09-02); retry after the refresh.
                if (
                    catalog_restart_required(error)
                    and attempt + 1 < CATALOG_RESTART_ATTEMPTS
                ):
                    time.sleep(CATALOG_RESTART_BACKOFF_SECONDS * (attempt + 1))
                    continue
                raise mount_error from error
        try:
            try:
                if require_visible and not allow_fenced_handle:
                    # Both the local proxy and split worker activate through
                    # this pin. Wait outside the global activation lock so a
                    # first stat/open cannot mistake the uninitialized mirror
                    # for ENOENT, or block already-active workspaces.
                    self._require_new_mutation_ready(session_id, active,
                        wait=wait_for_mutation_ready, namespace_only=True)
                if require_mutation_ready:
                    self._require_new_mutation_ready(session_id, active, wait=wait_for_mutation_ready)
                yield active.runtime
            except (
                Disconnected,
                InvalidArgument,
                NetworkError,
                RemoteError,
                StateError,
            ) as error:
                raise self._mount_error(error, session_id) from error
        finally:
            self._return_runtime(session_id, active)

    def rename_workspace_root(
        self, session_id: str, source_label: str, destination_label: str
    ) -> str:
        """Root rename for a mount process, with control-plane errors mapped.

        Returns the accepted label so the caller can rekey its route.
        """

        try:
            self._rename_workspace_root(session_id, source_label, destination_label)
        except (Disconnected, InvalidArgument, NetworkError, RemoteError, StateError) as error:
            raise self._mount_error(error, session_id) from error
        with self._lock:
            label = self._labels.get(session_id)
        if label is None:
            raise OSError(errno.ENOENT, "The workspace is no longer available.")
        return label

    def _record_open_handle(
        self, session_id: str, active: _ActiveRuntime
    ) -> None:
        with self._lock:
            if self._closed:
                raise OSError(errno.EIO, "The workspace runtime manager is closed.")
            if self._active.get(session_id) is not active:
                raise OSError(errno.ESTALE, "The workspace runtime was retired.")
            active.open_handles += 1

    def _record_closed_handle(
        self, session_id: str, active: _ActiveRuntime
    ) -> None:
        with self._lock:
            if active.open_handles > 0:
                active.open_handles -= 1

    def _complete_pending_authority_if_drained(
        self,
        session_id: str,
        *,
        wait_for_activation: bool = True,
    ) -> bool:
        """Atomically rebind one drained runtime to its persisted attachment."""

        with self._lock:
            if session_id not in self._pending_authority:
                self._authority_recreate_deferred.discard(session_id)
                return False
        acquired = self._activation_lock.acquire(blocking=wait_for_activation)
        if not acquired:
            # `_pending_authority` is the retry queue. Retain it and make the
            # service loop immediately retry after the lifecycle lane drains.
            self._notify_child_wake(session_id)
            return False
        try:
            with self._lock:
                target = self._pending_authority.get(session_id)
                if target is None:
                    self._authority_recreate_deferred.discard(session_id)
                    return False
                if session_id in self._authority_recreate_deferred:
                    return False
                active = self._active.get(session_id)
                retired_primary = (
                    self._pending_primary_runtime
                    if session_id == self.primary_session_id
                    and session_id in self._retired_storage_runtimes
                    else None
                )
                closed_or_hidden = self._closed or session_id not in self._entries
                if active is not None and (
                    active.active_calls or active.open_handles
                ):
                    return False
                target_attachment_id = (
                    target.attachment.id
                    if target.attachment is not None
                    else None
                )
                if (
                    active is not None
                    and session_id not in self._retired_storage_runtimes
                    and active.authority_attachment_id
                    == target_attachment_id
                ):
                    self._pending_authority.pop(session_id, None)
                    return True

            if retired_primary is not None:
                try:
                    safe = retired_primary.can_evict()
                except BaseException:
                    safe = False
                if not safe or closed_or_hidden:
                    return False
                with self._lock:
                    if self._pending_primary_runtime is not retired_primary:
                        return False
                    self._pending_primary_runtime = None
                retired_primary.close()

            if closed_or_hidden:
                if active is None:
                    with self._lock:
                        self._pending_authority.pop(session_id, None)
                    return True
                try:
                    safe = active.runtime.can_close()
                except BaseException:
                    safe = False
                if not safe:
                    return False
                with self._lock:
                    if (
                        self._active.get(session_id) is not active
                        or active.active_calls
                        or active.open_handles
                    ):
                        return False
                    self._active.pop(session_id)
                    self._pending_authority.pop(session_id, None)
                    self._proxies.pop(session_id, None)
                active.runtime.close()
                return True

            if (active is not None and active.runtime.refresh_authority is not None
                    and session_id not in self._retired_storage_runtimes):
                try:
                    active.runtime.refresh_authority(target)
                except BaseException as error:
                    self.logger.record(
                        "workspace_runtime_authority_refresh_failed",
                        session_id=session_id,
                        error=str(error),
                    )
                    return False
                with self._lock:
                    if self._active.get(session_id) is not active:
                        return False
                    active.authority_attachment_id = (
                        target_attachment_id
                    )
                    if self._pending_authority.get(session_id) == target:
                        self._pending_authority.pop(session_id, None)
                return True

            if active is not None:
                try:
                    safe = (active.runtime.can_evict()
                            if session_id in self._retired_storage_runtimes
                            else active.runtime.can_close())
                except BaseException as error:
                    safe = False
                    self.logger.record(
                        "workspace_runtime_close_probe_failed",
                        session_id=session_id,
                        error=str(error),
                    )
                if not safe:
                    return False
                with self._lock:
                    if (
                        self._active.get(session_id) is not active
                        or active.active_calls
                        or active.open_handles
                    ):
                        return False
                    self._active.pop(session_id)
                try:
                    active.runtime.close()
                except BaseException as error:
                    # Runtime close is terminal once entered. A real backend
                    # marks itself closed before releasing its workspace/root
                    # descriptors, and a later cleanup failure can therefore
                    # raise after those descriptors are already invalid.
                    # Reinserting that partially closed object makes the mount
                    # route return EBADF forever because its idempotent close
                    # hook cannot repair or retire it on the next pass.
                    #
                    # safe_to_close above proves all user evidence is durable.
                    # Keep the attachment transition pending, discard this
                    # unusable in-memory instance, and construct a fresh
                    # runtime below. If construction fails, the absent route
                    # remains EAGAIN-fenced and a later maintenance pass retries
                    # from the persisted attachment and journal.
                    self.logger.record(
                        "workspace_runtime_authority_close_incomplete",
                        session_id=session_id,
                        error=str(error),
                    )

            try:
                replacement = self._activate_runtime(session_id)
            except BaseException as error:
                with self._lock:
                    self._authority_recreate_deferred.add(session_id)
                self.logger.record(
                    "workspace_runtime_authority_recreate_failed",
                    session_id=session_id,
                    error=str(error),
                )
                return False
            with self._lock:
                if self._active.get(session_id) is not replacement:
                    return False
                self._retired_storage_runtimes.discard(session_id)
                self._authority_recreate_deferred.discard(session_id)
                if self._pending_authority.get(session_id) == target:
                    self._pending_authority.pop(session_id, None)
            return True
        finally:
            self._activation_lock.release()

    def _retry_pending_authorities(self) -> bool:
        with self._lock:
            pending = tuple(self._pending_authority)
        changed = False
        for session_id in pending:
            changed = (
                self._complete_pending_authority_if_drained(session_id)
                or changed
            )
        return changed

    def _route_retired(
        self, session_id: str, proxy: _LazyWorkspaceBackend
    ) -> None:
        with self._activation_lock:
            with self._lock:
                if self._proxies.get(session_id) is not proxy:
                    return
                if session_id in self._entries:
                    return
                if (
                    session_id == self.primary_session_id
                    and not self._catalog_owns_primary
                    and not self._closed
                ):
                    # NodeRunner still reads this coordinator for health and
                    # owns its attachment. Hide its route, but retain its
                    # resources until the runner shuts down with the manager.
                    return
                active = self._active.get(session_id)
                if active is None:
                    self._pending_authority.pop(session_id, None)
                    self._proxies.pop(session_id, None)
                    return
                if active.active_calls or active.open_handles:
                    return
            try:
                safe = (active.runtime.can_evict()
                        if session_id in self._retired_storage_runtimes
                        else active.runtime.can_close())
            except BaseException:
                safe = False
            if not safe:
                return
            with self._lock:
                if (
                    self._active.get(session_id) is not active
                    or active.active_calls
                    or active.open_handles
                ):
                    return
                self._active.pop(session_id)
                self._pending_authority.pop(session_id, None)
                if session_id not in self._entries:
                    self._proxies.pop(session_id, None)
            active.runtime.close()
            with self._lock:
                self._retired_storage_runtimes.discard(session_id)

    def _rename_workspace_root(
        self, session_id: str, source_label: str, destination_label: str
    ) -> None:
        accepted = portable_workspace_name(destination_label)
        with self._activation_lock:
            with self._state_condition:
                if self._closed:
                    raise OSError(
                        errno.EIO, "The workspace runtime manager is closed."
                    )
                # MultiWorkspaceMountBackend already owns its topology lock.
                # Waiting for an in-flight projection that may be waiting for
                # that same lock would invert the order; fail fast and let the
                # native caller retry the rename.
                if self._projection_inflight:
                    raise OSError(
                        errno.EAGAIN,
                        "The workspace catalog is being refreshed; retry rename.",
                    )
                self._rename_inflight = True
            try:
                entry = self._ensure_attachment(session_id, reproject=False)
                with self._lock:
                    current_label = self._labels.get(session_id)
                    snapshot = self._snapshot
                if current_label != source_label or snapshot is None:
                    raise OSError(
                        errno.ESTALE,
                        "Workspace name changed; refresh and retry.",
                    )
                idempotency = hashlib.sha256(
                    (
                        f"{snapshot.account.id}\0{session_id}\0"
                        f"{entry.name_revision}\0{accepted}"
                    ).encode("utf-8")
                ).hexdigest()
                receipt = self.catalog_client.rename_workspace(
                    session_id=session_id,
                    attachment_id=entry.attachment.id,
                    expected_name_revision=entry.name_revision,
                    name=accepted,
                    idempotency_key=f"mount-rename:{idempotency}",
                )
                updated = self.catalog_store.apply_rename(receipt)
                self._validate_account(updated.account)
                projected = {
                    item.workspace.session_id: item.component_name
                    for item in updated.projected
                }
                with self._state_condition:
                    # A rename receipt changes one admitted root's label. It
                    # cannot restore storage authority from retained catalog
                    # entries that were retired while its request was in flight.
                    projected = {
                        item_id: label for item_id, label in projected.items()
                        if item_id in self._entries
                    }
                    if session_id not in projected:
                        raise OSError(errno.ESTALE, "The workspace storage was retired.")
                    updated_label = projected[session_id]
                    previous_labels = self._labels
                    changed_other = any(
                        previous_labels.get(other_id) != label
                        for other_id, label in projected.items()
                        if other_id != session_id
                    )
                    self._snapshot = updated
                    self._entries = {
                        item.session_id: item for item in updated.workspaces
                        if item.session_id in self._entries
                    }
                    self._labels = projected
                    self._state_version += 1
                    proxy = self._proxies[session_id]
                    proxy.set_workspace_name(updated_label)
                    active = self._active.get(session_id)
                if active is not None:
                    active.runtime.backend.set_workspace_name(updated_label)
                # A rename receipt observes only one workspace. Refresh the
                # complete generation promptly after the mount releases its
                # topology lock; historical collisions particularly need the
                # full projection to update every affected label.
                with self._lock:
                    self._next_catalog_refresh = 0.0
                if changed_other:
                    self.logger.record(
                        "workspace_rename_projection_refresh_required",
                        session_id=session_id,
                    )
                self.wake()
            finally:
                with self._state_condition:
                    self._rename_inflight = False
                    self._state_condition.notify_all()

    def _apply_heartbeat(self) -> tuple[bool, bool]:
        with self._lock:
            snapshot = self._snapshot
            refs = tuple(
                AttachmentHeartbeatRef(
                    attachment_id=entry.attachment.id,
                    session_id=session_id,
                )
                for session_id in self._active
                if (
                    self._catalog_owns_primary
                    or session_id != self.primary_session_id
                )
                if (entry := self._entries.get(session_id)) is not None
                and entry.attachment is not None
            )
        if snapshot is None or not refs:
            return False, False
        try:
            batch = self.catalog_client.heartbeat_workspaces(
                refs,
                known_catalog_generation=snapshot.snapshot_generation,
            )
        except RemoteError as error:
            if error.status != 409 or error.remote_code != "ATTACHMENT_INACTIVE":
                raise
            return self._reattach_active_workspaces(
                tuple(item.session_id for item in refs)
            ), False
        self._validate_account(batch.account)
        receipts = {item.session_id: item for item in batch.attachments}
        changed = False
        with self._lock:
            current = self._snapshot
            expected_state_version = self._state_version
        if current is None:
            return False, batch.catalog_changed
        workspaces: list[WorkspaceCatalogEntry] = []
        for entry in current.workspaces:
            receipt = receipts.get(entry.session_id)
            if receipt is None:
                workspaces.append(entry)
                continue
            if receipt.name_revision < entry.name_revision:
                # A concurrent catalog/rename already advanced this name.
                workspaces.append(entry)
                continue
            attachment = AttachmentLease(
                id=receipt.attachment_id,
                lease_expires_at=receipt.lease_expires_at,
            )
            updated_entry = replace(
                entry,
                name=receipt.workspace_name,
                name_revision=receipt.name_revision,
                attachment=attachment,
            )
            changed = changed or updated_entry != entry
            workspaces.append(updated_entry)
        if changed:
            updated = replace(current, workspaces=tuple(workspaces))
            self.catalog_store.save(updated)
            changed = self._install_snapshot(
                updated, expected_state_version=expected_state_version
            )
        generation_changed = (
            batch.account.catalog_generation != snapshot.account.catalog_generation
        )
        return changed, batch.catalog_changed or generation_changed

    def _reattach_active_workspaces(
        self, session_ids: tuple[str, ...]
    ) -> bool:
        """Boundedly replace expired active leases without losing runtimes."""

        with self._lock:
            current = self._snapshot
            expected_state_version = self._state_version
        if current is None or not session_ids:
            return False
        batch = self.catalog_client.attach_workspaces(
            catalog_generation=current.snapshot_generation,
            workspace_ids=session_ids,
        )
        self._validate_account(batch.account)
        receipts = {item.session_id: item for item in batch.attachments}
        updated_entries: dict[str, WorkspaceCatalogEntry] = {}
        workspaces: list[WorkspaceCatalogEntry] = []
        for entry in current.workspaces:
            receipt = receipts.get(entry.session_id)
            if receipt is None:
                workspaces.append(entry)
                continue
            updated = replace(
                entry,
                name=receipt.workspace_name,
                name_revision=receipt.name_revision,
                storage=receipt.workspace_storage,
                attachment=receipt.attachment,
            )
            updated_entries[entry.session_id] = updated
            workspaces.append(updated)
        if set(updated_entries) != set(session_ids):
            raise NetworkError("Meshia omitted an active workspace reattachment.")
        updated_snapshot = replace(current, workspaces=tuple(workspaces))
        self.catalog_store.save(updated_snapshot)
        if not self._install_snapshot(
            updated_snapshot,
            expected_state_version=expected_state_version,
        ):
            return False
        return True

    def _runtime_poll_order(self) -> tuple[str, ...]:
        with self._lock:
            # A pending authority runtime may finish already-borrowed calls
            # and open-handle I/O, but must not begin fresh coordinator work
            # using an attachment that the control plane has superseded.
            return tuple(
                session_id
                for session_id, _active in sorted(
                    (
                        (session_id, active)
                        for session_id, active in self._active.items()
                        if session_id not in self._pending_authority
                        and session_id not in self._retired_storage_runtimes
                    ),
                    key=lambda item: (-item[1].last_used, item[0]),
                )
            )

    def _poll_runtime(self, session_id: str) -> bool:
        try:
            active = self._borrow_runtime(
                session_id, require_visible=False, touch=False
            )
        except OSError:
            return False
        try:
            poll = getattr(active.runtime.coordinator, "poll_once", None)
            did_work = bool(poll()) if callable(poll) else False
            readiness = active.runtime.coordinator.command_readiness
            if (
                isinstance(readiness, tuple)
                and len(readiness) == 3
                and readiness[0] is True
            ):
                # Once this activation has actually reached command safety,
                # its one foreground grace cannot be reused by a later cursor
                # refresh or recovery transition.
                with self._lock:
                    if self._active.get(session_id) is active:
                        active.first_mutation_wait_available = False
            tick = getattr(active.runtime.coordinator, "last_tick", None)
            if bool(getattr(tick, "remote_changed", False)):
                with self._lock:
                    label = self._labels.get(session_id)
                if label is not None:
                    raw_paths = getattr(tick, "remote_changed_paths", ())
                    paths = (
                        tuple(item for item in raw_paths if isinstance(item, str))
                        if isinstance(raw_paths, (tuple, list))
                        else ()
                    )
                    if paths:
                        self.mount_backend.invalidate_workspace(label, paths)
            return did_work
        except Disconnected as error:
            if self.retire_workspace_storage(session_id, error):
                return False
            self._hide_projection()
            raise
        finally:
            try:
                self._return_runtime(session_id, active, touch=False)
            finally:
                # Foreground Finder callbacks may be waiting for the bounded
                # first activation reconcile. Publish completion only; they
                # re-read the coordinator's O(1) readiness snapshot and never
                # poll or spin on the filesystem worker thread.
                with self._state_condition:
                    self._readiness_version += 1
                    self._state_condition.notify_all()

    def _poll_active_runtimes(self) -> bool:
        sessions = self._runtime_poll_order()
        with self._lock:
            cursor = self._poll_cursor
            eligible = set(sessions)
            urgent = tuple(
                session_id
                for session_id in self._urgent_sessions
                if session_id in eligible
            )
            stale_urgent = self._urgent_session_members - set(urgent)
            for session_id in stale_urgent:
                self._urgent_session_members.discard(session_id)
            if stale_urgent:
                self._urgent_sessions = deque(urgent)
        regular = tuple(session_id for session_id in sessions if session_id not in urgent)
        if cursor in regular:
            start = regular.index(cursor) + 1
            regular = regular[start:] + regular[:start]
        sessions = urgent + regular
        urgent_members = set(urgent)
        # SignedClient deliberately serializes sequence-bearing requests, so
        # one manager turn performs at most one due child poll. NodeRunner sees
        # the remaining zero deadline and immediately re-enters maintenance.
        # Rotate after every attempted child so a persistently due workspace
        # cannot strand another workspace's startup repair. User recency still
        # chooses the first child in each new rotation.
        for session_id in sessions:
            if self.stop_requested():
                return False
            with self._lock:
                active = self._active.get(session_id)
            if active is None:
                continue
            try:
                candidate = getattr(
                    active.runtime.coordinator, "next_poll_delay", None
                )
                value = candidate() if callable(candidate) else candidate
                delay = float(value)
            except (AttributeError, TypeError, ValueError):
                delay = 0.0
            if session_id not in urgent_members and delay == delay and delay > 0:
                continue
            with self._lock:
                if self._active.get(session_id) is not active:
                    continue
                if session_id in self._urgent_session_members:
                    self._urgent_session_members.discard(session_id)
                    try:
                        self._urgent_sessions.remove(session_id)
                    except ValueError:
                        pass
                # Advance before polling: even a failing child must yield the
                # next manager turn to other due workspaces.
                self._poll_cursor = session_id
            did_work = self._poll_runtime(session_id)
            if session_id in urgent_members:
                try:
                    candidate = getattr(
                        active.runtime.coordinator, "next_poll_delay", None
                    )
                    value = candidate() if callable(candidate) else candidate
                    follow_up_delay = float(value)
                except (AttributeError, TypeError, ValueError):
                    follow_up_delay = float("inf")
                if follow_up_delay == follow_up_delay and follow_up_delay <= 0:
                    # A local mutation often needs several serialized control
                    # turns (ticket, verify, manifest commit). Keep its owner
                    # ahead of unrelated periodic polls until it reaches a
                    # real wait; async completion will enqueue it again.
                    with self._lock:
                        if (
                            self._active.get(session_id) is active
                            and session_id not in self._pending_authority
                            and session_id not in self._urgent_session_members
                        ):
                            self._urgent_sessions.append(session_id)
                            self._urgent_session_members.add(session_id)
            return did_work
        return False

    def _retire_invisible_if_safe(self) -> None:
        with self._lock:
            retired = tuple(
                session_id
                for session_id in self._active
                if session_id not in self._entries
            )
        for session_id in retired:
            proxy = self._proxies.get(session_id)
            if proxy is not None:
                self._route_retired(session_id, proxy)

    def _heartbeat_if_due(self, now: float) -> tuple[bool, bool]:
        """Renew active workspace authority without starving foreground work.

        Native writes can keep a child coordinator continuously urgent for
        longer than the 90-second attachment lease.  Heartbeat maintenance is
        therefore checked after the foreground child has received its bounded
        turn as well as on the normal maintenance path.  A failed renewal stays
        fail-closed inside ``_apply_heartbeat``: an inactive lease is replaced
        through the authenticated account catalog before fresh runtime work is
        admitted.
        """

        with self._lock:
            if now < self._next_heartbeat:
                return False, False
        changed = force_catalog = False
        try:
            changed, force_catalog = self._apply_heartbeat()
        except BaseException as error:
            if (isinstance(error, RemoteError) and error.status == 409
                    and error.remote_code in {"CATALOG_CHANGED", "WORKSPACE_STORAGE_UNAVAILABLE"}):
                # A member of the batch disappeared while its lease was being
                # replaced. Refresh the account projection in this same turn;
                # do not replay the rejected attachment mutation or park the
                # surviving roots until the periodic catalog timer expires.
                return False, True
            if not self._is_transient(error):
                if isinstance(error, Disconnected):
                    self._hide_projection()
                raise
            self.logger.record(
                "workspace_heartbeat_deferred", error_code=type(error).__name__
            )
        finally:
            with self._lock:
                self._next_heartbeat = now + self.heartbeat_seconds
        return changed, force_catalog

    def poll_once(self) -> bool:
        """Run bounded catalog, lease, and active-runtime maintenance once."""

        with self._lock:
            self._authority_recreate_deferred.clear()
            started = self._started
            if self._closed:
                raise StateError("The workspace runtime manager is closed.")
        if not started:
            self.start()

        with self._lock:
            storage_projection = self._snapshot if self._storage_projection_pending else None
            self._storage_projection_pending = False
        if storage_projection is not None:
            try:
                self._install_snapshot(storage_projection, authoritative_attachments=False)
            except BaseException:
                with self._lock:
                    self._storage_projection_pending = True
                raise

        did_work = False
        if self.stop_requested():
            return False

        with self._lock:
            urgent_runtime = bool(self._urgent_sessions)
        if urgent_runtime:
            # A mounted mutation or completed byte worker is user-visible
            # foreground work. Give its one bounded child turn precedence over
            # potentially slow catalog/secondary-lease calls. Lease renewal is
            # still mandatory after that child turn: a stream of immediately
            # ready chunks must not starve its own workspace authority or a
            # catalog refresh that can revoke or resize that workspace.
            did_work = self._poll_active_runtimes() or did_work
            if self.stop_requested():
                return did_work
            now = float(self._clock())
            heartbeat_changed, force_catalog = self._heartbeat_if_due(now)
            did_work = heartbeat_changed or did_work
            if self.stop_requested():
                return did_work
            with self._lock:
                catalog_due = now >= self._next_catalog_refresh
                # Yield to a still-urgent workspace: its next turn (the apply
                # after a push poll, the commit after a wave) is user-visible;
                # the catalog projection can wait a few seconds, never more
                # than the grace bound.
                if (
                    catalog_due
                    and not force_catalog
                    and self._urgent_sessions
                    and now < self._next_catalog_refresh + PUSH_CATALOG_REFRESH_URGENT_GRACE_SECONDS
                ):
                    catalog_due = False
            if catalog_due or force_catalog:
                with self._lock:
                    cached = self._snapshot
                did_work = self._refresh_catalog(cached=cached) or did_work
                with self._lock:
                    self._last_catalog_refresh_at = now
                    self._next_catalog_refresh = (
                        now + self._catalog_refresh_interval()
                    )
                # Snapshot installation can fence an attachment replacement or
                # hide a workspace whose first close-safety probe was still
                # false. Give those bounded lifecycle edges one immediate
                # convergence pass; another continuously urgent workspace must
                # not retain a stale authority/runtime until urgency stops.
                did_work = self._retry_pending_authorities() or did_work
                self._retire_invisible_if_safe()
            released = self._refresh_startup_recovery()
            if catalog_due or force_catalog:
                with self._lock:
                    incomplete = bool(
                        self._startup_recovery_scan_saturated
                        or self._startup_recovery_unavailable_count
                    )
                if incomplete:
                    self._activate_startup_recovery()
            else:
                self._retry_incomplete_startup_recovery(released=released)
            return did_work

        now = float(self._clock())
        force_catalog = False
        with self._lock:
            heartbeat_due = now >= self._next_heartbeat
            catalog_due = now >= self._next_catalog_refresh

        if heartbeat_due:
            heartbeat_changed, force_catalog = self._heartbeat_if_due(now)
            did_work = heartbeat_changed or did_work
        if self.stop_requested():
            return did_work

        if catalog_due or force_catalog:
            with self._lock:
                cached = self._snapshot
            did_work = self._refresh_catalog(cached=cached) or did_work
            with self._lock:
                self._last_catalog_refresh_at = now
                self._next_catalog_refresh = now + self._catalog_refresh_interval()
        if self.stop_requested():
            return did_work

        did_work = self._retry_pending_authorities() or did_work
        did_work = self._poll_active_runtimes() or did_work
        did_work = self._retry_pending_authorities() or did_work
        self._retire_invisible_if_safe()
        released = self._refresh_startup_recovery()
        if catalog_due or force_catalog:
            with self._lock:
                incomplete = bool(
                    self._startup_recovery_scan_saturated
                    or self._startup_recovery_unavailable_count
                )
            if incomplete:
                self._activate_startup_recovery()
        else:
            self._retry_incomplete_startup_recovery(released=released)
        return did_work

    def wake(self) -> None:
        self._notify_child_wake()
        with self._lock:
            coordinators = tuple(
                active.runtime.coordinator for active in self._active.values()
            )
        for coordinator in coordinators:
            wake = getattr(coordinator, "wake", None)
            if callable(wake):
                wake()

    def wait(self, timeout: float) -> bool:
        if (
            isinstance(timeout, bool)
            or not isinstance(timeout, (int, float))
            or timeout < 0
        ):
            raise ValueError("timeout must not be negative")
        with self._wake_condition:
            observed = self._consumed_wake_generation
            if self._wake_generation == observed:
                self._wake_condition.wait_for(
                    lambda: self._wake_generation != observed,
                    timeout=float(timeout),
                )
            if self._wake_generation == observed:
                return False
            self._consumed_wake_generation = self._wake_generation
            return True

    def close(self) -> None:
        with self._state_condition:
            first_close = not self._closed
            if first_close:
                self._closed = True
                self._prepared = False
                self._started = False
                while self._projection_inflight or self._rename_inflight:
                    self._state_condition.wait()
                self._projection_inflight = True
                self._entries = {}
                self._labels = {}
                self._snapshot = None
                self._activation_unavailable.clear()
                self._state_version += 1
        if first_close:
            try:
                # No manager lock is held while acquiring mount topology.
                try:
                    self.mount_backend.replace_workspaces({})
                except StateError:
                    # A native mount startup failure closes its dispatcher
                    # before returning the error. Runtime shutdown must still
                    # drain independently owned coordinators and journals.
                    self.logger.record("workspace_mount_topology_already_closed")
            finally:
                with self._state_condition:
                    self._projection_inflight = False
                    self._state_condition.notify_all()
        self._retire_invisible_if_safe()
        with self._lock:
            retained = len(self._active)
            pending_primary = self._pending_primary_runtime
        if pending_primary is not None and pending_primary.can_close():
            with self._lock:
                if self._pending_primary_runtime is pending_primary:
                    self._pending_primary_runtime = None
                else:
                    pending_primary = None
            if pending_primary is not None:
                pending_primary.close()
        if retained:
            self.logger.record(
                "workspace_runtime_close_deferred", retained=retained
            )
        self.wake()
