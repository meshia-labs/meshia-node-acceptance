"""Machine discovery and process metrics — /proc on Linux, Win32 on Windows.

No psutil: everything here is stdlib (plus ``ctypes`` for the two Win32 calls
that have no /proc analog). Values are bounded and sanitised to the control
plane's capability allowlist (``normalizeEnrollment`` in
web/lib/connected-hosts.ts) before they are ever sent.
"""

from __future__ import annotations

import ctypes
import os
import platform
import posixpath
import re
import shutil
import socket
import subprocess
import sys
import time
from dataclasses import dataclass

from .identity import KEY_PROTECTION
from .util import CAPABILITY_VALUE_RE

# Server-side ceilings (web/lib/connected-hosts.ts `boundedUnsigned`).
MAX_CPU_LOGICAL = 1024
MAX_MEMORY_BYTES = 2**51
MAX_GPU_COUNT = 256
_MACHINE_FAMILIES = {"x86_64": "x86_64", "amd64": "x86_64", "aarch64": "arm64", "arm64": "arm64"}
_GPU_FAMILIES = ("nvidia", "amd", "intel")
_WINDOWS_DISPLAY_ONLY_ADAPTERS = (
    "microsoft basic", "microsoft remote display", "microsoft hyper-v video",
)
_APPLE_CHIP_RE = re.compile(r"^Apple M[1-9][0-9]?(?: Pro| Max| Ultra)?$")
_CGROUP_ROOT = "/sys/fs/cgroup"
_CGROUP_V1_CPU_MOUNTS = ("cpu", "cpu,cpuacct")
_CGROUP_V1_MEMORY_MOUNT = "memory"
# Linux cgroup v1 represents an unlimited memory controller with a page-aligned
# LONG_MAX value (normally 9223372036854771712 on 64-bit kernels). A real limit
# above this threshold is already far beyond Meshia's server-side capability
# ceiling, so treating it as unlimited cannot hide usable capacity.
_CGROUP_V1_UNLIMITED_MEMORY_MIN = 1 << 60


def sanitize_capability(value: str, fallback: str = "unknown") -> str:
    """Coerce a free-form probe result into the server's capability charset."""
    collapsed = " ".join(re.sub(r"[^A-Za-z0-9 ._:+()-]", " ", value).split())[:96]
    return collapsed if collapsed and CAPABILITY_VALUE_RE.match(collapsed) else fallback


def _read_text(path: str, limit: int = 65536) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as stream:
            return stream.read(limit)
    except OSError:
        return ""


def _cgroup_memberships() -> tuple[str | None, dict[str, str]]:
    """Return the current process's validated v2 and v1 cgroup paths."""
    unified: str | None = None
    controllers: dict[str, str] = {}
    for line in _read_text("/proc/self/cgroup", limit=16384).splitlines():
        hierarchy, separator, remainder = line.partition(":")
        if not separator:
            continue
        names, separator, raw_path = remainder.partition(":")
        if not separator or not raw_path.startswith("/") or "\x00" in raw_path:
            continue
        path = posixpath.normpath("/" + raw_path.lstrip("/"))
        if hierarchy == "0" and not names:
            unified = path
            continue
        for name in names.split(","):
            if name:
                controllers.setdefault(name, path)
    return unified, controllers


def _cgroup_ancestor_dirs(mount: str, membership: str | None) -> tuple[str, ...]:
    """List the member cgroup and its parents, bounded at the controller mount."""
    parts = () if not membership or membership == "/" else tuple(membership.strip("/").split("/"))
    directories: list[str] = []
    for length in range(len(parts), -1, -1):
        candidate = posixpath.join(mount, *parts[:length])
        if candidate not in directories:
            directories.append(candidate)
    return tuple(directories)


def _parse_positive_int(value: str) -> int | None:
    try:
        parsed = int(value, 10)
    except ValueError:
        return None
    return parsed if parsed > 0 else None


def _quota_cpu_count(quota: str, period: str, *, unlimited: str) -> int | None:
    if quota == unlimited:
        return None
    parsed_quota = _parse_positive_int(quota)
    parsed_period = _parse_positive_int(period)
    if parsed_quota is None or parsed_period is None:
        return None
    # The capability is an integer count. Round down so a fractional quota is
    # never advertised as more parallel CPU than the cgroup can actually use;
    # the schema's minimum of one represents sub-CPU quotas conservatively.
    return max(1, parsed_quota // parsed_period)


def _v2_cpu_limit(membership: str | None) -> tuple[bool, int | None]:
    present = bool(_read_text(posixpath.join(_CGROUP_ROOT, "cgroup.controllers")).strip())
    limits: list[int] = []
    for directory in _cgroup_ancestor_dirs(_CGROUP_ROOT, membership):
        raw = _read_text(posixpath.join(directory, "cpu.max"), limit=256).strip()
        if not raw:
            continue
        present = True
        fields = raw.split()
        if len(fields) != 2:
            continue
        limit = _quota_cpu_count(fields[0], fields[1], unlimited="max")
        if limit is not None:
            limits.append(limit)
    return present, min(limits) if limits else None


def _v1_cpu_limit(controllers: dict[str, str]) -> tuple[bool, int | None]:
    membership = controllers.get("cpu") or controllers.get("cpuacct")
    present = False
    limits: list[int] = []
    for mount_name in _CGROUP_V1_CPU_MOUNTS:
        mount = posixpath.join(_CGROUP_ROOT, mount_name)
        for directory in _cgroup_ancestor_dirs(mount, membership):
            quota = _read_text(posixpath.join(directory, "cpu.cfs_quota_us"), limit=256).strip()
            period = _read_text(posixpath.join(directory, "cpu.cfs_period_us"), limit=256).strip()
            if not quota and not period:
                continue
            present = True
            if not quota or not period:
                continue
            limit = _quota_cpu_count(quota, period, unlimited="-1")
            if limit is not None:
                limits.append(limit)
    return present, min(limits) if limits else None


def _cgroup_cpu_limit() -> int | None:
    if sys.platform != "linux":
        return None
    unified, controllers = _cgroup_memberships()
    v2_present, v2_limit = _v2_cpu_limit(unified)
    if v2_present:
        return v2_limit
    _v1_present, v1_limit = _v1_cpu_limit(controllers)
    return v1_limit


def cpu_logical() -> int:
    physical = min(max(os.cpu_count() or 1, 1), MAX_CPU_LOGICAL)
    limit = _cgroup_cpu_limit()
    return min(physical, limit) if limit is not None else physical


def _parse_memory_limit(value: str, *, unlimited: str | None) -> int | None:
    if unlimited is not None and value == unlimited:
        return None
    limit = _parse_positive_int(value)
    if limit is None:
        return None
    if unlimited is None and limit >= _CGROUP_V1_UNLIMITED_MEMORY_MIN:
        return None
    return min(limit, MAX_MEMORY_BYTES)


def _v2_memory_limit(membership: str | None) -> tuple[bool, int | None]:
    present = bool(_read_text(posixpath.join(_CGROUP_ROOT, "cgroup.controllers")).strip())
    limits: list[int] = []
    for directory in _cgroup_ancestor_dirs(_CGROUP_ROOT, membership):
        raw = _read_text(posixpath.join(directory, "memory.max"), limit=256).strip()
        if not raw:
            continue
        present = True
        limit = _parse_memory_limit(raw, unlimited="max")
        if limit is not None:
            limits.append(limit)
    return present, min(limits) if limits else None


def _v1_memory_limit(controllers: dict[str, str]) -> tuple[bool, int | None]:
    membership = controllers.get("memory")
    present = False
    limits: list[int] = []
    mount = posixpath.join(_CGROUP_ROOT, _CGROUP_V1_MEMORY_MOUNT)
    for directory in _cgroup_ancestor_dirs(mount, membership):
        raw = _read_text(posixpath.join(directory, "memory.limit_in_bytes"), limit=256).strip()
        if not raw:
            continue
        present = True
        limit = _parse_memory_limit(raw, unlimited=None)
        if limit is not None:
            limits.append(limit)
    return present, min(limits) if limits else None


def _cgroup_memory_limit() -> int | None:
    if sys.platform != "linux":
        return None
    unified, controllers = _cgroup_memberships()
    v2_present, v2_limit = _v2_memory_limit(unified)
    if v2_present:
        return v2_limit
    _v1_present, v1_limit = _v1_memory_limit(controllers)
    return v1_limit


@dataclass(frozen=True)
class GpuInventory:
    family: str
    count: int
    names: tuple[str, ...]


@dataclass(frozen=True)
class MachineInventory:
    platform: str
    platform_version: str
    architecture: str
    machine_family: str
    model: str
    hostname: str
    cpu_logical: int
    memory_bytes: int
    gpu: GpuInventory
    apple_chip: str | None = None

    @property
    def display_name(self) -> str:
        # This is only the generated name. Explicit --name values bypass it.
        label = self.hostname.strip()
        suffix = f" ({self.model})"
        if self.model != "unknown" and label.endswith(suffix):
            label = label[:-len(suffix)]
        label = re.sub(r"\.local\.?$", "", label, flags=re.IGNORECASE)
        return sanitize_capability(label, fallback="meshia-node")[:96]


def cpu_model() -> str:
    if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
        name = _windows_cpu_model()
        if name:
            return sanitize_capability(name)
    if sys.platform == "darwin":  # pragma: no branch - exercised on macOS hosts
        name = _darwin_sysctl("machdep.cpu.brand_string")
        if name:
            return sanitize_capability(name)
    for line in _read_text("/proc/cpuinfo").splitlines():
        key, separator, value = line.partition(":")
        if separator and key.strip() in ("model name", "Model", "Hardware", "cpu model"):
            return sanitize_capability(value.strip())
    return sanitize_capability(platform.processor() or "unknown")


def _darwin_sysctl(name: str, timeout: float = 2.0) -> str:
    """Read one allowlisted macOS system fact with fixed argv and a hard timeout."""
    if name != "machdep.cpu.brand_string":
        return ""
    try:
        completed = subprocess.run(  # noqa: S603 - fixed executable + allowlisted argv
            ["/usr/sbin/sysctl", "-n", name],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return completed.stdout.strip() if completed.returncode == 0 else ""


def _apple_chip(model: str) -> str | None:
    candidate = sanitize_capability(model, fallback="")
    return candidate if _APPLE_CHIP_RE.fullmatch(candidate) else None


def _windows_cpu_model() -> str:  # pragma: no cover - exercised on Windows hosts
    try:
        import winreg

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0"
        ) as key:
            value, _ = winreg.QueryValueEx(key, "ProcessorNameString")
            return str(value).strip()
    except OSError:
        return ""


def _physical_memory_bytes() -> int:
    if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
        total = _windows_memory_bytes()
        if total:
            return min(total, MAX_MEMORY_BYTES)
    match = re.search(r"^MemTotal:\s+(\d+)\s+kB", _read_text("/proc/meminfo"), re.M)
    if match:
        return min(int(match.group(1)) * 1024, MAX_MEMORY_BYTES)
    try:  # non-Linux development hosts
        return min(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"), MAX_MEMORY_BYTES)
    except (OSError, ValueError, AttributeError):
        return 0


def memory_bytes() -> int:
    physical = _physical_memory_bytes()
    limit = _cgroup_memory_limit()
    if limit is None:
        return physical
    return min(physical, limit) if physical else limit


class _MemoryStatusEx(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_uint64),
        ("ullAvailPhys", ctypes.c_uint64),
        ("ullTotalPageFile", ctypes.c_uint64),
        ("ullAvailPageFile", ctypes.c_uint64),
        ("ullTotalVirtual", ctypes.c_uint64),
        ("ullAvailVirtual", ctypes.c_uint64),
        ("ullAvailExtendedVirtual", ctypes.c_uint64),
    ]


def _windows_memory_bytes() -> int:  # pragma: no cover - exercised on Windows hosts
    try:
        status = _MemoryStatusEx()
        status.dwLength = ctypes.sizeof(status)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
        if kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullTotalPhys)
    except Exception:
        pass
    return 0


def _nvidia_smi_path() -> str | None:
    """nvidia-smi from PATH, plus the two canonical Windows install locations."""
    found = shutil.which("nvidia-smi")
    if found:
        return found
    if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
        system_root = os.environ.get("SystemRoot", r"C:\Windows")
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        for candidate in (
            os.path.join(system_root, "System32", "nvidia-smi.exe"),
            os.path.join(program_files, "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe"),
        ):
            if os.path.isfile(candidate):
                return candidate
    return None


def gpu_inventory(timeout: float = 4.0) -> GpuInventory:
    """Report the native Apple GPU, then nvidia-smi or a cheap platform sweep."""
    if sys.platform == "darwin" and platform.machine().lower() in {"arm64", "aarch64"}:
        # All supported Apple Silicon Macs expose one integrated Metal GPU. GPU
        # utilization remains explicitly unsupported; this is static inventory.
        return GpuInventory("apple_integrated", 1, ())
    smi = _nvidia_smi_path()
    if smi:
        try:
            completed = subprocess.run(
                [smi, "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
            names = tuple(
                sanitize_capability(line.strip())
                for line in completed.stdout.splitlines()
                if line.strip()
            )
            if names:
                return GpuInventory("nvidia", min(len(names), MAX_GPU_COUNT), names[:MAX_GPU_COUNT])
        except (OSError, subprocess.SubprocessError):
            pass
    if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
        return _windows_gpu_inventory(timeout)
    drivers = set()
    try:
        for entry in os.listdir("/sys/class/drm"):
            if not re.fullmatch(r"card\d+", entry):
                continue
            link = _read_text(f"/sys/class/drm/{entry}/device/uevent")
            match = re.search(r"^DRIVER=(\S+)", link, re.M)
            if match:
                drivers.add(match.group(1).lower())
    except OSError:
        pass
    for family in _GPU_FAMILIES:
        if any(family in driver or (family == "amd" and "amdgpu" in driver) for driver in drivers):
            return GpuInventory(family, 1, ())
    return GpuInventory("none", 0, ())


def classify_gpu_family(names: list[str]) -> str:
    """Map adapter display names to the server's gpu_family allowlist."""
    lowered = " ".join(names).lower()
    if "nvidia" in lowered or "geforce" in lowered or "quadro" in lowered or "tesla" in lowered:
        return "nvidia"
    if "amd" in lowered or "radeon" in lowered:
        return "amd"
    if "intel" in lowered:
        return "intel"
    return "none" if not names else "unknown"


def _windows_gpu_inventory(timeout: float) -> GpuInventory:
    """Exclude Windows display transports; retain unrecognized physical adapters."""
    try:
        completed = subprocess.run(  # noqa: S603 - fixed argv
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                "(Get-CimInstance Win32_VideoController | "
                "Select-Object -ExpandProperty Name) -join \"`n\"",
            ],
            capture_output=True,
            text=True,
            timeout=max(timeout, 8.0),
            check=False,
        )
        if completed.returncode != 0:
            return GpuInventory("none", 0, ())
        names = [
            sanitize_capability(line.strip())
            for line in completed.stdout.splitlines()
            if line.strip() and not any(
                adapter in line.casefold() for adapter in _WINDOWS_DISPLAY_ONLY_ADAPTERS
            )
        ]
    except (OSError, subprocess.SubprocessError):
        names = []
    if not names:
        return GpuInventory("none", 0, ())
    family = classify_gpu_family(names)
    return GpuInventory(family, min(len(names), MAX_GPU_COUNT), tuple(names[:MAX_GPU_COUNT]))


def inventory() -> MachineInventory:
    uname = platform.uname()
    raw_architecture = sanitize_capability(uname.machine or "unknown")
    # Report the canonical spelling where we recognise it, so the same silicon
    # reads identically whatever the OS calls it (Windows says AMD64, Linux says
    # x86_64) and the workspace can group machines meaningfully.
    architecture = _MACHINE_FAMILIES.get(raw_architecture.lower(), raw_architecture)
    model = cpu_model()
    apple_chip = _apple_chip(model) if uname.system.lower() == "darwin" else None
    machine_family = _MACHINE_FAMILIES.get(architecture.lower(), "unknown")
    if uname.system.lower() == "darwin" and architecture == "arm64":
        machine_family = "apple_silicon"
    gpu = (
        GpuInventory("apple_integrated", 1, ())
        if machine_family == "apple_silicon"
        else gpu_inventory()
    )
    return MachineInventory(
        platform=uname.system.lower() or "linux",
        platform_version=sanitize_capability(uname.release or "unknown"),
        architecture=architecture,
        machine_family=machine_family,
        model=model,
        hostname=sanitize_capability(socket.gethostname(), fallback="meshia-node"),
        cpu_logical=cpu_logical(),
        memory_bytes=memory_bytes(),
        gpu=gpu,
        apple_chip=apple_chip,
    )


def capabilities(machine: MachineInventory, tier: str) -> dict[str, str]:
    """Build the enrollment capability map inside the server's allowlist.

    Only keys in ``allowedCapabilities`` may appear, every value must be a
    1..96 char string matching ``^[A-Za-z0-9 ._:+()-]+$``, and the three
    numeric keys must be canonical bounded integers.
    """
    # Capability describes support. Only the server's owner grant permits execution.
    del tier
    from .native_execution import full_available
    native_ready = full_available()
    values = {
        "executor": "native-host" if native_ready else "unavailable",
        "filesystem": "synchronized-workspace-v1",
        "outside_workspace": "owner-granted" if native_ready else "unsupported",
        "task_network": "owner-granted" if native_ready else "unsupported",
        "gpu_utilization": "unsupported",
        "key_protection": KEY_PROTECTION,
        "release_tier": "development-canary",
        "machine_family": machine.machine_family,
        "cpu_logical": str(machine.cpu_logical),
        "memory_bytes": str(machine.memory_bytes),
        "gpu_family": machine.gpu.family,
        "gpu_count": str(min(machine.gpu.count, MAX_GPU_COUNT)),
    }
    if machine.apple_chip:
        values["apple_chip"] = machine.apple_chip
    model = sanitize_capability(machine.model)
    if model.casefold() != "unknown":
        values["cpu_model"] = model
    gpu_models = list(dict.fromkeys(
        name for raw in machine.gpu.names
        if (name := sanitize_capability(raw, fallback="")) and name.casefold() != "unknown"
    ))
    if machine.gpu.family == "apple_integrated" and machine.apple_chip and not gpu_models:
        gpu_models = [machine.apple_chip]
    if machine.gpu.count > 0 and gpu_models:
        values["gpu_model"] = sanitize_capability(" + ".join(gpu_models))
    if native_ready:
        values["app_protocol"] = "http-stream-v1"
    return values


class ProcessSampler:
    """Self+children CPU/RSS sampler, mirroring the Swift node's metrics loop."""

    def __init__(self) -> None:
        self._clock_ticks = float(os.sysconf("SC_CLK_TCK")) if hasattr(os, "sysconf") else 100.0
        self._previous: tuple[float, float] | None = None

    def cpu_seconds(self) -> float:
        stat = _read_text("/proc/self/stat", limit=4096)
        if stat:
            # utime, stime, cutime, cstime are fields 14..17 after the comm field.
            tail = stat.rpartition(")")[2].split()
            if len(tail) >= 15:
                try:
                    return sum(float(tail[index]) for index in (11, 12, 13, 14)) / self._clock_ticks
                except ValueError:
                    pass
        usage = os.times()
        return usage.user + usage.system + usage.children_user + usage.children_system

    def resident_bytes(self) -> int:
        if sys.platform == "win32":  # pragma: no cover - exercised on Windows hosts
            return _windows_resident_bytes()
        match = re.search(r"^VmRSS:\s+(\d+)\s+kB", _read_text("/proc/self/status"), re.M)
        if match:
            return int(match.group(1)) * 1024
        try:
            import resource

            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # Linux reports kB, macOS reports bytes.
            return int(peak) * (1 if peak > 10**9 else 1024)
        except Exception:  # pragma: no cover - defensive
            return 0

    def sample(self, now: float | None = None) -> tuple[float, int]:
        """Return (cpu_percent bounded to 0..100, resident bytes)."""
        moment = now if now is not None else time.time()
        total = self.cpu_seconds()
        percent = 0.0
        if self._previous is not None:
            previous_at, previous_total = self._previous
            elapsed = max(moment - previous_at, 0.001)
            percent = max(0.0, min(100.0, (total - previous_total) / elapsed * 100.0))
        self._previous = (moment, total)
        return round(percent, 3), max(0, self.resident_bytes())


class _ProcessMemoryCounters(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("PageFaultCount", ctypes.c_ulong),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def _windows_resident_bytes() -> int:  # pragma: no cover - exercised on Windows hosts
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
        psapi = ctypes.WinDLL("psapi", use_last_error=True)  # type: ignore[attr-defined]
        # GetCurrentProcess returns (HANDLE)-1; without an explicit restype ctypes
        # truncates it to 32 bits and the call fails with ERROR_INVALID_HANDLE.
        kernel32.GetCurrentProcess.restype = ctypes.c_void_p
        kernel32.GetCurrentProcess.argtypes = []
        psapi.GetProcessMemoryInfo.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong
        ]
        counters = _ProcessMemoryCounters()
        counters.cb = ctypes.sizeof(counters)
        if psapi.GetProcessMemoryInfo(
            kernel32.GetCurrentProcess(), ctypes.byref(counters), counters.cb
        ):
            return int(counters.WorkingSetSize)
    except Exception:
        pass
    return 0


def disk_free_bytes(path: str) -> int:
    try:
        usage = shutil.disk_usage(path)
        return int(usage.free)
    except OSError:
        return 0
