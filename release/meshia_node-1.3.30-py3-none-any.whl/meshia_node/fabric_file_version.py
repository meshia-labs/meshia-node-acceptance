"""Open-file ownership of immutable remote bytes, shared by reads and COW.

The pool belongs to one authenticated workspace coordinator. It shares read
holds across local descriptions; write holds belong to one durable journal ID.
No pathname lookup is allowed to substitute bytes after a hold is acquired.
"""
from __future__ import annotations

import copy
import errno
import threading
import time
import uuid
from collections import OrderedDict, deque
from contextlib import contextmanager
from datetime import datetime
from typing import Callable, Iterator

from .errors import NetworkError, RemoteError
from .fabric_db import RemoteEntry, RemoteManifestHead

_TTL = 900


class FabricFileVersion:
    def __init__(self, pool, entry, head, mode, hold_id, key):
        self.pool = pool
        self.entry = copy.deepcopy(entry)
        self.head = head
        self.mode, self.hold_id, self.key = mode, hold_id, key
        self.references = 0
        self.inflight = 0
        self.closed = False
        self._acquired = False
        self._uncertain = False
        self._deadline = 0.0
        self._renew_at = 0.0
        self._retry_at = 0.0
        self._lock = threading.RLock()
        self.tickets = OrderedDict()
        self.ticket_lock = threading.Lock()

    def _payload(self, action):
        result = {"operation": "file_hold", "action": action, "hold_id": self.hold_id}
        if action in {"acquire", "renew"}:
            result["ttl_seconds"] = _TTL
        if action == "acquire":
            result.update(path=self.entry.path, file_digest=self.entry.digest,
                          size_bytes=self.entry.size_bytes, mode=self.mode)
        return result

    def _accept(self, response):
        if (not isinstance(response, dict)
                or response.get("schema") != "meshia.fabric_file_hold.v1"
                or response.get("operation") != "file_hold"
                or response.get("hold_id") != self.hold_id
                or response.get("path") != self.entry.path
                or response.get("digest") != self.entry.digest
                or type(response.get("size_bytes")) is not int
                or response.get("size_bytes") != self.entry.size_bytes
                or response.get("mode") != self.mode or response.get("released") is not False
                or response.get("storage_kind") != self.entry.blocks["storage"]["kind"]):
            raise NetworkError("The file-version hold response changed its immutable identity")
        expires = response.get("expires_at")
        if self.mode == "write":
            if expires is not None:
                raise NetworkError("A pending-write base must have durable ownership")
            self._deadline = self._renew_at = float("inf")
        else:
            try:
                stamp = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    raise ValueError("timezone required")
                remaining = stamp.timestamp() - self.pool.wall_time()
                if not 0 < remaining <= _TTL + 60:
                    raise ValueError("expiry out of bounds")
            except (AttributeError, TypeError, ValueError) as error:
                raise NetworkError("The file-version hold has an invalid expiry") from error
            self._deadline = self.pool.clock() + remaining
            # Renew with enough room for a bounded queue of open descriptions.
            self._renew_at = self.pool.clock() + max(0, remaining - _TTL * 2 / 3)
        self._acquired = True
        self._uncertain = False
        self._retry_at = 0.0

    def acquire(self):
        with self._lock:
            self.pool.check_context(self.head)
            if self.closed or self.pool.closed:
                raise OSError(errno.EBADF, "The remote file description is closed")
            if self._acquired:
                self.ensure()
                return
            if self._uncertain:
                # Resolve an interrupted acquisition before submitting again.
                # The same UUID never becomes authority for a different base.
                try:
                    self._accept(self.pool.request(self._payload("status")))
                    return
                except RemoteError as error:
                    if error.remote_code != "FABRIC_FILE_HOLD_EXPIRED":
                        raise
                    # No readable hold exists. Acquire with the original ID;
                    # a released/expired tombstone still rejects resurrection.
            self._uncertain = True
            self._accept(self.pool.request(self._payload("acquire")))

    def ensure(self):
        self.pool.check_context(self.head)
        with self._lock:
            if self.closed or self.pool.closed:
                raise OSError(errno.EBADF, "The remote file description is closed")
            if not self._acquired:
                self.acquire()
            now = self.pool.clock()
            if now >= self._deadline:
                raise OSError(errno.ESTALE, "The open remote file lost its retention lease")
            if now >= self._renew_at:
                self._accept(self.pool.request(self._payload("renew")))

    def stream(self, offset: int, length: int) -> Iterator[bytes]:
        if (type(offset) is not int or type(length) is not int or offset < 0 or length < 0
                or offset + length > self.entry.size_bytes):
            raise ValueError("The held file range exceeds its original version")
        with self.pool.reading(self):
            self.ensure()
            total = 0
            for data in self.pool.stream(self, offset, length):
                self.ensure()
                if not isinstance(data, bytes) or len(data) > 1024 * 1024 or total + len(data) > length:
                    raise NetworkError("The held file reader exceeded its range bound")
                total += len(data)
                yield data
            self.ensure()
            if total != length:
                raise NetworkError("The held file range ended early")

    def read_source(self, kind, digest, size, offset, count, ancestors=()):
        with self.pool.reading(self):
            self.ensure()
            data = self.pool.read_source(self, kind, digest, size, offset, count, ancestors)
            self.ensure()
            return data


class FabricFileVersionPool:
    def __init__(self, *, request: Callable, check_context: Callable, stream: Callable,
                 read_source: Callable, clock=time.monotonic, wall_time=time.time):
        self.request, self.check_context, self.stream, self.read_source = request, check_context, stream, read_source
        self.clock, self.wall_time = clock, wall_time
        self.closed = False
        self._lock = threading.RLock()
        self._versions = {}
        self._owned = set()
        self._retired = deque()

    def open(self, entry: RemoteEntry, head: RemoteManifestHead, *, mode="read", hold_id=None):
        if mode not in {"read", "write"} or (mode == "write" and hold_id is None):
            raise ValueError("A pending write requires its durable journal hold ID")
        if hold_id is not None and str(uuid.UUID(hold_id)) != hold_id:
            raise ValueError("The file hold ID must be canonical")
        key = (entry.path, entry.digest, entry.size_bytes, entry.blocks["storage"]["kind"], mode, hold_id)
        with self._lock:
            if self.closed:
                raise OSError(errno.EBADF, "The file-version pool is closed")
            version = self._versions.get(key)
            if (version is not None and mode == "read" and version._acquired
                    and self.clock() >= version._deadline):
                # Old descriptions remain stale; a new open can acquire the
                # current live version without reviving an expired hold.
                self._versions.pop(key)
                version = None
            if version is None:
                if len(self._owned) >= 4096:
                    raise OSError(errno.EMFILE, "Too many retained remote file versions")
                version = FabricFileVersion(self, entry, head, mode, hold_id or str(uuid.uuid4()), key)
                self._versions[key] = version
                self._owned.add(version)
            version.references += 1
        try:
            version.acquire()
            if self.closed or version.closed:
                raise OSError(errno.EBADF, "The file-version pool closed during acquisition")
            return version
        except BaseException:
            # Keep an uncertain acquisition addressable by its original UUID.
            # The next open reads its status; retirement must not race it.
            with self._lock:
                version.references -= 1
            raise

    def release(self, version):
        if version.mode != "read":
            raise ValueError("A journal releases its durable base only after acknowledgement or cancellation")
        with self._lock:
            if version not in self._owned or version.references <= 0:
                return
            version.references -= 1
            self._retire_idle(version)

    def _retire_idle(self, version):
        # Called with the pool lock. An already-running syscall owns its
        # version until its final chunk, even if another thread closes the FD.
        if version.mode == "read" and not version.closed and not version.references and not version.inflight:
            if self._versions.get(version.key) is version:
                self._versions.pop(version.key)
            version.closed = True
            self._retired.append(version)

    @contextmanager
    def reading(self, version):
        with self._lock:
            if self.closed or version.closed or version not in self._owned:
                raise OSError(errno.EBADF, "The remote file description is closed")
            version.inflight += 1
        try:
            yield
        finally:
            with self._lock:
                version.inflight -= 1
                self._retire_idle(version)

    def release_write(self, version):
        if version.mode != "write":
            raise ValueError("Expected a durable write base")
        # The owning journal keeps its cleanup marker until this succeeds.
        response = self.request(version._payload("release"))
        if not isinstance(response, dict) or response.get("hold_id") != version.hold_id or response.get("released") is not True:
            raise NetworkError("The write base release was not acknowledged")
        self.complete_write_release(version.hold_id)

    def complete_write_release(self, hold_id):
        """Forget a write hold only after its release was authoritatively read back."""
        with self._lock:
            versions = tuple(value for value in self._owned if value.mode == "write" and value.hold_id == hold_id)
            if any(value.inflight for value in versions):
                raise OSError(errno.EBUSY, "A native read still owns the write source")
            for version in versions:
                self._versions.pop(version.key, None)
                self._owned.discard(version)
                version.closed = True

    def maintain(self, limit=4):
        if self.closed:
            return
        now = self.clock()
        with self._lock:
            # Failed opens have no handle owner. Retire their UUID directly;
            # release is idempotent even if acquisition never reached the server.
            for value in tuple(self._owned):
                self._retire_idle(value)
            due = sorted((value for value in self._owned
                          if value._acquired and not value.closed and value.mode == "read"
                          and value._renew_at <= now and value._retry_at <= now), key=lambda value: value._deadline)[:limit]
            retired = []
            for _ in range(len(self._retired)):
                if len(due) + len(retired) >= limit:
                    break
                value = self._retired.popleft()
                if value._retry_at > now:
                    self._retired.append(value)
                else:
                    retired.append(value)
        for version in due:
            try:
                version.ensure()
            except (OSError, NetworkError, RemoteError):
                version._retry_at = now + 5
        for version in retired:
            try:
                response = self.request(version._payload("release"))
                if not isinstance(response, dict) or response.get("hold_id") != version.hold_id or response.get("released") is not True:
                    raise NetworkError("The read hold release was not acknowledged")
                with self._lock:
                    self._owned.discard(version)
            except (OSError, NetworkError, RemoteError):
                version._retry_at = now + 5
                with self._lock:
                    self._retired.append(version)

    def next_maintenance(self):
        with self._lock:
            if self.closed:
                return float("inf")
            return min((max(value._retry_at, value._renew_at if value._acquired
                            and not value.closed and (value.references or value.inflight) else 0)
                        for value in self._owned if value.mode == "read"), default=float("inf"))

    def close(self):
        with self._lock:
            self.closed = True
            # Read holds expire after shutdown; write holds remain owned by
            # durable journals. Shutdown must not discard their only base.
            self._versions.clear()
            self._owned.clear()
            self._retired.clear()
