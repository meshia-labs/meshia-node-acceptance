"""Mount-side proxy and engine-side server for the split-process node.

The mount keeps its own ``FabricDatabase`` handle, so metadata reads --
``getattr``, ``readdir``, ``lookup``, the attribute and readdir caches -- never
cross the boundary. That is deliberate and is where the win lives: measured on
the real backend, a ``getattr`` costs 66 us alone, 17,557 us beside four
interpreter-bound threads, and 67 us beside the same work in another process.

Only genuinely cross-process concerns travel over IPC:

* staging a write, delete or rename (must fail loudly; losing one would lose
  data),
* ``wake``/``warm`` signals (best-effort by construction),
* file content streaming, which reaches the network on a cache miss anyway,
* and, in the reverse direction, the mount-cleanup fence, the close-safety
  probe, the catalog projection (labels, quota, running set, folder dates)
  and namespace invalidations.

Multi-workspace topology
------------------------

Production mounts one ``~/Meshia`` root with every account workspace beneath
it. In split mode the **engine** keeps ``WorkspaceRuntimeManager`` (catalog,
attachments, heartbeats, coordinators, uploads, hydration) and the **mount
worker** keeps ``MultiWorkspaceMountBackend`` with one real
``FabricMountBackend`` per activated workspace. Every message therefore names a
``session_id``; the engine resolves it through the manager exactly as the
in-process ``_LazyWorkspaceBackend`` would (visibility fence, mutation-ready
fence, runtime pinning), so a mounted write meets the same admission rules
whichever process it starts in.

Callbacks
---------

``stage_file_provider_write``/``stage_file_provider_delete`` take a
``publish_local_namespace`` closure that the coordinator runs *inside* its
namespace stripe. That closure owns mount-process state, so it cannot move; it
is replaced on the wire by a token and the engine calls back over the same
duplex link while it holds the stripe. The IPC endpoint runs handlers off its
reader thread precisely so that nested reply can be delivered.

Fail-closed rules, matching the semantics each call already documents:

* a staging call with no engine raises ``OSError(EIO)`` -- never a silent drop,
* the cleanup fence answers "unknown" when the mount is unreachable, which
  ``set_mount_cleanup_fence`` already defines as *do not reclaim*,
* the close-safety probe answers *unsafe* while a mount is connected but does
  not answer, and *safe* only when no mount process exists,
* ``wake``/``warm`` are dropped silently, as they already are in-process when
  the coordinator declines them.
"""

from __future__ import annotations

import base64
import errno
import json
import os
import sys
import threading
import time
import uuid
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from typing import Any

from .errors import StateError
from .log import NULL_LOGGER, NodeLogger
from .sync_engine_files import EngineFileDescriptions, RemoteFileVersion, RemoteNativeJournal
from .sync_engine_ipc import (
    IpcEndpoint,
    IpcError,
    IpcRemoteError,
    IpcUnavailable,
    connect,
    listen,
    socket_path,
)

# Content is moved in bounded frames; 256 KiB keeps a frame well inside the
# IPC bound while amortising the per-frame cost over a useful payload.
STREAM_CHUNK_BYTES = 256 * 1024
# Staging is durable work behind a signed control call, so it is allowed a
# longer budget than a metadata query, but never an unbounded one.
STAGE_TIMEOUT_SECONDS = 120.0
FENCE_TIMEOUT_SECONDS = 5.0
# The mount holds a path's open/create admission while the engine reclaims a
# retired inode behind it. If the engine never says it is done (it died, or
# the link dropped), the hold expires on its own so a Finder open of that
# path can never wait indefinitely on a peer.
FENCE_HOLD_MAX_SECONDS = 30.0
# A callback runs mount-local filesystem work (publishing a stage into the
# materialized root); it is bounded by that work, not by the network.
CALLBACK_TIMEOUT_SECONDS = 60.0
# A catalog projection is a handful of labels; the mount applies it under its
# topology lock, which a concurrent root rename may hold for one control call.
TOPOLOGY_TIMEOUT_SECONDS = 30.0
# Activation may attach the workspace (a signed call) and build its runtime.
ACTIVATE_TIMEOUT_SECONDS = 120.0
# Typed commands share the existing authenticated local link, not a second
# filesystem owner. Reserve handler capacity for their nested stream/stage
# callbacks; a saturated command lane fails immediately rather than deadlocking
# all of the duplex endpoint's handlers behind callbacks to the same peer.
COMMAND_MAX_CONCURRENT = 4
COMMAND_MAX_FRAME_BYTES = 2 * 1024 * 1024
COMMAND_TIMEOUT_SECONDS = 120.0
_CALLBACK_KEY = "__meshia_callback__"
_MODE_ENV = "MESHIA_SYNC_ENGINE_PROCESS"


def _bounded_command_payload(value: Any) -> None:
    """Reject oversized or non-wire command values before touching the link."""

    try:
        encoded = json.dumps(value, separators=(",", ":"), ensure_ascii=True)
    except (TypeError, ValueError) as error:
        raise OSError(errno.EINVAL, "The filesystem command payload is invalid.") from error
    if len(encoded) > COMMAND_MAX_FRAME_BYTES:
        raise OSError(errno.EOVERFLOW, "The filesystem command exceeds its IPC bound.")


def _jsonable(value: Any) -> Any:
    """Reduce a handler result to what a control frame can carry.

    Coordinator staging returns ``PendingOperation`` records the mount never
    reads; sending ``None`` for them is exact, and turning any other opaque
    object into ``None`` beats a caller waiting out its timeout on an
    unserializable reply.
    """

    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    return None


def _fingerprint_payload(value: Any) -> dict[str, int]:
    """Encode one local file identity without weakening its concrete type."""

    from .workspace import FileFingerprint

    if not isinstance(value, FileFingerprint):
        raise OSError(errno.EINVAL, "The local file fingerprint is invalid.")
    return {
        "size_bytes": value.size_bytes,
        "mtime_ns": value.mtime_ns,
        "ctime_ns": value.ctime_ns,
        "device_id": value.device_id,
        "file_id": value.file_id,
    }


def _fingerprint_from_payload(value: Any) -> Any:
    """Decode the exact JSON wire shape back into coordinator authority."""

    from .workspace import FileFingerprint

    names = ("size_bytes", "mtime_ns", "ctime_ns", "device_id", "file_id")
    if not isinstance(value, dict) or set(value) != set(names):
        raise OSError(errno.EINVAL, "The local file fingerprint is invalid.")
    fields = []
    for name in names:
        field = value[name]
        if isinstance(field, bool) or not isinstance(field, int):
            raise OSError(errno.EINVAL, "The local file fingerprint is invalid.")
        if name in ("size_bytes", "device_id", "file_id") and field < 0:
            raise OSError(errno.EINVAL, "The local file fingerprint is invalid.")
        if name in ("mtime_ns", "ctime_ns") and not -(2**63) <= field < 2**63:
            raise OSError(errno.EINVAL, "The local file fingerprint is invalid.")
        fields.append(field)
    return FileFingerprint(*fields)


def _remote_message(error: IpcRemoteError) -> str:
    """The peer's original message without the transport's class prefix."""

    text = str(error)
    prefix = f"{error.error_type}: "
    return text[len(prefix):] if error.error_type and text.startswith(prefix) else text


def _exception_from_remote(error: IpcRemoteError) -> Exception:
    """Rebuild the class of failure the peer's handler raised."""

    if error.error_type == "StagingRepairPending":
        from .fabric_sync import StagingRepairPending

        return StagingRepairPending(str(error))
    # The mount backend chooses its Finder verdict by the engine's exception
    # CLASS (an InvalidTask "source is missing" is a local-only directory
    # rename; a StateError is EBUSY). Rebuilt as a flat EIO those branches
    # never ran in the real split topology (empty-dir rename, 2026-09-03).
    if error.error_type in ("InvalidTask", "StateError", "UnsafePath"):
        from . import errors as node_errors

        rebuilt_class = getattr(node_errors, error.error_type, None)
        if rebuilt_class is not None:
            return rebuilt_class(_remote_message(error))
    if error.errno is not None:
        return OSError(error.errno, str(error))
    return OSError(errno.EIO, f"The Meshia sync engine failed: {error}")


class LocalCacheReader:
    """Serves a cache-hit range in the mount process, without touching IPC.

    This exists so the split does not regress reads. It deliberately replicates
    only the *fast path* of ``FabricSyncCoordinator.stream``: one
    side-effect-free ``cache.get`` bracketed by the same identity check the
    coordinator performs, which is itself a pure database re-read. Everything
    else -- object reads, block reads, network fetch, packing -- stays in the
    engine, so the complex logic is never forked and cannot drift.

    Any doubt returns ``None`` and defers to the engine. The worst case is one
    extra IPC hop; it can never be wrong bytes.
    """

    def __init__(self, database: Any, cache: Any) -> None:
        self._database = database
        self._cache = cache

    @staticmethod
    def _identity(head: Any, entry: Any) -> tuple[Any, ...]:
        # ``digest`` is absent on a v2 sequence-only head; compare what exists.
        return (
            getattr(head, "generation", None),
            getattr(head, "digest", None),
            getattr(entry, "digest", None),
            getattr(entry, "size_bytes", None),
            getattr(entry, "blocks", None),
        )

    def read(self, path: str, offset: int, length: int, *, expected_digest=None, expected_size=None) -> bytes | None:
        """Bytes on a verified cache hit, ``None`` to defer to the engine."""

        if length <= 0:
            return None
        try:
            entry = self._database.get_remote_entry(path)
            head = self._database.get_remote_manifest_head()
            if entry is None or head is None:
                return None
            if expected_digest is not None and (entry.digest != expected_digest or entry.size_bytes != expected_size):
                return None
            if offset + length > getattr(entry, "size_bytes", 0):
                return None
            before = self._identity(head, entry)
            descriptor = getattr(entry, "blocks", None)
            if (descriptor or {}).get("file_digest_algorithm") == "sha256_tree_v1":
                from .fabric_tree_read import FabricTreeReader

                def cache_miss(*_args):
                    raise LookupError("The immutable tree range is not cached")

                reader = FabricTreeReader(descriptor, entry.digest, entry.size_bytes,
                    cache=self._cache, generation=head.generation, fetch=cache_miss)
                cached = b"".join(reader.stream(offset, length))
            elif getattr(head, "digest", None) is None or descriptor is not None:
                # Keep v2 warm reads IPC-free only when the authoritative map
                # is complete and every covering block is cached under its
                # current block SHA-256. Missing descriptors and any doubt
                # defer to the engine's fetch/validation path.
                from .fabric_cache import MAX_COVERING_RANGES
                from .fabric_sync import _cas_read_blocks

                blocks = _cas_read_blocks(entry)
                if blocks is None:
                    return None
                end = offset + length
                covering = []
                for block in blocks:
                    if block.offset_bytes >= end:
                        break
                    if block.offset_bytes + block.size_bytes <= offset:
                        continue
                    covering.append(block)
                    if len(covering) > MAX_COVERING_RANGES:
                        return None
                if not covering:
                    return None
                assembled = bytearray()
                cursor = offset
                for block in covering:
                    hit = self._cache.get(
                        entry.digest,
                        entry.size_bytes,
                        block.offset_bytes,
                        block.size_bytes,
                        manifest_generation=head.generation,
                        manifest_digest=getattr(head, "digest", None),
                        expected_range_sha256=block.sha256,
                    )
                    start = max(cursor, block.offset_bytes) - block.offset_bytes
                    stop = min(end, block.offset_bytes + block.size_bytes) - block.offset_bytes
                    if stop <= start:
                        return None
                    if hit is None:
                        # Demand reads cache verified extents smaller than a
                        # CAS block. The range map binds their own hashes to
                        # this file identity; keep those warm reads IPC-free.
                        hit = self._cache.get(
                            entry.digest, entry.size_bytes,
                            block.offset_bytes + start, stop - start,
                            manifest_generation=head.generation,
                            manifest_digest=getattr(head, "digest", None),
                        )
                        if hit is None:
                            return None
                        assembled.extend(hit)
                    else:
                        assembled.extend(hit[start:stop])
                    cursor = block.offset_bytes + stop
                cached = bytes(assembled) if cursor == end else None
            else:
                cached = self._cache.get(
                    entry.digest,
                    entry.size_bytes,
                    offset,
                    length,
                    manifest_generation=head.generation,
                    manifest_digest=getattr(head, "digest", None),
                )
            if cached is None or len(cached) != length:
                return None
            # Same guarantee as the coordinator's _assert_stream_identity: the
            # manifest must not have moved under the read. On any change, defer
            # rather than raise -- the engine owns ESTALE semantics.
            current_entry = self._database.get_remote_entry(path)
            current_head = self._database.get_remote_manifest_head()
            if current_entry is None or current_head is None:
                return None
            if self._identity(current_head, current_entry) != before:
                return None
            return cached
        except Exception:  # noqa: BLE001 - a fast path may never fail a read
            return None


class _FenceHold(threading.Thread):
    """Keeps one cleanup-fence context entered until released or expired."""

    def __init__(self, provider: Callable[[str], Any], path: str) -> None:
        super().__init__(name="meshia-fence-hold", daemon=True)
        self._provider = provider
        self._path = path
        self.entered = threading.Event()
        self.released = threading.Event()
        self.handles_closed = False
        self.error: BaseException | None = None

    def run(self) -> None:
        try:
            with self._provider(self._path) as handles_closed:
                self.handles_closed = bool(handles_closed)
                self.entered.set()
                self.released.wait(FENCE_HOLD_MAX_SECONDS)
        except BaseException as error:  # noqa: BLE001 - unknown evidence, never a crash
            self.error = error
            self.entered.set()


class EngineLink:
    """Mount-side end of the duplex link: one socket, many session proxies.

    Owns what is shared between the proxies -- the callback table the engine
    invokes by token, the per-session cleanup-fence providers, and any handler
    the mount worker installs for engine-pushed projection changes.
    """

    def __init__(self, sock: Any) -> None:
        self._callbacks: dict[str, Callable[[], Any]] = {}
        self._callback_lock = threading.Lock()
        self._fences: dict[str | None, Callable[[str], Any]] = {}
        self._fence_lock = threading.Lock()
        self._holds: dict[str, _FenceHold] = {}
        self._proxies: dict[str | None, CoordinatorProxy] = {}
        self._proxy_lock = threading.Lock()
        self.endpoint = IpcEndpoint(
            sock,
            {
                "fence_enter": self.fence_enter,
                "fence_exit": self.fence_exit,
                "invoke_callback": self.invoke_callback,
            },
            start_reader=False,
            on_close=self._release_all_holds,
        )
        self.endpoint.start()

    @property
    def closed(self) -> bool:
        return self.endpoint.closed

    def close(self) -> None:
        self.endpoint.close()

    def install_handlers(self, handlers: Mapping[str, Callable[..., Any]]) -> None:
        """Expose mount-worker handlers (topology pushes, close probes)."""

        for name, handler in handlers.items():
            self.endpoint.register_handler(name, handler)

    def install_filesystem_command_handler(self, handler: Callable[..., Any]) -> None:
        """Install the one bounded typed-command lane on this existing link."""

        slots = threading.BoundedSemaphore(COMMAND_MAX_CONCURRENT)

        def dispatch(session_id: str, operation: str, arguments: Any) -> dict[str, Any]:
            if self.closed:
                raise OSError(errno.EIO, "The Meshia sync engine is not running.")
            if not isinstance(session_id, str) or not session_id or len(session_id) > 256:
                raise OSError(errno.EINVAL, "A workspace session id is required.")
            if operation not in ("read", "list", "write") or not isinstance(arguments, dict):
                raise OSError(errno.EINVAL, "Unsupported filesystem command.")
            _bounded_command_payload(arguments)
            if not slots.acquire(blocking=False):
                raise OSError(errno.EBUSY, "The Meshia filesystem command lane is busy.")
            try:
                answer = handler(session_id, operation, **arguments)
                if not isinstance(answer, dict):
                    raise OSError(errno.EIO, "The filesystem command returned no receipt.")
                # In particular, an unusually long recursive listing must
                # produce a bounded error, not poison the duplex socket with
                # an oversized response that every pending call then waits on.
                _bounded_command_payload(answer)
                return answer
            finally:
                slots.release()

        self.install_handlers({"command_filesystem": dispatch})

    def proxy(
        self,
        session_id: str | None,
        *,
        local_reader: "LocalCacheReader | None" = None,
    ) -> "CoordinatorProxy":
        with self._proxy_lock:
            proxy = self._proxies.get(session_id)
            if proxy is None:
                proxy = CoordinatorProxy(
                    self.endpoint, local_reader, session_id=session_id, link=self
                )
                self._proxies[session_id] = proxy
            elif local_reader is not None:
                proxy._local_reader = local_reader  # noqa: SLF001 - owner
            return proxy

    # -- callbacks -------------------------------------------------------

    def register_callback(self, function: Callable[[], Any]) -> str:
        token = uuid.uuid4().hex
        with self._callback_lock:
            self._callbacks[token] = function
        return token

    def release_callback(self, token: str) -> None:
        with self._callback_lock:
            self._callbacks.pop(token, None)

    def invoke_callback(self, token: str) -> Any:
        with self._callback_lock:
            function = self._callbacks.get(str(token))
        if function is None:
            raise OSError(errno.ESTALE, "The mount callback is no longer registered.")
        return _jsonable(function())

    # -- cleanup fence (engine -> mount) ----------------------------------

    def set_cleanup_fence(
        self, session_id: str | None, provider: Callable[[str], Any] | None
    ) -> None:
        with self._fence_lock:
            if provider is None:
                self._fences.pop(session_id, None)
            else:
                self._fences[session_id] = provider

    def fence_enter(self, path: str, session_id: str | None = None) -> dict[str, Any]:
        """Enter the mount's cleanup fence for ``path`` and hold it.

        The provider is a context manager (``FabricMountBackend`` excludes
        open/create for the path while it proves no handle references it).
        A holder thread enters it, reports the evidence, and keeps it entered
        until ``fence_exit`` or the hold bound -- whichever comes first. Any
        doubt reports ``False`` (not closed), which the engine reads as "do
        not reclaim", exactly as an absent provider does in-process.
        """

        with self._fence_lock:
            provider = self._fences.get(session_id)
        if provider is None:
            return {"handles_closed": False}
        hold = _FenceHold(provider, path)
        hold.start()
        if not hold.entered.wait(FENCE_TIMEOUT_SECONDS) or hold.error is not None:
            hold.released.set()
            return {"handles_closed": False}
        token = uuid.uuid4().hex
        with self._fence_lock:
            self._holds[token] = hold
        return {"token": token, "handles_closed": bool(hold.handles_closed)}

    def fence_exit(self, token: str) -> bool:
        with self._fence_lock:
            hold = self._holds.pop(str(token), None)
        if hold is None:
            return False
        hold.released.set()
        return True

    def _release_all_holds(self) -> None:
        with self._fence_lock:
            holds = list(self._holds.values())
            self._holds.clear()
        for hold in holds:
            hold.released.set()


class CoordinatorProxy:
    """The coordinator surface the mount uses, forwarded to another process.

    Implements exactly the members ``fabric_mount`` touches. Anything absent
    here is, by construction, something the mount never calls -- keeping the
    boundary auditable rather than inheriting a whole object's API.
    """

    def __init__(
        self,
        endpoint: IpcEndpoint,
        local_reader: "LocalCacheReader | None" = None,
        *,
        session_id: str | None = None,
        link: EngineLink | None = None,
    ) -> None:
        self._endpoint = endpoint
        self._local_reader = local_reader
        self._session_id = session_id
        self._link = link
        self._fence: Callable[[str], Any] | None = None
        self._fence_lock = threading.Lock()
        self.local_hits = 0
        self.ipc_reads = 0

    @property
    def session_id(self) -> str | None:
        return self._session_id

    # -- engine -> mount ------------------------------------------------

    def set_mount_cleanup_fence(self, provider: Callable[[str], Any] | None) -> None:
        """Register locally; the engine queries it back over the link.

        The provider closes over the mount's open-description table, which
        cannot leave this process, so registration stays here and the engine
        asks by path when it needs an answer.
        """

        with self._fence_lock:
            self._fence = provider
        if self._link is not None:
            self._link.set_cleanup_fence(self._session_id, provider)

    def answer_cleanup_fence(self, path: str) -> Any:
        """Serve the engine's fence query. Unknown on any doubt."""

        with self._fence_lock:
            provider = self._fence
        if provider is None:
            return None
        try:
            return provider(path)
        except Exception:  # noqa: BLE001 - unknown evidence, never a crash
            return None

    # -- mount -> engine (best effort) -----------------------------------

    def _notify(self, method: str, **kwargs: Any) -> None:
        self._endpoint.notify(method, session_id=self._session_id, **kwargs)

    def wake(self) -> None:
        self._notify("wake")

    def wake_mount_cleanup(self) -> None:
        self._notify("wake_mount_cleanup")

    def note_materialized_access(self, path: str) -> None:
        """Fire-and-forget last-access hint. Never blocks a mount open."""

        self._notify("note_materialized_access", path=path)

    def warm_object_read(self, path: str) -> bool:
        try:
            return bool(
                self._endpoint.call(
                    "warm_object_read",
                    session_id=self._session_id,
                    path=path,
                    timeout=5.0,
                )
            )
        except IpcError:
            return False

    def clear_directory_delete_acknowledgement(self, path: str) -> None:
        self._notify("clear_directory_delete_acknowledgement", path=path)

    def acknowledge_local_metadata_change(
        self,
        path: str,
        *,
        previous_fingerprint: Any,
        current_fingerprint: Any,
        allow_mtime_change: bool = False,
    ) -> bool:
        return bool(
            self._stage(
                "acknowledge_local_metadata_change",
                args=[path],
                kwargs={
                    "previous_fingerprint": _fingerprint_payload(
                        previous_fingerprint
                    ),
                    "current_fingerprint": _fingerprint_payload(current_fingerprint),
                    "allow_mtime_change": bool(allow_mtime_change),
                },
            )
        )

    # -- mount -> engine (must not be lost) -------------------------------

    def _encode_kwargs(self, kwargs: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
        encoded: dict[str, Any] = {}
        tokens: list[str] = []
        for key, value in kwargs.items():
            if callable(value):
                if self._link is None:
                    raise OSError(
                        errno.EIO,
                        "The Meshia sync engine link cannot carry a callback.",
                    )
                token = self._link.register_callback(value)
                tokens.append(token)
                encoded[key] = {_CALLBACK_KEY: token}
            else:
                encoded[key] = value
        return encoded, tokens

    def _stage(self, method: str, **kwargs: Any) -> Any:
        tokens: list[str] = []
        try:
            if isinstance(kwargs.get("kwargs"), dict):
                kwargs["kwargs"], tokens = self._encode_kwargs(dict(kwargs["kwargs"]))
            try:
                return self._endpoint.call(
                    method,
                    timeout=STAGE_TIMEOUT_SECONDS,
                    session_id=self._session_id,
                    **kwargs,
                )
            except IpcRemoteError as error:
                raise _exception_from_remote(error) from error
            except IpcUnavailable as error:
                if method in {"file_version_open", "file_version_close"} or method.startswith("native_"):
                    self._endpoint.close()
                raise OSError(
                    errno.EIO, "The Meshia sync engine is not running."
                ) from error
            except IpcError as error:
                if method in {"file_version_open", "file_version_close"} or method.startswith("native_"):
                    # An OPEN may have landed without a reply. Disconnect
                    # releases its connection-owned pin, including a handler
                    # still finishing acquisition; never submit a second OPEN.
                    self._endpoint.close()
                raise OSError(
                    errno.EIO, f"The Meshia sync engine failed: {error}"
                ) from error
        finally:
            if self._link is not None:
                for token in tokens:
                    self._link.release_callback(token)

    def stage_file_provider_write(self, *args: Any, **kwargs: Any) -> Any:
        return self._stage("stage_file_provider_write", args=list(args), kwargs=kwargs)

    def stage_file_provider_delete(self, *args: Any, **kwargs: Any) -> Any:
        return self._stage("stage_file_provider_delete", args=list(args), kwargs=kwargs)

    def stage_local_rename(self, *args: Any, **kwargs: Any) -> Any:
        return self._stage("stage_local_rename", args=list(args), kwargs=kwargs)

    def stage_local_directory(self, *args: Any, **kwargs: Any) -> Any:
        return self._stage("stage_local_directory", args=list(args), kwargs=kwargs)

    def stage_local_directory_rename(self, *args: Any, **kwargs: Any) -> Any:
        return self._stage("stage_local_directory_rename", args=list(args), kwargs=kwargs)

    def stage_metadata_rename(self, *args: Any, **kwargs: Any) -> Any:
        return self._stage("stage_metadata_rename", args=list(args), kwargs=kwargs)

    def stage_metadata_directory_rename(self, *args: Any, **kwargs: Any) -> Any:
        return self._stage(
            "stage_metadata_directory_rename", args=list(args), kwargs=kwargs
        )

    # -- content ----------------------------------------------------------

    def open_file_version(self, path, *, expected_digest, expected_size):
        started = time.monotonic()
        answer = self._stage("file_version_open", path=path,
            expected_digest=expected_digest, expected_size=expected_size)
        return RemoteFileVersion(self, answer, started) if answer is not None else None

    def open_native_file_version(self, path, token, snapshot, *, expected_digest, expected_size):
        started = time.monotonic()
        answer = self._stage("file_version_open", path=path, native=[token, snapshot],
            expected_digest=expected_digest, expected_size=expected_size)
        return RemoteFileVersion(self, answer, started) if answer is not None else None

    def release_file_version(self, version):
        version.pool.release(version)

    def open_native_journal(self, path, *, expected_digest, expected_size, discard_source=False):
        answer = self._stage("native_open", path=path, expected_digest=expected_digest,
            expected_size=expected_size, discard_source=discard_source)
        return RemoteNativeJournal(self, **answer) if answer is not None else None

    def recover_native_journal(self, document):
        answer = self._stage("native_recover", document=document)
        journal = RemoteNativeJournal(self, answer["token"])
        # Recovery has already verified this frozen snapshot in the engine.
        from .fabric_contract_generated import FileTree
        descriptor = document["tree_descriptor"]
        digest = FileTree.from_descriptor(descriptor, load_node=None, read_object=None, put_object=None).digest
        journal.journal._views[document["tree_owner"]] = descriptor, digest
        return journal, answer["owned"]

    def native_tree_handoff_owned(self, document):
        return bool(self._stage("native_owned", document=document))

    def pending_native_file(self, operation):
        # A pending namespace lookup remains mount-local. The engine owns the
        # durable plan; this shared, validated immutable projection never opens
        # a journal writer, admission ledger, or remote connection in the worker.
        from pathlib import Path
        from .fabric_sync import _load_plan, _plan_is_tree
        if operation.kind != "put" or operation.staged_path is None:
            return None
        plan = _load_plan(Path(operation.staged_path), operation)
        return plan if _plan_is_tree(plan) else None

    def stage_tree_snapshot(self, path, *, journal, snapshot, tree_mutation,
                            expected_source_digest, mutation_id, delete_after_ack=None, modified_at=None):
        del tree_mutation  # The single engine writer owns shared admission.
        return self._stage("native_stage", token=journal.identity, path=path, snapshot=snapshot,
            expected_source_digest=expected_source_digest, mutation_id=mutation_id,
            delete_after_ack=delete_after_ack, modified_at=modified_at)

    def stream(
        self, path: str, *, offset: int = 0, length: int | None = None
    ) -> Iterator[bytes]:
        """Stream file content in bounded frames.

        A cache hit is served locally by ``LocalCacheReader`` -- the CAS cache
        is content-addressed and safe for two readers, and only its in-flight
        de-duplication map is process-local. Only a miss crosses the boundary,
        and a miss reaches the network anyway, where an IPC hop is noise.
        """

        if self._local_reader is not None and length is not None and length > 0:
            served = self._local_reader.read(path, offset, length)
            if served is not None:
                self.local_hits += 1
                yield served
                return
        self.ipc_reads += 1
        cursor = offset
        remaining = length
        while True:
            want = STREAM_CHUNK_BYTES if remaining is None else min(STREAM_CHUNK_BYTES, remaining)
            if remaining is not None and want <= 0:
                return
            encoded = self._stage(
                "stream_chunk", path=path, offset=cursor, length=want
            )
            if not encoded:
                return
            chunk = base64.b64decode(encoded)
            if not chunk:
                return
            yield chunk
            cursor += len(chunk)
            if remaining is not None:
                remaining -= len(chunk)
                if remaining <= 0:
                    return
            if len(chunk) < want:
                return


def _materialize_arguments(
    endpoint: IpcEndpoint, kwargs: Mapping[str, Any] | None
) -> dict[str, Any]:
    """Turn callback tokens back into callables that reach the mount."""

    materialized: dict[str, Any] = {}
    for key, value in (kwargs or {}).items():
        if isinstance(value, dict) and set(value) == {_CALLBACK_KEY}:
            token = str(value[_CALLBACK_KEY])

            def callback(_token: str = token) -> Any:
                try:
                    return endpoint.call(
                        "invoke_callback",
                        token=_token,
                        timeout=CALLBACK_TIMEOUT_SECONDS,
                    )
                except IpcRemoteError as error:
                    raise _exception_from_remote(error) from error
                except IpcError as error:
                    raise OSError(
                        errno.EIO, f"The Meshia mount did not answer: {error}"
                    ) from error

            materialized[key] = callback
        elif key == "delete_after_ack" and isinstance(value, list):
            materialized[key] = tuple(value)
        else:
            materialized[key] = value
    return materialized


def _materialize_stage_arguments(
    endpoint: IpcEndpoint,
    name: str,
    kwargs: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Decode shared stage-call wire types for either engine-server shape."""

    materialized = _materialize_arguments(endpoint, kwargs)
    if name != "acknowledge_local_metadata_change":
        return materialized
    materialized["previous_fingerprint"] = _fingerprint_from_payload(
        materialized.get("previous_fingerprint")
    )
    materialized["current_fingerprint"] = _fingerprint_from_payload(
        materialized.get("current_fingerprint")
    )
    if not isinstance(materialized.get("allow_mtime_change"), bool):
        raise OSError(errno.EINVAL, "The metadata acknowledgement is invalid.")
    return materialized


class SyncEngineServer:
    """Engine-side listener exposing the coordinator to a mount process."""

    def __init__(
        self,
        coordinator: Any,
        home: os.PathLike[str] | str,
        *,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        self._coordinator = coordinator
        self._logger = logger
        self._path = socket_path(home)
        self._server = listen(self._path)
        self._endpoint: IpcEndpoint | None = None
        self._endpoint_lock = threading.Lock()
        self._command_slots = threading.BoundedSemaphore(COMMAND_MAX_CONCURRENT)
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._accept_loop, name="meshia-ipc-accept", daemon=True
        )
        self._thread.start()

    @property
    def socket_path(self) -> str:
        return self._path

    @property
    def closed(self) -> bool:
        return self._stop.is_set()

    def _current_endpoint(self) -> IpcEndpoint | None:
        with self._endpoint_lock:
            endpoint = self._endpoint
        if endpoint is None or endpoint.closed:
            return None
        return endpoint

    @property
    def mount_connected(self) -> bool:
        return self._current_endpoint() is not None

    def command_filesystem(
        self, session_id: str, operation: str, **kwargs: Any
    ) -> dict[str, Any]:
        """Run a bounded typed operation on the worker-owned original backend.

        The caller holds the existing workspace runtime lease and admission;
        this method deliberately holds no runtime/topology mutex across IPC.
        A cold read or journaled write calls back into this engine over the
        same duplex link. A timeout is an unknown write outcome, never license
        to retry it, and a dead worker must not fall back to private disk IO.
        """

        if not isinstance(session_id, str) or not session_id or len(session_id) > 256:
            raise OSError(errno.EINVAL, "A workspace session id is required.")
        if operation not in ("read", "list", "write"):
            raise OSError(errno.EINVAL, "Unsupported filesystem command.")
        _bounded_command_payload({"session_id": session_id, "operation": operation, **kwargs})
        endpoint = self._current_endpoint()
        if endpoint is None:
            raise OSError(errno.EIO, "The Meshia mount worker is not running.")
        if not self._command_slots.acquire(blocking=False):
            raise OSError(errno.EBUSY, "The Meshia filesystem command lane is busy.")
        try:
            try:
                answer = endpoint.call(
                    "command_filesystem",
                    session_id=session_id,
                    operation=operation,
                    arguments=kwargs,
                    timeout=COMMAND_TIMEOUT_SECONDS,
                )
            except IpcRemoteError as error:
                raise _exception_from_remote(error) from error
            except IpcError as error:
                raise OSError(
                    errno.EIO,
                    "The filesystem command did not return a receipt; "
                    "read back state before retrying a write.",
                ) from error
            if not isinstance(answer, dict):
                raise OSError(errno.EIO, "The mount worker returned no filesystem receipt.")
            _bounded_command_payload(answer)
            return answer
        finally:
            self._command_slots.release()

    @contextmanager
    def cleanup_fence(
        self, path: str, *, session_id: str | None = None
    ) -> Iterator[bool]:
        """Hold the mount's cleanup fence for ``path`` while the body runs.

        Yields whether no mount handle references the path. ``False`` --
        not proven closed, therefore do not reclaim -- whenever the mount is
        absent, slow or failing, which is exactly what the coordinator's
        contract gives a missing in-process provider.
        """

        endpoint = self._current_endpoint()
        if endpoint is None:
            yield False
            return
        try:
            answer = endpoint.call(
                "fence_enter",
                path=path,
                session_id=session_id,
                timeout=FENCE_TIMEOUT_SECONDS,
            )
        except IpcError:
            yield False
            return
        token = answer.get("token") if isinstance(answer, dict) else None
        closed = answer.get("handles_closed") if isinstance(answer, dict) else None
        try:
            yield closed if isinstance(closed, bool) else False
        finally:
            if isinstance(token, str) and token:
                endpoint.notify("fence_exit", token=token)

    def cleanup_fence_for(self, session_id: str) -> Callable[[str], Any]:
        return lambda path: self.cleanup_fence(path, session_id=session_id)

    def close(self) -> None:
        self._stop.set()
        with self._endpoint_lock:
            endpoint = self._endpoint
            self._endpoint = None
        if endpoint is not None:
            endpoint.close()
        try:
            self._server.close()
        except OSError:
            pass
        try:
            os.unlink(self._path)
        except OSError:
            pass

    @contextmanager
    def _lease_file_runtime(self, session_id):
        del session_id
        yield self._coordinator

    def _file_handlers(self, endpoint_holder):
        descriptions = EngineFileDescriptions(self._lease_file_runtime)
        endpoint_holder["files"] = descriptions
        return descriptions.handlers()

    def _handlers(self, endpoint_holder: dict[str, IpcEndpoint]) -> dict[str, Callable[..., Any]]:
        coordinator = self._coordinator

        def _call(
            name: str,
            args: list[Any] | None = None,
            kwargs: dict[str, Any] | None = None,
            session_id: str | None = None,
        ) -> Any:
            del session_id
            method = getattr(coordinator, name)
            return _jsonable(
                method(
                    *(args or []),
                    **_materialize_stage_arguments(
                        endpoint_holder["endpoint"], name, kwargs
                    ),
                )
            )

        def stream_chunk(
            path: str, offset: int, length: int, session_id: str | None = None
        ) -> str:
            del session_id
            collected = bytearray()
            for chunk in coordinator.stream(path, offset=offset, length=length):
                collected.extend(chunk)
                if len(collected) >= length:
                    break
            return base64.b64encode(bytes(collected[:length])).decode("ascii")

        def _signal(name: str) -> Callable[..., Any]:
            def handler(session_id: str | None = None, **kwargs: Any) -> Any:
                del session_id
                target = getattr(coordinator, name, None)
                if not callable(target):
                    return None
                return _jsonable(target(**kwargs))

            return handler

        handlers: dict[str, Callable[..., Any]] = {
            "wake": _signal("wake"),
            "wake_mount_cleanup": _signal("wake_mount_cleanup"),
            "note_materialized_access": _signal("note_materialized_access"),
            "clear_directory_delete_acknowledgement": _signal(
                "clear_directory_delete_acknowledgement"
            ),
            "warm_object_read": lambda path, session_id=None: bool(
                coordinator.warm_object_read(path)
            ),
            "stream_chunk": stream_chunk,
        }
        for name in (
            "stage_file_provider_write",
            "stage_file_provider_delete",
            "stage_local_rename",
            "stage_local_directory",
            "stage_local_directory_rename",
            "stage_metadata_rename",
            "stage_metadata_directory_rename",
            "acknowledge_local_metadata_change",
        ):
            handlers[name] = (
                lambda args=None, kwargs=None, session_id=None, _name=name: _call(
                    _name, args, kwargs, session_id
                )
            )
        handlers.update(self._file_handlers(endpoint_holder))
        return handlers

    def _on_mount_connected(self, endpoint: IpcEndpoint) -> None:
        """Hook for subclasses; the base server has nothing to replay."""

    def _accept_loop(self) -> None:
        while not self._stop.is_set():
            try:
                conn, _ = self._server.accept()
            except OSError:
                return
            # Publish the accepted endpoint before its reader can dispatch a
            # blocking coordinator call. Otherwise close() can race between
            # accept and publication and leave that in-flight request able to
            # report success after the engine has already closed.
            holder: dict[str, IpcEndpoint] = {}
            endpoint = IpcEndpoint(conn, self._handlers(holder), start_reader=False,
                on_close=lambda _holder=holder: _holder["files"].close())
            holder["endpoint"] = endpoint
            with self._endpoint_lock:
                if self._stop.is_set():
                    endpoint.close()
                    return
                previous = self._endpoint
                self._endpoint = endpoint
            if previous is not None:
                previous.close()
            endpoint.start()
            self._on_mount_connected(endpoint)


class EngineWorkspaceHandle:
    """Engine-side stand-in for ``FabricMountBackend`` in split mode.

    The manager expects every runtime to carry a backend it can label, hand a
    stage-capacity fence and a remote quota, and ask for close safety. In
    split mode the real backend -- write sessions, handles, stage recovery --
    lives in the mount worker; this handle records what the worker needs to
    build it (``describe``) and forwards close safety over the link.
    """

    def __init__(
        self,
        *,
        workspace_name: str,
        database_path: os.PathLike[str] | str,
        cache_path: os.PathLike[str] | str,
        workspace_root: os.PathLike[str] | str,
        can_close: Callable[[], bool],
    ) -> None:
        self.workspace_name = workspace_name
        self.database_path = str(database_path)
        self.cache_path = str(cache_path)
        self.workspace_root = str(workspace_root)
        self._can_close = can_close
        self._lock = threading.Lock()
        self.stage_capacity: Any | None = None
        self.remote_quota: Any | None = None

    def set_workspace_name(self, workspace_name: str) -> None:
        with self._lock:
            self.workspace_name = workspace_name

    def set_stage_capacity(self, capacity: Any) -> None:
        with self._lock:
            self.stage_capacity = capacity

    def set_remote_quota(self, capacity: Any) -> None:
        with self._lock:
            self.remote_quota = capacity

    def can_close(self) -> bool:
        return bool(self._can_close())

    def close(self) -> None:
        return None

    def describe(self) -> dict[str, str]:
        with self._lock:
            return {
                "workspace_name": self.workspace_name,
                "database_path": self.database_path,
                "cache_path": self.cache_path,
                "workspace_root": self.workspace_root,
            }


class MultiWorkspaceEngineServer(SyncEngineServer):
    """Session-scoped engine server for the account-wide ``Meshia`` mount.

    Every mount request names a ``session_id``; this server resolves it through
    ``WorkspaceRuntimeManager.run_pinned`` so activation, visibility and
    mutation fences are the manager's, not a copy. The engine also *pushes*
    the catalog projection here (``publish_topology`` and friends) and replays
    it whenever a mount worker (re)connects, so a restarted worker never
    serves a stale namespace.
    """

    def __init__(
        self,
        home: os.PathLike[str] | str,
        *,
        manager: Any = None,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        self._manager = manager
        self._topology_lock = threading.Lock()
        self._topology: list[dict[str, Any]] = []
        self._running_labels: tuple[str, ...] = ()
        self._modified: dict[str, int] = {}
        self._topology_closed = False
        super().__init__(None, home, logger=logger)

    def bind_manager(self, manager: Any) -> None:
        self._manager = manager

    # -- manager access -----------------------------------------------------

    def _require_manager(self) -> Any:
        manager = self._manager
        if manager is None:
            raise OSError(errno.EIO, "The workspace runtime manager is not ready.")
        return manager

    def _run(
        self,
        session_id: str | None,
        operation: Callable[[Any], Any],
        *,
        require_mutation_ready: bool = False,
        activate: bool = True,
    ) -> Any:
        if not isinstance(session_id, str) or not session_id:
            raise OSError(errno.EINVAL, "A workspace session id is required.")
        return self._require_manager().run_pinned(
            session_id,
            operation,
            require_visible=True,
            require_mutation_ready=require_mutation_ready,
            activate=activate,
        )

    # -- handlers (mount -> engine) ------------------------------------------

    @contextmanager
    def _lease_file_runtime(self, session_id):
        if not isinstance(session_id, str) or not session_id:
            raise OSError(errno.EINVAL, "A workspace session id is required.")
        with self._require_manager().lease_runtime(session_id, require_visible=True) as runtime:
            yield runtime.coordinator

    def _handlers(self, endpoint_holder: dict[str, IpcEndpoint]) -> dict[str, Callable[..., Any]]:
        def describe(runtime: Any) -> dict[str, str]:
            describe_backend = getattr(runtime.backend, "describe", None)
            if not callable(describe_backend):
                raise StateError(
                    "The workspace runtime was built for an in-process mount."
                )
            return dict(describe_backend())

        def activate_workspace(session_id: str) -> dict[str, str]:
            return self._run(session_id, describe)

        def await_mutation_ready(session_id: str) -> bool:
            self._run(session_id, lambda _runtime: None, require_mutation_ready=True)
            return True

        def rename_workspace_root(
            session_id: str, source: str, destination: str
        ) -> str:
            manager = self._require_manager()
            return str(manager.rename_workspace_root(session_id, source, destination))

        def stage(
            name: str,
            session_id: str,
            args: list[Any] | None,
            kwargs: dict[str, Any] | None,
            *,
            require_mutation_ready: bool,
        ) -> Any:
            materialized = _materialize_stage_arguments(
                endpoint_holder["endpoint"], name, kwargs
            )

            def operation(runtime: Any) -> Any:
                method = getattr(runtime.coordinator, name)
                return _jsonable(method(*(args or []), **materialized))

            return self._run(
                session_id, operation, require_mutation_ready=require_mutation_ready
            )

        def stream_chunk(session_id: str, path: str, offset: int, length: int) -> str:
            def operation(runtime: Any) -> str:
                collected = bytearray()
                for chunk in runtime.coordinator.stream(path, offset=offset, length=length):
                    collected.extend(chunk)
                    if len(collected) >= length:
                        break
                return base64.b64encode(bytes(collected[:length])).decode("ascii")

            return self._run(session_id, operation)

        def signal(name: str) -> Callable[..., Any]:
            # Best effort and never an activation: a wake for a workspace the
            # engine already evicted is meaningless.
            def handler(session_id: str | None = None, **kwargs: Any) -> Any:
                def operation(runtime: Any) -> Any:
                    target = getattr(runtime.coordinator, name, None)
                    if not callable(target):
                        return None
                    return _jsonable(target(**kwargs))

                try:
                    return self._run(session_id, operation, activate=False)
                except OSError:
                    return None

            return handler

        def warm_object_read(session_id: str, path: str) -> bool:
            return bool(
                self._run(
                    session_id, lambda runtime: runtime.coordinator.warm_object_read(path)
                )
            )

        handlers: dict[str, Callable[..., Any]] = {
            "topology": self._topology_payload,
            "activate_workspace": activate_workspace,
            "await_mutation_ready": await_mutation_ready,
            "rename_workspace_root": rename_workspace_root,
            "wake": signal("wake"),
            "wake_mount_cleanup": signal("wake_mount_cleanup"),
            "note_materialized_access": signal("note_materialized_access"),
            "clear_directory_delete_acknowledgement": signal(
                "clear_directory_delete_acknowledgement"
            ),
            "warm_object_read": warm_object_read,
            "stream_chunk": stream_chunk,
        }
        # A queued write was admitted at open time; publishing it later must
        # not be refused by a fence that did not exist then (in-process, the
        # publish timer calls the coordinator with no manager fence either).
        # A local rename is also admitted on the mount side, but by the time
        # ``stage_local_rename`` crosses this boundary FabricMountBackend has
        # already atomically moved the exact inode. Re-fencing that journal
        # handoff can return EAGAIN after the visible replacement succeeded,
        # leaving NSDocument with correct new bytes plus a false permission
        # failure. The coordinator lock safely orders the already-admitted
        # event with any recovery that began meanwhile, matching the
        # in-process path. Metadata renames have no mount-side namespace
        # mutation and therefore keep their engine-side admission fence.
        for name, fenced in (
            ("stage_file_provider_write", False),
            ("stage_file_provider_delete", True),
            ("stage_local_rename", False),
            ("stage_local_directory", True),
            ("stage_local_directory_rename", True),
            ("stage_metadata_rename", True),
            ("stage_metadata_directory_rename", True),
            ("acknowledge_local_metadata_change", False),
        ):
            handlers[name] = (
                lambda session_id=None, args=None, kwargs=None, _name=name, _fenced=fenced: stage(
                    _name, session_id, args, kwargs, require_mutation_ready=_fenced
                )
            )
        handlers.update(self._file_handlers(endpoint_holder))
        return handlers

    # -- projection (engine -> mount) ----------------------------------------

    def _topology_payload(self) -> dict[str, Any]:
        with self._topology_lock:
            return {
                "workspaces": [dict(item) for item in self._topology],
                "running": list(self._running_labels),
                "modified": dict(self._modified),
            }

    def _push(self, method: str, **kwargs: Any) -> bool:
        endpoint = self._current_endpoint()
        if endpoint is None:
            return False
        try:
            endpoint.call(method, timeout=TOPOLOGY_TIMEOUT_SECONDS, **kwargs)
            return True
        except IpcError as error:
            # The mount re-pulls the whole projection on its next connect, so
            # a missed push is a delay, never a divergence.
            self._logger.record(
                "sync_engine_mount_push_failed",
                method=method,
                error=str(error)[:200],
            )
            return False

    def _on_mount_connected(self, endpoint: IpcEndpoint) -> None:
        self._logger.record("sync_engine_mount_connected")

    def publish_topology(self, workspaces: list[dict[str, Any]]) -> None:
        with self._topology_lock:
            if self._topology_closed or self._stop.is_set():
                raise StateError("The Meshia mount backend is closed.")
            self._topology = [dict(item) for item in workspaces]
            payload = [dict(item) for item in self._topology]
        self._push("replace_workspaces", workspaces=payload)

    def publish_running(self, labels: tuple[str, ...]) -> None:
        with self._topology_lock:
            self._running_labels = tuple(labels)
        self._push("set_compute_running", labels=list(labels))

    def publish_modified(self, modified: Mapping[str, int]) -> None:
        with self._topology_lock:
            self._modified = dict(modified)
        self._push("set_workspace_modified", modified=dict(modified))

    def invalidate_workspace(self, label: str, paths: tuple[str, ...]) -> None:
        endpoint = self._current_endpoint()
        if endpoint is None:
            return
        endpoint.notify("invalidate_workspace", label=label, paths=list(paths))

    def workspace_can_close(self, session_id: str) -> bool:
        """Close safety for one engine runtime, answered by the mount.

        No mount process means no open descriptions and no transient private
        write on our side of the boundary (a crashed worker's stages are
        preserved on disk and recovered by the next one), so absence is safe.
        A connected mount that does not answer is not.
        """

        endpoint = self._current_endpoint()
        if endpoint is None:
            return True
        try:
            return bool(
                endpoint.call(
                    "workspace_can_close",
                    session_id=session_id,
                    timeout=FENCE_TIMEOUT_SECONDS,
                )
            )
        except IpcError:
            return False

    def close_topology(self) -> None:
        with self._topology_lock:
            self._topology_closed = True
            self._topology = []


class EngineMountTopology:
    """Engine-side ``MultiWorkspaceMountBackend`` stand-in.

    ``WorkspaceRuntimeManager`` projects the catalog into its mount backend; in
    split mode that projection is serialized and pushed to the mount worker,
    which builds the real routes. Only what the worker needs crosses: labels,
    session ids, quota figures, the running set and folder dates.
    """

    def __init__(self, server: MultiWorkspaceEngineServer) -> None:
        self._server = server

    def replace_workspaces(self, workspaces: Mapping[str, Any]) -> None:
        entries: list[dict[str, Any]] = []
        for label, proxy in workspaces.items():
            storage = getattr(proxy, "workspace_storage", None)
            entries.append(
                {
                    "label": str(label),
                    "session_id": str(getattr(proxy, "session_id", "")),
                    "catalog_generation": int(getattr(proxy, "catalog_generation", 0)),
                    "quota_bytes": getattr(storage, "quota_bytes", None),
                    "used_bytes": getattr(storage, "used_bytes", None),
                    "reserved_bytes": getattr(storage, "reserved_bytes", None),
                }
            )
        self._server.publish_topology(entries)

    def invalidate_workspace(self, workspace_name: str, changed_paths: Any = ()) -> int:
        paths = tuple(item for item in changed_paths if isinstance(item, str))
        self._server.invalidate_workspace(str(workspace_name), paths)
        return 0

    def set_workspace_modified(self, modified: Mapping[str, int]) -> None:
        self._server.publish_modified(
            {
                str(label): int(stamp)
                for label, stamp in modified.items()
                if isinstance(stamp, int) and not isinstance(stamp, bool) and stamp > 0
            }
        )

    def set_compute_running(self, labels: Any) -> tuple[str, ...]:
        running = tuple(str(label) for label in labels if str(label))
        self._server.publish_running(running)
        return running

    def close(self) -> None:
        self._server.close_topology()


def connect_engine(home: os.PathLike[str] | str, *, timeout: float = 5.0) -> EngineLink:
    """Attach a mount process to a running engine."""

    return EngineLink(connect(socket_path(home), timeout=timeout))


def connect_proxy(home: os.PathLike[str] | str, *, timeout: float = 5.0) -> CoordinatorProxy:
    """Attach a single-workspace mount process to a running engine."""

    return connect_engine(home, timeout=timeout).proxy(None)


def sync_engine_process_mode(environ: Mapping[str, str] | None = None) -> str:
    """``split``, ``inline`` or ``auto`` from the environment."""

    env = os.environ if environ is None else environ
    value = env.get(_MODE_ENV, "auto").strip().lower()
    return value if value in ("split", "inline") else "auto"


def sync_engine_process_enabled(environ: Mapping[str, str] | None = None) -> bool:
    """Selector for the legacy single-workspace mount: split only when asked.

    Mirrors the mount-backend selector so the split can be rolled back by
    environment alone, without a release.
    """

    return sync_engine_process_mode(environ) == "split"


def multi_workspace_split_enabled(
    environ: Mapping[str, str] | None = None, *, platform: str = sys.platform
) -> bool:
    """Selector for the account-wide mount: split by default where proven.

    ``MESHIA_SYNC_ENGINE_PROCESS=inline`` returns to the single-process mount
    without a release. Windows keeps the in-process mount until the WinFsp
    worker has been proven the same way.
    """

    mode = sync_engine_process_mode(environ)
    if mode == "split":
        return True
    if mode == "inline":
        return False
    return platform in ("darwin", "linux")
