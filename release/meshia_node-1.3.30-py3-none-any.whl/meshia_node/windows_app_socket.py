"""Private inherited-pipe connection to an app in the same Windows LPAC.

An ordinary process cannot connect to an AppContainer's loopback listener, and
LPAC rejects exporting its socket to that process. A fixed restricted helper
therefore owns the TCP connection. HTTP/SSE/WebSocket keep their existing real
socket interface over a private socketpair; no listening proxy is published.

Before acknowledging the helper, authenticate BOTH established TCP endpoints
against the retained app Job and this connector's separate retained Job. The
helper gets no caller code, environment, credentials, socket destination or
filesystem permission beyond this app's already-leased workspace boundary.
"""
from __future__ import annotations

import os
import socket
import struct
import sys
import threading
import time

from .app_process import AppProcessOwner, _PendingSocket, _refused

_HEADER = struct.Struct("!8sHHI")
_MAGIC = b"MSHAPP1\0"
_CHUNK = 65536

# This is executed with the canonical native launcher, after LPAC and the
# private HANDLE_LIST are installed. No workspace module is imported (-I).
_HELPER = r'''
import os,socket,struct,sys,threading
if sys.platform=='win32':
 import msvcrt
 for descriptor in (0,1,2):msvcrt.setmode(descriptor,os.O_BINARY)
port=int(sys.argv[1]);seconds=float(sys.argv[2])
if not 9000<=port<=9099 or not 0<seconds<=10:raise SystemExit(2)
def write_all(fd,data):
 view=memoryview(data)
 while view:
  count=os.write(fd,view)
  if count<=0:raise OSError('Private channel closed')
  view=view[count:]
with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as connection:
 connection.settimeout(seconds)
 connection.connect(('127.0.0.1',port))
 write_all(1,struct.pack('!8sHHI',b'MSHAPP1\0',port,connection.getsockname()[1],os.getpid()))
 # No application bytes move until the ordinary broker verifies both Jobs.
 if os.read(0,1)!=b'\x01':raise SystemExit(3)
 connection.settimeout(None)
 def send():
  try:
   while True:
    data=os.read(0,65536)
    if not data:break
    connection.sendall(data)
  except OSError:pass
  finally:
   try:connection.shutdown(socket.SHUT_WR)
   except OSError:pass
 sender=threading.Thread(target=send,daemon=True);sender.start()
 try:
  while True:
   data=connection.recv(65536)
   if not data:break
   write_all(1,data)
 except OSError:pass
'''


def _write_all(descriptor, data):
    view = memoryview(data)
    while view:
        count = os.write(descriptor, view)
        if count <= 0:
            raise _refused()
        view = view[count:]


class _Socket(socket.socket):
    def __init__(self, original, connection):
        super().__init__(original.family, original.type, original.proto,
                         fileno=original.detach())
        self._connection = connection

    def _real_close(self):
        # HTTPResponse.makefile retains this socket after HTTPConnection.close.
        # Retire the relay only after the final file reference releases it.
        connection, self._connection = self._connection, None
        if connection is not None:
            connection.close()
        super()._real_close()

    def shutdown(self, how):
        if how == socket.SHUT_RDWR and self._connection is not None:
            self._connection.close()
        else:
            super().shutdown(how)


class WindowsAppConnection:
    def __init__(self, owner, root, port):
        self.owner, self.root, self.port = owner, root, port
        self.helper_owner = AppProcessOwner()
        self.cancel = threading.Event()
        self.header_ready = threading.Event()
        self.authorized = threading.Event()
        self.lock = threading.Lock()
        self.closed = False
        self.header = None
        self.thread = None
        self.pumps = []
        self.attached = False
        self.started = False
        self.exited = threading.Event()
        left, self.right = socket.socketpair()
        self.socket = _Socket(left, self)

    def start(self, *, deadline, check=None):
        remaining = deadline - time.monotonic()
        if sys.platform != "win32" or not 0 < remaining <= 10:
            raise _refused()
        with self.lock:
            if self.closed or self.started:
                raise _refused()
            self.started = True
            self.thread = threading.Thread(target=self._run, args=(remaining,),
                                           name="meshia-app-lpac-connection", daemon=True)
            self.thread.start()
        while not self.header_ready.wait(.01):
            if check is not None:
                check()
            if self.cancel.is_set() or time.monotonic() >= deadline:
                raise _refused()
        self.verify(deadline=deadline, check=check)
        with self.lock:
            if self.closed or self.cancel.is_set() or time.monotonic() >= deadline:
                raise _refused()
            self.authorized.set()

    def _run(self, remaining):
        try:
            from . import winexec
            from .executor import native_environment
            from .native_command import command_argv
            from .util import console_python
            argv = command_argv([console_python(), "-I", "-c", _HELPER,
                                 str(self.port), str(remaining)],
                                root=self.root, cwd=".", access="limited")
            winexec.run_bounded_subprocess(argv, cwd=os.path.abspath(os.sep),
                env=native_environment(), timeout_seconds=None, max_output_bytes=0,
                cancel_event=self.cancel, process_owner=self.helper_owner,
                private_channel=self)
        except Exception:
            # Workload text, interpreter paths and pipe bytes are never errors
            # returned through the app protocol. Startup fails closed.
            self.close()
        finally:
            self.process_exited()

    def attach(self, stdin_fd, stdout_fd, stderr_fd):
        """Own all three descriptors on entry, including a rejected attachment."""
        from .native_command import command_stdin
        descriptors = (stdin_fd, stdout_fd, stderr_fd)
        pending = set(descriptors)
        try:
            with self.lock:
                if self.attached or self.closed or len(pending) != 3:
                    raise _refused()
                self.attached = True
                self.prefix = command_stdin({}, None)
                for target, descriptor in ((self._send, stdin_fd), (self._receive, stdout_fd),
                                           (self._discard_errors, stderr_fd)):
                    thread = threading.Thread(target=target, args=(descriptor,),
                                              name="meshia-app-private-pipe", daemon=True)
                    thread.start()
                    pending.remove(descriptor)
                    self.pumps.append(thread)
        except BaseException:
            for descriptor in pending:
                os.close(descriptor)
            self.close()
            raise

    def process_exited(self):
        self.exited.set()
        if not self.authorized.is_set():
            self.close()
        else:
            # No further request bytes can be delivered. Keep stdout's pump and
            # the reader socket alive until buffered response bytes drain to EOF.
            try:
                self.right.shutdown(socket.SHUT_RD)
            except OSError:
                pass

    def _gate(self):
        while not self.authorized.wait(.01):
            if self.cancel.is_set():
                return False
        return not self.cancel.is_set()

    def _send(self, descriptor):
        try:
            _write_all(descriptor, self.prefix)
            if not self._gate():
                return
            _write_all(descriptor, b"\x01")
            while not self.cancel.is_set():
                data = self.right.recv(_CHUNK)
                if not data:
                    break
                _write_all(descriptor, data)
        except (OSError, ValueError):
            pass
        finally:
            os.close(descriptor)

    def _receive(self, descriptor):
        try:
            data = b""
            while len(data) < _HEADER.size:
                chunk = os.read(descriptor, _HEADER.size-len(data))
                if not chunk:
                    raise _refused()
                data += chunk
            magic, port, client_port, pid = _HEADER.unpack(data)
            if magic != _MAGIC or port != self.port or not 0 < client_port < 65536 or pid <= 0:
                raise _refused()
            self.header = (port, client_port, pid)
            self.header_ready.set()
            if not self._gate():
                return
            while not self.cancel.is_set():
                data = os.read(descriptor, _CHUNK)
                if not data:
                    break
                self.right.sendall(data)
        except Exception:
            self.cancel.set()
        finally:
            os.close(descriptor)
            # Preserve buffered response bytes on a normal EOF. The socket's
            # reader consumes them before seeing EOF; no unbounded byte queue.
            try:
                self.right.shutdown(socket.SHUT_WR)
            except OSError:
                pass
            self.header_ready.set()

    @staticmethod
    def _discard_errors(descriptor):
        try:
            while os.read(descriptor, _CHUNK):
                pass
        except OSError:
            pass
        finally:
            os.close(descriptor)

    def verify(self, *, deadline, check=None):
        from .app_process import _windows_pids
        while True:
            if check is not None:
                check()
            if self.closed or self.cancel.is_set() or self.header is None or time.monotonic() >= deadline:
                raise _refused()
            port, client_port, pid = self.header
            server, client = ("127.0.0.1", port), ("127.0.0.1", client_port)
            try:
                # Locks protect borrowed Job handles from closure. No sleep or
                # app-authority callback runs while either lock is held.
                with self.owner._lock, self.helper_owner._lock:
                    if self.owner._closed or self.helper_owner._closed:
                        raise _refused()
                    self.owner._verify_windows(server, client)
                    self.helper_owner._verify_windows(client, server)
                    if _windows_pids(client, server) != {pid}:
                        raise _refused()
            except _PendingSocket:
                time.sleep(min(.01, max(0, deadline-time.monotonic())))
                continue
            if check is not None:
                check()
            if self.closed or self.cancel.is_set() or time.monotonic() >= deadline:
                raise _refused()
            return

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            self.cancel.set()
            self.header_ready.set()
            self.authorized.set()
            self.socket._connection = None
            for connection in (self.socket, self.right):
                try:
                    socket.socket.shutdown(connection, socket.SHUT_RDWR)
                except OSError:
                    pass
                socket.socket.close(connection)
        self.owner._retire_connection(self)
        # The existing native Job monitor owns termination and pipe retirement.
        # Never join ourselves or hold either ownership lock while reaping.
        if self.thread is not None and self.thread is not threading.current_thread():
            self.thread.join(timeout=.5)
