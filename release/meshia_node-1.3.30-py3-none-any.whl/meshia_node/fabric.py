"""MeshiaFabric signed transport and legacy small-file compatibility client.

``SignedFabricTransport`` is the wire adapter used by the current bounded
working-set coordinator: signed manifest/change/range/block/mutation calls plus
strict, short-lived direct block transfers. The legacy small-file synchronizer
remains below for compatibility and migration tests; it is not the installed
service's primary reconciliation path.
"""

from __future__ import annotations

import base64
import hashlib
import http.client
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import Future, TimeoutError as FutureTimeout
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from typing import Any, Mapping, Protocol

from .client import SignedClient
from .config import Paths, file_lock
from .fabric_transfer import MAX_BATCH_BLOCKS
from .http_pool import HttpsConnectionPool
from .object_edge import (
    CONNECTED_HOST_OBJECT_CAS_KIND,
    LEGACY_OBJECT_CAS_KIND,
    ObjectEdgeAuthExpired,
    ObjectEdgeDenied,
    ObjectEdgeDigestMismatch,
    ObjectEdgeError,
    ObjectEdgeNotFound,
    ObjectEdgeSession,
    ObjectEdgeUnavailable,
    ObjectEdgeUnprovenRange,
    object_edge_block_key,
    object_edge_path_key,
)
from .errors import InvalidTask, NetworkError, StateError, UnsafePath
from .fabric_contract_generated import parse_content_range, verify_block_range_response
from .log import NULL_LOGGER, NodeLogger
from .util import (
    RAW_SHA256_RE,
    UUID_RE,
    b64_standard,
    decode_canonical_b64,
    ensure_private_dir,
    sha256_hex,
    write_private_file,
)
from .workspace import WorkspaceBoundary

MANIFEST_SCHEMA = "meshia.connected_host.fabric_manifest.v1"
READ_SCHEMA = "meshia.connected_host.fabric_read.v1"
PUBLISH_SCHEMA = "meshia.connected_host.fabric_publish.v1"
UPLOAD_PART_RECEIPT_SCHEMA = "meshia.connected_host_fabric_upload_part_receipt.v1"
WORKSPACE_MOUNT = "workspace"
# Above the control plane's 120 s batch-persist budget and its own transport
# fence; below the route's 300 s maxDuration.
MUTATE_BATCH_TIMEOUT_SECONDS = 180.0
# A progressive ticket request contains only the active mutation and one
# companion. M1747 still carries a 25 s SQL statement fence; leave one default
# client deadline (20 s) of route/response margin above that hard fence while
# every classic write, verify, and read retains SignedClient's 20 s default.
MULTI_WRITE_TICKET_BATCH_TIMEOUT_SECONDS = 45.0
MANIFEST_PAGE_SIZE = 1_000
MAX_FILE_BYTES = 1_048_576
MAX_MANIFEST_FILES = 10_000
MAX_HYDRATION_BYTES = 64 * 1_048_576
MAX_DIRECT_BLOCK_BYTES = 64 * 1_048_576
MAX_DIRECT_RESPONSE_BYTES = MAX_DIRECT_BLOCK_BYTES + 1
MAX_DIRECT_ERROR_BYTES = 4 * 1024
MAX_DIRECT_TICKET_LIFETIME_SECONDS = 15 * 60
OBJECT_READ_TICKET_SCHEMA = "meshia.connected_host_fabric_object_read_ticket.v1"
CONTENT_ENCODING_IDENTITY_TICKET_FEATURE = "content_encoding_identity_v1"
# Whole-object tickets describe the complete file; range requests through them
# stay bounded by MAX_DIRECT_BLOCK_BYTES per call.
MAX_OBJECT_TICKET_BYTES = 2**53 - 1
DEFAULT_DIRECT_TIMEOUT_SECONDS = 5 * 60.0
DEFAULT_DIRECT_UPLOAD_TIMEOUT_SECONDS = 15 * 60.0
_HEADER_NAME_RE = re.compile(r"^[A-Za-z0-9-]{1,128}$")
_DIRECT_DENIED_HEADERS = frozenset(
    {"authorization", "cookie", "proxy-authorization", "proxy-connection"}
)
_DIRECT_LEGACY_PUT_HEADERS = frozenset(
    {
        "content-length",
        "content-type",
        "if-none-match",
        "x-amz-checksum-sha256",
        "x-amz-meta-meshia-sha256",
        "x-amz-meta-meshia-size-bytes",
    }
)
_DIRECT_IDENTITY_PUT_HEADERS = _DIRECT_LEGACY_PUT_HEADERS | {"content-encoding"}
_R2_STORAGE_SUFFIX = ".r2.cloudflarestorage.com"


class _DirectDeadlineRunner:
    """Bound direct object calls by elapsed time and retained worker count.

    ``wait_for_slot`` makes a full runner queue callers (bounded by the same
    wall-clock deadline) instead of failing them immediately. Uploads use a
    waiting runner: a refused slot must never be recorded as an attempted
    transfer, and the upload worker pool already bounds concurrency.
    """

    def __init__(self, max_active: int = 4, *, wait_for_slot: bool = False) -> None:
        self._slots = threading.BoundedSemaphore(max_active)
        self._wait_for_slot = wait_for_slot

    def run(self, function: Any, *, timeout: float) -> Any:
        if self._wait_for_slot:
            acquired = self._slots.acquire(timeout=max(0.0, float(timeout)))
        else:
            acquired = self._slots.acquire(blocking=False)
        if not acquired:
            raise _DirectSlotsBusy(
                "Fabric block deadline workers are still occupied by prior transfers."
            )
        future: Future[Any] = Future()

        def execute() -> None:
            try:
                if future.set_running_or_notify_cancel():
                    future.set_result(function())
            except BaseException as error:
                future.set_exception(error)
            finally:
                self._slots.release()

        threading.Thread(
            target=execute, name="meshia-block-deadline", daemon=True
        ).start()
        try:
            return future.result(timeout=timeout)
        except FutureTimeout:
            raise NetworkError(
                "Fabric block transfer exceeded its absolute wall-clock deadline."
            ) from None


class _DirectSlotsBusy(NetworkError):
    """No deadline slot was available; the transfer was never attempted."""


# The block deadline slots must never be smaller than the direct read pool
# (fabric_transfer.MAX_BATCH_BLOCKS), or the pool's extra workers are refused
# a slot and their transfers fail immediately as _DirectSlotsBusy.
DIRECT_BLOCK_MAX_ACTIVE = MAX_BATCH_BLOCKS
_DIRECT_DEADLINES = _DirectDeadlineRunner(max_active=DIRECT_BLOCK_MAX_ACTIVE)
# Object-range reads run several units in flight per file (see
# fabric_object_read); they must not compete with block uploads/downloads
# for the block slots, or a concurrent range beyond the bound fails at once.
OBJECT_RANGE_MAX_ACTIVE = 8
_OBJECT_RANGE_DEADLINES = _DirectDeadlineRunner(max_active=OBJECT_RANGE_MAX_ACTIVE)
# Block uploads have their own waiting runner sized for the upload worker
# pool (fabric_sync.UPLOAD_WORKER_CONCURRENCY must not exceed this). Sharing
# the download slots silently skipped later PUTs of an eight-stream wave and
# recorded them as unknown-outcome receipts.
DIRECT_UPLOAD_MAX_ACTIVE = 8
_UPLOAD_DEADLINES = _DirectDeadlineRunner(
    max_active=DIRECT_UPLOAD_MAX_ACTIVE, wait_for_slot=True
)


class _DirectPutPrecondition(Exception):
    """The immutable canonical object already exists."""


class _DirectPutRejected(NetworkError):
    """A definitive PUT rejection that must not be reported as success-unknown."""


@dataclass(frozen=True)
class FabricAuthority:
    host_id: str
    session_id: str
    host_generation: int
    attachment_id: str
    workspace_id: str | None = None

    @property
    def stable(self) -> tuple[str, str, int, str | None]:
        """The part of the scope that must survive an attachment change."""
        return (
            self.host_id,
            self.session_id,
            self.host_generation,
            self.workspace_id,
        )


@dataclass(frozen=True)
class ManifestFile:
    path: str
    size_bytes: int
    sha256: str


@dataclass(frozen=True)
class LoadedManifest:
    digest: str
    generation: int
    files: tuple[ManifestFile, ...]


@dataclass(frozen=True)
class HydrationReceipt:
    manifest_digest: str
    manifest_generation: int
    file_count: int
    written: int
    removed: int
    received_bytes: int


@dataclass
class FabricState:
    schema_version: int = 1
    authority: dict[str, Any] | None = None
    manifest_digest: str | None = None
    manifest_generation: int | None = None
    hydrated_digests: dict[str, str] = field(default_factory=dict)
    received_bytes: int = 0
    transmitted_bytes: int = 0


class FabricTransport(Protocol):
    def manifest(self, payload: dict[str, Any]) -> dict[str, Any]: ...
    def read(self, payload: dict[str, Any]) -> dict[str, Any]: ...
    def publish(self, payload: dict[str, Any]) -> dict[str, Any]: ...


class SignedFabricTransport:
    """Signed Fabric control calls plus verified, ticket-authorized block I/O.

    Signed JSON calls deliberately remain serialized inside ``SignedClient`` so
    request sequences cannot arrive out of order. Object bytes use exact,
    short-lived presigned tickets instead: that permits bounded parallel block
    transfer without handing the node reusable storage credentials or spending
    one host sequence per block.
    """

    def __init__(
        self,
        client: SignedClient,
        host_id: str,
        *,
        direct_opener: Any | None = None,
        direct_timeout: float = DEFAULT_DIRECT_TIMEOUT_SECONDS,
        direct_upload_timeout: float = DEFAULT_DIRECT_UPLOAD_TIMEOUT_SECONDS,
        allow_insecure_loopback: bool = False,
        now: Any = time.time,
        object_edge: ObjectEdgeSession | None = None,
    ) -> None:
        if (
            not isinstance(direct_timeout, (int, float))
            or isinstance(direct_timeout, bool)
            or not 0 < direct_timeout <= MAX_DIRECT_TICKET_LIFETIME_SECONDS
        ):
            raise ValueError(
                "direct_timeout must be positive and at most the maximum ticket lifetime"
            )
        if (
            not isinstance(direct_upload_timeout, (int, float))
            or isinstance(direct_upload_timeout, bool)
            or not 0 < direct_upload_timeout <= MAX_DIRECT_TICKET_LIFETIME_SECONDS
        ):
            raise ValueError(
                "direct_upload_timeout must be positive and at most the maximum ticket lifetime"
            )
        if not isinstance(allow_insecure_loopback, bool):
            raise ValueError("allow_insecure_loopback must be a boolean")
        self.client = client
        self.host_id = host_id
        # Keep-alive pool by default: presigned PUT/GET and object ranges reuse
        # TLS connections instead of paying a handshake per block or unit.
        self._direct_opener = direct_opener or HttpsConnectionPool(
            allow_insecure_loopback=allow_insecure_loopback
        )
        self._direct_timeout = float(direct_timeout)
        self._direct_upload_timeout = float(direct_upload_timeout)
        self._allow_insecure_loopback = allow_insecure_loopback
        self._now = now
        self._traffic_lock = threading.Lock()
        self._received_bytes = 0
        self._transmitted_bytes = 0
        # Meshia object edge (files.meshia.io): when the workspace holds a
        # scoped grant, block and object bytes bypass tickets entirely. The
        # session is fed by attach/heartbeat receipts and may be disabled for
        # the process lifetime after a definitive edge failure.
        self._object_edge = object_edge

    # ------------------------------------------------------------ object edge

    @property
    def object_edge(self) -> ObjectEdgeSession | None:
        return self._object_edge

    def edge_read_ready(self) -> bool:
        return self._object_edge is not None and self._object_edge.ready("read", float(self._now()))

    def edge_write_ready(self) -> bool:
        return self._object_edge is not None and self._object_edge.ready("write", float(self._now()))

    def edge_direct_commits(self) -> bool:
        """Whether verify/commit must admit blocks as direct edge uploads.

        True whenever an edge session exists (not only while a grant is
        live): a block may have been PUT through the edge by an earlier
        process, and the admission is idempotent for ticketed blocks.
        """

        return self._object_edge is not None

    def _edge_ticket(self, *, method: str, key: str, sha256: str, size_bytes: int) -> dict[str, Any] | None:
        edge = self._object_edge
        grant = edge.grant() if edge is not None else None
        if grant is None or not grant.usable(float(self._now()), "write" if method == "PUT" else "read"):
            return None
        return {
            "sha256": sha256,
            "size_bytes": size_bytes,
            "method": method,
            "url": f"{grant.url}/o/{key}",
            "headers": {},
            "expires_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(grant.expires_at)),
            "via": "edge",
            "key": key,
        }

    def edge_block_ticket(
        self,
        *,
        method: str,
        sha256: str,
        size_bytes: int,
        storage_kind: str = CONNECTED_HOST_OBJECT_CAS_KIND,
    ) -> dict[str, Any] | None:
        """Synthesize a ticket-shaped edge descriptor for one CAS block, or None."""

        edge = self._object_edge
        prefix = edge.prefix() if edge is not None else None
        if prefix is None:
            return None
        try:
            key = object_edge_block_key(prefix, sha256, storage_kind)
        except ValueError:
            return None
        return self._edge_ticket(method=method, key=key, sha256=sha256, size_bytes=size_bytes)

    def edge_object_ticket(self, *, path: str, sha256: str, size_bytes: int) -> dict[str, Any] | None:
        """Synthesize an object-read descriptor for a whole workspace object, or None."""

        edge = self._object_edge
        prefix = edge.prefix() if edge is not None else None
        if prefix is None:
            return None
        try:
            key = object_edge_path_key(prefix, path)
        except ValueError:
            return None
        ticket = self._edge_ticket(method="GET", key=key, sha256=sha256, size_bytes=size_bytes)
        if ticket is None:
            return None
        return {**ticket, "schema": OBJECT_READ_TICKET_SCHEMA, "operation": "object_read", "path": path}

    @staticmethod
    def _is_edge_ticket(ticket: Mapping[str, Any]) -> bool:
        return isinstance(ticket, Mapping) and ticket.get("via") == "edge" and isinstance(ticket.get("key"), str)

    def _edge_failure(self, error: ObjectEdgeError, *, operation: str) -> NetworkError:
        """Map an edge failure; definitive failures park the edge for this process."""

        edge = self._object_edge
        if (
            isinstance(error, (ObjectEdgeUnavailable, ObjectEdgeDenied, ObjectEdgeDigestMismatch))
            and edge is not None
        ):
            # A 422 here means the edge saw different bytes than the plan
            # digest: the ticket path re-reads the source and lets exact HEAD
            # verification decide, so park the edge rather than loop on it.
            edge.disable(f"{operation}: {type(error).__name__}: {error}")
        if isinstance(error, ObjectEdgeDigestMismatch):
            return _DirectPutRejected(f"Fabric block transfer was rejected by the object edge: {error}")
        return NetworkError(f"Meshia object edge {operation} failed: {error}")

    def _edge_client(self) -> Any:
        edge = self._object_edge
        client = edge.client() if edge is not None else None
        if client is None:
            raise NetworkError("The Meshia object edge grant is no longer available.")
        return client

    def _post(
        self,
        operation: str,
        payload: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        document = self.client.post_json(
            f"api/connected-hosts/{self.host_id}/fabric/{operation}",
            payload,
            **({"timeout": timeout} if timeout is not None else {}),
        )
        if not isinstance(document, dict):
            raise NetworkError(f"Meshia returned an invalid Fabric {operation} response.")
        return document

    def manifest(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("manifest", payload)

    def read(self, payload: dict[str, Any]) -> dict[str, Any]:
        document = self._post("read", payload)
        received = document.get("length_bytes", document.get("size_bytes", 0))
        if isinstance(received, int) and not isinstance(received, bool) and 0 <= received <= MAX_DIRECT_BLOCK_BYTES:
            with self._traffic_lock:
                self._received_bytes += received
        return document

    def publish(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("publish", payload)

    def changes(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("changes", payload)

    def blocks(self, payload: dict[str, Any]) -> dict[str, Any]:
        operation = (
            f"blocks?ticket_feature={CONTENT_ENCODING_IDENTITY_TICKET_FEATURE}"
            if payload.get("operation") == "write_batch"
            else "blocks"
        )
        items = payload.get("items")
        timeout = (
            MULTI_WRITE_TICKET_BATCH_TIMEOUT_SECONDS
            if payload.get("operation") == "write_batch"
            and isinstance(items, list)
            and len(items) > 1
            else None
        )
        return self._post(operation, payload, timeout=timeout)

    def block_reads(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.blocks(payload)

    def mutate(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("mutate", payload)

    def delete_path(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Publish one manifest-fenced directory tombstone."""

        return self._post("delete-path", payload)

    def mutate_batch(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Commit up to 64 path-independent mutations in one signed call.

        The route persists every item inside one database transaction under a
        120 s server budget (route maxDuration 300 s), so this call carries its
        own wall-clock deadline above that budget instead of the 20 s default.
        A deadline still surfaces as NetworkError: every member stays
        commit-unknown and is read back by mutation_status, never resent.
        """

        return self._post(
            "mutate-batch", payload, timeout=MUTATE_BATCH_TIMEOUT_SECONDS
        )

    def commit_v2(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Commit per-path ops through the Fabric v2 log-structured path.

        The request carries only what changed -- one op per touched path with
        the digest it expects to replace -- so its size is O(changed) rather
        than O(namespace). That is what removes the PAYLOAD_TOO_LARGE class of
        failure: v1 put a whole-namespace manifest preimage in every request,
        and a large workspace could blow the body limit on bookkeeping alone.
        """

        return self._post("v2-commit", payload, timeout=MUTATE_BATCH_TIMEOUT_SECONDS)

    def changes_v2(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Fetch journal records after a sequence: the v2 sync primitive."""

        return self._post("v2-changes", payload)

    def counters_v2(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Workspace size from incrementally maintained counters."""

        return self._post("v2-counters", payload)

    def snapshot_v2(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Page the whole tree, with the sequence to resume `changes` from.

        Used to bootstrap a fresh node and to rebuild one that has fallen
        behind the journal's retention. The walk is NOT a point-in-time view,
        so the caller resumes from the watermark its FIRST page reported and
        replays the overlap.
        """

        return self._post("v2-snapshot", payload)

    def lookup_v2(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Read one exact v2 entry, block descriptor included.

        A file learned through a snapshot page carried no descriptor before
        the control plane attached one; the read path fetches it here on
        first use rather than failing the read (v2 has no manifest-scoped
        range lane to fall back to).
        """

        return self._post("v2-lookup", payload)

    def mutation_status(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("mutation-status", payload)

    def upload_block(self, ticket: Mapping[str, Any], data: bytes) -> dict[str, Any]:
        if self._is_edge_ticket(ticket):
            return self._upload_block_via_edge(ticket, data)
        descriptor = _direct_ticket(
            ticket,
            expected_method="PUT",
            now=float(self._now()),
            allow_insecure_loopback=self._allow_insecure_loopback,
        )
        if not isinstance(data, bytes):
            raise NetworkError("A Fabric block upload must contain exact bytes.")
        if len(data) != descriptor.size_bytes or hashlib.sha256(data).hexdigest() != descriptor.sha256:
            raise NetworkError("A Fabric block upload failed local size or digest verification.")
        if descriptor.headers.get("content-length") != str(descriptor.size_bytes):
            raise NetworkError("A Fabric block upload ticket has an invalid content length.")
        def transfer() -> None:
            response = self._open_direct("PUT", descriptor, data)
            _read_bounded_direct_body(response, MAX_DIRECT_ERROR_BYTES)

        try:
            _UPLOAD_DEADLINES.run(transfer, timeout=self._direct_upload_timeout)
            outcome = "stored"
        except _DirectSlotsBusy:
            # Nothing was sent; this must surface as a failed attempt, never
            # as a receipt that verification later has to disprove.
            raise
        except _DirectPutPrecondition:
            # If-None-Match makes a same-key winner indistinguishable from an
            # exact replay here.  Signed verification is the authority.
            outcome = "canonical_exists"
        except _DirectPutRejected:
            raise
        except NetworkError:
            # A timeout or severed response can happen after the object became
            # durable.  Persist the attempt and let signed exact-HEAD
            # verification decide whether another PUT is needed.
            outcome = "unknown"
        with self._traffic_lock:
            self._transmitted_bytes += len(data)
        return {
            "schema": UPLOAD_PART_RECEIPT_SCHEMA,
            "sha256": descriptor.sha256,
            "size_bytes": descriptor.size_bytes,
            "outcome": outcome,
        }

    def _upload_block_via_edge(self, ticket: Mapping[str, Any], data: bytes) -> dict[str, Any]:
        digest = ticket.get("sha256")
        size = ticket.get("size_bytes")
        if (
            not isinstance(digest, str)
            or RAW_SHA256_RE.fullmatch(digest) is None
            or isinstance(size, bool)
            or not isinstance(size, int)
            or not isinstance(data, bytes)
            or len(data) != size
            or hashlib.sha256(data).hexdigest() != digest
        ):
            raise NetworkError("A Fabric block upload failed local size or digest verification.")
        client = self._edge_client()

        def transfer() -> dict[str, Any]:
            return client.put_cas(digest, data)

        try:
            receipt = _UPLOAD_DEADLINES.run(transfer, timeout=self._direct_upload_timeout)
        except _DirectSlotsBusy:
            raise
        except ObjectEdgeError as error:
            raise self._edge_failure(error, operation="put") from None
        outcome = receipt.get("outcome") if isinstance(receipt, Mapping) else None
        if outcome not in ("stored", "canonical_exists"):
            raise NetworkError("The Meshia object edge returned an invalid upload receipt.")
        with self._traffic_lock:
            self._transmitted_bytes += len(data)
        return {
            "schema": UPLOAD_PART_RECEIPT_SCHEMA,
            "sha256": digest,
            "size_bytes": size,
            "outcome": outcome,
        }

    def _download_block_via_edge(self, ticket: Mapping[str, Any]) -> bytes:
        digest = ticket.get("sha256")
        size = ticket.get("size_bytes")
        key = ticket.get("key")
        if (
            not isinstance(digest, str)
            or RAW_SHA256_RE.fullmatch(digest) is None
            or isinstance(size, bool)
            or not isinstance(size, int)
            or not 0 <= size <= MAX_DIRECT_BLOCK_BYTES
            or not isinstance(key, str)
        ):
            raise NetworkError("Meshia produced an invalid edge block descriptor.")
        client = self._edge_client()

        def transfer() -> bytes:
            if size == 0:
                return b""
            return client.read_range(key, 0, size, total_size=size)

        try:
            data = _DIRECT_DEADLINES.run(transfer, timeout=self._direct_timeout)
        except ObjectEdgeError as error:
            raise self._edge_failure(error, operation="block read") from None
        if len(data) != size or hashlib.sha256(data).hexdigest() != digest:
            raise NetworkError("A Fabric block download failed end-to-end verification.")
        with self._traffic_lock:
            self._received_bytes += len(data)
        return data

    def _download_object_range_via_edge(
        self, ticket: Mapping[str, Any], offset: int, length: int
    ) -> bytes:
        size = ticket.get("size_bytes")
        key = ticket.get("key")
        if (
            isinstance(size, bool)
            or not isinstance(size, int)
            or not 1 <= size <= MAX_OBJECT_TICKET_BYTES
            or not isinstance(key, str)
            or isinstance(offset, bool)
            or isinstance(length, bool)
            or not isinstance(offset, int)
            or not isinstance(length, int)
            or offset < 0
            or not 1 <= length <= MAX_DIRECT_BLOCK_BYTES
            or offset + length > size
        ):
            raise ValueError("The object range is outside the descriptor's declared size.")
        client = self._edge_client()

        def transfer() -> bytes:
            return client.read_range(key, offset, length, total_size=size)

        try:
            data = _OBJECT_RANGE_DEADLINES.run(transfer, timeout=self._direct_timeout)
        except ObjectEdgeNotFound as error:
            # A per-file miss (scaffold, packed, or replaced object) is not an
            # edge outage: the reader falls back to a signed ticket for the
            # file while the edge stays live for every other object.
            raise ObjectEdgeNotFound(str(error)) from None
        except ObjectEdgeAuthExpired as error:
            raise NetworkError(f"Meshia object edge read failed: {error}") from None
        except ObjectEdgeError as error:
            raise self._edge_failure(error, operation="object read") from None
        with self._traffic_lock:
            self._received_bytes += len(data)
        return data

    def object_read(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Signed ``object_read`` ticket request on the blocks route."""

        return self.blocks(payload)

    def object_read_batch(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Signed ``object_read_batch`` ticket request on the blocks route."""

        return self.blocks(payload)

    def download_object_range(
        self, ticket: Mapping[str, Any], offset: int, length: int
    ) -> bytes:
        """Fetch one exact byte range of a whole object through a GET ticket.

        The response must be a ``206`` whose ``Content-Range`` names exactly
        the requested span and the ticket's total size (a ``200`` is accepted
        only for a complete single-request read).  Bytes beyond the declared
        length are rejected rather than truncated.
        """

        if self._is_edge_ticket(ticket):
            return self._download_object_range_via_edge(ticket, offset, length)
        descriptor = parse_object_ticket(
            ticket,
            now=float(self._now()),
            allow_insecure_loopback=self._allow_insecure_loopback,
        )
        if (
            isinstance(offset, bool)
            or isinstance(length, bool)
            or not isinstance(offset, int)
            or not isinstance(length, int)
            or offset < 0
            or not 1 <= length <= MAX_DIRECT_BLOCK_BYTES
            or offset + length > descriptor.size_bytes
        ):
            raise ValueError("The object range is outside the ticket's declared size.")
        end = offset + length - 1
        request_ticket = _DirectTicket(
            url=descriptor.url,
            sha256=descriptor.sha256,
            size_bytes=length,
            headers={**descriptor.headers, "range": f"bytes={offset}-{end}"},
        )
        whole_object = offset == 0 and length == descriptor.size_bytes

        def transfer() -> bytes:
            response = self._open_direct("GET", request_ticket, None)
            status = getattr(response, "status", None)
            content_range = _parse_content_range(response.headers.get("content-range"))
            claimed_length = response.headers.get("content-length")
            if status == 206:
                valid = content_range == (offset, end, descriptor.size_bytes)
            elif status == 200:
                valid = whole_object and content_range is None
            else:
                valid = False
            if valid and claimed_length is not None:
                valid = claimed_length.strip() == str(length)
            if not valid:
                response.close()
                raise NetworkError(
                    "Fabric object storage returned a range that does not match the request."
                )
            data = _read_bounded_direct_body(response, length)
            if len(data) != length:
                raise NetworkError("Fabric object storage ended its range early.")
            return data

        data = _OBJECT_RANGE_DEADLINES.run(transfer, timeout=self._direct_timeout)
        with self._traffic_lock:
            self._received_bytes += len(data)
        return data

    def download_block_range(self, ticket: Mapping[str, Any], offset: int, length: int) -> bytes:
        """Read a provider-proven slice; old blocks retain complete SHA-256 verification."""
        size = ticket.get("size_bytes")
        digest = ticket.get("sha256")
        if (isinstance(offset, bool) or isinstance(length, bool) or
                not isinstance(offset, int) or not isinstance(length, int) or
                isinstance(size, bool) or not isinstance(size, int) or
                not isinstance(digest, str) or RAW_SHA256_RE.fullmatch(digest) is None or
                not 0 <= offset < size or not 0 < length <= size - offset):
            raise ValueError("Invalid block read range")
        if offset == 0 and length == size:
            return self.download_block(ticket)
        if self._is_edge_ticket(ticket):
            try:
                data = _DIRECT_DEADLINES.run(lambda: self._edge_client().read_range(
                    ticket["key"], offset, length, total_size=size, expected_sha256=digest,
                ), timeout=self._direct_timeout)
            except ObjectEdgeUnprovenRange:
                return self.download_block(ticket)[offset:offset + length]
        else:
            descriptor = _direct_ticket(ticket, expected_method="GET", now=float(self._now()),
                allow_insecure_loopback=self._allow_insecure_loopback)
            ranged = _DirectTicket(url=descriptor.url, sha256=digest, size_bytes=length,
                headers={**descriptor.headers, "range": f"bytes={offset}-{offset + length - 1}",
                         "accept-encoding": "identity"})
            def transfer() -> bytes | None:
                response = self._open_direct("GET", ranged, None)
                try:
                    proven = verify_block_range_response(response.headers, response.status,
                        sha256=digest, size=size, offset=offset, length=length)
                except ValueError as error:
                    response.close()
                    raise NetworkError(str(error)) from None
                if not proven:
                    response.close()
                    return None
                data = _read_bounded_direct_body(response, length)
                if len(data) != length:
                    raise NetworkError("The block range ended early.")
                return data
            data = _DIRECT_DEADLINES.run(transfer, timeout=self._direct_timeout)
            if data is None:
                return self.download_block(ticket)[offset:offset + length]
        with self._traffic_lock:
            self._received_bytes += len(data)
        return data

    def download_block(self, ticket: Mapping[str, Any]) -> bytes:
        if self._is_edge_ticket(ticket):
            return self._download_block_via_edge(ticket)
        descriptor = _direct_ticket(
            ticket,
            expected_method="GET",
            now=float(self._now()),
            allow_insecure_loopback=self._allow_insecure_loopback,
        )
        def transfer() -> bytes:
            response = self._open_direct("GET", descriptor, None)
            claimed_length = response.headers.get("content-length")
            if claimed_length is not None and claimed_length.strip() != str(
                descriptor.size_bytes
            ):
                response.close()
                raise NetworkError(
                    "A Fabric block download returned an invalid content length."
                )
            return _read_bounded_direct_body(response, descriptor.size_bytes)

        data = _DIRECT_DEADLINES.run(transfer, timeout=self._direct_timeout)
        if len(data) != descriptor.size_bytes or hashlib.sha256(data).hexdigest() != descriptor.sha256:
            raise NetworkError("A Fabric block download failed end-to-end verification.")
        with self._traffic_lock:
            self._received_bytes += len(data)
        return data

    def traffic(self) -> tuple[int, int]:
        with self._traffic_lock:
            return self._received_bytes, self._transmitted_bytes

    def _open_direct(
        self,
        method: str,
        descriptor: "_DirectTicket",
        body: bytes | None,
    ) -> Any:
        try:
            request = urllib.request.Request(
                descriptor.url,
                data=body,
                method=method,
                headers=dict(descriptor.headers),
            )
            timeout = (
                self._direct_upload_timeout
                if method == "PUT"
                else self._direct_timeout
            )
            response = self._direct_opener.open(request, timeout=timeout)
        except urllib.error.HTTPError as error:
            try:
                _read_bounded_direct_body(error, MAX_DIRECT_ERROR_BYTES)
            except NetworkError:
                if method != "PUT":
                    raise
            # Presigned URLs contain bearer query parameters.  Never retain the
            # urllib exception as a cause because its repr/string can expose
            # the full target in tracebacks or persistent logs.
            if method == "PUT" and error.code == 412:
                raise _DirectPutPrecondition from None
            if method == "PUT" and error.code not in {408, 429} and error.code < 500:
                raise _DirectPutRejected(
                    f"Fabric block transfer failed (HTTP {error.code})."
                ) from None
            raise NetworkError(f"Fabric block transfer failed (HTTP {error.code}).") from None
        except (urllib.error.URLError, http.client.HTTPException, OSError):
            raise NetworkError("Fabric block storage is temporarily unreachable.") from None
        status = getattr(response, "status", None)
        if not isinstance(status, int) or not 200 <= status < 300:
            try:
                _read_bounded_direct_body(response, MAX_DIRECT_ERROR_BYTES)
            finally:
                response.close()
            if method == "PUT" and isinstance(status, int):
                if status == 412:
                    raise _DirectPutPrecondition
                if status not in {408, 429} and status < 500:
                    raise _DirectPutRejected(
                        f"Fabric block transfer failed (HTTP {status})."
                    )
            raise NetworkError("Fabric block storage returned an invalid response.")
        return response


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Never forward a presigned URL or signed PUT headers across redirects."""

    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> None:
        return None


@dataclass(frozen=True)
class _DirectTicket:
    url: str
    sha256: str
    size_bytes: int
    headers: Mapping[str, str]


def _validate_direct_url(url: object, *, allow_insecure_loopback: bool) -> str:
    if (
        not isinstance(url, str)
        or len(url) > 16_384
        or any(ord(character) <= 0x20 or ord(character) == 0x7F for character in url)
    ):
        raise NetworkError("Meshia returned an unsafe Fabric block URL.")
    try:
        parts = urllib.parse.urlsplit(url)
        host = (parts.hostname or "").lower()
        port = parts.port
    except ValueError:
        raise NetworkError("Meshia returned an unsafe Fabric block URL.") from None
    loopback_http = (
        allow_insecure_loopback
        and parts.scheme == "http"
        and host in {"localhost", "127.0.0.1", "::1"}
    )
    r2_https = (
        parts.scheme == "https"
        and (port is None or port == 443)
        and host.endswith(_R2_STORAGE_SUFFIX)
        and len(host) > len(_R2_STORAGE_SUFFIX)
        and all(
            label
            and len(label) <= 63
            and label[0].isalnum()
            and label[-1].isalnum()
            and all(character.isascii() and (character.isalnum() or character == "-") for character in label)
            for label in host.split(".")
        )
    )
    if (
        not (loopback_http or r2_https)
        or parts.username is not None
        or parts.password is not None
        or bool(parts.fragment)
    ):
        raise NetworkError("Meshia returned an unsafe Fabric block URL.")
    return url


def parse_direct_ticket_expiry(expires_at: object, *, now: float) -> float:
    """Return the epoch expiry of one ticket, rejecting non-UTC or absurd values."""

    if not isinstance(expires_at, str):
        raise NetworkError("Meshia returned an invalid Fabric block ticket expiry.")
    try:
        parsed_expiry = datetime.fromisoformat(
            expires_at[:-1] + "+00:00" if expires_at.endswith("Z") else expires_at
        )
        if parsed_expiry.tzinfo is None or parsed_expiry.utcoffset() != timedelta(0):
            raise ValueError("Fabric ticket expiry must identify UTC")
        expiry = parsed_expiry.timestamp()
    except (ValueError, OverflowError):
        raise NetworkError("Meshia returned an invalid Fabric block ticket expiry.") from None
    if expiry <= now + 1 or expiry > now + MAX_DIRECT_TICKET_LIFETIME_SECONDS + 5:
        raise NetworkError("The Fabric block ticket is expired or has an excessive lifetime.")
    return expiry


def _validate_direct_headers(raw_headers: object) -> dict[str, str]:
    if not isinstance(raw_headers, Mapping) or len(raw_headers) > 32:
        raise NetworkError("Meshia returned an invalid Fabric block ticket.")
    headers: dict[str, str] = {}
    for raw_name, raw_value in raw_headers.items():
        if not isinstance(raw_name, str) or not isinstance(raw_value, str):
            raise NetworkError("Meshia returned invalid Fabric block ticket headers.")
        name = raw_name.strip().lower()
        value_text = raw_value.strip()
        if (
            _HEADER_NAME_RE.fullmatch(name) is None
            or name in _DIRECT_DENIED_HEADERS
            or len(value_text) > 8_192
            or any(character in value_text for character in ("\r", "\n", "\0"))
            or name in headers
        ):
            raise NetworkError("Meshia returned unsafe Fabric block ticket headers.")
        headers[name] = value_text
    return headers


def _direct_ticket(
    value: Mapping[str, Any],
    *,
    expected_method: str,
    now: float,
    allow_insecure_loopback: bool = False,
) -> _DirectTicket:
    if not isinstance(value, Mapping):
        raise NetworkError("Meshia returned an invalid Fabric block ticket.")
    digest = value.get("sha256")
    size = value.get("size_bytes")
    url = value.get("url")
    expires_at = value.get("expires_at")
    method = value.get("method", "GET")
    raw_headers = value.get("headers")
    if (
        not isinstance(digest, str)
        or RAW_SHA256_RE.fullmatch(digest) is None
        or isinstance(size, bool)
        or not isinstance(size, int)
        or not 0 <= size <= MAX_DIRECT_BLOCK_BYTES
        or not isinstance(url, str)
        or method != expected_method
        or not isinstance(expires_at, str)
        or not isinstance(raw_headers, Mapping)
        or (
            expected_method == "PUT"
            and set(value)
            != ({"sha256", "size_bytes", "method", "url", "headers", "expires_at"}
                | ({"storage_kind"} if value.get("storage_kind") == LEGACY_OBJECT_CAS_KIND else set()))
        )
        or (
            expected_method != "PUT"
            and set(value)
            not in (
                {"sha256", "size_bytes", "url", "headers", "expires_at"},
                {"sha256", "size_bytes", "method", "url", "headers", "expires_at"},
            )
        )
    ):
        raise NetworkError("Meshia returned an invalid Fabric block ticket.")
    _validate_direct_url(url, allow_insecure_loopback=allow_insecure_loopback)
    parse_direct_ticket_expiry(expires_at, now=now)
    headers = _validate_direct_headers(raw_headers)
    expected_headers = set(headers)
    if expected_method == "PUT" and expected_headers not in (
        _DIRECT_LEGACY_PUT_HEADERS,
        _DIRECT_IDENTITY_PUT_HEADERS,
    ):
        raise NetworkError("Meshia returned unsafe Fabric block ticket headers.")
    if expected_method != "PUT" and expected_headers:
        raise NetworkError("Meshia returned unsafe Fabric block ticket headers.")
    if expected_method == "PUT":
        checksum = base64.b64encode(bytes.fromhex(digest)).decode("ascii")
        if (
            ("content-encoding" in headers and headers["content-encoding"] != "identity")
            or headers["content-length"] != str(size)
            or headers["content-type"] != "application/octet-stream"
            or headers["if-none-match"] != "*"
            or headers["x-amz-checksum-sha256"] != checksum
            or headers["x-amz-meta-meshia-sha256"] != digest
            or headers["x-amz-meta-meshia-size-bytes"] != str(size)
        ):
            raise NetworkError("Meshia returned unsafe Fabric block ticket headers.")
    return _DirectTicket(
        url=url,
        sha256=digest,
        size_bytes=size,
        headers=headers,
    )


@dataclass(frozen=True)
class ObjectTicket:
    """One validated whole-object GET capability for bounded range reads."""

    url: str
    sha256: str
    size_bytes: int
    headers: Mapping[str, str]
    expires_at: float


_OBJECT_TICKET_REQUIRED_KEYS = frozenset({"sha256", "size_bytes", "url", "headers", "expires_at"})
_OBJECT_TICKET_OPTIONAL_KEYS = frozenset(
    {"schema", "operation", "method", "path", "manifest_generation", "manifest_digest"}
)


def parse_object_ticket(
    value: Mapping[str, Any],
    *,
    now: float,
    allow_insecure_loopback: bool = False,
) -> ObjectTicket:
    """Validate an ``object_read`` ticket document (whole file, GET only)."""

    if (
        not isinstance(value, Mapping)
        or not _OBJECT_TICKET_REQUIRED_KEYS <= set(value)
        or not set(value) <= (_OBJECT_TICKET_REQUIRED_KEYS | _OBJECT_TICKET_OPTIONAL_KEYS)
    ):
        raise NetworkError("Meshia returned an invalid Fabric object ticket.")
    digest = value.get("sha256")
    size = value.get("size_bytes")
    if (
        not isinstance(digest, str)
        or RAW_SHA256_RE.fullmatch(digest) is None
        or isinstance(size, bool)
        or not isinstance(size, int)
        or not 1 <= size <= MAX_OBJECT_TICKET_BYTES
        or value.get("method", "GET") != "GET"
        or ("schema" in value and value["schema"] != OBJECT_READ_TICKET_SCHEMA)
        or ("operation" in value and value["operation"] != "object_read")
    ):
        raise NetworkError("Meshia returned an invalid Fabric object ticket.")
    url = _validate_direct_url(
        value.get("url"), allow_insecure_loopback=allow_insecure_loopback
    )
    expiry = parse_direct_ticket_expiry(value.get("expires_at"), now=now)
    headers = _validate_direct_headers(value.get("headers"))
    if headers:
        # GET tickets carry their whole authority in the signed query string.
        raise NetworkError("Meshia returned unsafe Fabric object ticket headers.")
    return ObjectTicket(
        url=url,
        sha256=digest,
        size_bytes=size,
        headers=headers,
        expires_at=expiry,
    )


def _parse_content_range(value: object) -> tuple[int, int, int] | None:
    return parse_content_range(value)


def _read_bounded_direct_body(response: Any, maximum: int) -> bytes:
    if maximum < 0 or maximum > MAX_DIRECT_RESPONSE_BYTES:
        response.close()
        raise NetworkError("The Fabric direct-response bound is invalid.")
    try:
        body = response.read(maximum + 1)
    except (http.client.HTTPException, OSError):
        # The underlying response object can retain the presigned request URL.
        raise NetworkError("Fabric block storage ended its response unexpectedly.") from None
    finally:
        response.close()
    if not isinstance(body, bytes) or len(body) > maximum:
        raise NetworkError("Fabric block storage returned an oversized response.")
    return body


class FabricStore:
    """0600 baseline document at ``~/.meshia/fabric-state.json``."""

    def __init__(self, paths: Paths) -> None:
        self.paths = paths
        self.lock_path = paths.locks_dir / "fabric.lock"

    def load(self) -> FabricState:
        path = self.paths.fabric_state
        if not path.exists():
            return FabricState()
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise StateError("The Fabric baseline is unreadable.") from error
        known = {key: document[key] for key in FabricState.__dataclass_fields__ if key in document}
        return FabricState(**known)

    def save(self, state: FabricState) -> None:
        ensure_private_dir(self.paths.home)
        write_private_file(
            self.paths.fabric_state, json.dumps(asdict(state), indent=2, sort_keys=True).encode("utf-8")
        )

    def bind(self, authority: FabricAuthority) -> FabricState:
        """Rebind the baseline, discarding it if the stable scope changed."""
        with file_lock(self.lock_path):
            state = self.load()
            existing = state.authority
            if existing is not None:
                previous = (
                    str(existing.get("host_id")),
                    str(existing.get("session_id")),
                    int(existing.get("host_generation", 0)),
                    (
                        str(existing["workspace_id"])
                        if existing.get("workspace_id") is not None
                        else None
                    ),
                )
                if previous != authority.stable:
                    state = FabricState()
            state.authority = asdict(authority)
            self.save(state)
            return state


class FabricSynchronizer:
    def __init__(
        self,
        transport: FabricTransport,
        store: FabricStore,
        workspace: WorkspaceBoundary,
        authority: FabricAuthority,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        self.transport = transport
        self.store = store
        self.workspace = workspace
        self.authority = authority
        self.logger = logger

    # ---------------------------------------------------------------- manifest

    def load_manifest(self) -> LoadedManifest:
        offset = 0
        after_path: str | None = None
        manifest_id: str | None = None
        digest: str | None = None
        generation: int | None = None
        total: int | None = None
        files: list[ManifestFile] = []
        seen: set[str] = set()
        while True:
            request: dict[str, Any] = {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "offset": offset,
                "limit": MANIFEST_PAGE_SIZE,
            }
            if after_path is not None:
                request["after_path"] = after_path
                request["manifest_id"] = manifest_id
                request["manifest_digest"] = digest
                request["manifest_generation"] = generation
            page = self.transport.manifest(request)
            entries = page.get("files")
            if (
                page.get("schema") != MANIFEST_SCHEMA
                or page.get("workspace") != WORKSPACE_MOUNT
                or page.get("offset") != offset
                or page.get("limit") != MANIFEST_PAGE_SIZE
                or not isinstance(page.get("total_files"), int)
                or isinstance(page.get("total_files"), bool)
                or not 0 <= page["total_files"] <= MAX_MANIFEST_FILES
                or not isinstance(page.get("manifest_id"), str)
                or not UUID_RE.match(page["manifest_id"])
                or not isinstance(page.get("manifest_digest"), str)
                or not RAW_SHA256_RE.match(page["manifest_digest"])
                or not isinstance(page.get("manifest_generation"), int)
                or isinstance(page.get("manifest_generation"), bool)
                or page["manifest_generation"] < 1
                or not isinstance(entries, list)
                or len(entries) > MANIFEST_PAGE_SIZE
            ):
                raise NetworkError("Meshia returned an invalid Fabric manifest page.")
            if manifest_id is not None and (
                manifest_id != page["manifest_id"]
                or digest != page["manifest_digest"]
                or generation != page["manifest_generation"]
                or total != page["total_files"]
            ):
                raise NetworkError("The Fabric manifest changed during hydration.")
            manifest_id, digest, generation, total = (
                page["manifest_id"],
                page["manifest_digest"],
                page["manifest_generation"],
                page["total_files"],
            )
            previous_path = after_path
            for entry in entries:
                descriptor = _descriptor(entry)
                if previous_path is not None and descriptor.path.encode(
                    "utf-8"
                ) <= previous_path.encode("utf-8"):
                    raise NetworkError(
                        "Meshia returned an out-of-order Fabric file descriptor."
                    )
                if descriptor.path in seen:
                    raise NetworkError("Meshia returned a duplicate Fabric file descriptor.")
                seen.add(descriptor.path)
                files.append(descriptor)
                previous_path = descriptor.path
            next_offset = page.get("next_offset")
            expected_next_offset = offset + len(entries)
            truncated = expected_next_offset < total
            next_after_path = page.get("next_after_path")
            if (
                not isinstance(next_offset, int)
                or isinstance(next_offset, bool)
                or next_offset != expected_next_offset
                or next_offset > total
                or page.get("truncated") is not truncated
                or (
                    truncated
                    and (
                        not entries
                        or not isinstance(next_after_path, str)
                        or next_after_path != previous_path
                    )
                )
                or (not truncated and next_after_path is not None)
            ):
                raise NetworkError("Meshia returned inconsistent Fabric pagination.")
            offset = next_offset
            if offset >= total:
                break
            after_path = next_after_path
        if manifest_id is None or digest is None or generation is None or len(files) != total:
            raise NetworkError("Meshia returned an incomplete Fabric manifest.")
        if sum(min(item.size_bytes, MAX_FILE_BYTES + 1) for item in files) > MAX_HYDRATION_BYTES:
            raise InvalidTask("Fabric v1 hydration exceeds the 64 MiB aggregate safety limit.")
        return LoadedManifest(digest=digest, generation=generation, files=tuple(files))

    # ---------------------------------------------------------------- hydrate

    def hydrate(self) -> HydrationReceipt:
        state = self.store.bind(self.authority)
        manifest = self.load_manifest()
        remote = {item.path: item for item in manifest.files}
        baseline = dict(state.hydrated_digests)

        # 1. Fetch + verify every remote object before mutating anything.
        contents: dict[str, bytes] = {}
        received = 0
        for descriptor in manifest.files:
            if descriptor.size_bytes > MAX_FILE_BYTES:
                raise InvalidTask("Fabric v1 cannot hydrate files larger than 1 MiB.")
            payload = self.transport.read(
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "path": descriptor.path,
                }
            )
            contents[descriptor.path] = self._verified_read(payload, descriptor, manifest)
            received += descriptor.size_bytes

        # 2. Fail closed on divergence, before any write.
        current: dict[str, str | None] = {}
        for path in set(baseline) | set(remote):
            try:
                digest = self.workspace.sha256_if_present(path)
            except (UnsafePath, InvalidTask) as error:
                raise InvalidTask(f"Fabric hydration cannot inspect {path}: {error}") from error
            current[path] = digest
            expected = baseline.get(path)
            remote_digest = remote[path].sha256 if path in remote else None
            if expected is None:
                if digest is not None and remote_digest is not None and digest != remote_digest:
                    raise InvalidTask(
                        f"Fabric hydration found a local file that conflicts with the attached workspace: {path}"
                    )
            elif digest != expected and digest != remote_digest:
                raise InvalidTask(
                    f"Fabric hydration found a locally edited file and will not overwrite it: {path}"
                )

        # 3. Apply.
        written = 0
        for descriptor in manifest.files:
            existing = current.get(descriptor.path)
            if existing == descriptor.sha256:
                continue
            self.workspace.write_file(
                descriptor.path,
                contents[descriptor.path],
                create_parents=True,
                overwrite=True,
                expected_sha256=f"sha256:{existing}" if existing else None,
            )
            written += 1
        removed = 0
        for path, expected in baseline.items():
            if path in remote:
                continue
            if current.get(path) == expected:
                self.workspace.remove_file(path)
                removed += 1

        with file_lock(self.store.lock_path):
            state = self.store.load()
            state.manifest_digest = manifest.digest
            state.manifest_generation = manifest.generation
            state.hydrated_digests = {item.path: item.sha256 for item in manifest.files}
            state.received_bytes += received
            self.store.save(state)
        self.logger.record(
            "fabric_hydrated",
            manifest_generation=manifest.generation,
            file_count=len(manifest.files),
            written=written,
            removed=removed,
        )
        return HydrationReceipt(
            manifest_digest=manifest.digest,
            manifest_generation=manifest.generation,
            file_count=len(manifest.files),
            written=written,
            removed=removed,
            received_bytes=received,
        )

    # ---------------------------------------------------------------- publish

    def publish_bytes(self, path: str, data: bytes) -> dict[str, Any]:
        if len(data) > MAX_FILE_BYTES:
            raise InvalidTask("Fabric v1 publishes are limited to 1 MiB.")
        digest = sha256_hex(data)
        receipt = self.transport.publish(
            {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "path": path,
                "content_base64": b64_standard(data),
                "sha256": digest,
            }
        )
        receipt_size = receipt.get("size_bytes")
        receipt_generation = receipt.get("manifest_generation")
        if (
            receipt.get("schema") != PUBLISH_SCHEMA
            or receipt.get("workspace") != WORKSPACE_MOUNT
            or receipt.get("path") != path
            or isinstance(receipt_size, bool)
            or not isinstance(receipt_size, int)
            or receipt_size != len(data)
            or receipt.get("sha256") != digest
            or not isinstance(receipt.get("manifest_id"), str)
            or not UUID_RE.match(receipt["manifest_id"])
            or not isinstance(receipt.get("manifest_digest"), str)
            or not RAW_SHA256_RE.match(receipt["manifest_digest"])
            or isinstance(receipt_generation, bool)
            or not isinstance(receipt_generation, int)
            or receipt_generation < 1
        ):
            raise NetworkError("Meshia returned an invalid Fabric publish receipt.")
        with file_lock(self.store.lock_path):
            state = self.store.load()
            state.hydrated_digests[path] = digest
            state.manifest_digest = receipt["manifest_digest"]
            state.manifest_generation = receipt["manifest_generation"]
            state.transmitted_bytes += len(data)
            self.store.save(state)
        self.logger.record("fabric_published", path=path, size_bytes=len(data))
        return receipt

    def publish_workspace_file(self, path: str) -> dict[str, Any]:
        data = self.workspace.snapshot(path)
        if data is None:
            raise InvalidTask(f"The workspace file {path} is missing and cannot be published.")
        return self.publish_bytes(path, data)

    def traffic(self) -> tuple[int, int]:
        state = self.store.load()
        return state.received_bytes, state.transmitted_bytes

    # --------------------------------------------------------------- internals

    @staticmethod
    def _verified_read(
        payload: dict[str, Any], descriptor: ManifestFile, manifest: LoadedManifest
    ) -> bytes:
        encoded = payload.get("content_base64")
        data = decode_canonical_b64(encoded) if isinstance(encoded, str) else None
        if (
            payload.get("schema") != READ_SCHEMA
            or payload.get("workspace") != WORKSPACE_MOUNT
            or payload.get("path") != descriptor.path
            or payload.get("size_bytes") != descriptor.size_bytes
            or payload.get("sha256") != descriptor.sha256
            or payload.get("manifest_digest") != manifest.digest
            or payload.get("manifest_generation") != manifest.generation
            or data is None
            or len(data) != descriptor.size_bytes
            or sha256_hex(data) != descriptor.sha256
        ):
            raise NetworkError("Fabric file content failed end-to-end verification.")
        return data


def _descriptor(entry: Any) -> ManifestFile:
    if (
        not isinstance(entry, dict)
        or not isinstance(entry.get("path"), str)
        or not isinstance(entry.get("size_bytes"), int)
        or isinstance(entry.get("size_bytes"), bool)
        or entry["size_bytes"] < 0
        or not isinstance(entry.get("sha256"), str)
        or not RAW_SHA256_RE.match(entry["sha256"])
    ):
        raise NetworkError("Meshia returned an invalid Fabric file descriptor.")
    return ManifestFile(path=entry["path"], size_bytes=entry["size_bytes"], sha256=entry["sha256"])
