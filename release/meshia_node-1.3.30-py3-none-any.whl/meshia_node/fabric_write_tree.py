"""Durable byte edits over an immutable Fabric file tree.

The journal owns changed data and index nodes. Unchanged objects remain in the
original CAS layout and are read through the caller's immutable source lease.
SQLite commits the new root with its objects, so reopening never mistakes a
sparse local inode for a complete file. Publication snapshots retain their root
while subsequent writes continue, and release reclaims superseded local bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import stat
import threading
import uuid
from pathlib import Path
from typing import Callable, Iterator
from urllib.parse import quote

from .fabric_contract_generated import (
    DataRange, FileTree, Node, decode_node, block_file_identity_bytes, parse_file_tree_descriptor,
    FABRIC_BASE_BLOCK_BYTES, FABRIC_FILE_TREE_ALGORITHM,
    FABRIC_FILE_TREE_PAGE_BYTES, FABRIC_V2_MAX_FILE_BYTES, FABRIC_CAS_PATH_PREFIX_BY_STORAGE_KIND,
    FABRIC_FILE_TREE_MAX_HEIGHT,
)

_PAGE = FABRIC_FILE_TREE_PAGE_BYTES
_MAX_WRITE = FABRIC_BASE_BLOCK_BYTES
_SCHEMA = """
CREATE TABLE properties (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE objects (
  kind TEXT NOT NULL CHECK(kind IN ('data','node')),
  digest TEXT NOT NULL, size INTEGER NOT NULL, height INTEGER NOT NULL,
  data BLOB NOT NULL, page_hashes BLOB NOT NULL,
  refs INTEGER NOT NULL CHECK(refs >= 0),
  PRIMARY KEY(kind,digest), CHECK(length(data)=size),
  CHECK(length(page_hashes)=((size+4095)/4096)*32));
CREATE TABLE edges (
  parent TEXT NOT NULL, kind TEXT NOT NULL, digest TEXT NOT NULL,
  PRIMARY KEY(parent,kind,digest));
CREATE INDEX edge_child ON edges(kind,digest);
CREATE INDEX dead_objects ON objects(size,kind,digest) WHERE refs=0;
CREATE TABLE roots (
  name TEXT PRIMARY KEY, descriptor TEXT NOT NULL,
  kind TEXT, digest TEXT, height INTEGER NOT NULL);
CREATE TABLE source_nodes (digest TEXT PRIMARY KEY, data BLOB NOT NULL CHECK(length(data)<=4096));
CREATE TABLE source_edges (
  kind TEXT NOT NULL, digest TEXT NOT NULL, size INTEGER NOT NULL,
  parent TEXT NOT NULL, PRIMARY KEY(kind,digest,size));
CREATE TABLE snapshot_objects (
  snapshot TEXT NOT NULL, kind TEXT NOT NULL, digest TEXT NOT NULL, ordinal INTEGER NOT NULL,
  PRIMARY KEY(snapshot,kind,digest), UNIQUE(snapshot,ordinal));
CREATE TABLE snapshot_owners (snapshot TEXT PRIMARY KEY, owner TEXT NOT NULL, epoch TEXT NOT NULL);
CREATE TABLE snapshot_publications (snapshot TEXT PRIMARY KEY, object_count INTEGER NOT NULL);
"""


def _json(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _identity(ref):
    if ref is None:
        return None, None
    return ("node" if isinstance(ref, Node) else "data"), ref.sha256


def _validate_descriptor(descriptor):
    try:
        storage = descriptor.get("storage")
        if (not isinstance(storage, dict) or set(storage) != {"kind"}
                or not isinstance(storage["kind"], str)
                or storage["kind"] not in FABRIC_CAS_PATH_PREFIX_BY_STORAGE_KIND):
            raise ValueError("Invalid source object layout")
        if descriptor.get("file_digest_algorithm") == FABRIC_FILE_TREE_ALGORITHM:
            parse_file_tree_descriptor(descriptor)
        else:
            block_file_identity_bytes(descriptor)
    except (AttributeError, KeyError, TypeError, ValueError) as error:
        raise ValueError("The write journal source descriptor is invalid") from error


class FileTreeJournal:
    """One private, recoverable write session; no network or namespace authority.

    ``read_source`` must be bound to the original immutable file version and
    verify provider range receipts. The opaque ``identity`` binds recovery to
    the caller's workspace, path and write intent. It is never an access grant.
    """

    def __init__(self, path: Path, *, identity: str,
                 read_source: Callable[[str, str, int, int, int, tuple[bytes, ...]], bytes],
                 base: dict | None = None, create: bool = False, context: dict | None = None):
        if not isinstance(identity, str) or not 1 <= len(identity.encode()) <= 4096:
            raise ValueError("The write journal identity is invalid")
        if base is not None:
            _validate_descriptor(base)
        if context is not None and (not isinstance(context, dict) or len(_json(context).encode()) > 65536):
            raise ValueError("The journal recovery context is invalid")
        self.path = Path(path)
        self.identity = identity
        self._owner_epoch = uuid.uuid4().hex
        self._lock = threading.RLock()
        self._source = read_source
        self._read_provenance = None
        self._db = None
        parent = self.path.parent.lstat()
        if (not stat.S_ISDIR(parent.st_mode) or stat.S_ISLNK(parent.st_mode)
                or (os.name != "nt" and (parent.st_mode & 0o077
                    or parent.st_uid != os.getuid()))):
            raise ValueError("The write journal requires a private owned directory")
        if create:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY
                         | getattr(os, "O_NOFOLLOW", 0), 0o600)
            os.close(fd)
        before = self.path.lstat()
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or (os.name != "nt" and (before.st_mode & 0o077
                    or before.st_uid != os.getuid()))):
            raise ValueError("The write journal is not a private regular file")
        try:
            self._db = sqlite3.connect("file:" + quote(str(self.path.absolute())) + "?mode=rw",
                                       uri=True, isolation_level=None, check_same_thread=False)
            after = self.path.lstat()
            if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
                raise ValueError("The write journal changed while opening")
            self._db.execute("PRAGMA trusted_schema=OFF")
            if create:
                self._db.execute("PRAGMA page_size=4096")
                self._db.execute("PRAGMA auto_vacuum=INCREMENTAL")
            if not create:
                stored = dict(self._db.execute("SELECT key,value FROM properties WHERE key IN ('identity','schema')"))
                if stored.get("identity") != identity:
                    raise ValueError("The write journal belongs to another write intent")
                if stored.get("schema") != "3":
                    raise ValueError("The write journal schema is invalid")
            if self._db.execute("PRAGMA auto_vacuum").fetchone()[0] != 2:
                raise ValueError("The write journal does not support bounded reclamation")
            if self._db.execute("PRAGMA page_size").fetchone()[0] != _PAGE:
                raise ValueError("The write journal page size is invalid")
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=FULL")
            self._db.execute("PRAGMA temp_store=FILE")
            self._db.execute("PRAGMA cache_size=-2048")
            if create:
                self._db.executescript(_SCHEMA)
                self._db.execute("BEGIN IMMEDIATE")
                try:
                    self._db.execute("INSERT INTO properties VALUES ('identity',?)", (identity,))
                    self._db.execute("INSERT INTO properties VALUES ('schema','3')")
                    if context is not None:
                        # This precedes any remote hold acquisition. A failed
                        # or interrupted OPEN keeps enough identity to retire
                        # its non-expiring source hold after restart.
                        self._db.execute("INSERT INTO properties VALUES ('context',?)", (_json(context),))
                    original = (FileTree(0, None, **self._adapters()).descriptor()
                                if base is None else base)
                    self._storage = original["storage"]["kind"]
                    self._db.execute("INSERT INTO properties VALUES ('storage',?)", (self._storage,))
                    self._db.execute("INSERT INTO properties VALUES ('source',?)", (_json(original),))
                    self._source_descriptor = json.loads(_json(original))
                    if original.get("file_digest_algorithm") == FABRIC_FILE_TREE_ALGORITHM:
                        tree = FileTree.from_descriptor(original, **self._adapters())
                    else:
                        tree = FileTree.from_blocks(original, **self._adapters())
                    self._replace_root("base", tree)
                    self._replace_root("current", tree)
                    self._collect_unused()
                    self._db.execute("COMMIT")
                except BaseException:
                    self._rollback()
                    raise
            stored = self._db.execute("SELECT value FROM properties WHERE key='identity'").fetchone()
            if stored != (identity,):
                raise ValueError("The write journal belongs to another write intent")
            self._storage = self._db.execute("SELECT value FROM properties WHERE key='storage'").fetchone()[0]
            # Keep the original wire descriptor as well as the converted tree.
            # A flat-file source has a different digest from its tree index;
            # recovery must renew the original version's authority.
            source_descriptor = self.source_descriptor()
            self._source_descriptor = source_descriptor
            if base is not None and source_descriptor != base:
                raise ValueError("The write journal has a different immutable source")
            if context is not None and self.recovery_context() != context:
                raise ValueError("The write journal belongs to another recovery scope")
            self._tree("current")
            if create and os.name != "nt":
                # FULL protects the transaction; the directory entry also has
                # to survive a crash before a caller can acknowledge creation.
                parent_fd = os.open(self.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
                try:
                    os.fsync(parent_fd)
                finally:
                    os.close(parent_fd)
        except BaseException:
            self.close()
            raise

    def close(self) -> None:
        with self._lock:
            if self._db is not None:
                self._db.close()
                self._db = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _adapters(self):
        return dict(load_node=lambda digest, size: self._read_object("node", digest, size, 0, size),
                    read_object=lambda digest, size, start, count: self._read_object("data", digest, size, start, count),
                    put_object=self._put)

    def _rollback(self):
        # SQLite can already have rolled back after an IO or full-disk error.
        # Preserve that original failure instead of masking it with a second
        # "no transaction is active" exception.
        if self._db.in_transaction:
            self._db.execute("ROLLBACK")

    def _read_object(self, kind, digest, size, offset, count):
        row = self._db.execute("SELECT rowid,size FROM objects WHERE kind=? AND digest=?", (kind, digest)).fetchone()
        if row is not None:
            if row[1] != size or not 0 <= offset <= offset + count <= size:
                raise ValueError("The local write journal object failed verification")
            if not count:
                return b""
            # Incremental BLOB IO reads only the touched pages. SELECT data
            # would hydrate and hash a whole 4 MiB object for every tiny dirty
            # read, losing the demand-paging benefit inside the local journal.
            low = offset // _PAGE * _PAGE
            high = min(size, (offset + count + _PAGE - 1) // _PAGE * _PAGE)
            with self._db.blobopen("objects", "data", row[0], readonly=True) as blob:
                blob.seek(low)
                data = blob.read(high - low)
            if len(data) != high - low:
                raise ValueError("The local write journal object was truncated")
            if low == 0 and high == size:
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError("The local write journal object failed verification")
            else:
                pages = (len(data) + _PAGE - 1) // _PAGE
                with self._db.blobopen("objects", "page_hashes", row[0], readonly=True) as blob:
                    blob.seek(low // _PAGE * 32)
                    hashes = blob.read(pages * 32)
                if len(hashes) != pages * 32 or any(
                    hashlib.sha256(data[at:at + _PAGE]).digest() != hashes[index * 32:(index + 1) * 32]
                    for index, at in enumerate(range(0, len(data), _PAGE))
                ):
                    raise ValueError("The local write journal page failed verification")
            return data[offset - low:offset - low + count]
        ancestors = self._source_ancestry(kind, digest, size)
        cached = self._source_node(digest) if kind == "node" else None
        data = cached if cached is not None else self._source(kind, digest, size, offset, count, ancestors)
        if not isinstance(data, bytes) or len(data) != count:
            raise ValueError("The immutable write source returned an invalid range")
        if kind == "node":
            height = self._source_descriptor["tree"]["height"] - len(ancestors)
            if offset != 0 or count != size or hashlib.sha256(data).hexdigest() != digest:
                raise ValueError("The original source metadata changed identity")
            children = decode_node(data, height)
            # Store one anchored parent per immutable typed child. Full paths
            # per child multiply metadata by tree depth; parent links retain
            # only nodes actually touched while building this journal.
            edges = tuple(
                (*_identity(child), child.size if isinstance(child, Node) else child.object_size, digest)
                for child in children if child is not None)
            if self._read_provenance is not None:
                nodes, parents = self._read_provenance
                nodes[digest] = data
                for child_kind, child_digest, child_size, parent in edges:
                    parents.setdefault((child_kind, child_digest, child_size), parent)
            else:
                self._db.execute("INSERT OR IGNORE INTO source_nodes VALUES (?,?)", (digest, data))
                self._db.executemany("INSERT OR IGNORE INTO source_edges VALUES (?,?,?,?)", edges)
        return data

    def _source_node(self, digest):
        if self._read_provenance is not None and digest in self._read_provenance[0]:
            return self._read_provenance[0][digest]
        row = self._db.execute("SELECT data FROM source_nodes WHERE digest=?", (digest,)).fetchone()
        return row[0] if row is not None else None

    def _source_ancestry(self, kind, digest, size):
        descriptor = self._source_descriptor
        if descriptor.get("file_digest_algorithm") != FABRIC_FILE_TREE_ALGORITHM:
            if kind != "data" or not any(block["sha256"] == digest and block["size_bytes"] == size
                                         for block in descriptor["blocks"]):
                raise ValueError("The journal requested an object outside its original flat source")
            return ()
        _, root = parse_file_tree_descriptor(descriptor)
        if root is None:
            raise ValueError("The empty source cannot authorize remote objects")
        def identity(ref):
            return (*_identity(ref), ref.size if isinstance(ref, Node) else ref.object_size)
        target = (kind, digest, size)
        root_identity = identity(root)
        nodes = []
        for _ in range(FABRIC_FILE_TREE_MAX_HEIGHT + 1):
            if target == root_identity:
                break
            parent = self._read_provenance[1].get(target) if self._read_provenance is not None else None
            if parent is None:
                row = self._db.execute("SELECT parent FROM source_edges WHERE kind=? AND digest=? AND size=?", target).fetchone()
                parent = row[0] if row is not None else None
            data = self._source_node(parent) if parent is not None else None
            if data is None or len(data) > _PAGE or hashlib.sha256(data).hexdigest() != parent:
                raise ValueError("The journal lost its original source ancestry")
            nodes.append(data)
            target = ("node", parent, len(data))
        else:
            raise ValueError("The source ancestry exceeds the tree height bound")
        ancestors = tuple(reversed(nodes))
        # Revalidate every typed edge against bytes anchored in the original
        # descriptor. SQL parent pointers alone are never read authority.
        ref, height = root, descriptor["tree"]["height"]
        for index, data in enumerate(ancestors):
            if not isinstance(ref, Node) or identity(ref) != ("node", hashlib.sha256(data).hexdigest(), len(data)):
                raise ValueError("The original source ancestry changed identity")
            children = decode_node(data, height)
            wanted = (("node", hashlib.sha256(ancestors[index + 1]).hexdigest(), len(ancestors[index + 1]))
                      if index + 1 < len(ancestors) else (kind, digest, size))
            ref = next((child for child in children if child is not None and identity(child) == wanted), None)
            if ref is None:
                raise ValueError("The original source ancestry lost its child")
            height -= 1
        if identity(ref) != (kind, digest, size):
            raise ValueError("The source ancestry does not authorize this object")
        return ancestors

    def _put(self, kind, data):
        if kind not in {"data", "node"} or not isinstance(data, bytes):
            raise ValueError("Invalid write journal object")
        if not 0 < len(data) <= (_PAGE if kind == "node" else _MAX_WRITE):
            raise ValueError("The write journal object exceeds its byte bound")
        height = data[4] if kind == "node" and len(data) > 4 else 0
        children = decode_node(data, height) if kind == "node" else ()
        digest = hashlib.sha256(data).hexdigest()
        previous = self._db.execute("SELECT size,data FROM objects WHERE kind=? AND digest=?", (kind, digest)).fetchone()
        if previous is not None:
            if previous != (len(data), data):
                raise ValueError("Conflicting immutable write journal object")
            return digest
        refs = self._db.execute("SELECT (SELECT count(*) FROM edges WHERE kind=? AND digest=?) + "
                                "(SELECT count(*) FROM roots WHERE kind=? AND digest=?)",
                                (kind, digest, kind, digest)).fetchone()[0]
        view = memoryview(data)
        page_hashes = b"".join(hashlib.sha256(view[at:at + _PAGE]).digest()
                               for at in range(0, len(data), _PAGE))
        self._db.execute("INSERT INTO objects VALUES (?,?,?,?,?,?,?)",
                         (kind, digest, len(data), height, data, page_hashes, refs))
        for child_kind, child_digest in {_identity(child) for child in children if child is not None}:
            self._db.execute("INSERT INTO edges VALUES (?,?,?)", (digest, child_kind, child_digest))
            self._db.execute("UPDATE objects SET refs=refs+1 WHERE kind=? AND digest=?", (child_kind, child_digest))
        return digest

    def _tree(self, name):
        row = self._db.execute("SELECT descriptor,kind,digest,height FROM roots WHERE name=?", (name,)).fetchone()
        if row is None:
            raise ValueError("The write journal snapshot is unavailable")
        descriptor = json.loads(row[0])
        tree = FileTree.from_descriptor(descriptor, **self._adapters())
        if descriptor["storage"]["kind"] != self._storage or (*_identity(tree.root), tree.height) != row[1:]:
            raise ValueError("The write journal root changed identity")
        return tree

    def _replace_root(self, name, tree):
        old = self._db.execute("SELECT kind,digest FROM roots WHERE name=?", (name,)).fetchone()
        kind, digest = _identity(tree.root)
        self._db.execute("INSERT INTO roots VALUES (?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET "
                         "descriptor=excluded.descriptor,kind=excluded.kind,digest=excluded.digest,height=excluded.height",
                         (name, _json(tree.descriptor(self._storage)), kind, digest, tree.height))
        if old is not None:
            self._db.execute("UPDATE objects SET refs=refs-1 WHERE kind=? AND digest=?", old)
        self._db.execute("UPDATE objects SET refs=refs+1 WHERE kind=? AND digest=?", (kind, digest))

    def _collect_unused(self):
        # A truncate can detach an arbitrarily large dirty tree. Retire at
        # most one bounded batch here; maintenance continues the same graph.
        # Otherwise one small syscall can create a file-sized WAL transaction.
        remaining, payload = 64, _MAX_WRITE
        while remaining:
            rows = self._db.execute("SELECT kind,digest,size FROM objects WHERE refs=0 "
                "AND size<=? ORDER BY size,kind,digest LIMIT ?", (payload, remaining)).fetchall()
            if not rows:
                return
            for kind, digest, size in rows:
                if size > payload:
                    return
                if kind == "node":
                    for child in self._db.execute("SELECT kind,digest FROM edges WHERE parent=?", (digest,)).fetchall():
                        self._db.execute("UPDATE objects SET refs=refs-1 WHERE kind=? AND digest=?", child)
                    self._db.execute("DELETE FROM edges WHERE parent=?", (digest,))
                self._db.execute("DELETE FROM objects WHERE kind=? AND digest=? AND refs=0", (kind, digest))
                remaining -= 1
                payload -= size

    def _change(self, transform):
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                if self.retirement_started():
                    raise ValueError("The write journal is retiring its source")
                tree = transform(self._tree("current"))
                self._replace_root("current", tree)
                self._collect_unused()
                self._db.execute("COMMIT")
            except BaseException:
                self._rollback()
                raise

    def descriptor(self, snapshot="current") -> dict:
        with self._lock:
            return self._tree(snapshot).descriptor(self._storage)

    def digest(self, snapshot="current") -> str:
        with self._lock:
            return self._tree(snapshot).digest

    def recovery_context(self) -> dict | None:
        with self._lock:
            row = self._db.execute("SELECT value FROM properties WHERE key='context'").fetchone()
            return json.loads(row[0]) if row is not None else None

    def retirement_started(self) -> bool:
        with self._lock:
            return self._db.execute("SELECT value FROM properties WHERE key='retiring'").fetchone() == ("1",)

    def begin_retirement(self) -> bool:
        """Persist source-hold cleanup debt only after the last retained root."""
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                if self._db.execute("SELECT 1 FROM roots WHERE name LIKE 'snapshot:%' LIMIT 1").fetchone():
                    self._db.execute("ROLLBACK")
                    return False
                self._db.execute("INSERT OR REPLACE INTO properties VALUES ('retiring','1')")
                self._db.execute("COMMIT")
                return True
            except BaseException:
                self._rollback()
                raise

    def snapshot_owners(self, *, after: str = "", limit: int = 256, previous_only: bool = False):
        if type(limit) is not int or not 1 <= limit <= 256:
            raise ValueError("Snapshot recovery requires a bounded page")
        with self._lock:
            return self._db.execute("SELECT r.name,o.owner,r.descriptor FROM roots r "
                "LEFT JOIN snapshot_owners o ON o.snapshot=r.name "
                "WHERE r.name LIKE 'snapshot:%' AND r.name>? AND (?=0 OR o.epoch IS NULL OR o.epoch<>?) "
                "ORDER BY r.name LIMIT ?", (after, int(previous_only), self._owner_epoch, limit)).fetchall()

    def snapshot_owner(self, snapshot):
        with self._lock:
            row = self._db.execute("SELECT owner FROM snapshot_owners WHERE snapshot=?", (snapshot,)).fetchone()
            return row[0] if row is not None else None

    def source_descriptor(self) -> dict:
        with self._lock:
            row = self._db.execute("SELECT value FROM properties WHERE key='source'").fetchone()
            if row is None:
                raise ValueError("The write journal lost its immutable source")
            descriptor = json.loads(row[0])
            _validate_descriptor(descriptor)
            if descriptor["storage"]["kind"] != self._storage:
                raise ValueError("The write journal source changed object layout")
            return descriptor

    def read(self, offset: int, count: int, *, snapshot="current") -> bytes:
        with self._lock:
            # Recovery/publication can open a second connection. Pin this SQL
            # read version so its root and object bytes cannot straddle a
            # concurrent root replacement and garbage collection.
            self._db.execute("BEGIN")
            # Read traversal must not upgrade its pinned snapshot to a SQL
            # writer while a second connection publishes a new journal root.
            # Ephemeral ancestry is bounded by this one range; writes persist
            # the original ancestors in the same transaction as their edits.
            self._read_provenance = ({}, {})
            try:
                return self._tree(snapshot).read(offset, count)
            finally:
                self._read_provenance = None
                self._rollback()

    def write(self, offset: int, data: bytes) -> int:
        if (type(offset) is not int or offset < 0 or not isinstance(data, bytes)
                or len(data) > _MAX_WRITE or offset + len(data) > FABRIC_V2_MAX_FILE_BYTES):
            raise ValueError("The write requires a bounded file range")
        if not data:
            return 0
        def edit(tree):
            end = offset + len(data)
            tree = tree.truncate(max(tree.size, end))
            low = offset // _PAGE * _PAGE
            high = min(tree.size, (end + _PAGE - 1) // _PAGE * _PAGE)
            if low < offset and end < high and high - low <= _PAGE:
                # One small edit needs both sides of the same page. Fetch
                # that page once instead of paying two serialized source
                # requests to avoid downloading a few overwritten bytes.
                previous = tree.read(low, high - low)
                content = previous[:offset - low] + data + previous[end - low:]
            else:
                content = tree.read(low, offset - low) + data + tree.read(end, high - end)
            for at in range(0, len(content), _MAX_WRITE):
                part = content[at:at + _MAX_WRITE]
                digest = self._put("data", part)
                tree = tree.replace_pages(low + at, DataRange(digest, len(part), 0, len(part)))
            return tree
        self._change(edit)
        return len(data)

    def truncate(self, size: int) -> None:
        if type(size) is not int or not 0 <= size <= FABRIC_V2_MAX_FILE_BYTES:
            raise ValueError("The truncate size is invalid")
        self._change(lambda tree: tree.truncate(size))

    def retain(self, snapshot: str = "current", *, owner: str | None = None, publication: bool = True) -> str:
        """Give a caller independent ownership of an exact existing root."""
        if owner is not None and (not isinstance(owner, str)
                or re.fullmatch(r"(?:mount|upload|reader):[a-f0-9-]{32,36}", owner) is None):
            raise ValueError("The retained snapshot owner is invalid")
        name = "snapshot:" + uuid.uuid4().hex
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                if self.retirement_started():
                    raise ValueError("The write journal is retiring its source")
                self._replace_root(name, self._tree(snapshot))
                if publication:
                    self._db.execute("""WITH RECURSIVE reachable(kind,digest) AS (
                        SELECT kind,digest FROM roots WHERE name=?
                        UNION SELECT edge.kind,edge.digest FROM reachable r
                        JOIN edges edge ON r.kind='node' AND edge.parent=r.digest)
                        INSERT INTO snapshot_objects SELECT ?,o.kind,o.digest,
                            row_number() OVER (ORDER BY o.height,o.digest)-1 FROM reachable r
                        JOIN objects o ON o.kind=r.kind AND o.digest=r.digest""", (name, name))
                    count = self._db.execute("SELECT changes()").fetchone()[0]
                    self._db.execute("INSERT INTO snapshot_publications VALUES (?,?)", (name, count))
                if owner is not None:
                    self._db.execute("INSERT INTO snapshot_owners VALUES (?,?,?)", (name, owner, self._owner_epoch))
                self._db.execute("COMMIT")
            except BaseException:
                self._rollback()
                raise
        return name

    def release(self, snapshot: str) -> bool:
        if not isinstance(snapshot, str) or re.fullmatch(r"snapshot:[a-f0-9]{32}", snapshot) is None:
            raise ValueError("Only retained write snapshots can be released")
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                row = self._db.execute("DELETE FROM roots WHERE name=? RETURNING kind,digest", (snapshot,)).fetchone()
                if row is None:
                    self._db.execute("COMMIT")
                    return False
                self._db.execute("DELETE FROM snapshot_objects WHERE snapshot=?", (snapshot,))
                self._db.execute("DELETE FROM snapshot_owners WHERE snapshot=?", (snapshot,))
                self._db.execute("DELETE FROM snapshot_publications WHERE snapshot=?", (snapshot,))
                self._db.execute("UPDATE objects SET refs=refs-1 WHERE kind=? AND digest=?", row)
                self._collect_unused()
                self._db.execute("COMMIT")
                return True
            except BaseException:
                self._rollback()
                raise

    def object_index(self, snapshot: str) -> Iterator[tuple[str, str, int]]:
        """Stream the frozen publication frontier without reading payload.

        Reachability is captured transactionally at retain, with SQLite's
        bounded disk-backed temporary store. Upload workers can then prove
        membership by an indexed lookup instead of walking the tree per block.
        """
        if not isinstance(snapshot, str) or not snapshot.startswith("snapshot:"):
            raise ValueError("Publication requires a retained write snapshot")
        with self._lock:
            self._tree(snapshot)
            cursor = self._db.execute("""SELECT o.kind,o.digest,o.size FROM snapshot_objects s
                JOIN objects o ON o.kind=s.kind AND o.digest=s.digest
                WHERE s.snapshot=? ORDER BY s.ordinal""", (snapshot,))
        try:
            while True:
                with self._lock:
                    self._tree(snapshot)  # A released capture may not keep reading.
                    row = cursor.fetchone()
                    if row is None:
                        return
                yield row
        finally:
            with self._lock:
                if self._db is not None:
                    cursor.close()

    def publication_page(self, snapshot: str, *, start: int = 0, limit: int = 256):
        """Read a bounded, indexed child-before-parent upload window."""
        if type(start) is not int or start < 0 or type(limit) is not int or not 1 <= limit <= 8192:
            raise ValueError("The publication page is outside its bounded index")
        with self._lock:
            self._tree(snapshot)
            row = self._db.execute("SELECT object_count FROM snapshot_publications WHERE snapshot=?", (snapshot,)).fetchone()
            if row is None:
                raise ValueError("The snapshot has no retained publication index")
            count = row[0]
            rows = self._db.execute("""SELECT o.kind,o.digest,o.size FROM snapshot_objects s
                JOIN objects o ON o.kind=s.kind AND o.digest=s.digest
                WHERE s.snapshot=? AND s.ordinal>=? ORDER BY s.ordinal LIMIT ?""", (snapshot, start, limit)).fetchall()
            return count, rows

    def read_publication_object(self, snapshot: str, kind: str, digest: str, size: int) -> bytes:
        with self._lock:
            self._db.execute("BEGIN")
            try:
                self._tree(snapshot)
                row = self._db.execute("""SELECT o.size FROM snapshot_objects s JOIN objects o
                    ON o.kind=s.kind AND o.digest=s.digest
                    WHERE s.snapshot=? AND s.kind=? AND s.digest=?""", (snapshot, kind, digest)).fetchone()
                if row != (size,):
                    raise ValueError("The object does not belong to the retained publication")
                return self._read_object(kind, digest, size, 0, size)
            finally:
                self._rollback()

    def objects(self, snapshot: str) -> Iterator[tuple[str, str, bytes]]:
        """Yield retained objects in child-before-parent order, one at a time."""
        for kind, digest, size in self.object_index(snapshot):
            yield kind, digest, self.read_publication_object(snapshot, kind, digest, size)

    def local_bytes(self) -> int:
        """Live object payload bytes; excludes SQLite and page-hash overhead."""
        with self._lock:
            return self._db.execute("SELECT coalesce(sum(size),0) FROM objects").fetchone()[0]

    def reclaim(self, *, max_pages: int = 256) -> int:
        """Reclaim a bounded batch of free database pages in one maintenance step.

        This never scans live payload or downloads source bytes. A pinned SQL
        reader can defer the WAL truncation; the caller must observe physical
        files before reducing its reservation. The caller also withdraws any
        allocation credit before invoking this method. Busy readers/writers
        cause an immediate bounded deferral, not a foreground write stall.
        """
        if type(max_pages) is not int or not 1 <= max_pages <= 256:
            raise ValueError("Journal reclamation requires 1 through 256 pages")
        with self._lock:
            timeout = self._db.execute("PRAGMA busy_timeout").fetchone()[0]
            self._db.execute("PRAGMA busy_timeout=0")
            try:
                self._db.execute("BEGIN IMMEDIATE")
                self._collect_unused()
                before = self._db.execute("PRAGMA page_count").fetchone()[0]
                # Consuming all rows matters: SQLite vacuums one page per step.
                self._db.execute(f"PRAGMA incremental_vacuum({max_pages})").fetchall()
                after = self._db.execute("PRAGMA page_count").fetchone()[0]
                self._db.execute("COMMIT")
                self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
                return before - after
            except sqlite3.OperationalError as error:
                self._rollback()
                if error.sqlite_errorcode in {sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED}:
                    return 0
                raise
            except BaseException:
                self._rollback()
                raise
            finally:
                self._db.execute(f"PRAGMA busy_timeout={int(timeout)}")
