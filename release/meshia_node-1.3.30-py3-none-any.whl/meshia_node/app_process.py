"""Authenticate an app connection against its live native command ownership.

Ports and saved PIDs are not authority. The connected server socket must belong
to a process in the retained command scope. This module never signals processes;
the executor's existing native supervision remains responsible for cancellation.
"""
from __future__ import annotations

import ctypes
import json
import math
import os
from pathlib import Path
import select
import socket
import struct
import sys
import threading
import time

from .errors import AccessRefused


def _refused() -> AccessRefused:
    return AccessRefused("The app connection could not be authenticated to its running command.")


class _PendingSocket(AccessRefused):
    """connect completed, but no accepted owned socket is visible yet."""


def _linux_identity(pid: int) -> tuple[int, int] | None:
    try:
        value = Path(f"/proc/{pid}/stat").read_text()
        fields = value[value.rindex(")") + 2:].split()
        if fields[0] in ("Z", "X"):
            return None
        return int(fields[1]), int(fields[19])  # parent PID, kernel start time
    except (OSError, ValueError, IndexError):
        return None


def _linux_inodes(server: tuple, client: tuple) -> set[str]:
    def address(value):
        return socket.inet_ntoa(bytes.fromhex(value)[::-1])
    matches = set()
    with open("/proc/net/tcp", encoding="ascii") as stream:
        for index, line in enumerate(stream):
            if index > 65536:
                raise _refused()
            fields = line.split()
            if index == 0 or len(fields) < 10 or fields[3] != "01":
                continue
            local, local_port = fields[1].split(":")
            remote, remote_port = fields[2].split(":")
            if ((address(local), int(local_port, 16)) == server
                    and (address(remote), int(remote_port, 16)) == client
                    and fields[9] != "0"):
                matches.add(fields[9])
    return matches


def _lsof_pids(output: bytes, server: tuple, client: tuple) -> set[int]:
    """Parse system lsof's NUL field format; names cannot affect record framing."""
    expected = f"{server[0]}:{server[1]}->{client[0]}:{client[1]}".encode()
    pid, matched, established = None, False, False
    result = set()
    for field in output.split(b"\0"):
        field = field.lstrip(b"\n")
        if field[:1] in (b"p", b"f"):
            if pid is not None and matched and established:
                result.add(pid)
            matched, established = False, False
        if field.startswith(b"p"):
            pid = int(field[1:])
        elif field.startswith(b"n"):
            matched = field[1:] == expected
        elif field == b"TST=ESTABLISHED":
            established = True
    if pid is not None and matched and established:
        result.add(pid)
    return result


class _TcpRow(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint32) for name in
                ("state", "local_address", "local_port", "remote_address", "remote_port", "pid")]


def _windows_pids(server: tuple, client: tuple) -> set[int]:
    table = ctypes.WinDLL("iphlpapi", use_last_error=True).GetExtendedTcpTable
    table.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32), ctypes.c_int,
                      ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
    table.restype = ctypes.c_uint32
    size = ctypes.c_uint32()
    # TCP_TABLE_OWNER_PID_ALL (5), IPv4. Retry only buffer sizing, never a mutation.
    for _ in range(3):
        if size.value > 4 * 1024 * 1024:
            raise _refused()
        buffer = ctypes.create_string_buffer(size.value) if size.value else None
        status = table(buffer, ctypes.byref(size), False, socket.AF_INET, 5, 0)
        if status == 122:
            continue
        if status or buffer is None or size.value < 4 or size.value > ctypes.sizeof(buffer):
            raise _refused()
        count = struct.unpack_from("=I", buffer.raw)[0]
        if 4 + count * ctypes.sizeof(_TcpRow) > size.value:
            raise _refused()
        result = set()
        for index in range(count):
            row = _TcpRow.from_buffer_copy(buffer, 4 + index * ctypes.sizeof(_TcpRow))
            local = (socket.inet_ntoa(struct.pack("=I", row.local_address)),
                     socket.ntohs(row.local_port & 65535))
            remote = (socket.inet_ntoa(struct.pack("=I", row.remote_address)),
                      socket.ntohs(row.remote_port & 65535))
            if row.state == 5 and local == server and remote == client:
                result.add(row.pid)
        return result
    raise _refused()


class AppProcessOwner:
    """One in-memory, single-use ownership scope for one executor invocation."""

    def __init__(self):
        self._lock = threading.RLock()
        self._closed = False
        self._process = None
        self._root = None
        self._job = None
        self._read_fd = self._write_fd = None
        self._mac_leader = None
        self._kernel = None
        self._windows_workspace = None
        self._connections = {}

    def prepare_native(self, *, root=None, access="full") -> int | None:
        """Capture private launch scope; macOS also reserves its report pipe."""
        with self._lock:
            if self._closed or self._process is not None:
                raise _refused()
            if sys.platform == "win32" and access == "limited":
                if not isinstance(root, str) or not root:
                    raise _refused()
                # Captured by the trusted executor after obtaining this exact
                # app's filesystem lease, never from registry or HTTP arguments.
                self._windows_workspace = root
            if sys.platform != "darwin":
                return None
            if self._read_fd is not None:
                raise _refused()
            self._read_fd, self._write_fd = os.pipe()
            return self._write_fd

    def on_started(self, process, *, job_handle=None) -> None:
        with self._lock:
            if self._closed or self._process is not None:
                raise _refused()
            self._process = process
            if self._write_fd is not None:
                os.close(self._write_fd)
                self._write_fd = None
            if sys.platform == "linux":
                self._root = _linux_identity(process.pid)
                if self._root is None:
                    raise _refused()
            elif sys.platform == "win32":
                if not job_handle:
                    raise _refused()
                # Borrowed, not duplicated: executor closes this owner under the
                # same lock before retiring its kill-on-close Job handle.
                self._job = job_handle
            elif sys.platform == "darwin":
                if self._read_fd is None:
                    raise _refused()
                from .macos_native import Kernel
                self._kernel = Kernel()
            else:
                raise _refused()

    def close(self) -> None:
        with self._lock:
            self._closed = True
            self._job = None
            connections, self._connections = list(self._connections.values()), {}
            for name in ("_read_fd", "_write_fd"):
                descriptor = getattr(self, name)
                if descriptor is not None:
                    os.close(descriptor)
                    setattr(self, name, None)
        for connection in connections:
            connection.close()

    def connect(self, port: int, *, deadline: float, check=None) -> socket.socket:
        """Open only this app's IPv4 connection; retain restricted relay lifetime."""
        if (type(port) is not int or not 9000 <= port <= 9099
                or type(deadline) not in (int, float) or not math.isfinite(deadline)):
            raise _refused()
        if check is not None:
            check()
        with self._lock:
            if self._closed or self._process is None or time.monotonic() >= deadline:
                raise _refused()
            root = self._windows_workspace
        if sys.platform != "win32" or root is None:
            return socket.create_connection(("127.0.0.1", port), timeout=deadline-time.monotonic())
        from .windows_app_socket import WindowsAppConnection
        connection = WindowsAppConnection(self, root, port)
        with self._lock:
            if self._closed:
                connection.close()
                raise _refused()
            self._connections[id(connection.socket)] = connection
        try:
            connection.start(deadline=deadline, check=check)
            return connection.socket
        except BaseException:
            connection.close()
            raise

    def _retire_connection(self, connection) -> None:
        with self._lock:
            if self._connections.get(id(connection.socket)) is connection:
                self._connections.pop(id(connection.socket))

    def verify_connection(self, connection: socket.socket, port: int, *, deadline: float, check=None) -> None:
        """Verify an already-connected IPv4 loopback socket before sending HTTP."""
        if type(deadline) not in (int, float) or not math.isfinite(deadline):
            raise _refused()
        with self._lock:
            relay = self._connections.get(id(connection))
        if relay is not None:
            if port != relay.port:
                raise _refused()
            relay.verify(deadline=deadline, check=check)
            return
        try:
            server, client = connection.getpeername(), connection.getsockname()
        except Exception as error:
            raise _refused() from error

        def live():
            if (self._closed or self._process is None or time.monotonic() >= deadline
                    or connection.family != socket.AF_INET
                    or server != ("127.0.0.1", port) or client[0] != "127.0.0.1"
                    or connection.getsockopt(socket.SOL_SOCKET, socket.SO_TYPE) != socket.SOCK_STREAM
                    or connection.getpeername() != server or connection.getsockname() != client
                    or sys.platform != "win32" and self._process.poll() is not None):
                raise _refused()

        while True:
            # Never hold the owner lock while consulting the caller's authority
            # or sleeping: revocation must be able to close this retained owner.
            if check is not None:
                check()
            try:
                with self._lock:
                    live()
                    if sys.platform == "linux":
                        self._verify_linux(server, client, deadline)
                    elif sys.platform == "win32":
                        self._verify_windows(server, client)
                    elif sys.platform == "darwin":
                        self._verify_macos(server, client, deadline)
                    else:
                        raise _refused()
                    live()
            except _PendingSocket:
                # An exact accepted FD is still mandatory. Only its visibility
                # may wait, inside the caller's existing request/startup budget.
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise _refused() from None
                time.sleep(min(.01, remaining))
                continue
            except AccessRefused:
                raise
            except Exception as error:
                raise _refused() from error
            if check is not None:
                check()
            with self._lock:
                try:
                    live()
                except Exception as error:
                    raise _refused() from error
            return

    def _verify_linux(self, server, client, deadline) -> None:
        root_pid = self._process.pid
        if _linux_identity(root_pid) != self._root:
            raise _refused()
        inodes = _linux_inodes(server, client)
        if not inodes:
            raise _PendingSocket()
        deadline = min(deadline, time.monotonic() + 2)
        identities = {}
        with os.scandir("/proc") as entries:
            for index, entry in enumerate(entries):
                if index > 65536 or time.monotonic() > deadline:
                    raise _refused()
                if entry.name.isdigit():
                    pid = int(entry.name)
                    identity = _linux_identity(pid)
                    if identity is not None:
                        identities[pid] = identity
        if identities.get(root_pid) != self._root:
            raise _refused()
        for pid in identities:
            lineage = []
            current = pid
            while current in identities and current not in lineage and len(lineage) < 1024:
                lineage.append(current)
                if current == root_pid:
                    break
                current = identities[current][0]
            if not lineage or lineage[-1] != root_pid:
                continue
            try:
                with os.scandir(f"/proc/{pid}/fd") as descriptors:
                    for index, descriptor in enumerate(descriptors):
                        if index > 65536 or time.monotonic() > deadline:
                            raise _refused()
                        try:
                            target = os.readlink(descriptor.path)
                        except FileNotFoundError:
                            continue
                        if (target.startswith("socket:[") and target[8:-1] in inodes
                                and all(_linux_identity(item) == identities[item] for item in lineage)
                                and target[8:-1] in _linux_inodes(server, client)):
                            return
            except (FileNotFoundError, PermissionError):
                continue
        raise _refused()

    def _load_macos_scope(self, deadline) -> None:
        if self._mac_leader is not None:
            return
        if self._read_fd is None or not select.select([self._read_fd], [], [], max(0, min(2, deadline-time.monotonic())))[0]:
            raise _refused()
        report = os.read(self._read_fd, 1025)
        os.close(self._read_fd)
        self._read_fd = None
        if len(report) > 1024 or not report.endswith(b"\n"):
            raise _refused()
        values = json.loads(report)
        from .macos_native import Identity
        leader = Identity(values["pid"], values["unique"], values["version"], tuple(values["coalition"]))
        if (leader.pid <= 1 or not all(leader.coalition) or len(leader.coalition) != 2
                or leader.coalition == self._kernel.own.coalition
                or self._kernel.identity(leader.pid) != leader):
            raise _refused()
        self._mac_leader = leader

    def _verify_macos(self, server, client, deadline) -> None:
        self._load_macos_scope(deadline)
        leader = self._mac_leader
        if self._kernel.identity(leader.pid) != leader:
            raise _refused()
        members = self._kernel.members(leader.coalition)
        if not members or len(members) > 4096:
            raise _refused()
        remaining = min(2, deadline - time.monotonic())
        if remaining <= 0:
            raise _refused()
        # Fixed system binary and numeric arguments. -F0 emits NUL-delimited
        # socket fields; -a intersects PID, TCP port and established state.
        from .executor import native_environment, run_bounded_subprocess
        output, code, truncated, timed_out = run_bounded_subprocess(
            ["/usr/sbin/lsof", "-nP", "-a", "-p", ",".join(str(item.pid) for item in members),
             f"-iTCP:{server[1]}", "-sTCP:ESTABLISHED", "-F0pfnT"],
            cwd="/", env=native_environment(), timeout_seconds=remaining, max_output_bytes=262144)
        # lsof also returns 1 when just one selected PID has disappeared. Its
        # complete output can still prove this exact socket belongs to a live
        # member. Keep that socket and both identity checks below authoritative;
        # missing matches, incomplete output and abnormal exits still fail.
        if code not in (0, 1) or truncated or timed_out:
            raise _refused()
        matches = _lsof_pids(output, server, client)
        if self._kernel.identity(leader.pid) != leader:
            raise _refused()
        if not matches:
            raise _PendingSocket()
        if any(item.pid in matches and self._kernel.identity(item.pid) == item for item in members):
            return
        raise _refused()

    def _verify_windows(self, server, client) -> None:
        if self._job is None:
            raise _refused()
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel.OpenProcess.restype = ctypes.c_void_p
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel.IsProcessInJob.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)]
        kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        kernel.WaitForSingleObject.restype = ctypes.c_uint32
        matches = _windows_pids(server, client)
        if not matches:
            raise _PendingSocket()
        for pid in matches:
            handle = kernel.OpenProcess(0x1000 | 0x100000, False, pid)
            if not handle:
                continue
            try:
                member = ctypes.c_int()
                # The open process handle pins the kernel object across PID reuse.
                # A live handle and a second exact TCP-table read exclude a stale
                # row becoming a foreign process with the same numerical PID.
                if (kernel.IsProcessInJob(handle, self._job, ctypes.byref(member)) and member.value
                        and kernel.WaitForSingleObject(handle, 0) == 258
                        and pid in _windows_pids(server, client)
                        and kernel.WaitForSingleObject(handle, 0) == 258):
                    return
            finally:
                kernel.CloseHandle(handle)
        raise _refused()
