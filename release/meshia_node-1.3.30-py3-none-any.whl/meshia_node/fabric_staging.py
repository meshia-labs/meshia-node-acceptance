"""Durable shared admission accounting for Fabric staging bytes.

Classic operation snapshots and incremental TransferStore jobs share one disk
budget.  Walking both namespaces for every new file makes a large dirty backlog
quadratic and still permits two processes to over-admit between their scans.
This ledger makes the steady-state decision one ``BEGIN IMMEDIATE`` transaction.

The filesystem remains authoritative after a crash.  Callers start a bounded
repair scan on process startup, observe at most 1,000 physical reservations per
step, then sweep stale rows in bounded pages.  New reservations fail closed
while that scan is incomplete; exact already-charged replays remain usable.
"""

from __future__ import annotations

import os
import re
import shutil
import sqlite3
import threading
import time
import uuid
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any


_SCHEMA_VERSION = 1
_MAX_OWNER_BYTES = 1_024
_MAX_KIND_BYTES = 64
_MAX_PAGE = 1_000
_MAX_ENTRIES = 250_000
_MAX_CONFIGURED_BYTES = 1 << 43  # keeps max_bytes * max_entries in int64
_KIND_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_LEGACY_DEFAULT_MIN_FREE_BYTES = 512 * 1024 * 1024
_LEGACY_DEFAULT_MIN_FREE_PPM = 50_000
_CURRENT_DEFAULT_MIN_FREE_PPM = 0


class StagingLedgerError(RuntimeError):
    """Base class for durable staging-accounting failures."""


class StagingRepairRequired(StagingLedgerError):
    """A physical namespace scan must finish before new admission."""


class StagingAdmissionExceeded(StagingLedgerError):
    """The shared byte, entry, or free-space budget would be exceeded."""


@dataclass(frozen=True)
class StagingReservation:
    owner_id: str
    kind: str
    size_bytes: int
    created_at_ns: int
    committed_bytes: int = 0


@dataclass(frozen=True)
class StagingLedgerStatus:
    reserved_bytes: int
    committed_bytes: int
    reservation_count: int
    max_bytes: int
    max_entries: int
    repair_required: bool
    repair_phase: str
    repair_id: str | None

    @property
    def outstanding_bytes(self) -> int:
        return max(0, self.reserved_bytes - self.committed_bytes)

    @property
    def over_capacity(self) -> bool:
        return (
            self.reserved_bytes > self.max_bytes
            or self.reservation_count > self.max_entries
        )


@dataclass(frozen=True)
class StagingRepairStep:
    status: StagingLedgerStatus
    removed: int
    complete: bool


def _owner(value: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or len(value.encode("utf-8")) > _MAX_OWNER_BYTES
        or any(ord(character) < 0x20 or ord(character) == 0x7F for character in value)
    ):
        raise ValueError("owner_id must be a bounded printable identifier")
    return value


def _kind(value: str) -> str:
    if (
        not isinstance(value, str)
        or len(value.encode("ascii", errors="ignore")) > _MAX_KIND_BYTES
        or _KIND_RE.fullmatch(value) is None
    ):
        raise ValueError("kind must be a bounded lowercase ASCII identifier")
    return value


def _size(value: int, *, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= maximum:
        raise ValueError("size_bytes is outside the staging ledger bound")
    return value


def _page_limit(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= _MAX_PAGE:
        raise ValueError(f"limit must be between 1 and {_MAX_PAGE}")
    return value


class StagingAdmissionLedger:
    """One cross-process byte/count authority for a staging root."""

    def __init__(
        self,
        path: Path | str,
        *,
        staging_root: Path | str,
        max_bytes: int,
        max_entries: int = _MAX_ENTRIES,
        min_free_bytes: int = 0,
        min_free_fraction: float = 0.0,
        disk_usage: Callable[[Path], Any] = shutil.disk_usage,
        now_ns: Callable[[], int] = time.time_ns,
    ) -> None:
        if (
            isinstance(max_bytes, bool)
            or not isinstance(max_bytes, int)
            or not 1 <= max_bytes <= _MAX_CONFIGURED_BYTES
        ):
            raise ValueError("max_bytes is outside the supported staging bound")
        if (
            isinstance(max_entries, bool)
            or not isinstance(max_entries, int)
            or not 1 <= max_entries <= _MAX_ENTRIES
        ):
            raise ValueError("max_entries is outside the supported staging bound")
        if (
            isinstance(min_free_bytes, bool)
            or not isinstance(min_free_bytes, int)
            or min_free_bytes < 0
            or not isinstance(min_free_fraction, (int, float))
            or isinstance(min_free_fraction, bool)
            or not 0 <= float(min_free_fraction) < 1
        ):
            raise ValueError("the staging free-space reserve is invalid")
        self.path = Path(path)
        self.staging_root = Path(staging_root)
        self.max_bytes = max_bytes
        self.max_entries = max_entries
        self.min_free_bytes = min_free_bytes
        self.min_free_ppm = round(float(min_free_fraction) * 1_000_000)
        self._disk_usage = disk_usage
        self._now_ns = now_ns
        self._lock = threading.RLock()
        self._closed = False

        self.staging_root.mkdir(parents=True, exist_ok=True)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(
            self.path,
            timeout=30,
            isolation_level=None,
            check_same_thread=False,
        )
        self._connection.row_factory = sqlite3.Row
        try:
            self._connection.execute("PRAGMA busy_timeout = 30000")
            self._connection.execute("PRAGMA journal_mode = WAL")
            self._connection.execute("PRAGMA synchronous = FULL")
            self._connection.execute("PRAGMA foreign_keys = ON")
            self._initialize()
            if os.name != "nt":
                os.chmod(self.path, 0o600)
        except BaseException:
            self._connection.close()
            raise

    def __enter__(self) -> "StagingAdmissionLedger":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def close(self) -> None:
        with self._lock:
            if not self._closed:
                self._connection.close()
                self._closed = True

    def _require_open(self) -> None:
        if self._closed:
            raise StagingLedgerError("the staging ledger is closed")

    def _initialize(self) -> None:
        with self._lock:
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS staging_meta (
                    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                    schema_version INTEGER NOT NULL,
                    reserved_bytes INTEGER NOT NULL CHECK (reserved_bytes >= 0),
                    committed_bytes INTEGER NOT NULL DEFAULT 0
                        CHECK (committed_bytes >= 0),
                    reservation_count INTEGER NOT NULL CHECK (reservation_count >= 0),
                    max_bytes INTEGER NOT NULL,
                    max_entries INTEGER NOT NULL,
                    min_free_bytes INTEGER NOT NULL,
                    min_free_ppm INTEGER NOT NULL,
                    repair_phase TEXT NOT NULL
                        CHECK (repair_phase IN ('required', 'scan', 'sweep', 'ready')),
                    repair_id TEXT,
                    repair_started_at_ns INTEGER,
                    repair_sweep_after TEXT
                );
                CREATE TABLE IF NOT EXISTS staging_reservations (
                    owner_id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL CHECK (size_bytes >= 0),
                    committed_bytes INTEGER NOT NULL DEFAULT 0
                        CHECK (committed_bytes >= 0),
                    created_at_ns INTEGER NOT NULL,
                    seen_repair_id TEXT
                ) WITHOUT ROWID;
                CREATE INDEX IF NOT EXISTS staging_repair_sweep
                    ON staging_reservations(seen_repair_id, owner_id);
                CREATE TABLE IF NOT EXISTS staging_kind_totals (
                    kind TEXT PRIMARY KEY,
                    reserved_bytes INTEGER NOT NULL CHECK (reserved_bytes >= 0),
                    reservation_count INTEGER NOT NULL CHECK (reservation_count >= 0)
                ) WITHOUT ROWID;
                """
            )
            # These additive columns deliberately retain schema_version=1. An
            # installer rollback can therefore reopen the ledger with the prior
            # runtime, which ignores the new columns, while upgraded processes
            # stop double-counting fsynced payload blocks against filesystem
            # ``free``. Existing reservations start conservatively at zero and
            # become precise at their next durable transfer checkpoint or
            # bounded startup repair observation.
            columns_added = False
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                meta_columns = {
                    str(row[1])
                    for row in self._connection.execute(
                        "PRAGMA table_info(staging_meta)"
                    ).fetchall()
                }
                if "committed_bytes" not in meta_columns:
                    self._connection.execute(
                        "ALTER TABLE staging_meta ADD COLUMN committed_bytes "
                        "INTEGER NOT NULL DEFAULT 0 CHECK(committed_bytes >= 0)"
                    )
                    columns_added = True
                reservation_columns = {
                    str(row[1])
                    for row in self._connection.execute(
                        "PRAGMA table_info(staging_reservations)"
                    ).fetchall()
                }
                if "committed_bytes" not in reservation_columns:
                    self._connection.execute(
                        "ALTER TABLE staging_reservations ADD COLUMN committed_bytes "
                        "INTEGER NOT NULL DEFAULT 0 CHECK(committed_bytes >= 0)"
                    )
                    columns_added = True
                self._connection.execute("COMMIT")
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
            self._connection.execute(
                """INSERT OR IGNORE INTO staging_meta(
                       singleton, schema_version, reserved_bytes, reservation_count,
                       max_bytes, max_entries, min_free_bytes, min_free_ppm,
                       repair_phase, repair_id, repair_started_at_ns
                   ) VALUES(1, ?, 0, 0, ?, ?, ?, ?, 'required', NULL, NULL)""",
                (
                    _SCHEMA_VERSION,
                    self.max_bytes,
                    self.max_entries,
                    self.min_free_bytes,
                    self.min_free_ppm,
                ),
            )
            row = self._meta_row()
            expected = (
                _SCHEMA_VERSION,
                self.max_bytes,
                self.max_entries,
                self.min_free_bytes,
                self.min_free_ppm,
            )
            observed = (
                int(row["schema_version"]),
                int(row["max_bytes"]),
                int(row["max_entries"]),
                int(row["min_free_bytes"]),
                int(row["min_free_ppm"]),
            )
            if observed != expected and not self._accept_legacy_default_reserve(
                observed=observed,
                expected=expected,
            ):
                raise StagingLedgerError(
                    "the staging ledger configuration does not match its durable authority"
                )
            # An older rollback binary legitimately ignores the additive
            # committed columns. Its delete/sweep or size-update DML can
            # therefore leave the aggregate stale. Detect that state before a
            # standalone caller can spend the false credit, but leave physical
            # namespace repair—not metadata guessing—to establish truth.
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                meta = self._meta_row()
                invalid = self._connection.execute(
                    "SELECT 1 FROM staging_reservations "
                    "WHERE committed_bytes < 0 OR committed_bytes > size_bytes LIMIT 1"
                ).fetchone()
                aggregate = int(
                    self._connection.execute(
                        "SELECT COALESCE(SUM(committed_bytes), 0) "
                        "FROM staging_reservations"
                    ).fetchone()[0]
                )
                inconsistent = (
                    invalid is not None
                    or aggregate != int(meta["committed_bytes"])
                    or aggregate > int(meta["reserved_bytes"])
                )
                if columns_added or inconsistent:
                    self._connection.execute(
                        """UPDATE staging_meta SET repair_phase = 'required',
                               repair_id = NULL, repair_started_at_ns = NULL,
                               repair_sweep_after = NULL WHERE singleton = 1"""
                    )
                self._connection.execute("COMMIT")
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise

    @staticmethod
    def _accept_legacy_default_reserve(
        *,
        observed: tuple[int, int, int, int, int],
        expected: tuple[int, int, int, int, int],
    ) -> bool:
        """Accept the one reviewed default-policy transition without mutation.

        Meshia 1.2.16 replaced the legacy 5%-of-volume staging reserve with the
        existing fixed 512 MiB cushion.  The ledger normally treats every
        configuration field as durable authority, so old installations need
        this exact compatibility view.  Keeping the stored policy unchanged
        lets the transactional installer still roll back to 1.2.15; this
        process uses its requested 0% policy for admission decisions.
        """

        (
            schema_version,
            max_bytes,
            max_entries,
            min_free_bytes,
            min_free_ppm,
        ) = observed
        (
            expected_schema,
            expected_max_bytes,
            expected_max_entries,
            expected_min_free_bytes,
            expected_min_free_ppm,
        ) = expected
        return (
            schema_version == expected_schema
            and max_bytes == expected_max_bytes
            and max_entries == expected_max_entries
            and min_free_bytes == _LEGACY_DEFAULT_MIN_FREE_BYTES
            and expected_min_free_bytes == _LEGACY_DEFAULT_MIN_FREE_BYTES
            and min_free_ppm == _LEGACY_DEFAULT_MIN_FREE_PPM
            and expected_min_free_ppm == _CURRENT_DEFAULT_MIN_FREE_PPM
        )

    def _meta_row(self) -> sqlite3.Row:
        row = self._connection.execute(
            "SELECT * FROM staging_meta WHERE singleton = 1"
        ).fetchone()
        if row is None:
            raise StagingLedgerError("the staging ledger metadata is missing")
        return row

    def _status_from_row(self, row: sqlite3.Row) -> StagingLedgerStatus:
        repair_id = row["repair_id"]
        return StagingLedgerStatus(
            reserved_bytes=int(row["reserved_bytes"]),
            committed_bytes=int(row["committed_bytes"]),
            reservation_count=int(row["reservation_count"]),
            max_bytes=int(row["max_bytes"]),
            max_entries=int(row["max_entries"]),
            repair_required=str(row["repair_phase"]) != "ready",
            repair_phase=str(row["repair_phase"]),
            repair_id=str(repair_id) if repair_id is not None else None,
        )

    def status(self) -> StagingLedgerStatus:
        with self._lock:
            self._require_open()
            return self._status_from_row(self._meta_row())

    def get(self, owner_id: str) -> StagingReservation | None:
        owner = _owner(owner_id)
        with self._lock:
            self._require_open()
            row = self._connection.execute(
                "SELECT owner_id, kind, size_bytes, created_at_ns, committed_bytes "
                "FROM staging_reservations WHERE owner_id = ?",
                (owner,),
            ).fetchone()
        return self._reservation_from_row(row) if row is not None else None

    @staticmethod
    def _reservation_from_row(row: sqlite3.Row) -> StagingReservation:
        return StagingReservation(
            owner_id=str(row["owner_id"]),
            kind=str(row["kind"]),
            size_bytes=int(row["size_bytes"]),
            created_at_ns=int(row["created_at_ns"]),
            committed_bytes=int(row["committed_bytes"]),
        )

    def page(
        self, *, limit: int = 256, after_owner_id: str | None = None
    ) -> tuple[StagingReservation, ...]:
        bounded = _page_limit(limit)
        after = _owner(after_owner_id) if after_owner_id is not None else None
        with self._lock:
            self._require_open()
            if after is None:
                rows = self._connection.execute(
                    """SELECT owner_id, kind, size_bytes, created_at_ns, committed_bytes
                       FROM staging_reservations ORDER BY owner_id LIMIT ?""",
                    (bounded,),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """SELECT owner_id, kind, size_bytes, created_at_ns, committed_bytes
                       FROM staging_reservations WHERE owner_id > ?
                       ORDER BY owner_id LIMIT ?""",
                    (after, bounded),
                ).fetchall()
        return tuple(self._reservation_from_row(row) for row in rows)

    def kind_usage(self, kind: str) -> tuple[int, int]:
        """Return ``(reservation_count, reserved_bytes)`` for one owner class."""

        normalized_kind = _kind(kind)
        with self._lock:
            self._require_open()
            row = self._connection.execute(
                "SELECT reservation_count, reserved_bytes "
                "FROM staging_kind_totals WHERE kind = ?",
                (normalized_kind,),
            ).fetchone()
        return (
            (int(row["reservation_count"]), int(row["reserved_bytes"]))
            if row is not None
            else (0, 0)
        )

    def reserve(
        self,
        owner_id: str,
        *,
        kind: str,
        size_bytes: int,
        max_kind_entries: int | None = None,
    ) -> StagingReservation:
        owner = _owner(owner_id)
        normalized_kind = _kind(kind)
        size = _size(size_bytes, maximum=self.max_bytes)
        if (
            max_kind_entries is not None
            and (
                isinstance(max_kind_entries, bool)
                or not isinstance(max_kind_entries, int)
                or not 1 <= max_kind_entries <= self.max_entries
            )
        ):
            raise ValueError("max_kind_entries is outside the staging entry bound")
        created_at = self._now_ns()
        if isinstance(created_at, bool) or not isinstance(created_at, int) or created_at < 0:
            raise StagingLedgerError("the staging ledger clock is invalid")
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                existing = self._connection.execute(
                    "SELECT owner_id, kind, size_bytes, created_at_ns, committed_bytes, seen_repair_id "
                    "FROM staging_reservations WHERE owner_id = ?",
                    (owner,),
                ).fetchone()
                if existing is not None:
                    reservation = self._reservation_from_row(existing)
                    if reservation.kind != normalized_kind or reservation.size_bytes != size:
                        raise StagingLedgerError(
                            "a staging owner was replayed with different reservation bytes"
                        )
                    meta = self._meta_row()
                    repair_phase = str(meta["repair_phase"])
                    repair_id = meta["repair_id"]
                    # A replay is allowed during repair only after the physical
                    # scanner has observed this exact owner under the active
                    # token. Otherwise a writer could recreate bytes after the
                    # scanner passed the path and the subsequent stale-row
                    # sweep would undercount live staging.
                    if repair_phase != "ready" and (
                        repair_id is None
                        or existing["seen_repair_id"] != repair_id
                    ):
                        raise StagingRepairRequired(
                            "staging replay is blocked until its physical bytes are observed"
                        )
                    self._connection.execute("COMMIT")
                    return reservation
                meta = self._meta_row()
                if str(meta["repair_phase"]) != "ready":
                    raise StagingRepairRequired(
                        "staging admission is blocked until physical repair completes"
                    )
                reserved = int(meta["reserved_bytes"])
                committed = int(meta["committed_bytes"])
                count = int(meta["reservation_count"])
                if count >= self.max_entries or size > self.max_bytes - reserved:
                    raise StagingAdmissionExceeded(
                        "the shared Fabric staging budget is exhausted"
                    )
                kind_row = self._connection.execute(
                    "SELECT reservation_count FROM staging_kind_totals WHERE kind = ?",
                    (normalized_kind,),
                ).fetchone()
                kind_count = (
                    int(kind_row["reservation_count"])
                    if kind_row is not None
                    else 0
                )
                if (
                    max_kind_entries is not None
                    and kind_count >= max_kind_entries
                ):
                    raise StagingAdmissionExceeded(
                        "the Fabric staging owner-class entry budget is exhausted"
                    )
                usage = self._disk_usage(self.staging_root)
                total = int(usage.total)
                free = int(usage.free)
                if total < 0 or free < 0:
                    raise StagingLedgerError("the staging filesystem accounting is invalid")
                minimum_free = max(
                    self.min_free_bytes,
                    (total * self.min_free_ppm) // 1_000_000,
                )
                # ``free`` already reflects fsynced payload allocation. Only
                # the not-yet-allocated portion of durable reservations remains
                # future debt. Data fsync always precedes ``record_committed``;
                # a crash between them therefore overcharges safely rather than
                # admitting bytes which the filesystem cannot hold.
                outstanding = max(0, reserved - committed)
                if size > max(0, free - minimum_free - outstanding):
                    raise StagingAdmissionExceeded(
                        "the Fabric staging free-space reserve would be violated"
                    )
                self._connection.execute(
                    """INSERT INTO staging_reservations(
                           owner_id, kind, size_bytes, committed_bytes,
                           created_at_ns, seen_repair_id
                       ) VALUES(?, ?, ?, 0, ?, NULL)""",
                    (owner, normalized_kind, size, created_at),
                )
                self._connection.execute(
                    """UPDATE staging_meta SET
                           reserved_bytes = reserved_bytes + ?,
                           reservation_count = reservation_count + 1
                       WHERE singleton = 1""",
                    (size,),
                )
                self._connection.execute(
                    """INSERT INTO staging_kind_totals(
                           kind, reserved_bytes, reservation_count
                       ) VALUES(?, ?, 1)
                       ON CONFLICT(kind) DO UPDATE SET
                           reserved_bytes = reserved_bytes + excluded.reserved_bytes,
                           reservation_count = reservation_count + 1""",
                    (normalized_kind, size),
                )
                self._connection.execute("COMMIT")
                return StagingReservation(owner, normalized_kind, size, created_at)
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise

    def resize(
        self,
        expected: StagingReservation,
        *,
        size_bytes: int,
        committed_bytes: int,
    ) -> StagingReservation:
        """Adjust one exclusively owned mutable stage before its next write.

        The caller holds its file's writer lock across resize and physical IO.
        Growth is admitted transactionally against every other staging owner.
        Shrink is allowed only after the caller has removed the physical bytes;
        allocation credit must be withdrawn *before* any truncate/checkpoint
        which could return those bytes to the filesystem. This method never
        increases that credit; only a subsequent fsynced observation through
        ``record_committed`` may do so. A crash at either boundary overcharges.
        """
        if not isinstance(expected, StagingReservation):
            raise TypeError("resize requires an exact staging reservation")
        owner = _owner(expected.owner_id)
        size = _size(size_bytes, maximum=self.max_bytes)
        committed = _size(committed_bytes, maximum=size)
        if committed > expected.committed_bytes:
            raise StagingLedgerError("resize cannot create physical allocation credit")
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                row = self._connection.execute(
                    "SELECT owner_id, kind, size_bytes, created_at_ns, committed_bytes "
                    "FROM staging_reservations WHERE owner_id = ?", (owner,)
                ).fetchone()
                if row is None or self._reservation_from_row(row) != expected:
                    raise StagingLedgerError("the mutable staging reservation changed")
                meta = self._meta_row()
                if str(meta["repair_phase"]) != "ready":
                    raise StagingRepairRequired("mutable staging is blocked until physical repair completes")
                delta = size - expected.size_bytes
                if delta > 0:
                    if delta > self.max_bytes - int(meta["reserved_bytes"]):
                        raise StagingAdmissionExceeded("the shared Fabric staging budget is exhausted")
                    usage = self._disk_usage(self.staging_root)
                    total, free = usage.total, usage.free
                    if type(total) is not int or type(free) is not int or not 0 <= free <= total:
                        raise StagingLedgerError("the staging filesystem accounting is invalid")
                    minimum_free = max(self.min_free_bytes, total * self.min_free_ppm // 1_000_000)
                    outstanding = max(0, int(meta["reserved_bytes"]) - int(meta["committed_bytes"])
                        + expected.committed_bytes - committed)
                    if delta > max(0, free - minimum_free - outstanding):
                        raise StagingAdmissionExceeded("the Fabric staging free-space reserve would be violated")
                # Withdrawing stale credit must work even on a full disk or an
                # over-budget ledger; it cannot authorize additional writes.
                self._connection.execute(
                    "UPDATE staging_reservations SET size_bytes=?, committed_bytes=? WHERE owner_id=?",
                    (size, committed, owner),
                )
                self._connection.execute(
                    "UPDATE staging_meta SET reserved_bytes=reserved_bytes+?, committed_bytes=committed_bytes+? "
                    "WHERE singleton=1", (delta, committed - expected.committed_bytes),
                )
                self._connection.execute(
                    "UPDATE staging_kind_totals SET reserved_bytes=reserved_bytes+? WHERE kind=?",
                    (delta, expected.kind),
                )
                self._connection.execute("COMMIT")
                return StagingReservation(owner, expected.kind, size, expected.created_at_ns, committed)
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise

    def record_committed(self, owner_id: str, *, allocated_bytes: int) -> int:
        """Durably charge payload allocation already reflected by disk ``free``.

        Callers invoke this only after the payload file has been fsynced. The
        value is monotonic for one owner; a smaller observation cannot grant
        capacity because delayed deallocation or a stale stat is not proof that
        the reservation's physical bytes disappeared.
        """

        owner = _owner(owner_id)
        allocated = _size(allocated_bytes, maximum=self.max_bytes)
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                row = self._connection.execute(
                    "SELECT size_bytes, committed_bytes FROM staging_reservations "
                    "WHERE owner_id = ?",
                    (owner,),
                ).fetchone()
                if row is None:
                    raise StagingLedgerError(
                        "committed staging bytes have no durable reservation"
                    )
                size = int(row["size_bytes"])
                prior = int(row["committed_bytes"])
                bounded = min(size, allocated)
                if bounded <= prior:
                    self._connection.execute("COMMIT")
                    return prior
                delta = bounded - prior
                self._connection.execute(
                    "UPDATE staging_reservations SET committed_bytes = ? "
                    "WHERE owner_id = ?",
                    (bounded, owner),
                )
                self._connection.execute(
                    "UPDATE staging_meta SET committed_bytes = committed_bytes + ? "
                    "WHERE singleton = 1",
                    (delta,),
                )
                self._connection.execute("COMMIT")
                return bounded
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise

    def release(self, owner_id: str, *, expected_size_bytes: int | None = None) -> bool:
        owner = _owner(owner_id)
        expected = (
            _size(expected_size_bytes, maximum=self.max_bytes)
            if expected_size_bytes is not None
            else None
        )
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                row = self._connection.execute(
                    "SELECT kind, size_bytes, committed_bytes "
                    "FROM staging_reservations WHERE owner_id = ?",
                    (owner,),
                ).fetchone()
                if row is None:
                    self._connection.execute("COMMIT")
                    return False
                size = int(row["size_bytes"])
                committed = int(row["committed_bytes"])
                reservation_kind = str(row["kind"])
                if expected is not None and expected != size:
                    raise StagingLedgerError(
                        "the staging release does not match its durable reservation"
                    )
                self._connection.execute(
                    "DELETE FROM staging_reservations WHERE owner_id = ?", (owner,)
                )
                self._connection.execute(
                    """UPDATE staging_meta SET
                           reserved_bytes = reserved_bytes - ?,
                           committed_bytes = committed_bytes - ?,
                           reservation_count = reservation_count - 1
                       WHERE singleton = 1""",
                    (size, committed),
                )
                self._connection.execute(
                    """UPDATE staging_kind_totals SET
                           reserved_bytes = reserved_bytes - ?,
                           reservation_count = reservation_count - 1
                       WHERE kind = ?""",
                    (size, reservation_kind),
                )
                self._connection.execute(
                    "DELETE FROM staging_kind_totals "
                    "WHERE kind = ? AND reservation_count = 0",
                    (reservation_kind,),
                )
                self._connection.execute("COMMIT")
                return True
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise

    def begin_repair(self) -> str:
        repair_id = str(uuid.uuid4())
        started_at = self._now_ns()
        if isinstance(started_at, bool) or not isinstance(started_at, int) or started_at < 0:
            raise StagingLedgerError("the staging ledger clock is invalid")
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                self._connection.execute(
                    """UPDATE staging_meta SET repair_phase = 'scan', repair_id = ?,
                           repair_started_at_ns = ?, repair_sweep_after = NULL
                       WHERE singleton = 1""",
                    (repair_id, started_at),
                )
                self._connection.execute("COMMIT")
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
        return repair_id

    def observe_repair(
        self,
        repair_id: str,
        reservations: Sequence[StagingReservation],
    ) -> int:
        try:
            normalized_repair_id = str(uuid.UUID(repair_id))
        except (ValueError, TypeError, AttributeError):
            raise ValueError("repair_id must be a canonical UUID") from None
        if normalized_repair_id != repair_id:
            raise ValueError("repair_id must be a canonical UUID")
        if isinstance(reservations, (str, bytes)) or not isinstance(reservations, Sequence):
            raise TypeError("reservations must be a bounded sequence")
        if len(reservations) > _MAX_PAGE:
            raise ValueError(f"at most {_MAX_PAGE} reservations may be observed per step")
        normalized: dict[str, tuple[str, int, int, int]] = {}
        for reservation in reservations:
            if not isinstance(reservation, StagingReservation):
                raise TypeError("repair observations must be StagingReservation values")
            owner = _owner(reservation.owner_id)
            kind = _kind(reservation.kind)
            size = _size(reservation.size_bytes, maximum=self.max_bytes)
            committed = _size(reservation.committed_bytes, maximum=size)
            created = reservation.created_at_ns
            if isinstance(created, bool) or not isinstance(created, int) or created < 0:
                raise ValueError("created_at_ns must be a non-negative integer")
            prior = normalized.get(owner)
            current = (kind, size, created, committed)
            if prior is not None and prior != current:
                raise StagingLedgerError(
                    "one repair page contains conflicting physical reservations"
                )
            normalized[owner] = current
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                meta = self._meta_row()
                if (
                    str(meta["repair_phase"]) != "scan"
                    or meta["repair_id"] != normalized_repair_id
                ):
                    raise StagingRepairRequired("the staging repair token is no longer active")
                byte_delta = 0
                committed_delta = 0
                count_delta = 0
                for owner, (kind, size, created, committed) in normalized.items():
                    row = self._connection.execute(
                        "SELECT kind, size_bytes, committed_bytes "
                        "FROM staging_reservations WHERE owner_id = ?",
                        (owner,),
                    ).fetchone()
                    if row is None:
                        self._connection.execute(
                            """INSERT INTO staging_reservations(
                                   owner_id, kind, size_bytes, committed_bytes,
                                   created_at_ns, seen_repair_id
                               ) VALUES(?, ?, ?, ?, ?, ?)""",
                            (
                                owner,
                                kind,
                                size,
                                committed,
                                created,
                                normalized_repair_id,
                            ),
                        )
                        byte_delta += size
                        committed_delta += committed
                        count_delta += 1
                        self._connection.execute(
                            """INSERT INTO staging_kind_totals(
                                   kind, reserved_bytes, reservation_count
                               ) VALUES(?, ?, 1)
                               ON CONFLICT(kind) DO UPDATE SET
                                   reserved_bytes = reserved_bytes + excluded.reserved_bytes,
                                   reservation_count = reservation_count + 1""",
                            (kind, size),
                        )
                    else:
                        prior_kind = str(row["kind"])
                        prior_size = int(row["size_bytes"])
                        prior_committed = int(row["committed_bytes"])
                        self._connection.execute(
                            """UPDATE staging_reservations SET kind = ?, size_bytes = ?,
                                   committed_bytes = ?,
                                   created_at_ns = ?, seen_repair_id = ?
                               WHERE owner_id = ?""",
                            (
                                kind,
                                size,
                                committed,
                                created,
                                normalized_repair_id,
                                owner,
                            ),
                        )
                        byte_delta += size - prior_size
                        committed_delta += committed - prior_committed
                        if prior_kind == kind:
                            self._connection.execute(
                                """UPDATE staging_kind_totals SET
                                       reserved_bytes = reserved_bytes + ?
                                   WHERE kind = ?""",
                                (size - prior_size, kind),
                            )
                        else:
                            self._connection.execute(
                                """UPDATE staging_kind_totals SET
                                       reserved_bytes = reserved_bytes - ?,
                                       reservation_count = reservation_count - 1
                                   WHERE kind = ?""",
                                (prior_size, prior_kind),
                            )
                            self._connection.execute(
                                "DELETE FROM staging_kind_totals "
                                "WHERE kind = ? AND reservation_count = 0",
                                (prior_kind,),
                            )
                            self._connection.execute(
                                """INSERT INTO staging_kind_totals(
                                       kind, reserved_bytes, reservation_count
                                   ) VALUES(?, ?, 1)
                                   ON CONFLICT(kind) DO UPDATE SET
                                       reserved_bytes = reserved_bytes + excluded.reserved_bytes,
                                       reservation_count = reservation_count + 1""",
                                (kind, size),
                            )
                self._connection.execute(
                    """UPDATE staging_meta SET
                           reserved_bytes = reserved_bytes + ?,
                           committed_bytes = committed_bytes + ?,
                           reservation_count = reservation_count + ?
                       WHERE singleton = 1""",
                    (byte_delta, committed_delta, count_delta),
                )
                self._connection.execute("COMMIT")
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
        return len(normalized)

    def observe_ambiguous(self, repair_id: str, owner_id: str) -> int:
        """Conservatively charge one unreadable physical entry at full budget."""

        return self.observe_repair(
            repair_id,
            (
                StagingReservation(
                    owner_id=_owner(owner_id),
                    kind="ambiguous",
                    size_bytes=self.max_bytes,
                    created_at_ns=self._now_ns(),
                ),
            ),
        )

    def begin_repair_sweep(self, repair_id: str) -> None:
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                meta = self._meta_row()
                if str(meta["repair_phase"]) != "scan" or meta["repair_id"] != repair_id:
                    raise StagingRepairRequired("the staging repair token is no longer active")
                self._connection.execute(
                    """UPDATE staging_meta SET repair_phase = 'sweep',
                           repair_sweep_after = NULL WHERE singleton = 1"""
                )
                self._connection.execute("COMMIT")
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise

    def sweep_repair(self, repair_id: str, *, limit: int = 1_000) -> StagingRepairStep:
        bounded = _page_limit(limit)
        with self._lock:
            self._require_open()
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                meta = self._meta_row()
                if str(meta["repair_phase"]) != "sweep" or meta["repair_id"] != repair_id:
                    raise StagingRepairRequired("the staging repair token is no longer active")
                cursor = meta["repair_sweep_after"]
                if cursor is None:
                    rows = self._connection.execute(
                        """SELECT owner_id, kind, size_bytes, committed_bytes,
                                  seen_repair_id
                           FROM staging_reservations ORDER BY owner_id LIMIT ?""",
                        (bounded,),
                    ).fetchall()
                else:
                    rows = self._connection.execute(
                        """SELECT owner_id, kind, size_bytes, committed_bytes,
                                  seen_repair_id
                           FROM staging_reservations WHERE owner_id > ?
                           ORDER BY owner_id LIMIT ?""",
                        (str(cursor), bounded),
                    ).fetchall()
                stale = [row for row in rows if row["seen_repair_id"] != repair_id]
                removed = len(stale)
                if rows:
                    if stale:
                        owners = tuple(str(row["owner_id"]) for row in stale)
                        placeholders = ",".join("?" for _ in owners)
                        removed_bytes = sum(int(row["size_bytes"]) for row in stale)
                        removed_committed = sum(
                            int(row["committed_bytes"]) for row in stale
                        )
                        self._connection.execute(
                            f"DELETE FROM staging_reservations WHERE owner_id IN ({placeholders})",
                            owners,
                        )
                        self._connection.execute(
                            """UPDATE staging_meta SET
                                   reserved_bytes = reserved_bytes - ?,
                                   committed_bytes = committed_bytes - ?,
                                   reservation_count = reservation_count - ?
                               WHERE singleton = 1""",
                            (removed_bytes, removed_committed, removed),
                        )
                        by_kind: dict[str, tuple[int, int]] = {}
                        for row in stale:
                            stale_kind = str(row["kind"])
                            old_count, old_bytes = by_kind.get(stale_kind, (0, 0))
                            by_kind[stale_kind] = (
                                old_count + 1,
                                old_bytes + int(row["size_bytes"]),
                            )
                        for stale_kind, (kind_count, kind_bytes) in by_kind.items():
                            self._connection.execute(
                                """UPDATE staging_kind_totals SET
                                       reserved_bytes = reserved_bytes - ?,
                                       reservation_count = reservation_count - ?
                                   WHERE kind = ?""",
                                (kind_bytes, kind_count, stale_kind),
                            )
                            self._connection.execute(
                                "DELETE FROM staging_kind_totals "
                                "WHERE kind = ? AND reservation_count = 0",
                                (stale_kind,),
                            )
                    self._connection.execute(
                        "UPDATE staging_meta SET repair_sweep_after = ? WHERE singleton = 1",
                        (str(rows[-1]["owner_id"]),),
                    )
                    complete = False
                else:
                    invalid = self._connection.execute(
                        "SELECT owner_id FROM staging_reservations "
                        "WHERE committed_bytes < 0 OR committed_bytes > size_bytes "
                        "LIMIT 1"
                    ).fetchone()
                    if invalid is not None:
                        raise StagingLedgerError(
                            "a repaired staging reservation has invalid committed bytes"
                        )
                    committed = int(
                        self._connection.execute(
                            "SELECT COALESCE(SUM(committed_bytes), 0) "
                            "FROM staging_reservations"
                        ).fetchone()[0]
                    )
                    if committed > int(meta["reserved_bytes"]):
                        raise StagingLedgerError(
                            "repaired staging committed bytes exceed reserved bytes"
                        )
                    self._connection.execute(
                        """UPDATE staging_meta SET committed_bytes = ?,
                               repair_phase = 'ready', repair_id = NULL,
                               repair_started_at_ns = NULL, repair_sweep_after = NULL
                           WHERE singleton = 1""",
                        (committed,),
                    )
                    complete = True
                status = self._status_from_row(self._meta_row())
                self._connection.execute("COMMIT")
                return StagingRepairStep(status=status, removed=removed, complete=complete)
            except BaseException:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
