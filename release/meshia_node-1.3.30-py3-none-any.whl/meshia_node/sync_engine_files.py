"""Connection-owned immutable file descriptions across the mount/engine link.

The engine retains the real version and its runtime lease. The worker holds an
opaque description, with a local in-flight pin so CLOSE cannot overtake a read
that is still assembling several bounded responses. Disconnect releases even
an OPEN whose response never reached the worker.
"""
from __future__ import annotations

import base64
import errno
import threading
import time
import uuid
from contextlib import contextmanager
from types import SimpleNamespace

READ_BYTES = 256 * 1024
WRITE_BYTES = 1024 * 1024
MAX_DESCRIPTIONS = 4096


class EngineFileDescriptions:
    def __init__(self, lease):
        self.lease = lease
        self.lock = threading.RLock()
        self.closed = False
        self.versions = {}
        self.opening = 0
        self.constructions = {}
        self.mount_owners = {}

    def handlers(self):
        return {"file_version_open": self.open, "file_version_read": self.read,
                "file_version_close": self.release, "native_open": self.native_open,
                "native_finish": self.native_finish, "native_call": self.native_call,
                "native_recover": self.native_recover, "native_owned": self.native_owned,
                "native_stage": self.native_stage}

    def native_open(self, session_id, path, expected_digest, expected_size, discard_source=False):
        with self.lock:
            if self.closed or len(self.constructions) + self.opening >= MAX_DESCRIPTIONS:
                raise OSError(errno.EIO if self.closed else errno.EMFILE, "Native OPEN is unavailable")
            self.opening += 1
        lease, coordinator, job, retained = self.lease(session_id), None, None, False
        try:
            coordinator = lease.__enter__()
            # Non-CAS fixture coordinators intentionally use inode staging.
            factory = getattr(coordinator, "open_native_journal", None)
            job = factory(path, expected_digest=expected_digest, expected_size=expected_size,
                discard_source=discard_source) if callable(factory) else None
            if job is None:
                return None
            construction = uuid.uuid4().hex
            with self.lock:
                if self.closed:
                    raise OSError(errno.EIO, "The mount disconnected during native OPEN")
                self.constructions[construction] = (session_id, job, lease)
                retained = True
            with job.lock:
                return {"token": job.token, "construction": construction,
                        "descriptor": job.journal.descriptor(), "digest": job.journal.digest()}
        finally:
            with self.lock:
                self.opening -= 1
            if not retained and coordinator is not None:
                try:
                    if job is not None:
                        job.finish_construction()
                finally:
                    lease.__exit__(None, None, None)

    def native_finish(self, session_id, construction):
        with self.lock:
            item = self.constructions.get(construction)
            if item is None:
                return
            if item[0] != session_id:
                raise OSError(errno.EBADF, "The native OPEN belongs to another workspace")
            self.constructions.pop(construction)
        try:
            item[1].finish_construction()
        finally:
            item[2].__exit__(None, None, None)

    def _remember_mount_owner(self, session_id, job, snapshot, owner):
        with self.lock:
            if not self.closed:
                self.mount_owners[(session_id, job.token, snapshot)] = (job, owner)
                return
        job.pool.disconnected_mount_owner(job, snapshot, owner)

    def native_call(self, session_id, token, operation, arguments):
        if not isinstance(arguments, dict) or operation not in {
                "read", "write", "truncate", "retain", "release", "release_later", "digest", "descriptor"}:
            raise OSError(errno.EINVAL, "Unsupported native journal operation")
        with self.lease(session_id) as coordinator:
            job = coordinator._native_journals.get(token, source=False)
            with job.lock:
                if self.closed:
                    raise OSError(errno.EIO, "The mount connection is closed")
                if operation == "read":
                    count = arguments.get("count")
                    if type(count) is not int or not 0 <= count <= WRITE_BYTES:
                        raise OSError(errno.EINVAL, "The native read exceeds its IPC bound")
                    return base64.b64encode(job.journal.read(**arguments)).decode("ascii")
                if operation in {"descriptor", "digest"}:
                    return getattr(job.journal, operation)(**arguments)
                if operation == "write":
                    arguments = dict(arguments)
                    encoded = arguments.get("data")
                    if not isinstance(encoded, str) or len(encoded) > 4 * ((WRITE_BYTES + 2) // 3):
                        raise OSError(errno.EINVAL, "The native write exceeds its IPC bound")
                    arguments["data"] = base64.b64decode(encoded, validate=True)
                    if len(arguments["data"]) > WRITE_BYTES:
                        raise OSError(errno.EINVAL, "The native write exceeds its IPC bound")
                if operation == "retain":
                    owner = arguments.get("owner")
                    if (not isinstance(owner, str) or not owner.startswith("mount:")
                            or len(owner) != 38 or uuid.UUID(hex=owner[6:]).hex != owner[6:]
                            or arguments.get("publication") is not False):
                        raise OSError(errno.EINVAL, "A native mount snapshot needs its exact owner")
                    snapshot = job.mutate(lambda: job.journal.retain(**arguments))
                    self._remember_mount_owner(session_id, job, snapshot, owner)
                    return {"value": snapshot, "descriptor": job.journal.descriptor(snapshot),
                            "digest": job.journal.digest(snapshot)}
                if operation in {"release", "release_later"}:
                    snapshot = arguments["snapshot"]
                    owner = job.journal.snapshot_owner(snapshot)
                    if owner is not None and not owner.startswith("mount:"):
                        raise OSError(errno.EINVAL, "The mount cannot release a publication or reader snapshot")
                    if operation == "release_later":
                        job.release_later(snapshot)
                        result = None
                    else:
                        result = job.mutate(lambda: job.journal.release(snapshot))
                    with self.lock:
                        self.mount_owners.pop((session_id, token, snapshot), None)
                    return result
                result = job.mutate(lambda: getattr(job.journal, operation)(**arguments))
                return {"value": result, "descriptor": job.journal.descriptor(), "digest": job.journal.digest()}

    def native_recover(self, session_id, document):
        with self.lease(session_id) as coordinator:
            job, owned = coordinator.recover_native_journal(document)
            self._remember_mount_owner(session_id, job, document["tree_owner"], "mount:" + document["token"])
            return {"token": job.token, "owned": owned}

    def native_owned(self, session_id, document):
        with self.lease(session_id) as coordinator:
            return coordinator.native_tree_handoff_owned(document)

    def native_stage(self, session_id, token, path, snapshot, expected_source_digest, mutation_id,
                     delete_after_ack=None, modified_at=None):
        with self.lease(session_id) as coordinator:
            job = coordinator._native_journals.get(token, source=False)
            if job.journal.snapshot_owner(snapshot) != "mount:" + uuid.UUID(mutation_id).hex:
                raise OSError(errno.EINVAL, "The native handoff lost its mount snapshot owner")
            coordinator.stage_tree_snapshot(path, journal=job.journal, snapshot=snapshot,
                tree_mutation=job.mutate, expected_source_digest=expected_source_digest,
                mutation_id=mutation_id, modified_at=modified_at,
                delete_after_ack=tuple(delete_after_ack) if delete_after_ack is not None else None)

    def open(self, session_id, path, expected_digest, expected_size, native=None):
        with self.lock:
            if self.closed:
                raise OSError(errno.EIO, "The mount connection is closed")
            if len(self.versions) + self.opening >= MAX_DESCRIPTIONS:
                raise OSError(errno.EMFILE, "Too many open file descriptions")
            self.opening += 1
        lease, coordinator, version, retained = self.lease(session_id), None, None, False
        try:
            coordinator = lease.__enter__()
            if native is None:
                version = coordinator.open_file_version(path, expected_digest=expected_digest,
                                                        expected_size=expected_size)
            else:
                if not isinstance(native, list) or len(native) != 2:
                    raise OSError(errno.EINVAL, "The native file description is invalid")
                version = coordinator.open_native_file_version(path, *native,
                    expected_digest=expected_digest, expected_size=expected_size)
            if version is None:
                return None
            token = uuid.uuid4().hex
            with self.lock:
                if self.closed:
                    raise OSError(errno.EIO, "The mount disconnected during OPEN")
                self.versions[token] = SimpleNamespace(session_id=session_id, coordinator=coordinator,
                    version=version, lease=lease, inflight=0, released=False)
                retained = True
            return {"token": token, "path": version.entry.path,
                    "digest": version.entry.digest, "size_bytes": version.entry.size_bytes,
                    # A warm current-path cache hit can bypass IPC only within
                    # this conservative read-hold renewal interval. Native
                    # journals have no remote cache projection.
                    "cache_seconds": max(0, getattr(version, "_renew_at", 0)
                        - version.pool.clock()) if hasattr(version.pool, "clock") else 0}
        finally:
            with self.lock:
                self.opening -= 1
            if not retained and coordinator is not None:
                try:
                    if version is not None:
                        coordinator.release_file_version(version)
                finally:
                    lease.__exit__(None, None, None)

    def read(self, session_id, token, offset, length):
        if type(offset) is not int or offset < 0 or type(length) is not int or not 0 <= length <= READ_BYTES:
            raise OSError(errno.EINVAL, "The file read exceeds its IPC bound")
        with self.lock:
            item = self.versions.get(token)
            if self.closed or item is None or item.session_id != session_id:
                raise OSError(errno.EBADF, "The file description is closed")
            version = item.version
            if offset + length > version.entry.size_bytes:
                raise OSError(errno.EINVAL, "The file read exceeds its immutable version")
            # Pin under the connection lock; release/disconnect may run while
            # the network read is in progress, but cannot reclaim its bytes.
            reading = version.pool.reading(version)
            reading.__enter__()
            item.inflight += 1
        try:
            data = b"".join(version.stream(offset, length))
            if len(data) != length:
                raise OSError(errno.EIO, "The retained file read ended early")
            return {"data": base64.b64encode(data).decode("ascii"),
                    "cache_seconds": max(0, getattr(version, "_renew_at", 0)
                        - version.pool.clock()) if hasattr(version.pool, "clock") else 0}
        finally:
            reading.__exit__(None, None, None)
            with self.lock:
                item.inflight -= 1
                retire = item.released and not item.inflight
            if retire:
                self._release(item)

    def release(self, session_id, token):
        with self.lock:
            item = self.versions.get(token)
            if item is None:
                return
            if item.session_id != session_id:
                raise OSError(errno.EBADF, "The file description belongs to another workspace")
            self.versions.pop(token)
            item.released = True
            retire = not item.inflight
        if retire:
            self._release(item)

    @staticmethod
    def _release(item):
        try:
            item.coordinator.release_file_version(item.version)
        finally:
            item.lease.__exit__(None, None, None)

    def close(self):
        with self.lock:
            self.closed = True
            versions, self.versions = tuple(self.versions.values()), {}
            for item in versions:
                item.released = True
            idle = tuple(item for item in versions if not item.inflight)
            constructions, self.constructions = tuple(self.constructions.values()), {}
            owners, self.mount_owners = tuple(self.mount_owners.items()), {}
        for (_, token, snapshot), (job, owner) in owners:
            job.pool.disconnected_mount_owner(job, snapshot, owner)
        for _, job, lease in constructions:
            try:
                job.finish_construction()
            finally:
                lease.__exit__(None, None, None)
        for item in idle:
            self._release(item)


class RemoteNativeJournal:
    """One OPEN construction pin; the underlying engine journal is shared."""
    def __init__(self, proxy, token, construction=None, descriptor=None, digest=None):
        self.proxy, self.token, self.construction = proxy, token, construction
        self.journal = RemoteWriteTree(proxy, token, descriptor=descriptor, digest=digest)

    def mutate(self, action):
        # The action invokes one of RemoteWriteTree's explicit methods. Its
        # engine handler performs shared admission and mutation under the one
        # physical writer lock; no callable or ledger crosses the boundary.
        return action()

    def release_later(self, snapshot):
        return self.journal._call("release_later", snapshot=snapshot)

    def finish_construction(self):
        if self.construction is not None and not self.proxy._endpoint.closed:
            self.proxy._stage("native_finish", construction=self.construction)
        self.construction = None


class RemoteWriteTree:
    def __init__(self, proxy, token, *, descriptor=None, digest=None):
        self.proxy, self.identity = proxy, token
        self._views = {"current": (descriptor, digest)} if descriptor is not None else {}

    def _call(self, operation, **arguments):
        return self.proxy._stage("native_call", token=self.identity,
                                 operation=operation, arguments=arguments)

    def read(self, offset, count, *, snapshot="current"):
        data = bytearray()
        while len(data) < count:
            want = min(WRITE_BYTES, count - len(data))
            chunk = base64.b64decode(self._call("read", offset=offset + len(data), count=want,
                                               snapshot=snapshot), validate=True)
            if len(chunk) != want:
                raise OSError(errno.EIO, "The native read ended early")
            data.extend(chunk)
        return bytes(data)

    def write(self, offset, data):
        if len(data) > WRITE_BYTES:
            raise OSError(errno.EINVAL, "The native write exceeds its IPC bound")
        answer = self._call("write", offset=offset, data=base64.b64encode(data).decode("ascii"))
        self._views["current"] = answer["descriptor"], answer["digest"]
        return answer["value"]

    def truncate(self, size):
        answer = self._call("truncate", size=size)
        self._views["current"] = answer["descriptor"], answer["digest"]
        return answer["value"]

    def retain(self, snapshot="current", *, owner=None, publication=True):
        answer = self._call("retain", snapshot=snapshot, owner=owner, publication=publication)
        self._views[answer["value"]] = answer["descriptor"], answer["digest"]
        return answer["value"]

    def release(self, snapshot):
        result = self._call("release", snapshot=snapshot)
        self._views.pop(snapshot, None)
        return result

    def descriptor(self, snapshot="current"):
        if snapshot in self._views:
            return self._views[snapshot][0]
        return self._call("descriptor", snapshot=snapshot)

    def digest(self, snapshot="current"):
        if snapshot in self._views:
            return self._views[snapshot][1]
        return self._call("digest", snapshot=snapshot)


class RemoteFileVersion:
    def __init__(self, proxy, answer, started):
        self.proxy, self.pool, self.token = proxy, self, answer["token"]
        self.entry = SimpleNamespace(**{key: answer[key] for key in ("path", "digest", "size_bytes")})
        self.cache_until = started + answer["cache_seconds"]
        self.lock = threading.RLock()
        self.inflight, self.references, self.closed = 0, 1, False

    @contextmanager
    def reading(self, version):
        if version is not self:
            raise OSError(errno.EBADF, "The file description belongs to another owner")
        with self.lock:
            if self.closed or self.proxy._endpoint.closed:
                raise OSError(errno.EBADF, "The file description is closed")
            self.inflight += 1
        try:
            yield
        finally:
            with self.lock:
                self.inflight -= 1
            self._retire()

    def release(self, version):
        if version is not self:
            raise OSError(errno.EBADF, "The file description belongs to another owner")
        with self.lock:
            self.references = 0
        self._retire()

    def _retire(self):
        with self.lock:
            if self.closed or self.references or self.inflight:
                return
            self.closed = True
        # This is engine-local bookkeeping; no provider call is made by CLOSE.
        if not self.proxy._endpoint.closed:
            try:
                self.proxy._stage("file_version_close", token=self.token)
            except OSError:
                if not self.proxy._endpoint.closed:
                    raise

    def stream(self, offset, length):
        if type(offset) is not int or type(length) is not int or min(offset, length) < 0 or offset + length > self.entry.size_bytes:
            raise OSError(errno.EINVAL, "The file read exceeds its immutable version")
        with self.reading(self):
            local = self.proxy._local_reader
            if local is not None and time.monotonic() < self.cache_until:
                hit = local.read(self.entry.path, offset, length,
                    expected_digest=self.entry.digest, expected_size=self.entry.size_bytes)
                if hit is not None and not self.proxy._endpoint.closed and time.monotonic() < self.cache_until:
                    self.proxy.local_hits += 1
                    yield hit
                    return
            cursor = offset
            while cursor < offset + length:
                count = min(READ_BYTES, offset + length - cursor)
                self.proxy.ipc_reads += 1
                started = time.monotonic()
                answer = self.proxy._stage("file_version_read", token=self.token, offset=cursor, length=count)
                data = base64.b64decode(answer["data"], validate=True)
                self.cache_until = started + answer["cache_seconds"]
                if len(data) != count:
                    raise OSError(errno.EIO, "The retained file read ended early")
                yield data
                cursor += count
