"""Workspace ownership and disk admission for native copy-on-write journals."""
from __future__ import annotations

import errno
import json
import os
import re
import sqlite3
import stat
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

from .errors import NetworkError, RemoteError, StateError
from .fabric_contract_generated import (FABRIC_CAS_PATH_PREFIX_BY_STORAGE_KIND, FABRIC_FILE_TREE_ALGORITHM,
    FABRIC_BLOCK_FILE_DIGEST_ALGORITHM, FileTree, block_file_sha256, file_digest_algorithm)
from .fabric_db import RemoteEntry
from .fabric_staging import StagingAdmissionExceeded, StagingLedgerError
from .fabric_write_tree import FileTreeJournal
from .workspace import split_relative


_MUTATION_RESERVE = 64 * 1024**2
_CONTEXT_FIELDS = ("scope_id", "host_id", "session_id", "host_generation", "attachment_id", "workspace_root", "workspace_id")


def _private_document(path):
    """Read only the exact private close marker named by a retained owner."""
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0))
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > 65536
                or (os.name != "nt" and (stat.S_IMODE(before.st_mode) != 0o600 or before.st_uid != os.getuid()))):
            raise StateError("The native close marker is not a private bounded file")
        raw = os.read(fd, 65537)
        after = os.fstat(fd)
        if (len(raw) != before.st_size or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)):
            raise StateError("The native close marker changed during recovery")
        document = json.loads(raw)
        if not isinstance(document, dict):
            raise StateError("The native close marker is not an object")
        return document
    finally:
        os.close(fd)


class NativeJournal:
    def __init__(self, pool, token, reservation):
        self.pool, self.token, self.reservation = pool, token, reservation
        self.path = pool.coordinator.staging_root / f"{token}.tree.sqlite"
        self.lock = threading.RLock()
        self.source_lock = threading.RLock()
        self.journal = None
        self.source = None
        self.source_retired = False
        self.source_entry = None
        self.constructing = 0
        self.recovery_after = ""
        self.recovery_done = False

    def family(self):
        return tuple(Path(str(self.path) + suffix) for suffix in ("", "-wal", "-shm"))

    def footprint(self):
        total, stable = 0, 0
        for path in self.family():
            try:
                info = path.lstat()
            except FileNotFoundError:
                continue
            if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                    or (os.name != "nt" and (info.st_mode & 0o077 or info.st_uid != os.getuid()))):
                raise StateError("The native journal family is not privately owned")
            total += info.st_size
            if path == self.path:
                stable = min(info.st_size, getattr(info, "st_blocks", 0) * 512)
        return total, stable

    def reserve(self):
        ledger = self.pool.ledger
        if ledger.status().repair_required and not self.pool.coordinator._advance_staging_repair():
            raise OSError(errno.EAGAIN, "Native journal staging repair is still running")
        actual, _ = self.footprint()
        current = ledger.get(self.reservation.owner_id)
        if current is None or current.kind != "tree":
            raise StateError("The native journal lost exclusive staging ownership")
        # Bounded startup repair may have replaced stale physical accounting.
        # Rebase under this journal's writer lock, then use resize's CAS fence.
        self.reservation = current
        # Each core edit accepts at most 4 MiB; GC retires at most 4 MiB and
        # 64 objects. Keep a conservative DB/WAL/metadata working reserve.
        # SQLite's ENOSPC transaction rollback remains the final IO boundary.
        if actual + _MUTATION_RESERVE > ledger.max_bytes:
            raise StagingAdmissionExceeded("The shared Fabric staging budget is full")
        self.reservation = ledger.resize(current, size_bytes=actual + _MUTATION_RESERVE,
            committed_bytes=min(current.committed_bytes, actual))

    def reconcile(self):
        actual, stable = self.footprint()
        ledger = self.pool.ledger
        if actual > self.reservation.size_bytes:
            # Preserve bytes and stop admitting work when observation exceeds
            # the conservative envelope. Physical repair owns the new debt.
            self.pool.coordinator._staging_repair_id = ledger.begin_repair()
            self.pool.coordinator._staging_repair_phase = "classic"
            raise OSError(errno.ENOSPC, "The native journal requires staging capacity repair")
        self.reservation = ledger.resize(self.reservation, size_bytes=actual,
            committed_bytes=min(self.reservation.committed_bytes, stable))
        if stable > self.reservation.committed_bytes:
            ledger.record_committed(self.reservation.owner_id, allocated_bytes=stable)
            self.reservation = ledger.get(self.reservation.owner_id)

    def mutate(self, action):
        with self.lock:
            try:
                self.reserve()
            except StagingAdmissionExceeded as error:
                raise OSError(errno.ENOSPC, "The shared Fabric staging budget is full") from error
            if self.journal is not None and self.journal._db is not None:
                pages = self.journal._db.execute("PRAGMA page_count").fetchone()[0]
                self.journal._db.execute(f"PRAGMA max_page_count={pages + _MUTATION_RESERVE // 4096}")
            try:
                result = action()
            except BaseException as error:
                try:
                    self.reconcile()
                except (OSError, StateError, sqlite3.Error, StagingLedgerError):
                    # Do not hide the actual syscall failure or delete its
                    # journal because accounting also needs recovery.
                    pass
                if isinstance(error, sqlite3.Error) and getattr(error, "sqlite_errorcode", None) == sqlite3.SQLITE_FULL:
                    raise OSError(errno.ENOSPC, "The native journal filesystem is full") from error
                raise
            self.reconcile()
            return result

    def read_source(self, *args):
        if self.source is None:
            self.ensure_source()
        if self.source is None:
            raise StateError("The native journal has no retained source object")
        return self.source.read_source(*args)

    def bind_context(self):
        context = self.journal.recovery_context()
        if (not isinstance(context, dict) or context.get("scope") != self.pool.scope()
                or set(context) != {"scope", "path", "source"}):
            raise StateError("The native journal belongs to another workspace authority")
        split_relative(context["path"])
        source, descriptor = context["source"], self.journal.source_descriptor()
        if source is None:
            if descriptor["total_bytes"] != 0:
                raise StateError("A nonempty native source lost its retention identity")
            return
        if not isinstance(source, dict) or set(source) != {"path", "digest", "size_bytes"}:
            raise StateError("The native journal source identity is invalid")
        split_relative(source["path"])
        digest = source["digest"]
        if not isinstance(digest, str) or re.fullmatch(r"[a-f0-9]{64}", digest) is None:
            raise StateError("The native journal source identity is invalid")
        algorithm = file_digest_algorithm(descriptor)
        if algorithm == FABRIC_FILE_TREE_ALGORITHM:
            digest = FileTree.from_descriptor(descriptor, load_node=None, read_object=None, put_object=None).digest
        elif algorithm == FABRIC_BLOCK_FILE_DIGEST_ALGORITHM:
            digest = block_file_sha256(descriptor)
        # A raw content SHA cannot be derived from block hashes. Keep the
        # exact admitted source digest; ensure_source must still acquire its
        # signed immutable hold before IO, and reads verify the CAS bytes.
        if source["digest"] != digest or type(source["size_bytes"]) is not int or source["size_bytes"] != descriptor["total_bytes"]:
            raise StateError("The native journal source does not match its retained descriptor")
        self.source_entry = RemoteEntry(source["path"], source["size_bytes"], source["digest"], blocks=descriptor)

    def ensure_source(self):
        with self.source_lock:
            if self.source_entry is None or self.source is not None:
                return
            entry = self.source_entry
            self.source = self.pool.coordinator.open_file_version(entry.path,
                expected_digest=entry.digest, expected_size=entry.size_bytes,
                mode="write", hold_id=self.token, source_entry=entry)
            if self.source is None:
                raise StateError("The native journal source is not range-readable")

    def release(self, snapshot):
        self.mutate(lambda: self.journal.release(snapshot))
        # A callback can run under the mount namespace lock. Remote cleanup is
        # deferred to the coordinator to avoid lock inversion with signed IO.
        self.pool.coordinator.wake()

    def release_later(self, snapshot):
        with self.pool.lock:
            self.pool._pending_releases[(self.token, snapshot)] = self
        self.pool.coordinator.wake()

    def finish_construction(self):
        with self.lock:
            if self.constructing <= 0:
                raise StateError("The native OPEN construction pin is already released")
            self.constructing -= 1
        self.pool.coordinator.wake()


class NativeJournalPool:
    def __init__(self, coordinator):
        self.coordinator = coordinator
        self.ledger = coordinator._staging_ledger
        self.lock = threading.RLock()
        self._journals = {}
        self._readers = set()
        self._pending_releases = {}
        self._disconnected_owners = {}
        self._maintenance_cursor = 0
        self._discovery_scan = None
        self._discovery_done = False
        self._retry_after = {}
        self._closed = False

    def scope(self):
        binding = self.coordinator.database.current_authority()
        if binding is None:
            raise StateError("Native journals require an adopted workspace authority")
        return {name: getattr(binding, name) for name in _CONTEXT_FIELDS}

    def create(self, path, *, expected_digest, expected_size, discard_source=False):
        split_relative(path)
        if self.ledger is None:
            raise StateError("Native journals require shared staging admission")
        if not self.coordinator._advance_staging_repair():
            raise OSError(errno.EAGAIN, "Native journal staging recovery is still running")
        source = None
        if expected_digest is not None and not discard_source:
            source = self.coordinator._remote_entry_for_write(path)
            if source is None or source.digest != expected_digest or source.size_bytes != expected_size:
                raise OSError(errno.ESTALE, "The native write source changed before OPEN")
            if source.blocks is None:
                source = self.coordinator._lookup_v2_descriptor(source)
            if (source.blocks or {}).get("storage", {}).get("kind") not in FABRIC_CAS_PATH_PREFIX_BY_STORAGE_KIND:
                return None  # Inline files still use their complete local bytes.
        token = str(uuid.uuid4())
        context = {"scope": self.scope(), "path": path, "source": None if source is None else
            {"path": source.path, "digest": source.digest, "size_bytes": source.size_bytes}}
        try:
            reservation = self.ledger.reserve(f"tree:{token}", kind="tree", size_bytes=_MUTATION_RESERVE)
        except (StagingAdmissionExceeded, ValueError) as error:
            raise OSError(errno.ENOSPC, "The shared Fabric staging budget is full") from error
        job = NativeJournal(self, token, reservation)
        job.constructing = 1
        job.recovery_done = True
        try:
            job.journal = FileTreeJournal(job.path, identity=token, create=True,
                base=source.blocks if source is not None else None, context=context,
                read_source=job.read_source)
            with self.lock:
                self._journals[token] = job
            job.bind_context()
            job.reconcile()
            # Recovery context and journal directory entry are durable before
            # requesting the source hold, including an uncertain acquisition.
            job.ensure_source()
            return job
        except BaseException:
            job.constructing = 0
            if job.journal is None:
                # No hold request has been made. Only this new UUID's private
                # incomplete database can exist; preserve any cleanup failure.
                for member in reversed(job.family()):
                    if member.exists():
                        job.footprint()
                        member.unlink()
                self.ledger.release(reservation.owner_id)
            self.coordinator.wake()
            raise

    def get(self, token, *, source=True):
        if str(uuid.UUID(token)) != token:
            raise StateError("The native journal identity is invalid")
        with self.lock:
            job = self._journals.get(token)
            if job is None:
                reservation = self.ledger.get(f"tree:{token}")
                if reservation is None:
                    raise StateError("The native journal has no recovered staging reservation")
                job = NativeJournal(self, token, reservation)
                job.journal = FileTreeJournal(job.path, identity=token, read_source=job.read_source)
                try:
                    job.bind_context()
                except BaseException:
                    job.journal.close()
                    raise
                self._journals[token] = job
        if source:
            with job.lock:
                if job.journal._db is None or job.journal.retirement_started():
                    raise OSError(errno.ESTALE, "The native journal is retiring")
                job.ensure_source()
        return job

    def _recover_owners(self, job, limit=64):
        with job.lock:
            if job.recovery_done or job.journal._db is None:
                return
            rows = job.journal.snapshot_owners(after=job.recovery_after, limit=limit, previous_only=True)
            for snapshot, owner, encoded in rows:
                retire = False
                if owner is not None:
                    kind, identity = owner.split(":", 1)
                    descriptor = json.loads(encoded)
                    if kind == "reader":
                        retire = True  # These descriptions belonged to the previous process.
                    elif kind == "mount":
                        marker = self.coordinator.workspace.mount_staging_directory() / f"{identity}.json"
                        try:
                            document = _private_document(marker)
                        except FileNotFoundError:
                            retire = True
                        except (ValueError, StateError, OSError) as error:
                            self.coordinator.logger.record("fabric_native_owner_preserved", journal=job.token,
                                snapshot=snapshot, error=str(error))
                        else:
                            # An older close epoch can lose its marker when a
                            # newer retained epoch atomically replaces it.
                            current = document.get("tree_owner")
                            if (document.get("token") == identity and document.get("tree_journal") == job.token
                                    and current != snapshot and job.journal.snapshot_owner(current) == owner
                                    and job.journal.descriptor(current) == document.get("tree_descriptor")):
                                retire = True
                    elif kind == "upload":
                        operation = self.coordinator.database.get_operation(str(uuid.UUID(identity)))
                        if operation is not None and operation.state == "acked":
                            receipt = self.coordinator.database.get_receipt(operation.mutation_id)
                            retire = bool(receipt is not None and receipt.remote_entry_digest == job.journal.digest(snapshot)
                                and operation.staged_size == descriptor["total_bytes"]
                                and isinstance(receipt.receipt, dict)
                                and receipt.receipt.get("native_journal") == job.token
                                and receipt.receipt.get("entry_blocks") == descriptor)
                        elif operation is not None and operation.kind == "put":
                            _, plan = self.coordinator._load_and_fence_put_plan(operation)
                            retire = bool(plan.source_kind == "file_tree_journal" and plan.source_token == job.token
                                and plan.tree_snapshot != snapshot
                                and job.journal.snapshot_owner(plan.tree_snapshot) == owner
                                and job.journal.descriptor(plan.tree_snapshot) == plan.tree_descriptor)
                        elif operation is None:
                            # A previous process died before persisting its
                            # plan or enqueue. A mount marker still owns any
                            # close that must be recovered and published.
                            plan = self.coordinator.staging_root / f"{str(uuid.UUID(identity))}.data.plan.json"
                            retire = not os.path.lexists(plan)
                if retire:
                    job.release(snapshot)
                job.recovery_after = snapshot
            job.recovery_done = len(rows) < limit

    def _discover(self, limit=64):
        if self.ledger is None or self._discovery_done or not self.coordinator._advance_staging_repair():
            return
        if self._discovery_scan is None:
            self._discovery_scan = os.scandir(self.coordinator.staging_root)
        for _ in range(limit):
            entry = next(self._discovery_scan, None)
            if entry is None:
                self._discovery_scan.close()
                self._discovery_scan = None
                self._discovery_done = True
                return
            if not entry.name.endswith(".tree.sqlite"):
                continue
            token = entry.name[:-len(".tree.sqlite")]
            try:
                self.get(token, source=False)
            except (ValueError, OSError, StateError, sqlite3.Error, StagingLedgerError) as error:
                # Foreign/unmanaged or damaged journals are never cleanup
                # candidates. Keep their charged bytes for explicit recovery.
                self.coordinator.logger.record("fabric_native_journal_preserved", journal=token, error=str(error))

    def retire(self, token, *, idle_only=False):
        """Release the source before removing its last durable cleanup identity."""
        job = self.get(token, source=False)
        with job.lock:
            if idle_only and job.constructing:
                return False
            if not job.source_retired:
                if job.journal.snapshot_owners(limit=1):
                    return False
                if not job.mutate(job.journal.begin_retirement):
                    return False
                context = job.journal.recovery_context()
            else:
                context = {"source": None}
            if not job.source_retired and context["source"] is not None:
                payload = {"operation": "file_hold", "hold_id": token}
                try:
                    status = self.coordinator._file_version_request({**payload, "action": "status"})
                except RemoteError as error:
                    if error.remote_code != "FABRIC_FILE_HOLD_EXPIRED":
                        raise
                    status = None
                if status is not None:
                    source = context["source"]
                    if (status.get("hold_id") != token or status.get("mode") != "write"
                            or status.get("path") != source["path"] or status.get("digest") != source["digest"]
                            or status.get("size_bytes") != source["size_bytes"]):
                        raise NetworkError("The native journal cleanup hold changed identity")
                    if status.get("released") is not True:
                        response = self.coordinator._file_version_request({**payload, "action": "release"})
                        if response.get("hold_id") != token or response.get("released") is not True:
                            raise NetworkError("The native journal source release was not acknowledged")
                self.coordinator._file_versions.complete_write_release(token)
            job.source_retired = True
            # Closing/checkpointing may allocate main-file pages from the WAL.
            # Keep admission active until every member has been observed gone.
            job.mutate(job.journal.close)
            job.footprint()
            for member in reversed(job.family()):
                member.unlink(missing_ok=True)
            directory = os.open(job.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)) if os.name != "nt" else None
            if directory is not None:
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
            self.ledger.release(job.reservation.owner_id, expected_size_bytes=job.reservation.size_bytes)
            with self.lock:
                self._journals.pop(token, None)
            return True

    def open_version(self, path, token, snapshot, *, expected_digest, expected_size):
        job = self.get(token)
        with job.lock:
            descriptor = job.journal.descriptor(snapshot)
            if job.journal.digest(snapshot) != expected_digest or descriptor["total_bytes"] != expected_size:
                raise OSError(errno.ESTALE, "The pending native file changed before OPEN")
            owned = job.mutate(lambda: job.journal.retain(snapshot,
                owner="reader:" + uuid.uuid4().hex, publication=False))
            version = NativeJournalVersion(self, job, owned, RemoteEntry(path, expected_size,
                expected_digest, blocks=descriptor))
            with self.lock:
                self._readers.add(version)
            return version

    @contextmanager
    def reading(self, version):
        with self.lock:
            if version.closed or version not in self._readers:
                raise OSError(errno.EBADF, "The native file description is closed")
            version.inflight += 1
        try:
            yield
        finally:
            with self.lock:
                version.inflight -= 1
            self._retire_reader(version)

    def release(self, version):
        with self.lock:
            if version.closed or not version.references:
                return
            version.references -= 1
        self._retire_reader(version)

    def _retire_reader(self, version):
        with self.lock:
            if version.closed or version.references or version.inflight:
                return
            version.closed = True
            self._readers.discard(version)
            self._pending_releases[(version.job.token, version.snapshot)] = version.job
        self.coordinator.wake()

    def disconnected_mount_owner(self, job, snapshot, owner):
        # The engine survived its mount worker. Current-process snapshot
        # epochs therefore cannot identify orphan mount roots by themselves.
        # Queue only owners created by that exact departed connection.
        with self.lock:
            self._disconnected_owners[(job.token, snapshot)] = (job, owner)
        self.coordinator.wake()

    def _recover_disconnected_owner(self, job, snapshot, owner):
        with job.lock:
            if job.journal._db is None:
                return  # Retirement already proved all owners released.
            if job.journal.snapshot_owner(snapshot) is None:
                return
            if job.journal.snapshot_owner(snapshot) != owner or not owner.startswith("mount:"):
                raise StateError("The disconnected mount snapshot changed owners")
            identity = owner.split(":", 1)[1]
            marker = self.coordinator.workspace.mount_staging_directory() / f"{identity}.json"
            try:
                document = _private_document(marker)
            except FileNotFoundError:
                job.release(snapshot)
                return
            current = document.get("tree_owner")
            if (document.get("token") != identity or document.get("tree_journal") != job.token
                    or job.journal.snapshot_owner(current) != owner
                    or job.journal.descriptor(current) != document.get("tree_descriptor")):
                raise StateError("The disconnected mount marker requires recovery")
            if current != snapshot:
                job.release(snapshot)
            # An exact marker still owns this root. The next worker recovers
            # its close epoch; a disconnect cannot cancel a durable write.

    def maintain(self, limit=4):
        if self._closed or self.ledger is None:
            return
        try:
            self._discover()
        except (OSError, StateError, sqlite3.Error, StagingLedgerError) as error:
            self.coordinator.logger.record("fabric_native_discovery_deferred", error=str(error))
        now = time.monotonic()
        with self.lock:
            disconnected = tuple((key, value) for key, value in self._disconnected_owners.items()
                if self._retry_after.get(key, 0) <= now)[:limit]
            releases = tuple((key, job) for key, job in self._pending_releases.items()
                if self._retry_after.get(key, 0) <= now)[:limit]
            tokens = tuple(self._journals)
            start = self._maintenance_cursor % len(tokens) if tokens else 0
            jobs = (tokens[start:] + tokens[:start])[:limit]
            self._maintenance_cursor = start + len(jobs)
        for key, (job, owner) in disconnected:
            try:
                self._recover_disconnected_owner(job, key[1], owner)
                with self.lock:
                    self._disconnected_owners.pop(key, None)
                    self._retry_after.pop(key, None)
            except (ValueError, OSError, StateError, sqlite3.Error, StagingLedgerError) as error:
                self._retry_after[key] = now + 5
                self.coordinator.logger.record("fabric_native_disconnected_owner_preserved", journal=job.token,
                    snapshot=key[1], error=str(error))
        for (token, snapshot), job in releases:
            try:
                job.release(snapshot)
                with self.lock:
                    self._pending_releases.pop((token, snapshot), None)
                    self._retry_after.pop((token, snapshot), None)
            except (OSError, StateError, sqlite3.Error, StagingLedgerError) as error:
                self._retry_after[(token, snapshot)] = now + 5
                self.coordinator.logger.record("fabric_native_snapshot_cleanup_deferred", journal=token, error=str(error))
        for token in jobs:
            if self._retry_after.get(token, 0) > now:
                continue
            try:
                self._recover_owners(self.get(token, source=False))
                self.retire(token, idle_only=True)
                self._retry_after.pop(token, None)
            except (ValueError, OSError, StateError, sqlite3.Error, StagingLedgerError, RemoteError, NetworkError) as error:
                self._retry_after[token] = now + 5
                self.coordinator.logger.record("fabric_native_source_cleanup_deferred", journal=token, error=str(error))

    def close(self):
        with self.lock:
            self._closed = True
            jobs = tuple(self._journals.values())
            self._journals.clear()
            if self._discovery_scan is not None:
                self._discovery_scan.close()
                self._discovery_scan = None
        for job in jobs:
            # Shutdown leaves recovery context, snapshots and non-expiring
            # source holds intact. It is never cancellation of pending writes.
            try:
                job.mutate(job.journal.close)
            except (OSError, StateError, sqlite3.Error, StagingLedgerError) as error:
                # No new user write is admitted here. SQLite may leave a WAL
                # on ENOSPC, but every connection still must be closed so the
                # next process can recover the last committed root.
                with job.lock:
                    job.journal.close()
                    try:
                        job.reconcile()
                    except (OSError, StateError, sqlite3.Error, StagingLedgerError):
                        pass
                self.coordinator.logger.record("fabric_native_shutdown_preserved", journal=job.token, error=str(error))


class NativeJournalVersion:
    def __init__(self, pool, job, snapshot, entry):
        self.pool, self.job, self.snapshot, self.entry = pool, job, snapshot, entry
        self.references, self.inflight, self.closed = 1, 0, False

    def stream(self, offset, length):
        if type(offset) is not int or type(length) is not int or offset < 0 or length < 0 or offset + length > self.entry.size_bytes:
            raise ValueError("The native read exceeds its retained version")
        with self.pool.reading(self):
            cursor = offset
            while cursor < offset + length:
                data = self.job.journal.read(cursor, min(1024**2, offset + length - cursor), snapshot=self.snapshot)
                if not data:
                    raise OSError(errno.EIO, "The native journal read ended early")
                yield data
                cursor += len(data)
