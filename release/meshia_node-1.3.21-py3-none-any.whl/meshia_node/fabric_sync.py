"""Continuous, bounded working-set reconciliation for MeshiaFabric.

The local directory is a *materialized working set*, not a mirror.  Remote
metadata is indexed eagerly, while bytes are fetched only by ``stream`` or
``materialize``.  Local watcher events are copied to a private, durable stage
and journalled before any network request.  A single caller drives
``poll_once``; watcher threads only collect metadata events. Signed requests
remain serialized while independent immutable PUTs share a bounded worker pool.

The transport protocol is deliberately narrow.  ``SignedFabricTransport`` can
grow these four small methods without coupling this module to its HTTP client:

* ``changes`` and ``mutate`` are signed JSON POSTs;
* ``blocks`` issues/validates signed block-CAS tickets;
* ``upload_block`` performs one ticket-authorized immutable PUT; signed
  verification remains the only completion authority.

All public digests are raw lowercase SHA-256 strings.  WorkspaceBoundary's
streaming writer is the only exception and receives the explicitly tagged form
it requires.
"""

from __future__ import annotations
from .fabric_contract_generated import file_digest_algorithm, block_file_sha256, FabricFileHasher, FABRIC_BLOCK_FILE_DIGEST_ALGORITHM
from .fabric_contract_generated import FABRIC_FILE_TREE_ALGORITHM
from .fabric_tree_read import FabricTreeReader

import errno
import collections
import base64
import concurrent.futures
import hashlib
import json
import os
import queue
import re
import shutil
import sqlite3
import stat
import threading
import time
import unicodedata
import uuid
from collections import deque
from concurrent.futures import Future
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
import traceback
from typing import Any, Callable, Iterable, Iterator, Mapping, Protocol, Sequence

from .errors import (
    InvalidTask,
    NetworkError,
    RemoteError,
    RetentionCapacityUnavailable,
    StateError,
    UnsafePath,
)
from .fabric import DIRECT_UPLOAD_MAX_ACTIVE, FabricAuthority, UPLOAD_PART_RECEIPT_SCHEMA
from .fabric_contract_generated import (
    FABRIC_BASE_BLOCK_BYTES,
    FABRIC_EMPTY_SHA256,
    FABRIC_MAX_BLOCK_BYTES,
    FABRIC_PARALLEL_UPLOAD_BLOCK_BYTES,
    FABRIC_PARALLEL_UPLOAD_THRESHOLD_BYTES,
    FABRIC_SMALL_TEXT_CDC_MIN_BYTES as SMALL_EDIT_CDC_MIN_BYTES,
    FABRIC_SMALL_TEXT_CDC_CUT_MASK as SMALL_EDIT_CDC_MASK,
    FABRIC_SMALL_TEXT_CDC_MAX_BYTES as SMALL_EDIT_CDC_MAX_BYTES,
    FABRIC_SMALL_TEXT_CDC_MAX_FILE_BYTES as SMALL_EDIT_CDC_FILE_MAX_BYTES,
    FABRIC_SMALL_TEXT_CDC_GEAR_SEED,
    FABRIC_SMALL_TEXT_CDC_GEAR_MASK,
    FABRIC_TARGET_LOCAL_UPLOAD_BLOCKS,
    FABRIC_V2_COHORT_UUID_NAMESPACE,
    FABRIC_V2_MAX_BLOCKS_PER_OP,
    FABRIC_V2_MAX_FILE_BYTES,
    FABRIC_VERDICT_ABSENT_CODES,
    FABRIC_VERDICT_REBASE_CODES,
    FABRIC_VERDICT_TERMINAL_CODES,
    adaptive_upload_block_bytes,
    fabric_v2_request_digest,
    is_small_text_file,
)
from .fabric_cache import FabricCacheError, FabricRangeCache, FetchedRange
from .fabric_object_read import (
    OBJECT_WARM_MIN_BYTES,
    DirectObjectReader,
    ObjectReadStale,
    ObjectReadUnavailable,
)
from .conflict_io import (
    copy_active_conflict_local_to_descriptor,
    keep_both_candidate_path,
)
from .fabric_db import (
    ConflictResolution,
    ConflictView,
    DirectoryPut,
    EvictionIntent,
    FabricDatabase,
    LocalTransferIntent,
    MaterializedEntry,
    PendingOperation,
    QuarantinedCommitUnknown,
    RemoteEntry,
    RemoteManifest,
    RemoteManifestHead,
)
from .fabric_staging import (
    StagingAdmissionExceeded,
    StagingAdmissionLedger,
    StagingLedgerError,
    StagingRepairRequired,
    StagingReservation,
)
from .fabric_transfer import (
    AnchoredLocalSource,
    BlockSpec,
    DirectBatchResult,
    DirectByteTask,
    DirectByteWorkerPool,
    LocalCopyWorker,
    LocalRecoveryCandidate,
    LocalSnapshotJob,
    ReceivedBlock,
    RecoveryDeferred,
    RemoteAssemblyJob,
    SourceDrift,
    SourceFingerprint,
    StagingQuotaExceeded,
    TransferBusy,
    TransferError,
    TransferStore,
    VerifiedStage,
)
from .fabric_watch import (
    DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
    FabricWatch,
    FabricWatchEvent,
)
from .log import NULL_LOGGER, NodeLogger
from .util import (
    RAW_SHA256_RE,
    UUID_RE,
    decode_canonical_b64,
    directory_entry_identity_stat,
    ensure_private_dir,
    write_private_file,
)
from .workspace import (
    FileFingerprint,
    HashedRegularFile,
    MAX_LIST_ENTRIES,
    RETAINED_STORAGE_ACCOUNT_MATERIALIZED_ROW,
    RETIRED_QUARANTINE_MAX_ENTRIES,
    RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX,
    RetiredRegularFile,
    RetiredQuarantinePromotion,
    WorkspaceBoundary,
    retired_quarantine_recovery_path,
)

WORKSPACE_MOUNT = "workspace"
RETIRED_QUARANTINE_MAINTENANCE_SECONDS = 5.0


class StagingRepairPending(StagingQuotaExceeded):
    """A native write must wait for bounded startup staging reconciliation."""


class FileProviderSourceUnavailable(RuntimeError):
    """A durable File Provider put is waiting for the system-owned source FD."""


MANIFEST_SCHEMA = "meshia.connected_host.fabric_manifest.v1"
CHANGES_SCHEMA = "meshia.connected_host.fabric_changes.v1"
RANGE_SCHEMA = "meshia.connected_host.fabric_range.v1"
BLOCK_WRITE_SCHEMA = "meshia.connected_host_fabric_block_write_batch.v1"
BLOCK_READ_SCHEMA = "meshia.connected_host_fabric_block_read_batch.v1"
BLOCK_VERIFY_SCHEMA = "meshia.connected_host_fabric_block_verification.v1"
MANIFEST_BLOCKS_SCHEMA = "meshia.connected_host.fabric_manifest_blocks.v1"
MUTATION_SCHEMA = "meshia.connected_host.fabric_mutation.v1"
MUTATION_STATUS_SCHEMA = "meshia.connected_host.fabric_mutation_status.v1"
MUTATION_BATCH_SCHEMA = "meshia.connected_host.fabric_mutation_batch.v1"
LEGACY_OBJECT_CAS_KIND = "object_cas_v1"
CONNECTED_HOST_OBJECT_CAS_KIND = "connected_host_object_cas_v1"
READABLE_OBJECT_CAS_KINDS = frozenset(
    (LEGACY_OBJECT_CAS_KIND, CONNECTED_HOST_OBJECT_CAS_KIND)
)

MANIFEST_PAGE_SIZE = 1_000
MANIFEST_PAGE_MIN_INTERVAL_SECONDS = 0.5
CHANGE_PAGE_SIZE = 128
# Fabric v2 refresh. A change record is one path, not a whole manifest
# generation, so a page can be much larger than v1's for the same bytes.
V2_CHANGES_SCHEMA = "meshia.fabric_v2.changes.v1"
V2_SNAPSHOT_SCHEMA = "meshia.fabric_v2.snapshot.v1"
V2_CHANGE_PAGE_SIZE = 500
V2_SNAPSHOT_PAGE_SIZE = 1_000
# One directory rename record can name an arbitrarily large subtree, so the
# local expansion reads it in bounded pages rather than one query.
V2_SUBTREE_PAGE_SIZE = 10_000
MAX_REMOTE_FILES = 250_000
LEGACY_CONTENT_MISSING_REPAIR_LIMIT = 8
LEGACY_CONTENT_MISSING_ERROR = (
    "The Fabric file manifest exists but its content is unavailable."
)
REMOTE_INTENT_RESTORE_BATCH = 100_000
BLOCK_BYTES = FABRIC_BASE_BLOCK_BYTES
MAX_CAS_BLOCK_BYTES = FABRIC_MAX_BLOCK_BYTES
# Opening one large plain object warms tickets for its siblings too.
OBJECT_WARM_SIBLING_LIMIT = 32
BACKGROUND_TRANSFER_THRESHOLD_BYTES = BLOCK_BYTES
MANIFEST_BLOCK_PAGE_SIZE = 2_048
# Server-side commit verification deliberately caps one mutation at 8,192
# unique blocks so signed JSON and HEAD verification stay bounded. Private
# snapshot assembly stays fixed at 4 MiB (32 GiB total); source-backed uploads
# adapt through 64 MiB (512 GiB total) under the same bounded manifest shape.
MAX_MANIFEST_BLOCKS = FABRIC_V2_MAX_BLOCKS_PER_OP
# Small source-backed uploads use a few dozen immutable extents so every
# stream carries enough bytes to amortize its PUT handshake. Once a file is
# large enough for transfer throughput to dominate control latency, use 16-MiB
# extents while the manifest bound permits it. Eight such PUTs fill, but never
# exceed, the process-wide 128-MiB payload budget; a 64-MiB extent would
# collapse the same lane to two HTTP streams. The 8,192-entry manifest ceiling
# still raises the extent size to 32/64 MiB for files above 128/256 GiB.
TARGET_LOCAL_UPLOAD_BLOCKS = FABRIC_TARGET_LOCAL_UPLOAD_BLOCKS
PARALLEL_SOURCE_UPLOAD_THRESHOLD_BYTES = FABRIC_PARALLEL_UPLOAD_THRESHOLD_BYTES
PARALLEL_SOURCE_UPLOAD_BLOCK_BYTES = FABRIC_PARALLEL_UPLOAD_BLOCK_BYTES
MAX_SYNC_FILE_BYTES = MAX_MANIFEST_BLOCKS * BLOCK_BYTES
# Large local files use adaptive 4..64-MiB canonical CAS extents and never
# enter TransferStore's full-copy snapshot lane.  This is the largest file the
# existing server's 8,192-block mutation contract can publish without a new
# hierarchical manifest format.
MAX_LOCAL_UPLOAD_FILE_BYTES = FABRIC_V2_MAX_FILE_BYTES
MAX_REMOTE_FILE_BYTES = 1 << 40
# The server can index larger remote-only objects.  TransferStore deliberately
# stays at 8,192 fixed blocks so one edge staging job is bounded to 32 GiB, but
# metadata validation must not reject the server's wider namespace contract.
MAX_REMOTE_MANIFEST_BLOCKS = 131_072
DEFAULT_MAX_EVENTS_PER_TICK = 64
DEFAULT_MAX_MUTATIONS_PER_TICK = 1
# A tick may issue this many signed mutation turns while a backlog is ready.
# One-per-tick made the runner's idle interval a per-batch tax; these bounds
# keep a bulk drain proportional to the work while still yielding promptly.
MAX_MUTATION_TURNS_PER_TICK = 32
MUTATION_DRAIN_BUDGET_SECONDS = 5.0
# A maintenance turn longer than this is logged with its stage timeline
# (``fabric_sync_turn_slow``). Sampling the live node stalls FUSE-T, and the
# 29-35 s turns that delayed shutdown on 2026-09-02/03 were never attributed
# to a stage; this record names it next time.
FABRIC_SLOW_TURN_SECONDS = 5.0
# One signed mutate_batch call commits up to this many ready, path-independent
# operations (the server bound). It still counts as the tick's one signed
# mutation-side control request.
DEFAULT_MAX_BATCH_MUTATIONS = 64
# Ticket admission is item-local and ordered inside M1747 (measured at about
# 1.4 s/item). Keep the active PUT's synchronous admission wave to one
# companion: this halves request/auth overhead without making first byte wait
# behind a whole folder. Later pairs are admitted progressively as the current
# byte wave completes.
MAX_PROGRESSIVE_WRITE_TICKET_ITEMS = 2
BATCH_BACKOFF_AFTER_FAILURES = 2
BATCH_GROW_AFTER_SUCCESSES = 2
# While more uploads are pending, ready commits accumulate so a folder drop
# becomes one batch call; a ready commit never waits longer than this for
# companions, and never waits at all when nothing else is uploading.
BATCH_COMMIT_MAX_WAIT_SECONDS = 30.0
# V2 publishes independent paths without rebuilding the workspace manifest.
# Holding already-uploaded files for the v1 30s window makes a continuous
# folder copy look stalled. Keep a short coalescing bound even while unrelated
# files still need bytes; full cohorts still leave immediately.
V2_BATCH_COMMIT_MAX_WAIT_SECONDS = 2.0
# A signed BASE_DIVERGED refresh has already paid the full-manifest cost. Rebase
# a bounded SQLite-only burst while preserving the one wire mutation per tick.
BASE_DIVERGED_REBASE_BATCH = 256
# FABRIC_MUTATION_BASE_INVALID is the control plane rejecting the *shape* of a
# request's base pair -- generation zero with a digest, or a later generation
# without one -- strictly before publication. That is almost always a stale
# belief about the remote head (a wiped or regenerated workspace resets the
# generation under a node still holding the old one), which an authoritative
# full head read plus a retry repairs. But the same code also covers a base
# this client genuinely built wrong, and no number of refreshes can repair
# that, so the refresh route is deliberately bounded: after this many
# refresh-and-retry rounds without a commit the operation takes the ordinary
# terminal conflict, with a reason that says the base is malformed rather
# than stale. Small on purpose -- a real head refresh converges on the first
# round; the extra rounds only cover a refresh that raced a concurrent write.
MAX_BASE_INVALID_REFRESH_ATTEMPTS = 3
# Read-ticket control requests may contain up to 64 immutable block
# descriptors. Upload issuance and verification accept up to 256 provider
# objects per signed request (M1735), so one control turn authorizes 4 GiB of
# 16-MiB extents and a commit proves a whole file in one call. Payload
# residency is independently capped at 128 MiB by adaptive worker
# concurrency, so a ticket wave never materializes its bytes together.
DEFAULT_MAX_BLOCKS_PER_TICK = 64
MAX_VERIFY_BLOCKS_PER_REQUEST = 256
# Inline small-block commits: blocks at or under this many bytes may ride
# base64-encoded inside the mutate_batch request itself; the control plane
# performs the canonical CAS PUTs, removing the ticket/PUT/receipt/verify
# round trips a small file otherwise pays. MESHIA_INLINE_BLOCK_MAX_BYTES
# overrides (0 disables). The per-request budget mirrors the server bound.
INLINE_BLOCK_MAX_BYTES_DEFAULT = 262_144
INLINE_BATCH_MAX_BYTES = 3 * 1024 * 1024
# Ceiling for the SERIALIZED request, which is what the edge actually rejects
# with 413. Inline bytes are only part of it: every item also carries its own
# manifest preimage, whose size grows with the whole workspace namespace, so a
# folder drop in a large workspace can blow the body limit on manifests alone
# while the inline budget still looks fine. Measured live: two consecutive
# batches rejected PAYLOAD_TOO_LARGE, and because 413 had no handler the same
# oversized request rebuilt forever and stalled 45 of 60 files.
BATCH_REQUEST_MAX_WIRE_BYTES = 3_500_000
# Floor for the adaptive shrink so a pathological item cannot spin.
BATCH_REQUEST_MIN_WIRE_BYTES = 512 * 1024
# A lone inline-eligible put waits this briefly for companions, then rides a
# one-item batch; it must never degrade to the classic ticket-wave path while
# inline batching is available.
INLINE_SINGLE_FLUSH_SECONDS = 0.75
# Arrival quiescence for inline cohorts: every newly seen inline-ready item
# restarts the flush window, so a Finder-style burst (files landing a few
# hundred ms apart) coalesces into ONE batch instead of splitting the moment
# two are ready. The coalesce cap bounds the total hold so a continuous
# stream still flushes rolling batches, far inside the 10 s wave valve.
INLINE_COALESCE_MAX_SECONDS = 3.0
# Safety valve: released only when the inline lane makes NO progress for this
# long (batch lane degraded, repeated rejections). It is measured from the
# lane's last successful batch, not from the put's arrival: a busy lane commits
# batches that legitimately take longer than this window (measured live:
# 10.7-16.5 s for 9-17 item batches), and an arrival-relative valve dumped
# every waiting put to the classic ticket path while a batch was in flight --
# inline could never win under real server latency.
INLINE_HOLD_MAX_SECONDS = 10.0
# Absolute ceiling from a put's arrival, regardless of lane progress, so a
# permanently starved put (always out-budget behind bigger cohorts) still
# reaches the provider instead of waiting forever.
INLINE_HOLD_ABSOLUTE_MAX_SECONDS = 120.0
# A control plane that rejects the inline field outright (an older deployment)
# disables the lane, but only for this long: a transient or self-inflicted
# rejection must never poison a long-lived process, so the lane re-probes.
INLINE_DISABLE_REPROBE_SECONDS = 300.0
# The REAL server limit, not a guess: the connected-host dispatcher reads at
# most this many bytes of signed request body and answers 413 PAYLOAD_TOO_LARGE
# above it (web/app/api/connected-hosts/[hostId]/fabric/route-support.ts,
# `MAX_SIGNED_JSON_BODY_BYTES`; `readBoundedUtf8Body` throws at both the
# content-length pre-check and the streamed total). It is OUR OWN check ahead of
# the RPC -- not Vercel's 4.5 MB body cap and not a PostgREST limit. Size cohorts
# against this, do not rediscover it by tripping a 413 every cohort.
EDGE_SIGNED_BODY_MAX_BYTES = 1_450_000
# Ceiling for the SERIALIZED v2 commit request the client aims for: the real
# edge limit above minus headroom for the signing envelope, JSON escaping, and
# estimate error. base64 costs a third on top of every inline byte, so the raw
# byte budget alone does not predict the wire size -- the v1 lane learned this
# the expensive way (two consecutive PAYLOAD_TOO_LARGE batches that rebuilt
# forever and stalled 45 of 60 files).
V2_COMMIT_REQUEST_MAX_WIRE_BYTES = 1_200_000
# Floor for the adaptive shrink, so a pathological cohort cannot spin.
V2_COMMIT_REQUEST_MIN_WIRE_BYTES = 256 * 1024
# Serialized size of one v2 put op with a single-block descriptor: path,
# digest, size and the block list. Used only to reserve room for the ops when
# budgeting inline bytes, so a slightly generous estimate is the safe error.
V2_OP_WIRE_ESTIMATE_BYTES = 512
# The server's per-commit op ceiling. ``fabric_commit_v2_1762`` rejects a
# request whose ``jsonb_array_length(p_ops)`` is not BETWEEN 1 AND 1024
# (web/migrations/1764-fabric-v2-log-structured-core.sql), and the edge route
# (web/app/api/connected-hosts/[hostId]/fabric/v2-commit/route.ts, maxDuration
# 120) sizes its body ceiling to "cover a 1024-op cohort". The BULK lane --
# cohorts whose blocks were uploaded separately, so each op is a bare
# descriptor (~V2_OP_WIRE_ESTIMATE_BYTES) -- can safely carry that many:
# 1024 * 512 B ~= 512 KiB, comfortably under V2_COMMIT_REQUEST_MAX_WIRE_BYTES.
# The INLINE lane stays at DEFAULT_MAX_BATCH_MUTATIONS because its base64 body
# is bytes-bound long before 1024 items (a 64-item cohort of 16-KiB files
# already fills the 1.2 MB wire budget), and the inline op-overhead reservation
# in `_effective_inline_request_budget_bytes` subtracts exactly that count.
SERVER_MAX_V2_COMMIT_OPS = 1024
# Extra wire a bulk op pays per block descriptor beyond the first (the first is
# already inside V2_OP_WIRE_ESTIMATE_BYTES). A put of a large file lists every
# block, so one such op can be far larger than the flat estimate; the bulk
# selector adds this per additional block so an unusually large-descriptor
# cohort trims itself below the wire budget rather than being 413'd at the edge.
V2_OP_BLOCK_WIRE_ESTIMATE_BYTES = 128
# JSON escaping roughly doubles worst-case bytes; 1.5x is a safe generous factor
# for the path/destination strings a v2 op carries.
V2_OP_PATH_WIRE_FACTOR_NUM = 3
V2_OP_PATH_WIRE_FACTOR_DEN = 2
# Per inline_blocks[] wrapper: the sha256/size_bytes/bytes_b64 keys and braces
# around each carried block's base64 payload.
V2_INLINE_ENTRY_ENVELOPE_BYTES = 128
# The control plane rejects any v2 commit that would need more than this many
# UNPROVEN-block readbacks -- blocks the ops name that are not yet registered in
# fabric_blocks_1771 -- with FABRIC_BLOCK_PROOF_REQUIRED (fast, nothing
# applied): "This commit would need N block readbacks, above the 256 one commit
# may spend. Verify the blocks before committing." It counts BLOCKS, not ops.
# A node bulk cohort (deletes/renames/already-verified puts) carries zero
# unproven blocks, so this rarely binds it; but the selector caps every v2
# cohort by it, and a FABRIC_BLOCK_PROOF_REQUIRED reply shrinks the lane like a
# 413, so an unusually block-heavy cohort chunks rather than looping forever.
FABRIC_V2_MAX_COMMIT_READBACKS = 256
# Gateway/timeout statuses on the v2 commit route (the RunPod/Cloudflare proxy
# cuts a slow control call: 524 is CF "origin timeout", 522 "connection timed
# out"; 502/503/504/408 are the ordinary gateway family). A big cohort that
# overruns the route deadline must SHRINK its item cap and re-ride, never
# re-plan the identical oversized request forever.
_V2_COMMIT_GATEWAY_TIMEOUT_STATUSES = frozenset({408, 502, 503, 504, 522, 524})
# Bounded room for the per-block reasons a failed direct batch reports.
_MAX_DIRECT_BATCH_REASON_BYTES = 2_000


def _inline_block_max_bytes_from_env() -> int:
    raw = os.environ.get("MESHIA_INLINE_BLOCK_MAX_BYTES")
    if raw is None or not raw.strip():
        return INLINE_BLOCK_MAX_BYTES_DEFAULT
    try:
        value = int(raw.strip())
    except ValueError:
        return INLINE_BLOCK_MAX_BYTES_DEFAULT
    if value <= 0:
        return 0
    return min(value, MAX_CAS_BLOCK_BYTES)
# Stable namespace for deriving a v2 cohort id from its request digest, so a
# retry of the same cohort replays rather than re-applies.
_FABRIC_V2_COHORT_NAMESPACE = FABRIC_V2_COHORT_UUID_NAMESPACE


def _fabric_v2_enabled_from_env() -> bool:
    """Whether this process commits through the Fabric v2 log-structured path.

    ON BY DEFAULT. v1 -- what this used to select -- sends a whole-namespace
    manifest preimage with every single file, so a folder drop is O(N^2), and
    because that preimage is bounded at 8 MiB it becomes a hard 10,000-file
    ceiling past which every later mutation fails with
    FABRIC_MUTATION_NAMESPACE_TOO_LARGE. An 80,000-file folder cannot complete
    on v1 at any speed. Only a recognized off value now selects it, and only as
    an escape hatch.

    Defaulting v2 on was blocked by eight failures in correctness-critical
    areas -- multi-process convergence, conflict fencing, and
    restart/authority rotation. Those were three real v2 defects, all of the
    same shape: the lanes are not interchangeable, and every place that
    assumed they were lost data-liveness.

      1. Only the commit path latched on an explicit 404. changes_v2 and
         snapshot_v2 retried the same 404 forever and could not fall back.
      2. The lanes hash different documents into one request_digest column
         (_mutation_request_digest vs _fabric_v2_request_digest), so a v2
         fence left behind by that 404 was unmatchable by the v1 retry -- the
         operation became unroutable on every lane, forever, restarts
         included.
      3. A crash mid-v2-commit was resolved by the v1 readback lane, which
         asks a status route that cannot know a v2 cohort id and then compares
         a rebuilt v1 document against a v2 digest. That never matches, so
         every such crash terminally conflicted the file.

    All three are fixed and neutralization-verified. The full node suite then
    ran with v2 forced on against pristine main with v2 off: 6 failed / 2564
    passed versus 7 failed / 2560 passed, and the six are a strict SUBSET of
    main's seven. v2 contributes no failure of its own.

    The rollout safety property does not depend on this switch: capability is
    proven by an explicit 404 from the route itself, so a node meeting an
    older control plane latches v2 off for the process, releases the
    unroutable fence, and completes the work on v1. Detection stays an
    explicit 404 and never a generic 400, which is indistinguishable from "our
    request was malformed" and which silently disabled the inline lane for a
    whole process once already.
    """

    raw = os.environ.get("MESHIA_FABRIC_V2")
    if raw is None:
        return True
    # Only a recognized off value takes the capped v1 path. An unset, empty,
    # or unrecognized value keeps the default rather than silently reinstating
    # the 10,000-file ceiling on a typo.
    return raw.strip().lower() not in {"0", "false", "no", "off"}


# Remote applies (hydration/rename application) per maintenance tick. Owner
# decision 2026-09-03: make the read side match the 8-wide write lane
# (UPLOAD_WORKER_CONCURRENCY) so a burst of remote changes lands in one
# turn instead of two files per turn.
DEFAULT_MAX_REMOTE_APPLIES_PER_TICK = 8
# The materialized-root budget. This is a CACHE bound, not a quota on what the
# user may own: the root lives inside private node state
# (~/.meshia/.../materialized-root), every byte in it that is clean and present
# in the remote manifest is re-fetchable, and the mount hydrates a miss on
# demand. It was a fixed 2 GiB with no override, which meant any workspace
# larger than 2 GiB permanently refused every hydration -- measured live at
# 3,392 MB and 10,249 MB on two real workspaces. Scale it with the volume
# instead, so a big disk caches more and a small disk caches less, and keep
# the free-space reserve (min_staging_free_bytes) as the real hard stop.
MATERIALIZED_BUDGET_VOLUME_FRACTION = 0.25
MATERIALIZED_BUDGET_FREE_FRACTION = 0.5
MATERIALIZED_BUDGET_FLOOR_BYTES = 8 * 1024 * 1024 * 1024
MATERIALIZED_BUDGET_CEILING_BYTES = 512 * 1024 * 1024 * 1024
# Used only when the destination volume cannot be measured at all.
DEFAULT_MAX_MATERIALIZED_BYTES = MATERIALIZED_BUDGET_FLOOR_BYTES
_GB = 1000 * 1000 * 1000


@dataclass(frozen=True)
class MaterializedCachePolicy:
    """One resolved decision about how much local cache this device may hold.

    ``limit_bytes`` is a CACHE TARGET, not a per-file cap. A single file larger
    than the whole limit is admitted after reclaiming everything reclaimable:
    the device free-space reserve is the only hard stop outside the emergency
    tier, because refusing a read of durable content while reclaimable space
    exists is never the right answer.
    """

    tier: str
    limit_bytes: int
    low_water_bytes: int
    #: Evict clean, re-fetchable content untouched for longer than this even
    #: when usage is under the limit. ``None`` disables the idle sweep.
    idle_evict_seconds: float | None
    maintenance_interval_seconds: float
    #: Ceiling on AUTOMATIC (prefetch) selection. The emergency tier sets this
    #: to zero: under real disk pressure Meshia stops speculatively pulling
    #: content down, while an explicit read is still always served.
    auto_materialization_bytes: int
    enforced: bool = True


# Free-space tiers, worst-first. ``enter`` is the free-byte level at or below
# which the tier engages; ``exit`` is the level the device must reach to leave
# it again. The gap between them is the hysteresis band that stops a device
# hovering on a threshold from flapping between eviction cadences.
#
#   emergency  <  5 GB free, leaves at >=  8 GB. Below ~5 GB macOS itself
#                 starts failing (swap, local snapshots); reclaim everything
#                 and refuse rather than thrash a dying disk.
#   aggressive < 15 GB free, leaves at >= 20 GB. The owner's stated trigger.
#                 5 GB of hysteresis is about one large model file, so ordinary
#                 churn cannot flip the tier.
#   constrained< 50 GB free, leaves at >= 65 GB. 15 GB gap, proportionally the
#                 same shape one tier up.
#   healthy      everything else.
MATERIALIZED_TIERS: tuple[tuple[str, int, int], ...] = (
    ("emergency", 5 * _GB, 8 * _GB),
    ("aggressive", 15 * _GB, 20 * _GB),
    ("constrained", 50 * _GB, 65 * _GB),
    ("healthy", 1 << 62, 1 << 62),
)
_TIER_ORDER = {name: index for index, (name, _enter, _exit) in enumerate(MATERIALIZED_TIERS)}
_DAY = 24 * 60 * 60
# How long a device capacity sample stays usable. Admission always takes a
# fresh one; this only spares the background maintenance lane a statvfs per
# tick.
VOLUME_SAMPLE_TTL_SECONDS = 2.0
# Free-space tiers are stated in absolute GB, which is meaningless on a volume
# smaller than the smallest threshold. Below this, skip tiering and use the
# volume-scaled default. Every real machine this ships to is far above it; the
# case this excludes is a synthetic capacity fixture.
MIN_TIERED_VOLUME_BYTES = 16 * 1024**3


def _clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))


def _materialized_cache_policy(
    tier: str, *, total_bytes: int, free_bytes: int
) -> MaterializedCachePolicy:
    """Resolve the cache policy for one tier against one capacity sample."""

    if tier == "emergency":
        # Hold no cache at all, reclaim every re-fetchable copy, and stop
        # prefetching. Deliberately NOT a blanket refusal of materialization:
        # a write the device can physically take must still succeed. Refusing
        # by policy would resurrect the exact defect the free-space reserve
        # comment records -- a proportional reserve that "stranded roughly
        # 50 GiB and rejected even a one-byte remote file" -- and it would
        # contradict the rule that a durable read never fails while the disk
        # has room. The free-space reserve stays the hard stop; it already
        # raises a truthful, retryable error.
        return MaterializedCachePolicy(
            tier="emergency",
            limit_bytes=0,
            low_water_bytes=0,
            idle_evict_seconds=0.0,
            # Frequent, but still a cadence: a maintenance pass on literally
            # every poll starves the byte workers that share this process.
            maintenance_interval_seconds=1.0,
            auto_materialization_bytes=0,
        )
    if tier == "aggressive":
        limit = _clamp(
            min(int(free_bytes * 0.25), 8 * 1024**3), 1 * 1024**3, 8 * 1024**3
        )
        return MaterializedCachePolicy(
            tier="aggressive",
            limit_bytes=limit,
            low_water_bytes=int(limit * 0.70),
            idle_evict_seconds=float(_DAY),
            maintenance_interval_seconds=15.0,
            auto_materialization_bytes=min(limit, 256 * 1024**2),
        )
    if tier == "constrained":
        limit = _clamp(
            min(int(total_bytes * 0.10), int(free_bytes * 0.33)),
            4 * 1024**3,
            64 * 1024**3,
        )
        return MaterializedCachePolicy(
            tier="constrained",
            limit_bytes=limit,
            low_water_bytes=int(limit * 0.90),
            idle_evict_seconds=float(7 * _DAY),
            maintenance_interval_seconds=60.0,
            auto_materialization_bytes=min(limit, 1024**3),
        )
    limit = _default_max_materialized_bytes(total_bytes, free_bytes)
    return MaterializedCachePolicy(
        tier="healthy",
        limit_bytes=limit,
        low_water_bytes=limit,
        idle_evict_seconds=float(30 * _DAY),
        maintenance_interval_seconds=300.0,
        auto_materialization_bytes=min(limit, DEFAULT_MAX_AUTO_MATERIALIZED_BYTES),
    )


def _next_materialized_tier(current: str | None, free_bytes: int) -> str:
    """Pick the tier for ``free_bytes``, honouring hysteresis in both directions.

    A tier engages the moment free space drops to its ``enter`` level, so
    pressure is never ignored. Leaving requires clearing the higher ``exit``
    level, so a device sitting on a threshold cannot oscillate between
    eviction cadences.
    """

    indicated = "healthy"
    for name, enter, _exit in MATERIALIZED_TIERS:
        if free_bytes < enter:
            indicated = name
            break
    if current is None or _TIER_ORDER[indicated] < _TIER_ORDER[current]:
        # First sample, or pressure increased: engage without hysteresis.
        return indicated
    if indicated == current:
        return current
    # Pressure eased. Hold the current tier until its exit level is cleared.
    _name, _enter, exit_bytes = MATERIALIZED_TIERS[_TIER_ORDER[current]]
    if free_bytes < exit_bytes:
        return current
    return indicated
MAX_MATERIALIZED_BYTES_ENV = "MESHIA_MAX_MATERIALIZED_BYTES"
_BYTE_BUDGET_RE = re.compile(r"\A(\d+)\s*([KMGT]?)(?:I?B)?\Z", re.IGNORECASE)
_BYTE_BUDGET_SCALE = {
    "": 1,
    "K": 1024,
    "M": 1024**2,
    "G": 1024**3,
    "T": 1024**4,
}
# fabric_db validates every budget it is handed against this same ceiling.
MAX_MATERIALIZED_BYTES_CEILING = 1 << 60


def _parse_byte_budget(raw: str, name: str) -> int:
    """Parse a byte budget, accepting an optional KiB/MiB/GiB/TiB suffix.

    Nonsense is rejected rather than silently ignored: an operator who sets
    this has an intent, and quietly falling back to a default would reproduce
    the exact class of bug this setting exists to fix -- a cache bound nobody
    can see or change.
    """

    match = _BYTE_BUDGET_RE.match(raw.strip())
    if match is None:
        raise ValueError(
            f"{name} must be a non-negative byte count, optionally suffixed "
            f"with K, M, G, or T (got {raw!r})."
        )
    value = int(match.group(1)) * _BYTE_BUDGET_SCALE[match.group(2).upper()]
    if value > MAX_MATERIALIZED_BYTES_CEILING:
        raise ValueError(
            f"{name} must not exceed {MAX_MATERIALIZED_BYTES_CEILING} bytes."
        )
    return value


def _max_materialized_bytes_from_env() -> int | None:
    """Return the operator override for the cache budget, if one is set."""

    raw = os.environ.get(MAX_MATERIALIZED_BYTES_ENV)
    if raw is None or not raw.strip():
        return None
    return _parse_byte_budget(raw, MAX_MATERIALIZED_BYTES_ENV)


def _measured_volume_bytes(disk_usage: Any, root: Any) -> tuple[int, int] | None:
    """Return ``(total, free)`` for the destination volume, or ``None``."""

    try:
        usage = disk_usage(root)
        total = usage.total
        free = usage.free
    except (AttributeError, OSError, TypeError, ValueError):
        return None
    for value in (total, free):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            return None
    if total <= 0 or free > total:
        return None
    return total, free


def _default_max_materialized_bytes(
    total_bytes: Any, free_bytes: Any = None
) -> int:
    """Scale the default cache budget with the destination volume.

    Two signals, because either alone gets a real machine wrong. A fraction of
    the whole volume says how much of this disk Meshia may ever use; a fraction
    of what is free right now keeps a nearly-full disk from planning to cache
    more than it can hold. The owner's Mac is 926 GB with 26.8 GB free (98%
    full): volume alone would authorize ~231 GB of cache it can never have.
    The floor keeps a small or crowded disk usable at all -- the per-write
    free-space reserve, not this number, is the hard stop there.
    """

    if (
        isinstance(total_bytes, bool)
        or not isinstance(total_bytes, int)
        or total_bytes <= 0
    ):
        return DEFAULT_MAX_MATERIALIZED_BYTES
    scaled = int(total_bytes * MATERIALIZED_BUDGET_VOLUME_FRACTION)
    if (
        not isinstance(free_bytes, bool)
        and isinstance(free_bytes, int)
        and free_bytes >= 0
    ):
        scaled = min(scaled, int(free_bytes * MATERIALIZED_BUDGET_FREE_FRACTION))
    return max(
        MATERIALIZED_BUDGET_FLOOR_BYTES,
        min(MATERIALIZED_BUDGET_CEILING_BYTES, scaled),
    )


DEFAULT_MAX_AUTO_MATERIALIZATIONS = 10_000
# Automatic first-attach/refresh selection keeps the historical conservative
# bound. Raising the CACHE ceiling must not turn attach into an eager
# whole-workspace download onto a disk that may be nearly full (the owner's Mac
# has 26.8 GB free of 926 GB); on-demand reads and explicit materialization
# still get the full budget, and the cache is what eviction now manages.
DEFAULT_MAX_AUTO_MATERIALIZED_BYTES = 2 * 1024 * 1024 * 1024
# Bounded coalescing map of "this path was opened" observations awaiting a
# durable accessed_at_ns stamp. Mount threads must never block on SQLite.
MAX_PENDING_ACCESS_TOUCHES = 10_000
# One maintenance pass evicts at most this many idle entries, so a huge cold
# working set is reclaimed over several ticks instead of stalling one.
MAX_IDLE_EVICTIONS_PER_PASS = 256
DEFAULT_MAX_STAGING_BYTES = 8 * 1024 * 1024 * 1024
LOCAL_FILE_UNSUPPORTED_CODE = "local_file_present_but_unsupported"
LOCAL_FILE_UNSUPPORTED_REMEDIATION = (
    "move the file outside Meshia or split it into files no larger than 512 GiB"
)
DEFAULT_MIN_STAGING_FREE_BYTES = 512 * 1024 * 1024
# Admission accounts for every Meshia byte before writing it. A percentage of
# the whole volume is therefore not a useful safety margin: on a 1 TiB Mac it
# stranded roughly 50 GiB and rejected even a one-byte remote file. Keep one
# bounded emergency cushion while still requiring the full incoming/staged
# high-water mark to fit.
DEFAULT_MIN_STAGING_FREE_FRACTION = 0.0
ACKED_STAGE_CLEANUP_BATCH = 256
CONFLICT_RECOVERY_CANDIDATE_LIMIT = 64
ORPHAN_STAGE_SCAN_MAX_ENTRIES = 4_096
ORPHAN_STAGE_GRACE_SECONDS = 300.0
ORPHAN_STAGE_SCAN_INTERVAL_SECONDS = 60.0
MIN_REMOTE_POLL_SECONDS = 1.0
MAX_REMOTE_POLL_SECONDS = 2.0
# While a push stream reports remote changes, idle remote polling stretches to
# this backstop; local work keeps the urgent MIN cadence regardless.
PUSH_REMOTE_POLL_BACKSTOP_SECONDS = 60.0
MAX_ERROR_POLL_SECONDS = 30.0
DIRECT_BATCH_TIMEOUT_SECONDS = 300.0
DIRECT_TICKET_EXPIRY_GUARD_SECONDS = 5.0
DIRECT_TICKET_BOOTSTRAP_BYTES = BLOCK_BYTES
DIRECT_TICKET_BATCH_BLOCKS = 64
OPERATION_RETRY_BASE_SECONDS = 1.0
OPERATION_RETRY_MAX_SECONDS = 30.0
# How many times the SAME oversized v2 commit request (identical digest) may be
# rejected and re-armed before the cohort is failed terminally instead of
# retried again. A shrink that makes the request smaller hashes to a new digest
# and resets the streak, so this only bites a request that cannot get smaller --
# the hot loop that hammered `fabric_commit_v2` with a guaranteed 400 at RPC
# rate. Six identical rejections, each backed off by `_operation_retry_delay`,
# span ~a minute before the terminal verdict; the old path had no ceiling at all.
V2_COMMIT_OVERSIZED_RETRY_CEILING = 6
QUOTA_PUT_PARK_SECONDS = 300.0
_IO_BYTES = 1024 * 1024
# Legacy and packed objects lack direct immutable block descriptors. Use one
# bounded 8 MiB authenticated range per coordinator turn: large enough to avoid
# multi-hour fallbacks, small enough to cap base64 response memory near 11 MiB
# and keep heartbeat/control work interleaved between provider reads.
LEGACY_RANGE_TRANSFER_BYTES = 8 * _IO_BYTES
# Server cap for one signed range read (CONNECTED_HOST_FABRIC_MAX_FILE_BYTES).
MAX_SIGNED_RANGE_BYTES = _IO_BYTES
MAX_UPLOAD_PROGRESS_BYTES = 4 * 1024 * 1024
MAX_MUTATION_LIVE_FILES = 10_000

# ---------------------------------------------------------- Fabric v2 verdicts
#
# The v2 commit RPC (migration 1764) answers 200 with one verdict per op, and
# `_send_commit_v2` lifts each rejection into a RemoteError so the single
# rejection lane classifies it. Every one of these codes used to be unknown to
# `_is_mutation_conflict` and `_is_transient_remote_error`, so all of them fell
# through to the terminal `else` -- meaning ANY per-path rejection permanently
# conflicted that file. Observed live: unlink() returned success while the
# entry stayed in the local view forever and rmdir failed ENOTEMPTY.
#
# Recoverable by refreshing the authority and rebasing onto what it actually
# holds. FABRIC_PATH_DIVERGED is the per-path CAS miss -- the exact v2
# analogue of FABRIC_MUTATION_BASE_DIVERGED. FABRIC_PATH_EXISTS is a
# create-where-something-exists, which the same rebase resolves.
FABRIC_V2_REBASE_CODES = FABRIC_VERDICT_REBASE_CODES
# Recoverable by refreshing remote state: a rename whose source the authority
# no longer holds. A *delete* answered FABRIC_PATH_ABSENT never reaches this
# classifier -- absence is the state a delete asked for, so `_send_commit_v2`
# acknowledges it as applied.
FABRIC_V2_REFRESH_CODES = FABRIC_VERDICT_ABSENT_CODES
# The ONLY verdict codes that may terminate an operation on sight. Each
# describes a request that cannot apply unchanged -- malformed operations and
# digests, illegal destinations, or a rename destination that is already
# occupied -- so no refresh can make the same operation apply. Terminal is a
# claim about the future, and a node may only make that claim about codes it
# actually knows: everything else, including a verdict carrying no code at all,
# is retried under a bound. Otherwise shipping one new server-side code would
# silently strand user files on every older node.
FABRIC_V2_TERMINAL_VERDICT_CODES = FABRIC_VERDICT_TERMINAL_CODES
#
# How many times one operation may cycle through v2 path recovery before its
# rejection is recorded as an honest conflict. Refresh+rebase is the right
# answer to a genuine race, but a code that recurs forever must terminate
# rather than livelock the mutation lane.
MAX_V2_PATH_RECOVERY_ATTEMPTS = 6
MAX_DEFERRED_DIRECTORY_EVENT_PATHS = 2 * MAX_MUTATION_LIVE_FILES
MAX_MUTATION_PREIMAGE_BYTES = 8 * 1024 * 1024
MAX_DIRECTORY_RENAME_DELTA_BYTES = 2 * 1024 * 1024
MUTATION_PREIMAGE_HEADER_MARGIN_BYTES = 2_048
MUTATION_PREIMAGE_ENTRY_MARGIN_BYTES = 16
DIRECTORY_RENAME_DELTA_HEADER_MARGIN_BYTES = 8 * 1024
WRITE_TICKET_TTL_SECONDS = 300
MAX_WRITE_TICKET_LIFETIME_SECONDS = 900
UPLOAD_TICKET_EXPIRY_GUARD_SECONDS = 60.0
UPLOAD_TICKET_HARD_GUARD_SECONDS = 5.0
UPLOAD_WORKER_CONCURRENCY = 8
if UPLOAD_WORKER_CONCURRENCY > DIRECT_UPLOAD_MAX_ACTIVE:
    raise RuntimeError("upload workers exceed the direct upload deadline slots")
# Source-backed planning hashes extents on a small pool while the file digest
# streams on the planner thread; bounded so a plan holds a few extents at most.
SOURCE_PLAN_HASH_WORKERS = 4
# Source-backed planning hashes the WHOLE file before its upload is authorized,
# so a large drop is silent for the entire pass -- measured at about 0.84 ms per
# MiB, i.e. roughly half a minute for a 30 GB file with a warm cache, and longer
# from cold disk. Two events used to bracket that pass with nothing in between,
# which is indistinguishable from a hang. Emit bounded progress instead: at most
# one record per interval per transfer, so the log stays proportional to time
# rather than to file size.
SOURCE_PLAN_PROGRESS_INTERVAL_SECONDS = 2.0
UPLOAD_RESIDENT_PAYLOAD_BYTES = 128 * 1024 * 1024
# Hash planning and provider upload never retain more than this many source
# bytes independently.  Adaptive extents can reach 64 MiB; using the worker
# count alone used to allow four such buffers (256 MiB) before the oldest
# digest was drained, on top of the upload pipeline's separate 128 MiB bound.
SOURCE_PLAN_RESIDENT_PAYLOAD_BYTES = UPLOAD_RESIDENT_PAYLOAD_BYTES
# Planning needs only hashes, never a block-sized payload.  Read a small fixed
# window so a maximum-size (64 MiB extent) File Provider save cannot transiently
# retain the pread result, a bytearray copy, and an immutable bytes copy at once.
FILE_PROVIDER_PLAN_READ_BYTES = 1024 * 1024
FILE_PROVIDER_CALLBACK_MAX_BYTES = 16 * 1024
MAX_WRITE_TICKETS_PER_REQUEST = 256
MAX_UPLOAD_TICKET_WAVE_BYTES = (
    MAX_WRITE_TICKETS_PER_REQUEST * MAX_CAS_BLOCK_BYTES
)
UPLOAD_IN_FLIGHT_RETRY_SECONDS = 30.0
_EMPTY_SHA256 = hashlib.sha256(b"").hexdigest()
_MUTATION_STATUS_MISS = "mutation status authoritatively reported found=false"
_AUTHORITATIVE_CONFLICT_PREFIX = "authoritative remote conflict refresh required: "
_AUTHORITATIVE_BASE_DIVERGED_PREFIX = (
    "authoritative remote base divergence refresh required: "
)
_RENAME_VERIFY_PREFIX = "large local rename verification pending: "
_USE_REMOTE_DIGEST = object()
_FINGERPRINT_NOT_OBSERVED = object()
_METADATA_SPLIT_REPAIR_CACHE_LIMIT = 256
_STAGE_UUID_PATTERN = (
    r"[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"
)
_OWNED_STAGE_FILE_RE = re.compile(
    rf"^(?P<id>{_STAGE_UUID_PATTERN})\.data"
    rf"(?:\.(?:plan|progress)\.json|\.file-provider-callback)?$",
    re.IGNORECASE,
)
_OWNED_STAGE_TEMP_RE = re.compile(
    rf"^\.(?P<id>{_STAGE_UUID_PATTERN})\.data"
    rf"(?:\.(?:plan|progress)\.json)?\.[A-Za-z0-9_-]+\.tmp$",
    re.IGNORECASE,
)


class FabricSyncTransport(Protocol):
    """All calls are synchronous and must return only after verification."""

    def manifest(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def changes(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def read(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def blocks(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def upload_block(
        self, ticket: Mapping[str, Any], data: bytes
    ) -> dict[str, Any]: ...

    def mutate(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def delete_path(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def mutation_status(self, payload: dict[str, Any]) -> dict[str, Any]: ...


class FabricBlockReadTransport(Protocol):
    """Optional direct-CAS read seam implemented by capable transports.

    ``block_reads`` is the signed `/blocks` JSON call. ``download_block`` is a
    ticket-authorized GET. The coordinator invokes both serially and never
    retains more than four block payloads (normally 16 MiB) at once.
    """

    def block_reads(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def download_block(self, ticket: Mapping[str, Any]) -> bytes: ...


@dataclass(frozen=True)
class StagedBlock:
    index: int
    offset_bytes: int
    size_bytes: int
    sha256: str


@dataclass(frozen=True)
class StagePlan:
    path: str
    size_bytes: int
    sha256: str
    source_fingerprint: str
    blocks: tuple[StagedBlock, ...]
    delete_after_ack_path: str | None = None
    delete_after_ack_digest: str | None = None
    transfer_logical_path: str | None = None
    transfer_token: str | None = None
    # Source-backed plans own only a private zero-byte marker plus bounded
    # plan/progress journals. Bytes are read from an exact identity-pinned
    # workspace path and revalidated before every range and before mutation.
    source_path: str | None = None
    # A source-backed rewrite may retain the connected-host object's exact
    # boundaries. Native small text also uses this explicit fine-extent policy
    # for the shared bounded CDC layout, rather than claiming adaptive sizing.
    preserved_target_extents: bool = False
    # File Provider owns an edited file until its callback completes.  Native
    # plans retain only this opaque lease token and a zero-byte marker; the
    # live descriptor is deliberately process-local and must be reattached by
    # an identical system retry after a crash.
    source_kind: str | None = None
    source_token: str | None = None
    delete_after_ack_mutation_id: str | None = None
    # Canonical RFC3339 UTC timestamp supplied by the native source. It rides
    # the same idempotent PUT as the bytes and therefore survives projection.
    modified_at: str | None = None


@dataclass
class _FileProviderSourceLease:
    descriptor: int
    fingerprint: FileFingerprint
    cancelled: bool = False
    lock: threading.RLock = field(default_factory=threading.RLock)


def _plan_is_source_backed(plan: StagePlan) -> bool:
    return plan.source_path is not None or plan.source_kind == "file_provider_fd"


@dataclass(frozen=True)
class _ManifestBlockPageState:
    """One bounded in-memory lazy block-index load for the queue head."""

    path: str
    generation: int
    manifest_digest: str
    file_digest: str
    file_size_bytes: int
    summary: Mapping[str, Any]
    blocks: tuple[StagedBlock, ...] = ()


@dataclass(frozen=True)
class _RemoteBatchProbe:
    blocks: tuple[BlockSpec, ...]
    missing: tuple[BlockSpec, ...]


@dataclass(frozen=True)
class _RemotePublishResult:
    outcome: str
    local: HashedRegularFile | None
    preserved_path: str | None = None


@dataclass
class _RemoteTransferState:
    path: str
    generation: int
    manifest_digest: str
    file_digest: str
    file_size_bytes: int
    pinned: bool
    expected_clean_digest: str | None
    logical_path: str
    expected_content_sha256: str | None = None
    block_descriptor: Mapping[str, Any] | None = None
    expected_existing_fingerprint: FileFingerprint | None = None
    job: RemoteAssemblyJob | None = None
    stage: VerifiedStage | None = None
    phase: str = "open"
    future: Future[Any] | None = None
    publish_result: _RemotePublishResult | None = None
    ticket_blocks: tuple[BlockSpec, ...] = ()
    tickets: Mapping[str, Mapping[str, Any]] | None = None
    ticket_cursor: int = 0
    fetch_count: int = 0
    # CAS storage kind of the remote entry (fixes the edge object key layout).
    cas_storage_kind: str | None = None
    # Large legacy/packed/non-CAS objects use one authenticated <=8 MiB range
    # per coordinator tick. The private stage is disposable remote data (not a
    # user snapshot), but inode/offset/digest state prevents a hostile or racy
    # staging entry from being trusted between chunks.
    range_stage_path: Path | None = None
    range_stage_device: int | None = None
    range_stage_inode: int | None = None
    range_offset: int = 0
    range_hasher: Any | None = None
    range_file_hasher: Any | None = None
    tree_reader: FabricTreeReader | None = None
    range_stage_owned: bool = False
    # A durable local mutation supersedes materialization of the older remote
    # identity.  The Event is shared with the off-loop namespace publisher so
    # cancellation never depends on a delayed coordinator poll.
    cancelled_by_local_mutation: threading.Event = field(
        default_factory=threading.Event, repr=False
    )


@dataclass(frozen=True)
class _BatchCommitEntry:
    """One operation that can be committed right now without more bytes."""

    operation: PendingOperation
    plan: StagePlan | None = None
    stage_path: Path | None = None
    commit_blocks: tuple[StagedBlock, ...] = ()
    # Blocks whose bytes ride inline in the batch request (with their data).
    inline_blocks: tuple[tuple[StagedBlock, bytes], ...] = ()
    # V2-only planning metadata: these exact blocks have durable upload
    # receipts, but still need server-side presence proof. The validated ops
    # already carry their descriptors; this is NOT a wire verify-list.
    readback_blocks: tuple[StagedBlock, ...] = ()


@dataclass
class _PutUploadState:
    """One byte-only upload wave owned by a durable queued put.

    Signed ticket minting remains on the coordinator thread.  Only exact stage
    reads and provider PUTs run in daemon futures, so a slow or stuck provider
    never pins the heartbeat/control loop.  Receipts are drained and fsynced by
    the coordinator before another group consumes more tickets.
    """

    mutation_id: str
    stage_path: Path
    plan: StagePlan
    max_concurrency: int
    pending: deque[StagedBlock]
    tickets: Mapping[str, Mapping[str, Any]]
    expires_at_epoch: float
    started_at: float
    active: dict[str, tuple[StagedBlock, Future[tuple[str, dict[str, Any]]]]] = field(
        default_factory=dict
    )
    uploaded_unique_blocks_before: int = 0
    verified_unique_blocks_before: int = 0
    completed_bytes: int = 0
    completed_blocks: int = 0
    first_error: BaseException | None = None


class _PersistentDaemonWorkerPool:
    """One process-wide bounded lane for potentially stuck provider PUTs.

    A running socket call cannot be cancelled safely. Eight persistent daemon
    workers plus an outstanding-work semaphore prevent retries, terminal
    operations, or coordinator replacement from accumulating orphan threads.
    """

    def __init__(self, max_workers: int) -> None:
        if not 1 <= max_workers <= UPLOAD_WORKER_CONCURRENCY:
            raise ValueError("upload worker count is outside its protocol bound")
        self.max_workers = max_workers
        self._slots = threading.BoundedSemaphore(max_workers)
        self._items: queue.Queue[tuple[Future[Any], Any, int]] = queue.Queue(
            maxsize=max_workers
        )
        self._lock = threading.Lock()
        self._start_lock = threading.Lock()
        self._active = 0
        self._resident_bytes = 0
        self._workers: tuple[threading.Thread, ...] = ()

    @property
    def worker_count(self) -> int:
        return len(self._workers)

    @property
    def active_workers(self) -> int:
        with self._lock:
            return self._active

    def submit(self, function: Any, *, payload_bytes: int = 0) -> Future[Any] | None:
        if not 0 <= payload_bytes <= UPLOAD_RESIDENT_PAYLOAD_BYTES:
            raise ValueError("upload payload exceeds the resident byte bound")
        self._ensure_started()
        if not self._slots.acquire(blocking=False):
            return None
        future: Future[Any] = Future()
        with self._lock:
            if self._resident_bytes + payload_bytes > UPLOAD_RESIDENT_PAYLOAD_BYTES:
                self._slots.release()
                return None
            self._active += 1
            self._resident_bytes += payload_bytes
        try:
            self._items.put_nowait((future, function, payload_bytes))
        except BaseException:
            with self._lock:
                self._active -= 1
                self._resident_bytes -= payload_bytes
            self._slots.release()
            raise
        return future

    def _ensure_started(self) -> None:
        if self._workers:
            return
        with self._start_lock:
            if self._workers:
                return
            workers = tuple(
                threading.Thread(
                    target=self._run,
                    name=f"meshia-upload-worker-{index}",
                    daemon=True,
                )
                for index in range(self.max_workers)
            )
            # Publish only after every Thread object exists; concurrent
            # diagnostics never observe a partially sized pool.
            self._workers = workers
            for worker in workers:
                worker.start()

    def _run(self) -> None:
        while True:
            future, function, payload_bytes = self._items.get()
            try:
                if future.set_running_or_notify_cancel():
                    future.set_result(function())
            except BaseException as error:
                future.set_exception(error)
            finally:
                with self._lock:
                    self._active -= 1
                    self._resident_bytes -= payload_bytes
                self._slots.release()
                self._items.task_done()


_PUT_UPLOAD_WORKERS = _PersistentDaemonWorkerPool(UPLOAD_WORKER_CONCURRENCY)


@dataclass(frozen=True)
class SyncTick:
    local_events: int = 0
    local_hashes: int = 0
    mutations: int = 0
    remote_changed: bool = False
    # Exact paths are advisory namespace-notification hints, never sync truth.
    # A full-manifest replacement may report only ``remote_changed``; callers
    # must then invalidate the workspace root rather than materializing an
    # unbounded manifest diff in Python.
    remote_changed_paths: tuple[str, ...] = ()
    remote_applies: int = 0
    evicted_bytes: int = 0
    error: str | None = None

    @property
    def did_work(self) -> bool:
        return bool(
            self.local_events
            or self.mutations
            or self.remote_changed
            or self.remote_applies
            or self.evicted_bytes
        )


@dataclass(frozen=True)
class FabricSyncHealth:
    """Cheap read-only coordinator health with no maintenance side effects."""

    runtime_ready: bool
    command_safe: bool
    sync_converged: bool
    pending_operations: bool
    pending_local_transfers: bool
    pending_local_transfer_count: int
    pending_local_transfer_bytes: int
    pending_local_transfer_path: str | None
    local_transfer_reason: str | None
    local_file_issue_sample: tuple[tuple[str, str, int, str], ...]
    local_file_issues_saturated: bool
    pending_remote_work: bool
    commit_unknown: bool
    unresolved_conflicts: bool
    staging_ready: bool
    staging_over_capacity: bool
    staging_reserved_bytes: int | None
    watcher_backend: str
    watcher_healthy: bool
    watcher_reconciliation_needed: bool
    watcher_local_issue_count: int
    watcher_local_issue_sample: tuple[tuple[str, str], ...]
    watcher_local_issues_saturated: bool
    last_error: str | None


class FabricSyncCoordinator:
    """One-threaded working-set reconciler suitable for NodeRunner maintenance.

    ``poll_once`` performs bounded work and returns whether durable or visible
    state changed. ``wait`` sleeps interruptibly on the watcher's event and the
    next remote deadline. ``wake`` lets NodeRunner stop promptly.
    """

    def __init__(
        self,
        transport: FabricSyncTransport,
        database: FabricDatabase,
        cache: FabricRangeCache,
        watch: FabricWatch,
        workspace: WorkspaceBoundary,
        authority: FabricAuthority,
        staging_root: Path | str,
        *,
        max_materialized_bytes: int | None = None,
        verify_on_commit: bool = True,
        max_events_per_tick: int = DEFAULT_MAX_EVENTS_PER_TICK,
        max_mutations_per_tick: int = DEFAULT_MAX_MUTATIONS_PER_TICK,
        max_blocks_per_tick: int = DEFAULT_MAX_BLOCKS_PER_TICK,
        max_remote_applies_per_tick: int = DEFAULT_MAX_REMOTE_APPLIES_PER_TICK,
        max_auto_materializations: int = DEFAULT_MAX_AUTO_MATERIALIZATIONS,
        max_staging_bytes: int = DEFAULT_MAX_STAGING_BYTES,
        min_staging_free_bytes: int = DEFAULT_MIN_STAGING_FREE_BYTES,
        min_staging_free_fraction: float = DEFAULT_MIN_STAGING_FREE_FRACTION,
        staging_admission_path: Path | str | None = None,
        adoption_pending: bool = False,
        workspace_id: str | None = None,
        disk_usage: Any = shutil.disk_usage,
        clock: Any = time.monotonic,
        wall_clock_ns: Any = time.time_ns,
        logger: NodeLogger = NULL_LOGGER,
    ) -> None:
        authority_workspace_id = authority.workspace_id
        if (
            workspace_id is not None
            and authority_workspace_id is not None
            and workspace_id != authority_workspace_id
        ):
            raise ValueError(
                "workspace_id conflicts with the Fabric authority workspace_id"
            )
        bound_workspace_id = (
            authority_workspace_id
            if authority_workspace_id is not None
            else workspace_id
        )
        # Resolution order: an explicit argument (tests and callers that must
        # pin an exact bound), then the operator environment override, then the
        # DYNAMIC free-space policy. Only the first two pin a constant; the
        # default path recomputes from real free space at decision time, which
        # is the whole point -- the old fixed 2 GiB had no override at all, so
        # a workspace larger than it could not be repaired from outside the
        # binary and could not react to the device filling up.
        if max_materialized_bytes is None:
            max_materialized_bytes = _max_materialized_bytes_from_env()
        pinned_materialized_bytes = max_materialized_bytes
        for name, value, minimum in (
            ("max_materialized_bytes", max_materialized_bytes, 0),
            ("max_events_per_tick", max_events_per_tick, 1),
            ("max_mutations_per_tick", max_mutations_per_tick, 1),
            ("max_blocks_per_tick", max_blocks_per_tick, 1),
            ("max_remote_applies_per_tick", max_remote_applies_per_tick, 1),
            ("max_auto_materializations", max_auto_materializations, 0),
            ("max_staging_bytes", max_staging_bytes, 0),
            ("min_staging_free_bytes", min_staging_free_bytes, 0),
        ):
            if name == "max_materialized_bytes" and value is None:
                continue
            if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
                raise ValueError(f"{name} must be an integer of at least {minimum}")
        self.transport = transport
        self.database = database
        # The range cache keys every entry by (manifest_generation,
        # manifest_digest), which a Fabric v2 head cannot supply. Rather than
        # thread a v2 check through the dozen call sites that pass a manifest
        # identity, the scoped surface is disabled at the boundary. The
        # content-addressed surface (get_content/put_content, keyed by block
        # sha256) is untouched and still caches normally -- and that is the
        # lane v2 reads actually use, so what is lost here is the v1 range
        # cache, not caching.
        self.cache = _ManifestScopedCacheGate(cache, self._fabric_v2_refresh_active)
        self.watch = watch
        self.workspace = workspace
        self.authority = authority
        self.workspace_id = bound_workspace_id
        self.staging_root = ensure_private_dir(Path(staging_root).expanduser())
        self._pinned_materialized_bytes = pinned_materialized_bytes
        self._volume_sample: tuple[int, int] | None = None
        self._volume_sample_expires = float("-inf")
        self._materialized_tier: str | None = None
        self._cache_policy: MaterializedCachePolicy | None = None
        self._next_cache_maintenance = 0.0
        self._unproven_cache_reported = False
        self._access_touches: dict[str, int] = {}
        self._access_touch_lock = threading.Lock()
        self.max_events_per_tick = max_events_per_tick
        self.max_mutations_per_tick = max_mutations_per_tick
        self.max_blocks_per_tick = min(max_blocks_per_tick, 256)
        self.max_remote_applies_per_tick = max_remote_applies_per_tick
        self.max_auto_materializations = min(max_auto_materializations, 10_000)
        self.max_auto_materialized_bytes = DEFAULT_MAX_AUTO_MATERIALIZED_BYTES
        if not isinstance(min_staging_free_fraction, (int, float)) or isinstance(min_staging_free_fraction, bool) or not 0 <= min_staging_free_fraction < 1:
            raise ValueError("min_staging_free_fraction must be between 0 and 1")
        if not isinstance(adoption_pending, bool):
            raise ValueError("adoption_pending must be a boolean")
        self.max_staging_bytes = max_staging_bytes
        self.min_staging_free_bytes = min_staging_free_bytes
        self.min_staging_free_fraction = float(min_staging_free_fraction)
        self._disk_usage = disk_usage
        self._clock = clock
        self._wall_clock_ns = wall_clock_ns
        self.logger = logger
        # Every dependency the free-space policy reads is now bound, so take
        # the first capacity sample and let it bound automatic selection.
        self._pinned_auto_materialized_bytes: int | None = None
        self._cache_policy = self._resolve_cache_policy(fresh=True)
        self._coordinator_lock = threading.RLock()
        # Remote publication runs off-loop, while Finder callbacks enter on a
        # FUSE/SMB worker.  A small fixed stripe set serializes namespace CASes
        # for the same path without allocating one lock per remote object or
        # blocking unrelated workspaces/files.
        self._namespace_locks = tuple(threading.RLock() for _ in range(64))
        self._signed_control_lock = threading.Lock()
        self._wake_callback: Callable[[], None] | None = None
        self._mount_cleanup_fence_provider: Callable[[str], Any] | None = None
        self._started = False
        self._startup_reconcile = True
        # An explicitly adopted non-empty namespace is classified against the
        # first authoritative manifest before watcher hints or mutations may be
        # drained. Same-path divergence becomes a durable conflict; it must
        # never inherit the normal local-edit-wins staging path.
        self._adoption_reconcile_pending = adoption_pending
        self._force_full_remote = (
            database.get_remote_manifest_head() is None
            if database.current_authority()
            else True
        )
        self._remote_apply_queue: deque[str] = deque()
        self._remote_apply_members: set[str] = set()
        self._remote_apply_priority_members: set[str] = set()
        self._remote_rename_queue: deque[tuple[str, str, str, int]] = deque()
        self._remote_rename_members: set[tuple[str, str]] = set()
        self._deferred_directory_events: dict[str, str] = {}
        self._deferred_directory_events_overflow = False
        # rmdir journals a head-fenced local tombstone synchronously. Its
        # authoritative delete is published from this serialized control lane;
        # acknowledged paths remain suppressed until local retirement evidence
        # is physically gone or an explicit mkdir clears the acknowledgement.
        self._acknowledged_directory_deletes: dict[str, int] = {}
        self._remote_intents_restored = False
        self._remote_apply_intents_may_remain = True
        self._remote_rename_intents_may_remain = True
        self._direct_read_batch = 4
        # Bytes in flight per direct-read batch. Four 4 MiB blocks was the
        # historical shape; blocks are adaptively sized up to 64 MiB, so the
        # batch is bounded by bytes (never fewer than one block).
        self._direct_read_batch_bytes = 4 * BLOCK_BYTES
        self._direct_ticket_batch = DIRECT_TICKET_BATCH_BLOCKS
        # Small puts verify their last wave inside the commit; cleared when a
        # control plane rejects the field so the classic verify call resumes.
        if not isinstance(verify_on_commit, bool):
            raise ValueError("verify_on_commit must be a boolean")
        self._mutate_verifies_blocks = verify_on_commit
        # Direct edge uploads: verify/commit calls carry ``direct_blocks`` so the
        # control plane admits unreserved digests itself. Flipped off after an
        # older control plane rejects the field (400); such a plane mints no
        # edge grants, so tickets remain the only lane there.
        self._direct_blocks_supported = True
        # Inline small-block commits: bytes ride inside mutate_batch and the
        # control plane performs the CAS PUTs itself. Cleared when an older
        # control plane rejects the field (400), so the classic ticket/upload
        # lane resumes for the rest of the process.
        self._inline_commit_supported = True
        # Wall deadline after which a disabled inline lane re-probes.
        self._inline_disabled_until_ns: int | None = None
        # Per-request inline budget. A server that rejects our payload shape or
        # size halves this (never disabling the lane) so the client converges on
        # a request the control plane accepts instead of falling back forever.
        self._inline_request_budget_bytes = INLINE_BATCH_MAX_BYTES
        # Per-LANE serialized-size budgets for a v2 commit, shrunk on a 413
        # exactly as the v1 batch budget is.
        #
        # Split by lane on purpose. A cohort of small files and a cohort of
        # large ones fail for unrelated reasons and at unrelated sizes, and a
        # shared budget makes one lane's 413 the other lane's permanent tax:
        # halving the item cap from 64 to 32 because a large-file commit was
        # refused doubles the signed control calls a folder of 80,000 tiny
        # files costs, for a reason that has nothing to do with tiny files.
        # Degradation signals must not cross lanes that do not share a
        # failure mode.
        #
        # ``item_cap_ceiling`` is each lane's un-shrunk item cap: the inline
        # lane's base64 body makes 64 items its natural bound, while the bulk
        # lane carries bare descriptors and may fill a full 1024-op server
        # cohort. A 413 halves ``item_cap`` toward one; a success streak grows
        # it back toward this ceiling (see `_note_v2_commit_success`), so a
        # transient overflow heals instead of ratcheting the lane down forever.
        #
        # ``wire_ceiling``/``inline_ceiling`` are the LEARNED byte ceilings the
        # grow-back restores toward -- NOT the hard constants. A 413 is not a
        # transient blip: the edge body limit is deterministic in the request
        # size, so a cohort that tripped it proves this lane's byte budget was
        # too big, and the grow-back must never restore it back above the size
        # that failed and re-trip -- the sawtooth (16->8, restore 1->4->8->16,
        # trip, repeat) that halved durable throughput on an 8-stream copy.
        # A shrink lowers these ceilings; the byte budgets can only heal up to
        # them, so the lane settles just under the real limit instead of
        # oscillating across it.
        self._v2_lane_budgets: dict[str, dict[str, int]] = {
            "inline": {
                "wire_bytes": V2_COMMIT_REQUEST_MAX_WIRE_BYTES,
                "wire_ceiling": V2_COMMIT_REQUEST_MAX_WIRE_BYTES,
                "inline_bytes": INLINE_BATCH_MAX_BYTES,
                "inline_ceiling": INLINE_BATCH_MAX_BYTES,
                "item_cap": DEFAULT_MAX_BATCH_MUTATIONS,
                "item_cap_ceiling": DEFAULT_MAX_BATCH_MUTATIONS,
            },
            "bulk": {
                "wire_bytes": V2_COMMIT_REQUEST_MAX_WIRE_BYTES,
                "wire_ceiling": V2_COMMIT_REQUEST_MAX_WIRE_BYTES,
                "inline_bytes": INLINE_BATCH_MAX_BYTES,
                "inline_ceiling": INLINE_BATCH_MAX_BYTES,
                "item_cap": SERVER_MAX_V2_COMMIT_OPS,
                "item_cap_ceiling": SERVER_MAX_V2_COMMIT_OPS,
            },
        }
        # Per-lane consecutive successful v2 commits, for the item-cap grow-back.
        self._v2_lane_success_streak: dict[str, int] = {"inline": 0, "bulk": 0}
        # Fabric v2 commits per-path ops instead of manifests. Opt-in while
        # both server paths exist; latched off only by an explicit 404.
        self._fabric_v2_enabled = _fabric_v2_enabled_from_env()
        self._inline_block_max_bytes = _inline_block_max_bytes_from_env()
        # First time the coordinator saw each inline-eligible put (own wall
        # clock, so linger/valve arithmetic never mixes clock domains with the
        # journal's timestamps). Entries are dropped when the put rides a
        # batch, releases to the wave path, or the bound is hit.
        self._inline_first_seen_ns: dict[str, int] = {}
        # Mutation ids whose OWN one-item inline commit was rejected as too
        # large -- the request-budget split bottomed out at a single file and
        # cannot shrink the cohort further. Such a file is forced off the inline
        # lane so it uploads its blocks and commits by verify (a small request),
        # instead of retrying the identical oversized inline commit forever.
        # `_classify_commit_candidate` reads this to decline inline; the id is
        # dropped once the put has uploaded everything (no missing blocks left).
        self._v2_inline_forced_upload: set[str] = set()
        # Count of times a single-file inline commit was forced to the upload
        # lane this process -- an observable signal that the split bottomed out,
        # distinct from ordinary shrink events.
        self._v2_inline_single_oversized_count = 0
        # request_digest -> how many times THAT EXACT oversized commit request
        # has been rejected and re-armed in a row. A shrink that actually makes
        # the request smaller produces a new digest (streak 1), so a normal
        # folder drain never accrues here; only a request that cannot get any
        # smaller keeps its digest and climbs -- and that streak drives the
        # backoff, the durable failure_count, and the terminal ceiling that stop
        # the guaranteed-400 hot loop. Bounded like `_inline_first_seen_ns`.
        self._v2_commit_rejection_streak: dict[str, int] = {}
        # Monotonic deadline (``self._clock()`` domain) the inline linger is
        # currently holding a ready cohort until, or None when nothing is
        # lingering. next_poll_delay honours it so the runner SLEEPS through
        # the linger instead of re-polling a cohort it has already decided not
        # to flush yet. Measured before this existed: one 4 KB file cost 855
        # poll_once() calls and 749 ms of CPU across a 763 ms wait, and that
        # pegged core is exactly the pure-Python load that stretches a mounted
        # write+fsync+close from 13 ms to seconds (see fabric_mount.py:96).
        self._inline_flush_not_before: float | None = None
        # Wall-ns until which a burst counts as open (0 = closed). The FIRST
        # inline cohort of a burst flushes without lingering, so a drop onto an
        # idle node starts uploading immediately; coalescing then engages for
        # every later cohort, where the request-count win actually accrues.
        # The window decays on TIME rather than on the queue emptying: files
        # trickling in a few hundred ms apart drain the queue between arrivals,
        # and resetting there would spend one signed request per file for the
        # whole drop instead of one per batch.
        self._inline_burst_open_until_ns = 0
        # Last time the batch lane proved it works (any committed batch). The
        # hold valve is relative to this, so puts waiting behind an in-flight
        # batch are not released to the classic path mid-flight.
        self._inline_last_progress_ns: int | None = None
        # When verify-on-commit / direct admission were last disabled by a 400
        # so they can be re-probed instead of staying off for the process life.
        self._capability_disabled_at_ns: int | None = None
        # Rate-limit state for inline-decline diagnostics (reason -> last log).
        self._inline_declined_logged_ns: dict[str, int] = {}
        # Adaptive serialized-request ceiling, halved on a 413 and restored on
        # a clean commit, so one oversized shape cannot wedge the lane.
        self._batch_wire_budget_bytes = BATCH_REQUEST_MAX_WIRE_BYTES
        # Adaptive per-request item cap. Claims cannot be released once taken,
        # so the request is bounded by planning fewer items next turn rather
        # than by trimming an already-claimed batch.
        self._batch_item_cap = DEFAULT_MAX_BATCH_MUTATIONS
        # Set by a turn that sent a commit cohort; gates the tick drain.
        self._last_turn_was_batch_commit = False
        # Ready commits ride one mutate_batch call when the transport offers
        # it; cleared when the control plane rejects the route so the classic
        # one-mutation-per-call path resumes for the rest of the process.
        self._mutate_batches = True
        # The additive v1 write_batch `items` form mints tickets for a bounded
        # folder burst in one signed request. Older control planes keep the
        # original mutation_id/blocks form; one rejected probe parks this lane.
        self._multi_put_ticket_batches = True
        # Capabilities remain mutation-scoped and in-memory only. At most one
        # companion is prefetched, so a crash leaves only M632/M1747's bounded,
        # collectable abandoned-upload debt.
        self._prefetched_write_tickets: dict[
            str, dict[str, Mapping[str, Any]]
        ] = {}
        self._signed_control_calls = 0
        # Adaptive batch bound: two consecutive lost batch responses (deadline
        # or transport) halve it, down to one (singles); each further success
        # streak doubles it back toward the server bound.
        self._batch_size_limit = DEFAULT_MAX_BATCH_MUTATIONS
        self._batch_transport_failures = 0
        self._batch_success_streak = 0
        self._direct_read_goodput_bytes_per_second: float | None = None
        self._direct_read_last_ticket_headroom_seconds: float | None = None
        self._poll_delay = MIN_REMOTE_POLL_SECONDS
        self._next_remote_poll = 0.0
        # Push invalidation: ``None`` means no healthy stream, so idle polling
        # follows the MIN/MAX ramp; a number is the idle backstop instead. A
        # requested poll is consumed at the top of the next tick so an event
        # that lands mid-tick is never lost behind that tick's own deadline.
        self._remote_poll_backstop_seconds: float | None = None
        self._push_poll_requested = False
        # Push latency accounting: when the event was received, whether this
        # tick's remote poll is answering it, and when that poll finished so
        # the apply that follows can report end-to-end event→visible time.
        # The requested timestamp stays paired with its flag until a remote
        # poll actually starts.  That matters when local work wins a turn and
        # when another push lands while the preceding poll is in flight.
        self._push_poll_requested_at: float | None = None
        self._push_apply_pending_since: float | None = None
        # A mutation receipt advances remote truth before the local manifest
        # cursor sees that generation. Keep that one readback urgent without
        # treating every previously-expired poll deadline as a continuation.
        self._receipt_readback_pending = False
        self._next_operation_poll = float("inf")
        self._next_quarantined_status_poll = 0.0
        self._next_apply_poll = float("inf")
        # Retry-After is authority-wide: every signed Fabric control request
        # shares the same host/session rate budget. Watcher edges and local or
        # direct-byte completions may wake the coordinator during this fence,
        # but they can never shorten it or leak a request from another lane.
        self._signed_control_not_before = 0.0
        watch_recovery_generation = self.watch.recovery_generation
        self._observed_watch_recovery_generation = (
            watch_recovery_generation - 1
            if self.watch.overflow
            else watch_recovery_generation
        )
        self._prefer_remote_control = False
        # A server-proven same-path/base conflict must be bound to a freshly
        # published remote entry, not the operation's stale local base. The
        # durable last_error prefix survives restart; this in-memory set only
        # tracks the single serialized conflict whose bounded refresh is live.
        self._authoritative_conflicts_waiting: set[str] = set()
        # Bounded v2 per-path recovery: mutation_id -> refresh attempts.
        # Cleared when the operation is acknowledged or conflicted, so it
        # never outlives the operation it bounds.
        self._v2_path_recovery_attempts: dict[str, int] = {}
        # Directory tombstones whose v1 publish was withheld under v2,
        # so the reason is logged once per path rather than every poll.
        self._v2_tombstone_publish_declined: set[str] = set()
        # A requested resolution must observe one forced full remote snapshot
        # in this process before any effect.  This is intentionally ephemeral:
        # a restart repeats the refresh rather than trusting a crash-window
        # marker that could outlive its network response.
        self._conflict_resolution_refreshes: set[str] = set()
        # Conflict-state rename ops re-armed once for a fresh submit after a
        # refresh (a code the server can now accept). Ephemeral and bounded: at
        # most one automatic re-submit per op per process; a restart may grant
        # one more, which is the same bound the refresh markers keep.
        self._conflict_ops_resubmitted: set[str] = set()
        # Directory tombstones whose v1 `delete_path` request cannot be formed
        # against the current head. Bounded by the tombstone table's own limit
        # and only used to keep the log to one line per path.
        self._directory_tombstones_unroutable: set[str] = set()
        # How many bounded head refreshes each operation has already spent on
        # FABRIC_MUTATION_BASE_INVALID.  Ephemeral for the same reason as the
        # set above: a restart re-reads the head anyway, and the durable
        # `failure_count` this path also increments keeps every retry on the
        # ordinary capped exponential backoff, so a restart loop cannot turn
        # the renewed budget into a hot loop.
        self._base_invalid_refreshes: dict[str, int] = {}
        self._next_orphan_stage_scan = 0.0
        self._next_retired_quarantine_maintenance = 0.0
        self._retired_evidence_pending = bool(
            self.workspace.retired_quarantine_status().visible_promotion_backlog
        )
        self._orphan_stage_scan: Iterator[os.DirEntry] | None = None
        self._acked_cleanup_cursor: tuple[int, str] | None = None
        self._inactive_stage_cleanup_cursor = 0
        self._resolved_conflict_cleanup_cursor: tuple[int, str] | None = None
        self._standalone_conflict_cleanup_cursor = 0
        self._legacy_content_missing_repair_cursor = 0
        self._inactive_authority_compaction_cursor = 0
        self._last_tick = SyncTick()
        self._remote_changed_paths: tuple[str, ...] = ()
        self._local_hashes = 0
        self.last_error: str | None = None
        self._readiness_error = False
        self._readiness_error_reason: str | None = None
        self._retry_error_code: str | None = None
        self._suppressed_retry_logs = 0

        self._staging_ledger = (
            StagingAdmissionLedger(
                staging_admission_path,
                staging_root=self.staging_root,
                max_bytes=max_staging_bytes,
                max_entries=MAX_REMOTE_FILES,
                min_free_bytes=min_staging_free_bytes,
                min_free_fraction=min_staging_free_fraction,
                disk_usage=disk_usage,
                now_ns=wall_clock_ns,
            )
            if staging_admission_path is not None
            else None
        )
        self._staging_repair_id = (
            self._staging_ledger.begin_repair()
            if self._staging_ledger is not None
            else None
        )
        self._staging_repair_phase = (
            "classic" if self._staging_ledger is not None else "ready"
        )
        self._staging_repair_scan: Iterator[os.DirEntry] | None = None

        # Large byte copies live below the serialized signed-control loop.
        # TransferStore persists exact source/remote identity and durable block
        # progress; the single local worker and four-slot direct pool bound RAM
        # and filesystem/network concurrency independently of file size.
        self._transfer_store = TransferStore(
            self.staging_root / "transfers",
            max_staging_bytes=max_staging_bytes,
            min_free_bytes=min_staging_free_bytes,
            min_free_fraction=min_staging_free_fraction,
            disk_usage=disk_usage,
            quota_hook=(None if self._staging_ledger is not None else self._transfer_quota_hook),
            source_resolver=self._resolve_transfer_source,
            admission_ledger=self._staging_ledger,
        )
        self._local_copy_worker = LocalCopyWorker(blocks_per_step=4)
        self._direct_byte_pool = DirectByteWorkerPool(max_workers=4)
        # Whole-object tickets let browser/MCP uploads (no CAS block map) stream
        # straight from object storage with readahead instead of one signed
        # 1 MiB control call per chunk. Absent transport support keeps the
        # legacy lane; every failure inside the lane also falls back per read.
        self._object_reader: DirectObjectReader | None = (
            DirectObjectReader(
                transport=transport,  # type: ignore[arg-type]
                cache=cache,
                request_ticket=lambda payload: self._signed_control_request(
                    getattr(self.transport, "object_read"), payload
                ),
                attachment_id=self.authority.attachment_id,
                request_ticket_batch=(
                    (
                        lambda payload: self._signed_control_request(
                            getattr(self.transport, "object_read_batch"), payload
                        )
                    )
                    if callable(getattr(transport, "object_read_batch", None))
                    else None
                ),
                workspace=WORKSPACE_MOUNT,
                now=lambda: self._wall_clock_ns() / 1_000_000_000,
                logger=logger,
            )
            if DirectObjectReader.transport_supported(transport)
            else None
        )
        self._local_transfer_future: Future[VerifiedStage] | None = None
        self._local_transfer_job: LocalSnapshotJob | None = None
        self._local_transfer_intent: LocalTransferIntent | None = None
        self._local_transfer_open_future: Future[
            RemoteAssemblyJob | LocalSnapshotJob
        ] | None = None
        self._local_transfer_open_intent: LocalTransferIntent | None = None
        self._local_plan_future: Future[tuple[StagedBlock, ...]] | None = None
        self._local_plan_stage: VerifiedStage | None = None
        self._bulk_plan_future: Future[StagePlan] | None = None
        self._bulk_plan_intent: LocalTransferIntent | None = None
        self._bulk_plan_cancel: threading.Event | None = None
        self._local_transfer_blocks: dict[int, StagedBlock] = {}
        self._local_transfer_lock = threading.Lock()
        self._transfer_source_paths: dict[str, str] = {}
        self._validated_local_transfer_handoffs: dict[
            str, tuple[str, str, int]
        ] = {}
        self._local_issue_audit_cursor: tuple[int, str] | None = None
        self._transfer_recovery_pending = True
        self._local_recovery_cursor: str | None = None
        self._local_recovery_future: Future[VerifiedStage] | None = None
        self._local_recovery_candidate: LocalRecoveryCandidate | None = None
        self._local_recovery_plan: StagePlan | None = None
        self._local_recovery_pending = True
        self._local_recovery_scan_blocked = False
        self._next_local_recovery_scan = 0.0
        self._remote_finalization_cleanup_cursor: str | None = None
        self._remote_transfer: _RemoteTransferState | None = None
        self._manifest_block_load: _ManifestBlockPageState | None = None
        # One immutable, exact-revision descriptor page/prefix for mounted
        # reads. Keep metadata bounded by MAX_MANIFEST_BLOCKS rather than
        # fetching the same index before every already-cached byte read.
        self._mounted_block_page_cache: _ManifestBlockPageState | None = None
        self._stage_cleanup_futures: dict[str, Future[Any]] = {}
        self._put_progress_cache_key: tuple[str, str] | None = None
        self._put_progress_cache: dict[str, Any] | None = None
        self._put_upload_states: dict[str, _PutUploadState] = {}
        # A File Provider contents URL is system-owned and is unlinked after
        # its callback.  Keep only duplicated read-only descriptors while the
        # callback is outstanding; durable plans contain no local byte copy.
        self._file_provider_sources: dict[str, _FileProviderSourceLease] = {}
        self._file_provider_sources_lock = threading.RLock()
        # Keep exact receipts addressable until the native callback has sent
        # its success response.  The ordinary acknowledged-stage sweeper may
        # otherwise prune a small write between the coordinator ACK and the
        # bridge's next 50 ms poll.
        self._file_provider_receipt_holds: set[str] = set()
        self._file_provider_receipt_holds_lock = threading.RLock()
        self._file_provider_namespace_results: dict[
            str, tuple[str, str | None]
        ] = {}
        # Metadata-plan split recovery is needed once per live PUT, not once
        # per upload/control tick.  Restart deliberately drops this bounded
        # hint and rechecks every durable operation that may have crossed the
        # plan-first crash window.
        self._metadata_split_repair_checked: set[str] = set()
        self._put_upload_workers = _PUT_UPLOAD_WORKERS
        self._put_upload_goodput_bytes_per_second: float | None = None
        self._put_upload_last_ticket_headroom = float(WRITE_TICKET_TTL_SECONDS)
        self._namespace_preflight_mutation_id: str | None = None
        self._rename_verify_future: Future[tuple[HashedRegularFile | None, bool]] | None = None
        self._rename_verify_mutation_id: str | None = None

        binding = self.database.bind_authority(
            host_id=authority.host_id,
            session_id=authority.session_id,
            host_generation=authority.host_generation,
            attachment_id=authority.attachment_id,
            workspace_root=workspace.root,
            workspace_id=bound_workspace_id,
        )
        self._authority_scope_id = binding.scope_id
        self._durable_adoption_pending = binding.adoption_required
        self._strict_authority_adoption = bool(
            binding.adoption_required
            and binding.adoption_reason != "host_generation_changed"
        )
        self._authority_adoption_unmatched = False
        if binding.adoption_required:
            self._adoption_reconcile_pending = True
        # Restart is the one moment every writer is quiesced, so it is where a
        # materialization fenced as `conflict` with no unresolved conflict
        # behind it is released. Left alone it stays pinned out of every
        # reconciliation lane and unreadable, with nothing in `conflicts list`
        # to explain it -- the user's only recovery was to re-pair the host.
        try:
            repaired = self.database.repair_unbacked_conflict_materializations()
        except (sqlite3.Error, StateError) as error:
            # A repair is never worth failing startup for; the entries stay as
            # they were and the next restart tries again.
            self.logger.record(
                "fabric_unbacked_conflict_repair_failed", error=str(error)
            )
        else:
            if repaired:
                self.logger.record(
                    "fabric_unbacked_conflict_repaired",
                    count=len(repaired),
                    paths=",".join(repaired[:20]),
                )
        if binding.changed:
            self._force_full_remote = True
        elif self.database.get_remote_manifest_load() is not None:
            # A crash after any nonterminal manifest page resumes its exact
            # frozen keyset cursor before the delta lane is allowed to run.
            self._force_full_remote = True

    @property
    def last_tick(self) -> SyncTick:
        return self._last_tick

    def staging_readiness_snapshot(self) -> tuple[bool, bool]:
        """Return ``(repair_ready, over_capacity)`` using only ledger metadata."""

        ledger = self._staging_ledger
        if ledger is None:
            return self._staging_repair_phase == "ready", False
        status = ledger.status()
        return not status.repair_required, status.over_capacity

    def health_snapshot(self) -> FabricSyncHealth:
        """Return constant-result health signals without scanning or writes."""

        database = self.database.readiness_snapshot()
        pending_apply, pending_rename = self.database.has_pending_remote_intents()
        watcher = self.watch.health_snapshot()
        local_backlog = self.database.local_transfer_backlog_snapshot()
        local_intents = self.database.list_local_transfer_intents(limit=1)
        local_issues = self.database.list_local_transfer_issues(limit=5)
        local_intent = local_intents[0] if local_intents else None
        local_transfer_bytes = 0
        local_transfer_reason: str | None = None
        if local_intent is not None:
            try:
                local_transfer_bytes = _fingerprint_from_text(
                    local_intent.source_fingerprint
                ).size_bytes
            except (StateError, ValueError):
                local_transfer_reason = "local snapshot metadata needs recovery"
            else:
                local_transfer_reason = (
                    "source-backed bulk upload pending"
                    if local_transfer_bytes > self.max_staging_bytes
                    else "local snapshot transfer pending"
                )
        if self._staging_ledger is None:
            staging_ready = self._staging_repair_phase == "ready"
            staging_over_capacity = False
            staging_reserved_bytes: int | None = None
        else:
            staging = self._staging_ledger.status()
            staging_ready = not staging.repair_required
            staging_over_capacity = staging.over_capacity
            staging_reserved_bytes = staging.reserved_bytes
        command_safe = self.command_readiness[0]
        pending_remote = bool(
            pending_apply
            or pending_rename
            or self.database.has_unobserved_receipts()
            or self._remote_apply_queue
            or self._remote_rename_queue
            or self._remote_transfer is not None
            or self._manifest_block_load is not None
        )
        error = self.last_error or watcher.last_loss_or_error
        runtime_ready = bool(
            self._started
            and database.authority_bound
            and staging_ready
            and not staging_over_capacity
            and watcher.collector_healthy
        )
        converged = bool(
            command_safe
            and not database.pending_operations
            and local_backlog.path_count == 0
            and not pending_remote
            and not database.commit_unknown
            and not database.unresolved_conflicts
            and not watcher.reconciliation_needed
            and not watcher.local_issues
            and not watcher.local_issues_saturated
            and error is None
        )
        return FabricSyncHealth(
            runtime_ready=runtime_ready,
            command_safe=command_safe,
            sync_converged=converged,
            pending_operations=database.pending_operations,
            pending_local_transfers=local_backlog.path_count > 0,
            pending_local_transfer_count=local_backlog.path_count,
            pending_local_transfer_bytes=local_backlog.size_bytes,
            pending_local_transfer_path=(
                local_intent.path if local_intent is not None else None
            ),
            local_transfer_reason=local_transfer_reason,
            local_file_issue_sample=tuple(
                (
                    str(item.issue_code),
                    item.path,
                    int(item.issue_size_bytes or 0),
                    LOCAL_FILE_UNSUPPORTED_REMEDIATION,
                )
                for item in local_issues[:4]
            ),
            local_file_issues_saturated=len(local_issues) > 4,
            pending_remote_work=pending_remote,
            commit_unknown=database.commit_unknown,
            unresolved_conflicts=database.unresolved_conflicts,
            staging_ready=staging_ready,
            staging_over_capacity=staging_over_capacity,
            staging_reserved_bytes=staging_reserved_bytes,
            watcher_backend=watcher.backend,
            watcher_healthy=watcher.collector_healthy,
            watcher_reconciliation_needed=watcher.reconciliation_needed,
            watcher_local_issue_count=len(watcher.local_issues),
            watcher_local_issue_sample=tuple(
                (issue.code, issue.path) for issue in watcher.local_issues[:4]
            ),
            watcher_local_issues_saturated=watcher.local_issues_saturated,
            last_error=error,
        )

    @property
    def ready_for_commands(self) -> bool:
        """Whether the selected local working set is safe for command claims.

        Heartbeats and reconciliation continue while false. The barrier opens
        only after an authoritative head exists, startup/overflow recovery is
        acknowledged, and every durable selected apply/rename has reached its
        local terminal state. It closes again on a cursor gap or sync error.
        """

        return self.command_readiness[0]

    @property
    def command_readiness(self) -> tuple[bool, str | None, int | None]:
        """Return one cheap readiness snapshot for the command-claim gate.

        The tuple is ``(ready, reason, published_head_generation)``. It reads
        only indexed O(1) metadata and coordinator-owned state; it never loads
        manifest entries or performs filesystem/network work.
        """

        try:
            head = self.database.get_remote_manifest_head()
            load_active = self.database.get_remote_manifest_load() is not None
            readiness = self.database.readiness_snapshot()
            pending_apply, pending_rename = self.database.has_pending_remote_intents()
        except StateError:
            return (False, "sync_error", None)
        generation = head.generation if head is not None else None
        if readiness.adoption_required:
            return (False, "authority_adoption", generation)
        if self._readiness_error or self.last_error is not None:
            return (False, self._readiness_error_reason or "sync_error", generation)
        if self._staging_repair_phase != "ready":
            return (False, "staging_repair", generation)
        if self._retired_evidence_pending:
            return (False, "retired_evidence_recovery", generation)
        if head is None:
            return (False, "no_head", None)
        if load_active or self._force_full_remote:
            return (False, "manifest_load", generation)
        if self._startup_reconcile or self._transfer_recovery_pending:
            return (False, "startup_reconcile", generation)
        if self._local_recovery_pending:
            return (False, "local_snapshot_recovery", generation)
        if self.database.list_local_transfer_intents(limit=1):
            return (False, "local_transfer_pending", generation)
        if self.database.list_directory_puts(limit=1):
            return (False, "directory_publish_pending", generation)
        if self.database.has_unobserved_receipts():
            return (False, "receipt_readback_pending", generation)
        if self.watch.overflow or bool(
            getattr(self.workspace, "stream_recovery_pending", False)
        ):
            return (False, "overflow_recovery", generation)
        if not self._remote_intents_restored:
            return (False, "intent_restore", generation)
        if self._remote_transfer is not None or self._manifest_block_load is not None:
            return (False, "transfer_pending", generation)
        if self._remote_apply_queue or self._remote_rename_queue:
            return (False, "apply_pending", generation)
        if (
            self._remote_apply_intents_may_remain
            or self._remote_rename_intents_may_remain
            or pending_apply
            or pending_rename
        ):
            # Durable truth wins over the bounded in-memory restore cursor.  A
            # no-op manifest refresh can insert zero new rows while an older
            # restore page is still draining.
            return (False, "intent_restore", generation)
        return (True, None, generation)

    def _local_work_pending(self) -> bool:
        """True while any local mutation still needs coordinator turns.

        The push backstop may only stretch the *remote* poll: bytes in flight,
        a rename hash, or a queued/retry/inflight journal row must keep ticking
        at the polling cadence, because every one of those steps (ticket,
        upload drain, commit, readback) is spent one per tick.
        """

        if self._put_upload_states or self._rename_verify_future is not None:
            return True
        try:
            if self.database.list_conflict_resolutions_for_work(limit=1):
                return True
            if self.database.list_directory_puts(limit=1):
                return True
            if self.database.has_unobserved_receipts():
                return True
            _identity, directory_tombstones = (
                self.database.local_directory_tombstone_snapshot()
            )
            if any(
                path not in self._acknowledged_directory_deletes
                for path in directory_tombstones
            ):
                return True
            return self.database.next_operation_attempt_ns(now_ns=self._wall_now_ns()) is not None
        except (OSError, FabricCacheError, StateError, ValueError):
            return True

    @property
    def next_poll_delay(self) -> float:
        now = float(self._clock())
        if self._push_poll_requested and now >= self._signed_control_not_before:
            return 0.0
        if (
            self._remote_poll_backstop_seconds is not None
            and self._next_remote_poll - now > MAX_REMOTE_POLL_SECONDS
            and self._local_work_pending()
        ):
            # A local write landed after the idle tick armed the backstop:
            # a lost wake must never cost more than today's poll interval.
            self._next_remote_poll = min(
                self._next_remote_poll, now + MAX_REMOTE_POLL_SECONDS
            )
        immediate_full = bool(
            self._force_full_remote
            and self.database.get_remote_manifest_load() is None
            and now >= self._signed_control_not_before
        )
        operation_poll = self._next_operation_poll
        if (
            len(self._put_upload_states) >= UPLOAD_WORKER_CONCURRENCY
            and not any(
                future.done()
                for state in self._put_upload_states.values()
                for _block, future in state.active.values()
            )
        ):
            # Queued file nine is immediately due in the journal but cannot
            # acquire a stream yet. Avoid a zero-delay admission hot loop;
            # provider completion callbacks still wake this short wait early.
            operation_poll = max(operation_poll, now + 0.05)
        linger_until = self._inline_flush_not_before
        if linger_until is not None and operation_poll < linger_until:
            # The journal says this operation is due now, but the inline
            # batching policy has already decided it will not flush until
            # ``linger_until``. Without reconciling the two the runner spins:
            # every wake re-plans the same cohort, declines it again, and
            # schedules zero delay. Sleep to the policy deadline instead; a
            # new arrival (or any other work) still wakes us early through the
            # watcher event, so nothing is delayed BEYOND the linger.
            operation_poll = min(linger_until, now + MAX_REMOTE_POLL_SECONDS)
        control_delay = (
            0.0
            if immediate_full
            else max(
                0.0,
                min(
                    max(self._next_remote_poll, self._signed_control_not_before),
                    max(operation_poll, self._signed_control_not_before),
                    max(self._next_apply_poll, self._signed_control_not_before),
                )
                - now,
            )
        )
        return min(control_delay, self.watch.next_wake_delay)

    @staticmethod
    def _covering_directory_tombstone(
        path: str, tombstones: Sequence[str]
    ) -> str | None:
        covered = tuple(
            candidate
            for candidate in tombstones
            if path == candidate or path.startswith(candidate + "/")
        )
        return max(covered, key=len) if covered else None

    def _relocate_retired_promotion(
        self,
        promotion: RetiredQuarantinePromotion,
        tombstones: Sequence[str],
    ) -> tuple[RetiredQuarantinePromotion, str | None] | None:
        covering = self._covering_directory_tombstone(
            promotion.original_path, tombstones
        )
        if covering is None:
            return promotion, None
        destination = retired_quarantine_recovery_path(
            promotion.conflict_path
        )
        if promotion.visible_path == destination:
            return promotion, covering
        destination_fingerprint = self.workspace.stat_fingerprint(destination)
        source_fingerprint = self.workspace.stat_fingerprint(
            promotion.visible_path
        )
        if source_fingerprint is None and (
            destination_fingerprint is not None
            and destination_fingerprint.device_id == promotion.device_id
            and destination_fingerprint.file_id == promotion.file_id
        ):
            # Resume an interrupted same-filesystem rename in this process.
            # The retained marker makes the destination authoritative even if
            # a failure occurred before the in-memory lease was refreshed.
            return replace(promotion, visible_path=destination), covering
        if (
            source_fingerprint is None
            or source_fingerprint.device_id != promotion.device_id
            or source_fingerprint.file_id != promotion.file_id
        ):
            raise InvalidTask("The retired-inode promotion changed identity.")
        apply_token: str | None = None
        if self._started:
            apply_token = self.watch.arm_remote_apply(
                promotion.visible_path, destination
            )
        try:
            if destination_fingerprint is None:
                self.workspace.rename_file_by_fingerprint(
                    promotion.visible_path,
                    destination,
                    expected_fingerprint=source_fingerprint,
                    create_parents=True,
                )
            elif (
                destination_fingerprint.device_id == source_fingerprint.device_id
                and destination_fingerprint.file_id == source_fingerprint.file_id
            ):
                current_source = self.workspace.stat_fingerprint(
                    promotion.visible_path
                )
                if current_source is not None:
                    removed = self._remove_exact_with_mount_fence(
                        promotion.visible_path,
                        current_source,
                    )
                    if removed is None:
                        # prepare_mount_namespace intentionally runs before the
                        # native backend registers its admission provider. The
                        # source and destination are both durable links, so keep
                        # the marker queued and retry after registration instead
                        # of either failing startup or guessing that direct
                        # headless descriptors are closed.
                        return None
                    if removed is not True and self.workspace.stat_fingerprint(
                        promotion.visible_path
                    ) is not None:
                        # ``False`` proves only that the exact candidate was
                        # absent. A successor that appeared meanwhile is not
                        # authorized by that result.
                        return None
            else:
                raise UnsafePath(
                    "The deterministic Meshia recovery destination is occupied."
                )
            relocated = self.workspace.stat_fingerprint(destination)
            if (
                relocated is None
                or relocated.device_id != promotion.device_id
                or relocated.file_id != promotion.file_id
            ):
                raise InvalidTask("The retired-inode relocation changed identity.")
            updated = replace(promotion, visible_path=destination)
            if apply_token is not None:
                if not self.watch.commit_remote_apply(
                    apply_token,
                    {promotion.visible_path: None, destination: relocated},
                ):
                    self._startup_reconcile = True
                apply_token = None
            return updated, covering
        finally:
            if apply_token is not None:
                self.watch.abort_remote_apply(apply_token)

    def prepare_mount_namespace(self) -> int:
        """Hide tombstoned retire evidence before exposing the native mount."""

        with self._coordinator_lock:
            self.workspace.maintain_retired_quarantine()
            _identity, tombstones = (
                self.database.local_directory_tombstone_snapshot()
            )
            promotions = self.workspace.drain_retired_quarantine_promotions(
                max_entries=RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX
            )
            relocated = 0
            for promotion in promotions:
                current = promotion
                try:
                    relocation = self._relocate_retired_promotion(
                        promotion, tombstones
                    )
                    if relocation is None:
                        continue
                    current, covering = relocation
                    relocated += int(covering is not None)
                finally:
                    self.workspace.defer_retired_quarantine_promotion(current)
            status = self.workspace.retired_quarantine_status()
            self._retired_evidence_pending = bool(
                status.visible_promotion_backlog
                or status.visible_promotion_overflow
            )
            return relocated

    def _promotion_mutation_id(
        self, promotion: RetiredQuarantinePromotion
    ) -> str:
        identity = (
            f"{self._authority_scope_id}:{promotion.marker_path}:"
            f"{promotion.device_id}:{promotion.file_id}"
        )
        return str(uuid.uuid5(uuid.NAMESPACE_URL, "meshia-retire:" + identity))

    def _promotion_evidence_key(
        self, promotion: RetiredQuarantinePromotion
    ) -> str:
        identity = (
            f"{self._authority_scope_id}\0{promotion.marker_path}\0"
            f"{promotion.device_id}\0{promotion.file_id}"
        )
        return "retired:" + hashlib.sha256(identity.encode("utf-8")).hexdigest()

    def _handoff_retired_quarantine_promotions(self) -> int:
        """Durably journal a bounded page of aged open-handle evidence."""

        handled = self._reclaim_mount_retained_quarantine()
        self.workspace.maintain_retired_quarantine()
        _identity, tombstones = self.database.local_directory_tombstone_snapshot()
        promotions = self.workspace.drain_retired_quarantine_promotions(
            max_entries=min(
                self.max_events_per_tick,
                RETIRED_QUARANTINE_VISIBLE_BACKLOG_MAX,
            )
        )
        for promotion in promotions:
            current = promotion
            acknowledged = False
            try:
                relocation = self._relocate_retired_promotion(
                    promotion, tombstones
                )
                if relocation is None:
                    continue
                current, covering = relocation
                fingerprint = self.workspace.stat_fingerprint(current.visible_path)
                if (
                    fingerprint is None
                    or fingerprint.device_id != current.device_id
                    or fingerprint.file_id != current.file_id
                ):
                    raise InvalidTask(
                        "The promoted retired inode changed before publication."
                    )
                mutation_id = self._promotion_mutation_id(current)
                evidence_key = self._promotion_evidence_key(current)
                reason = (
                    "retired inode outlived a deleted directory and was moved "
                    "to Meshia Recovered Files"
                    if covering is not None
                    else "retired inode outlived its safe quarantine and was preserved"
                )
                existing_conflict = self.database.get_conflict_by_evidence_key(
                    evidence_key
                )
                if existing_conflict is not None:
                    if (
                        existing_conflict.path != current.original_path
                        or existing_conflict.reason != reason
                    ):
                        raise StateError(
                            "The retired-inode evidence key identifies different work."
                        )
                    # Conflict insertion is ordered after the durable upload
                    # handoff. A retained marker therefore only means the
                    # process stopped before its final filesystem ACK; do not
                    # manufacture another stage on restart.
                    self.workspace.acknowledge_retired_quarantine_promotion(
                        current, expected_fingerprint=fingerprint
                    )
                    acknowledged = True
                    handled += 1
                    continue
                operation = self.database.get_operation(mutation_id)
                if operation is None:
                    path_owner = self.database.get_latest_nonterminal_operation(
                        current.visible_path
                    )
                    if (
                        path_owner is not None
                        and path_owner.kind == "put"
                        and path_owner.staged_path is not None
                        and path_owner.staged_digest is not None
                        and path_owner.staged_size is not None
                    ):
                        owner_plan = _load_plan(
                            Path(path_owner.staged_path), path_owner
                        )
                        if owner_plan.source_fingerprint == _fingerprint_text(
                            fingerprint
                        ):
                            # A watcher edge may have journalled these exact
                            # bytes before quarantine maintenance ran. Reuse
                            # that durable snapshot instead of copying it and
                            # relying on enqueue coalescing to reveal its UUID.
                            operation = path_owner
                if operation is None:
                    operation = self._stage_local_put_bounded(
                        current.visible_path,
                        expected_source_digest=None,
                        mutation_id=mutation_id,
                    )
                local_digest: str | None
                local_fingerprint: str | None
                if operation is None:
                    intent = self.database.get_local_transfer_intent_by_id(
                        mutation_id
                    )
                    if intent is None:
                        # The serial large-file lane may already own this exact
                        # path/fingerprint under an earlier watcher UUID. That
                        # row is just as durable; bind the evidence to its real
                        # owner instead of waiting forever for an alias that
                        # cannot be inserted while the path key is occupied.
                        intent = self.database.get_local_transfer_intent(
                            current.visible_path
                        )
                    if intent is None:
                        # Another exact-path transfer may still own the serial
                        # copier. Keep the marker until this deterministic
                        # fingerprint fence can enter the durable journal.
                        continue
                    if (
                        intent.path != current.visible_path
                        or intent.source_fingerprint
                        != _fingerprint_text(fingerprint)
                    ):
                        raise StateError(
                            "The retired-inode recovery UUID identifies different work."
                        )
                    # The durable transfer intent pins the exact inode/stat
                    # tuple and survives restart. It is sufficient ownership
                    # for a 50+ GiB source-backed upload without first copying
                    # those bytes into private staging.
                    local_digest = None
                    local_fingerprint = intent.source_fingerprint
                else:
                    if (
                        operation.kind != "put"
                        or operation.path != current.visible_path
                        or operation.staged_path is None
                        or operation.staged_digest is None
                        or operation.staged_size is None
                        or operation.state in ("conflict", "quarantined")
                    ):
                        raise StateError(
                            "The retired-inode recovery UUID identifies different work."
                        )
                    if operation.state == "acked":
                        # An acknowledged remote object is durable even when
                        # its disposable local stage was already reclaimed.
                        local_digest = operation.staged_digest
                        local_fingerprint = None
                    else:
                        plan = _load_plan(Path(operation.staged_path), operation)
                        if _plan_is_source_backed(plan):
                            local_digest = None
                            local_fingerprint = plan.source_fingerprint
                        else:
                            local_digest = operation.staged_digest
                            local_fingerprint = None
                original_remote = self.database.get_remote_entry(
                    current.original_path
                )
                original_local = self.database.get_materialized(
                    current.original_path
                )
                self.database.record_conflict(
                    current.original_path,
                    reason,
                    evidence_key=evidence_key,
                    base_digest=(
                        original_local.clean_digest
                        if original_local is not None
                        else (original_remote.digest if original_remote else None)
                    ),
                    local_digest=local_digest,
                    local_fingerprint=local_fingerprint,
                    remote_digest=(
                        original_remote.digest if original_remote else None
                    ),
                    remote_generation=self._remote_generation(),
                    # The outgoing operation or source-backed transfer owns
                    # publication. Keeping a second unresolved-conflict stage
                    # reference would pin a full local copy forever after the
                    # recovered file is durable remotely.
                    staged_path=None,
                )
                visible_fingerprint = self.workspace.stat_fingerprint(
                    current.visible_path
                )
                if visible_fingerprint is None:
                    raise InvalidTask(
                        "The retired-inode evidence disappeared before acknowledgement."
                    )
                self.workspace.acknowledge_retired_quarantine_promotion(
                    current, expected_fingerprint=visible_fingerprint
                )
                acknowledged = True
                handled += 1
            finally:
                if not acknowledged:
                    self.workspace.defer_retired_quarantine_promotion(current)
        status = self.workspace.retired_quarantine_status()
        self._retired_evidence_pending = bool(
            status.visible_promotion_backlog
            or status.visible_promotion_overflow
        )
        self._next_retired_quarantine_maintenance = float(self._clock()) + (
            RETIRED_QUARANTINE_MAINTENANCE_SECONDS
            if status.entry_count
            else 60.0
        )
        return handled

    def start(self) -> None:
        if not self._started:
            self.prepare_mount_namespace()
            self._seed_watcher_durable_baselines()
            self.watch.start()
            self._started = True

    def _seed_watcher_durable_baselines(self) -> int:
        """Keyset-page every trusted local digest before collection starts."""

        seeded = 0
        after_path: str | None = None
        while True:
            page = self.database.list_materialized_entries(
                states=("clean",), limit=1_000, after_path=after_path
            )
            if not page:
                break
            baselines = {
                item.path: item.content_sha256
                for item in page
                if item.content_sha256 is not None
                and item.stat_fingerprint is not None
                and item.bytes_on_disk >= 0
            }
            seeded += self.watch.seed_durable_content_baselines(baselines)
            after_path = page[-1].path
            if len(page) < 1_000:
                break
        return seeded

    def stop(self) -> None:
        self.wake()
        if self._bulk_plan_cancel is not None:
            self._bulk_plan_cancel.set()
        if self._started:
            self.watch.stop()
            self._started = False
        self._local_copy_worker.cancel_current()
        self._local_copy_worker.close(timeout=0.25)
        for state in self._put_upload_states.values():
            for _block, future in state.active.values():
                future.cancel()
        with self._file_provider_sources_lock:
            source_tokens = tuple(self._file_provider_sources)
        for source_token in source_tokens:
            self.release_file_provider_source(source_token)
        self._close_orphan_stage_scan()

    def close(self) -> None:
        """Stop workers and close coordinator-owned staging authority."""

        self.stop()
        if self._object_reader is not None:
            self._object_reader.close()
        if self._staging_ledger is not None:
            self._staging_ledger.close()

    def set_stop_check(self, callback: Callable[[], bool] | None) -> None:
        """Install the runner's stop predicate; polls yield between stages.

        A turn used to run to completion after a stop was requested (29-35 s
        under hydration), which is what made the installer's mount release
        expire. Consulted before the remote poll, between mutation-drain
        turns, and before local transfer work; in-flight network calls still
        finish, so the bound is one stage, not one turn.
        """

        if callback is not None and not callable(callback):
            raise TypeError("stop check must be callable")
        self._stop_check = callback

    def _stop_requested(self, stage: str | None = None) -> bool:
        """Whether the runner asked to stop; ``stage`` marks the turn timeline."""

        if stage is not None:
            marks = getattr(self, "_turn_marks", None)
            if marks is not None and len(marks) < 64:
                marks.append((stage, time.monotonic()))
        callback = getattr(self, "_stop_check", None)
        if callback is None:
            return False
        try:
            return bool(callback())
        except Exception:  # noqa: BLE001 - never let a predicate break a poll
            return False

    def set_wake_callback(self, callback: Callable[[], None] | None) -> None:
        """Forward child work to an optional account-runtime supervisor.

        A standalone coordinator already wakes NodeRunner through ``watch``.
        Under ``WorkspaceRuntimeManager`` the runner waits on the manager's
        condition instead, so worker completions and mounted mutations must
        also wake that parent without adding a periodic polling loop.
        """

        if callback is not None and not callable(callback):
            raise TypeError("wake callback must be callable")
        self._wake_callback = callback

    def set_mount_cleanup_fence(
        self, provider: Callable[[str], Any] | None
    ) -> None:
        """Bind the mount's path admission fence for last-link reclamation.

        The provider owns the same lock as open/create admission and yields
        whether no tracked read or write description can still reference the
        path. An absent provider is unknown evidence, not proof: headless
        programs can hold direct descriptors into the workspace too.
        """

        if provider is not None and not callable(provider):
            raise TypeError("mount cleanup fence provider must be callable")
        self._mount_cleanup_fence_provider = provider
        if provider is not None:
            self._next_retired_quarantine_maintenance = 0.0

    @contextmanager
    def _mount_cleanup_fence(self, path: str) -> Iterator[bool]:
        provider = self._mount_cleanup_fence_provider
        if provider is None:
            yield False
            return
        with provider(path) as handles_closed:
            if not isinstance(handles_closed, bool):
                raise StateError("The mount cleanup fence returned invalid evidence.")
            yield handles_closed

    def _finish_retired_with_mount_fence(
        self,
        retired: RetiredRegularFile,
        *,
        preserve: bool,
    ) -> str | None:
        """Finalize one remote-owned retire without a check/unlink race."""

        if preserve:
            return self.workspace.finish_retired_file(retired, preserve=True)
        with self._mount_cleanup_fence(retired.original_path) as handles_closed:
            reclaim_result = (
                self.workspace.finish_retired_file_by_fingerprint(
                    retired, tracked_handles_closed=True
                )
                if handles_closed
                else None
            )
            if reclaim_result is True:
                return None
        if handles_closed and reclaim_result is False:
            # The O(1) fingerprint drifted. Hash only after releasing the mount
            # admission lock, then restore the user bytes visibly for conflict
            # staging. Unrelated Finder operations never wait on a large read.
            return self.workspace.finish_retired_file(retired, preserve=True)
        # A live mount description, a lock-order deferral, and a headless/no-
        # provider runtime are all unproven. Keep the clean inode hidden behind
        # its full post-retire fingerprint/digest. The five-second maintenance
        # lane promotes and stages it only if a late direct writer changes it;
        # unchanged entries are count-bounded without charging sparse length.
        return self.workspace.finish_retired_file(
            retired,
            preserve=False,
            quarantine_unchanged=True,
            retain_unchanged=True,
        )

    def _remove_exact_with_mount_fence(
        self,
        path: str,
        expected_fingerprint: FileFingerprint,
    ) -> bool | None:
        """Remove one exact file only while mount open admission is excluded.

        ``None`` means a registered mount backend reported the path busy;
        callers must leave the file visible and classify/re-stage it as user
        data.
        """

        with self._mount_cleanup_fence(path) as handles_closed:
            if not handles_closed:
                return None
            return self.workspace.remove_file_by_fingerprint(
                path,
                expected_fingerprint=expected_fingerprint,
                tracked_handles_closed=True,
            )

    def wake_mount_cleanup(self) -> None:
        """Run retained-inode reclamation promptly after a mount RELEASE."""

        self._next_retired_quarantine_maintenance = 0.0
        self.wake()

    def clear_directory_delete_acknowledgement(self, path: str) -> None:
        """Let a later remove of an explicitly recreated directory publish."""

        self._acknowledged_directory_deletes.pop(path, None)

    def stage_local_directory(
        self, path: str, *, retain_file_provider_receipt: bool = False
    ) -> DirectoryPut | None:
        """Persist mkdir intent before reporting the mounted operation complete."""

        if self._v2_commit_active():
            operation = self.database.queue_directory_put(path)
            if retain_file_provider_receipt:
                self.retain_file_provider_namespace_receipt(operation.mutation_id)
            self.wake()
            return operation
        return None

    def _publish_one_directory_put(self) -> bool:
        if not self._v2_commit_active():
            return False
        queued = self.database.list_directory_puts(limit=1)
        if not queued:
            return False
        entry = queued[0]
        if (
            entry.kind == "delete"
            and self.database.list_nonterminal_operations_touching_prefix(
                entry.path, limit=1
            )
        ):
            # An empty-directory delete is a fence after *all* byte-namespace
            # work below it, not only file deletes. A safe-save can close and
            # journal a temporary file, rename that file out of its temporary
            # directory, and rmdir the now-locally-empty directory while the
            # put/rename receipts are still pending. Publishing the rmdir
            # first sees the remote temporary child and returns
            # FABRIC_DIRECTORY_NOT_EMPTY; conflict recovery then quarantines
            # the very rename which would have emptied it. Every publisher
            # (including the idle-turn fallback) must therefore wait for any
            # pending source or destination below the directory to settle.
            return False
        operation: dict[str, Any] = {"op": "put", "path": entry.path, "kind": "dir"}
        if entry.kind == "rename":
            operation = {
                "op": "rename", "path": entry.path,
                "destination_path": entry.destination_path,
            }
        elif entry.kind == "delete":
            operation = {"op": "delete", "path": entry.path, "empty_directory_only": True}
        try:
            sequence = self._commit_directory_operation(
                entry.path, entry.mutation_id, operation
            )
        except RemoteError as error:
            if error.remote_code in {
                "FABRIC_DIRECTORY_NOT_EMPTY", "FABRIC_PATH_EXISTS",
                "FABRIC_PATH_DIVERGED", "FABRIC_PATH_ABSENT",
                "FABRIC_DESTINATION_EXISTS", "FABRIC_RENAME_INTO_SELF",
            }:
                # A terminal path verdict cannot poison the FIFO. Retire its
                # dependent chain atomically with durable conflict evidence;
                # especially never execute a rename's cleanup delete after
                # the rename lost to a concurrent destination writer.
                affected = self.database.conflict_directory_operations(
                    entry.path, entry.mutation_id,
                    f"Directory {entry.kind} rejected: {error.remote_code}; local and remote paths preserved.",
                )
                for item in affected:
                    self._acknowledged_directory_deletes.pop(item.path, None)
                    self._complete_file_provider_namespace_receipt(
                        item.mutation_id,
                        error=f"Directory {item.kind} rejected: {error.remote_code}",
                    )
                self._next_remote_poll = 0.0
                self.logger.record(
                    "fabric_directory_operation_conflict", path=entry.path,
                    code=error.remote_code, affected_operations=len(affected),
                )
            raise
        self.database.record_namespace_receipt(sequence)
        self.database.complete_directory_put(entry.path, entry.mutation_id)
        self._complete_file_provider_namespace_receipt(entry.mutation_id)
        if entry.kind == "delete":
            _identity, tombstones = self.database.local_directory_tombstone_snapshot()
            if entry.path in tombstones:
                self._acknowledged_directory_deletes[entry.path] = sequence
        self._next_remote_poll = 0.0
        return True

    def stage_local_directory_rename(
        self,
        path: str,
        destination_path: str,
        *,
        retain_file_provider_receipt: bool = False,
    ) -> DirectoryPut | None:
        """Journal an empty-directory rename after its earlier mkdir, if any."""
        if self._v2_commit_active():
            operation = self.database.queue_directory_rename(path, destination_path)
            if retain_file_provider_receipt:
                self.retain_file_provider_namespace_receipt(operation.mutation_id)
            self.wake()
            return operation
        return None

    def _commit_directory_operation(
        self, path: str, mutation_id: str, operation: dict[str, Any]
    ) -> int:
        """Replay a stable metadata mutation, never treat transport success as commit."""

        response = self._signed_control_request(
            self.transport.commit_v2,
            {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "mutation_id": mutation_id,
                "request_digest": hashlib.sha256(
                    json.dumps([operation], sort_keys=True, separators=(",", ":")).encode("utf-8")
                ).hexdigest(),
                "ops": [operation],
            },
        )
        verdicts = response.get("ops") if isinstance(response, Mapping) else None
        sequence = response.get("seq") if isinstance(response, Mapping) else None
        if (
            not isinstance(response, Mapping)
            or response.get("schema") != "meshia.fabric_commit.v2"
            or response.get("mutation_id") != mutation_id
            or isinstance(sequence, bool)
            or not isinstance(sequence, int)
            or sequence < 0
            or not isinstance(verdicts, list)
            or len(verdicts) != 1
            or not isinstance(verdicts[0], Mapping)
            or verdicts[0].get("path") != path
            or verdicts[0].get("index") != 0
        ):
            raise NetworkError("Meshia returned an invalid Fabric directory commit receipt.")
        verdict = verdicts[0]
        if verdict.get("status") == "applied" or (
            operation["op"] == "delete"
            and verdict.get("status") == "rejected"
            and verdict.get("code") == "FABRIC_PATH_ABSENT"
        ):
            return sequence
        raise RemoteError(
            409, str(verdict.get("code") or "FABRIC_DIRECTORY_COMMIT_REJECTED"),
            "The directory changed before the mutation could be published.",
        )

    def _finalize_acknowledged_directory_deletes(self) -> int:
        finalized = 0
        identity, tombstones = self.database.local_directory_tombstone_snapshot()
        live = set(tombstones)
        for path, acknowledged_generation in tuple(
            self._acknowledged_directory_deletes.items()
        ):
            if path not in live:
                self._acknowledged_directory_deletes.pop(path, None)
                continue
            # Keep suppressing the locally deleted directory until a refreshed
            # authoritative head has incorporated the delete receipt. Retiring
            # the tombstone immediately after the POST can briefly re-expose
            # descendants from the older cached manifest.
            if identity is None or identity[0] < acknowledged_generation:
                continue
            self.workspace.prune_empty_directories(path)
            if self.workspace.directory_exists(path):
                continue
            self.database.forget_local_directory_tombstone(path)
            self._acknowledged_directory_deletes.pop(path, None)
            finalized += 1
        return finalized

    def _publish_one_directory_tombstone(self) -> bool:
        # New v2 namespace operations share one durable FIFO. Only old
        # tombstones from before that queue need the fallback below.
        if self._v2_commit_active() and self.database.list_directory_puts(limit=1):
            return self._publish_one_directory_put()
        identity, tombstones = self.database.local_directory_tombstone_snapshot()
        if identity is None:
            return False
        path = next(
            (
                candidate
                for candidate in sorted(tombstones, key=lambda value: (value.count("/"), value))
                if candidate not in self._acknowledged_directory_deletes
            ),
            None,
        )
        if path is None:
            return False
        if self._v2_commit_active():
            mutation_id = self.database.directory_delete_mutation_id(path)
            if mutation_id is None:
                return False
            generation = self._commit_directory_operation(
                path, mutation_id,
                {"op": "delete", "path": path, "empty_directory_only": True},
            )
            self.database.record_namespace_receipt(generation)
            self._acknowledged_directory_deletes[path] = generation
            self._next_remote_poll = 0.0
            return True
        generation, digest = identity
        if digest is None:
            # A Fabric v2 head carries no manifest digest. `delete_path` is a
            # v1 route that fences on (generation, manifest digest), so this
            # request is malformed by construction and can only be rejected --
            # previously as the literal string "None", forever. Refuse to send
            # it and say why; the directory stays locally hidden (its overlay
            # is durable) and its children are removed by the ordinary
            # per-path delete lane, which batches.
            if path not in self._directory_tombstones_unroutable:
                self._directory_tombstones_unroutable.add(path)
                self.logger.record(
                    "fabric_directory_tombstone_unroutable",
                    path=path,
                    base_generation=generation,
                    reason="the remote head has no manifest digest (Fabric v2)",
                )
            return False
        mutation_id = str(
            uuid.uuid5(
                uuid.NAMESPACE_URL,
                (
                    "meshia-directory-delete:"
                    f"{self._authority_scope_id}:{generation}:{digest}:{path}"
                ),
            )
        )
        try:
            response = self._signed_control_request(
                self.transport.delete_path,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "mutation_id": mutation_id,
                    "path": path,
                    "base_generation": generation,
                    "base_manifest_digest": digest,
                },
            )
        except RemoteError as error:
            if (
                error.status == 409
                and error.remote_code
                == "FABRIC_DIRECTORY_DELETE_BASE_DIVERGED"
            ):
                self._force_full_remote = True
                self._next_remote_poll = 0.0
                return True
            raise
        if (
            set(response)
            != {
                "schema",
                "workspace",
                "mutation_id",
                "path",
                "already_absent",
                "manifest_generation",
                "manifest_digest",
            }
            or response.get("schema")
            != "meshia.connected_host_fabric_directory_delete_receipt.v1"
            or response.get("workspace") != WORKSPACE_MOUNT
            or response.get("mutation_id") != mutation_id
            or response.get("path") != path
            or not isinstance(response.get("already_absent"), bool)
            or not isinstance(response.get("manifest_generation"), int)
            or isinstance(response.get("manifest_generation"), bool)
            or response.get("manifest_generation", 0) < generation
            or not _digest(response.get("manifest_digest"))
        ):
            raise NetworkError(
                "Meshia returned an invalid Fabric directory delete receipt."
            )
        self._acknowledged_directory_deletes[path] = response[
            "manifest_generation"
        ]
        self._force_full_remote = True
        self._next_remote_poll = 0.0
        self.logger.record(
            "fabric_directory_delete_acknowledged",
            path=path,
            already_absent=response["already_absent"],
            generation=response["manifest_generation"],
        )
        return True

    def _reclaim_mount_retained_quarantine(self) -> int:
        """Reclaim unchanged hidden preimages only under a registered path proof."""

        if self._mount_cleanup_fence_provider is None:
            return 0
        reclaimed = 0
        candidates = self.workspace.retained_retired_files(
            max_entries=min(
                self.max_events_per_tick,
                RETIRED_QUARANTINE_MAX_ENTRIES,
            )
        )
        for retired in candidates:
            with self._mount_cleanup_fence(retired.original_path) as handles_closed:
                if not handles_closed:
                    continue
                reclaim_result = self.workspace.finish_retired_file_by_fingerprint(
                    retired, tracked_handles_closed=True
                )
            if reclaim_result is True:
                reclaimed += 1
            elif reclaim_result is False:
                # A writer drifted between maintenance and the fence. Promote
                # outside mount admission; the ordinary quarantine handoff below
                # hashes/stages the visible bytes without blocking Finder.
                self.workspace.finish_retired_file(retired, preserve=True)
            # ``None`` is a Windows share/access denial after mount admission:
            # it proves neither drift nor closure, so retain the durable quiet
            # owner and retry after the sharing handle releases.
        if reclaimed:
            _identity, tombstones = self.database.local_directory_tombstone_snapshot()
            for path in tombstones:
                self.workspace.prune_empty_directories(path)
                if not self.workspace.directory_exists(path):
                    self.database.forget_local_directory_tombstone(path)
        return reclaimed

    def wake(self) -> None:
        self.watch.wake()
        callback = self._wake_callback
        if callback is not None:
            callback()

    def set_remote_poll_backstop(self, seconds: float | None) -> None:
        """Stretch idle remote polling to ``seconds`` while push is healthy.

        ``None`` restores the MIN/MAX ramp and clamps any pending long deadline
        so the coordinator is back on today's cadence within one tick. Plain
        attribute writes on purpose: the push thread must never wait behind a
        multi-second maintenance tick holding the coordinator lock.
        """

        if seconds is not None and (
            isinstance(seconds, bool)
            or not isinstance(seconds, (int, float))
            or not seconds > 0
        ):
            raise ValueError("remote poll backstop must be positive or None")
        previous = self._remote_poll_backstop_seconds
        self._remote_poll_backstop_seconds = (
            float(seconds) if seconds is not None else None
        )
        if seconds is None and previous is not None:
            now = float(self._clock())
            self._poll_delay = min(self._poll_delay, MAX_REMOTE_POLL_SECONDS)
            self._next_remote_poll = min(
                self._next_remote_poll, now + MAX_REMOTE_POLL_SECONDS
            )
        if previous != self._remote_poll_backstop_seconds:
            self.wake()

    def request_remote_poll(self) -> None:
        """A push event named this workspace: read remote truth on the next turn."""

        if not self._push_poll_requested:
            self._push_poll_requested_at = float(self._clock())
        self._push_poll_requested = True
        self.wake()

    @property
    def remote_poll_backstop_seconds(self) -> float | None:
        return self._remote_poll_backstop_seconds

    def wait(self, timeout: float) -> bool:
        """Wait for local work or the earlier remote deadline."""

        if timeout < 0:
            raise ValueError("timeout must not be negative")
        return self.watch.wait(min(float(timeout), self.next_poll_delay))

    def _extend_signed_control_cooldown(self, delay_seconds: float) -> None:
        if (
            isinstance(delay_seconds, bool)
            or not isinstance(delay_seconds, (int, float))
            or delay_seconds < 0
        ):
            raise StateError("The Fabric signed-control delay is invalid.")
        self._signed_control_not_before = max(
            self._signed_control_not_before,
            float(self._clock()) + float(delay_seconds),
        )

    def _signed_control_request(
        self, request: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        """Issue one signed call behind the host-global Retry-After fence."""

        with self._signed_control_lock:
            if float(self._clock()) < self._signed_control_not_before:
                raise NetworkError(
                    "Fabric signed control is cooling down after rate limiting."
                )
            self._signed_control_calls += 1
            try:
                response = request(payload)
            except RemoteError as error:
                if error.status == 429:
                    self._extend_signed_control_cooldown(
                        max(
                            MIN_REMOTE_POLL_SECONDS * 2,
                            error.retry_after_seconds or 0.0,
                        )
                    )
                raise
            if not isinstance(response, dict):
                raise NetworkError("Meshia returned a non-object Fabric response.")
            return response

    # -------------------------------------------------------------- main loop

    def poll_once(self) -> bool:
        """Perform bounded serialized maintenance and return ``did_work``."""

        if self._stop_requested():
            return False
        with self._coordinator_lock:
            if self._push_poll_requested:
                self._next_remote_poll = 0.0
            started = time.monotonic()
            self._turn_marks: list[tuple[str, float]] = []
            try:
                return self._poll_once_locked()
            finally:
                elapsed = time.monotonic() - started
                marks = self._turn_marks
                self._turn_marks = []
                if elapsed >= FABRIC_SLOW_TURN_SECONDS:
                    self.logger.record(
                        "fabric_sync_turn_slow",
                        seconds=round(elapsed, 2),
                        stages=" ".join(
                            f"{stage}@{int((at - started) * 1000)}ms" for stage, at in marks
                        )[:250],
                    )

    def _poll_once_locked(self) -> bool:
        """Implementation protected from concurrent File Provider mutations."""

        self.watch.begin_poll()
        watch_overflow = self.watch.overflow
        watch_recovery_generation = self.watch.recovery_generation
        new_watch_overflow = bool(
            watch_overflow
            and watch_recovery_generation
            != self._observed_watch_recovery_generation
        )
        # Record the generation before any fallible recovery work. A failed
        # attempt therefore honors its scheduled backoff instead of treating a
        # persistent overflow level as a fresh zero-delay notification.
        self._observed_watch_recovery_generation = watch_recovery_generation
        local_events = mutations = remote_applies = evicted = 0
        resolution_advanced = False
        resolution_control = False
        self._local_hashes = 0
        remote_changed = False
        self._remote_changed_paths = ()
        remote_polled = False
        apply_attempted = False
        reconciled_head_identity: tuple[int, str] | None = None
        error_text: str | None = None
        now = float(self._clock())
        signed_control_ready = now >= self._signed_control_not_before
        adoption_fence = self._adoption_reconcile_pending
        try:
            staging_ready = self._advance_staging_repair()
            if self._transfer_recovery_pending:
                report = self._transfer_store.recover(
                    max_entries=64,
                    max_verify_bytes=0,
                    max_seconds=0.05,
                )
                self._transfer_recovery_pending = report.more_remaining
            if (
                self._local_recovery_pending
                or now >= self._next_local_recovery_scan
            ):
                local_events += self._reconcile_unjournaled_local_snapshots()
            self._reclaim_finalized_remote_transfers()
            if getattr(self.workspace, "stream_recovery_pending", False):
                self.workspace.recover_stale_stream_temps()
            workspace_recovery_pending = bool(
                getattr(self.workspace, "stream_recovery_pending", False)
            )
            if (
                not workspace_recovery_pending
                and not self._adoption_reconcile_pending
                and staging_ready
                and (
                    self._retired_evidence_pending
                    or now >= self._next_retired_quarantine_maintenance
                )
            ):
                local_events += self._handoff_retired_quarantine_promotions()
            # Recover durable eviction intent before observing watcher deletes
            # or performing the startup scan. A file missing under an explicit
            # intent is local cache cleanup, never a remote tombstone.
            evicted += self._recover_evictions()
            self._restore_remote_intents()
            self._flush_deferred_directory_events()
            directory_overlay_active = (
                self.database.get_active_directory_rename() is not None
            )
            if now >= self._next_orphan_stage_scan:
                self._scavenge_unjournaled_stages()
                self._next_orphan_stage_scan = now + (
                    0.0
                    if self._orphan_stage_scan is not None
                    else ORPHAN_STAGE_SCAN_INTERVAL_SECONDS
                )
            # Cleanup cannot sit behind a persistently failing remote poll: an
            # acknowledged stage otherwise fills the local staging budget even
            # though its mutation is already durable remotely.
            self._cleanup_acked_stages()
            # The first rule is intentional: an observed local edit becomes a
            # durable journal row before this tick can make a network call.
            if not self._adoption_reconcile_pending and staging_ready:
                local_events += self._poll_local_transfer()
                local_events += self._drain_local_events()

            head = self.database.get_remote_manifest_head()
            needs_full_local = self._startup_reconcile or watch_overflow
            # Never classify local bytes against an unpublished/incomplete
            # first manifest.  The old published head remains authoritative
            # while a replacement snapshot is paged into its isolated table.
            can_reconcile = (
                needs_full_local
                and not directory_overlay_active
                and not workspace_recovery_pending
                and head is not None
            )
            recovery = self.watch.begin_recovery() if can_reconcile else None
            if can_reconcile and head is not None:
                reconciled_head_identity = (head.generation, head.digest)
                if self._durable_adoption_pending:
                    self._authority_adoption_unmatched = False
                local_events += self._reconcile_local_namespace()

            if (
                not needs_full_local
                and staging_ready
                and signed_control_ready
                and not adoption_fence
            ):
                resolution_advanced, resolution_control = (
                    self._advance_one_conflict_resolution()
                )
                if resolution_control:
                    remote_polled = True

            load_pending_for_schedule = (
                self.database.get_remote_manifest_load() is not None
            )
            if self._stop_requested("before_remote"):
                # Stop was requested during the local phases: do not start a
                # remote poll or an apply wave on the way out.
                return bool(local_events or mutations or evicted)
            remote_due = (
                signed_control_ready
                and (
                    new_watch_overflow
                    or (self._force_full_remote and not load_pending_for_schedule)
                    or now >= self._next_remote_poll
                )
            )
            local_completion_ready = bool(
                (
                    any(
                        future.done()
                        for state in self._put_upload_states.values()
                        for _block, future in state.active.values()
                    )
                )
                or (
                    self._rename_verify_future is not None
                    and self._rename_verify_future.done()
                )
            )
            if (
                not resolution_advanced
                and not resolution_control
                # Completed provider PUTs and byte-only rename hashes are already
                # outside the signed-control lane. Drain them before a preferred
                # manifest refresh can fail and move every maintenance deadline
                # into remote backoff. Running work remains non-blocking and
                # preserves remote fairness.
                and (
                    local_completion_ready
                    or not (remote_due and self._prefer_remote_control)
                )
            ):
                # A tick historically owned at most ONE signed mutation-side
                # control request. That bound is a per-tick cap, not a rate
                # limit, so a backlog paid the runner's whole idle interval per
                # batch: measured live at ~3.4 s between commits, which for
                # 80,000 files is 1,250 ticks and >5 hours of pure cadence
                # against a ~10 minute byte floor. Drain instead while a
                # backlog is actually present, bounded by turns AND wall time
                # so remote control, commands and heartbeats are never starved.
                signed_calls_before_operation = self._signed_control_calls
                drain_started = float(self._clock())
                drained = 0
                # Only FRESH work may extend a drain. A turn that rejects an
                # item re-queues it, and continuing would retry it immediately
                # inside the same tick -- defeating the backoff a park exists
                # to impose and re-sending a request the server just refused.
                # Stop as soon as the next sendable row is one this tick has
                # already attempted.
                # The FIRST turn is unconditional, exactly as before: it also
                # serves commit-unknown readbacks and tombstones that never
                # appear in the sendable journal. Only CONTINUATION is gated.
                attempted: set[str] = set()
                head = self._next_sendable_mutation_id()
                if head is not None:
                    attempted.add(head)
                while self._process_one_operation(
                    allow_signed_control=(
                        signed_control_ready and not adoption_fence
                    )
                ):
                    drained += 1
                    mutations = 1
                    self._prefer_remote_control = True
                    if self._stop_requested("mutation_drain"):
                        break
                    if not self._last_turn_was_batch_commit:
                        break
                    if drained >= MAX_MUTATION_TURNS_PER_TICK:
                        break
                    if float(self._clock()) - drain_started >= MUTATION_DRAIN_BUDGET_SECONDS:
                        break
                    head = self._next_sendable_mutation_id()
                    if head is None or head in attempted:
                        break
                    attempted.add(head)
                if not drained and (
                    signed_control_ready
                    and not adoption_fence
                    and self._signed_control_calls
                    == signed_calls_before_operation
                    and (
                        self._publish_one_directory_put()
                        or self._publish_one_directory_tombstone()
                    )
                ):
                    mutations = 1
                    self._prefer_remote_control = True

            apply_due = bool(
                (self._remote_apply_queue or self._remote_rename_queue)
                and staging_ready
                and signed_control_ready
                and not adoption_fence
                and now >= self._next_apply_poll
            )
            should_poll_remote = bool(
                remote_due
                and not resolution_control
                and mutations == 0
                # A queued rename is derived from an earlier cursor.  When a
                # newer remote poll is due, refresh first so a destination that
                # advanced X->Y cannot be blessed clean as stale X locally.
                and (
                    (
                        bool(self._remote_rename_queue)
                        and self._prefer_remote_control
                    )
                    or not (apply_due and not self._prefer_remote_control)
                )
            )
            if should_poll_remote:
                # Consume a push only when its answering poll starts, not at
                # the top of a turn that may be spent on local work. Capture
                # its timestamp before the signed call: a newer event can then
                # queue independently while this poll is in flight and remain
                # immediately due for the following turn.
                push_poll_consumed = self._push_poll_requested
                push_requested_at = (
                    self._push_poll_requested_at if push_poll_consumed else None
                )
                if push_poll_consumed:
                    self._push_poll_requested = False
                    self._push_poll_requested_at = None
                remote_polled = True
                force_full = self._force_full_remote or watch_overflow
                self._force_full_remote = False
                poll_started_at = float(self._clock())
                remote_changed = self.refresh_remote(
                    force_full=force_full
                )
                if push_poll_consumed:
                    # The namespace is visible on the mount as soon as this
                    # poll ingested the manifest; bytes hydrate on demand.
                    polled_at = float(self._clock())
                    self.logger.record(
                        "push_remote_poll",
                        wait_ms=(
                            int((poll_started_at - push_requested_at) * 1000)
                            if push_requested_at is not None
                            else None
                        ),
                        poll_ms=int((polled_at - poll_started_at) * 1000),
                        event_to_visible_ms=(
                            int((polled_at - push_requested_at) * 1000)
                            if push_requested_at is not None
                            else None
                        ),
                        remote_changed=remote_changed,
                        queued_applies=len(self._remote_apply_queue)
                        + len(self._remote_rename_queue),
                    )
                    self._push_apply_pending_since = (
                        push_requested_at if remote_changed else None
                    )
                self._receipt_readback_pending = False
                if (
                    self._authoritative_conflicts_waiting
                    and not self._force_full_remote
                    and self.database.get_remote_manifest_load() is None
                ):
                    self._finalize_authoritative_operation_conflicts()
                if (
                    not needs_full_local
                    and staging_ready
                    and not adoption_fence
                    and not watch_overflow
                    and not directory_overlay_active
                    and not workspace_recovery_pending
                    and not self._force_full_remote
                    and self.database.get_remote_manifest_load() is None
                ):
                    remote_applies += (
                        self._repair_legacy_content_missing_conflicts()
                    )
                self._prefer_remote_control = False

            if can_reconcile:
                assert recovery is not None
                if not self.watch.acknowledge_recovery(recovery):
                    raise StateError(
                        "Local workspace observation overflowed during recovery."
                    )
                durable_adoption = self._durable_adoption_pending
                if durable_adoption:
                    current_head = self.database.get_remote_manifest_head()
                    adoption_head_stable = bool(
                        current_head is not None
                        and reconciled_head_identity
                        == (current_head.generation, current_head.digest)
                        and self.database.get_remote_manifest_load() is None
                        and not self._force_full_remote
                    )
                    if not adoption_head_stable:
                        # The remote cursor moved (or began a replacement full
                        # load) after this tick's local tree proof. Repeat the
                        # complete scan against the newly published head before
                        # releasing the durable write fence.
                        self._startup_reconcile = True
                    elif (
                        self._strict_authority_adoption
                        and self._authority_adoption_unmatched
                    ):
                        # A session/workspace/root/host boundary cannot infer
                        # ownership of unmatched visible bytes. Keep both the
                        # DB publication fence and coordinator gate closed.
                        # An operator may resolve the preserved conflicts and
                        # restart to request another complete adoption scan.
                        self._startup_reconcile = False
                    else:
                        # Only the complete, acknowledged visible-tree scan
                        # above may release the DB authority fence. Generation-
                        # only offline edits are staged by the follow-up normal
                        # reconciliation after publication is permitted.
                        self.database.complete_authority_adoption(
                            expected_scope_id=self._authority_scope_id
                        )
                        self._durable_adoption_pending = False
                        self._strict_authority_adoption = False
                        self._startup_reconcile = True
                        self._adoption_reconcile_pending = False
                else:
                    current_head = self.database.get_remote_manifest_head()
                    # A poll may replace the namespace after this turn's local
                    # scan. Do not clear the new snapshot's recovery request
                    # using a proof against the preceding head, especially when
                    # a reset revoked an older remote-apply intent.
                    self._startup_reconcile = bool(
                        current_head is None
                        or reconciled_head_identity
                        != (current_head.generation, current_head.digest)
                        or self.database.get_remote_manifest_load() is not None
                        or self._force_full_remote
                    )
                    self._adoption_reconcile_pending = False

            if self._stop_requested("after_remote_poll"):
                # The remote poll (a chain of signed calls) finished after a
                # stop was requested: no apply wave, no conflict work.
                return bool(local_events or mutations or evicted or remote_polled)
            if not remote_polled and mutations == 0 and apply_due:
                apply_attempted = True
                remote_applies = self._apply_remote_working_set()
                if self._push_apply_pending_since is not None and remote_applies:
                    self.logger.record(
                        "push_remote_apply",
                        applies=remote_applies,
                        event_to_visible_ms=int(
                            (float(self._clock()) - self._push_apply_pending_since) * 1000
                        ),
                    )
                    if not self._remote_apply_queue and not self._remote_rename_queue:
                        self._push_apply_pending_since = None
                self._prefer_remote_control = True
                self._next_apply_poll = float(self._clock()) + MIN_REMOTE_POLL_SECONDS
            self._flush_access_touches()
            evicted = self._evict_materialized_working_set()
            evicted += self.maintain_materialized_cache()
            local_events += self._finalize_acknowledged_directory_deletes()
            self._cleanup_acked_stages()
            # Keep an acknowledged prefix projection until both its receipt
            # generation and every durable local cache intent are complete.
            self._prune_directory_rename_source()
            self.database.mark_directory_renames_observed()
            if remote_changed:
                # The remote view just advanced; a rename/put parked in conflict
                # may now be satisfied by the remote (a server-side move landed)
                # or freshly re-submittable. Retire/re-arm those so a stale
                # conflict does not outlive the state that caused it.
                local_events += self._auto_resolve_satisfied_conflicts()
            operation_deadline_ns = self.database.next_operation_attempt_ns(
                now_ns=self._wall_now_ns()
            )
            if operation_deadline_ns is None:
                self._next_operation_poll = float("inf")
            else:
                operation_delay = max(
                    0.0,
                    (operation_deadline_ns - self._wall_now_ns()) / 1_000_000_000,
                )
                self._next_operation_poll = float(self._clock()) + operation_delay
            if self._remote_apply_queue or self._remote_rename_queue:
                if remote_polled and not apply_attempted:
                    self._next_apply_poll = float(self._clock())
            else:
                self._next_apply_poll = float("inf")
            manifest_load_active = self.database.get_remote_manifest_load() is not None
            active = bool(
                local_events
                or mutations
                or resolution_advanced
                or resolution_control
                or remote_changed
                or remote_applies
                or self._next_operation_poll <= float(self._clock())
                or self._remote_apply_queue
                or self._remote_rename_queue
                or any(
                    path not in self._acknowledged_directory_deletes
                    for path in self.database.local_directory_tombstone_snapshot()[1]
                )
                or workspace_recovery_pending
                or manifest_load_active
                or not staging_ready
            )
            if active:
                self._poll_delay = MIN_REMOTE_POLL_SECONDS
                self._next_remote_poll = (
                    max(float(self._clock()), self._next_remote_poll)
                    if manifest_load_active
                    else (
                        float(self._clock())
                        if self._receipt_readback_pending
                        else float(self._clock()) + self._poll_delay
                    )
                )
            elif remote_polled:
                backstop = self._remote_poll_backstop_seconds
                # The backstop only stretches idle remote polling: while any
                # local operation is queued, retrying, or moving bytes the
                # coordinator keeps the MIN/MAX ramp so ticket, drain, commit
                # and readback turns arrive at the same cadence as polling.
                self._poll_delay = (
                    backstop
                    if backstop is not None and not self._local_work_pending()
                    else min(
                        MAX_REMOTE_POLL_SECONDS,
                        max(MIN_REMOTE_POLL_SECONDS, self._poll_delay * 2),
                    )
                )
                self._next_remote_poll = float(self._clock()) + self._poll_delay
            if remote_polled or apply_attempted:
                self._readiness_error = False
                self._readiness_error_reason = None
                if self._retry_error_code is not None:
                    self.logger.record(
                        "fabric_sync_recovered",
                        previous_error_code=self._retry_error_code,
                        suppressed_retries=self._suppressed_retry_logs,
                    )
                    self._retry_error_code = None
                    self._suppressed_retry_logs = 0
            self.last_error = None
        except (
            OSError,
            FabricCacheError,
            InvalidTask,
            NetworkError,
            RemoteError,
            StateError,
            TransferError,
            UnsafePath,
            ValueError,
        ) as error:
            error_text = str(error)
            self.last_error = error_text
            self._readiness_error = True
            self._readiness_error_reason = _fabric_readiness_reason(error)
            retry_hint = (
                error.retry_after_seconds
                if isinstance(error, RemoteError)
                and error.status == 429
                and error.retry_after_seconds is not None
                else 0.0
            )
            self._poll_delay = max(
                retry_hint,
                min(
                    MAX_ERROR_POLL_SECONDS,
                    max(MIN_REMOTE_POLL_SECONDS * 2, self._poll_delay * 2),
                ),
            )
            retry_deadline = float(self._clock()) + self._poll_delay
            if isinstance(error, RemoteError) and error.status == 429:
                self._extend_signed_control_cooldown(self._poll_delay)
                retry_deadline = max(
                    retry_deadline, self._signed_control_not_before
                )
            self._next_remote_poll = retry_deadline
            if self._next_operation_poll <= float(self._clock()):
                self._next_operation_poll = retry_deadline
            if self._next_apply_poll <= float(self._clock()):
                self._next_apply_poll = retry_deadline
            error_code = (
                error.remote_code
                if isinstance(error, RemoteError) and error.remote_code
                else getattr(error, "code", type(error).__name__)
            )
            if error_code != self._retry_error_code:
                self.logger.record(
                    "fabric_sync_retry",
                    error_code=error_code,
                    readiness_reason=self._readiness_error_reason,
                    error=error_text,
                    traceback_tail=_traceback_tail(error),
                )
                self._retry_error_code = error_code
                self._suppressed_retry_logs = 0
            else:
                self._suppressed_retry_logs += 1
        self._last_tick = SyncTick(
            local_events=local_events,
            local_hashes=self._local_hashes,
            mutations=mutations,
            remote_changed=remote_changed,
            remote_changed_paths=self._remote_changed_paths,
            remote_applies=remote_applies,
            evicted_bytes=evicted,
            error=error_text,
        )
        return self._last_tick.did_work

    # ---------------------------------------------------------- remote index

    def _note_fabric_v2_unsupported(self, where: str, status: int) -> None:
        """Latch v2 off for this process on the one explicit unsupported signal.

        A 404 is the only thing that means "this control plane has no v2
        route". A generic 400 is NOT treated as unsupported: it cannot be
        told apart from a malformed request, and inferring capability from one
        silently disabled the inline lane for a whole process once already.
        """

        if not self._fabric_v2_enabled:
            return
        self._fabric_v2_enabled = False
        self.logger.record(
            "fabric_v2_unsupported", where=where, status=status
        )

    def refresh_remote(self, *, force_full: bool = False) -> bool:
        if self._fabric_v2_refresh_active():
            try:
                return self._refresh_remote_v2(force_full=force_full)
            except RemoteError as error:
                if error.status != 404:
                    raise
                # The commit path already latched on an explicit 404, but the
                # REFRESH path did not, so a v2 node meeting a control plane
                # without v2 routes retried the same 404 forever and never
                # converged -- it could not even fall back to v1. Latch here
                # too and take the v1 path in this same tick rather than
                # losing one.
                self._note_fabric_v2_unsupported("refresh", error.status)
        current_head = self.database.get_remote_manifest_head()
        load = self.database.get_remote_manifest_load()
        if current_head is None or force_full or load is not None:
            return self._load_full_manifest_page(load)

        response = self._signed_control_request(
            self.transport.changes,
            {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "after_generation": current_head.generation,
                "after_manifest_digest": current_head.digest,
                "limit": CHANGE_PAGE_SIZE,
            },
        )
        if not isinstance(response, dict) or response.get("schema") != CHANGES_SCHEMA:
            raise NetworkError("Meshia returned an invalid Fabric changes response.")
        if response.get("requires_full_manifest") is True:
            # A gap response consumed this tick's signed control-call budget.
            # Fetch the full snapshot on the next scheduled tick.
            self._force_full_remote = True
            self._next_remote_poll = 0.0
            return False
        if response.get("unchanged") is True:
            if response.get("changes") != [] or response.get("next_generation") != current_head.generation or response.get("next_manifest_digest") != current_head.digest:
                raise NetworkError("Meshia returned an inconsistent unchanged Fabric cursor.")
            return False

        changes = response.get("changes")
        if not isinstance(changes, list) or not changes:
            raise NetworkError("Meshia returned an invalid Fabric change chain.")
        updates: dict[str, RemoteEntry | None] = {}
        generation = current_head.generation
        digest = current_head.digest
        changed_paths: set[str] = set()
        for raw_change in changes:
            if not isinstance(raw_change, Mapping):
                raise NetworkError("Meshia returned an invalid Fabric change.")
            next_generation = raw_change.get("manifest_generation")
            next_digest = raw_change.get("manifest_digest")
            if next_generation != generation + 1 or raw_change.get("previous_manifest_digest") != digest or not _digest(next_digest):
                raise NetworkError("The Fabric change chain is not contiguous.")
            raw_entries = raw_change.get("entries")
            if not isinstance(raw_entries, list):
                raise NetworkError("Meshia returned invalid Fabric change entries.")
            for raw_entry in raw_entries:
                path, entry = _delta_entry(raw_entry)
                changed_paths.add(path)
                updates[path] = entry
            generation = int(next_generation)
            digest = str(next_digest)
        namespace_paths = tuple(sorted(changed_paths))
        if response.get("next_generation") != generation or response.get("next_manifest_digest") != digest:
            raise NetworkError("Meshia returned an inconsistent Fabric next cursor.")
        if not updates:
            # A generation can advance for directory-only/catalog metadata that
            # does not alter the file index. Preserve that authoritative cursor
            # with a head-only CAS instead of manufacturing a touched path.
            self.database.advance_remote_manifest_head(
                expected_generation=current_head.generation,
                expected_digest=current_head.digest,
                generation=generation,
                digest=digest,
            )
            if response.get("truncated") is True:
                self._next_remote_poll = 0.0
            self._remote_changed_paths = namespace_paths
            return True
        previous = self.database.get_remote_entries(updates)
        before = RemoteManifest(
            current_head.generation,
            current_head.digest,
            previous,
            current_head.refreshed_at_ns,
        )
        after = RemoteManifest(
            generation,
            digest,
            tuple(
                sorted(
                    (entry for entry in updates.values() if entry is not None),
                    key=lambda item: item.path,
                )
            ),
            time.time_ns(),
        )
        renames = self._infer_remote_renames(before, after)
        for source, destination, _digest_value, _size in renames:
            changed_paths.discard(source)
            changed_paths.discard(destination)
        working_paths = self.database.filter_materialized_paths(changed_paths)
        committed_previous = self.database.apply_remote_delta(
            expected_generation=current_head.generation,
            expected_digest=current_head.digest,
            generation=generation,
            digest=digest,
            entries=updates,
            apply_paths=working_paths,
            rename_intents=renames,
        )
        if committed_previous != previous:
            raise StateError("The remote delta preimage changed before commit.")
        self._queue_remote_renames(renames)
        previous_paths = {entry.path for entry in previous}
        self._seed_remote_entries(
            entry
            for path, entry in updates.items()
            if entry is not None and entry.kind == "file" and path not in previous_paths
        )
        self._queue_remote_applies(working_paths)
        if response.get("truncated") is True:
            self._next_remote_poll = 0.0
        self._remote_changed_paths = namespace_paths
        return True

    # ------------------------------------------------------- Fabric v2 refresh

    def _remote_head_is_v2(self) -> bool:
        """Whether the published remote head is a journal sequence.

        A v1 head carries a manifest digest; a v2 head carries none. The
        distinction matters wherever "the remote has no entry for this path"
        has to be interpreted, because only under v2 can that mean "this
        workspace was reset" rather than "this path was deleted".
        """

        head = self.database.get_remote_manifest_head()
        return head is not None and head.digest is None

    def _fabric_v2_refresh_active(self) -> bool:
        """Whether this node should learn remote state from the journal.

        Gated on the same explicit signals as the write lane: the feature must
        be enabled, and the transport must actually expose the v2 methods. A
        node whose transport predates them keeps the v1 lane untouched.
        """

        return bool(
            self._fabric_v2_enabled
            and getattr(self.transport, "changes_v2", None) is not None
            and getattr(self.transport, "snapshot_v2", None) is not None
        )

    def _block_read_payload(
        self,
        *,
        path: str,
        blocks: Sequence[StagedBlock],
        manifest_generation: int | None,
        manifest_digest: str | None,
    ) -> dict[str, Any]:
        """Wire for one signed block-read ticket request.

        v1 proves membership with a manifest generation and digest. A v2 head
        has neither -- integrity moved to checkpoints -- so the v2 request
        names only the path, and the server proves membership against
        fabric_entries_1762 (M1769). The operation NAME is the capability
        signal: an older control plane rejects `read_batch_v2` as an unknown
        operation, which is explicit, rather than us probing it with a request
        it would answer with a generic 400.
        """

        wire = [
            {"sha256": block.sha256, "size_bytes": block.size_bytes}
            for block in blocks
        ]
        if self._fabric_v2_refresh_active():
            return {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "operation": "read_batch_v2",
                "path": path,
                "blocks": wire,
            }
        return {
            "attachment_id": self.authority.attachment_id,
            "workspace": WORKSPACE_MOUNT,
            "operation": "read_batch",
            "path": path,
            "manifest_generation": manifest_generation,
            "manifest_digest": manifest_digest,
            "blocks": wire,
        }

    def _refresh_remote_v2(self, *, force_full: bool) -> bool:
        """Pull journal records after our watermark and apply them per path.

        v1 asked "what does the whole namespace look like now?" and diffed the
        answer against local state -- O(workspace) per poll, and the reason a
        rename had to be *inferred* from a digest that happened to move. v2
        asks "what happened after sequence N?" and gets back the ops
        themselves, so the work is O(changed) and a rename arrives as a rename.
        """

        head = self.database.get_remote_manifest_head()
        load = self.database.get_remote_manifest_load()
        # A v1 head carries a manifest digest and counts generations; a v2 head
        # carries none and counts journal sequences. The two number spaces are
        # unrelated, so a v1 generation must never be handed to `changes_since`
        # as a watermark -- it would silently skip or replay arbitrary history.
        # Crossing over is a bootstrap, not a resume.
        if load is not None or force_full or head is None or head.digest is not None:
            return self._load_snapshot_page_v2(load)

        since_seq = int(head.generation)
        response = self._signed_control_request(
            self.transport.changes_v2,
            {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "since_seq": since_seq,
                "limit": V2_CHANGE_PAGE_SIZE,
            },
        )
        changes = response.get("changes") if isinstance(response, Mapping) else None
        last_seq = response.get("last_seq") if isinstance(response, Mapping) else None
        next_since = response.get("next_since_seq") if isinstance(response, Mapping) else None
        if (
            not isinstance(response, Mapping)
            or response.get("schema") != V2_CHANGES_SCHEMA
            or response.get("workspace") != WORKSPACE_MOUNT
            or response.get("since_seq") != since_seq
            or isinstance(last_seq, bool)
            or not isinstance(last_seq, int)
            or last_seq < 0
            or isinstance(next_since, bool)
            or not isinstance(next_since, int)
            or not isinstance(changes, list)
            or len(changes) > V2_CHANGE_PAGE_SIZE
            or not isinstance(response.get("has_more"), bool)
            or not isinstance(response.get("requires_rebuild"), bool)
        ):
            raise NetworkError("Meshia returned an invalid Fabric v2 changes response.")

        if response.get("requires_rebuild") is True:
            # The records we are missing were pruned below a checkpoint, so no
            # amount of paging can recover them. Rebuild from the snapshot
            # instead of applying the suffix we *can* see, which would leave a
            # workspace that looks complete and is not.
            self._force_full_remote = True
            self._next_remote_poll = 0.0
            return False

        if not changes:
            if next_since != since_seq:
                raise NetworkError("Meshia advanced the Fabric v2 cursor past no records.")
            return False

        updates, renames, changed_paths, applied_seq = self._v2_plan_change_page(
            changes, since_seq
        )
        if applied_seq != next_since:
            raise NetworkError("Meshia returned an inconsistent Fabric v2 cursor.")

        # A mkdir receipt does not change an already-visible local directory.
        # Invalidating that SMB directory while Finder is copying its first
        # child can break the in-flight copy with EIO. Keep the durable cursor
        # update, but notify only actual visible namespace changes.
        namespace_paths = tuple(sorted(
            path for path in changed_paths
            if not (
                (entry := updates.get(path)) is not None
                and entry.kind == "directory"
                and self.workspace.directory_exists(path)
            )
        ))
        if not updates:
            self.database.advance_remote_manifest_head(
                expected_generation=since_seq,
                expected_digest=None,
                generation=applied_seq,
                digest=None,
            )
            if response.get("has_more") is True:
                self._next_remote_poll = 0.0
            self._remote_changed_paths = namespace_paths
            return True

        previous = self.database.get_remote_entries(updates)
        before = RemoteManifest(since_seq, None, previous, head.refreshed_at_ns)
        after = RemoteManifest(
            applied_seq,
            None,
            tuple(
                sorted(
                    (entry for entry in updates.values() if entry is not None),
                    key=lambda item: item.path,
                )
            ),
            time.time_ns(),
        )
        # The moved paths come from the explicit rename op, which is the whole
        # point of having one; inference then decides which of them may be
        # carried out as a local *move*. It enforces the preconditions the
        # rename applier depends on (the source is materialized, clean, and at
        # the digest we think it is), and declines ambiguous digests, which
        # then fall back to delete-and-refetch. Correct either way, and never
        # a move onto a file whose local content we cannot vouch for.
        inferred = self._infer_remote_renames(before, after)
        for source, destination, _digest_value, _size in inferred:
            changed_paths.discard(source)
            changed_paths.discard(destination)
        working_paths = self.database.filter_materialized_paths(changed_paths)
        working_paths = tuple(sorted(set(working_paths) | {
            path for path, entry in updates.items()
            if entry is None and self.database.is_remote_directory(path)
        }))
        committed_previous = self.database.apply_remote_delta_v2(
            expected_seq=since_seq,
            seq=applied_seq,
            entries=updates,
            apply_paths=working_paths,
            rename_intents=inferred,
        )
        if committed_previous != previous:
            raise StateError("The remote delta preimage changed before commit.")
        self._queue_remote_renames(inferred)
        previous_paths = {entry.path for entry in previous}
        self._seed_remote_entries(
            entry
            for path, entry in updates.items()
            if entry is not None and path not in previous_paths
        )
        self._queue_remote_applies(working_paths)
        if response.get("has_more") is True:
            self._next_remote_poll = 0.0
        self._remote_changed_paths = namespace_paths
        return True

    def _v2_plan_change_page(
        self, changes: list[Any], since_seq: int
    ) -> tuple[dict[str, RemoteEntry | None], list[tuple[str, str, str, int]], set[str], int]:
        """Fold an ordered run of journal records into one per-path delta.

        Records are applied in sequence order into a single mapping, so a path
        touched several times in one page collapses to its final state -- which
        is what makes replaying an overlapping page after a snapshot or a lost
        response idempotent rather than merely tolerable.
        """

        updates: dict[str, RemoteEntry | None] = {}
        changed_paths: set[str] = set()
        renames: list[tuple[str, str, str, int]] = []
        cursor = since_seq
        for raw in changes:
            if not isinstance(raw, Mapping):
                raise NetworkError("Meshia returned an invalid Fabric v2 change.")
            seq = raw.get("seq")
            if isinstance(seq, bool) or not isinstance(seq, int) or seq <= cursor:
                raise NetworkError("The Fabric v2 change sequence is not increasing.")
            cursor = seq
            op = raw.get("op")
            path = self._v2_change_path(raw.get("path"))
            if op == "put":
                entry = _v2_remote_entry(raw, path)
                updates[path] = entry
                changed_paths.add(path)
            elif op == "delete":
                updates[path] = None
                changed_paths.add(path)
                if raw.get("kind") == "dir":
                    offset = 0
                    while True:
                        page = self.database.list_remote_entries(
                            prefix=path, limit=V2_SUBTREE_PAGE_SIZE, offset=offset
                        )
                        for entry in page:
                            updates[entry.path] = None
                            changed_paths.add(entry.path)
                        if len(page) < V2_SUBTREE_PAGE_SIZE:
                            break
                        offset += len(page)
                        if offset > MAX_REMOTE_FILES:
                            raise StateError("A Fabric v2 delete subtree exceeded the namespace bound.")
                    for directory in self.database.list_remote_directories(prefix=path):
                        updates[directory] = None
                        changed_paths.add(directory)
                    for candidate in tuple(updates):
                        if candidate.startswith(path + "/"):
                            updates[candidate] = None
                            changed_paths.add(candidate)
            elif op == "rename":
                destination = self._v2_change_path(raw.get("destination_path"))
                if destination == path:
                    raise NetworkError("A Fabric v2 rename must move the path.")
                self._v2_plan_rename(raw, path, destination, updates, changed_paths, renames)
            else:
                raise NetworkError("Meshia returned an unknown Fabric v2 change op.")
        return updates, renames, changed_paths, cursor

    def _v2_plan_rename(
        self,
        raw: Mapping[str, Any],
        source: str,
        destination: str,
        updates: dict[str, RemoteEntry | None],
        changed_paths: set[str],
        renames: list[tuple[str, str, str, int]],
    ) -> None:
        """Expand one rename record into the per-path moves it stands for.

        The authority moves a directory with a single journal record and a
        subtree UPDATE, so the record is O(1) while the namespace change is
        O(subtree). The node holds the remote namespace locally, so it can
        expand the record itself rather than making the server enumerate what
        it moved -- and expanding locally is also what keeps the wire O(changed)
        for the writer that caused it.

        The subtree is read from local remote state overlaid with the changes
        already folded from THIS page, so a file created and then swept up by a
        directory rename in the same page moves with it.
        """

        moved: dict[str, RemoteEntry] = {}
        prefix = source + "/"
        for directory in self.database.list_remote_directories(prefix=source):
            moved[directory] = RemoteEntry(directory, 0, None, kind="directory")
        offset = 0
        while True:
            page = self.database.list_remote_entries(
                prefix=source, limit=V2_SUBTREE_PAGE_SIZE, offset=offset
            )
            for entry in page:
                if entry.path == source or entry.path.startswith(prefix):
                    moved[entry.path] = entry
            if len(page) < V2_SUBTREE_PAGE_SIZE:
                break
            offset += len(page)
            if offset > MAX_REMOTE_FILES:
                raise StateError("A Fabric v2 rename subtree exceeded the namespace bound.")
        for path, entry in updates.items():
            if path != source and not path.startswith(prefix):
                continue
            if entry is None:
                moved.pop(path, None)
            else:
                moved[path] = entry

        for path in sorted(moved):
            entry = moved[path]
            target = destination + path[len(source):]
            updates[path] = None
            updates[target] = RemoteEntry(
                target, entry.size_bytes, entry.digest, entry.modified, entry.blocks,
                kind=entry.kind,
            )
            changed_paths.add(path)
            changed_paths.add(target)

        if not moved:
            # A rename of something we have no remote record of. The namespace
            # change is still real, so surface the endpoints for invalidation
            # rather than dropping the record silently.
            changed_paths.add(source)
            changed_paths.add(destination)

    def _v2_change_path(self, value: Any) -> str:
        """Validate a path off the wire before it can reach the namespace.

        Same boundary the v1 delta lane applies: a traversal or absolute path
        from the authority is rejected here rather than being canonicalized
        into something plausible further down.
        """

        if not isinstance(value, str) or not value:
            raise NetworkError("Meshia returned an invalid Fabric v2 change path.")
        try:
            from .workspace import split_relative

            split_relative(value)
        except UnsafePath as error:
            raise NetworkError("Meshia returned an unsafe Fabric v2 change path.") from error
        return value

    def _load_snapshot_page_v2(self, load: Any | None) -> bool:
        """Ingest exactly one page of the tree, publishing only at EOF.

        Paging is deliberately NOT a point-in-time view: the authority serves
        each page from live state, so writes land while the walk is in
        progress. This is safe because of which watermark is kept -- the one
        reported by the FIRST page. A write that lands behind the cursor is
        missed by the walk and recovered by replaying from that watermark; a
        write that lands ahead of it is picked up by the walk and then replayed
        harmlessly. Keeping a later page's watermark would skip exactly the
        first case, which is why the first page's value is pinned into the load
        and every later page's value is ignored rather than re-checked.
        """

        after_path = load.last_path if load is not None else None
        request = {
            "attachment_id": self.authority.attachment_id,
            "workspace": WORKSPACE_MOUNT,
            "after": after_path,
            "limit": V2_SNAPSHOT_PAGE_SIZE,
        }
        page = self._signed_control_request(self.transport.snapshot_v2, request)
        entries_raw = page.get("entries") if isinstance(page, Mapping) else None
        last_seq = page.get("last_seq") if isinstance(page, Mapping) else None
        next_after = page.get("next_after") if isinstance(page, Mapping) else None
        if (
            not isinstance(page, Mapping)
            or page.get("schema") != V2_SNAPSHOT_SCHEMA
            or page.get("workspace") != WORKSPACE_MOUNT
            or isinstance(last_seq, bool)
            or not isinstance(last_seq, int)
            or last_seq < 0
            or not isinstance(entries_raw, list)
            or len(entries_raw) > V2_SNAPSHOT_PAGE_SIZE
            or not (next_after is None or isinstance(next_after, str))
        ):
            raise NetworkError("Meshia returned an invalid Fabric v2 snapshot page.")

        parsed = tuple(
            (
                self._v2_change_path(raw.get("path") if isinstance(raw, Mapping) else None),
                raw,
            )
            for raw in entries_raw
        )
        # Ordering and pagination are judged on every row the server sent
        # (directories included); explicit empty directories remain namespace rows.
        paths = tuple(path for path, _raw in parsed)
        entries = tuple(
            entry
            for entry in (_v2_snapshot_entry(raw, path) for path, raw in parsed)
            if entry is not None
        )
        if any(left >= right for left, right in zip(paths, paths[1:])) or (
            after_path is not None and paths and paths[0] <= after_path
        ):
            raise NetworkError("Meshia returned a non-increasing Fabric v2 snapshot page.")
        expected_after = paths[-1] if paths and len(paths) == V2_SNAPSHOT_PAGE_SIZE else None
        if next_after != expected_after:
            raise NetworkError("Meshia returned inconsistent Fabric v2 snapshot pagination.")

        if load is None:
            load = self.database.begin_remote_manifest_load(
                last_seq,
                None,
                MAX_REMOTE_FILES,
                manifest_id=str(uuid.uuid4()),
            )
        if entries:
            load = self.database.ingest_remote_manifest_page(load.load_id, entries)
        if next_after is not None:
            self._force_full_remote = True
            self._next_remote_poll = (
                float(self._clock()) + MANIFEST_PAGE_MIN_INTERVAL_SECONDS
            )
            return False

        sealed = self.database.seal_remote_manifest_load(load.load_id)
        previous_head = self.database.get_remote_manifest_head()
        commit = self.database.commit_remote_manifest_load(
            sealed.load_id,
            max_materialized_entries=self.max_auto_materializations,
            max_materialized_bytes=self.max_auto_materialized_bytes,
            # A same-authority, non-regressing v2 snapshot proves absence even
            # after journal compaction. A reset sequence or first adoption has
            # no such continuity proof and retains the local recovery policy.
            retire_absent_local=(
                not self._durable_adoption_pending
                and previous_head is not None
                and previous_head.digest is None
                and previous_head.generation > 0
                and sealed.generation >= previous_head.generation
            ),
        )
        # Reconcile against the completed snapshot. Durable apply intents own
        # unchanged cache retirement; reset/adoption survivors and real local
        # edits retain their existing recovery and publication paths.
        self._startup_reconcile = True
        (
            self._remote_apply_intents_may_remain,
            self._remote_rename_intents_may_remain,
        ) = self.database.has_pending_remote_intents()
        self._restore_remote_intents(refresh_priority=True)
        # A rebuild replaces the whole namespace, so no bounded set of paths
        # describes it. Leave `_remote_changed_paths` empty exactly as the v1
        # snapshot lane does; the mount treats a full load as a whole-workspace
        # invalidation rather than a path list.
        return bool(commit.changed)

    def _load_full_manifest_page(self, load: Any | None) -> bool:
        """Ingest exactly one frozen keyset page and publish only at EOF."""

        offset = int(load.ingested_entries) if load is not None else 0
        after_path = load.last_path if load is not None else None
        request = {
            "attachment_id": self.authority.attachment_id,
            "workspace": WORKSPACE_MOUNT,
            "offset": offset,
            "limit": MANIFEST_PAGE_SIZE,
        }
        if after_path is not None:
            request["after_path"] = after_path
            request["manifest_id"] = load.manifest_id
            request["manifest_digest"] = load.digest
            request["manifest_generation"] = load.generation
        try:
            page = self._signed_control_request(self.transport.manifest, request)
        except RemoteError as error:
            if (
                load is not None
                and error.remote_code == "FABRIC_MANIFEST_CURSOR_INVALID"
            ):
                # A continuation cursor is snapshot-bound. If the authority can
                # no longer serve it, discard only the isolated partial load;
                # the published head remains intact until a fresh page-0 load
                # reaches its terminal atomic commit.
                self.database.abort_remote_manifest_load(load.load_id)
                self._force_full_remote = True
                self._next_remote_poll = 0.0
                return False
            raise
        files = page.get("files") if isinstance(page, Mapping) else None
        total = page.get("total_files") if isinstance(page, Mapping) else None
        generation = (
            page.get("manifest_generation") if isinstance(page, Mapping) else None
        )
        digest = page.get("manifest_digest") if isinstance(page, Mapping) else None
        manifest_id = page.get("manifest_id") if isinstance(page, Mapping) else None
        if (
            not isinstance(page, Mapping)
            or page.get("schema") != MANIFEST_SCHEMA
            or page.get("workspace") != WORKSPACE_MOUNT
            or page.get("offset") != offset
            or page.get("limit") != MANIFEST_PAGE_SIZE
            or isinstance(total, bool)
            or not isinstance(total, int)
            or not 0 <= total <= MAX_REMOTE_FILES
            or isinstance(generation, bool)
            or not isinstance(generation, int)
            or generation < 1
            or not _digest(digest)
            or not isinstance(manifest_id, str)
            or UUID_RE.fullmatch(manifest_id) is None
            or str(uuid.UUID(manifest_id)) != manifest_id
            or not isinstance(files, list)
            or len(files) > MANIFEST_PAGE_SIZE
        ):
            raise NetworkError("Meshia returned an invalid Fabric manifest page.")

        if load is not None and (
            load.manifest_id != manifest_id
            or load.generation != generation
            or load.digest != digest
            or load.expected_entries != total
        ):
            # Identity is the authority for every cursor and descriptor below.
            # Reject drift before parsing path order or trusting pagination
            # fields: an insertion/deletion before ``after_path`` can make all
            # of those fields internally plausible for a different snapshot.
            self.database.abort_remote_manifest_load(load.load_id)
            self._force_full_remote = True
            self._next_remote_poll = 0.0
            return False

        entries = tuple(_remote_entry(raw) for raw in files)
        paths = tuple(entry.path for entry in entries)
        if any(left >= right for left, right in zip(paths, paths[1:])) or (
            after_path is not None and paths and paths[0] <= after_path
        ):
            raise NetworkError(
                "Meshia returned a non-increasing Fabric manifest keyset page."
            )
        next_offset = offset + len(entries)
        truncated = next_offset < total
        expected_after = paths[-1] if truncated and paths else None
        if (
            page.get("next_offset") != next_offset
            or page.get("truncated") is not truncated
            or page.get("next_after_path") != expected_after
            or next_offset > total
            or (truncated and not entries)
        ):
            raise NetworkError("Meshia returned inconsistent Fabric manifest pagination.")

        if load is None:
            load = self.database.begin_remote_manifest_load(
                int(generation),
                str(digest),
                int(total),
                manifest_id=str(manifest_id),
            )
        if entries:
            load = self.database.ingest_remote_manifest_page(load.load_id, entries)
        if next_offset != total:
            self._force_full_remote = True
            self._next_remote_poll = (
                float(self._clock()) + MANIFEST_PAGE_MIN_INTERVAL_SECONDS
            )
            return False

        commit = self.database.commit_remote_manifest_load(
            load.load_id,
            max_materialized_entries=self.max_auto_materializations,
            max_materialized_bytes=self.max_auto_materialized_bytes,
        )
        # Commit materializes no namespace tuples in Python. Durable intent
        # rows refill the bounded in-memory queues on this or a later tick.
        (
            self._remote_apply_intents_may_remain,
            self._remote_rename_intents_may_remain,
        ) = self.database.has_pending_remote_intents()
        self._restore_remote_intents(refresh_priority=True)
        return bool(commit.changed)

    # ---------------------------------------------------------- local staging

    def _advance_staging_repair(self, *, limit: int = 1_000) -> bool:
        """Reconcile physical stages into the shared ledger in bounded pages."""

        ledger = self._staging_ledger
        repair_id = self._staging_repair_id
        if ledger is None:
            return True
        if self._staging_repair_phase == "ready":
            return True
        if repair_id is None:
            raise StateError("The Fabric staging repair lost its durable token.")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1_000:
            raise ValueError("staging repair limit must be between 1 and 1000")

        phase_roots = {
            "classic": self.staging_root,
            "transfer_jobs": self._transfer_store.jobs_root,
            "transfer_quarantine": self._transfer_store.quarantine_root,
        }
        while self._staging_repair_phase in phase_roots:
            if self._staging_repair_scan is None:
                self._staging_repair_scan = iter(
                    os.scandir(phase_roots[self._staging_repair_phase])
                )
            reservations: list[StagingReservation] = []
            exhausted = False
            for _ in range(limit):
                try:
                    entry = next(self._staging_repair_scan)
                except StopIteration:
                    exhausted = True
                    break
                reservation = self._physical_staging_reservation(
                    self._staging_repair_phase, entry
                )
                if reservation is not None:
                    reservations.append(reservation)
            if reservations:
                ledger.observe_repair(repair_id, reservations)
            if not exhausted:
                return False
            close = getattr(self._staging_repair_scan, "close", None)
            if callable(close):
                close()
            self._staging_repair_scan = None
            self._staging_repair_phase = {
                "classic": "transfer_jobs",
                "transfer_jobs": "transfer_quarantine",
                "transfer_quarantine": "sweep",
            }[self._staging_repair_phase]

        if self._staging_repair_phase == "sweep":
            if ledger.status().repair_phase == "scan":
                ledger.begin_repair_sweep(repair_id)
            step = ledger.sweep_repair(repair_id, limit=limit)
            if not step.complete:
                return False
            self._staging_repair_phase = "ready"
            self._staging_repair_id = None
        return True

    def _physical_staging_reservation(
        self, phase: str, entry: os.DirEntry
    ) -> StagingReservation | None:
        """Classify one private-root entry without following links."""

        if phase != "classic":
            try:
                return self._transfer_store.physical_reservation(Path(entry.path))
            except (OSError, ValueError, TransferError):
                return self._ambiguous_staging_reservation(phase, entry.name)

        match = _OWNED_STAGE_FILE_RE.fullmatch(entry.name)
        if match is not None and entry.name == f"{match.group('id')}.data":
            try:
                info = directory_entry_identity_stat(entry)
            except OSError:
                return self._ambiguous_staging_reservation(phase, entry.name)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                return self._ambiguous_staging_reservation(phase, entry.name)
            return StagingReservation(
                owner_id=f"classic:{match.group('id').lower()}",
                kind="classic",
                size_bytes=int(info.st_size),
                created_at_ns=int(info.st_mtime_ns),
                committed_bytes=self._allocated_staging_bytes(info),
            )

        admission_names: set[str] = set()
        ledger = self._staging_ledger
        if ledger is not None:
            admission_names = {
                ledger.path.name,
                ledger.path.name + "-wal",
                ledger.path.name + "-shm",
            }
        if (
            entry.name in admission_names
            or entry.name == self._transfer_store.root.name
            or _OWNED_STAGE_FILE_RE.fullmatch(entry.name) is not None
        ):
            # Plan/progress sidecars share their base stage's reservation.
            return None
        return self._ambiguous_staging_reservation(phase, entry.name)

    def _ambiguous_staging_reservation(
        self, phase: str, name: str
    ) -> StagingReservation:
        token = hashlib.sha256(f"{phase}\0{name}".encode("utf-8")).hexdigest()
        return StagingReservation(
            owner_id=f"ambiguous:{token}",
            kind="ambiguous",
            size_bytes=self.max_staging_bytes,
            created_at_ns=self._wall_now_ns(),
        )

    def _classic_stage_owner(self, stage: Path) -> str:
        match = _OWNED_STAGE_FILE_RE.fullmatch(stage.name)
        if match is None or stage.name != f"{match.group('id')}.data":
            raise StateError("The Fabric stage has no shared-ledger identity.")
        return f"classic:{match.group('id').lower()}"

    def _reserve_classic_stage(self, stage: Path, size_bytes: int) -> None:
        ledger = self._staging_ledger
        if ledger is None:
            self._assert_staging_capacity(size_bytes)
            return
        try:
            ledger.reserve(
                self._classic_stage_owner(stage),
                kind="classic",
                size_bytes=size_bytes,
                max_kind_entries=MAX_REMOTE_FILES,
            )
        except (StagingAdmissionExceeded, StagingRepairRequired) as error:
            raise StagingQuotaExceeded(str(error)) from None
        except StagingLedgerError as error:
            raise StateError("Fabric staging admission could not be proven.") from error

    def _release_classic_stage(self, stage: Path) -> None:
        ledger = self._staging_ledger
        if ledger is None:
            return
        owner = self._classic_stage_owner(stage)
        try:
            reservation = ledger.get(owner)
            if reservation is not None:
                ledger.release(owner, expected_size_bytes=reservation.size_bytes)
        except StagingLedgerError as error:
            raise StateError("Fabric staging release could not be proven.") from error

    @staticmethod
    def _allocated_staging_bytes(info: os.stat_result) -> int:
        blocks = getattr(info, "st_blocks", None)
        if isinstance(blocks, int) and blocks >= 0:
            return min(int(info.st_size), blocks * 512)
        # Windows cannot prove physical allocation from portable stat fields.
        # Preserve the conservative outstanding reservation there.
        return 0

    def _record_classic_stage_committed(
        self, stage: Path, info: os.stat_result | None = None
    ) -> None:
        ledger = self._staging_ledger
        if ledger is None:
            return
        try:
            observed = stage.stat(follow_symlinks=False) if info is None else info
            if not stat.S_ISREG(observed.st_mode) or observed.st_nlink != 1:
                raise StateError("The Fabric stage allocation is not authoritative.")
            ledger.record_committed(
                self._classic_stage_owner(stage),
                allocated_bytes=self._allocated_staging_bytes(observed),
            )
        except StagingLedgerError as error:
            raise StateError(
                "Fabric staging allocation could not be recorded."
            ) from error

    def _drain_local_events(self) -> int:
        events = self.watch.drain(max_events=self.max_events_per_tick)
        staged = 0
        for index, event in enumerate(events):
            if self._absorb_conflicted_event(event):
                staged += 1
                continue
            if self._defer_directory_event(event):
                staged += 1
                continue
            try:
                self._stage_event(event)
                staged += 1
            except (InvalidTask, OSError, StagingQuotaExceeded, UnsafePath):
                # Atomic saves may modify again between notification and the
                # stable snapshot. Requeue instead of losing the final state.
                self._requeue_local_event(event)
            except TransferBusy:
                # One serial local byte worker is intentional. Preserve this
                # event and the untouched tail for the next bounded handoff.
                for pending in events[index:]:
                    self._requeue_local_event(pending)
                break
            except (FabricCacheError, StateError, ValueError):
                # drain() transfers ownership of the whole batch. Preserve the
                # failing event and every unprocessed successor before the poll
                # propagates its bounded retry; otherwise those hints vanish.
                for pending in events[index:]:
                    self._requeue_local_event(pending)
                raise
        return staged

    def _absorb_conflicted_event(self, event: FabricWatchEvent) -> bool:
        paths = (
            (event.path,)
            if event.kind != "rename"
            else (event.source_path, event.path)
        )
        conflicted = tuple(
            path
            for path in paths
            if path is not None
            and (materialized := self.database.get_materialized(path)) is not None
            and materialized.state == "conflict"
        )
        if not conflicted:
            return False
        current = {
            path: self.workspace.stat_fingerprint(path) for path in conflicted
        }
        self.watch.acknowledge_local_state(
            current,
            absorb_late_events_seconds=DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
        )
        if event.kind == "rename":
            # Exact reconciliation handles the non-conflicted endpoint; the
            # conflict endpoint remains owned by explicit resolution.
            self.watch.mark_overflow()
        return True

    def _defer_directory_path(self, path: str, kind: str) -> bool:
        operation = self.database.get_active_directory_rename()
        if operation is None or operation.destination_path is None:
            return False
        if not any(
            path == prefix or path.startswith(prefix + "/")
            for prefix in (operation.path, operation.destination_path)
        ):
            return False
        self._record_deferred_directory_path(path, kind)
        return True

    def _record_deferred_directory_path(self, path: str, kind: str) -> None:
        if (
            path not in self._deferred_directory_events
            and len(self._deferred_directory_events)
            >= MAX_DEFERRED_DIRECTORY_EVENT_PATHS
        ):
            self._deferred_directory_events_overflow = True
            return
        self._deferred_directory_events[path] = kind

    def _defer_directory_event(self, event: FabricWatchEvent) -> bool:
        operation = self.database.get_active_directory_rename()
        if operation is None or operation.destination_path is None:
            return False
        affected = (
            ((event.path, event.kind),)
            if event.kind != "rename"
            else (
                (event.source_path, "delete"),
                (event.path, "put"),
            )
        )
        if not any(
            path is not None
            and any(
                path == prefix or path.startswith(prefix + "/")
                for prefix in (operation.path, operation.destination_path)
            )
            for path, _kind in affected
        ):
            return False
        for path, kind in affected:
            assert path is not None
            self._record_deferred_directory_path(path, kind)
        return True

    def _flush_deferred_directory_events(self) -> None:
        if self.database.get_active_directory_rename() is not None:
            return
        if self._deferred_directory_events_overflow:
            self.watch.mark_overflow()
        else:
            for path in sorted(self._deferred_directory_events):
                materialized = self.database.get_materialized(path)
                if materialized is not None and materialized.state == "conflict":
                    # Explicit conflict resolution, not a stale watcher hint,
                    # owns this path now. Never let deferred replay choose the
                    # local side implicitly after the overlay retires.
                    continue
                try:
                    local = self.workspace.stat_fingerprint(path)
                except (InvalidTask, OSError, UnsafePath):
                    self.watch.mark_overflow()
                    break
                remote = self.database.get_remote_entry(path)
                if local is not None:
                    self.watch.record_put(path)
                elif remote is not None:
                    self.watch.record_delete(path)
                # Both sides absent is the already-converged result of a source
                # deletion or rename apply, not another remote mutation.
        self._deferred_directory_events.clear()
        self._deferred_directory_events_overflow = False

    def _requeue_local_event(self, event: FabricWatchEvent) -> None:
        if event.kind == "put":
            self.watch.record_put(event.path)
        elif event.kind == "delete":
            self.watch.record_delete(event.path)
        else:
            assert event.source_path is not None
            self.watch.record_rename(event.source_path, event.path)

    def _stage_event(self, event: FabricWatchEvent) -> None:
        if event.kind == "put":
            if self._begin_large_local_transfer(event.path):
                return
            self._stage_local_put_bounded(event.path)
            return
        if event.kind == "delete":
            self._stage_delete(event.path)
            return
        assert event.source_path is not None
        destination_fingerprint = self.workspace.stat_fingerprint(event.path)
        if (
            destination_fingerprint is not None
            and destination_fingerprint.size_bytes > BACKGROUND_TRANSFER_THRESHOLD_BYTES
        ):
            source = self._remote_entry_for_write(event.source_path)
            if source is not None and source.blocks is not None:
                self._queue_large_rename_verification(
                    event.source_path,
                    event.path,
                    destination_fingerprint,
                    source,
                )
                return
            if self._begin_local_transfer(
                event.path,
                fingerprint=destination_fingerprint,
                delete_after_ack=(
                    (event.source_path, source.digest) if source is not None else None
                ),
            ):
                if source is not None:
                    self.watch.acknowledge_local_state(
                        {
                            event.source_path: None,
                            event.path: destination_fingerprint,
                        },
                        absorb_late_events_seconds=DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
                    )
                return
        destination = self.workspace.hash_regular_file(event.path)
        head = self.database.get_remote_manifest_head()
        source = self._remote_entry_for_write(event.source_path)
        target = self._remote_entry_for_write(event.path)
        if (
            destination is not None
            and source is not None
            and source.blocks is not None
            and self._local_matches_remote(destination, source,
                self.database.get_materialized(event.source_path), source_path=event.path)
        ):
            base_generation, base_digest = _head_fields(head)
            self.database.enqueue_rename(
                event.source_path,
                event.path,
                base_generation=base_generation,
                base_digest=base_digest,
                expected_source_digest=source.digest,
                expected_destination_digest=target.digest if target else None,
            )
            self.database.mark_materialized(
                event.source_path, state="dirty", clean_digest=source.digest, bytes_on_disk=0
            )
            self.database.mark_materialized(
                event.path,
                state="dirty",
                clean_digest=source.digest,
                clean_digest_algorithm=file_digest_algorithm(source.blocks),
                content_sha256=destination.sha256,
                stat_fingerprint=_fingerprint_text(destination.fingerprint),
                bytes_on_disk=destination.fingerprint.size_bytes,
                pinned=True,
            )
            self.watch.acknowledge_local_state(
                {event.source_path: None, event.path: destination},
                absorb_late_events_seconds=DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
            )
            return
        # A move accompanied by a content change is represented without lying:
        # upload the destination snapshot, then tombstone the old path.
        if destination is not None:
            if source is not None:
                self._stage_local_put_bounded(
                    event.path,
                    delete_after_ack=(event.source_path, source.digest),
                )
                self.watch.acknowledge_local_state(
                    {event.source_path: None, event.path: destination},
                    absorb_late_events_seconds=DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
                )
            else:
                self._stage_local_put_bounded(event.path)
        elif source is not None:
            self._stage_delete(event.source_path)

    def _queue_large_rename_verification(
        self,
        source_path: str,
        destination_path: str,
        destination_fingerprint: FileFingerprint,
        source: RemoteEntry,
    ) -> None:
        """Durably fence a large metadata rename behind byte verification."""

        existing = self.database.get_latest_nonterminal_operation(source_path)
        if (
            existing is not None
            and existing.kind == "rename"
            and existing.destination_path == destination_path
            and existing.last_error is not None
            and existing.last_error.startswith(_RENAME_VERIFY_PREFIX)
        ):
            self.watch.acknowledge_local_state(
                {source_path: None, destination_path: destination_fingerprint},
                absorb_late_events_seconds=DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
            )
            return
        head = self.database.get_remote_manifest_head()
        target = self._remote_entry_for_write(destination_path)
        marker = _RENAME_VERIFY_PREFIX + _fingerprint_text(destination_fingerprint)
        base_generation, base_digest = _head_fields(head)
        self.database.enqueue_rename(
            source_path,
            destination_path,
            base_generation=base_generation,
            base_digest=base_digest,
            expected_source_digest=source.digest,
            expected_destination_digest=target.digest if target else None,
            initial_retry_error=marker,
        )
        self.database.mark_materialized(
            source_path,
            state="dirty",
            clean_digest=source.digest,
            bytes_on_disk=0,
        )
        self.database.mark_materialized(
            destination_path,
            state="dirty",
            clean_digest=source.digest,
            clean_digest_algorithm=file_digest_algorithm(source.blocks),
            stat_fingerprint=_fingerprint_text(destination_fingerprint),
            bytes_on_disk=destination_fingerprint.size_bytes,
            pinned=True,
        )
        # This acknowledgement is safe because the retry row above is the
        # durable owner. A crash restarts verification before mutate is legal.
        self.watch.acknowledge_local_state(
            {source_path: None, destination_path: destination_fingerprint},
            absorb_late_events_seconds=DEFAULT_REMOTE_APPLY_COMMITTED_SECONDS,
        )
        self.wake()

    def stage_local_put(self, path: str) -> PendingOperation:
        with self._coordinator_lock:
            return self._stage_local_put(path)

    def acknowledge_local_metadata_change(
        self,
        path: str,
        *,
        previous_fingerprint: FileFingerprint,
        current_fingerprint: FileFingerprint,
        allow_mtime_change: bool = False,
    ) -> bool:
        """Advance a mounted file's durable fingerprint without new byte work.

        This is an explicit mount-to-coordinator handoff, not a heuristic.
        The caller must have pinned the inode around a metadata-only syscall
        and excluded concurrent writers. This method independently requires
        the same device, inode and size and, unless the explicit syscall is the
        mtime change itself, the same mtime; it then verifies the exact
        post-state through the workspace boundary.
        A classic immutable stage keeps its digest and mutation UUID. A
        source-backed stage advances only its source fence, so subsequent
        range reads remain identity-pinned without restarting the upload.
        """

        same_identity = (
            _same_local_file_storage(previous_fingerprint, current_fingerprint)
            if allow_mtime_change
            else _same_byte_visible_fingerprint(
                previous_fingerprint, current_fingerprint
            )
        )
        if not same_identity:
            raise StateError("A local metadata update changed byte-visible identity.")
        previous_text = _fingerprint_text(previous_fingerprint)
        current_text = _fingerprint_text(current_fingerprint)
        with self._coordinator_lock:
            with self._namespace_lock(path):
                observed = self.workspace.stat_fingerprint(path)
                if observed != current_fingerprint:
                    raise StateError(
                        "The local file changed before metadata acknowledgement."
                    )
                operation = self.database.get_latest_nonterminal_operation(path)
                plan: StagePlan | None = None
                rebased_plan: StagePlan | None = None
                plan_path: Path | None = None
                if (
                    operation is not None
                    and operation.kind == "put"
                    and operation.staged_path is not None
                ):
                    plan_path = _plan_path(Path(operation.staged_path))
                    plan = _load_plan(Path(operation.staged_path), operation)
                    if plan.source_fingerprint not in (previous_text, current_text):
                        raise StateError(
                            "The staged local snapshot changed before metadata acknowledgement."
                        )
                    if plan.size_bytes != current_fingerprint.size_bytes:
                        raise StateError(
                            "The staged local snapshot changed size before metadata acknowledgement."
                        )
                    rebased_plan = replace(
                        plan, source_fingerprint=current_text
                    )
                    if plan.source_fingerprint != current_text:
                        # Advance the byte-source fence before the database
                        # baseline. An interrupted caller can safely replay the
                        # same explicit acknowledgement after restart.
                        _write_json(
                            plan_path,
                            _plan_document(rebased_plan),
                        )
                try:
                    database_owned = self.database.rebase_local_metadata_fingerprint(
                        path,
                        expected_fingerprint=previous_text,
                        current_fingerprint=current_text,
                    )
                except BaseException:
                    if operation is not None:
                        # If rollback also fails, the next PUT attempt in this
                        # process must run the same recovery used on restart.
                        self._metadata_split_repair_checked.discard(
                            operation.mutation_id
                        )
                    if (
                        plan is not None
                        and rebased_plan is not None
                        and plan_path is not None
                        and plan.source_fingerprint != current_text
                    ):
                        try:
                            materialized = self.database.get_materialized(path)
                            intent = self.database.get_local_transfer_intent(path)
                            owner_values = tuple(
                                value
                                for value in (
                                    materialized.stat_fingerprint
                                    if materialized is not None
                                    else None,
                                    intent.source_fingerprint
                                    if intent is not None
                                    else None,
                                )
                                if value is not None
                            )
                            # A failed/ambiguous COMMIT may still expose the
                            # current value. Keep the matching plan in that
                            # case; otherwise restore the pre-call pair.
                            if owner_values and current_text not in owner_values:
                                _write_json(plan_path, _plan_document(plan))
                        except BaseException as rollback_error:
                            # The current plan is itself a durable recovery
                            # signal. _send_put reconciles its byte-neutral
                            # fingerprint back into SQLite after restart or on
                            # this process's next attempt. Readback, rollback,
                            # and diagnostics are strictly best effort here:
                            # none may replace the original ambiguous CAS error.
                            try:
                                self.logger.record(
                                    "fabric_local_metadata_plan_rollback_deferred",
                                    path=path,
                                    mutation_id=operation.mutation_id,
                                    error=str(rollback_error),
                                )
                            except BaseException:
                                pass
                    raise
                if rebased_plan is None and not database_owned:
                    return False
                if (
                    rebased_plan is not None
                    and operation is not None
                    and operation.mutation_id in self._put_upload_states
                ):
                    self._put_upload_states[operation.mutation_id].plan = rebased_plan
                self.watch.acknowledge_local_state({path: current_fingerprint})
                self.logger.record(
                    "fabric_local_metadata_fingerprint_rebased",
                    path=path,
                    mutation_id=(operation.mutation_id if operation else None),
                )
                return True

    def _reconcile_split_plan_metadata_fingerprint(
        self, operation: PendingOperation, plan: StagePlan
    ) -> FileFingerprint | None:
        """Repair a crash between durable plan and SQLite metadata commits.

        The plan may lead SQLite only when an explicit mounted metadata handoff
        atomically wrote its post-state and crashed before the database CAS.
        Reconcile that split only when the visible inode is still the plan's
        exact fingerprint and every older durable owner differs solely in
        byte-invisible metadata. Any byte-visible or third-state change remains
        a hard source fence.
        """

        current_text = plan.source_fingerprint
        current = _fingerprint_from_text(current_text)
        observed = self.workspace.stat_fingerprint(operation.path)
        if observed != current:
            return observed
        materialized = self.database.get_materialized(operation.path)
        intent = self.database.get_local_transfer_intent(operation.path)
        owners = tuple(
            value
            for value in (
                materialized.stat_fingerprint if materialized is not None else None,
                intent.source_fingerprint if intent is not None else None,
            )
            if value is not None
        )
        previous_values = tuple(sorted(set(owners) - {current_text}))
        if not previous_values:
            return observed
        if len(previous_values) != 1:
            raise StateError(
                "Durable local metadata owners disagree with the stage plan."
            )
        previous_text = previous_values[0]
        previous = _fingerprint_from_text(previous_text)
        if not _same_byte_visible_fingerprint(previous, current):
            raise StateError(
                "The stage plan changed byte-visible identity ahead of SQLite."
            )
        if not self.database.rebase_local_metadata_fingerprint(
            operation.path,
            expected_fingerprint=previous_text,
            current_fingerprint=current_text,
        ):
            raise StateError("The split stage plan has no durable metadata owner.")
        self.logger.record(
            "fabric_local_metadata_split_reconciled",
            path=operation.path,
            mutation_id=operation.mutation_id,
        )
        return observed

    def stage_local_rename(self, source_path: str, destination_path: str) -> None:
        """Durably publish an already-committed local namespace rename."""

        with self._coordinator_lock:
            self._stage_event(
                FabricWatchEvent(
                    kind="rename",
                    path=destination_path,
                    source_path=source_path,
                )
            )
            self.wake()

    def _remote_entry_for_write(self, path: str) -> RemoteEntry | None:
        """Use exact acknowledged path effects while journal readback catches up.

        A receipt proves only its path, not a session-wide cursor. Readers of
        the raw journal preimage retain the original remote_entries view.
        """

        receipt = self.database.get_receipted_entry(path)
        return receipt.entry if receipt is not None else self.database.get_remote_entry(path)

    def stage_metadata_rename(
        self,
        source_path: str,
        destination_path: str,
        *,
        expected_source_digest: str,
        expected_destination_digest: str | None,
        retain_file_provider_receipt: bool = False,
    ) -> PendingOperation:
        """Rename a remote-only File Provider item without hydrating its bytes."""

        with self._coordinator_lock:
            source = self._remote_entry_for_write(source_path)
            destination = self._remote_entry_for_write(destination_path)
            if source is None or source.digest != expected_source_digest:
                raise InvalidTask("The File Provider rename source advanced.")
            observed_destination = destination.digest if destination is not None else None
            if observed_destination != expected_destination_digest:
                raise InvalidTask("The File Provider rename destination advanced.")
            if self.database.get_latest_nonterminal_operation(source_path) is not None:
                raise InvalidTask("The File Provider rename source is busy.")
            if self.database.get_latest_nonterminal_operation(destination_path) is not None:
                raise InvalidTask("The File Provider rename destination is busy.")
            head = self.database.get_remote_manifest_head()
            base_generation, base_digest = _head_fields(head)
            operation = self.database.enqueue_rename(
                source_path,
                destination_path,
                base_generation=base_generation,
                base_digest=base_digest,
                expected_source_digest=expected_source_digest,
                expected_destination_digest=expected_destination_digest,
            )
            self.database.mark_materialized(
                source_path,
                state="dirty",
                clean_digest=expected_source_digest,
                bytes_on_disk=0,
            )
            # ``absent`` here is a deliberate remote-only cache state, not a
            # local tombstone. The operation receipt preserves that distinction.
            self.database.mark_materialized(
                destination_path,
                state="absent",
                clean_digest=expected_source_digest,
                clean_digest_algorithm=file_digest_algorithm(source.blocks),
                bytes_on_disk=0,
            )
            self.watch.acknowledge_local_state(
                {source_path: None, destination_path: None}
            )
            if retain_file_provider_receipt:
                self.retain_file_provider_receipts(operation.mutation_id)
            self.wake()
            return operation

    def stage_metadata_directory_rename(
        self,
        source_path: str,
        destination_path: str,
        *,
        retain_file_provider_receipt: bool = False,
    ) -> PendingOperation:
        """Durably queue one metadata-only, atomic manifest-prefix rename."""

        with self._coordinator_lock:
            if destination_path.startswith(source_path + "/"):
                raise InvalidTask("A directory cannot be moved inside itself.")
            if _portable_paths_alias(source_path, destination_path):
                raise InvalidTask(
                    "A case-only directory rename is not supported on portable mounts."
                )
            source_work = self.database.list_nonterminal_operations_touching_prefix(
                source_path,
                limit=MAX_MUTATION_LIVE_FILES + 1,
            )
            destination_work = self.database.list_nonterminal_operations_touching_prefix(
                destination_path,
                limit=1,
            )
            if destination_work:
                raise InvalidTask(
                    "The Fabric directory rename destination has pending work."
                )
            if len(source_work) > MAX_MUTATION_LIVE_FILES:
                raise InvalidTask(
                    "FABRIC_MUTATION_NAMESPACE_TOO_LARGE: directory rename exceeds "
                    "the bounded 10,000-file dependency set"
                )
            if any(
                operation.kind != "put"
                or operation.destination_path is not None
                or not operation.path.startswith(source_path + "/")
                for operation in source_work
            ):
                raise InvalidTask(
                    "The Fabric directory rename source has incompatible pending work."
                )
            if (
                self.database.get_remote_entry(destination_path) is not None
                or self.database.list_remote_children(destination_path, limit=1)
            ):
                raise InvalidTask("The Fabric directory rename destination is not empty.")
            remote_sources = self.database.list_remote_entries(
                prefix=source_path,
                limit=MAX_MUTATION_LIVE_FILES + 1,
            )
            if not remote_sources and not source_work:
                raise InvalidTask("The Fabric directory rename source is missing.")
            if any(not _complete_object_cas_layout(source) for source in remote_sources):
                raise InvalidTask(
                    "FABRIC_MUTATION_LEGACY_RENAME_UNSUPPORTED: directory rename "
                    "requires complete directly indexed immutable blocks"
                )
            projected_sources = {source.path: source for source in remote_sources}
            latest_puts: dict[str, PendingOperation] = {}
            for operation in source_work:
                previous = latest_puts.get(operation.path)
                if previous is None or operation.journal_seq > previous.journal_seq:
                    latest_puts[operation.path] = operation
            for operation in latest_puts.values():
                projected_sources[operation.path] = _staged_remote_entry(operation)
            sources = tuple(projected_sources.values())
            if (
                len(sources) > MAX_MUTATION_LIVE_FILES
                or _directory_rename_delta_bytes(
                    sources,
                    source_path=source_path,
                    destination_path=destination_path,
                )
                > MAX_DIRECTORY_RENAME_DELTA_BYTES
            ):
                raise InvalidTask(
                    "FABRIC_MUTATION_NAMESPACE_TOO_LARGE: directory rename exceeds "
                    "the bounded 2-MiB incremental delta"
                )
            head = self.database.get_remote_manifest_head()
            base_generation, base_digest = _head_fields(head)
            operation = self.database.enqueue_rename(
                source_path,
                destination_path,
                base_generation=base_generation,
                base_digest=base_digest,
                directory_rename=True,
            )
            if retain_file_provider_receipt:
                self.retain_file_provider_receipts(operation.mutation_id)
            self.wake()
            return operation

    def _stage_local_put_bounded(
        self,
        path: str,
        *,
        expected_source_digest: object = _USE_REMOTE_DIGEST,
        delete_after_ack: tuple[str, str] | None = None,
        mutation_id: str | None = None,
        coalesce_pending: bool = True,
    ) -> PendingOperation | None:
        self._cancel_remote_materialization(path)
        fingerprint = self.workspace.stat_fingerprint(path)
        if (
            fingerprint is not None
            and fingerprint.size_bytes > BACKGROUND_TRANSFER_THRESHOLD_BYTES
        ):
            self._begin_local_transfer(
                path,
                fingerprint=fingerprint,
                delete_after_ack=delete_after_ack,
                expected_source_digest=expected_source_digest,
                transfer_id=mutation_id,
            )
            return None
        return self._stage_local_put(
            path,
            expected_source_digest=expected_source_digest,
            delete_after_ack=delete_after_ack,
            mutation_id=mutation_id,
            coalesce_pending=coalesce_pending,
        )

    def _namespace_lock(self, path: str) -> threading.RLock:
        """Return the bounded per-path namespace serialization stripe."""

        digest = hashlib.blake2s(path.encode("utf-8"), digest_size=2).digest()
        index = int.from_bytes(digest, "big") % len(self._namespace_locks)
        return self._namespace_locks[index]

    def _cancel_remote_materialization(self, path: str) -> None:
        """Fence an older remote apply behind newly durable local intent."""

        active = self._remote_transfer
        if active is not None and active.path == path:
            active.cancelled_by_local_mutation.set()

    def _pin_operation_cache_best_effort(
        self, mutation_id: str, file_digest: str
    ) -> None:
        """Keep disposable cache admission outside the durable journal boundary."""

        try:
            self.cache.pin_owner(
                f"operation:{mutation_id}", file_digest, dirty=True
            )
        except (OSError, FabricCacheError) as error:
            self.logger.record(
                "fabric_operation_cache_pin_skipped",
                mutation_id=mutation_id,
                error=str(error),
            )

    @staticmethod
    def _transfer_source_fingerprint(value: FileFingerprint) -> SourceFingerprint:
        return SourceFingerprint(
            device=value.device_id,
            inode=value.file_id,
            size_bytes=value.size_bytes,
            modified_ns=value.mtime_ns,
            changed_ns=value.ctime_ns,
        )

    @staticmethod
    def _workspace_source_fingerprint(value: SourceFingerprint) -> FileFingerprint:
        return FileFingerprint(
            size_bytes=value.size_bytes,
            mtime_ns=value.modified_ns,
            ctime_ns=value.changed_ns,
            device_id=value.device,
            file_id=value.inode,
        )

    @staticmethod
    def _transfer_source_id(path: str) -> str:
        return "workspace:" + hashlib.sha256(path.encode("utf-8")).hexdigest()

    @staticmethod
    def _local_transfer_logical_path(transfer_id: str) -> str:
        return f"local/{transfer_id}"

    def _anchored_transfer_source(
        self, path: str, *, collect_blocks: bool
    ) -> AnchoredLocalSource:
        source_id = self._transfer_source_id(path)
        self._transfer_source_paths[source_id] = path

        def stat_source() -> SourceFingerprint:
            try:
                current = self.workspace.stat_fingerprint(path)
            except (InvalidTask, UnsafePath, OSError) as error:
                raise SourceDrift("the anchored workspace source cannot be statted") from error
            if current is None:
                raise SourceDrift("the anchored workspace source disappeared")
            return self._transfer_source_fingerprint(current)

        def read_source_block(
            offset_bytes: int,
            size_bytes: int,
            expected: SourceFingerprint,
        ) -> bytes:
            try:
                data = self.workspace.read_regular_range(
                    path,
                    offset_bytes,
                    size_bytes,
                    self._workspace_source_fingerprint(expected),
                )
            except (InvalidTask, UnsafePath, OSError) as error:
                raise SourceDrift("the anchored workspace source changed during copy") from error
            if collect_blocks:
                block = StagedBlock(
                    index=offset_bytes // BLOCK_BYTES,
                    offset_bytes=offset_bytes,
                    size_bytes=size_bytes,
                    sha256=hashlib.sha256(data).hexdigest(),
                )
                with self._local_transfer_lock:
                    self._local_transfer_blocks[block.index] = block
            return data

        return AnchoredLocalSource(source_id, stat_source, read_source_block)

    def _resolve_transfer_source(
        self, source_id: str, _logical_path: str
    ) -> AnchoredLocalSource | None:
        path = self._transfer_source_paths.get(source_id)
        if path is None:
            return None
        return self._anchored_transfer_source(path, collect_blocks=True)

    def _begin_large_local_transfer(
        self,
        path: str,
        *,
        delete_after_ack: tuple[str, str] | None = None,
    ) -> bool:
        fingerprint = self.workspace.stat_fingerprint(path)
        if (
            fingerprint is None
            or fingerprint.size_bytes <= BACKGROUND_TRANSFER_THRESHOLD_BYTES
        ):
            return False
        return self._begin_local_transfer(
            path,
            fingerprint=fingerprint,
            delete_after_ack=delete_after_ack,
        )

    def _begin_local_transfer(
        self,
        path: str,
        *,
        fingerprint: FileFingerprint,
        delete_after_ack: tuple[str, str] | None,
        expected_source_digest: object = _USE_REMOTE_DIGEST,
        transfer_id: str | None = None,
    ) -> bool:
        """Durably hand one large watcher snapshot to the byte worker."""

        fingerprint_text = _fingerprint_text(fingerprint)
        existing = self.database.get_local_transfer_intent(path)
        if existing is not None:
            same_dependency = (
                existing.delete_after_ack_path,
                existing.delete_after_ack_digest,
            ) == (
                delete_after_ack if delete_after_ack is not None else (None, None)
            )
            if existing.source_fingerprint != fingerprint_text or not same_dependency:
                raise TransferBusy(
                    "a newer local state is waiting for the prior durable snapshot"
                )
            self.watch.acknowledge_local_state({path: fingerprint})
            return True

        remote = self._remote_entry_for_write(path)
        expected_digest = (
            remote.digest if remote is not None else None
        ) if expected_source_digest is _USE_REMOTE_DIGEST else expected_source_digest
        if expected_digest is not None and not _digest(expected_digest):
            raise StateError("The local transfer expected digest is invalid.")
        if fingerprint.size_bytes > MAX_LOCAL_UPLOAD_FILE_BYTES:
            self._record_unstageable_local_file(
                path,
                fingerprint,
                expected_digest=(str(expected_digest) if expected_digest else None),
            )
            return True
        intent = self.database.begin_local_transfer_intent(
            transfer_id=transfer_id or str(uuid.uuid4()),
            path=path,
            source_fingerprint=fingerprint_text,
            expected_remote_digest=(str(expected_digest) if expected_digest else None),
            delete_after_ack_path=(
                delete_after_ack[0] if delete_after_ack is not None else None
            ),
            delete_after_ack_digest=(
                delete_after_ack[1] if delete_after_ack is not None else None
            ),
            issue_code=None,
            issue_size_bytes=None,
        )
        current = self.database.get_materialized(path)
        self.database.mark_materialized(
            path,
            state="staging",
            clean_digest=(
                current.clean_digest
                if current is not None
                else (remote.digest if remote is not None else None)
            ),
            stat_fingerprint=fingerprint_text,
            bytes_on_disk=fingerprint.size_bytes,
            pinned=True,
        )
        self._transfer_source_paths[self._transfer_source_id(path)] = path
        # The DB row above is the durable watcher handoff. A crash before the
        # byte job exists recreates it from this exact source fingerprint;
        # subsequent local edits remain observable because suppression commits
        # only this stat tuple.
        self.watch.acknowledge_local_state({path: fingerprint})
        self.logger.record(
            "fabric_local_transfer_queued",
            path=path,
            transfer_id=intent.transfer_id,
            size_bytes=fingerprint.size_bytes,
        )
        # Snapshot-sized work uses the existing private-copy worker. Larger
        # files use the source-backed bulk planner, so staging capacity is not
        # an upload ceiling and every supported edit can make progress now.
        self.wake()
        return True

    def _record_unstageable_local_file(
        self,
        path: str,
        fingerprint: FileFingerprint,
        *,
        expected_digest: str | None,
        intent: LocalTransferIntent | None = None,
    ) -> None:
        ceiling = MAX_LOCAL_UPLOAD_FILE_BYTES
        reason = "local file exceeds the 512 GiB Fabric transfer format ceiling"
        self.database.record_conflict(
            path,
            reason,
            base_digest=expected_digest,
            local_fingerprint=_fingerprint_text(fingerprint),
            remote_digest=expected_digest,
            remote_generation=self._remote_generation(),
        )
        self.database.mark_materialized(
            path,
            state="conflict",
            clean_digest=expected_digest,
            stat_fingerprint=_fingerprint_text(fingerprint),
            bytes_on_disk=fingerprint.size_bytes,
            pinned=True,
        )
        self.watch.acknowledge_local_state({path: fingerprint})
        if intent is not None:
            self.database.complete_local_transfer_intent(intent.transfer_id)
            self._transfer_source_paths.pop(self._transfer_source_id(path), None)
        self.logger.record(
            "fabric_local_transfer_rejected",
            path=path,
            size_bytes=fingerprint.size_bytes,
            ceiling_bytes=ceiling,
            error=reason,
        )

    def _poll_local_transfer(self) -> int:
        """Advance at most one local transfer handoff without copying here."""

        if self._bulk_plan_future is not None:
            if not self._bulk_plan_future.done():
                return 0
            intent = self._bulk_plan_intent
            future = self._bulk_plan_future
            self._bulk_plan_future = None
            self._bulk_plan_intent = None
            self._bulk_plan_cancel = None
            if intent is None:
                raise StateError("The Fabric bulk planner lost its durable owner.")
            try:
                plan = future.result()
                self._finalize_source_backed_transfer(intent, plan)
            except BaseException as error:
                self._restart_local_transfer(intent, None, error)
            return 1

        if self._local_plan_future is not None:
            if not self._local_plan_future.done():
                return 0
            intent = self._local_transfer_intent
            job = self._local_transfer_job
            stage = self._local_plan_stage
            future = self._local_plan_future
            self._local_plan_future = None
            self._local_plan_stage = None
            if intent is None or job is None or stage is None:
                raise StateError("The Fabric local transfer planner lost its durable owner.")
            try:
                blocks = future.result()
            except BaseException as error:
                self._restart_local_transfer(intent, job, error)
                return 1
            self._finalize_local_transfer(intent, job, stage, blocks)
            self._clear_active_local_transfer()
            return 1

        if self._local_transfer_future is not None:
            if not self._local_transfer_future.done():
                return 0
            intent = self._local_transfer_intent
            job = self._local_transfer_job
            future = self._local_transfer_future
            self._local_transfer_future = None
            if intent is None or job is None:
                raise StateError("The Fabric local copy worker lost its durable owner.")
            try:
                stage = future.result()
            except BaseException as error:
                self._restart_local_transfer(intent, job, error)
                self._clear_active_local_transfer()
                return 1
            with self._local_transfer_lock:
                blocks = tuple(
                    self._local_transfer_blocks[index]
                    for index in sorted(self._local_transfer_blocks)
                )
            expected_blocks = (stage.size_bytes + BLOCK_BYTES - 1) // BLOCK_BYTES
            if len(blocks) == expected_blocks:
                self._finalize_local_transfer(intent, job, stage, blocks)
                self._clear_active_local_transfer()
                return 1
            # This only occurs after crash/reopen of an already-ready stage.
            # Reconstruct its block plan on a daemon byte lane, never here.
            self._local_plan_stage = stage
            self._local_plan_future = _daemon_future(
                "meshia-local-stage-plan",
                lambda: self._hash_verified_stage_blocks(stage),
            )
            self._local_plan_future.add_done_callback(
                lambda _future: self.wake()
            )
            return 0

        if self._local_transfer_open_future is not None:
            if not self._local_transfer_open_future.done():
                return 0
            intent = self._local_transfer_open_intent
            future = self._local_transfer_open_future
            self._local_transfer_open_future = None
            self._local_transfer_open_intent = None
            if intent is None:
                raise StateError("The Fabric transfer reopen lost its durable owner.")
            try:
                opened = future.result()
            except BaseException as error:
                self._restart_local_transfer(intent, None, error)
                return 1
            if not isinstance(opened, LocalSnapshotJob):
                raise StateError("A local transfer reopened as the wrong job kind.")
            self._start_local_copy_job(intent, opened)
            return 0

        if self._audit_one_local_transfer_issue():
            return 1
        intent = self.database.get_runnable_local_transfer_intent()
        if intent is None:
            return 0
        handed_off = self.database.get_operation(intent.transfer_id)
        if handed_off is not None:
            if handed_off.state in ("acked", "conflict", "quarantined"):
                # The operation journal now owns the staged/conflict evidence;
                # retaining its pre-enqueue copy-worker intent would block the
                # serial worker and reserve the same bytes forever.
                self.database.complete_local_transfer_intent(intent.transfer_id)
                self._validated_local_transfer_handoffs.pop(intent.transfer_id, None)
                self._transfer_source_paths.pop(
                    self._transfer_source_id(intent.path), None
                )
                return 1
            if (
                handed_off.kind != "put"
                or handed_off.path != intent.path
                or handed_off.staged_path is None
                or handed_off.staged_digest is None
                or handed_off.staged_size is None
            ):
                raise StateError(
                    "The local transfer UUID identifies different journal work."
                )
            signature = (
                handed_off.staged_path,
                handed_off.staged_digest,
                handed_off.staged_size,
            )
            if self._validated_local_transfer_handoffs.get(intent.transfer_id) != signature:
                plan = _load_plan(Path(handed_off.staged_path), handed_off)
                if (
                    plan.source_fingerprint != intent.source_fingerprint
                    or plan.delete_after_ack_path != intent.delete_after_ack_path
                    or plan.delete_after_ack_digest != intent.delete_after_ack_digest
                ):
                    raise StateError(
                        "The local transfer intent does not match its handed-off stage."
                    )
                self._validated_local_transfer_handoffs[intent.transfer_id] = signature
            return 0
        expected = _fingerprint_from_text(intent.source_fingerprint)
        current = self.workspace.stat_fingerprint(intent.path)
        if current is None or current != expected:
            self._restart_local_transfer(
                intent,
                None,
                SourceDrift("local source changed before snapshot start"),
            )
            return 1
        if current.size_bytes > MAX_LOCAL_UPLOAD_FILE_BYTES:
            self._record_unstageable_local_file(
                intent.path,
                current,
                expected_digest=intent.expected_remote_digest,
                intent=intent,
            )
            return 1
        # Every background transfer is source-backed: the plan pins the exact
        # device/inode/size/mtime/ctime identity and every block read and the
        # commit re-check it, so no user byte is copied into private staging
        # and no local disk is consumed. Drift restarts the transfer, exactly
        # as a native uploader re-uploads a file that changed underneath it.
        if current.size_bytes > BACKGROUND_TRANSFER_THRESHOLD_BYTES:
            self._bulk_plan_intent = intent
            cancel = threading.Event()
            self._bulk_plan_cancel = cancel
            self._bulk_plan_future = _daemon_future(
                "meshia-local-bulk-plan",
                lambda intent=intent, expected=current: (
                    self._build_source_backed_plan(intent, expected, cancel)
                ),
            )
            self._bulk_plan_future.add_done_callback(lambda _future: self.wake())
            self.logger.record(
                "fabric_local_bulk_planning",
                path=intent.path,
                transfer_id=intent.transfer_id,
                size_bytes=current.size_bytes,
                block_size_bytes=_adaptive_upload_block_bytes(current.size_bytes),
            )
            return 0
        if intent.issue_code is not None:
            intent = self.database.set_local_transfer_issue(
                intent.transfer_id,
                issue_code=None,
                issue_size_bytes=None,
            )
        self._transfer_source_paths[self._transfer_source_id(intent.path)] = intent.path
        logical_path = self._local_transfer_logical_path(intent.transfer_id)
        try:
            opened = self._transfer_store.open(
                logical_path, max_sync_verify_bytes=0
            )
        except FileNotFoundError:
            source = self._anchored_transfer_source(
                intent.path, collect_blocks=True
            )
            if source.fingerprint() != self._transfer_source_fingerprint(expected):
                self._restart_local_transfer(
                    intent, None, SourceDrift("local source changed before snapshot start")
                )
                return 1
            try:
                opened = self._transfer_store.create_local(logical_path, source)
            except (TransferError, OSError) as error:
                # Admission/free-space failures are retryable durable backlog;
                # no watcher event or source byte is discarded.
                self.logger.record(
                    "fabric_local_transfer_deferred",
                    path=intent.path,
                    error=str(error),
                )
                return 0
        except RecoveryDeferred:
            try:
                self._local_transfer_open_future = self._transfer_store.open_async(
                    logical_path
                )
            except TransferBusy:
                return 0
            self._local_transfer_open_intent = intent
            self._local_transfer_open_future.add_done_callback(
                lambda _future: self.wake()
            )
            return 0
        if not isinstance(opened, LocalSnapshotJob):
            raise StateError("A local transfer path belongs to a remote job.")
        self._start_local_copy_job(intent, opened)
        return 0

    def _audit_one_local_transfer_issue(self) -> bool:
        """Reclassify one explicit issue without scanning or spinning on it.

        The partial issue index and keyset cursor cap this at two one-row
        lookups and one local stat per idle transfer tick. A wrap lookup is
        needed only after reaching the end of the current issue ring.
        """

        issues = self.database.list_local_transfer_issues(
            limit=1, after=self._local_issue_audit_cursor
        )
        if not issues and self._local_issue_audit_cursor is not None:
            self._local_issue_audit_cursor = None
            issues = self.database.list_local_transfer_issues(limit=1)
        if not issues:
            return False
        intent = issues[0]
        self._local_issue_audit_cursor = (
            intent.created_at_ns,
            intent.transfer_id,
        )
        expected = _fingerprint_from_text(intent.source_fingerprint)
        current = self.workspace.stat_fingerprint(intent.path)
        if current is not None and current.size_bytes > MAX_LOCAL_UPLOAD_FILE_BYTES:
            self._record_unstageable_local_file(
                intent.path,
                current,
                expected_digest=intent.expected_remote_digest,
                intent=intent,
            )
            return True
        if current is None or current != expected:
            self._restart_local_transfer(
                intent,
                None,
                SourceDrift("deferred local source changed during issue audit"),
            )
            return True
        self.database.set_local_transfer_issue(
            intent.transfer_id,
            issue_code=None,
            issue_size_bytes=None,
        )
        self.wake()
        return True

    def _start_local_copy_job(
        self, intent: LocalTransferIntent, job: LocalSnapshotJob
    ) -> None:
        self._local_transfer_intent = intent
        self._local_transfer_job = job
        with self._local_transfer_lock:
            self._local_transfer_blocks.clear()
        state = job.progress.get("state")
        if state in ("ready", "leased"):
            stage = job.verified_stage()
            self._local_plan_stage = stage
            self._local_plan_future = _daemon_future(
                "meshia-local-stage-plan",
                lambda: self._hash_verified_stage_blocks(stage),
            )
            self._local_plan_future.add_done_callback(
                lambda _future: self.wake()
            )
            return
        self._local_transfer_future = self._local_copy_worker.submit(job)
        self._local_transfer_future.add_done_callback(
            lambda _future: self.wake()
        )

    def _hash_verified_stage_blocks(
        self, stage: VerifiedStage
    ) -> tuple[StagedBlock, ...]:
        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(str(stage.path), flags)
        blocks: list[StagedBlock] = []
        whole = hashlib.sha256()
        try:
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size != stage.size_bytes:
                raise StateError("The verified transfer stage changed before publication.")
            offset = 0
            while offset < stage.size_bytes:
                size = min(BLOCK_BYTES, stage.size_bytes - offset)
                data = bytearray()
                while len(data) < size:
                    chunk = os.read(descriptor, size - len(data))
                    if not chunk:
                        break
                    data.extend(chunk)
                if len(data) != size:
                    raise StateError("The verified transfer stage was truncated.")
                payload = bytes(data)
                whole.update(payload)
                blocks.append(
                    StagedBlock(
                        index=len(blocks),
                        offset_bytes=offset,
                        size_bytes=size,
                        sha256=hashlib.sha256(payload).hexdigest(),
                    )
                )
                offset += size
            after = os.fstat(descriptor)
            if (
                after.st_dev != info.st_dev
                or after.st_ino != info.st_ino
                or after.st_size != info.st_size
                or after.st_mtime_ns != info.st_mtime_ns
                or after.st_ctime_ns != info.st_ctime_ns
                or whole.hexdigest() != stage.sha256
            ):
                raise StateError("The verified transfer stage failed publication verification.")
        finally:
            os.close(descriptor)
        return tuple(blocks)

    def _build_source_backed_plan(
        self,
        intent: LocalTransferIntent,
        expected: FileFingerprint,
        cancel: threading.Event | None = None,
    ) -> StagePlan:
        """Hash one exact local identity into adaptive immutable CAS extents.

        No user byte is copied into private staging. ``read_regular_range``
        pins every read to the original device/inode/size/mtime/ctime tuple,
        and the complete tuple is checked again after the final block. A crash
        before this bounded plan is published merely repeats the local hash;
        once published, the ordinary upload journal resumes provider progress.
        """

        if expected.size_bytes > MAX_LOCAL_UPLOAD_FILE_BYTES:
            raise InvalidTask("The local file exceeds the 512 GiB upload ceiling.")
        if intent.source_fingerprint != _fingerprint_text(expected):
            raise SourceDrift("the local source changed before bulk planning")
        target_sizes = self._target_block_sizes_for_reuse(
            intent.path, expected.size_bytes
        )
        block_size = (
            max(target_sizes)
            if target_sizes
            else _adaptive_upload_block_bytes(expected.size_bytes)
        )
        hash_workers = _source_plan_hash_concurrency(block_size)
        whole = hashlib.sha256()
        blocks: list[StagedBlock] = []
        offset = 0
        # One sequential read pass feeds the whole-file digest on this thread
        # while extent digests run on a small pool (hashlib releases the GIL),
        # so planning runs at the file digest's rate instead of twice the
        # bytes through one core. In-flight extents are bounded so at most a
        # few extents of source bytes are resident.
        pending: collections.deque[tuple[int, int, concurrent.futures.Future[str]]] = (
            collections.deque()
        )
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=hash_workers,
            thread_name_prefix="meshia-source-plan-hash",
        ) as pool:
            def drain(limit: int) -> None:
                while len(pending) > limit:
                    block_offset, block_bytes, future = pending.popleft()
                    blocks.append(
                        StagedBlock(
                            index=len(blocks),
                            offset_bytes=block_offset,
                            size_bytes=block_bytes,
                            sha256=future.result(),
                        )
                    )

            next_progress = float(self._clock()) + (
                SOURCE_PLAN_PROGRESS_INTERVAL_SECONDS
            )
            while offset < expected.size_bytes:
                if cancel is not None and cancel.is_set():
                    raise SourceDrift("the bulk upload planner was stopped")
                now = float(self._clock())
                if now >= next_progress:
                    next_progress = now + SOURCE_PLAN_PROGRESS_INTERVAL_SECONDS
                    self.logger.record(
                        "fabric_local_bulk_planning_progress",
                        path=intent.path,
                        transfer_id=intent.transfer_id,
                        hashed_bytes=offset,
                        size_bytes=expected.size_bytes,
                        percent=int(offset * 100 / max(1, expected.size_bytes)),
                    )
                size = (
                    target_sizes[len(blocks) + len(pending)]
                    if target_sizes
                    else min(block_size, expected.size_bytes - offset)
                )
                try:
                    data = self.workspace.read_regular_range(
                        intent.path, offset, size, expected
                    )
                except (InvalidTask, UnsafePath, OSError) as error:
                    raise SourceDrift(
                        "the local source changed during bulk planning"
                    ) from error
                pending.append(
                    (offset, size, pool.submit(_sha256_hex, data))
                )
                whole.update(data)
                del data
                offset += size
                # Drain after the append so the transient high-water mark is
                # exactly ``hash_workers`` extents, never workers + one.
                drain(hash_workers - 1)
            drain(0)
        if cancel is not None and cancel.is_set():
            raise SourceDrift("the bulk upload planner was stopped")
        if not blocks:
            blocks.append(StagedBlock(0, 0, 0, _EMPTY_SHA256))
        current = self.workspace.stat_fingerprint(intent.path)
        if current != expected:
            raise SourceDrift("the local source changed after bulk planning")
        if len(blocks) > MAX_MANIFEST_BLOCKS:
            raise StateError("The adaptive bulk plan exceeds 8,192 blocks.")
        return StagePlan(
            path=intent.path,
            size_bytes=expected.size_bytes,
            sha256=whole.hexdigest(),
            source_fingerprint=intent.source_fingerprint,
            blocks=tuple(blocks),
            delete_after_ack_path=intent.delete_after_ack_path,
            delete_after_ack_digest=intent.delete_after_ack_digest,
            source_path=intent.path,
            preserved_target_extents=bool(target_sizes),
        )

    def _finalize_source_backed_transfer(
        self, intent: LocalTransferIntent, plan: StagePlan
    ) -> PendingOperation:
        """Publish a tiny durable marker that owns a source-backed upload."""

        if (
            plan.source_path != intent.path
            or plan.path != intent.path
            or plan.source_fingerprint != intent.source_fingerprint
            or plan.size_bytes > MAX_LOCAL_UPLOAD_FILE_BYTES
        ):
            raise StateError("The source-backed upload plan changed identity.")
        self._assert_source_backed_plan_current(plan)
        stage = self.staging_root / f"{intent.transfer_id}.data"
        self._reserve_classic_stage(stage, 0)
        published = False
        try:
            try:
                info = stage.lstat()
            except FileNotFoundError:
                write_private_file(stage, b"")
                info = stage.lstat()
            if (
                not stat.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or info.st_size != 0
            ):
                raise StateError("The source-backed upload marker is unsafe.")
            _write_json(_plan_path(stage), _plan_document(plan))
            _fsync_dir(self.staging_root)
            head = self.database.get_remote_manifest_head()
            base_generation, base_digest = _head_fields(head)
            operation = self.database.enqueue_put(
                intent.path,
                mutation_id=intent.transfer_id,
                base_generation=base_generation,
                base_digest=base_digest,
                expected_source_digest=intent.expected_remote_digest,
                staged_path=stage,
                staged_digest=plan.sha256,
                staged_size=plan.size_bytes,
            )
            if (
                intent.delete_after_ack_path is not None
                and operation.mutation_id != intent.transfer_id
            ):
                intent = self.database.supersede_local_transfer_intent(
                    intent.transfer_id,
                    transfer_id=operation.mutation_id,
                    path=intent.path,
                    source_fingerprint=intent.source_fingerprint,
                    expected_remote_digest=intent.expected_remote_digest,
                    delete_after_ack_path=intent.delete_after_ack_path,
                    delete_after_ack_digest=intent.delete_after_ack_digest,
                    delete_mutation_id=intent.delete_mutation_id,
                )
            published = True
        finally:
            if not published:
                self._remove_stage_family(stage)
        self.database.mark_materialized(
            intent.path,
            state="dirty",
            clean_digest=(
                self.database.get_materialized(intent.path).clean_digest
                if self.database.get_materialized(intent.path) is not None
                else intent.expected_remote_digest
            ),
            stat_fingerprint=intent.source_fingerprint,
            bytes_on_disk=plan.size_bytes,
            pinned=True,
        )
        self._pin_operation_cache_best_effort(operation.mutation_id, plan.sha256)
        if intent.delete_after_ack_path is None:
            self.database.complete_local_transfer_intent(intent.transfer_id)
        else:
            self._validated_local_transfer_handoffs[operation.mutation_id] = (
                str(operation.staged_path),
                str(operation.staged_digest),
                int(operation.staged_size),
            )
        self.logger.record(
            "fabric_local_bulk_staged",
            path=intent.path,
            transfer_id=intent.transfer_id,
            size_bytes=plan.size_bytes,
            block_count=len(plan.blocks),
            block_size_bytes=max(block.size_bytes for block in plan.blocks),
            staged_bytes=0,
        )
        return operation

    def _assert_source_backed_plan_current(
        self,
        plan: StagePlan,
        *,
        observed: FileFingerprint | None | object = _FINGERPRINT_NOT_OBSERVED,
    ) -> None:
        if plan.source_kind == "file_provider_fd":
            token = plan.source_token
            if token is None:
                raise StateError("The File Provider source plan has no lease token.")
            with self._file_provider_sources_lock:
                lease = self._file_provider_sources.get(token)
            if lease is None:
                raise FileProviderSourceUnavailable(
                    "the File Provider source must be reattached"
                )
            with lease.lock:
                if lease.cancelled:
                    raise FileProviderSourceUnavailable(
                        "the File Provider source was detached"
                    )
                if self._descriptor_fingerprint(lease.descriptor) != lease.fingerprint:
                    raise SourceDrift("the File Provider source changed before commit")
            return
        if plan.source_path is None:
            return
        expected = _fingerprint_from_text(plan.source_fingerprint)
        if observed is _FINGERPRINT_NOT_OBSERVED:
            try:
                current = self.workspace.stat_fingerprint(plan.source_path)
            except (InvalidTask, UnsafePath, OSError) as error:
                raise SourceDrift(
                    "the source-backed upload cannot stat its source"
                ) from error
        else:
            current = observed
        if current != expected:
            raise SourceDrift("the source-backed upload changed before commit")

    def _finalize_local_transfer(
        self,
        intent: LocalTransferIntent,
        job: LocalSnapshotJob,
        stage: VerifiedStage,
        blocks: Sequence[StagedBlock],
    ) -> PendingOperation:
        expected_count = (stage.size_bytes + BLOCK_BYTES - 1) // BLOCK_BYTES
        if len(blocks) != expected_count:
            raise StateError("The local transfer block plan is incomplete.")
        plan = StagePlan(
            path=intent.path,
            size_bytes=stage.size_bytes,
            sha256=stage.sha256,
            source_fingerprint=intent.source_fingerprint,
            blocks=tuple(blocks),
            delete_after_ack_path=intent.delete_after_ack_path,
            delete_after_ack_digest=intent.delete_after_ack_digest,
            transfer_logical_path=stage.logical_path,
            transfer_token=stage.token,
        )
        _write_json(_plan_path(stage.path), _plan_document(plan))
        head = self.database.get_remote_manifest_head()
        base_generation, base_digest = _head_fields(head)
        state = job.progress.get("state")
        claimed_here = False
        if state == "ready":
            self._transfer_store.claim_ready(stage.logical_path, stage.token)
            claimed_here = True
        elif state != "leased" or job.progress.get("token") != stage.token:
            raise StateError("The local transfer stage lease is inconsistent.")
        try:
            operation = self.database.enqueue_put(
                intent.path,
                mutation_id=intent.transfer_id,
                base_generation=base_generation,
                base_digest=base_digest,
                expected_source_digest=intent.expected_remote_digest,
                staged_path=stage.path,
                staged_digest=stage.sha256,
                staged_size=stage.size_bytes,
            )
            if (
                intent.delete_after_ack_path is not None
                and operation.mutation_id != intent.transfer_id
            ):
                # enqueue_put may coalesce into an older never-sent path row.
                # Move the dependency metadata onto that actual mutation UUID
                # atomically; acknowledgement must find the deterministic delete
                # identity under the UUID carried on the wire.
                intent = self.database.supersede_local_transfer_intent(
                    intent.transfer_id,
                    transfer_id=operation.mutation_id,
                    path=intent.path,
                    source_fingerprint=intent.source_fingerprint,
                    expected_remote_digest=intent.expected_remote_digest,
                    delete_after_ack_path=intent.delete_after_ack_path,
                    delete_after_ack_digest=intent.delete_after_ack_digest,
                    delete_mutation_id=intent.delete_mutation_id,
                )
        except BaseException:
            if claimed_here:
                self._transfer_store.release_ready(
                    stage.logical_path, stage.token
                )
            raise
        self.database.mark_materialized(
            intent.path,
            state="dirty",
            clean_digest=(
                self.database.get_materialized(intent.path).clean_digest
                if self.database.get_materialized(intent.path) is not None
                else None
            ),
            stat_fingerprint=intent.source_fingerprint,
            bytes_on_disk=stage.size_bytes,
            pinned=True,
        )
        self._pin_operation_cache_best_effort(operation.mutation_id, plan.sha256)
        if intent.delete_after_ack_path is None:
            self.database.complete_local_transfer_intent(intent.transfer_id)
            self._transfer_source_paths.pop(
                self._transfer_source_id(intent.path), None
            )
        else:
            self._validated_local_transfer_handoffs[operation.mutation_id] = (
                str(operation.staged_path),
                str(operation.staged_digest),
                int(operation.staged_size),
            )
        self.logger.record(
            "fabric_local_transfer_staged",
            path=intent.path,
            transfer_id=intent.transfer_id,
            size_bytes=stage.size_bytes,
        )
        return operation

    def _restart_local_transfer(
        self,
        intent: LocalTransferIntent,
        job: LocalSnapshotJob | None,
        error: BaseException,
    ) -> None:
        if job is not None:
            try:
                if job.progress.get("state") not in ("cancelled", "quarantined"):
                    job.cancel("local source changed before durable publication")
                self._transfer_store.remove_terminal(
                    job.logical_path, job.transfer_id
                )
            except (OSError, TransferError):
                pass
        current = self.workspace.stat_fingerprint(intent.path)
        dependency = (
            (intent.delete_after_ack_path, intent.delete_after_ack_digest)
            if intent.delete_after_ack_path is not None
            and intent.delete_after_ack_digest is not None
            else None
        )
        if current is None:
            # The successor tombstone is durable before the old snapshot row
            # disappears, so a crash cannot strand a staging materialization.
            self._stage_delete(
                intent.path,
                expected_source_digest=intent.expected_remote_digest,
            )
            if dependency is not None:
                self._stage_delete(
                    dependency[0], expected_source_digest=dependency[1]
                )
            self.database.complete_local_transfer_intent(intent.transfer_id)
            self._transfer_source_paths.pop(
                self._transfer_source_id(intent.path), None
            )
        elif current.size_bytes > MAX_LOCAL_UPLOAD_FILE_BYTES:
            self._record_unstageable_local_file(
                intent.path,
                current,
                expected_digest=intent.expected_remote_digest,
                intent=intent,
            )
        elif current.size_bytes > BACKGROUND_TRANSFER_THRESHOLD_BYTES:
            successor_id = str(uuid.uuid4())
            successor = self.database.supersede_local_transfer_intent(
                intent.transfer_id,
                transfer_id=successor_id,
                path=intent.path,
                source_fingerprint=_fingerprint_text(current),
                expected_remote_digest=intent.expected_remote_digest,
                delete_after_ack_path=(dependency[0] if dependency else None),
                delete_after_ack_digest=(dependency[1] if dependency else None),
                delete_mutation_id=intent.delete_mutation_id,
                issue_code=None,
                issue_size_bytes=None,
            )
            self.database.mark_materialized(
                intent.path,
                state="staging",
                clean_digest=(
                    self.database.get_materialized(intent.path).clean_digest
                    if self.database.get_materialized(intent.path) is not None
                    else intent.expected_remote_digest
                ),
                stat_fingerprint=successor.source_fingerprint,
                bytes_on_disk=current.size_bytes,
                pinned=True,
            )
            self._transfer_source_paths[self._transfer_source_id(intent.path)] = (
                intent.path
            )
            self.watch.acknowledge_local_state({intent.path: current})
        else:
            # A bounded classic stage can be captured while the old intent is
            # still durable; only then retire that row.
            self._stage_local_put(
                intent.path,
                expected_source_digest=intent.expected_remote_digest,
                delete_after_ack=dependency,
            )
            self.database.complete_local_transfer_intent(intent.transfer_id)
            self._transfer_source_paths.pop(
                self._transfer_source_id(intent.path), None
            )
        self.logger.record(
            "fabric_local_transfer_restarted",
            path=intent.path,
            error=str(error),
        )

    def _supersede_source_backed_operation(
        self, operation: PendingOperation, error: BaseException
    ) -> None:
        """Retire a mutable-source plan and durably capture its latest state."""

        if operation.staged_path is None:
            raise StateError("The source-backed operation lost its plan marker.")
        plan = _load_plan(Path(operation.staged_path), operation)
        if plan.source_kind == "file_provider_fd":
            self.release_file_provider_source(operation.mutation_id)
            self._record_operation_conflict(
                operation, f"the File Provider source changed: {error}"
            )
            return
        if plan.source_path is None:
            self._record_operation_conflict(
                operation, f"an immutable Fabric stage changed unexpectedly: {error}"
            )
            return
        self.database.supersede_operation(
            operation.mutation_id,
            reason="source-backed upload changed; superseded by current local state",
        )
        self._discard_prefetched_write_tickets(
            operation.mutation_id, reason="source_superseded"
        )
        self._put_progress_cache_key = None
        self._put_progress_cache = None
        dependency = (
            (plan.delete_after_ack_path, plan.delete_after_ack_digest)
            if plan.delete_after_ack_path is not None
            and plan.delete_after_ack_digest is not None
            else None
        )
        if self.workspace.stat_fingerprint(plan.source_path) is None:
            self._stage_delete(
                plan.source_path,
                expected_source_digest=operation.expected_source_digest,
            )
            if dependency is not None:
                self._stage_delete(
                    dependency[0], expected_source_digest=dependency[1]
                )
        else:
            self._stage_local_put_bounded(
                plan.source_path,
                expected_source_digest=operation.expected_source_digest,
                delete_after_ack=dependency,
            )
        self.logger.record(
            "fabric_local_bulk_superseded",
            mutation_id=operation.mutation_id,
            path=plan.source_path,
            error=str(error),
        )

    def _clear_active_local_transfer(self) -> None:
        self._local_transfer_future = None
        self._local_transfer_job = None
        self._local_transfer_intent = None
        with self._local_transfer_lock:
            self._local_transfer_blocks.clear()

    def _stage_local_put(
        self,
        path: str,
        *,
        expected_source_digest: object = _USE_REMOTE_DIGEST,
        delete_after_ack: tuple[str, str] | None = None,
        mutation_id: str | None = None,
        coalesce_pending: bool = True,
    ) -> PendingOperation:
        if delete_after_ack is None:
            predecessor = self.database.get_latest_nonterminal_operation(path)
            if predecessor is not None and predecessor.kind == "put" and predecessor.staged_path:
                predecessor_plan = _load_plan(
                    Path(predecessor.staged_path), predecessor
                )
                if (
                    predecessor_plan.delete_after_ack_path is not None
                    and predecessor_plan.delete_after_ack_digest is not None
                ):
                    delete_after_ack = (
                        predecessor_plan.delete_after_ack_path,
                        predecessor_plan.delete_after_ack_digest,
                    )
        mutation_id = mutation_id or str(uuid.uuid4())
        existing_operation = self.database.get_operation(mutation_id)
        if existing_operation is not None:
            if (
                existing_operation.kind != "put"
                or existing_operation.path != path
                or existing_operation.staged_path is None
                or existing_operation.staged_digest is None
                or existing_operation.staged_size is None
            ):
                raise StateError(
                    "A deterministic local snapshot UUID identifies different work."
                )
            return existing_operation
        stage_path = self.staging_root / f"{mutation_id}.data"
        plan = self._copy_stable_stage(
            path, stage_path, delete_after_ack=delete_after_ack
        )
        _write_json(_plan_path(stage_path), _plan_document(plan))
        head = self.database.get_remote_manifest_head()
        remote = self._remote_entry_for_write(path)
        expected_digest = (
            remote.digest if remote else None
        ) if expected_source_digest is _USE_REMOTE_DIGEST else expected_source_digest
        if expected_digest is not None and not _digest(expected_digest):
            raise StateError("The staged put expected digest is invalid.")
        base_generation, base_digest = _head_fields(head)
        operation = self.database.enqueue_put(
            path,
            mutation_id=mutation_id,
            base_generation=base_generation,
            base_digest=base_digest,
            expected_source_digest=str(expected_digest) if expected_digest else None,
            staged_path=stage_path,
            staged_digest=plan.sha256,
            staged_size=plan.size_bytes,
            coalesce=coalesce_pending,
        )
        self.database.mark_materialized(
            path,
            state="dirty",
            clean_digest=(self.database.get_materialized(path).clean_digest if self.database.get_materialized(path) else None),
            stat_fingerprint=plan.source_fingerprint,
            bytes_on_disk=plan.size_bytes,
            pinned=True,
        )
        self._pin_operation_cache_best_effort(operation.mutation_id, plan.sha256)
        self.watch.acknowledge_local_state({path: self.staged_post_state(operation)})
        return operation

    def staged_post_state(self, operation: PendingOperation) -> HashedRegularFile:
        """Return the exact watcher post-state represented by a durable put stage."""

        if operation.kind != "put" or operation.staged_path is None:
            raise StateError("Only a staged Fabric put has a local post-state.")
        plan = _load_plan(Path(operation.staged_path), operation)
        try:
            raw = json.loads(plan.source_fingerprint)
            fingerprint = FileFingerprint(
                size_bytes=int(raw["size_bytes"]),
                mtime_ns=int(raw["mtime_ns"]),
                ctime_ns=int(raw["ctime_ns"]),
                device_id=int(raw["device_id"]),
                file_id=int(raw["file_id"]),
            )
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
            raise StateError("The staged Fabric fingerprint is invalid.") from error
        return HashedRegularFile(fingerprint=fingerprint, sha256=plan.sha256)

    def stage_local_state(
        self, path: str, *, retain_file_provider_receipt: bool = False
    ) -> PendingOperation | None:
        """Durably snapshot whichever local state currently owns one path."""

        with self._coordinator_lock:
            if self.workspace.stat_fingerprint(path) is None:
                operation = self._stage_delete(path)
            else:
                operation = self._stage_local_put_bounded(path)
            if operation is not None and retain_file_provider_receipt:
                self.retain_file_provider_receipts(operation.mutation_id)
            self.wake()
            return operation

    def stage_file_provider_write(
        self,
        path: str,
        *,
        expected_source_digest: str | None,
        delete_after_ack: tuple[str, str] | None = None,
        publish_local_namespace: Callable[[], None] | None = None,
        mutation_id: str | None = None,
        defer_seconds: float | None = None,
    ) -> PendingOperation | None:
        """Stage a native write, preserving an optional rename dependency.

        ``defer_seconds`` holds the queued put back (a retry fence) so a
        transport artefact such as an AppleDouble sidecar can be paired,
        discarded, or unlinked before it spends an upload wave.

        File Provider can report a rename and new contents in one callback. The
        destination must become durable before the old remote name disappears,
        so the source tombstone is owned by the put receipt rather than queued
        as an independent mutation.
        """

        with self._coordinator_lock:
            with self._namespace_lock(path):
                self._cancel_remote_materialization(path)
                return self._stage_file_provider_write_locked(
                    path,
                    expected_source_digest=expected_source_digest,
                    delete_after_ack=delete_after_ack,
                    publish_local_namespace=publish_local_namespace,
                    mutation_id=mutation_id,
                    defer_seconds=defer_seconds,
                )

    def stage_file_provider_descriptor(
        self,
        path: str,
        descriptor: int,
        *,
        idempotency_key: str,
        expected_source_digest: str | None,
        expected_size: int | None = None,
        delete_after_ack: tuple[str, str] | None = None,
        validate_new: Callable[[], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
        modified_at: str | None = None,
        item_identifier: str | None = None,
        base_metadata_version: str | None = None,
        replay_base_digest: str | None = None,
        replay_mutation_ids: tuple[str, str] | None = None,
    ) -> tuple[PendingOperation, StagePlan]:
        """Publish a File Provider-owned inode without making a second copy.

        Apple retains the contents URL until the extension completes its
        callback.  The bridge passes an open descriptor for that URL; this
        method hashes it into the ordinary Fabric CAS plan, persists only a
        zero-byte stage marker, and lets the existing concurrent uploader
        ``pread`` the descriptor.  The deterministic mutation UUID makes a
        system retry after response loss attach to the same durable receipt.
        """

        if (
            isinstance(descriptor, bool)
            or not isinstance(descriptor, int)
            or descriptor < 0
        ):
            raise InvalidTask("The File Provider source descriptor is invalid.")
        if (
            not isinstance(idempotency_key, str)
            or not idempotency_key
            or len(idempotency_key.encode("utf-8")) > 4_096
        ):
            raise InvalidTask("The File Provider idempotency key is invalid.")
        if expected_size is not None and (
            isinstance(expected_size, bool)
            or not isinstance(expected_size, int)
            or expected_size < 0
        ):
            raise InvalidTask("The File Provider source size is invalid.")
        modified_at = _normalized_modified_at(modified_at)
        if item_identifier is not None and (
            not isinstance(item_identifier, str)
            or not 1 <= len(item_identifier.encode("utf-8")) <= 256
        ):
            raise InvalidTask("The File Provider item identifier is invalid.")
        if base_metadata_version is not None and not _digest(base_metadata_version):
            raise InvalidTask("The File Provider base metadata version is invalid.")
        if replay_base_digest is not None and not _digest(replay_base_digest):
            raise InvalidTask("The File Provider replay base digest is invalid.")

        owned = os.dup(descriptor)
        os.set_inheritable(owned, False)
        attached = False
        intent_created = False
        held_receipts: tuple[str, ...] = ()
        operation: PendingOperation | None = None
        try:
            planned = self._plan_file_provider_descriptor(
                owned,
                path=path,
                expected_size=expected_size,
                is_cancelled=is_cancelled,
            )
            fingerprint, digest, blocks, fine_extents = planned
            mutation_id = str(
                uuid.uuid5(
                    uuid.NAMESPACE_URL,
                    "meshia:file-provider-write:v1\0"
                    + idempotency_key
                    + "\0"
                    + str(fingerprint.size_bytes)
                    + "\0"
                    + digest,
                )
            )
            if replay_mutation_ids is not None:
                mutation_id = replay_mutation_ids[0]
            delete_mutation_id = (
                str(
                    uuid.uuid5(
                        uuid.NAMESPACE_URL,
                        "meshia:file-provider-delete:v1\0"
                        + mutation_id
                        + "\0"
                        + delete_after_ack[0]
                        + "\0"
                        + delete_after_ack[1],
                    )
                )
                if delete_after_ack is not None
                else None
            )
            if replay_mutation_ids is not None:
                if delete_after_ack is None:
                    raise StateError(
                        "A compound File Provider replay lost its source delete."
                    )
                delete_mutation_id = replay_mutation_ids[1]
            plan = StagePlan(
                path=path,
                size_bytes=fingerprint.size_bytes,
                sha256=digest,
                source_fingerprint=_fingerprint_text(fingerprint),
                blocks=blocks,
                delete_after_ack_path=(
                    delete_after_ack[0] if delete_after_ack is not None else None
                ),
                delete_after_ack_digest=(
                    delete_after_ack[1] if delete_after_ack is not None else None
                ),
                source_kind="file_provider_fd",
                preserved_target_extents=fine_extents,
                source_token=mutation_id,
                delete_after_ack_mutation_id=delete_mutation_id,
                modified_at=modified_at,
            )

            with self._coordinator_lock:
                path_owner = self.database.get_latest_nonterminal_operation(path)
                if (
                    path_owner is not None
                    and path_owner.mutation_id != mutation_id
                ):
                    raise StateError(
                        "another pending mutation owns the File Provider target"
                    )
                existing = self.database.get_operation(mutation_id)
                if existing is not None:
                    if (
                        existing.kind != "put"
                        or existing.path != path
                        or existing.staged_digest != digest
                        or existing.staged_size != fingerprint.size_bytes
                    ):
                        raise StateError(
                            "A File Provider retry identifies different Fabric work."
                        )
                    if existing.state in ("conflict", "quarantined"):
                        raise StateError(
                            "The File Provider write cannot resume from its durable state."
                        )
                    if replay_mutation_ids is not None:
                        deletion = self.database.get_operation(delete_mutation_id)
                        if (
                            deletion is None
                            or deletion.kind != "delete"
                            or delete_after_ack is None
                            or deletion.path != delete_after_ack[0]
                            or deletion.expected_source_digest != delete_after_ack[1]
                            or deletion.state in ("conflict", "quarantined")
                        ):
                            raise StateError(
                                "The compound File Provider replay lost its exact delete."
                            )
                    held_receipts = tuple(
                        value
                        for value in (mutation_id, delete_mutation_id)
                        if value is not None
                    )
                    self.retain_file_provider_receipts(*held_receipts)
                    if existing.state == "acked":
                        return existing, plan
                    self._attach_file_provider_source(mutation_id, owned, fingerprint)
                    attached = True
                    operation = existing
                    if existing.state == "retry" and not existing.commit_unknown:
                        operation = self.database.update_operation(
                            mutation_id,
                            state="retry",
                            error="File Provider source reattached",
                            retry_after_seconds=0.0,
                            reset_failures=True,
                            now_ns=self._wall_now_ns(),
                        )
                    self.wake()
                    return operation, plan

                if replay_mutation_ids is not None:
                    raise StateError(
                        "The compound File Provider replay receipt is unavailable."
                    )

                if validate_new is not None:
                    validate_new()

                stage = self.staging_root / f"{mutation_id}.data"
                self._reserve_classic_stage(stage, 0)
                published = False
                try:
                    write_private_file(stage, b"")
                    _write_json(_plan_path(stage), _plan_document(plan))
                    _write_json(
                        _file_provider_callback_path(stage),
                        {
                            "version": 1,
                            "path": path,
                            "size_bytes": fingerprint.size_bytes,
                            "sha256": digest,
                            "modified_at": modified_at,
                            "delete_after_ack_path": (
                                delete_after_ack[0]
                                if delete_after_ack is not None
                                else None
                            ),
                            "delete_after_ack_mutation_id": delete_mutation_id,
                            "item_identifier": item_identifier,
                            "base_content_version": replay_base_digest,
                            "base_metadata_version": base_metadata_version,
                        },
                    )
                    _fsync_dir(self.staging_root)
                    if delete_after_ack is not None:
                        intent = self.database.begin_local_transfer_intent(
                            transfer_id=mutation_id,
                            path=path,
                            source_fingerprint=plan.source_fingerprint,
                            expected_remote_digest=expected_source_digest,
                            delete_after_ack_path=delete_after_ack[0],
                            delete_after_ack_digest=delete_after_ack[1],
                            delete_mutation_id=delete_mutation_id,
                        )
                        intent_created = True
                        assert intent.delete_mutation_id is not None
                        held_receipts = (mutation_id, intent.delete_mutation_id)
                    else:
                        held_receipts = (mutation_id,)
                    self.retain_file_provider_receipts(*held_receipts)
                    head = self.database.get_remote_manifest_head()
                    base_generation, base_digest = _head_fields(head)
                    operation = self.database.enqueue_put(
                        path,
                        mutation_id=mutation_id,
                        base_generation=base_generation,
                        base_digest=base_digest,
                        expected_source_digest=expected_source_digest,
                        staged_path=stage,
                        staged_digest=digest,
                        staged_size=fingerprint.size_bytes,
                        coalesce=False,
                    )
                    self._record_classic_stage_committed(stage)
                    published = True
                finally:
                    if not published:
                        if held_receipts:
                            self.release_file_provider_receipts(*held_receipts)
                        if intent_created:
                            self.database.complete_local_transfer_intent(mutation_id)
                            intent_created = False
                        self._remove_stage_family(stage)
                self._attach_file_provider_source(mutation_id, owned, fingerprint)
                attached = True
                self._pin_operation_cache_best_effort(mutation_id, digest)
                self.wake()
                return operation, plan
        finally:
            if not attached:
                os.close(owned)

    @staticmethod
    def _descriptor_fingerprint(descriptor: int) -> FileFingerprint:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode):
            raise InvalidTask("The File Provider source must be a regular file.")
        if info.st_size < 0 or info.st_size > MAX_LOCAL_UPLOAD_FILE_BYTES:
            raise InvalidTask("The File Provider source exceeds the upload ceiling.")
        return FileFingerprint(
            size_bytes=int(info.st_size),
            mtime_ns=int(info.st_mtime_ns),
            ctime_ns=int(info.st_ctime_ns),
            device_id=int(info.st_dev),
            file_id=int(info.st_ino),
        )

    def _plan_file_provider_descriptor(
        self,
        descriptor: int,
        *,
        path: str,
        expected_size: int | None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> tuple[FileFingerprint, str, tuple[StagedBlock, ...], bool]:
        if is_cancelled is not None and is_cancelled():
            raise InvalidTask("The File Provider write was cancelled before planning.")
        expected = self._descriptor_fingerprint(descriptor)
        if expected_size is not None and expected.size_bytes != expected_size:
            raise SourceDrift("the File Provider source size changed before upload")
        block_size = _adaptive_upload_block_bytes(expected.size_bytes)
        # The native inode is only a different byte source, not a different
        # upload policy. Preserve browser/command extents and use the same
        # bounded CDC layout for newly created or size-changing small text.
        target_sizes = self._target_block_sizes_for_reuse(path, expected.size_bytes)
        rechunk_small_edit = (
            not target_sizes
            and self._target_uses_small_edit_extents(path, expected.size_bytes)
        )
        whole = hashlib.sha256()
        blocks: list[StagedBlock] = []
        offset = 0
        while offset < expected.size_bytes:
            size = (
                target_sizes[len(blocks)]
                if target_sizes
                else min(block_size, expected.size_bytes - offset)
            )
            block = hashlib.sha256()
            consumed = 0
            while consumed < size:
                if is_cancelled is not None and is_cancelled():
                    raise InvalidTask("The File Provider write was cancelled during planning.")
                chunk = os.pread(
                    descriptor,
                    min(FILE_PROVIDER_PLAN_READ_BYTES, size - consumed),
                    offset + consumed,
                )
                if not chunk:
                    del chunk
                    break
                whole.update(chunk)
                block.update(chunk)
                consumed += len(chunk)
                # Do not retain the prior immutable pread result while Python
                # allocates the next one on the right-hand side of assignment.
                # With eight native callbacks this keeps planning payloads at
                # 8 MiB instead of a transient 16 MiB.
                del chunk
            if consumed != size or self._descriptor_fingerprint(descriptor) != expected:
                raise SourceDrift("the File Provider source changed during planning")
            blocks.append(
                StagedBlock(
                    index=len(blocks),
                    offset_bytes=offset,
                    size_bytes=size,
                    sha256=block.hexdigest(),
                )
            )
            offset += size
        if not blocks:
            blocks.append(StagedBlock(0, 0, 0, _EMPTY_SHA256))
        if rechunk_small_edit:
            blocks = list(
                _small_edit_content_defined_blocks(
                    descriptor, expected.size_bytes, is_cancelled=is_cancelled
                )
            )
        if self._descriptor_fingerprint(descriptor) != expected:
            raise SourceDrift("the File Provider source changed after planning")
        return (
            expected,
            whole.hexdigest(),
            tuple(blocks),
            bool(target_sizes or rechunk_small_edit),
        )

    def _attach_file_provider_source(
        self, token: str, descriptor: int, fingerprint: FileFingerprint
    ) -> None:
        replacement = _FileProviderSourceLease(descriptor, fingerprint)
        with self._file_provider_sources_lock:
            previous = self._file_provider_sources.get(token)
            self._file_provider_sources[token] = replacement
        if previous is not None:
            with previous.lock:
                previous.cancelled = True
                os.close(previous.descriptor)

    def release_file_provider_source(self, mutation_id: str) -> None:
        """Detach an unfinished system source after cancellation/disconnect."""

        with self._file_provider_sources_lock:
            lease = self._file_provider_sources.pop(mutation_id, None)
        if lease is not None:
            with lease.lock:
                lease.cancelled = True
                os.close(lease.descriptor)
        self.wake()

    def retain_file_provider_receipts(self, *mutation_ids: str) -> None:
        """Fence acknowledged-operation GC while a native callback waits."""

        with self._file_provider_receipt_holds_lock:
            self._file_provider_receipt_holds.update(mutation_ids)

    def release_file_provider_receipts(self, *mutation_ids: str) -> None:
        """Allow ordinary bounded receipt cleanup after a callback settles."""

        with self._file_provider_receipt_holds_lock:
            self._file_provider_receipt_holds.difference_update(mutation_ids)
        changed = False
        for mutation_id in mutation_ids:
            operation = self.database.get_operation(mutation_id)
            if operation is None or operation.staged_path is None:
                continue
            marker = _file_provider_callback_path(Path(operation.staged_path))
            try:
                marker.unlink()
                changed = True
            except FileNotFoundError:
                pass
        if changed:
            _fsync_dir(self.staging_root)
        self.wake()

    def detach_file_provider_receipts(self, *mutation_ids: str) -> None:
        """Drop process-local callback holds but preserve durable retry fences.

        A cancelled callback or broken response socket did not receive the
        mutation result.  Its exact operation receipt must therefore remain
        addressable for a later File Provider retry, even if this process keeps
        running long enough for acknowledged-stage cleanup to run.
        """

        with self._file_provider_receipt_holds_lock:
            self._file_provider_receipt_holds.difference_update(mutation_ids)
        self.wake()

    def file_provider_compound_replay(
        self,
        operation: PendingOperation,
        *,
        item_identifier: str,
        source_path: str,
    ) -> Mapping[str, Any] | None:
        """Recover the exact stable-ID replay tuple from a native PUT marker."""

        if operation.kind != "put" or operation.staged_path is None:
            return None
        if (
            operation.state == "acked"
            and not self._file_provider_callback_result_is_current(operation)
        ):
            return None
        marker = _file_provider_callback_path(Path(operation.staged_path))
        try:
            encoded, _info = _read_bounded_regular_file(
                marker, FILE_PROVIDER_CALLBACK_MAX_BYTES
            )
            document = json.loads(encoded.decode("utf-8"))
        except (OSError, UnicodeDecodeError, ValueError):
            return None
        if not isinstance(document, Mapping):
            return None
        delete_id = document.get("delete_after_ack_mutation_id")
        deletion = (
            self.database.get_operation(str(delete_id))
            if isinstance(delete_id, str)
            else None
        )
        transfer = self.database.get_local_transfer_intent_by_id(
            operation.mutation_id
        )
        delete_is_durable = (
            deletion is not None
            and deletion.kind == "delete"
            and deletion.path == source_path
            and deletion.mutation_id == delete_id
            and deletion.expected_source_digest
            == document.get("base_content_version")
        ) or (
            transfer is not None
            and transfer.delete_mutation_id == delete_id
            and transfer.delete_after_ack_path == source_path
            and transfer.delete_after_ack_digest
            == document.get("base_content_version")
        )
        if (
            document.get("version") != 1
            or document.get("path") != operation.path
            or document.get("sha256") != operation.staged_digest
            or document.get("size_bytes") != operation.staged_size
            or document.get("item_identifier") != item_identifier
            or document.get("delete_after_ack_path") != source_path
            or not isinstance(document.get("base_content_version"), str)
            or not delete_is_durable
        ):
            return None
        result = dict(document)
        receipted = self.database.get_receipted_entry(operation.path)
        if (
            receipted is not None
            and receipted.mutation_id == operation.mutation_id
            and receipted.entry is not None
        ):
            result["modified_at"] = receipted.entry.modified
        return result

    def _file_provider_receipt_is_held(self, mutation_id: str) -> bool:
        with self._file_provider_receipt_holds_lock:
            return mutation_id in self._file_provider_receipt_holds

    def retain_file_provider_namespace_receipt(self, mutation_id: str) -> None:
        """Register a directory callback before its journal row can publish."""

        with self._file_provider_receipt_holds_lock:
            self._file_provider_namespace_results.setdefault(
                mutation_id, ("pending", None)
            )

    def _complete_file_provider_namespace_receipt(
        self, mutation_id: str, *, error: str | None = None
    ) -> None:
        with self._file_provider_receipt_holds_lock:
            if mutation_id in self._file_provider_namespace_results:
                self._file_provider_namespace_results[mutation_id] = (
                    "conflict" if error is not None else "acked",
                    error,
                )

    def file_provider_namespace_receipt(
        self, mutation_id: str
    ) -> tuple[str, str | None] | None:
        with self._file_provider_receipt_holds_lock:
            return self._file_provider_namespace_results.get(mutation_id)

    def release_file_provider_namespace_receipt(self, mutation_id: str) -> None:
        with self._file_provider_receipt_holds_lock:
            self._file_provider_namespace_results.pop(mutation_id, None)

    def _arm_native_namespace_publish(self, *paths: str) -> str | None:
        """Suppress local echo only when the watcher has a healthy baseline.

        Native mutations own a private inode/namespace lock and persist their
        exact post-state in the local journal. They can therefore proceed
        without echo suppression during recovery. The staging methods still
        acknowledge only their exact paths; overflow and unrelated edits stay
        fenced for the full recovery scan. Remote hydration keeps the strict
        arm_remote_apply rejection unchanged.
        """
        try:
            return self.watch.arm_remote_apply(*paths)
        except RuntimeError:
            if not self.watch.overflow:
                raise
            return None

    def _stage_file_provider_write_locked(
        self,
        path: str,
        *,
        expected_source_digest: str | None,
        delete_after_ack: tuple[str, str] | None,
        publish_local_namespace: Callable[[], None] | None,
        mutation_id: str | None,
        defer_seconds: float | None = None,
    ) -> PendingOperation | None:
        # A mounted write already owns a crash-described private inode. Advance
        # the shared staging ledger before moving it into the visible namespace.
        if not self._advance_staging_repair():
            self.wake()
            raise StagingRepairPending(
                "staging repair is still reconciling preserved local writes"
            )
        apply_token: str | None = None
        if publish_local_namespace is not None:
            armed_paths = [path]
            if delete_after_ack is not None:
                armed_paths.append(delete_after_ack[0])
            apply_token = self._arm_native_namespace_publish(*armed_paths)
        try:
            if publish_local_namespace is not None:
                publish_local_namespace()
            operation = self._stage_local_put_bounded(
                path,
                expected_source_digest=expected_source_digest,
                delete_after_ack=delete_after_ack,
                mutation_id=mutation_id,
                coalesce_pending=mutation_id is None,
            )
            if delete_after_ack is not None:
                source_path, source_digest = delete_after_ack
                self.database.mark_materialized(
                    source_path,
                    state="dirty",
                    clean_digest=source_digest,
                    bytes_on_disk=0,
                )
                self.watch.acknowledge_local_state({source_path: None})
        except BaseException:
            if apply_token is not None:
                self.watch.abort_remote_apply(apply_token)
            raise

        if apply_token is not None:
            published = self.workspace.stat_fingerprint(path)
            if published is None:
                self.watch.abort_remote_apply(apply_token)
                raise StateError("The native write disappeared before journaling.")
            expected: dict[str, FileFingerprint | None] = {path: published}
            if delete_after_ack is not None:
                expected[delete_after_ack[0]] = None
            if not self.watch.commit_remote_apply(apply_token, expected):
                self.logger.record(
                    "fabric_native_write_watcher_reconciliation_required",
                    path=path,
                )
        if operation is not None and defer_seconds is not None and defer_seconds > 0:
            self.database.update_operation(
                operation.mutation_id,
                state="retry",
                error="transport sidecar grace",
                retry_after_seconds=float(defer_seconds),
                reset_failures=True,
                now_ns=self._wall_now_ns(),
            )
        self.wake()
        return operation

    def stage_file_provider_delete(
        self,
        path: str,
        *,
        publish_local_namespace: Callable[[], None],
        retain_file_provider_receipt: bool = False,
    ) -> PendingOperation:
        """Atomically hide and journal one mounted file deletion.

        The path stripe closes the race where an off-loop remote apply could
        republish the just-deleted inode and turn its retire quarantine into a
        new user-visible upload.
        """

        with self._coordinator_lock:
            with self._namespace_lock(path):
                self._cancel_remote_materialization(path)
                apply_token = self._arm_native_namespace_publish(path)
                try:
                    publish_local_namespace()
                    operation = self._stage_delete(path)
                    if retain_file_provider_receipt:
                        self.retain_file_provider_receipts(operation.mutation_id)
                except BaseException:
                    if apply_token is not None:
                        self.watch.abort_remote_apply(apply_token)
                    raise
                if apply_token is not None and not self.watch.commit_remote_apply(apply_token, {path: None}):
                    self.logger.record(
                        "fabric_native_delete_watcher_reconciliation_required",
                        path=path,
                    )
                self.wake()
                return operation

    def _stage_delete(
        self, path: str, *, expected_source_digest: object = _USE_REMOTE_DIGEST
    ) -> PendingOperation:
        self._cancel_remote_materialization(path)
        # A delete observed after a PUT that never crossed the commit fence is
        # the user's latest intent, not work that should wait behind a staged
        # upload.  This matters especially for authoritative quota rejection:
        # the PUT is intentionally parked so a different-path delete can free
        # space, but deleting the rejected file itself must cancel its staged
        # bytes immediately.  Never supersede a commit-unknown PUT; its remote
        # outcome must be read back before a tombstone can be ordered safely.
        for pending in self.database.list_nonterminal_source_operations(path):
            if pending.kind == "put" and not pending.commit_unknown:
                self.database.supersede_operation(
                    pending.mutation_id,
                    reason="unpublished local put superseded by local delete",
                )
                self._discard_prefetched_write_tickets(
                    pending.mutation_id, reason="delete_superseded"
                )
        head = self.database.get_remote_manifest_head()
        remote = self._remote_entry_for_write(path)
        materialized = self.database.get_materialized(path)
        if expected_source_digest is _USE_REMOTE_DIGEST:
            expected_digest = (
                remote.digest
                if remote is not None
                else (
                    materialized.clean_digest
                    if materialized is not None and materialized.state == "clean"
                    else None
                )
            )
        else:
            expected_digest = expected_source_digest
        if expected_digest is not None and not _digest(expected_digest):
            raise StateError("The staged delete expected digest is invalid.")
        base_generation, base_digest = _head_fields(head)
        operation = self.database.enqueue_delete(
            path,
            base_generation=base_generation,
            base_digest=base_digest,
            expected_source_digest=str(expected_digest) if expected_digest else None,
        )
        self.database.mark_materialized(
            path,
            state="dirty",
            clean_digest=(
                materialized.clean_digest
                if materialized is not None
                else (remote.digest if remote else None)
            ),
            bytes_on_disk=0,
        )
        self.watch.acknowledge_local_state({path: None})
        return operation

    def _copy_stable_stage(
        self,
        path: str,
        destination: Path,
        *,
        delete_after_ack: tuple[str, str] | None = None,
    ) -> StagePlan:
        fingerprint = self.workspace.stat_fingerprint(path)
        if fingerprint is None:
            raise InvalidTask("The local file disappeared before it could be staged.")
        if fingerprint.size_bytes > MAX_SYNC_FILE_BYTES:
            raise InvalidTask(
                "Fabric sync supports at most 32 GiB per file (8,192 fixed 4 MiB blocks)."
            )
        self._reserve_classic_stage(destination, fingerprint.size_bytes)
        temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
        output_fd = -1
        published = False
        blocks: list[StagedBlock] = []
        target_sizes = self._target_block_sizes_for_reuse(
            path, fingerprint.size_bytes, max_block_bytes=BLOCK_BYTES
        )
        rechunk_small_edit = (
            not target_sizes
            and self._target_uses_small_edit_extents(path, fingerprint.size_bytes)
        )
        try:
            output_fd = os.open(
                str(temporary),
                os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0),
                0o600,
            )
            def record_block(chunk: bytes, offset: int) -> None:
                blocks.append(
                    StagedBlock(
                        len(blocks), offset, len(chunk), hashlib.sha256(chunk).hexdigest()
                    )
                )

            hashed = self.workspace.copy_regular_file_to_descriptor(
                path,
                output_fd,
                max_bytes=MAX_SYNC_FILE_BYTES,
                chunk_bytes=BLOCK_BYTES,
                on_chunk=record_block,
                chunk_sizes=target_sizes or None,
            )
            if hashed is None:
                raise InvalidTask("The local file disappeared before it could be staged.")
            if len(blocks) > MAX_MANIFEST_BLOCKS:
                raise InvalidTask("The local file exceeds MeshiaFabric's block limit.")
            if rechunk_small_edit:
                blocks = list(
                    _small_edit_content_defined_blocks(
                        output_fd, hashed.fingerprint.size_bytes
                    )
                )
            if hashed.fingerprint.size_bytes == 0:
                blocks.append(StagedBlock(0, 0, 0, _EMPTY_SHA256))
            os.fsync(output_fd)
            os.close(output_fd)
            output_fd = -1
            os.chmod(temporary, 0o600)
            os.replace(temporary, destination)
            published = True
            _fsync_dir(self.staging_root)
            self._record_classic_stage_committed(destination)
        finally:
            if output_fd >= 0:
                os.close(output_fd)
            if not published:
                try:
                    temporary.unlink()
                except OSError:
                    pass
                self._release_classic_stage(destination)
        return StagePlan(
            path=path,
            size_bytes=hashed.fingerprint.size_bytes,
            sha256=hashed.sha256,
            source_fingerprint=_fingerprint_text(hashed.fingerprint),
            blocks=tuple(blocks),
            delete_after_ack_path=(delete_after_ack[0] if delete_after_ack else None),
            delete_after_ack_digest=(delete_after_ack[1] if delete_after_ack else None),
        )

    def _target_block_sizes_for_reuse(
        self,
        path: str,
        size_bytes: int,
        *,
        max_block_bytes: int = MAX_CAS_BLOCK_BYTES,
    ) -> tuple[int, ...]:
        """Return exact reusable connected-host boundaries for a same-size PUT."""

        entry = self.database.get_remote_entry(path)
        if (
            entry is None
            or size_bytes == 0
            or entry.size_bytes != size_bytes
            or not _complete_object_cas_layout(entry)
            or not isinstance(entry.blocks, Mapping)
            or len(entry.blocks["blocks"]) > MAX_MANIFEST_BLOCKS
            or any(
                int(block["size_bytes"]) > max_block_bytes
                for block in entry.blocks["blocks"]
            )
            or entry.blocks["storage"].get("kind")
            != CONNECTED_HOST_OBJECT_CAS_KIND
        ):
            return ()
        return tuple(int(block["size_bytes"]) for block in entry.blocks["blocks"])

    def _target_uses_small_edit_extents(
        self, path: str, replacement_size_bytes: int
    ) -> bool:
        """Use fine extents for new small text or preserve an existing CDC layout."""

        entry = self.database.get_remote_entry(path)
        if entry is None:
            return is_small_text_file(path, replacement_size_bytes)
        if (
            replacement_size_bytes <= 0
            or entry.size_bytes == replacement_size_bytes
            or entry.size_bytes > SMALL_EDIT_CDC_FILE_MAX_BYTES
            or replacement_size_bytes > SMALL_EDIT_CDC_FILE_MAX_BYTES
            or not _complete_object_cas_layout(entry)
            or not isinstance(entry.blocks, Mapping)
            or entry.blocks["storage"].get("kind")
            != CONNECTED_HOST_OBJECT_CAS_KIND
        ):
            return False
        blocks = entry.blocks["blocks"]
        return bool(
            len(blocks) > 1
            and all(
                0 < int(block["size_bytes"]) <= SMALL_EDIT_CDC_MAX_BYTES
                for block in blocks
            )
        )

    def _assert_staging_capacity(self, incoming_bytes: int) -> None:
        staged_bytes = 0
        staged_files = 0
        try:
            with os.scandir(self.staging_root) as entries:
                for item in entries:
                    if not item.name.endswith(".data") or not item.is_file(follow_symlinks=False):
                        continue
                    staged_files += 1
                    if staged_files > MAX_REMOTE_FILES:
                        raise StateError("The Fabric staging area has too many durable stages.")
                    staged_bytes += item.stat(follow_symlinks=False).st_size
        except OSError as error:
            raise StateError("The Fabric staging area cannot be measured safely.") from error
        try:
            _transfer_count, transfer_reserved = (
                self._transfer_store._active_reservations()
            )
        except (OSError, TransferError) as error:
            raise StateError("The Fabric transfer reservation cannot be measured safely.") from error
        total_reserved = min(
            self.max_staging_bytes, staged_bytes + transfer_reserved
        )
        if incoming_bytes > self.max_staging_bytes - total_reserved:
            raise StagingQuotaExceeded(
                "The local edit exceeds the bounded Fabric staging budget."
            )
        usage = self._disk_usage(self.staging_root)
        reserve = max(
            self.min_staging_free_bytes,
            int(int(usage.total) * self.min_staging_free_fraction),
        )
        if incoming_bytes > max(0, int(usage.free) - reserve):
            raise StagingQuotaExceeded(
                "Fabric staging would violate the local disk free-space reserve."
            )

    def _assert_remote_destination_capacity(
        self, incoming_bytes: int, *, replacing_path: str | None = None
    ) -> None:
        """Preflight the visible workspace volume independently of staging.

        Atomic replacement writes a complete destination temporary while the
        old visible file and private stage still exist. Calling this both
        before hydration and immediately before publication classifies local
        staging and destination-volume pressure as retryable resource state,
        including the two-copy high-water mark when both roots share a volume.
        """

        policy = self.cache_policy(fresh=True)
        if policy.enforced:
            # The limit is a CACHE TARGET, not a per-file cap. Reclaim toward
            # the room this write needs; a file larger than the whole limit
            # drives the target to zero, reclaims everything reclaimable, and
            # then proceeds. The device free-space reserve below is the only
            # hard stop, because refusing a read of durable content while
            # reclaimable space exists is never the right answer -- and a
            # 30 GB file must be able to land on a disk with room for it even
            # though no sane cache budget is 30 GB.
            configured_usage = self._configured_materialized_usage(replacing_path)
            target_usage = max(0, policy.limit_bytes - incoming_bytes)
            freed = 0
            if configured_usage > target_usage:
                # Finish any wave a previous tick started before opening a new
                # one: an eviction that unlinked the visible name but could not
                # yet prove the inode unreferenced holds a durable intent, and
                # that pending intent also gates every later wave.
                freed = self._recover_evictions()
                if self._reclaim_mount_retained_quarantine():
                    freed += self._recover_evictions()
                freed += self._evict_materialized_working_set(
                    policy=policy,
                    bytes_needed=max(
                        0, configured_usage - target_usage - freed
                    ),
                    exclude_path=replacing_path,
                )
                configured_usage = self._configured_materialized_usage(
                    replacing_path
                )
        # Reuse the sample the policy above already took: two statvfs per
        # hydration is 160,000 syscalls across an 80k-file folder for no
        # additional truth. ``_volume_snapshot`` validated it; a rejected
        # sample falls back to the raw read so the invalid-capacity guard below
        # still fires.
        measured = self._volume_snapshot()
        if measured is not None:
            total, free = measured
        else:
            usage = self._disk_usage(self.workspace.root)
            total = int(usage.total)
            free = int(usage.free)
        if total < 0 or free < 0 or free > total:
            raise StateError("The workspace disk capacity is invalid.")
        reserve = max(
            self.min_staging_free_bytes,
            int(total * self.min_staging_free_fraction),
        )
        if incoming_bytes > max(0, free - reserve):
            self.logger.record(
                "fabric_materialized_budget_exhausted",
                path=replacing_path,
                tier=policy.tier,
                incoming_bytes=incoming_bytes,
                usage_bytes=self._materialized_storage_bytes(),
                budget_bytes=policy.limit_bytes,
                free_bytes=free,
                reserve_bytes=reserve,
            )
            raise StagingQuotaExceeded(
                "This device does not have room for the file even after "
                "reclaiming every re-fetchable local copy. Free space on the "
                f"disk, or set {MAX_MATERIALIZED_BYTES_ENV} to pin a smaller "
                "Meshia cache."
            )

    # ------------------------------------------------ dynamic cache policy

    def _volume_snapshot(self, *, fresh: bool = False) -> tuple[int, int] | None:
        """Return ``(total, free)`` for the workspace volume.

        Admission always asks for a fresh sample: a budget decided from a stale
        free-space reading is exactly the failure this policy exists to
        prevent, and one statvfs is cheap next to a materialization. The short
        TTL only spares the background maintenance lane a syscall per tick.
        """

        now = float(self._clock())
        if not fresh and now < self._volume_sample_expires:
            return self._volume_sample
        self._volume_sample = _measured_volume_bytes(
            self._disk_usage, self.workspace.root
        )
        self._volume_sample_expires = now + VOLUME_SAMPLE_TTL_SECONDS
        return self._volume_sample

    def _resolve_cache_policy(
        self, *, fresh: bool = False
    ) -> MaterializedCachePolicy:
        """Decide the cache policy for right now, pinned or dynamic."""

        pinned = self._pinned_materialized_bytes
        if pinned is not None:
            # A pinned budget is a deliberate override: no tiering, no
            # free-space scaling. Zero keeps its historical meaning of "do not
            # enforce a cache bound at all".
            return MaterializedCachePolicy(
                tier="pinned",
                limit_bytes=pinned,
                low_water_bytes=pinned,
                idle_evict_seconds=None,
                maintenance_interval_seconds=60.0,
                auto_materialization_bytes=min(
                    pinned, DEFAULT_MAX_AUTO_MATERIALIZED_BYTES
                ),
                enforced=pinned > 0,
            )
        measured = self._volume_snapshot(fresh=fresh)
        if measured is None:
            # The volume cannot be measured. Fall back to the fixed floor
            # rather than to "unbounded"; an unmeasurable disk is not licence
            # to fill it.
            return MaterializedCachePolicy(
                tier="unmeasured",
                limit_bytes=DEFAULT_MAX_MATERIALIZED_BYTES,
                low_water_bytes=DEFAULT_MAX_MATERIALIZED_BYTES,
                idle_evict_seconds=None,
                maintenance_interval_seconds=300.0,
                auto_materialization_bytes=DEFAULT_MAX_AUTO_MATERIALIZED_BYTES,
            )
        total, free = measured
        if total < MIN_TIERED_VOLUME_BYTES:
            limit = _default_max_materialized_bytes(total, free)
            return MaterializedCachePolicy(
                tier="untiered",
                limit_bytes=limit,
                low_water_bytes=limit,
                idle_evict_seconds=None,
                maintenance_interval_seconds=300.0,
                auto_materialization_bytes=min(
                    limit, DEFAULT_MAX_AUTO_MATERIALIZED_BYTES
                ),
            )
        tier = _next_materialized_tier(self._materialized_tier, free)
        if tier != self._materialized_tier:
            previous = self._materialized_tier
            self._materialized_tier = tier
            if previous is not None:
                self.logger.record(
                    "fabric_cache_tier_changed",
                    previous=previous,
                    tier=tier,
                    free_bytes=free,
                    total_bytes=total,
                )
        return _materialized_cache_policy(tier, total_bytes=total, free_bytes=free)

    def cache_policy(self, *, fresh: bool = False) -> MaterializedCachePolicy:
        """The cache policy in force, refreshed against current free space."""

        self._cache_policy = self._resolve_cache_policy(fresh=fresh)
        return self._cache_policy

    @property
    def max_materialized_bytes(self) -> int:
        """The cache limit in force right now (pinned constant or dynamic)."""

        return self.cache_policy().limit_bytes

    @max_materialized_bytes.setter
    def max_materialized_bytes(self, value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("max_materialized_bytes must be a non-negative integer")
        # Assigning pins the budget, exactly as passing it to the constructor
        # would: a caller naming an exact number wants that number, not a
        # free-space estimate.
        self._pinned_materialized_bytes = value
        self._cache_policy = self._resolve_cache_policy()

    @property
    def max_auto_materialized_bytes(self) -> int:
        """Ceiling on AUTOMATIC (prefetch) selection, tier-aware.

        Separate from the cache limit on purpose. A generous cache ceiling must
        not turn attach into an eager whole-workspace download, and under real
        disk pressure Meshia stops speculating entirely while an explicit read
        is still always served.
        """

        if self._pinned_auto_materialized_bytes is not None:
            return self._pinned_auto_materialized_bytes
        return self.cache_policy().auto_materialization_bytes

    @max_auto_materialized_bytes.setter
    def max_auto_materialized_bytes(self, value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(
                "max_auto_materialized_bytes must be a non-negative integer"
            )
        self._pinned_auto_materialized_bytes = value

    @property
    def materialized_cache_tier(self) -> str:
        policy = self._cache_policy
        return policy.tier if policy is not None else "unmeasured"

    def note_materialized_access(self, path: str) -> None:
        """Record that ``path`` was opened, for last-ACCESS eviction ordering.

        Called from mount threads on every open, so it must never touch the
        database or block: it coalesces into a bounded in-memory map that the
        poll flushes. Before this existed ``accessed_at_ns`` was only ever
        written by ``mark_materialized``, which made the "LRU" ordering a
        last-WRITE ordering -- reading a file forever did not protect it, and
        writing one once did.
        """

        with self._access_touch_lock:
            if (
                len(self._access_touches) >= MAX_PENDING_ACCESS_TOUCHES
                and path not in self._access_touches
            ):
                # Bounded: drop the oldest observation rather than grow without
                # limit. A missed touch costs eviction accuracy, never safety.
                self._access_touches.pop(next(iter(self._access_touches)), None)
            self._access_touches[path] = self._wall_now_ns()

    def _flush_access_touches(self) -> int:
        with self._access_touch_lock:
            if not self._access_touches:
                return 0
            pending = self._access_touches
            self._access_touches = {}
        touched = 0
        for path, stamp in pending.items():
            try:
                if self.database.touch_materialized(path, accessed_at_ns=stamp):
                    touched += 1
            except (StateError, ValueError):
                # A path that left the working set between the open and this
                # flush simply has nothing to stamp.
                continue
        return touched

    def _configured_materialized_usage(self, replacing_path: str | None) -> int:
        """Usage charged against the cache budget for one candidate write."""

        usage = self._materialized_storage_bytes()
        if replacing_path is not None:
            current = self.database.get_materialized(replacing_path)
            if current is not None and current.bytes_on_disk > 0:
                usage = max(
                    0, usage - current.bytes_on_disk
                ) + self.workspace.allocated_file_bytes(replacing_path)
        return usage

    def _materialized_storage_bytes(self) -> int:
        """Return visible cache plus additional hidden logical policy bytes.

        The database row continues to own a hidden eviction preimage, so that
        owner class is not added twice. Overwrite/delete survivors have no live
        materialized row and are charged by logical length even when sparse;
        actual allocated blocks remain separately bounded by filesystem free.
        """

        retained = self.workspace.retained_storage_usage()
        return (
            self.database.materialized_bytes()
            + retained.additional_logical_bytes
        )

    def _observe_clean_file_without_rehash(
        self,
        path: str,
        *,
        content_sha256: str | None,
        stat_fingerprint: str | None,
    ) -> HashedRegularFile | None:
        """Reuse a durable digest while its exact clean stat tuple still owns path."""

        current = self.workspace.stat_fingerprint(path)
        if current is None:
            return None
        if stat_fingerprint is not None:
            try:
                expected = _fingerprint_from_text(stat_fingerprint)
            except (StateError, ValueError):
                expected = None
            if current == expected and content_sha256 is not None:
                return HashedRegularFile(current, content_sha256)
        return self.workspace.hash_regular_file(path)

    def _transfer_quota_hook(
        self, phase: str, additional_bytes: int, transfer_reserved: int
    ) -> None:
        """Include classic operation stages in TransferStore admission."""

        if phase != "reserve":
            return
        staged_bytes = 0
        try:
            with os.scandir(self.staging_root) as entries:
                for item in entries:
                    if item.name.endswith(".data") and item.is_file(
                        follow_symlinks=False
                    ):
                        staged_bytes += item.stat(follow_symlinks=False).st_size
                        if staged_bytes > self.max_staging_bytes:
                            break
        except OSError as error:
            raise StagingQuotaExceeded(
                "the existing Fabric staging area cannot be measured"
            ) from error
        if (
            staged_bytes + transfer_reserved + additional_bytes
            > self.max_staging_bytes
        ):
            raise StagingQuotaExceeded(
                "combined Fabric operation and transfer stages exceed the configured budget"
            )

    # ------------------------------------------------------ conflict recovery

    def _advance_one_conflict_resolution(self) -> tuple[bool, bool]:
        """Advance at most one active-authority resolution phase.

        The result is ``(did_work, used_signed_control)``.  A durable successor
        or remote-apply intent is deliberately driven by the ordinary mutation
        and apply lanes on later turns; this method never creates a second send
        or namespace engine.
        """

        resolutions = self.database.list_conflict_resolutions_for_work(limit=1)
        if not resolutions:
            return False, False
        resolution = resolutions[0]
        view = self.database.get_conflict_view(resolution.anchor_conflict_id)
        if view is None or view.resolution is None:
            return self._block_conflict_resolution(
                resolution, "the active conflict anchor is unavailable"
            ), False
        if view.resolution.resolution_id != resolution.resolution_id:
            return self._block_conflict_resolution(
                resolution, "the conflict group is owned by another resolution"
            ), False
        if view.operation is not None and view.operation.kind == "rename":
            operation = view.operation
            if (
                resolution.decision == "keep_remote"
                and operation.directory_rename
                and operation.state == "conflict"
                and not operation.commit_unknown
                and operation.request_digest is None
            ):
                self.database.complete_unsent_directory_rename_keep_remote(
                    resolution.resolution_id
                )
                self.logger.record(
                    "fabric_unsent_directory_rename_keep_remote_completed",
                    resolution_id=resolution.resolution_id,
                    conflict_id=resolution.anchor_conflict_id,
                    mutation_id=operation.mutation_id,
                )
                return True, False
            return self._block_conflict_resolution(
                resolution,
                "rename conflict recovery requires endpoint evidence that this client does not have",
            ), False
        if view.operation is not None and view.operation.kind not in ("put", "delete"):
            return self._block_conflict_resolution(
                resolution, "the linked conflict operation shape is unsupported"
            ), False

        retry_safe = False
        try:
            if resolution.phase == "blocked":
                if resolution.retry_requested_at_ns is None:
                    return False, False
                load = self.database.get_remote_manifest_load()
                if resolution.resolution_id not in self._conflict_resolution_refreshes:
                    self.refresh_remote(force_full=load is None)
                    if self.database.get_remote_manifest_load() is None:
                        self._conflict_resolution_refreshes.add(
                            resolution.resolution_id
                        )
                    return True, True
                fingerprint = self.workspace.stat_fingerprint(view.conflict.path)
                local_digest: str | None = None
                local_fingerprint: str | None = None
                materialized_fingerprint: str | None = None
                local_bytes = 0
                if fingerprint is not None:
                    materialized_fingerprint = _fingerprint_text(fingerprint)
                    local_bytes = fingerprint.size_bytes
                    if fingerprint.size_bytes > MAX_SYNC_FILE_BYTES:
                        local_fingerprint = materialized_fingerprint
                    else:
                        local = self._hash_regular_file(view.conflict.path)
                        if local is None:
                            raise StateError(
                                "the local path disappeared during retry rebase"
                            )
                        local_digest = local.sha256
                remote = self.database.get_remote_entry(view.conflict.path)
                if resolution.retry_safe:
                    self.database.rebase_blocked_conflict_resolution(
                        resolution.resolution_id,
                        expected_local_digest=local_digest,
                        expected_local_fingerprint=local_fingerprint,
                        materialized_fingerprint=materialized_fingerprint,
                        local_bytes=local_bytes,
                        expected_remote_digest=(
                            remote.digest if remote is not None else None
                        ),
                        expected_remote_generation=self._remote_generation(),
                    )
                else:
                    # A keep-both collision may be an unrelated occupant, which
                    # is safe to leave untouched. Exact staged bytes at the
                    # sibling are ambiguous: this client might already have
                    # published them before the block, so abandoning would hide
                    # a live effect behind a fresh decision. Fail closed.
                    if resolution.survivor_path is not None:
                        survivor = self._hash_regular_file(
                            resolution.survivor_path
                        )
                        if (
                            survivor is not None
                            and survivor.sha256 == resolution.staged_digest
                        ):
                            raise StateError(
                                "the keep-both sibling may already contain the "
                                "resolution bytes"
                            )
                    self.database.abandon_blocked_conflict_resolution(
                        resolution.resolution_id,
                        expected_local_digest=local_digest,
                        expected_local_fingerprint=local_fingerprint,
                        materialized_fingerprint=materialized_fingerprint,
                        local_bytes=local_bytes,
                        expected_remote_digest=(
                            remote.digest if remote is not None else None
                        ),
                        expected_remote_generation=self._remote_generation(),
                    )
                    self.watch.acknowledge_local_state(
                        {view.conflict.path: fingerprint}
                    )
                    self._conflict_resolution_refreshes.discard(
                        resolution.resolution_id
                    )
                return True, False

            if resolution.phase == "requested":
                load = self.database.get_remote_manifest_load()
                if resolution.resolution_id not in self._conflict_resolution_refreshes:
                    self.refresh_remote(force_full=load is None)
                    if self.database.get_remote_manifest_load() is None:
                        self._conflict_resolution_refreshes.add(
                            resolution.resolution_id
                        )
                    return True, True
                retry_safe = True
                self._require_resolution_remote_precondition(view, resolution)
                local = self._require_resolution_local_precondition(view, resolution)
                return self._prepare_conflict_resolution(view, resolution, local), False

            if resolution.phase == "prepared":
                retry_safe = True
                self._require_resolution_remote_precondition(view, resolution)
                local = self._require_resolution_local_precondition(view, resolution)
                retry_safe = False
                if resolution.decision == "keep_remote":
                    self._authorize_resolution_remote_apply(
                        view, resolution, local, expected_phase="prepared"
                    )
                    return True, False
                if isinstance(local, FileFingerprint):
                    raise StateError(
                        "protocol-oversize local bytes cannot be uploaded"
                    )
                return self._publish_resolution_successor(
                    view, resolution, local
                ), False

            if resolution.phase == "waiting_successor":
                successor_id = resolution.successor_mutation_id
                if successor_id is None:
                    raise StateError("the resolution lost its successor mutation ID")
                successor = self.database.get_operation(successor_id)
                receipt = self.database.get_receipt(successor_id)
                if successor is not None and successor.state == "conflict":
                    raise StateError("the resolution successor encountered a new conflict")
                if receipt is None:
                    return False, False
                if resolution.decision == "keep_local":
                    self.database.complete_conflict_resolution(
                        resolution.resolution_id
                    )
                else:
                    local = self._require_resolution_local_precondition(
                        view, resolution
                    )
                    self._require_resolution_remote_precondition(view, resolution)
                    self._authorize_resolution_remote_apply(
                        view,
                        resolution,
                        local,
                        expected_phase="waiting_successor",
                    )
                return True, False

            if resolution.phase == "applying_remote":
                try:
                    self.database.complete_conflict_resolution(
                        resolution.resolution_id
                    )
                    return True, False
                except StateError as proof_error:
                    self._require_resolution_remote_precondition(view, resolution)
                    if self.database.has_remote_apply_intent(view.conflict.path):
                        self._queue_remote_applies((view.conflict.path,))
                        return False, False
                    raise StateError(
                        "remote apply ended without the exact materialization proof: "
                        f"{proof_error}"
                    ) from proof_error
        except (InvalidTask, StateError, UnsafePath, ValueError) as error:
            return self._block_conflict_resolution(
                resolution, str(error), retry_safe=retry_safe
            ), False
        raise StateError("The conflict resolution has an unknown runnable phase.")

    def _block_conflict_resolution(
        self,
        resolution: ConflictResolution,
        reason: str,
        *,
        retry_safe: bool = False,
    ) -> bool:
        updated = self.database.transition_conflict_resolution(
            resolution.resolution_id,
            expected_phase=resolution.phase,
            phase="blocked",
            last_error=reason[:8_000],
            retry_safe=retry_safe,
        )
        if updated is not None:
            self._conflict_resolution_refreshes.discard(
                resolution.resolution_id
            )
            self.logger.record(
                "fabric_conflict_resolution_blocked",
                resolution_id=resolution.resolution_id,
                conflict_id=resolution.anchor_conflict_id,
                decision=resolution.decision,
                error=reason,
            )
        return updated is not None

    def _require_resolution_remote_precondition(
        self, view: ConflictView, resolution: ConflictResolution
    ) -> RemoteEntry | None:
        remote = self.database.get_remote_entry(view.conflict.path)
        observed = remote.digest if remote is not None else None
        if observed != resolution.expected_remote_digest:
            raise StateError("the accepted remote conflict state advanced")
        return remote

    def _require_resolution_local_precondition(
        self, view: ConflictView, resolution: ConflictResolution
    ) -> HashedRegularFile | FileFingerprint | None:
        if resolution.expected_local_fingerprint is not None:
            local_fingerprint = self.workspace.stat_fingerprint(view.conflict.path)
            if (
                local_fingerprint is None
                or _fingerprint_text(local_fingerprint)
                != resolution.expected_local_fingerprint
            ):
                raise StateError("the protocol-oversize local identity advanced")
            return local_fingerprint
        local = self._hash_regular_file(view.conflict.path)
        if resolution.expected_local_digest is None:
            if local is not None:
                raise StateError("the local path advanced from known absence")
            return None
        if local is None or local.sha256 != resolution.expected_local_digest:
            raise StateError("the local conflict bytes advanced")
        return local

    def _prepare_conflict_resolution(
        self,
        view: ConflictView,
        resolution: ConflictResolution,
        local: HashedRegularFile | FileFingerprint | None,
    ) -> bool:
        if resolution.decision == "keep_both" and not isinstance(
            local, HashedRegularFile
        ):
            raise StateError("keep-both requires exact local bytes")
        stage: Path | None = None
        survivor: str | None = None
        if resolution.decision == "keep_both":
            survivor = self._select_keep_both_path(view, resolution)
        if resolution.decision in ("keep_local", "keep_both") and isinstance(
            local, HashedRegularFile
        ):
            if resolution.successor_mutation_id is None:
                raise StateError("the resolution lost its successor mutation ID")
            stage = self.staging_root / f"{resolution.successor_mutation_id}.data"
        updated = self.database.transition_conflict_resolution(
            resolution.resolution_id,
            expected_phase="requested",
            phase="prepared",
            staged_path=stage,
            staged_digest=(
                local.sha256
                if stage is not None and isinstance(local, HashedRegularFile)
                else None
            ),
            staged_size=(
                local.fingerprint.size_bytes
                if stage is not None and isinstance(local, HashedRegularFile)
                else None
            ),
            survivor_path=survivor,
        )
        if updated is not None:
            self._conflict_resolution_refreshes.discard(
                resolution.resolution_id
            )
        return updated is not None

    def _prepare_resolution_stage(
        self,
        view: ConflictView,
        resolution: ConflictResolution,
        local: HashedRegularFile,
        *,
        target_path: str,
    ) -> tuple[Path, StagePlan]:
        mutation_id = resolution.successor_mutation_id
        if mutation_id is None:
            raise StateError("the resolution lost its preallocated successor ID")
        stage = self.staging_root / f"{mutation_id}.data"
        self._reserve_classic_stage(stage, local.fingerprint.size_bytes)
        if not stage.exists():
            temporary = stage.with_name(
                f".{stage.name}.{uuid.uuid4().hex}.tmp"
            )
            descriptor = -1
            published = False
            try:
                descriptor = os.open(
                    str(temporary),
                    os.O_WRONLY
                    | os.O_CREAT
                    | os.O_EXCL
                    | getattr(os, "O_BINARY", 0)
                    | getattr(os, "O_NOFOLLOW", 0),
                    0o600,
                )
                staged_path = (
                    view.conflict.staged_path
                    or (view.operation.staged_path if view.operation is not None else None)
                )
                copied = copy_active_conflict_local_to_descriptor(
                    self.workspace,
                    view.conflict.path,
                    descriptor,
                    staging_root=self.staging_root,
                    staged_path=staged_path,
                    expected_sha256=local.sha256,
                    expected_size=local.fingerprint.size_bytes,
                    max_bytes=MAX_SYNC_FILE_BYTES,
                    chunk_bytes=BLOCK_BYTES,
                )
                if copied.sha256 != local.sha256:
                    raise InvalidTask("the copied conflict stage changed digest")
                os.fsync(descriptor)
                os.close(descriptor)
                descriptor = -1
                os.replace(temporary, stage)
                published = True
                _fsync_dir(self.staging_root)
                self._record_classic_stage_committed(stage)
            finally:
                if descriptor >= 0:
                    os.close(descriptor)
                if not published:
                    try:
                        temporary.unlink()
                    except OSError:
                        pass
                    if not stage.exists():
                        self._release_classic_stage(stage)
        plan = self._resolution_stage_plan(
            stage,
            path=target_path,
            expected_digest=local.sha256,
            expected_size=local.fingerprint.size_bytes,
            source_fingerprint=_fingerprint_text(local.fingerprint),
        )
        _write_json(_plan_path(stage), _plan_document(plan))
        return stage, plan

    def _resolution_stage_plan(
        self,
        stage: Path,
        *,
        path: str,
        expected_digest: str,
        expected_size: int,
        source_fingerprint: str,
    ) -> StagePlan:
        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(str(stage), flags)
        blocks: list[StagedBlock] = []
        whole = hashlib.sha256()
        try:
            before = os.fstat(descriptor)
            if (
                not stat.S_ISREG(before.st_mode)
                or before.st_nlink != 1
                or before.st_size != expected_size
            ):
                raise InvalidTask("the resolution stage is not the expected private file")
            offset = 0
            while offset < expected_size:
                data = _read_up_to(descriptor, min(BLOCK_BYTES, expected_size - offset))
                if not data:
                    raise InvalidTask("the resolution stage was truncated")
                whole.update(data)
                blocks.append(
                    StagedBlock(
                        len(blocks),
                        offset,
                        len(data),
                        hashlib.sha256(data).hexdigest(),
                    )
                )
                offset += len(data)
            if expected_size == 0:
                blocks.append(StagedBlock(0, 0, 0, _EMPTY_SHA256))
            after = os.fstat(descriptor)
            if (
                before.st_dev != after.st_dev
                or before.st_ino != after.st_ino
                or before.st_size != after.st_size
                or before.st_mtime_ns != after.st_mtime_ns
                or before.st_ctime_ns != after.st_ctime_ns
                or whole.hexdigest() != expected_digest
            ):
                raise InvalidTask("the resolution stage changed during verification")
        finally:
            os.close(descriptor)
        return StagePlan(
            path=path,
            size_bytes=expected_size,
            sha256=expected_digest,
            source_fingerprint=source_fingerprint,
            blocks=tuple(blocks),
        )

    def _select_keep_both_path(
        self, view: ConflictView, resolution: ConflictResolution
    ) -> str:
        for candidate in range(CONFLICT_RECOVERY_CANDIDATE_LIMIT):
            path = keep_both_candidate_path(
                view.conflict.path,
                view.conflict.conflict_id,
                resolution.resolution_id,
                candidate=candidate,
            )
            if (
                self.workspace.stat_fingerprint(path) is None
                and self.database.get_remote_entry(path) is None
                and self.database.get_latest_nonterminal_operation(path) is None
            ):
                return path
        raise StateError("no collision-free keep-both sibling is available")

    def _publish_resolution_successor(
        self,
        view: ConflictView,
        resolution: ConflictResolution,
        local: HashedRegularFile | None,
    ) -> bool:
        successor_id = resolution.successor_mutation_id
        if successor_id is None:
            raise StateError("the resolution lost its successor mutation ID")
        existing = self.database.get_operation(successor_id)
        target = (
            resolution.survivor_path
            if resolution.decision == "keep_both"
            else view.conflict.path
        )
        if target is None:
            raise StateError("keep-both lost its durable sibling path")
        plan: StagePlan | None = None
        if local is not None:
            if (
                resolution.staged_path is None
                or resolution.staged_digest != local.sha256
                or resolution.staged_size != local.fingerprint.size_bytes
            ):
                raise StateError("the resolution lost its immutable local stage")
            stage, plan = self._prepare_resolution_stage(
                view,
                resolution,
                local,
                target_path=target,
            )
            if stage.resolve(strict=False) != Path(
                resolution.staged_path
            ).resolve(strict=False):
                raise StateError("the resolution stage path changed")

        if resolution.decision == "keep_both":
            assert local is not None and plan is not None
            survivor = self._hash_regular_file(target)
            if survivor is None:
                token = self.watch.arm_remote_apply(target)
                resolved = False
                try:
                    self.workspace.write_stream(
                        target,
                        self._classic_stage_chunks(Path(resolution.staged_path), plan),
                        expected_size=plan.size_bytes,
                        expected_sha256=f"sha256:{plan.sha256}",
                        overwrite=False,
                    )
                    survivor = self._hash_regular_file(target)
                    if survivor is None or survivor.sha256 != plan.sha256:
                        raise StateError("the keep-both sibling failed publication proof")
                    resolved = self.watch.commit_remote_apply(token, {target: survivor})
                    if not resolved:
                        self._startup_reconcile = True
                finally:
                    if not resolved:
                        self.watch.abort_remote_apply(token)
            elif survivor.sha256 != plan.sha256:
                raise StateError("the keep-both sibling path was occupied")
            local = survivor
            plan = StagePlan(
                path=plan.path,
                size_bytes=plan.size_bytes,
                sha256=plan.sha256,
                source_fingerprint=_fingerprint_text(survivor.fingerprint),
                blocks=plan.blocks,
            )
            _write_json(
                _plan_path(Path(resolution.staged_path)),
                _plan_document(plan),
            )

        path_owner = self.database.get_latest_nonterminal_operation(target)
        if (
            path_owner is not None
            and path_owner.mutation_id != successor_id
        ):
            raise StateError(
                "another pending mutation owns the resolution target path"
            )
        if existing is None:
            head = self.database.get_remote_manifest_head()
            base_generation, base_digest = _head_fields(head)
            if local is None:
                existing = self.database.enqueue_delete(
                    target,
                    mutation_id=successor_id,
                    base_generation=base_generation,
                    base_digest=base_digest,
                    expected_source_digest=resolution.expected_remote_digest,
                )
            else:
                assert plan is not None and resolution.staged_path is not None
                existing = self.database.enqueue_put(
                    target,
                    mutation_id=successor_id,
                    base_generation=base_generation,
                    base_digest=base_digest,
                    expected_source_digest=(
                        None
                        if resolution.decision == "keep_both"
                        else resolution.expected_remote_digest
                    ),
                    staged_path=resolution.staged_path,
                    staged_digest=plan.sha256,
                    staged_size=plan.size_bytes,
                )
        if existing.mutation_id != successor_id or existing.path != target:
            raise StateError("the resolution successor was coalesced into other work")
        if local is None:
            if existing.kind != "delete":
                raise StateError("the resolution successor is not the expected delete")
            self.database.mark_materialized(
                target,
                state="dirty",
                clean_digest=resolution.expected_remote_digest,
                bytes_on_disk=0,
                pinned=True,
            )
            self.watch.acknowledge_local_state({target: None})
        else:
            if (
                existing.kind != "put"
                or existing.staged_path != resolution.staged_path
                or existing.staged_digest != local.sha256
            ):
                raise StateError("the resolution successor changed its staged identity")
            self.database.mark_materialized(
                target,
                state="dirty",
                clean_digest=(
                    None
                    if resolution.decision == "keep_both"
                    else resolution.expected_remote_digest
                ),
                stat_fingerprint=_fingerprint_text(local.fingerprint),
                bytes_on_disk=local.fingerprint.size_bytes,
                pinned=True,
            )
            self.watch.acknowledge_local_state({target: local})
            try:
                self.cache.pin_owner(
                    f"operation:{successor_id}", local.sha256, dirty=True
                )
            except (OSError, FabricCacheError) as error:
                self.logger.record(
                    "fabric_conflict_cache_pin_skipped",
                    mutation_id=successor_id,
                    error=str(error),
                )
        updated = self.database.transition_conflict_resolution(
            resolution.resolution_id,
            expected_phase="prepared",
            phase="waiting_successor",
        )
        return updated is not None

    def _authorize_resolution_remote_apply(
        self,
        view: ConflictView,
        resolution: ConflictResolution,
        local: HashedRegularFile | FileFingerprint | None,
        *,
        expected_phase: str,
    ) -> None:
        materialized = self.database.get_materialized(view.conflict.path)
        local_identity = (
            local.fingerprint if isinstance(local, HashedRegularFile) else local
        )
        fingerprint = (
            _fingerprint_text(local_identity)
            if local_identity is not None
            else None
        )
        local_bytes = local_identity.size_bytes if local_identity is not None else 0
        if (
            materialized is None
            or materialized.state != "conflict"
            or materialized.stat_fingerprint != fingerprint
            or materialized.bytes_on_disk != local_bytes
        ):
            raise StateError("the materialized local conflict identity advanced")
        self.database.authorize_conflict_remote_apply(
            resolution.resolution_id,
            expected_phase=expected_phase,
            local_fingerprint=fingerprint,
            local_bytes=local_bytes,
        )
        self._queue_remote_applies((view.conflict.path,))
        self._remote_apply_intents_may_remain = True

    def _classic_stage_chunks(
        self, stage: Path, plan: StagePlan
    ) -> Iterator[bytes]:
        descriptor = os.open(
            str(stage),
            os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0),
        )
        whole = hashlib.sha256()
        try:
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
                raise InvalidTask("the resolution stage is not a private regular file")
            for block in plan.blocks:
                data = _read_up_to(descriptor, block.size_bytes)
                if len(data) != block.size_bytes or hashlib.sha256(data).hexdigest() != block.sha256:
                    raise InvalidTask("the resolution stage block changed")
                whole.update(data)
                if data:
                    yield data
            after = os.fstat(descriptor)
            if (
                before.st_dev != after.st_dev
                or before.st_ino != after.st_ino
                or before.st_size != after.st_size
                or whole.hexdigest() != plan.sha256
            ):
                raise InvalidTask("the resolution stage changed while streaming")
        finally:
            os.close(descriptor)

    # ------------------------------------------------------------- mutations

    def _next_sendable_mutation_id(self) -> str | None:
        """The mutation id the next turn would claim, or None when idle.

        Deliberately cheap -- the drain asks this between turns, so it must not
        cost more than the turn it guards. It also gives the drain its
        stop condition: seeing the same id twice means the previous turn parked
        it rather than making progress.
        """

        try:
            head = self.database.list_sendable_operations(
                limit=1, now_ns=self._wall_now_ns()
            )
        except StateError:
            return None
        return head[0].mutation_id if head else None

    def _process_one_operation(self, *, allow_signed_control: bool | None = None) -> bool:
        self._last_turn_was_batch_commit = False
        if allow_signed_control is None:
            allow_signed_control = (
                float(self._clock()) >= self._signed_control_not_before
            )
        if not isinstance(allow_signed_control, bool):
            raise ValueError("allow_signed_control must be a boolean")

        # Namespace prerequisites must become durable before a child file can
        # publish under their destination. Otherwise a→b followed by b/file
        # creates the rename destination itself and rejects its own rename.
        # Byte staging remains independent. A folder delete waits for its
        # earlier child-file deletes, so this does not race rmdir ahead of them.
        if allow_signed_control and self._v2_commit_active():
            if self._publish_one_directory_put():
                return True

        # Provider PUTs and byte-only rename hashing are deliberately outside
        # the signed control budget. Drain and fsync those completions during a
        # Retry-After fence; only mint/verify/mutate after the fence opens.
        if self._put_upload_states:
            calls_before = self._signed_control_calls
            polled = self._poll_put_upload(allow_signed_control=allow_signed_control)
            # An upload tick that spent no signed call may commit the ready
            # companions of the running upload once they have waited long
            # enough; the running put joins the next batch when it lands.
            if (
                allow_signed_control
                and self._signed_control_calls == calls_before
                and self._put_upload_states
                and self._batching_enabled()
                and self.database.get_commit_unknown_operation() is None
            ):
                batch = self._plan_commit_batch(
                    exclude=set(self._put_upload_states), uploading=True
                )
                if batch:
                    self._send_commit_cohort(batch)
                    return True
            if (not allow_signed_control or self._signed_control_calls != calls_before
                    or (polled and not self._put_upload_states)):
                return polled
            # Byte workers are independent of the serialized control lane.
            # Admit another durable file while existing files are uploading;
            # the process-wide pool owns both slot and resident-byte bounds.

        if self._rename_verify_future is not None:
            return self._poll_large_rename_verification()

        if not allow_signed_control:
            return False

        # A mutation whose response was not durably acknowledged owns the
        # signed-control lane until status proves either the receipt or an
        # authoritative miss. It is never returned by claim_operation, so no
        # later path can leapfrog this readback fence and issue another POST.
        unknown = self.database.get_commit_unknown_operation()
        if unknown is not None:
            if (
                unknown.next_attempt_at_ns is not None
                and unknown.next_attempt_at_ns > self._wall_now_ns()
            ):
                return False
            if _is_v2_commit_fence(unknown):
                self._recover_v2_commit_fence(unknown)
                return True
            self._read_back_commit_unknown(unknown)
            return True

        quarantined_unknown = (
            self.database.get_resolvable_quarantined_commit_unknown()
            if float(self._clock()) >= self._next_quarantined_status_poll
            else None
        )
        if quarantined_unknown is not None:
            self._read_back_quarantined_commit_unknown(quarantined_unknown)
            return True

        operation: PendingOperation | None
        if self._batching_enabled():
            turn = self._plan_mutation_turn()
            if turn is None:
                return False
            kind, selected = turn
            if kind == "batch":
                self._send_commit_cohort(selected)
                # Only a batch-commit turn may extend a drain (see the tick
                # loop). Ticket-minting and single-mutation turns keep their
                # one-per-tick bound: those govern provider ticket debt and
                # expiry safety, not bulk commit throughput.
                self._last_turn_was_batch_commit = True
                return True
            operation = selected[0].operation
        elif not self._put_upload_states:
            # Preserve the classic lane's expired-lease recovery on restart.
            operation = self.database.claim_operation(now_ns=self._wall_now_ns())
        else:
            candidates = self.database.list_sendable_operations(
                limit=UPLOAD_WORKER_CONCURRENCY + 1, now_ns=self._wall_now_ns()
            )
            candidate = next(
                (item for item in candidates
                 if item.mutation_id not in self._put_upload_states), None
            )
            if candidate is None:
                return False
            claimed = self.database.claim_operations(
                [candidate.mutation_id],
                now_ns=self._wall_now_ns(),
            )
            operation = claimed[0] if claimed else None
        if operation is None:
            return False
        head = self.database.get_remote_manifest_head()
        if (
            operation.base_generation is not None
            and (head is None or head.generation < operation.base_generation)
        ):
            # A predecessor receipt can advance a dependent row before the
            # next signed change poll publishes that generation into the local
            # manifest index.  Capacity and directory-source checks against
            # that stale index would manufacture a permanent conflict for an
            # operation that is already correctly ordered.  Park the row for
            # one normal poll interval and give remote control priority; no
            # mutation or provider ticket is issued from stale metadata.
            self.database.update_operation(
                operation.mutation_id,
                state="retry",
                error=(
                    "waiting for authoritative Fabric manifest generation "
                    f"{operation.base_generation}"
                ),
                retry_after_seconds=MIN_REMOTE_POLL_SECONDS,
                reset_failures=True,
                now_ns=self._wall_now_ns(),
            )
            self._next_remote_poll = 0.0
            self._prefer_remote_control = True
            return False
        authoritative_prefix = next(
            (
                prefix
                for prefix in (
                    _AUTHORITATIVE_BASE_DIVERGED_PREFIX,
                    _AUTHORITATIVE_CONFLICT_PREFIX,
                )
                if operation.last_error is not None
                and operation.last_error.startswith(prefix)
            ),
            None,
        )
        if authoritative_prefix is not None:
            # A restart may discover this durable marker before any in-memory
            # refresh state exists. Requeue it without a mutation POST and make
            # the next signed control call an authoritative manifest refresh.
            self._defer_operation_conflict_for_refresh(
                operation,
                operation.last_error[len(authoritative_prefix) :],  # type: ignore[index]
                remote_code=(
                    "FABRIC_MUTATION_BASE_DIVERGED"
                    if authoritative_prefix == _AUTHORITATIVE_BASE_DIVERGED_PREFIX
                    else None
                ),
            )
            return False
        if (
            operation.kind == "rename"
            and operation.last_error is not None
            and operation.last_error.startswith(_RENAME_VERIFY_PREFIX)
        ):
            self._start_large_rename_verification(operation)
            return False
        try:
            if operation.kind == "put":
                complete = self._send_put(operation)
                if not complete:
                    in_flight = operation.mutation_id in self._put_upload_states
                    self.database.update_operation(
                        operation.mutation_id,
                        state="retry",
                        error=(
                            "provider upload in flight"
                            if in_flight
                            else "bounded block continuation"
                        ),
                        # This is successful progress, not an error retry. Keep
                        # the one-control-call-per-poll boundary, then expose an
                        # immediately-due journal row so NodeRunner can run the
                        # next batch after its heartbeat/command bookkeeping.
                        retry_after_seconds=(
                            UPLOAD_IN_FLIGHT_RETRY_SECONDS if in_flight else 0.0
                        ),
                        reset_failures=True,
                        now_ns=self._wall_now_ns(),
                    )
                    return True
            else:
                if operation.kind == "rename":
                    self._assert_mutation_namespace_capacity(operation, plan=None)
                if self._v2_commit_active():
                    # The v1 lane sends (base_generation, base_manifest_digest).
                    # A workspace whose v1 manifest lineage was wiped is
                    # permanently at generation zero with no digest, so every
                    # such request is rejected 400 FABRIC_MUTATION_BASE_INVALID
                    # and the operation is terminally conflicted -- the single
                    # lane cannot succeed AT ALL once v2 owns the workspace.
                    # v2 has no generation/base concept, so a cohort of one is
                    # well defined and is exactly what the batch lane already
                    # sends for a lone inline entry.
                    self._send_commit_cohort(
                        [_BatchCommitEntry(operation=operation)]
                    )
                else:
                    receipt = self._send_path_mutation(operation)
                    self._ack_mutation(operation, receipt)
            return True

        except FileProviderSourceUnavailable as error:
            # The system-owned contents inode is intentionally not copied.
            # A process/extension restart therefore pauses this exact durable
            # mutation until File Provider retries and reattaches the URL.
            if operation.state != "acked":
                self.database.update_operation(
                    operation.mutation_id,
                    state="retry",
                    error=str(error),
                    retry_after_seconds=60.0,
                    reset_failures=True,
                    now_ns=self._wall_now_ns(),
                )
            return True
        except SourceDrift as error:
            if self._operation_commit_is_unknown(operation.mutation_id):
                self._defer_commit_unknown(operation, error)
            elif operation.kind == "put":
                self._supersede_source_backed_operation(operation, error)
            else:
                self._record_operation_conflict(
                    operation, f"local Fabric source changed: {error}"
                )
            return True
        except RemoteError as error:
            if self._handle_operation_remote_error(operation, error):
                # The operation is already durably parked above. Propagate
                # only the lease failure to the coordinator boundary so new
                # namespace mutations are fenced until the runtime manager's
                # authenticated attachment heartbeat/rebind succeeds. Local
                # bytes and the same mutation id remain available for retry.
                raise
            return True
        except (OSError, NetworkError) as error:
            if self._operation_commit_is_unknown(operation.mutation_id):
                self._defer_commit_unknown(operation, error)
            else:
                self._schedule_operation_retry(operation, error)
            return True
        except (InvalidTask, StateError, UnsafePath, ValueError) as error:
            if self._operation_commit_is_unknown(operation.mutation_id):
                # The remote commit may be durable even if local receipt
                # finalization failed. Re-read and retry idempotent local ACK
                # work; never turn an acknowledged user mutation into a local
                # conflict merely because SQLite/filesystem work was interrupted.
                self._defer_commit_unknown(operation, error)
            else:
                self._record_operation_conflict(
                    operation, f"local Fabric operation cannot continue safely: {error}"
                )
            return True

    def _handle_operation_remote_error(
        self, operation: PendingOperation, error: RemoteError
    ) -> bool:
        """Park one rejected operation exactly as the single mutate path does.

        Returns True when the rejection was an attachment-lease failure the
        caller must propagate to the coordinator boundary.
        """

        attachment_inactive = (
            error.status == 409
            and error.remote_code == "FABRIC_ATTACHMENT_INACTIVE"
        )
        if self._operation_commit_is_unknown(operation.mutation_id):
            if error.remote_code in {
                "FABRIC_BINDING_CHANGED",
                "FABRIC_BINDING_INACTIVE",
                "FABRIC_MANIFEST_UNAVAILABLE",
                "FABRIC_AUTHORITY_STALE",
                "FABRIC_MUTATION_PERSIST_CONFLICT",
                "FABRIC_MUTATION_CONFLICT_RETRY_EXHAUSTED",
            }:
                self._force_full_remote = True
            self._defer_commit_unknown(operation, error)
        elif (
            operation.kind == "put"
            and error.status == 409
            and error.remote_code == "WORKSPACE_STORAGE_QUOTA_EXCEEDED"
        ):
            # Quota is an authoritative pre-commit rejection, not a
            # status-readback ambiguity. Park only this byte-producing
            # operation long enough for an independently queued delete to
            # free space; the SQLite ready-at ordering then lets that
            # delete bypass the parked put without a second scheduler.
            self.database.update_operation(
                operation.mutation_id,
                state="retry",
                error=str(error),
                retry_after_seconds=QUOTA_PUT_PARK_SECONDS,
                count_failure=True,
                now_ns=self._wall_now_ns(),
            )
        elif operation.kind == "put" and _is_put_verification_expired(error):
            # Verification authority is deliberately shorter-lived than
            # the immutable CAS objects.  A slow upload or reconnect may
            # therefore reach mutate with stale durable proof.  Revoke
            # only the proof journal and re-verify under the same mutation
            # id; clearing ``uploaded`` would waste bandwidth and can loop
            # forever when the object is healthy but the proof expired.
            self._clear_put_verification(operation)
            self._schedule_operation_retry(operation, error)
        elif _is_fabric_v2_path_conflict(error):
            self._recover_fabric_v2_path_conflict(operation, error)
        elif error.remote_code == "FABRIC_MUTATION_BASE_INVALID":
            self._refresh_or_conflict_invalid_base(operation, error)
        elif operation.kind == "put" and _is_v2_absent_block_rejection(error):
            # The store says a block this put depends on is not there. The
            # remedy is to send the bytes again, so this is a bounded retry
            # and never a permanent verdict -- the caller has already dropped
            # whatever this put believed the store held, so the next attempt
            # re-uploads rather than re-offering the same unprovable digests.
            #
            # `_schedule_operation_retry` accrues a failure, which is what
            # keeps a store that refuses everything from turning into an
            # endless re-upload loop: it backs off and eventually parks, the
            # same bound every other retryable class gets.
            self._schedule_operation_retry(operation, error)
        elif _is_mutation_conflict(error):
            if error.remote_code in {
                "FABRIC_MUTATION_BASE_DIVERGED",
                "FABRIC_MUTATION_PATH_CONFLICT",
            }:
                self._defer_operation_conflict_for_refresh(
                    operation,
                    str(error),
                    remote_code=error.remote_code,
                )
            else:
                self._record_operation_conflict(operation, str(error))
        elif _is_transient_remote_error(error):
            if error.remote_code in {
                "FABRIC_BINDING_CHANGED",
                "FABRIC_BINDING_INACTIVE",
                "FABRIC_MANIFEST_UNAVAILABLE",
                "FABRIC_AUTHORITY_STALE",
                "FABRIC_MUTATION_PERSIST_CONFLICT",
                "FABRIC_MUTATION_CONFLICT_RETRY_EXHAUSTED",
            }:
                # Refresh/read back the durable head on the alternating
                # control tick before this operation retries.
                self._force_full_remote = True
            self._schedule_operation_retry(operation, error)
        else:
            self._record_operation_conflict(
                operation,
                f"permanent remote rejection ({error.status} {error.remote_code or 'REMOTE_ERROR'}): {error}",
            )
        return attachment_inactive

    def _recover_fabric_v2_path_conflict(
        self, operation: PendingOperation, error: RemoteError
    ) -> None:
        """Refresh and rebase one v2 per-path rejection, under a bound.

        A per-path verdict says the authority holds something other than what
        this operation assumed. That is recoverable: read the authority back
        and rebase onto what is actually there, exactly as the v1
        FABRIC_MUTATION_BASE_DIVERGED lane already does. Recording a conflict
        on first sight instead is what stranded a file permanently.

        The bound is what keeps the recovery honest. A server answering the
        same code every time would otherwise cycle this operation for the life
        of the process; past ``MAX_V2_PATH_RECOVERY_ATTEMPTS`` the rejection
        becomes one conflict the user can see and resolve.
        """

        attempts = self._v2_recovery_attempt(operation.mutation_id)
        if attempts > MAX_V2_PATH_RECOVERY_ATTEMPTS:
            self.logger.record(
                "fabric_v2_path_recovery_exhausted",
                mutation_id=operation.mutation_id,
                path=operation.path,
                code=error.remote_code,
                attempts=attempts - 1,
            )
            self._record_operation_conflict(
                operation,
                f"Fabric v2 path recovery exhausted after "
                f"{MAX_V2_PATH_RECOVERY_ATTEMPTS} refreshes "
                f"({error.remote_code or 'REMOTE_ERROR'}): {error}",
            )
            return
        self._commit_v2_recovery_attempt(operation.mutation_id, attempts)
        self.logger.record(
            "fabric_v2_path_recovery_scheduled",
            mutation_id=operation.mutation_id,
            path=operation.path,
            code=error.remote_code,
            attempt=attempts,
            # FABRIC_PATH_EXISTS and FABRIC_PATH_DIVERGED name what the
            # authority actually holds. The rebase reads that back under
            # signature rather than trusting this hint, but recording it makes
            # a divergence diagnosable without a second round trip.
            observed_digest=(error.details or {}).get("observed_digest"),
        )
        self._defer_operation_conflict_for_refresh(
            operation,
            str(error),
            count_failure=True,
            # A CAS miss carries a winner to rebase onto; a missing rename
            # source does not, so it takes the plain refresh marker, which
            # converges or conflicts on the very next authoritative read.
            remote_code=(
                "FABRIC_MUTATION_BASE_DIVERGED"
                if error.remote_code in FABRIC_V2_REBASE_CODES
                else None
            ),
        )

    def _v2_recovery_attempt(self, mutation_id: str) -> int:
        """This operation's next v2 recovery attempt number."""

        return self._v2_path_recovery_attempts.get(mutation_id, 0) + 1

    def _commit_v2_recovery_attempt(self, mutation_id: str, attempts: int) -> None:
        """Record the attempt, keeping the in-memory map bounded."""

        if (
            mutation_id not in self._v2_path_recovery_attempts
            and len(self._v2_path_recovery_attempts) >= MAX_MUTATION_LIVE_FILES
        ):
            # Entries are retired on ack and on conflict, but an operation
            # superseded or quarantined elsewhere leaves one behind. Bound the
            # map rather than let a long-lived process accumulate them; the
            # cost of forgetting is one extra refresh, never a lost operation.
            self._v2_path_recovery_attempts.clear()
        self._v2_path_recovery_attempts[mutation_id] = attempts

    def _defer_unknown_v2_verdict(
        self,
        operation: PendingOperation,
        error: RemoteError,
        verdict: Mapping[str, Any],
    ) -> None:
        """Retry a v2 verdict code this node does not recognise.

        Terminal is a claim about the future: it asserts that no retry can ever
        succeed. A node cannot honestly make that claim about a code it has
        never seen, and being wrong strands a user's file the moment a newer
        server ships a code an older node has not learned. So an unrecognised
        code -- including a verdict carrying no code at all -- retries under
        the same bound as the other v2 recoveries, and the raw verdict is
        logged so the unknown code is diagnosable rather than invisible.
        """

        attempts = self._v2_recovery_attempt(operation.mutation_id)
        self.logger.record(
            "fabric_v2_unknown_verdict_code",
            mutation_id=operation.mutation_id,
            path=operation.path,
            code=error.remote_code,
            attempt=attempts,
            verdict=json.dumps(dict(verdict), sort_keys=True, default=str)[:1_000],
        )
        if attempts > MAX_V2_PATH_RECOVERY_ATTEMPTS:
            self._record_operation_conflict(
                operation,
                f"unrecognised Fabric v2 verdict still rejected after "
                f"{MAX_V2_PATH_RECOVERY_ATTEMPTS} retries "
                f"({error.remote_code or 'REMOTE_ERROR'}): {error}",
            )
            return
        self._commit_v2_recovery_attempt(operation.mutation_id, attempts)
        self._schedule_operation_retry(operation, error)

    def _start_large_rename_verification(
        self, operation: PendingOperation
    ) -> None:
        """Move a claimed durable rename back behind its byte-only fence."""

        if operation.destination_path is None or operation.last_error is None:
            raise StateError("The large rename verification marker is incomplete.")
        _rename_verification_fingerprint(operation.last_error)
        self.database.update_operation(
            operation.mutation_id,
            state="retry",
            error=operation.last_error,
            retry_after_seconds=0.0,
            reset_failures=True,
            now_ns=self._wall_now_ns(),
        )
        self._rename_verify_mutation_id = operation.mutation_id
        source = self._remote_entry_for_write(operation.path)
        baseline = self.database.get_materialized(operation.path)
        def verify_destination() -> tuple[HashedRegularFile | None, bool]:
            local = self.workspace.hash_regular_file(operation.destination_path)
            matches = bool(local is not None and source is not None
                and source.digest == operation.expected_source_digest
                and self._local_matches_remote(local, source, baseline,
                                               source_path=operation.destination_path))
            return local, matches
        self._rename_verify_future = _daemon_future(
            "meshia-large-rename-verify",
            verify_destination,
        )
        self._rename_verify_future.add_done_callback(lambda _future: self.wake())

    def _poll_large_rename_verification(self) -> bool:
        future = self._rename_verify_future
        mutation_id = self._rename_verify_mutation_id
        if future is None or mutation_id is None:
            raise StateError("The large rename verifier lost its durable owner.")
        if not future.done():
            return False
        self._rename_verify_future = None
        self._rename_verify_mutation_id = None
        operation = self.database.get_operation(mutation_id)
        if operation is None or operation.state in ("acked", "conflict", "quarantined"):
            return True
        if operation.destination_path is None or operation.last_error is None:
            raise StateError("The durable large rename verification marker disappeared.")
        expected_fingerprint = _rename_verification_fingerprint(operation.last_error)
        try:
            local, matches = future.result()
        except BaseException:
            # Keep the exact durable marker. The next bounded retry reopens the
            # anchored destination; it never sends a metadata mutation on an
            # inconclusive read.
            self.database.update_operation(
                mutation_id,
                state="retry",
                error=operation.last_error,
                retry_after_seconds=MIN_REMOTE_POLL_SECONDS,
                count_failure=True,
                now_ns=self._wall_now_ns(),
            )
            return True
        if (
            local is not None
            and local.fingerprint == expected_fingerprint
            and matches
        ):
            current = self.database.get_materialized(operation.destination_path)
            self.database.mark_materialized(
                operation.destination_path, state="dirty",
                clean_digest=operation.expected_source_digest,
                clean_digest_algorithm=current.clean_digest_algorithm if current is not None else None,
                content_sha256=local.sha256,
                stat_fingerprint=_fingerprint_text(local.fingerprint),
                bytes_on_disk=local.fingerprint.size_bytes, pinned=True,
            )
            self.database.update_operation(
                mutation_id,
                state="retry",
                error=None,
                retry_after_seconds=0.0,
                reset_failures=True,
                now_ns=self._wall_now_ns(),
            )
            return True

        # The move carried an edit (or changed again while hashing). Preserve
        # its bytes and fall back to the existing put-then-dependent-delete
        # flow; only the now-proven metadata rename is retired as a conflict.
        # This is an internal plan supersession, not a user-visible divergent
        # file: the destination bytes are preserved by the durable put below.
        self.database.supersede_operation(
            operation.mutation_id,
            reason="large local rename changed; superseded by put+delete",
        )
        if local is not None and operation.expected_source_digest is not None:
            self._stage_local_put_bounded(
                operation.destination_path,
                expected_source_digest=operation.expected_destination_digest,
                delete_after_ack=(operation.path, operation.expected_source_digest),
            )
        return True

    def _operation_commit_is_unknown(self, mutation_id: str) -> bool:
        current = self.database.get_operation(mutation_id)
        return current is not None and current.commit_unknown

    def _read_back_commit_unknown(self, operation: PendingOperation) -> None:
        """Spend one signed tick resolving an ambiguous mutation receipt."""

        try:
            request_digest = operation.request_digest
            if not _digest(request_digest):
                raise StateError(
                    "The ambiguous Fabric mutation lost its frozen request digest."
                )
            assert request_digest is not None
            # The frozen digest and mutation UUID are sufficient to resolve the
            # remote outcome. Disposable PUT plan metadata must never stand in
            # front of that status authority.
            response = self._signed_control_request(
                self.transport.mutation_status,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "mutation_id": operation.mutation_id,
                    "request_digest": request_digest,
                },
            )
            receipt = _mutation_status_receipt(
                response, operation, request_digest=request_digest
            )
            plan: StagePlan | None = None
            if receipt is None:
                try:
                    plan = self._reconstruct_commit_unknown_plan(
                        operation, request_digest=request_digest
                    )
                except (OSError, InvalidTask, StateError, UnsafePath, ValueError) as error:
                    self._record_operation_conflict(
                        operation,
                        "mutation status proved no commit, but the frozen local request "
                        f"cannot be reconstructed safely: {error}",
                    )
                    self.logger.record(
                        "fabric_mutation_status_recovery_required",
                        mutation_id=operation.mutation_id,
                        error=str(error),
                    )
                    return
                self.database.clear_operation_commit_unknown_for_retry(
                    operation.mutation_id,
                    reason=_MUTATION_STATUS_MISS,
                    now_ns=self._wall_now_ns(),
                )
                self.logger.record(
                    "fabric_mutation_status_not_found",
                    mutation_id=operation.mutation_id,
                )
                return
            if operation.kind == "put":
                try:
                    plan = self._reconstruct_commit_unknown_plan(
                        operation, request_digest=request_digest
                    )
                except (OSError, InvalidTask, StateError, UnsafePath, ValueError) as error:
                    self._ack_commit_unknown_with_unusable_put_evidence(
                        operation, receipt, error
                    )
                else:
                    self._ack_mutation(operation, receipt, plan=plan)
            else:
                self._ack_mutation(operation, receipt)
            self.logger.record(
                "fabric_mutation_status_acknowledged",
                mutation_id=operation.mutation_id,
                manifest_generation=int(receipt["manifest_generation"]),
            )
        except RemoteError as error:
            if (
                error.status == 409
                and error.remote_code == "FABRIC_MUTATION_IDEMPOTENCY_CONFLICT"
            ):
                self._record_operation_conflict(
                    operation,
                    "mutation status rejected the frozen request digest as an idempotency conflict",
                )
                return
            if error.remote_code in {
                "FABRIC_BINDING_CHANGED",
                "FABRIC_BINDING_INACTIVE",
                "FABRIC_MANIFEST_UNAVAILABLE",
                "FABRIC_AUTHORITY_STALE",
            }:
                self._force_full_remote = True
            self._defer_commit_unknown(operation, error)
        except (
            OSError,
            NetworkError,
            InvalidTask,
            StateError,
            UnsafePath,
            ValueError,
        ) as error:
            self._defer_commit_unknown(operation, error)

    def _read_back_quarantined_commit_unknown(
        self, unknown: QuarantinedCommitUnknown
    ) -> None:
        """Resolve a generation-fenced outcome by status only, never replay."""

        operation = unknown.operation
        request_digest = operation.request_digest
        if not _digest(request_digest):
            raise StateError(
                "A quarantined Fabric mutation lost its frozen request digest."
            )
        assert request_digest is not None
        try:
            response = self._signed_control_request(
                self.transport.mutation_status,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "mutation_id": operation.mutation_id,
                    "request_digest": request_digest,
                },
            )
            receipt = _mutation_status_receipt(
                response, operation, request_digest=request_digest
            )
            plan_error: BaseException | None = None
            if operation.kind == "put":
                try:
                    self._reconstruct_commit_unknown_plan(
                        operation, request_digest=request_digest
                    )
                except (OSError, InvalidTask, StateError, UnsafePath, ValueError) as error:
                    plan_error = error
            if receipt is None:
                self.database.resolve_quarantined_commit_unknown_missing(
                    original_scope_id=unknown.original_scope_id,
                    mutation_id=operation.mutation_id,
                    request_digest=request_digest,
                    reason=(
                        "status proved no commit; local PUT evidence needs recovery: "
                        + str(plan_error)
                        if plan_error is not None
                        else _MUTATION_STATUS_MISS
                    ),
                    preserve_as_conflict=plan_error is not None,
                )
                self.logger.record(
                    "fabric_quarantined_mutation_status_not_found",
                    mutation_id=operation.mutation_id,
                )
                return
            if plan_error is not None and operation.staged_path is not None:
                remote = self.database.get_remote_entry(operation.path)
                self.database.record_conflict(
                    operation.path,
                    "prior-generation remote commit was proven, but local staged "
                    f"evidence needs recovery: {plan_error}",
                    base_digest=operation.expected_source_digest,
                    local_digest=operation.staged_digest,
                    remote_digest=(
                        remote.digest
                        if remote is not None
                        else operation.staged_digest
                    ),
                    remote_generation=int(receipt["manifest_generation"]),
                    staged_path=operation.staged_path,
                )
            self.database.resolve_quarantined_commit_unknown_found(
                original_scope_id=unknown.original_scope_id,
                mutation_id=operation.mutation_id,
                request_digest=request_digest,
                remote_generation=int(receipt["manifest_generation"]),
                remote_manifest_digest=_receipt_manifest_digest(receipt),
                remote_entry_digest=(
                    operation.staged_digest if operation.kind == "put" else None
                ),
                receipt=dict(receipt),
            )
            self._next_remote_poll = 0.0
            self.logger.record(
                "fabric_quarantined_mutation_status_acknowledged",
                mutation_id=operation.mutation_id,
                manifest_generation=int(receipt["manifest_generation"]),
            )
        except RemoteError as error:
            if (
                error.status == 409
                and error.remote_code == "FABRIC_MUTATION_IDEMPOTENCY_CONFLICT"
            ):
                self.database.resolve_quarantined_commit_unknown_missing(
                    original_scope_id=unknown.original_scope_id,
                    mutation_id=operation.mutation_id,
                    request_digest=request_digest,
                    reason="status rejected the frozen request digest",
                    preserve_as_conflict=operation.kind == "put",
                )
                return
            self._defer_quarantined_status(error)
        except (OSError, NetworkError, InvalidTask, StateError, UnsafePath, ValueError) as error:
            self._defer_quarantined_status(error)

    def _defer_quarantined_status(self, error: BaseException) -> None:
        delay = (
            error.retry_after_seconds
            if isinstance(error, RemoteError)
            and error.status == 429
            and error.retry_after_seconds is not None
            else MIN_REMOTE_POLL_SECONDS * 2
        )
        self._next_quarantined_status_poll = float(self._clock()) + max(
            MIN_REMOTE_POLL_SECONDS * 2, float(delay)
        )
        self.logger.record(
            "fabric_quarantined_mutation_status_deferred", error=str(error)
        )

    def _reconstruct_commit_unknown_plan(
        self, operation: PendingOperation, *, request_digest: str
    ) -> StagePlan | None:
        plan = (
            _load_plan(Path(operation.staged_path), operation)
            if operation.kind == "put" and operation.staged_path is not None
            else None
        )
        if operation.kind == "put" and plan is None:
            raise StateError("An ambiguous Fabric put lost its durable stage plan.")
        mutation_payload = self._path_mutation_payload(operation, plan=plan)
        reconstructed = _mutation_request_digest(
            self.authority.session_id, mutation_payload
        )
        if reconstructed != request_digest:
            raise StateError(
                "The frozen Fabric mutation request no longer matches its durable journal."
            )
        return plan

    def _ack_commit_unknown_with_unusable_put_evidence(
        self,
        operation: PendingOperation,
        receipt: Mapping[str, Any],
        error: BaseException,
    ) -> None:
        """ACK server truth while retaining the only inspectable local stage."""

        if (
            operation.kind != "put"
            or operation.staged_path is None
            or operation.staged_digest is None
            or operation.staged_size is None
        ):
            raise StateError("The ambiguous Fabric put lost its staged identity.")
        remote = self.database.get_remote_entry(operation.path)
        self.database.record_conflict(
            operation.path,
            "remote commit was proven, but local staged evidence needs recovery: "
            f"{error}",
            base_digest=operation.expected_source_digest,
            local_digest=operation.staged_digest,
            remote_digest=remote.digest if remote is not None else operation.staged_digest,
            remote_generation=int(receipt["manifest_generation"]),
            staged_path=operation.staged_path,
        )
        local = self.database.get_materialized(operation.path)
        self.database.mark_materialized(
            operation.path,
            state="conflict",
            clean_digest=local.clean_digest if local else None,
            stat_fingerprint=local.stat_fingerprint if local else None,
            bytes_on_disk=local.bytes_on_disk if local else 0,
            pinned=True,
        )
        # Conflict evidence above is durable before the operation ACK. The
        # acknowledged-stage sweeper therefore sees an external reference and
        # cannot remove the exportable bytes through the crash window.
        self.database.ack_operation(
            operation.mutation_id,
            remote_generation=int(receipt["manifest_generation"]),
            remote_manifest_digest=_receipt_manifest_digest(receipt),
            remote_entry_digest=operation.staged_digest,
            receipt=dict(receipt),
        )
        try:
            self.cache.unpin_owner(
                f"operation:{operation.mutation_id}", operation.staged_digest
            )
        except (OSError, FabricCacheError) as cleanup_error:
            self.logger.record(
                "fabric_acked_cache_cleanup_deferred",
                mutation_id=operation.mutation_id,
                error=str(cleanup_error),
            )
        self._next_remote_poll = 0.0

    def _defer_commit_unknown(
        self, operation: PendingOperation, error: BaseException
    ) -> None:
        failure_count = operation.failure_count + 1
        delay = max(
            _operation_retry_delay(operation.mutation_id, failure_count),
            (
                error.retry_after_seconds
                if isinstance(error, RemoteError)
                and error.status == 429
                and error.retry_after_seconds is not None
                else 0.0
            ),
        )
        self.database.update_operation(
            operation.mutation_id,
            state="retry",
            # 3,000 Unicode scalars stay below the DB's 16-KiB UTF-8 cap even
            # in the four-byte worst case, including this fixed prefix.
            error=f"mutation status required: {str(error)[:3_000]}",
            retry_after_seconds=delay,
            count_failure=True,
            now_ns=self._wall_now_ns(),
        )
        self.logger.record(
            "fabric_mutation_status_retry_scheduled",
            mutation_id=operation.mutation_id,
            failure_count=failure_count,
            retry_after_seconds=round(delay, 3),
            error=str(error),
        )

    def _clear_put_verification(self, operation: PendingOperation) -> None:
        if operation.staged_path is None:
            raise StateError("A queued Fabric put has no durable stage.")
        stage_path = Path(operation.staged_path)
        progress = self._put_progress(operation, stage_path)
        # The staging-PUT attempt is durable and server verification is
        # idempotent. If only the mutation proof expired, replay those exact
        # digest/size descriptors to renew it without spending bandwidth or
        # creating another staging attempt. Explicit object missing/corruption
        # errors take the separate re-upload path in _verify_put_receipts.
        progress["verified"].clear()
        # A target-block reuse proof can be the stale assumption that caused
        # BLOCKS_NOT_VERIFIED. Persistently revoke it so the next attempt
        # obtains fresh immutable PUT attempts instead of looping on the same
        # optimistic target membership.
        progress["reuse_target_blocks"] = False
        _write_progress(stage_path, operation.mutation_id, progress)

    def _refresh_or_conflict_invalid_base(
        self, operation: PendingOperation, error: RemoteError
    ) -> None:
        """Re-read the durable head for a stale base, bounded, then conflict.

        Deliberately NOT the signed BASE_DIVERGED rebase route. That route
        asserts in the durable journal that a *signed* refresh proved a newer
        head superseded this operation's base, and
        ``rebase_precommit_operation_to_current_head`` fails closed with
        ``StateError`` unless the refreshed head strictly advanced past the
        rejected one. A BASE_INVALID rejection proves neither: the control
        plane only checked the request's base pair for shape, without ever
        comparing it to its own head, so the head may be unchanged or (after a
        storage wipe) behind. Claiming the divergence marker would both assert
        authority this response never granted and hand a guaranteed StateError
        to ``_finalize_authoritative_operation_conflicts``, which re-arms a
        refresh and re-raises. So take the plain route already used for
        FABRIC_AUTHORITY_STALE and friends: force one authoritative full head
        read, then retry on the ordinary backoff.
        """

        attempt = self._base_invalid_refreshes.get(operation.mutation_id, 0) + 1
        if attempt > MAX_BASE_INVALID_REFRESH_ATTEMPTS:
            # `_record_operation_conflict` retires this operation's budget.
            self._record_operation_conflict(
                operation,
                "remote rejected this mutation's base "
                f"({error.status} {error.remote_code}) again after "
                f"{MAX_BASE_INVALID_REFRESH_ATTEMPTS} authoritative remote head "
                "refreshes, so the base is malformed rather than stale: "
                f"{error}",
            )
            return
        self._base_invalid_refreshes[operation.mutation_id] = attempt
        # Read the durable head back on the alternating control tick before
        # this operation retries; replaying the identical base without one
        # could only be rejected the same way.
        self._force_full_remote = True
        self._next_remote_poll = 0.0
        self.logger.record(
            "fabric_mutation_base_invalid_refresh",
            mutation_id=operation.mutation_id,
            path=operation.path,
            attempt=attempt,
            limit=MAX_BASE_INVALID_REFRESH_ATTEMPTS,
            error=str(error),
        )
        self._schedule_operation_retry(operation, error)

    def _schedule_operation_retry(
        self, operation: PendingOperation, error: BaseException
    ) -> None:
        failure_count = operation.failure_count + 1
        delay = max(
            _operation_retry_delay(operation.mutation_id, failure_count),
            (
                error.retry_after_seconds
                if isinstance(error, RemoteError)
                and error.status == 429
                and error.retry_after_seconds is not None
                else 0.0
            ),
        )
        self.database.update_operation(
            operation.mutation_id,
            state="retry",
            error=str(error),
            retry_after_seconds=delay,
            count_failure=True,
            now_ns=self._wall_now_ns(),
        )
        self.logger.record(
            "fabric_operation_retry_scheduled",
            mutation_id=operation.mutation_id,
            failure_count=failure_count,
            retry_after_seconds=round(delay, 3),
            error=str(error),
        )

    def _wall_now_ns(self) -> int:
        value = self._wall_clock_ns()
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise StateError("The Fabric wall clock returned an invalid timestamp.")
        return value

    @staticmethod
    def _v2_lane_of(entries: Sequence[_BatchCommitEntry]) -> str:
        """Which budget lane a cohort belongs to.

        A cohort carrying inline bytes is the small-file lane; anything else
        is bulk. That is the same split the failure modes have: the inline
        lane is bounded by base64 payload against the body limit, the bulk
        lane by op count and descriptor size.
        """

        return "inline" if any(entry.inline_blocks for entry in entries) else "bulk"

    def _v2_lane_budget(self, lane: str = "inline") -> dict[str, int]:
        return self._v2_lane_budgets[lane if lane in self._v2_lane_budgets else "bulk"]

    def _v2_item_cap(self, lane: str = "inline") -> int:
        """The cohort size this lane may currently ask for."""

        return self._v2_lane_budget(lane)["item_cap"]

    def _v2_candidate_fetch_limit(self) -> int:
        """How many sendable rows to pull so the widest lane can fill a cohort.

        The bulk lane may ask for up to ``SERVER_MAX_V2_COMMIT_OPS`` ops, so a
        fetch capped at ``DEFAULT_MAX_BATCH_MUTATIONS`` would starve it to 64 no
        matter its item cap -- that page cap, not the cohort planner, was the
        real 64-op ceiling on already-uploaded files. The inline lane stays
        byte-bound: its classify loop stops reading bytes once the request
        budget is full, and the selection loop stops appending once the inline
        item cap is reached, so pulling more ROWS (metadata only) never buffers
        more inline bytes or builds a larger inline request than before.
        """

        if self._v2_commit_active():
            return max(DEFAULT_MAX_BATCH_MUTATIONS, SERVER_MAX_V2_COMMIT_OPS)
        return DEFAULT_MAX_BATCH_MUTATIONS

    @staticmethod
    def _v2_bulk_entry_wire_estimate(entry: _BatchCommitEntry) -> int:
        """Upper estimate of one bulk (descriptor-only) op's serialized size.

        A put lists every block of its file, so a large file's op is far bigger
        than the flat single-block estimate. Counting the blocks lets the bulk
        selector keep a cohort under the wire budget even when one member has a
        long block list; a slightly generous estimate is the safe error.
        """

        blocks = len(entry.plan.blocks) if entry.plan is not None else 1
        return _v2_op_wire_estimate(entry.operation, blocks)

    def _v2_inline_entry_wire_estimate(self, entry: _BatchCommitEntry) -> int:
        """Upper estimate of one INLINE entry's serialized contribution.

        The whole point of budgeting the SERIALIZED wire rather than the source
        bytes: an inline entry rides both its op descriptor (path-aware, may be
        long on a copy-of-a-copy) AND its block bytes base64-encoded (+1/3), each
        wrapped in an ``inline_blocks[]`` object. Item count is the wrong knob
        for mixed sizes -- a 16-item cohort of long-path multi-block files and a
        16-item cohort of tiny files are wildly different bodies -- so the
        selector sizes by this against the wire budget.
        """

        blocks = len(entry.plan.blocks) if entry.plan is not None else 1
        op_bytes = _v2_op_wire_estimate(entry.operation, blocks)
        source = sum(len(data) for _block, data in entry.inline_blocks)
        # base64 length is ceil(n/3)*4; the inline_blocks[] wrapper adds the
        # sha256/size_bytes/bytes_b64 keys per carried block.
        b64_bytes = ((source + 2) // 3) * 4
        wrapper = V2_INLINE_ENTRY_ENVELOPE_BYTES * max(1, len(entry.inline_blocks))
        return op_bytes + b64_bytes + wrapper

    @staticmethod
    def _v2_entry_readback_cost(entry: _BatchCommitEntry) -> int:
        """How many unproven-block readbacks this op would ask the commit to spend.

        Count inline bytes and receipt-backed uploads still awaiting server
        proof. Already verified/reused blocks cost zero. Distinct shas within
        an entry count once; duplicates across entries conservatively count
        again, so the planner never understates the server's readback budget.
        """

        if not entry.inline_blocks and not entry.commit_blocks and not entry.readback_blocks:
            return 0
        shas = {block.sha256 for block in entry.commit_blocks}
        shas |= {block.sha256 for block, _data in entry.inline_blocks}
        shas |= {block.sha256 for block in entry.readback_blocks}
        return len(shas)

    def _effective_inline_request_budget_bytes(self) -> int:
        """Inline SOURCE bytes one request can carry.

        The planner budgets raw bytes, but the edge rejects on the SERIALIZED
        request: base64 inflates every inline byte by 4/3 and the ops ride the
        same body. On v2 the wire is therefore the binding constraint, not the
        3-MiB byte budget -- a 64-item cohort of 16-KiB files is comfortably
        inside the byte budget and comfortably over the 1,450,000-byte body
        limit.

        This has to be applied where the cohort is SELECTED, not where the
        payload is serialized. Trimming at serialization time would leave the
        cohort naming blocks whose bytes did not ride, and the commit would
        reject exactly those ops as absent -- forever, because the next
        attempt re-plans the same cohort and trims it the same way.
        """

        if not self._v2_commit_active():
            return self._inline_request_budget_bytes
        budget = self._v2_lane_budget("inline")
        for_bytes = budget["wire_bytes"] - (
            DEFAULT_MAX_BATCH_MUTATIONS * V2_OP_WIRE_ESTIMATE_BYTES
        )
        return max(1, min(budget["inline_bytes"], (max(0, for_bytes) * 3) // 4))

    def _inline_supported_now(self) -> bool:
        """Whether the inline lane may be used on this tick.

        A disable is always time-bounded: an older control plane keeps failing
        the re-probe cheaply (one rejected batch every
        ``INLINE_DISABLE_REPROBE_SECONDS``), while a transient or self-inflicted
        rejection heals instead of degrading every later put to ticket waves for
        the life of the process.
        """

        if self._inline_commit_supported:
            return True
        deadline = self._inline_disabled_until_ns
        if deadline is None:
            return False
        if self._wall_now_ns() < deadline:
            return False
        self._inline_commit_supported = True
        self._inline_disabled_until_ns = None
        self.logger.record("fabric_inline_commit_reprobe")
        return True

    def _note_inline_declined(self, reason: str) -> None:
        """Log why a small put fell back to the classic ticket path.

        Rate limited to one record per reason per minute: without this the
        node was silent about the inline lane being off, which cost three
        rounds of hypothesis-driven debugging against live folders.
        """

        now_ns = self._wall_now_ns()
        last_ns = self._inline_declined_logged_ns.get(reason)
        if last_ns is not None and now_ns - last_ns < 60_000_000_000:
            return
        self._inline_declined_logged_ns[reason] = now_ns
        self.logger.record("fabric_inline_hold_declined", reason=reason)

    def _inline_wave_hold(
        self,
        operation: PendingOperation,
        plan: StagePlan,
        missing: Sequence[StagedBlock],
    ) -> bool:
        """Whether a put's un-uploaded blocks should wait for an inline batch."""

        reason = self._inline_put_decline_reason(plan, missing)
        if reason is not None:
            self._note_inline_declined(reason)
            return False
        now_ns = self._wall_now_ns()
        if len(self._inline_first_seen_ns) > 4096:
            self._inline_first_seen_ns.clear()
        since_ns = self._inline_first_seen_ns.setdefault(
            operation.mutation_id, now_ns
        )
        if now_ns - since_ns >= int(
            INLINE_HOLD_ABSOLUTE_MAX_SECONDS * 1_000_000_000
        ):
            # Ceiling: this put has waited far too long whatever the lane is
            # doing. Release it so it cannot starve behind larger cohorts.
            self._inline_first_seen_ns.pop(operation.mutation_id, None)
            return False
        # Valve proper: measured from the lane's last proven progress, so a
        # put waiting behind an in-flight batch is never released mid-flight.
        idle_from_ns = (
            since_ns
            if self._inline_last_progress_ns is None
            else max(since_ns, self._inline_last_progress_ns)
        )
        if now_ns - idle_from_ns >= int(INLINE_HOLD_MAX_SECONDS * 1_000_000_000):
            # Valve: the batch lane is not committing. Release to the classic
            # wave path so nothing can wedge behind the inline hold.
            self._inline_first_seen_ns.pop(operation.mutation_id, None)
            return False
        return True

    def _inline_put_decline_reason(
        self, plan: StagePlan, missing: Sequence[StagedBlock]
    ) -> str | None:
        """Why this put cannot ride one inline commit, or None when eligible.

        Keep the diagnostic gate and ticket exclusion on one decision: minting
        a capability for an inline companion creates unused reservation debt,
        while duplicating these conditions made that regression easy to
        reintroduce.
        """

        limit = self._inline_block_max_bytes
        # ``verify_on_commit`` and ``direct admission`` describe the v1 mutate
        # route: there, inline bytes still had to be admitted and verified
        # through the block lanes. The v2 commit performs the CAS PUT and the
        # readback itself, so requiring those v1 capabilities would decline
        # every inline put on a control plane that has no v1 mutate route at
        # all.
        on_v2 = self._v2_commit_active()
        admission = True if on_v2 else self._direct_block_admission()
        if limit <= 0:
            return "block_limit_zero"
        if not self._batching_enabled():
            return "batching_disabled"
        if not self._inline_supported_now():
            return "inline_unsupported"
        if not on_v2 and not self._mutate_verifies_blocks:
            return "verify_on_commit_disabled"
        if not admission:
            return "direct_admission_disabled"
        if any(block.size_bytes > limit for block in missing):
            return "block_over_limit"
        if (
            sum(block.size_bytes for block in missing)
            > self._effective_inline_request_budget_bytes()
        ):
            return "over_request_budget"
        if len({block.sha256 for block in plan.blocks}) > MAX_VERIFY_BLOCKS_PER_REQUEST:
            return "too_many_blocks"
        return None

    def _inline_put_eligible(
        self, plan: StagePlan, missing: Sequence[StagedBlock]
    ) -> bool:
        """Whether every missing byte can ride one bounded inline commit."""

        return self._inline_put_decline_reason(plan, missing) is None

    def _intrinsic_v2_blocks(self, plan: StagePlan) -> set[str]:
        # V2's authority excludes the canonical empty sentinel from required
        # CAS objects. Keep its descriptor, but never send zero bytes inline:
        # the inline parser rejects size=0 and that rejection would shrink
        # every unrelated small-file cohort's learned byte budget.
        # Derive this from the validated plan on every attempt/restart; no
        # fabricated upload receipt or persisted provider proof is needed.
        if (
            self._v2_commit_active()
            and plan.size_bytes == 0
            and plan.sha256 == _EMPTY_SHA256
            and len(plan.blocks) == 1
            and plan.blocks[0].size_bytes == 0
            and plan.blocks[0].sha256 == _EMPTY_SHA256
        ):
            return {_EMPTY_SHA256}
        return set()

    def _send_put(self, operation: PendingOperation) -> bool:
        stage_path, plan = self._load_and_fence_put_plan(operation)
        self._assert_mutation_namespace_capacity(operation, plan=plan)
        progress = self._put_progress(operation, stage_path)
        reusable = (
            self._reusable_target_blocks(operation.path)
            if progress["reuse_target_blocks"]
            else set()
        )
        reusable.update(self._intrinsic_v2_blocks(plan))
        verified = set(progress["verified"])
        if reusable:
            # The authority initializes proof only for digests present in both
            # the supplied base-head target and the still-current target.
            # Those exact target blocks need neither upload nor verify tickets.
            verified.update(reusable)
        receipts = progress["receipts"]
        ready_to_verify = list(
            {
                block.sha256: block
                for block in plan.blocks
                if block.sha256 in receipts and block.sha256 not in verified
            }.values()
        )
        satisfied = set(progress["uploaded"]) | reusable
        missing_by_digest = {
            block.sha256: block for block in plan.blocks if block.sha256 not in satisfied
        }
        missing = list(missing_by_digest.values())
        # A small put (its whole remaining proof fits one verify call) lets the
        # commit verify those blocks itself, saving a serialized signed round
        # trip per file. Larger files keep renewing proof wave by wave.
        commit_verifies = (
            bool(ready_to_verify)
            and not missing
            and self._commit_carries_verify_list()
            and len({block.sha256 for block in plan.blocks})
            <= MAX_VERIFY_BLOCKS_PER_REQUEST
            and {block.sha256 for block in plan.blocks} - verified
            == {block.sha256 for block in ready_to_verify}
        )
        if ready_to_verify and not commit_verifies and not self._commit_can_verify(plan):
            if (
                self._v2_commit_active()
                and not missing
                and len(ready_to_verify) <= FABRIC_V2_MAX_COMMIT_READBACKS
            ):
                # A single-path retry or disabled batching still has to make
                # progress: commit one classified readback cohort here rather
                # than returning an inflight row with no worker to drain it.
                entry = self._classify_commit_candidate(operation)
                if entry is not None:
                    self._send_commit_cohort([entry])
                    return True
            # Only files too large for one commit-time verification renew
            # server-side proof wave by wave; everything else proves every
            # block inside the commit, saving a serialized signed round trip.
            self._verify_put_receipts(
                operation,
                stage_path,
                progress,
                ready_to_verify[:MAX_VERIFY_BLOCKS_PER_REQUEST],
            )
            return False
        if (
            missing
            # A file forced off the inline lane (its own inline commit was
            # rejected as oversized) must NOT be held for a batch that would
            # only rebuild the same oversized commit. It proceeds straight to
            # the ticket wave below.
            and operation.mutation_id not in self._v2_inline_forced_upload
            and self._inline_wave_hold(operation, plan, missing)
        ):
            # Every remaining block can ride inline in a batch commit: hold
            # the ticket wave and let the batch lane take it. The journal row
            # stays sendable, so the next planner tick classifies it again;
            # after INLINE_HOLD_MAX_SECONDS the hold expires and the classic
            # wave path proceeds so nothing can wedge.
            return False
        if missing:
            if len(self._put_upload_states) >= UPLOAD_WORKER_CONCURRENCY:
                # Backpressure is not an operation failure. The immutable
                # stage and mutation remain sendable after a stream drains.
                return False
            # Staging ticket minting creates durable provider debt. Bootstrap
            # with one object, then issue every object (up to 256) that can
            # start within measured ticket headroom. Large source plans use
            # eight 16-MiB streams under the 128-MiB aggregate payload
            # ceiling; legacy 64-MiB plans stay two-stream and restart compatible.
            upload_concurrency = _upload_concurrency(plan)
            issue_count = self._put_upload_issue_count(
                missing,
                max_concurrency=upload_concurrency,
            )
            batch = missing[:issue_count]
            batch, tickets, lane = self._initial_put_write_tickets(
                operation,
                missing=missing,
                batch=batch,
                upload_concurrency=upload_concurrency,
            )
            expiry = min(_write_ticket_expiry(ticket) for ticket in tickets.values())
            headroom = expiry - (self._wall_now_ns() / 1_000_000_000)
            if (
                headroom <= 1.0
                or headroom > MAX_WRITE_TICKET_LIFETIME_SECONDS + 5.0
            ):
                raise NetworkError(
                    "Meshia returned an expired or excessive Fabric upload ticket."
                )
            self._put_upload_last_ticket_headroom = max(0.0, headroom)
            state = _PutUploadState(
                mutation_id=operation.mutation_id,
                stage_path=stage_path,
                plan=plan,
                max_concurrency=upload_concurrency,
                pending=deque(batch),
                tickets=tickets,
                expires_at_epoch=expiry,
                started_at=float(self._clock()),
                uploaded_unique_blocks_before=len(progress["uploaded"]),
                verified_unique_blocks_before=len(progress["verified"]),
            )
            self._put_upload_states[operation.mutation_id] = state
            self._schedule_put_upload_group(state)
            self.logger.record(
                "fabric_upload_wave_started",
                mutation_id=operation.mutation_id,
                path=operation.path,
                lane=lane,
                scheduled_blocks=len(batch),
                scheduled_bytes=sum(block.size_bytes for block in batch),
                max_concurrency=upload_concurrency,
                aggregate_buffer_limit_bytes=UPLOAD_RESIDENT_PAYLOAD_BYTES,
                active_file_streams=len(self._put_upload_states),
                ticket_headroom_ms=round(headroom * 1_000),
                uploaded_unique_blocks=len(progress["uploaded"]),
                verified_unique_blocks=len(progress["verified"]),
                total_unique_blocks=len({block.sha256 for block in plan.blocks}),
                reused_unique_blocks=len(
                    {block.sha256 for block in plan.blocks} & reusable
                ),
                reused_bytes=sum(
                    block.size_bytes
                    for block in {
                        block.sha256: block for block in plan.blocks
                    }.values()
                    if block.sha256 in reusable
                ),
            )
            # Byte work continues on daemon workers.  A callback wakes the
            # coordinator, which fsyncs exact receipts before another ticket
            # group or signed verification call is allowed to start.
            return False

        verify_missing = list(
            {
                block.sha256: block
                for block in plan.blocks
                if block.sha256 not in verified
            }.values()
        )
        if verify_missing and not commit_verifies:
            raise StateError(
                "The durable Fabric upload lost its exact attempt record."
            )

        # Every immutable block is now provider-verified (or, for a small
        # final wave, is verified inside the commit itself). Revalidate the
        # local identity once more so an edit during a long upload becomes a
        # clean successor instead of being mistaken for the committed snapshot.
        self._assert_source_backed_plan_current(plan)
        commit_blocks = list(ready_to_verify) if commit_verifies else None
        if commit_blocks:
            for block in commit_blocks:
                _durable_upload_part_receipt(
                    receipts[block.sha256],
                    expected_digest=block.sha256,
                    expected_size=block.size_bytes,
                )
        if self._v2_commit_active():
            # Every put whose bytes did not fit one inline commit lands here --
            # essentially every non-tiny file. Committing it on the v1 lane
            # under v2 is a guaranteed FABRIC_MUTATION_BASE_INVALID, so the
            # upload waves above would be paid for and then thrown away. The
            # cohort commits, acknowledges and records its verified blocks
            # through exactly the path a batched put uses.
            # `_commit_carries_verify_list()` is false under v2, so
            # `commit_blocks` is empty here and the entry asks the commit to
            # prove nothing it cannot carry. `_send_commit_v2`'s block-payload
            # fence enforces that rather than trusting it.
            self._send_commit_cohort([
                _BatchCommitEntry(operation=operation, plan=plan, stage_path=stage_path)
            ])
            self._metadata_split_repair_checked.discard(operation.mutation_id)
            self._put_progress_cache_key = None
            self._put_progress_cache = None
            return True
        try:
            receipt = self._send_path_mutation(
                operation, plan=plan, verify_blocks=commit_blocks
            )
        except RemoteError as error:
            if commit_blocks and _is_reupload_verification_error(error):
                # Drop only receipts the provider never confirmed (a severed
                # PUT recorded as "unknown"); a wave that has none of those
                # proves a confirmed object vanished, so everything re-uploads.
                if _demote_unconfirmed_receipts(progress) == 0:
                    progress["uploaded"].clear()
                    progress["receipts"].clear()
                    progress["reuse_target_blocks"] = False
                progress["verified"].clear()
                _write_progress(stage_path, operation.mutation_id, progress)
                raise
            if commit_blocks and error.status == 400:
                # An older control plane does not know verify_blocks (or
                # direct_blocks). The rejected request had no effect, so
                # finish this put the classic way right now and keep
                # verifying separately from here on. This disable used to be
                # silent AND permanent: a single self-inflicted 400 removed
                # verify-on-commit and direct admission -- both preconditions
                # of the inline lane -- for the rest of the process, with no
                # log line to show it had happened. Record it and re-probe.
                self._mutate_verifies_blocks = False
                self._direct_blocks_supported = False
                self._capability_disabled_at_ns = self._wall_now_ns()
                self.logger.record(
                    "fabric_commit_capabilities_disabled",
                    mutation_id=operation.mutation_id,
                    status=error.status,
                    detail=str(error)[:200],
                )
                self._verify_put_receipts(operation, stage_path, progress, commit_blocks)
                commit_blocks = None
                receipt = self._send_path_mutation(operation, plan=plan)
            else:
                raise
        if commit_blocks:
            _append_verified_upload_blocks(
                stage_path,
                operation.mutation_id,
                progress,
                tuple(block.sha256 for block in commit_blocks),
            )
        self.logger.record(
            "fabric_put_committed",
            mutation_id=operation.mutation_id,
            path=operation.path,
            size_bytes=plan.size_bytes,
            blocks=len({block.sha256 for block in plan.blocks}),
            verified_in_commit=len(commit_blocks or ()),
        )
        self._ack_mutation(
            operation,
            receipt,
            plan=plan,
            # Blocks left to ``verify_blocks`` on the commit route are NOT
            # counted as proven: that field is advisory and a control plane
            # may record the entry without checking the objects exist. Only a
            # completed HEAD through the dedicated verify endpoint counts.
            blocks_provider_verified=not commit_blocks,
        )
        self._metadata_split_repair_checked.discard(operation.mutation_id)
        self._put_progress_cache_key = None
        self._put_progress_cache = None
        return True


    # ---------------------------------------------------------- batch commits

    def _batching_enabled(self) -> bool:
        # v2 commits a cohort through ``commit_v2`` rather than
        # ``mutate_batch``. Gating on the v1 route alone would have turned the
        # inline lane off for every v2 process -- the batch is the only place
        # inline bytes ride.
        return self._mutate_batches and (
            getattr(self.transport, "mutate_batch", None) is not None
            or self._v2_commit_active()
        )

    def _operation_needs_single_path(
        self, operation: PendingOperation, head: RemoteManifestHead | None
    ) -> bool:
        """Operations the classic one-per-call path must own.

        Stale-index parking, authoritative-conflict markers, large-rename
        verification and directory renames all carry state machines of their
        own; they keep exact journal order through the single path.
        """

        if (
            operation.base_generation is not None
            and (head is None or head.generation < operation.base_generation)
        ):
            return True
        if operation.last_error is not None and (
            operation.last_error.startswith(_AUTHORITATIVE_BASE_DIVERGED_PREFIX)
            or operation.last_error.startswith(_AUTHORITATIVE_CONFLICT_PREFIX)
            or (
                operation.kind == "rename"
                and operation.last_error.startswith(_RENAME_VERIFY_PREFIX)
            )
        ):
            return True
        return bool(operation.directory_rename)

    def _classify_commit_candidate(
        self, operation: PendingOperation
    ) -> _BatchCommitEntry | None:
        """Return a commit-only entry, or None when the put still needs bytes.

        Mirrors the head of ``_send_put`` without issuing tickets: a put is
        ready when every block is uploaded and the commit itself can prove the
        last wave. Any exception means the single path must surface it.
        """

        if operation.kind != "put":
            if operation.kind == "rename":
                self._assert_mutation_namespace_capacity(operation, plan=None)
            return _BatchCommitEntry(operation=operation)
        stage_path, plan = self._load_and_fence_put_plan(operation)
        self._assert_mutation_namespace_capacity(operation, plan=plan)
        progress = self._put_progress(operation, stage_path)
        reusable = (
            self._reusable_target_blocks(operation.path)
            if progress["reuse_target_blocks"]
            else set()
        )
        reusable.update(self._intrinsic_v2_blocks(plan))
        verified = set(progress["verified"]) | reusable
        receipts = progress["receipts"]
        ready_to_verify = list(
            {
                block.sha256: block
                for block in plan.blocks
                if block.sha256 in receipts and block.sha256 not in verified
            }.values()
        )
        satisfied = set(progress["uploaded"]) | reusable
        missing = list({
            block.sha256: block
            for block in plan.blocks
            if block.sha256 not in satisfied
        }.values())
        if not missing:
            # Every block is uploaded, so this put commits by verify -- a small
            # request. Any inline-force marker has served its purpose; drop it so
            # the set stays bounded to files still working through the wave.
            self._v2_inline_forced_upload.discard(operation.mutation_id)
        inline_payload: tuple[tuple[StagedBlock, bytes], ...] = ()
        if missing:
            # Un-uploaded small blocks may ride inline in the batch commit:
            # the control plane admits, PUTs, verifies, and records them in
            # the same call, so the put never pays a ticket wave at all.
            #
            # A file whose own one-item inline commit the edge already rejected
            # (`_shrink_v2_request_budget` bottomed out and marked it) is barred
            # from inline here: returning None routes it to the upload lane,
            # where its blocks upload and the commit proves them by verify -- a
            # small request that fits. Retrying inline would replay the exact
            # oversized commit it just failed.
            if (
                operation.mutation_id in self._v2_inline_forced_upload
                or not self._inline_put_eligible(plan, missing)
            ):
                return None
            loaded: list[tuple[StagedBlock, bytes]] = []
            for block in missing:
                loaded.append((block, self._read_plan_block(plan, stage_path, block)))
            inline_payload = tuple(loaded)
            ready_to_verify = list({
                block.sha256: block
                for block in (*ready_to_verify, *missing)
            }.values())
        unique = {block.sha256 for block in plan.blocks}
        inline_shas = {block.sha256 for block, _data in inline_payload}
        commit_verifies = (
            bool(ready_to_verify)
            and self._commit_carries_inline_bytes()
            and len(unique) <= MAX_VERIFY_BLOCKS_PER_REQUEST
            and unique - verified == {block.sha256 for block in ready_to_verify}
            # V2 has no client verify-list. Keep commit_blocks restricted to
            # inline bytes; durable uploaded blocks use readback_blocks below,
            # and the server derives their presence proof from the validated
            # op descriptors, never from a client verification assertion.
            and (
                not self._v2_commit_active()
                or {block.sha256 for block in ready_to_verify} <= inline_shas
            )
        )
        v2_proves_blocks = (
            self._v2_commit_active()
            and bool(ready_to_verify)
            and len(ready_to_verify) <= FABRIC_V2_MAX_COMMIT_READBACKS
            and unique - verified == {block.sha256 for block in ready_to_verify}
        )
        if inline_payload and not (commit_verifies or v2_proves_blocks):
            return None
        if ready_to_verify and not (commit_verifies or v2_proves_blocks):
            return None
        if any(block.sha256 not in verified for block in plan.blocks) and not (
            commit_verifies or v2_proves_blocks
        ):
            return None
        self._assert_source_backed_plan_current(plan)
        commit_blocks = tuple(
            block for block in ready_to_verify
            if commit_verifies or block.sha256 in inline_shas
        )
        readback_blocks = tuple(
            block for block in ready_to_verify
            if v2_proves_blocks and block.sha256 not in inline_shas
        )
        for block in (*commit_blocks, *readback_blocks):
            receipt_document = receipts.get(block.sha256)
            if receipt_document is None:
                # Inline blocks carry their bytes, not upload receipts.
                if block.sha256 not in inline_shas:
                    raise StateError("A Fabric commit readback lost its durable upload receipt.")
                continue
            _durable_upload_part_receipt(
                receipt_document,
                expected_digest=block.sha256,
                expected_size=block.size_bytes,
            )
        return _BatchCommitEntry(
            operation=operation,
            plan=plan,
            stage_path=stage_path,
            commit_blocks=commit_blocks,
            inline_blocks=inline_payload,
            readback_blocks=readback_blocks,
        )

    def _delete_cohort_lingers(
        self, ready: Sequence[_BatchCommitEntry], *, now_ns: int, limit: int
    ) -> bool:
        """Coalesce journaled deletes using the existing bounded linger clock.

        Native unlink is already durable and visible locally. Sending every
        singleton immediately contends with the next native callback and turns
        a recursive delete into one signed HTTP request per one or two files.
        Only homogeneous v2 delete cohorts linger; mixed work and dependency
        fences keep their existing scheduling and order.
        """

        if (
            not self._v2_commit_active()
            or not ready
            or len(ready) >= limit
            or any(entry.operation.kind != "delete" for entry in ready)
        ):
            return False
        if len(self._inline_first_seen_ns) > 4096:
            self._inline_first_seen_ns.clear()
        seen = [
            self._inline_first_seen_ns.setdefault(entry.operation.mutation_id, now_ns)
            for entry in ready
        ]
        deadline_ns = min(
            max(seen) + int(INLINE_SINGLE_FLUSH_SECONDS * 1_000_000_000),
            min(seen) + int(INLINE_COALESCE_MAX_SECONDS * 1_000_000_000),
        )
        if now_ns >= deadline_ns:
            self._inline_flush_not_before = None
            return False
        self._inline_flush_not_before = float(self._clock()) + (
            deadline_ns - now_ns
        ) / 1_000_000_000
        return True

    def _plan_commit_batch(
        self, *, exclude: set[str] = frozenset(), uploading: bool
    ) -> list[_BatchCommitEntry]:
        """Select and claim the ready commits that should ride one batch now.

        With uploads still pending (``uploading`` or a queued put that needs
        bytes), ready commits keep accumulating until the server bound or
        the protocol's bounded coalescing window; with nothing else uploading,
        two or more ready commits leave immediately.
        """

        now_ns = self._wall_now_ns()
        candidates = self.database.list_sendable_operations(
            limit=self._v2_candidate_fetch_limit(), now_ns=now_ns
        )
        head = self.database.get_remote_manifest_head()
        ready: list[_BatchCommitEntry] = []
        pending_upload = uploading
        pending_upload_candidates = 0
        inline_budget_used = 0
        bulk_wire_used = 0
        readback_used = 0
        saw_inline = False
        for operation in candidates:
            if operation.mutation_id in exclude or operation.mutation_id in self._put_upload_states:
                continue
            if self._operation_needs_single_path(operation, head):
                continue
            try:
                entry = self._classify_commit_candidate(operation)
            except FileProviderSourceUnavailable as error:
                self.database.update_operation(
                    operation.mutation_id,
                    state="retry",
                    error=str(error),
                    retry_after_seconds=60.0,
                    reset_failures=True,
                    now_ns=self._wall_now_ns(),
                )
                continue
            except (
                SourceDrift,
                OSError,
                InvalidTask,
                StateError,
                UnsafePath,
                ValueError,
                StagingRepairPending,
            ):
                continue
            if entry is None:
                pending_upload = True
                pending_upload_candidates += 1
                # Plan one byte-worker wave, not every not-yet-uploaded file
                # in the 1024-row metadata page on every tick. Ready cohorts
                # can still fill the full server cap; queued byte work drains
                # in journal order through the ordinary admission lane.
                if (
                    self._v2_commit_active()
                    and pending_upload_candidates >= DIRECT_UPLOAD_MAX_ACTIVE
                ):
                    break
                continue
            if entry.inline_blocks:
                saw_inline = True
                if self._v2_commit_active():
                    # Size by the REAL serialized wire (op path/blocks + base64
                    # payload), not raw source bytes with a flat op reservation:
                    # item count is the wrong knob for mixed sizes, and the
                    # flat reservation under-counts long copy-paths -- the case
                    # that tripped the edge body limit and sawtoothed.
                    entry_cost = self._v2_inline_entry_wire_estimate(entry)
                    budget_bytes = self._v2_lane_budget("inline")["wire_bytes"]
                else:
                    entry_cost = sum(
                        len(data) for _block, data in entry.inline_blocks
                    )
                    budget_bytes = self._effective_inline_request_budget_bytes()
                if inline_budget_used + entry_cost > budget_bytes:
                    # Over what one request can carry: this put waits for the
                    # next batch round rather than falling back to waves.
                    pending_upload = True
                    continue
                inline_budget_used += entry_cost
            elif self._v2_commit_active():
                # Bulk (descriptor-only) op: keep the cohort under the bulk
                # wire budget so a member with a long block list cannot push
                # the body past the edge's 413 threshold before it is even sent.
                entry_wire = self._v2_bulk_entry_wire_estimate(entry)
                if (
                    ready
                    and bulk_wire_used + entry_wire
                    > self._v2_lane_budget("bulk")["wire_bytes"]
                ):
                    pending_upload = True
                    continue
                bulk_wire_used += entry_wire
            if self._v2_commit_active():
                # One commit may prove at most FABRIC_V2_MAX_COMMIT_READBACKS
                # unproven blocks; a cohort over that budget chunks into the next
                # round rather than being rejected FABRIC_BLOCK_PROOF_REQUIRED.
                readback_cost = self._v2_entry_readback_cost(entry)
                if (
                    ready
                    and readback_used + readback_cost > FABRIC_V2_MAX_COMMIT_READBACKS
                ):
                    pending_upload = True
                    continue
                readback_used += readback_cost
            ready.append(entry)
            # Stop classifying once the widest lane this cohort could use is
            # full; the slice below enforces the exact cap, this only bounds the
            # per-tick classification work when the backlog is deep.
            if self._v2_commit_active() and len(ready) >= self._v2_item_cap(
                "inline" if saw_inline else "bulk"
            ):
                break
        if not ready:
            return []
        waited_ns = now_ns - min(
            entry.operation.ready_at_ns
            if entry.operation.ready_at_ns is not None
            else entry.operation.created_at_ns
            for entry in ready
        )
        # On v2 the cohort is bounded by the v2 lane cap ALONE: the v1
        # `_batch_size_limit`/`_batch_item_cap` are the v1 mutate_batch route's
        # adaptive controls (transport-failure and 413 backoff), which the v2
        # commit path never touches, so folding them in here pinned every v2
        # cohort at the v1 default of 64 no matter the lane.
        if self._v2_commit_active():
            limit = self._v2_item_cap(self._v2_lane_of(ready))
        else:
            limit = min(self._batch_size_limit, self._batch_item_cap)
        if limit < 2:
            return []
        if self._delete_cohort_lingers(ready, now_ns=now_ns, limit=limit):
            return []
        flush = (
            len(ready) >= limit
            or waited_ns >= int(
                (V2_BATCH_COMMIT_MAX_WAIT_SECONDS if self._v2_commit_active()
                 and any(not entry.inline_blocks for entry in ready)
                 else BATCH_COMMIT_MAX_WAIT_SECONDS) * 1_000_000_000
            )
            or (not pending_upload and len(ready) >= 2)
            # The bounded delete linger above already expired. Unrelated byte
            # uploads must not extend a namespace-only commit to the 30s valve.
            or (self._v2_commit_active() and all(entry.operation.kind == "delete" for entry in ready))
        )
        if not flush:
            return []
        selected = ready[:limit]
        claimed = {
            operation.mutation_id: operation
            for operation in self.database.claim_operations(
                [entry.operation.mutation_id for entry in selected], now_ns=now_ns
            )
        }
        return [
            replace(entry, operation=claimed[entry.operation.mutation_id])
            for entry in selected
            if entry.operation.mutation_id in claimed
        ]

    def _plan_mutation_turn(
        self,
    ) -> tuple[str, list[_BatchCommitEntry]] | None:
        """Decide this tick's signed mutation turn.

        Returns ``("batch", entries)`` for a claimed batch, ``("single",
        [entry])`` for one claimed operation the classic path must send (a put
        that needs bytes, or a special-cased row), or None when nothing is
        sendable.
        """

        now_ns = self._wall_now_ns()
        candidates = self.database.list_sendable_operations(
            limit=self._v2_candidate_fetch_limit(), now_ns=now_ns
        )
        candidates = [item for item in candidates
                      if item.mutation_id not in self._put_upload_states]
        if not candidates:
            # Nothing is lingering. The burst window is deliberately NOT reset
            # here: it expires on its own so a slow trickle still coalesces.
            self._inline_flush_not_before = None
            return None
        head = self.database.get_remote_manifest_head()
        oldest = candidates[0]
        if self._operation_needs_single_path(oldest, head):
            return self._claim_single_turn(oldest, now_ns)
        ready: list[_BatchCommitEntry] = []
        needs_upload: list[PendingOperation] = []
        # Inline bytes are budgeted per REQUEST, never per cohort: a folder
        # larger than one request streams as consecutive inline batches. The
        # loop also stops classifying once the budget is full, so peak buffered
        # bytes stay bounded by the budget plus the one entry that crossed it
        # (a 510-file drop must never be read into memory at once).
        inline_budget_used = 0
        inline_deferred = False
        bulk_wire_used = 0
        readback_used = 0
        saw_inline = False
        for operation in candidates:
            if self._operation_needs_single_path(operation, head):
                continue
            try:
                entry = self._classify_commit_candidate(operation)
            except FileProviderSourceUnavailable as error:
                self.database.update_operation(
                    operation.mutation_id,
                    state="retry",
                    error=str(error),
                    retry_after_seconds=60.0,
                    reset_failures=True,
                    now_ns=self._wall_now_ns(),
                )
                if operation.mutation_id == oldest.mutation_id:
                    return []
                continue
            except (
                SourceDrift,
                OSError,
                InvalidTask,
                StateError,
                UnsafePath,
                ValueError,
                StagingRepairPending,
            ):
                if operation.mutation_id == oldest.mutation_id:
                    return self._claim_single_turn(operation, now_ns)
                continue
            if entry is None:
                needs_upload.append(operation)
                if (
                    self._v2_commit_active()
                    and len(needs_upload) >= DIRECT_UPLOAD_MAX_ACTIVE
                ):
                    break
                continue
            if entry.inline_blocks:
                saw_inline = True
                if self._v2_commit_active():
                    # Size by the REAL serialized wire, not raw source bytes
                    # with a flat op reservation (see `_plan_commit_batch`).
                    entry_cost = self._v2_inline_entry_wire_estimate(entry)
                    budget_bytes = self._v2_lane_budget("inline")["wire_bytes"]
                else:
                    entry_cost = sum(
                        len(data) for _block, data in entry.inline_blocks
                    )
                    budget_bytes = self._effective_inline_request_budget_bytes()
                if ready and inline_budget_used + entry_cost > budget_bytes:
                    # This request is full. The remainder rides the next tick;
                    # dropping the entry releases its bytes immediately.
                    inline_deferred = True
                    break
                inline_budget_used += entry_cost
            elif self._v2_commit_active():
                # Bulk (descriptor-only) op: bound the cohort by the bulk wire
                # budget so a member with a long block list cannot push the
                # body over the edge's 413 threshold before it is even sent.
                entry_wire = self._v2_bulk_entry_wire_estimate(entry)
                if (
                    ready
                    and bulk_wire_used + entry_wire
                    > self._v2_lane_budget("bulk")["wire_bytes"]
                ):
                    inline_deferred = True
                    break
                bulk_wire_used += entry_wire
            if self._v2_commit_active():
                # One commit may prove at most FABRIC_V2_MAX_COMMIT_READBACKS
                # unproven blocks; a cohort over that budget chunks into the next
                # tick rather than being rejected FABRIC_BLOCK_PROOF_REQUIRED.
                readback_cost = self._v2_entry_readback_cost(entry)
                if (
                    ready
                    and readback_used + readback_cost > FABRIC_V2_MAX_COMMIT_READBACKS
                ):
                    inline_deferred = True
                    break
                readback_used += readback_cost
            ready.append(entry)
            # Stop classifying once the widest lane this cohort could use is
            # full; the slice below enforces the exact cap, this only bounds
            # per-tick classification (and inline byte reads) on a deep backlog.
            if self._v2_commit_active() and len(ready) >= self._v2_item_cap(
                "inline" if saw_inline else "bulk"
            ):
                break
        if ready:
            waited_ns = now_ns - min(
                entry.operation.ready_at_ns
                if entry.operation.ready_at_ns is not None
                else entry.operation.created_at_ns
                for entry in ready
            )
            # On v2 the cohort is bounded by the v2 lane cap ALONE (see
            # `_plan_commit_batch`): the v1 batch caps never govern a v2 commit.
            if self._v2_commit_active():
                limit = self._v2_item_cap(self._v2_lane_of(ready))
            else:
                limit = min(self._batch_size_limit, self._batch_item_cap)
            if self._delete_cohort_lingers(ready, now_ns=now_ns, limit=limit):
                if needs_upload:
                    return self._claim_single_turn(needs_upload[0], now_ns)
                return None
            # A lone inline entry must NOT degrade to the classic single path
            # (that discards the classified bytes and starts ticket waves —
            # the exact regression seen live). It lingers briefly for
            # companions, then rides a one-item batch.
            all_inline = limit >= 2 and all(
                entry.inline_blocks for entry in ready
            )
            inline_quiescent = False
            inline_capped = False
            inline_burst_opening = False
            if all_inline:
                if len(self._inline_first_seen_ns) > 4096:
                    self._inline_first_seen_ns.clear()
                seen = [
                    self._inline_first_seen_ns.setdefault(
                        entry.operation.mutation_id, now_ns
                    )
                    for entry in ready
                ]
                # A new arrival restarts the window: flush only once no new
                # inline item has appeared for the linger, or the cohort has
                # coalesced for the cap.
                inline_quiescent = (
                    now_ns - max(seen)
                    >= int(INLINE_SINGLE_FLUSH_SECONDS * 1_000_000_000)
                )
                inline_capped = (
                    now_ns - min(seen)
                    >= int(INLINE_COALESCE_MAX_SECONDS * 1_000_000_000)
                )
                # The cohort that OPENS a burst never lingers. Coalescing
                # buys request count, which only matters across the long tail
                # of a drop; the first commit is the one a person is watching
                # for, and holding it is exactly the "it just sits there" the
                # linger was never meant to cause. Once open, the window
                # applies normally for the rest of the drop, so an 80k-file
                # folder keeps its batching and pays one extra signed request.
                inline_burst_opening = now_ns >= self._inline_burst_open_until_ns
            flush = (
                len(ready) >= limit
                or waited_ns >= int(
                    (V2_BATCH_COMMIT_MAX_WAIT_SECONDS if self._v2_commit_active()
                     and not all_inline
                     else BATCH_COMMIT_MAX_WAIT_SECONDS) * 1_000_000_000
                )
                or (self._v2_commit_active() and all(entry.operation.kind == "delete" for entry in ready))
                # The per-request inline budget is full: send it and let the
                # next tick carry the rest of the folder.
                or inline_deferred
                or (not needs_upload and not all_inline and len(ready) >= 2)
                # An inline cohort is complete in itself (its bytes ride the
                # request), so it must not linger behind unrelated puts that
                # still need upload waves.
                or (
                    all_inline
                    and (inline_quiescent or inline_capped or inline_burst_opening)
                )
                or (
                    not needs_upload
                    and len(ready) == 1
                    and not ready[0].inline_blocks
                )
            )
            if flush:
                # Whatever this turn returns, the linger is no longer holding
                # anything back, and the burst is open for the coalesce cap --
                # long enough to cover the gaps in a Finder-paced drop.
                self._inline_flush_not_before = None
                self._inline_burst_open_until_ns = now_ns + int(
                    INLINE_COALESCE_MAX_SECONDS * 1_000_000_000
                )
                # A v2 inline entry commits ONLY through a cohort -- the single
                # lane holds it (`_inline_wave_hold`) rather than commit it. So
                # when the request budget has shrunk the cap to one (a 413 split
                # bottoming out), the working route is a one-item BATCH that
                # carries the inline bytes, never the single lane. Diverting a
                # lone inline v2 entry to `_claim_single_turn` here is exactly
                # what livelocked a folder drop: the cap floored, the single
                # lane held, and nothing ever committed.
                v2_inline_singleton = (
                    self._v2_commit_active() and bool(ready[0].inline_blocks)
                )
                if not v2_inline_singleton and (
                    limit < 2
                    or (
                        len(ready) == 1
                        and not ready[0].inline_blocks
                        # Under v2 the single lane cannot commit at all, and
                        # dropping to it would also discard this classification.
                        and not self._v2_commit_active()
                    )
                ):
                    return self._claim_single_turn(ready[0].operation, now_ns)
                selected = ready[:limit]
                claimed = {
                    operation.mutation_id: operation
                    for operation in self.database.claim_operations(
                        [entry.operation.mutation_id for entry in selected],
                        now_ns=now_ns,
                    )
                }
                batch = [
                    replace(entry, operation=claimed[entry.operation.mutation_id])
                    for entry in selected
                    if entry.operation.mutation_id in claimed
                ]
                for entry in batch:
                    self._inline_first_seen_ns.pop(entry.operation.mutation_id, None)
                if len(batch) >= 2:
                    return ("batch", batch)
                if len(batch) == 1:
                    # A one-item batch keeps the inline bytes; a plain single
                    # turn would re-plan without them. Under v2 the single lane
                    # cannot commit at all, so a cohort of one is the only
                    # working route regardless of inline bytes.
                    if batch[0].inline_blocks or self._v2_commit_active():
                        return ("batch", batch)
                    return ("single", batch)
                return None
            if all_inline:
                # Not flushing: the ONLY thing standing between this ready
                # cohort and the wire is wall-clock. Publish the exact
                # deadline so the runner can sleep to it instead of re-asking.
                # Both terms are already-computed policy: quiescence measured
                # from the newest arrival, and the coalesce cap from the
                # oldest. Whichever comes first ends the hold.
                quiescent_at_ns = max(seen) + int(
                    INLINE_SINGLE_FLUSH_SECONDS * 1_000_000_000
                )
                capped_at_ns = min(seen) + int(
                    INLINE_COALESCE_MAX_SECONDS * 1_000_000_000
                )
                remaining_ns = min(quiescent_at_ns, capped_at_ns) - now_ns
                # A duration, never a timestamp: the journal's wall clock and
                # the coordinator's monotonic clock stay in separate domains.
                self._inline_flush_not_before = float(self._clock()) + max(
                    0.0, remaining_ns / 1_000_000_000
                )
            else:
                self._inline_flush_not_before = None
        if needs_upload:
            # Start the next upload; ready commits accumulate behind it and
            # leave together once nothing else needs bytes (or the wait cap).
            return self._claim_single_turn(needs_upload[0], now_ns)
        return None

    def _claim_single_turn(
        self, operation: PendingOperation, now_ns: int
    ) -> tuple[str, list[_BatchCommitEntry]] | None:
        claimed = self.database.claim_operations([operation.mutation_id], now_ns=now_ns)
        if not claimed:
            return None
        return ("single", [_BatchCommitEntry(operation=claimed[0])])

    def _send_commit_cohort(self, entries: Sequence[_BatchCommitEntry]) -> None:
        """Route a claimed cohort to the v2 or v1 commit path.

        V2 carries inline bytes explicitly and proves uploaded descriptors
        server-side. Its dispatcher retains the byte-payload fence; neither
        path may silently discard a client verify-list or unsent inline bytes.
        """

        if self._v2_commit_active():
            self._send_commit_v2(entries)
            return
        self._send_commit_batch(entries)

    def _v2_commit_active(self) -> bool:
        """Whether cohorts commit through the v2 per-path log path.

        The single source of truth for that routing decision, so preflights
        can ask the same question the dispatcher answers instead of
        re-deriving it and drifting.
        """

        return bool(
            self._fabric_v2_enabled and getattr(self.transport, "commit_v2", None)
        )

    def _recover_v2_commit_fence(self, operation: PendingOperation) -> None:
        """Resolve a v2 fence that outlived the process that wrote it.

        A crash between the FULL-synchronous fence and the commit response
        leaves commit_unknown set with a v2 digest. The v1 readback lane would
        then ask ``mutation_status`` -- which knows nothing of v2 cohort ids --
        and, on the resulting miss, rebuild a v1 request document to compare
        against a v2 digest. That comparison can never match, so every crash
        mid-v2-commit terminally conflicted the operation, whether or not the
        commit had actually applied.

        v2 needs no status route to resolve this. The cohort id is derived
        from the request and the server records one verdict per mutation id,
        so resending the identical cohort replays that verdict rather than
        applying a second time.
        """

        if self._v2_commit_active():
            self.database.clear_operation_commit_unknown_for_retry(
                operation.mutation_id,
                reason="v2 commit fence recovered; the idempotent cohort will replay",
                now_ns=self._wall_now_ns(),
                preserve_batch_id=True,
            )
            self.logger.record(
                "fabric_v2_commit_fence_recovered",
                mutation_id=operation.mutation_id,
                lane="v2",
            )
            return
        # v2 is unavailable to this process, so the retry will be built by v1,
        # whose fence cannot match a v2 digest. Release it whole rather than
        # strand the file: the v1 mutation carries its own path preimage
        # expectation, so a v2 commit that did land is rejected as a conflict
        # instead of being applied twice.
        assert operation.request_digest is not None
        self.database.release_unroutable_commit_fence(
            operation.mutation_id,
            expected_request_digest=operation.request_digest,
            reason="v2 commit fence unresolvable without the v2 lane",
            now_ns=self._wall_now_ns(),
        )
        self.logger.record(
            "fabric_v2_commit_fence_recovered",
            mutation_id=operation.mutation_id,
            lane="v1",
        )

    def _send_commit_v2(self, entries: Sequence[_BatchCommitEntry]) -> None:
        """Commit a claimed cohort through the Fabric v2 log-structured path.

        One signed request carries one op per touched path. There is no
        manifest preimage, so the body is O(changed) rather than O(namespace)
        -- which is both the performance change and the reason
        PAYLOAD_TOO_LARGE cannot arise from bookkeeping any more.

        The server takes a single mutation id for the cohort and returns a
        per-op verdict, which is exactly the shape the v20 batch fence already
        models: every member is marked commit-unknown under one batch id
        before the POST, so a lost response is read back rather than resent.
        """

        if not entries:
            return
        prepared = list(entries)
        try:
            ops = self._v2_commit_ops(prepared)
        except (StateError, InvalidTask, ValueError) as error:
            for entry in prepared:
                self._defer_commit_unknown(entry.operation, error)
            return

        # Bytes for blocks the provider does not have yet, shipped inside the
        # commit. This is what makes a folder of tiny files fast: without it
        # each 64-byte file pays a ticket mint, a PUT, a receipt and a verify
        # -- four signed control calls per file -- and a backlog drains at the
        # rate of the ticket lane rather than the rate of the commit.
        #
        # The server hashes what it receives, PUTs it into CAS and reads it
        # back before the entry is recorded, so shipping bytes here is not a
        # shortcut around the block-existence check: it is how a block passes
        # that check without a separate round trip.
        inline_blocks = (
            self._v2_inline_blocks(prepared, ops)
            if self._commit_carries_inline_bytes()
            else []
        )
        # An op whose inline bytes did not fit would be committed against a
        # block nobody uploaded, and the commit rejects exactly that -- every
        # time, because the next attempt re-plans the identical cohort. The
        # planner sizes cohorts to fit, so a shortfall here is a mis-sizing;
        # it is acted on below, once the cohort is fenced, because the release
        # that re-arms it is only valid on a fenced operation.
        wanted_inline = {
            block.sha256 for entry in prepared for block, _data in entry.inline_blocks
        }
        carried_inline = {str(item["sha256"]) for item in inline_blocks}

        # THE BLOCK-PAYLOAD FENCE.
        #
        # Its property is unchanged and must never be dropped: never send a
        # cohort whose block payload the wire cannot deliver, because a server
        # that does not receive those bytes still commits the entry, and the
        # result is a durable file whose content is not in object storage.
        #
        # What changed is the test. It used to be "does this entry carry a
        # payload at all", which was exact when the v2 wire had no byte
        # channel. Now it has one, so carrying a payload is no longer the same
        # thing as being undeliverable, and the honest test is COVERAGE: every
        # block this cohort asks the commit to account for must ride inline in
        # THIS request. That is strictly stronger than the old rule for the
        # case that mattered -- it catches a payload that was built but did
        # not fit, which "carries a payload" never could.
        #
        # It still fires whole for a control plane without the inline channel:
        # `_commit_carries_inline_bytes()` is false there, so `carried_inline`
        # is empty and any entry with a payload is refused, exactly as before.
        # Two distinct undeliverable shapes, and only these two:
        #
        #   channel absent  -- this control plane takes no inline bytes, so a
        #                      payload of any kind cannot be transmitted;
        #   verify list     -- the entry asks the commit to account for a block
        #                      it is NOT shipping, and the v2 wire has no field
        #                      for that request.
        #
        # A payload the node BUILT but could not fit in one request is a third
        # thing and is deliberately not handled here: shrinking and re-riding
        # is a better answer than parking, and it happens below, once the
        # cohort is fenced, because the release that re-arms it is only valid
        # on a fenced operation.
        if not self._commit_carries_inline_bytes():
            undeliverable = [
                entry for entry in prepared
                if entry.inline_blocks or entry.commit_blocks
            ]
        else:
            undeliverable = [
                entry for entry in prepared
                if {block.sha256 for block in entry.commit_blocks}
                - {block.sha256 for block, _data in entry.inline_blocks}
            ]
        if undeliverable:
            for entry in undeliverable:
                self.logger.record(
                    "fabric_v2_commit_refused_undeliverable_blocks",
                    mutation_id=entry.operation.mutation_id,
                    path=entry.operation.path,
                    inline_blocks=len(entry.inline_blocks),
                    commit_blocks=len(entry.commit_blocks),
                    carried_inline=len(carried_inline),
                )
            for entry in prepared:
                self._schedule_operation_retry(
                    entry.operation,
                    StateError(
                        "A Fabric v2 commit cannot carry block bytes this "
                        "request did not ship; the blocks must ride inline or "
                        "be verified before the commit."
                    ),
                )
            return

        # Payload identity and operation identity are different: recreating
        # identical bytes after deletion is a NEW operation with the same
        # semantic payload. Bind the idempotency key to durable journal IDs,
        # while retries (including inline downgrade) retain the same identity.
        request_digest = _fabric_v2_request_digest(self.authority.session_id, ops)
        retained_ids = {entry.operation.commit_batch_id for entry in prepared}
        batch_id = (
            next(iter(retained_ids))
            if len(retained_ids) == 1 and None not in retained_ids
            and all(entry.operation.request_digest == request_digest for entry in prepared)
            else _v2_cohort_mutation_id(
                request_digest, [
                    # A rejected operation's durable renewal seed is folded
                    # into a UUID5, never sent as the UUID4 seed itself: crash
                    # recovery distinguishes v2 fences by UUID version.
                    entry.operation.commit_batch_id or entry.operation.mutation_id
                    for entry in prepared
                ]
            )
        )
        self.database.mark_operations_commit_unknown(
            [(entry.operation.mutation_id, request_digest) for entry in prepared],
            batch_id=batch_id,
            now_ns=self._wall_now_ns(),
        )
        if (
            wanted_inline
            and self._commit_carries_inline_bytes()
            and carried_inline != wanted_inline
        ):
            # Shrink and re-ride rather than send ops the server must refuse.
            # Nothing has been sent, so the fence is released whole.
            self._shrink_v2_request_budget(
                prepared,
                request_digest=request_digest,
                reason="cohort inline bytes exceeded one request",
                carried=len(carried_inline),
                wanted=len(wanted_inline),
            )
            return
        started = float(self._clock())
        try:
            response = self._signed_control_request(
                self.transport.commit_v2,  # type: ignore[attr-defined]
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "mutation_id": batch_id,
                    "request_digest": request_digest,
                    "ops": ops,
                    # Upload verification is per file, but the namespace
                    # receipt is per cohort. Preserve the exact association
                    # so applied puts release their admission slots; without
                    # it 64 successful v2 puts exhaust the v1 proof limit.
                    # This is receipt metadata, not a namespace operation:
                    # keep the existing digest/frozen-fence identity intact.
                    "verification_mutation_ids": [
                        entry.operation.mutation_id
                        if entry.operation.kind == "put" else None
                        for entry in prepared
                    ],
                    # Omitted entirely when empty: an older control plane
                    # refuses unlisted fields outright, so the wire an
                    # inline-free cohort presents is the one it always was.
                    **({"inline_blocks": inline_blocks} if inline_blocks else {}),
                },
            )
        except RemoteError as error:
            if error.remote_code in {
                "FABRIC_VERIFICATION_IDENTITY_INVALID",
                "FABRIC_VERIFICATION_TARGET_MISMATCH",
                "FABRIC_VERIFICATION_REPLAY_CONFLICT",
            }:
                # An exact receipt association cannot heal by resending or
                # inventing a new identity. Preserve staged bytes as a visible
                # conflict, including the frozen cohort identity for diagnosis.
                # A prior replay may already have committed; this is not an ACK
                # and never deletes the local user's recovery evidence.
                for entry in prepared:
                    self._record_operation_conflict(
                        entry.operation,
                        f"{error.remote_code} for cohort {batch_id}: {error}",
                    )
                return
            if error.remote_code == "FABRIC_BLOCK_WRITE_AUTHORITY_STALE":
                # The native commit wrapper rejected the transaction before
                # publishing any member. Renew authority and retry the same
                # durable operation IDs with ordinary bounded backoff.
                self._force_full_remote = True
                self._next_remote_poll = 0.0
                for entry in prepared:
                    self.database.clear_operation_commit_unknown_for_retry(
                        entry.operation.mutation_id,
                        reason="v2 verification authority rejected the commit",
                        now_ns=self._wall_now_ns(),
                    )
                    self._schedule_operation_retry(entry.operation, error)
                return
            if inline_blocks and _is_inline_payload_oversized(error):
                # The channel works; this request was too big for the edge.
                # Shrinking and re-riding is the whole difference between a
                # slower next attempt and the v1 incident where an oversized
                # request rebuilt forever. Nothing was applied.
                self._shrink_v2_request_budget(
                    prepared,
                    request_digest=request_digest,
                    reason="v2 commit payload rejected as too large",
                    status=error.status,
                    inline_blocks=len(inline_blocks),
                )
                return
            if not inline_blocks and _is_inline_payload_oversized(error):
                # A BULK (descriptor-only) cohort now carries up to
                # SERVER_MAX_V2_COMMIT_OPS ops, so for the first time it can
                # exceed the edge body limit -- an unusually long block list on
                # one member. Shrink the bulk lane and re-ride, exactly as the
                # inline lane does, so one 413 never becomes the identical-
                # request hot loop the wider ceiling would otherwise risk.
                # Nothing was applied: the edge rejects the body before any
                # handler runs. `_shrink_v2_request_budget` reads the lane from
                # `prepared` (no inline bytes -> bulk), so it shrinks the right
                # lane's item cap and byte budget.
                self._shrink_v2_request_budget(
                    prepared,
                    request_digest=request_digest,
                    reason="v2 bulk commit payload rejected as too large",
                    status=error.status,
                    lane_hint="bulk",
                )
                return
            if _is_v2_block_proof_required(error):
                # The cohort named more unproven blocks than one commit may read
                # back (FABRIC_V2_MAX_COMMIT_READBACKS). Nothing was applied --
                # the check runs before any op is recorded -- so it is exactly a
                # 413 in a different currency: shrink the lane and re-ride so the
                # cohort carries fewer unproven blocks, never re-plan the
                # identical over-budget request forever.
                self._shrink_v2_request_budget(
                    prepared,
                    request_digest=request_digest,
                    reason="v2 commit exceeded the unproven-block readback budget",
                    status=error.status,
                    code=_remote_code(error),
                )
                return
            if _is_v2_commit_gateway_timeout(error) and len(prepared) > 1:
                # A proxy cut the call before the origin answered on a MULTI-op
                # cohort -- very likely the route deadline. Re-sending the
                # identical cohort would time out identically forever (the
                # livelock class). Shrink the cohort and re-ride: a gateway
                # timeout cannot be resolved by same-cohort replay, so the fence
                # must be RELEASED (new digest) rather than merely cleared, which
                # is exactly what `_shrink_v2_request_budget` does. The retry is
                # smaller and per-path idempotent -- a delete the commit may have
                # already applied replays as PATH_ABSENT (a success), a put as a
                # path conflict the recovery lane rebases.
                self.logger.record(
                    "fabric_v2_commit_gateway_timeout",
                    batch_id=batch_id,
                    item_count=len(prepared),
                    status=error.status,
                )
                self._shrink_v2_request_budget(
                    prepared,
                    request_digest=request_digest,
                    reason="v2 commit cut by a gateway timeout; the cohort retries smaller",
                    status=error.status,
                )
                return
            if inline_blocks and _is_inline_field_rejection(error):
                # This control plane does not know inline_blocks. Nothing was
                # applied, so turn the lane off for a bounded window and let
                # the identical cohort retry through the ticket path. A
                # permanent, silent disable is the v1 mistake that cost a
                # whole process its small-file throughput with no log line to
                # show for it.
                self._inline_commit_supported = False
                self._inline_disabled_until_ns = self._wall_now_ns() + int(
                    INLINE_DISABLE_REPROBE_SECONDS * 1_000_000_000
                )
                self.logger.record(
                    "fabric_v2_inline_commit_disabled",
                    batch_id=batch_id,
                    status=error.status,
                    detail=str(error)[:200],
                )
                for entry in prepared:
                    self.database.clear_operation_commit_unknown_for_retry(
                        entry.operation.mutation_id,
                        reason="v2 inline commit refused; the cohort retries without inline bytes",
                        now_ns=self._wall_now_ns(),
                    )
                return
            if error.status == 404:
                # The v2 route is absent, so no handler ran and this cohort's
                # retry will be built by the v1 lane -- whose fence cannot
                # match a v2-namespace digest. Release the fence whole or the
                # operation is unroutable on every lane, forever.
                self._note_fabric_v2_unsupported("commit", error.status)
                for entry in prepared:
                    self.database.release_unroutable_commit_fence(
                        entry.operation.mutation_id,
                        expected_request_digest=request_digest,
                        reason="v2 commit route absent; no op was applied",
                        now_ns=self._wall_now_ns(),
                    )
                return
            for entry in prepared:
                self.database.clear_operation_commit_unknown_for_retry(
                    entry.operation.mutation_id,
                    reason="v2 commit rejected before any op was applied",
                    now_ns=self._wall_now_ns(),
                )
            return
        except (OSError, NetworkError) as error:
            # The outcome is unknown, but v2 does not need a status readback to
            # resolve it: the cohort id is derived from the request, and the
            # server records one verdict per mutation id, so resending the
            # identical cohort REPLAYS rather than re-applies. Clearing for
            # retry is therefore both safe and complete -- and it avoids the
            # v1 recovery lane, which reconstructs a frozen v1 request document
            # and terminally conflicts an operation that was committed by v2.
            #
            # A no-response on a MULTI-op cohort is very likely the route
            # deadline; replaying the identical oversized request would time out
            # again, forever. Shrink and re-ride (fence released, new digest) so
            # the retry is smaller and per-path idempotent. A single-op cohort
            # cannot be shrunk and is not a size problem, so it keeps the plain
            # idempotent same-cohort replay.
            self.logger.record(
                "fabric_v2_commit_failed",
                batch_id=batch_id,
                item_count=len(prepared),
                error=str(error),
            )
            if len(prepared) > 1:
                self._shrink_v2_request_budget(
                    prepared,
                    request_digest=request_digest,
                    reason="v2 commit got no response; a big cohort likely overran the route deadline",
                )
                return
            for entry in prepared:
                self.database.clear_operation_commit_unknown_for_retry(
                    entry.operation.mutation_id,
                    reason="v2 commit outcome unknown; the idempotent cohort will replay",
                    now_ns=self._wall_now_ns(),
                    preserve_batch_id=True,
                )
            return

        verdicts = response.get("ops")
        if not isinstance(verdicts, list) or len(verdicts) != len(prepared):
            error = NetworkError("The Fabric v2 commit returned an unexpected shape.")
            for entry in prepared:
                self._defer_commit_unknown(entry.operation, error)
            return

        applied = rejected = 0
        for entry, verdict in zip(prepared, verdicts):
            operation = entry.operation
            if not isinstance(verdict, Mapping):
                self._defer_commit_unknown(
                    operation, NetworkError("A Fabric v2 op verdict was malformed.")
                )
                continue
            code = str(verdict.get("code") or "FABRIC_OP_REJECTED")
            # A delete the server answers FABRIC_PATH_ABSENT is a SUCCESS, not
            # a rejection: the authority holding no such path is exactly the
            # state the delete asked for, and an idempotent delete reaching its
            # desired state is the whole point of naming the path rather than a
            # version. Treating it as a rejection terminally conflicts the
            # operation, and the entry then never leaves the local view -- the
            # live symptom was unlink() returning success while readdir kept
            # returning the name and rmdir failed ENOTEMPTY for good.
            already_absent = (
                verdict.get("status") != "applied"
                and code == "FABRIC_PATH_ABSENT"
                and operation.kind == "delete"
            )
            if verdict.get("status") == "applied" or already_absent:
                receipt = {
                    "schema": "meshia.fabric_commit.v2",
                    "mutation_id": operation.mutation_id,
                    "request_digest": request_digest,
                    # The journal sequence IS the head identity in v2; there is
                    # no per-commit content digest, and None is recorded rather
                    # than a synthesised value.
                    "manifest_generation": int(verdict.get("seq") or 0),
                    "manifest_digest": None,
                    "entry_sha256": entry.plan.sha256 if entry.plan else None,
                }
                if entry.plan is not None:
                    receipt["entry_blocks"] = self._v2_commit_ops([entry])[0]["blocks"]
                    receipt["entry_modified_at"] = (
                        _normalized_modified_at(verdict.get("modified_at"))
                        or entry.plan.modified_at
                    )
                if already_absent:
                    # A no-op commit advances no sequence, so the response head
                    # is the only truthful identity to record. v2 permits zero:
                    # inventing sequence one on an empty workspace would make
                    # receipt readback wait forever for a journal entry absent
                    # by construction.
                    receipt["manifest_generation"] = int(response.get("seq") or 0)
                    # Observable rather than silent: this is the one path where
                    # a rejection verdict is acknowledged, and an operator
                    # reading the journal must be able to see that happen.
                    self.logger.record(
                        "fabric_v2_delete_already_absent",
                        mutation_id=operation.mutation_id,
                        path=operation.path,
                        seq=int(response.get("seq") or 0),
                    )
                try:
                    self._ack_batch_entry(entry, receipt)
                except (
                    NetworkError, OSError, InvalidTask, StateError, UnsafePath, ValueError
                ) as error:
                    self._defer_commit_unknown(operation, error)
                    continue
                self._v2_path_recovery_attempts.pop(operation.mutation_id, None)
                applied += 1
                continue

            rejected += 1
            # FABRIC_PATH_EXISTS/FABRIC_PATH_DIVERGED report what the authority
            # actually holds. Carry it through instead of discarding it, so the
            # recovery lane can record the divergence it is rebasing over.
            observed = verdict.get("observed_digest")
            error = RemoteError(
                409,
                code,
                f"Meshia rejected {operation.path}: {code}",
                details=(
                    {"observed_digest": str(observed)} if _digest(observed) else None
                ),
            )
            renew_after_byte_repair = (
                operation.kind == "put" and _is_v2_absent_block_rejection(error)
            )
            self.database.clear_operation_commit_unknown_for_retry(
                operation.mutation_id,
                reason=f"v2 op rejected ({code})",
                now_ns=self._wall_now_ns(),
                # This exact op authoritatively did not apply. Its next
                # attempt may have different cohort neighbors, and must not
                # replay the server's cached rejection after repairing bytes.
                # Path-conflict recovery still needs its frozen digest to
                # fence an authoritative rebase. Renew only byte-repair
                # attempts; they retain the same path expectations.
                renew_v2_cohort=renew_after_byte_repair,
                expected_v2_batch_id=(
                    batch_id if renew_after_byte_repair else None
                ),
                expected_v2_request_digest=(
                    request_digest if renew_after_byte_repair else None
                ),
            )
            if (
                entry.plan is not None
                and entry.stage_path is not None
                and _is_reupload_verification_error(error)
            ):
                # Drop what this put believed the store already held. Note the
                # absence of an `entry.commit_blocks` guard, which the v1 batch
                # path has: the case that matters most here is precisely the
                # one where commit_blocks is EMPTY, because every block was
                # reused from the previous entry and therefore counted as
                # already verified. Gating on it would skip the overwrite this
                # classification exists to heal.
                self._demote_put_commit_receipts(operation, entry.stage_path)
            if not (
                code in FABRIC_V2_TERMINAL_VERDICT_CODES
                or _is_fabric_v2_path_conflict(error)
                or _is_transient_remote_error(error)
                or _is_v2_absent_block_rejection(error)
            ):
                self._defer_unknown_v2_verdict(operation, error, verdict)
                continue
            self._handle_operation_remote_error(operation, error)

        if applied and inline_blocks:
            # The lane made progress: the starvation valve measures from the
            # last successful inline batch, not from a put's arrival.
            self._inline_last_progress_ns = self._wall_now_ns()
        if applied:
            # A committed cohort proves the current per-lane budget is
            # deliverable, so heal any earlier 413 shrink (symmetric to the v1
            # `_note_batch_success` grow-back).
            self._note_v2_commit_success(self._v2_lane_of(prepared))
        self.logger.record(
            "fabric_v2_commit_committed",
            batch_id=batch_id,
            item_count=len(prepared),
            applied=applied,
            rejected=rejected,
            inline_blocks=len(inline_blocks),
            inline_bytes=sum(int(block["size_bytes"]) for block in inline_blocks),
            seq=int(response.get("seq") or 0),
            duration_ms=round(max(0.0, float(self._clock()) - started) * 1_000),
        )

    def _note_v2_commit_success(self, lane: str) -> None:
        """Grow a v2 lane's budget back after a successful commit.

        The mirror of `_shrink_v2_request_budget`: a 413 halves this lane's
        ``wire_bytes``/``inline_bytes`` and its ``item_cap`` toward one, and
        without a growth path one transient overflow would ratchet the lane
        down for the life of the process -- the exact bug that pinned the v1
        lane at two items per commit against a 64 cap. A committed cohort is
        proof the shrunken budget works, so restore the byte budgets to their
        ceilings immediately and grow the item cap back toward this lane's
        ceiling on a success streak (doubling, clamped), so the cohort size
        climbs gradually rather than snapping straight back to the shape that
        was just refused.
        """

        budget = self._v2_lane_budget(lane)
        # Byte budgets heal toward the LEARNED ceiling, never the hard constant:
        # if an earlier 413 lowered ``wire_ceiling``/``inline_ceiling``, a
        # success must not restore the budget back above the size that tripped
        # and re-trip it (the throughput-halving sawtooth). When nothing has
        # tripped, the ceilings are the hard constants and this restores fully.
        budget["wire_bytes"] = budget.get(
            "wire_ceiling", V2_COMMIT_REQUEST_MAX_WIRE_BYTES
        )
        budget["inline_bytes"] = budget.get("inline_ceiling", INLINE_BATCH_MAX_BYTES)
        ceiling = budget.get("item_cap_ceiling", DEFAULT_MAX_BATCH_MUTATIONS)
        if budget["item_cap"] >= ceiling:
            self._v2_lane_success_streak[lane] = 0
            return
        streak = self._v2_lane_success_streak.get(lane, 0) + 1
        if streak < BATCH_GROW_AFTER_SUCCESSES:
            self._v2_lane_success_streak[lane] = streak
            return
        self._v2_lane_success_streak[lane] = 0
        previous = budget["item_cap"]
        # `_shrink_v2_request_budget` can floor the cap at one; `max(2, ...)`
        # keeps the doubling productive from that floor.
        restored = min(ceiling, max(2, previous) * 2)
        if restored != previous:
            budget["item_cap"] = restored
            self.logger.record(
                "fabric_v2_item_cap_restored",
                lane=lane,
                previous=previous,
                item_cap=restored,
                ceiling=ceiling,
            )

    def _shrink_v2_request_budget(
        self,
        prepared: Sequence[_BatchCommitEntry],
        *,
        request_digest: str,
        reason: str,
        **fields: Any,
    ) -> None:
        """Halve what a v2 request may carry and re-arm the cohort.

        Both callers mean the same thing -- this request was bigger than the
        edge will take -- and neither is a verdict on any file. The item cap
        shrinks alongside the byte budgets because a cohort of large inline
        files can be over the wire at ANY per-request byte budget; the cap is
        what eventually makes the request small enough.

        The fence is released WHOLE, digest included, which needs justifying
        because a frozen request digest normally survives a retry: one
        mutation id may only ever carry one request body. The next attempt
        here is deliberately a DIFFERENT body -- a smaller cohort hashes
        differently -- so keeping the digest would make every member
        unmatchable forever (`mark_operations_commit_unknown` refuses to
        rebind), which is precisely the stall this shrink exists to avoid.
        Releasing it is licensed by the same evidence a 404 gives: on this
        route a 413 comes from the dispatcher's bounded-body reader, before
        authentication and before any handler runs, and the two in-handler
        413s (oversized inline payload, too many ops) both throw before the
        commit RPC is called. No body under these ids was ever seen.
        """

        lane = self._v2_lane_of(prepared)
        budget = self._v2_lane_budget(lane)
        # A 413 interrupts any grow-back streak: the lane is shrinking, not
        # proving itself, so the next success starts counting from zero.
        self._v2_lane_success_streak[lane] = 0
        before = (budget["wire_bytes"], budget["inline_bytes"], budget["item_cap"])
        budget["wire_bytes"] = max(
            V2_COMMIT_REQUEST_MIN_WIRE_BYTES,
            budget["wire_bytes"] // 2,
        )
        budget["inline_bytes"] = max(
            self._inline_block_max_bytes or 1,
            budget["inline_bytes"] // 2,
        )
        # LEARN the lowered ceiling: this size tripped the edge body limit, so
        # the grow-back must never restore the budget above it and re-trip. The
        # ceiling only ratchets down within a process (a 413 is deterministic in
        # request size, never a transient blip) and resets on restart.
        budget["wire_ceiling"] = min(
            budget.get("wire_ceiling", V2_COMMIT_REQUEST_MAX_WIRE_BYTES),
            budget["wire_bytes"],
        )
        budget["inline_ceiling"] = min(
            budget.get("inline_ceiling", INLINE_BATCH_MAX_BYTES),
            budget["inline_bytes"],
        )
        # Floor the cap at ONE. A cohort of one is the smallest a folder drop
        # of DISTINCT files can be split into, and it is the only request that
        # fits when the edge body limit sits between one file's inline commit
        # and two of them -- the exact stall a folder drop hit. `_plan_mutation
        # _turn` commits a one-item inline cohort under v2 (a single put's bytes
        # ride its own commit); the old floor of two forbade that and livelocked
        # the whole drop. A single file whose OWN inline commit still exceeds the
        # limit stops being inline-eligible (its bytes exceed the shrunken
        # request budget) and finishes through the ticket/upload lane instead.
        #
        # The SHARED `_batch_item_cap` is deliberately untouched: it is the v1
        # batch lane's, and a v2 413 says nothing about it.
        budget["item_cap"] = max(1, min(budget["item_cap"], len(prepared)) // 2)
        after = (budget["wire_bytes"], budget["inline_bytes"], budget["item_cap"])
        # Did this shrink make the request smaller at all? If any budget dropped,
        # the next attempt is a genuinely different (smaller) request that hashes
        # to a new digest -- forward progress. If nothing dropped, the identical
        # request will be rebuilt and rejected identically: the hot loop. Track
        # the streak PER DIGEST so a draining folder (new digest each shrink)
        # never accrues, and only a stuck request climbs toward the ceiling.
        reduced = after != before
        if len(self._v2_commit_rejection_streak) > 4096:
            self._v2_commit_rejection_streak.clear()
        if reduced:
            self._v2_commit_rejection_streak.pop(request_digest, None)
            streak = 1
        else:
            streak = self._v2_commit_rejection_streak.get(request_digest, 0) + 1
            self._v2_commit_rejection_streak[request_digest] = streak
        # THE SPLIT BOTTOMED OUT. A cohort of one cannot be halved into a
        # smaller cohort, so shrinking the cap changes nothing: this single
        # file's OWN inline commit is what the edge rejected, and retrying the
        # identical inline commit would idle the file forever (the livelock this
        # method exists to prevent, now in its last remaining shape). Force it
        # off the inline lane instead: it uploads its blocks and commits by
        # verify, a request whose body is O(digests), not O(bytes), so it always
        # fits. This is the "goes to the block path" verdict -- named, counted,
        # and logged once -- never a silent re-queue that loops.
        single_bottomed = len(prepared) == 1
        if single_bottomed:
            entry = prepared[0]
            self._v2_inline_forced_upload.add(entry.operation.mutation_id)
            self._v2_inline_single_oversized_count += 1
            self.logger.record(
                "fabric_v2_inline_single_oversized_forced_upload",
                lane=lane,
                reason=reason,
                mutation_id=entry.operation.mutation_id,
                path=entry.operation.path,
                wire_budget_bytes=budget["wire_bytes"],
                inline_budget_bytes=budget["inline_bytes"],
                forced_upload_total=self._v2_inline_single_oversized_count,
                **fields,
            )
        else:
            self.logger.record(
                "fabric_v2_inline_budget_reduced",
                lane=lane,
                reason=reason,
                item_count=len(prepared),
                wire_budget_bytes=budget["wire_bytes"],
                inline_budget_bytes=budget["inline_bytes"],
                item_cap=budget["item_cap"],
                **fields,
            )
        # THE HARD CEILING. An identical oversized request rejected this many
        # times in a row is not going to start fitting; retrying it again is the
        # guaranteed-400 hot loop that ran ~5 signed commits/second all night and
        # is the leading suspect for a production database outage. Fail the ops
        # terminally with a named verdict instead of re-arming them a seventh
        # time -- never a silent hot loop. (A single file bottomed at the floor
        # is already routed to the upload lane above and re-armed as an upload,
        # not an inline commit, so it does not reach this ceiling; this catches
        # any request that keeps hashing identically without either shrinking or
        # leaving the inline lane.)
        if not reduced and streak >= V2_COMMIT_OVERSIZED_RETRY_CEILING:
            self._v2_commit_rejection_streak.pop(request_digest, None)
            for entry in prepared:
                self.logger.record(
                    "fabric_v2_commit_oversized_terminal",
                    lane=lane,
                    reason=reason,
                    mutation_id=entry.operation.mutation_id,
                    path=entry.operation.path,
                    rejections=streak,
                    **fields,
                )
                self.database.update_operation(
                    entry.operation.mutation_id,
                    state="conflict",
                    error=(
                        "The connected host rejected this file's Fabric commit "
                        f"as too large {streak} times without it getting "
                        "smaller; it will not sync until it is changed."
                    ),
                    now_ns=self._wall_now_ns(),
                )
            return
        # An IDENTICAL rejection (nothing got smaller) that has not yet reached
        # the ceiling backs off with jittered exponential delay and accrues a
        # durable failure_count, so the loop is rate-limited and visible to the
        # breaker/readiness machinery -- the shape whose absence let 4,580
        # identical rejections run at RPC rate with failure_count still 0. A
        # reducing shrink (streak 1) keeps the original immediate re-arm so a
        # normal folder drain is not slowed at all.
        backoff_streak = 0 if reduced else streak
        for entry in prepared:
            reason_text = (
                "v2 single-file inline commit oversized; routes to the upload lane"
                if single_bottomed
                else "v2 commit payload oversized; the cohort retries smaller"
            )
            released = self.database.release_unroutable_commit_fence(
                entry.operation.mutation_id,
                expected_request_digest=request_digest,
                reason=reason_text,
                now_ns=self._wall_now_ns(),
            )
            if backoff_streak >= 2:
                self.database.update_operation(
                    entry.operation.mutation_id,
                    state="retry",
                    error=reason_text,
                    retry_after_seconds=_operation_retry_delay(
                        entry.operation.mutation_id, released.failure_count + 1
                    ),
                    count_failure=True,
                    now_ns=self._wall_now_ns(),
                )

    def _v2_inline_blocks(
        self, entries: Sequence[_BatchCommitEntry], ops: Sequence[Mapping[str, Any]]
    ) -> list[dict[str, Any]]:
        """The cohort's inline byte payload, bounded by the SERIALIZED request.

        Content addressing means two files with identical bytes name one
        block; sending it twice would be pure waste, and the server refuses a
        repeated digest anyway.

        The binding constraint is the wire, not the byte budget. Base64 costs
        a third on top of every inline byte, and the ops themselves are
        already on the request, so a cohort well inside the 3-MiB inline
        budget can still exceed the edge's 1,450,000-byte signed-body limit --
        and a 413 fails the WHOLE cohort. Measuring the real serialized size
        as the payload is assembled is the only bound that predicts what the
        edge will do. A block left out is far cheaper: its own op is rejected
        as absent and retried through the ticket lane, one file's cost rather
        than the batch's.
        """

        budget = self._v2_lane_budget(self._v2_lane_of(entries))["wire_bytes"]
        wire = len(json.dumps(list(ops), separators=(",", ":")))
        payload: list[dict[str, Any]] = []
        seen: set[str] = set()
        total = 0
        for entry in entries:
            if len(payload) >= MAX_VERIFY_BLOCKS_PER_REQUEST:
                break
            for block, data in entry.inline_blocks:
                if block.sha256 in seen:
                    continue
                if len(data) > self._inline_block_max_bytes:
                    continue
                encoded = base64.b64encode(data).decode("ascii")
                item = {
                    "sha256": block.sha256,
                    "size_bytes": len(data),
                    "bytes_b64": encoded,
                }
                # +1 for the separating comma; the object's own braces, keys
                # and quotes are in the dumps() below.
                item_wire = len(json.dumps(item, separators=(",", ":"))) + 1
                if wire + item_wire > budget:
                    continue
                wire += item_wire
                seen.add(block.sha256)
                total += len(data)
                payload.append(item)
        return payload

    def _send_commit_batch(self, entries: Sequence[_BatchCommitEntry]) -> None:
        """Commit several claimed, path-independent operations in one call.

        Every member is fenced commit_unknown in one SQLite transaction before
        the POST; each item result is then acknowledged or parked exactly as
        the single mutate path would treat that response.
        """

        prepared: list[tuple[_BatchCommitEntry, dict[str, Any], str]] = []
        for entry in entries:
            operation = entry.operation
            rebased = self.database.rebase_never_sent_operation_to_current_head(
                operation.mutation_id, now_ns=self._wall_now_ns()
            )
            if rebased is not None:
                operation = rebased
            payload = self._path_mutation_payload(
                operation,
                plan=entry.plan,
                verify_blocks=entry.commit_blocks or None,
            )
            if entry.inline_blocks:
                # Outside the digested mutation document, like verify_blocks.
                payload["inline_blocks"] = [
                    {
                        "sha256": block.sha256,
                        "size_bytes": block.size_bytes,
                        "bytes_b64": base64.b64encode(data).decode("ascii"),
                    }
                    for block, data in entry.inline_blocks
                ]
            request_digest = _mutation_request_digest(
                self.authority.session_id, payload
            )
            payload["request_digest"] = request_digest
            prepared.append((replace(entry, operation=operation), payload, request_digest))
        # Observe the serialized size so the adaptive cap has real data: the
        # inline byte budget alone does not predict the wire size, because
        # every item also carries a manifest preimage that scales with the
        # whole workspace namespace.
        wire_bytes = sum(
            len(json.dumps(payload, separators=(",", ":")))
            for _entry, payload, _digest in prepared
        )
        if wire_bytes > self._batch_wire_budget_bytes and len(prepared) > 1:
            # Too big for one request and we cannot un-claim: shrink the cap so
            # the NEXT turn plans a smaller batch, and let this one try.
            self._batch_item_cap = max(1, min(self._batch_item_cap, len(prepared)) // 2)
            self.logger.record(
                "fabric_batch_item_cap_reduced",
                reason="wire_estimate",
                item_count=len(prepared),
                wire_bytes=wire_bytes,
                budget_bytes=self._batch_wire_budget_bytes,
                item_cap=self._batch_item_cap,
            )
        batch_id = str(uuid.uuid4())
        self.database.mark_operations_commit_unknown(
            [(payload["mutation_id"], digest) for _entry, payload, digest in prepared],
            batch_id=batch_id,
            now_ns=self._wall_now_ns(),
        )
        started = float(self._clock())
        try:
            response = self._signed_control_request(
                self.transport.mutate_batch,  # type: ignore[attr-defined]
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "items": [payload for _entry, payload, _digest in prepared],
                },
            )
        except RemoteError as error:
            self._handle_batch_request_rejection(prepared, error)
            return
        except (OSError, NetworkError) as error:
            # Outcome unknown for every member: keep the fence, read back.
            for entry, _payload, _digest in prepared:
                self._defer_commit_unknown(entry.operation, error)
            self.logger.record(
                "fabric_mutation_batch_failed",
                batch_id=batch_id,
                item_count=len(prepared),
                error=str(error),
            )
            self._note_batch_transport_failure(len(prepared))
            return
        self._note_batch_success()
        try:
            items = _mutation_batch_items(response, prepared)
        except NetworkError as error:
            for entry, _payload, _digest in prepared:
                self._defer_commit_unknown(entry.operation, error)
            self.logger.record(
                "fabric_mutation_batch_failed",
                batch_id=batch_id,
                item_count=len(prepared),
                error=str(error),
            )
            return
        applied = rejected = skipped = 0
        verified_blocks = 0
        committed_bytes = 0
        inline_blocks_sent = 0
        inline_bytes_sent = 0
        attachment_inactive: RemoteError | None = None
        for (entry, _payload, request_digest), item in zip(prepared, items):
            operation = entry.operation
            status = item["status"]
            if status == "applied":
                try:
                    receipt = _mutation_receipt(
                        item.get("receipt"),
                        operation,
                        plan=entry.plan,
                        request_digest=request_digest,
                    )
                    self._ack_batch_entry(entry, receipt)
                except (NetworkError, OSError, InvalidTask, StateError, UnsafePath, ValueError) as error:
                    self._defer_commit_unknown(operation, error)
                    continue
                applied += 1
                verified_blocks += len(entry.commit_blocks)
                inline_blocks_sent += len(entry.inline_blocks)
                inline_bytes_sent += sum(len(data) for _block, data in entry.inline_blocks)
                if entry.plan is not None:
                    committed_bytes += entry.plan.size_bytes
                continue
            error_document = item.get("error") or {}
            error = RemoteError(
                int(error_document.get("status") or 409),
                str(error_document.get("code") or "FABRIC_MUTATION_FAILED"),
                (
                    f"Meshia rejected batch item {operation.mutation_id} "
                    f"({error_document.get('code') or 'REMOTE_ERROR'}): "
                    f"{error_document.get('message') or ''}"
                ),
            )
            if status == "skipped":
                # Never reached the database; immediately sendable again.
                skipped += 1
                self.database.clear_operation_commit_unknown_for_retry(
                    operation.mutation_id,
                    reason="batch item skipped by the control plane",
                    now_ns=self._wall_now_ns(),
                )
                continue
            rejected += 1
            if _is_precommit_safe_mutation_rejection(error):
                self.database.clear_operation_commit_unknown_for_retry(
                    operation.mutation_id,
                    reason="remote mutation rejection authoritatively proved no commit",
                    now_ns=self._wall_now_ns(),
                )
            if (
                entry.plan is not None
                and entry.stage_path is not None
                and entry.commit_blocks
                and _is_reupload_verification_error(error)
            ):
                self._demote_put_commit_receipts(operation, entry.stage_path)
            if self._handle_operation_remote_error(operation, error):
                attachment_inactive = error
        # The lane demonstrably works: reset the hold valve's idle clock so
        # puts queued behind this batch keep waiting for inline instead of
        # falling back to per-file ticket waves.
        self._inline_last_progress_ns = self._wall_now_ns()
        self.logger.record(
            "fabric_mutation_batch_committed",
            batch_id=batch_id,
            item_count=len(prepared),
            applied=applied,
            rejected=rejected,
            skipped=skipped,
            verified_blocks=verified_blocks,
            committed_bytes=committed_bytes,
            inline_blocks=inline_blocks_sent,
            inline_bytes=inline_bytes_sent,
            duration_ms=round(max(0.0, float(self._clock()) - started) * 1_000),
        )
        if attachment_inactive is not None:
            raise attachment_inactive

    def _note_batch_transport_failure(self, item_count: int) -> None:
        """A lost batch response: after two in a row, halve the batch bound."""

        self._batch_success_streak = 0
        self._batch_transport_failures += 1
        if self._batch_transport_failures < BATCH_BACKOFF_AFTER_FAILURES:
            return
        self._batch_transport_failures = 0
        previous = self._batch_size_limit
        self._batch_size_limit = max(1, min(previous, item_count) // 2)
        if self._batch_size_limit != previous:
            self.logger.record(
                "fabric_mutation_batch_size_reduced",
                previous_limit=previous,
                limit=self._batch_size_limit,
            )

    def _note_batch_success(self) -> None:
        """A batch response arrived: grow the bound back after a success streak."""

        self._batch_transport_failures = 0
        # The wire/413 cap shrinks on an oversized request but had NO growth
        # path, so one overflow ratcheted it down for the life of the process:
        # observed live at 2 items per commit against a 64 cap, turning a
        # 557-file drop into 119 round trips whose server work was 0.3 s each.
        # Recover it on the same success cadence as the size limit.
        if self._batch_item_cap < DEFAULT_MAX_BATCH_MUTATIONS:
            restored = min(DEFAULT_MAX_BATCH_MUTATIONS, max(2, self._batch_item_cap) * 2)
            if restored != self._batch_item_cap:
                self.logger.record(
                    "fabric_batch_item_cap_restored",
                    previous=self._batch_item_cap,
                    item_cap=restored,
                )
                self._batch_item_cap = restored
        if self._batch_size_limit >= DEFAULT_MAX_BATCH_MUTATIONS:
            self._batch_success_streak = 0
            return
        self._batch_success_streak += 1
        if self._batch_success_streak < BATCH_GROW_AFTER_SUCCESSES:
            return
        self._batch_success_streak = 0
        previous = self._batch_size_limit
        self._batch_size_limit = min(DEFAULT_MAX_BATCH_MUTATIONS, previous * 2)
        self.logger.record(
            "fabric_mutation_batch_size_restored",
            previous_limit=previous,
            limit=self._batch_size_limit,
        )

    def _handle_batch_request_rejection(
        self,
        prepared: Sequence[tuple[_BatchCommitEntry, dict[str, Any], str]],
        error: RemoteError,
    ) -> None:
        """A whole-batch HTTP rejection happens before any item is persisted.

        The route authenticates, checks authority, parses and fences every
        item before the first database write, and item outcomes travel inside
        a 200 response; a 4xx therefore proves no member committed. Anything
        5xx keeps the fence and resolves by status readback.
        """

        inline_payloads = [
            payload
            for _entry, payload, _digest in prepared
            if "inline_blocks" in payload
        ]
        if (
            inline_payloads
            and error.status == 400
            and error.remote_code == "FABRIC_MUTATION_INLINE_BLOCKS_INVALID"
        ):
            # The control plane knows the field and rejected THIS payload's
            # shape or size: our bug, not a missing feature. Halve the request
            # budget (never below one maximum block, so the lane still works)
            # and retry; the client converges on a request the server accepts
            # instead of degrading every later put to ticket waves.
            floor = max(self._inline_block_max_bytes, 1)
            self._inline_request_budget_bytes = max(
                floor, self._inline_request_budget_bytes // 2
            )
            self.logger.record(
                "fabric_inline_batch_rejected",
                status=error.status,
                code=error.remote_code,
                item_count=len(prepared),
                inline_items=len(inline_payloads),
                request_budget_bytes=self._inline_request_budget_bytes,
            )
            for entry, _payload, _digest in prepared:
                self.database.clear_operation_commit_unknown_for_retry(
                    entry.operation.mutation_id,
                    reason="inline batch payload rejected; retrying within a smaller budget",
                    now_ns=self._wall_now_ns(),
                )
            return
        if (
            inline_payloads
            and self._inline_commit_supported
            and error.status == 400
            and error.remote_code
            in {"BAD_REQUEST", "FABRIC_MUTATION_BATCH_INVALID"}
        ):
            # An older control plane rejects the inline field at parse time,
            # before any database write: no member committed. Resume the
            # classic ticket/upload lane and re-probe after a cooldown, so one
            # rejection cannot disable inline for the life of the process.
            self._inline_commit_supported = False
            self._inline_disabled_until_ns = self._wall_now_ns() + int(
                INLINE_DISABLE_REPROBE_SECONDS * 1_000_000_000
            )
            self.logger.record(
                "fabric_inline_commit_unsupported",
                # The server's message is the only thing that distinguishes
                # "this control plane predates inline" from "our request was
                # malformed"; without it a generic 400 is undiagnosable.
                detail=str(error)[:300],
                status=error.status,
                code=error.remote_code,
                item_count=len(prepared),
                inline_items=len(inline_payloads),
                reprobe_seconds=INLINE_DISABLE_REPROBE_SECONDS,
            )
            for entry, _payload, _digest in prepared:
                self.database.clear_operation_commit_unknown_for_retry(
                    entry.operation.mutation_id,
                    reason="inline batch blocks rejected; classic upload lane resumes",
                    now_ns=self._wall_now_ns(),
                )
            return
        unsupported = error.status == 404 or (
            error.status == 400
            and error.remote_code
            in {"BAD_REQUEST", "FABRIC_MUTATION_BATCH_INVALID", "FABRIC_MUTATION_BATCH_DEPENDENT_ITEMS"}
        ) or (
            error.status == 503
            and error.remote_code == "FABRIC_MUTATION_BATCH_UNAVAILABLE"
        )
        if unsupported:
            self._mutate_batches = False
            self.logger.record(
                "fabric_mutation_batch_unsupported",
                status=error.status,
                code=error.remote_code,
                item_count=len(prepared),
            )
        oversized = error.status == 413 or error.remote_code == "PAYLOAD_TOO_LARGE"
        if oversized:
            self._batch_wire_budget_bytes = max(
                BATCH_REQUEST_MIN_WIRE_BYTES,
                self._batch_wire_budget_bytes // 2,
            )
            self._inline_request_budget_bytes = max(
                self._inline_block_max_bytes or 1,
                self._inline_request_budget_bytes // 2,
            )
            self._batch_item_cap = max(1, min(self._batch_item_cap, len(prepared)) // 2)
            self.logger.record(
                "fabric_batch_wire_budget_reduced",
                item_count=len(prepared),
                wire_budget_bytes=self._batch_wire_budget_bytes,
                inline_budget_bytes=self._inline_request_budget_bytes,
                item_cap=self._batch_item_cap,
            )
        if unsupported or error.status < 500:
            for entry, _payload, _digest in prepared:
                self.database.clear_operation_commit_unknown_for_retry(
                    entry.operation.mutation_id,
                    reason="batch request rejected before any item was persisted",
                    now_ns=self._wall_now_ns(),
                )
                if not unsupported and not oversized:
                    # An oversized request is a transport condition, never a
                    # verdict on any item. Classifying it as a permanent
                    # rejection put every file of the batch into terminal
                    # `conflict` state -- the live 45-of-60 stall, and the
                    # "stuck greyed-out files" the user reported. The items
                    # are already re-armed above; the shrunk cap makes the
                    # next attempt smaller.
                    self._handle_operation_remote_error(entry.operation, error)
            if not unsupported:
                self.logger.record(
                    "fabric_mutation_batch_rejected",
                    status=error.status,
                    code=error.remote_code,
                    item_count=len(prepared),
                )
            if (
                error.status == 409
                and error.remote_code == "FABRIC_ATTACHMENT_INACTIVE"
            ):
                raise error
            return
        for entry, _payload, _digest in prepared:
            self._defer_commit_unknown(entry.operation, error)
        self.logger.record(
            "fabric_mutation_batch_failed",
            status=error.status,
            code=error.remote_code,
            item_count=len(prepared),
            error=str(error),
        )

    def _demote_put_commit_receipts(
        self, operation: PendingOperation, stage_path: Path
    ) -> None:
        """Forget provider receipts a rejected commit-time verification disproved."""

        progress = self._put_progress(operation, stage_path)
        if _demote_unconfirmed_receipts(progress) == 0:
            progress["uploaded"].clear()
            progress["receipts"].clear()
            progress["reuse_target_blocks"] = False
        progress["verified"].clear()
        _write_progress(stage_path, operation.mutation_id, progress)

    def _ack_batch_entry(
        self, entry: _BatchCommitEntry, receipt: Mapping[str, Any]
    ) -> None:
        operation = entry.operation
        if entry.plan is not None and entry.stage_path is not None:
            # Inline blocks were verified server-side from the request bytes;
            # they never held an upload receipt, and the receipted journal
            # append below asserts one, so record only receipt-backed waves.
            inline_shas = {block.sha256 for block, _data in entry.inline_blocks}
            receipted = tuple(
                block.sha256
                for block in (*entry.commit_blocks, *entry.readback_blocks)
                if block.sha256 not in inline_shas
            )
            if receipted:
                progress = self._put_progress(operation, entry.stage_path)
                _append_verified_upload_blocks(
                    entry.stage_path,
                    operation.mutation_id,
                    progress,
                    receipted,
                )
            self.logger.record(
                "fabric_put_committed",
                mutation_id=operation.mutation_id,
                path=operation.path,
                size_bytes=entry.plan.size_bytes,
                blocks=len({block.sha256 for block in entry.plan.blocks}),
                verified_in_commit=len(entry.commit_blocks) + len(entry.readback_blocks),
                inline_blocks=len(entry.inline_blocks),
                batched=True,
            )
            self._ack_mutation(
                operation,
                receipt,
                plan=entry.plan,
                blocks_provider_verified=not (entry.commit_blocks or entry.readback_blocks),
            )
            self._metadata_split_repair_checked.discard(operation.mutation_id)
            self._put_progress_cache_key = None
            self._put_progress_cache = None
            return
        self._ack_mutation(operation, receipt)

    def _load_and_fence_put_plan(
        self, operation: PendingOperation
    ) -> tuple[Path, StagePlan]:
        if operation.staged_path is None:
            raise StateError("A queued Fabric put has no durable stage.")
        stage_path = Path(operation.staged_path)
        plan = _load_plan(stage_path, operation)
        observed: FileFingerprint | None | object = _FINGERPRINT_NOT_OBSERVED
        if (
            plan.source_path is not None
            and operation.mutation_id not in self._metadata_split_repair_checked
        ):
            observed = self._reconcile_split_plan_metadata_fingerprint(
                operation, plan
            )
        self._assert_source_backed_plan_current(
            plan,
            observed=(
                observed
                if plan.source_path == operation.path
                else _FINGERPRINT_NOT_OBSERVED
            ),
        )
        if (
            plan.source_path is not None
            and operation.mutation_id not in self._metadata_split_repair_checked
        ):
            if (
                len(self._metadata_split_repair_checked)
                >= _METADATA_SPLIT_REPAIR_CACHE_LIMIT
            ):
                self._metadata_split_repair_checked.clear()
            self._metadata_split_repair_checked.add(operation.mutation_id)
        return stage_path, plan

    def _verify_put_receipts(
        self,
        operation: PendingOperation,
        stage_path: Path,
        progress: dict[str, Any],
        batch: Sequence[StagedBlock],
    ) -> None:
        if not 1 <= len(batch) <= MAX_VERIFY_BLOCKS_PER_REQUEST:
            raise StateError("A Fabric upload verification exceeds its batch bound.")
        receipts = progress["receipts"]
        if any(block.sha256 not in receipts for block in batch):
            raise StateError(
                "The durable Fabric upload lost its exact attempt record."
            )
        for block in batch:
            _durable_upload_part_receipt(
                receipts[block.sha256],
                expected_digest=block.sha256,
                expected_size=block.size_bytes,
            )
        verification_blocks = [
            {"sha256": block.sha256, "size_bytes": block.size_bytes}
            for block in batch
        ]
        payload: dict[str, Any] = {
            "operation": "verify",
            "mutation_id": operation.mutation_id,
            "blocks": verification_blocks,
        }
        if self._direct_block_admission():
            # Direct edge uploads have no write_batch reservation; the
            # control plane admits them (one begin per ≤256 blocks) under
            # the named attachment before HEAD verification.
            payload = {
                **payload,
                "direct_blocks": True,
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
            }
        try:
            try:
                response = self._signed_control_request(self.transport.blocks, payload)
            except RemoteError as error:
                if error.status != 400 or "direct_blocks" not in payload:
                    raise
                # An older control plane does not know direct_blocks (and
                # never minted an edge grant): finish this verify classically.
                self._direct_blocks_supported = False
                self.logger.record(
                    "fabric_direct_blocks_unsupported", mutation_id=operation.mutation_id
                )
                response = self._signed_control_request(
                    self.transport.blocks,
                    {
                        "operation": "verify",
                        "mutation_id": operation.mutation_id,
                        "blocks": verification_blocks,
                    },
                )
        except RemoteError as error:
            if _is_reupload_verification_error(error):
                # A CAS object can disappear after a successful PUT or after
                # target-manifest reuse. Persistently revoke both assumptions
                # so the next bounded attempt re-uploads every source block.
                progress["uploaded"].clear()
                progress["verified"].clear()
                progress["receipts"].clear()
                progress["reuse_target_blocks"] = False
                _write_progress(stage_path, operation.mutation_id, progress)
            raise
        _verified_blocks(response, batch)
        _append_verified_upload_blocks(
            stage_path,
            operation.mutation_id,
            progress,
            tuple(block.sha256 for block in batch),
        )

    def _assert_mutation_namespace_capacity(
        self, operation: PendingOperation, *, plan: StagePlan | None
    ) -> None:
        """Reject an observably over-cap projected namespace before tickets.

        The connected-host index intentionally stores files only, so this is a
        conservative bounded estimate over the exact file descriptors visible
        to the node plus derived parent directories. The server remains the
        byte-for-byte canonical preimage authority for explicit empty
        directories and storage metadata omitted from the edge wire.

        v2 skips this entirely, and that is the point rather than a shortcut.
        The bound exists to keep the v1 whole-namespace manifest PREIMAGE
        under 8 MiB, and the 10,000-file cap is just that byte bound restated
        in files. ``_v2_commit_ops`` sends one op per changed path and no
        preimage at all, so on v2 the guard polices a request body that is
        not constructed. Keeping it there cost a full remote-entry scan plus
        a JSON encode of every entry, PER FILE -- reintroducing on the client
        the exact O(N^2) the v2 wire was built to remove (measured: 64.5 s of
        a 141 s profile at 4,800 files). Worse, it is not merely slow: any
        workspace past 10,000 files hard-failed every subsequent mutation
        with FABRIC_MUTATION_NAMESPACE_TOO_LARGE, so an 80,000-file folder
        could never finish at any speed. The server stays the authority on
        its own per-op limits.
        """

        if self._v2_commit_active():
            return
        if self._namespace_preflight_mutation_id == operation.mutation_id:
            return
        entries = self.database.list_remote_entries(limit=MAX_MUTATION_LIVE_FILES + 1)
        file_count, estimated_bytes = _projected_mutation_namespace_usage(
            entries,
            operation,
            plan=plan,
            session_id=self.authority.session_id,
        )
        if (
            file_count > MAX_MUTATION_LIVE_FILES
            or estimated_bytes > MAX_MUTATION_PREIMAGE_BYTES
        ):
            raise InvalidTask(
                "FABRIC_MUTATION_NAMESPACE_TOO_LARGE: projected namespace exceeds "
                "10,000 live files or the 8-MiB observable preimage bound"
            )
        self._namespace_preflight_mutation_id = operation.mutation_id

    def _edge_write_ready(self) -> bool:
        probe = getattr(self.transport, "edge_write_ready", None)
        try:
            return bool(callable(probe) and probe())
        except Exception:  # noqa: BLE001 - readiness must never raise into the loop
            return False

    def _edge_read_ready(self) -> bool:
        probe = getattr(self.transport, "edge_read_ready", None)
        try:
            return bool(callable(probe) and probe())
        except Exception:  # noqa: BLE001
            return False

    def _reprobe_commit_capabilities(self) -> None:
        """Restore verify-on-commit / direct admission after a cooling period.

        A 400 on one request is treated as "this control plane is older", but
        a transient or self-inflicted rejection must not disable the inline
        lane forever; re-probe on the same cadence as the inline route.
        """

        at_ns = self._capability_disabled_at_ns
        if at_ns is None:
            return
        if self._wall_now_ns() - at_ns < int(
            INLINE_DISABLE_REPROBE_SECONDS * 1_000_000_000
        ):
            return
        self._capability_disabled_at_ns = None
        self._mutate_verifies_blocks = True
        self._direct_blocks_supported = True
        self.logger.record("fabric_commit_capabilities_reprobe")

    def _direct_block_admission(self) -> bool:
        """Whether verify/commit must ask the control plane to admit blocks."""

        self._reprobe_commit_capabilities()
        probe = getattr(self.transport, "edge_direct_commits", None)
        try:
            return self._direct_blocks_supported and bool(callable(probe) and probe())
        except Exception:  # noqa: BLE001
            return False

    def _edge_write_tickets(
        self, blocks: Sequence[StagedBlock]
    ) -> dict[str, Mapping[str, Any]] | None:
        """Ticket-shaped edge descriptors for ``blocks``; None when unavailable."""

        if not self._edge_write_ready():
            return None
        mint = getattr(self.transport, "edge_block_ticket", None)
        if not callable(mint):
            return None
        tickets: dict[str, Mapping[str, Any]] = {}
        for block in blocks:
            ticket = mint(method="PUT", sha256=block.sha256, size_bytes=block.size_bytes)
            if ticket is None:
                return None
            tickets[block.sha256] = ticket
        return tickets

    def _initial_put_write_tickets(
        self,
        operation: PendingOperation,
        *,
        missing: Sequence[StagedBlock],
        batch: Sequence[StagedBlock],
        upload_concurrency: int,
    ) -> tuple[list[StagedBlock], dict[str, Mapping[str, Any]], str]:
        """Issue the first wave, amortizing one companion when safe.

        Byte transfer remains one mutation at a time on the existing daemon
        pool. Only one companion's signed capabilities are prefetched under one
        v1 request and a goodput-derived byte budget. The small progressive
        cohort bounds first-PUT admission delay while preserving a 2:1 request
        reduction. Every item retains its own mutation id, reservation, target,
        and abandoned-upload cleanup provenance.
        """

        cached = self._prefetched_write_tickets.pop(operation.mutation_id, None)
        if cached:
            cached_batch = [block for block in missing if block.sha256 in cached]
            now_epoch = self._wall_now_ns() / 1_000_000_000
            try:
                headroom = min(_write_ticket_expiry(ticket) for ticket in cached.values()) - now_epoch
            except (NetworkError, ValueError):
                headroom = 0.0
            if (
                cached_batch
                and {block.sha256 for block in cached_batch} == set(cached)
                and 1.0 < headroom <= MAX_WRITE_TICKET_LIFETIME_SECONDS + 5.0
            ):
                self.logger.record(
                    "fabric_upload_ticket_batch_consumed",
                    mutation_id=operation.mutation_id,
                    block_count=len(cached_batch),
                    ticket_headroom_ms=round(headroom * 1_000),
                    prefetched_remaining=len(self._prefetched_write_tickets),
                )
                return cached_batch, cached, "tickets_batch"
            self.logger.record(
                "fabric_upload_ticket_batch_expired",
                mutation_id=operation.mutation_id,
                block_count=len(cached),
            )

        # Meshia object edge: no reservation call; the commit admits these
        # digests itself, so every worker slot can start at once instead of
        # probing goodput with a single ticketed object.
        edge_batch = list(
            missing[: max(len(batch), min(len(missing), upload_concurrency))]
        )
        edge_tickets = (
            self._edge_write_tickets(edge_batch) if self._edge_write_ready() else None
        )
        if edge_tickets is not None:
            return edge_batch, edge_tickets, "edge"

        items = self._plan_multi_put_ticket_items(operation, batch)
        if len(items) >= 2:
            flattened = [block for _candidate, blocks in items for block in blocks]
            started = float(self._clock())
            try:
                response = self._signed_control_request(
                    self.transport.blocks,
                    {
                        "attachment_id": self.authority.attachment_id,
                        "workspace": WORKSPACE_MOUNT,
                        "operation": "write_batch",
                        "ttl_seconds": self._put_upload_ticket_ttl(flattened),
                        "items": [
                            {
                                "mutation_id": candidate.mutation_id,
                                "blocks": [
                                    {
                                        "sha256": block.sha256,
                                        "size_bytes": block.size_bytes,
                                    }
                                    for block in blocks
                                ],
                            }
                            for candidate, blocks in items
                        ],
                    },
                )
                issued, rejected = _block_ticket_batch_items(response, items)
            except RemoteError as error:
                if error.status in {400, 404} and error.remote_code in {
                    None,
                    "BAD_REQUEST",
                    "FABRIC_BLOCK_OPERATION_INVALID",
                    "FABRIC_BLOCK_WRITE_BATCH_INVALID",
                }:
                    self._multi_put_ticket_batches = False
                    self.logger.record(
                        "fabric_upload_ticket_batch_unsupported",
                        status=error.status,
                        code=error.remote_code,
                    )
                else:
                    raise
            else:
                now_epoch = self._wall_now_ns() / 1_000_000_000
                for tickets in issued.values():
                    headroom = min(
                        _write_ticket_expiry(ticket) for ticket in tickets.values()
                    ) - now_epoch
                    if (
                        headroom <= 1.0
                        or headroom > MAX_WRITE_TICKET_LIFETIME_SECONDS + 5.0
                    ):
                        raise NetworkError(
                            "Meshia returned an expired or excessive Fabric upload ticket."
                        )
                for candidate, _blocks in items[1:]:
                    tickets = issued.get(candidate.mutation_id)
                    if tickets:
                        self._prefetched_write_tickets[candidate.mutation_id] = tickets
                successful = len(issued)
                self.logger.record(
                    "fabric_upload_ticket_batch_issued",
                    mutation_id=operation.mutation_id,
                    item_count=len(items),
                    issued_items=successful,
                    rejected_items=len(rejected),
                    block_count=len(flattened),
                    total_bytes=sum(block.size_bytes for block in flattened),
                    signed_requests_saved=max(0, successful - 1),
                    duration_ms=round(
                        max(0.0, float(self._clock()) - started) * 1_000
                    ),
                )
                current = issued.get(operation.mutation_id)
                if current is not None:
                    return list(items[0][1]), current, "tickets_batch"
                error = rejected.get(operation.mutation_id)
                if error is None:
                    raise NetworkError(
                        "Meshia omitted the active mutation from a Fabric ticket batch."
                    )
                raise error

        response = self._signed_control_request(
            self.transport.blocks,
            {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "operation": "write_batch",
                "mutation_id": operation.mutation_id,
                "ttl_seconds": self._put_upload_ticket_ttl(batch),
                "blocks": [
                    {"sha256": block.sha256, "size_bytes": block.size_bytes}
                    for block in batch
                ],
            },
        )
        return list(batch), _block_tickets(response, operation.mutation_id, batch), "tickets"

    def _plan_multi_put_ticket_items(
        self,
        operation: PendingOperation,
        batch: Sequence[StagedBlock],
    ) -> list[tuple[PendingOperation, list[StagedBlock]]]:
        """Collect one source-stable companion for a progressive ticket wave."""

        items = [(operation, list(batch))]
        self._prune_prefetched_write_tickets()
        if (
            not self._multi_put_ticket_batches
            or self._prefetched_write_tickets
            or len(batch) >= MAX_WRITE_TICKETS_PER_REQUEST
        ):
            return items
        goodput = self._put_upload_goodput_bytes_per_second
        byte_budget = (
            BLOCK_BYTES
            if goodput is None
            else max(
                BLOCK_BYTES,
                min(
                    UPLOAD_RESIDENT_PAYLOAD_BYTES,
                    int(
                        goodput
                        * (
                            MAX_WRITE_TICKET_LIFETIME_SECONDS
                            - UPLOAD_TICKET_EXPIRY_GUARD_SECONDS
                        )
                    ),
                ),
            )
        )
        used_bytes = sum(block.size_bytes for block in batch)
        if used_bytes > byte_budget:
            return items
        used_blocks = len(batch)
        head = self.database.get_remote_manifest_head()
        candidates = self.database.list_sendable_operations(
            # Ready-to-commit puts remain sendable while folder uploads are
            # accumulating for one manifest batch. Scan the existing bounded
            # journal page so those rows cannot hide the one missing-byte
            # companion this progressive ticket wave is looking for.
            limit=DEFAULT_MAX_BATCH_MUTATIONS,
            now_ns=self._wall_now_ns(),
        )
        for candidate in candidates:
            if len(items) >= MAX_PROGRESSIVE_WRITE_TICKET_ITEMS:
                break
            if (
                candidate.mutation_id == operation.mutation_id
                or candidate.mutation_id in self._put_upload_states
                or candidate.kind != "put"
                or self._operation_needs_single_path(candidate, head)
            ):
                continue
            remaining_tickets = MAX_WRITE_TICKETS_PER_REQUEST - used_blocks
            if remaining_tickets <= 0:
                break
            try:
                stage_path, plan = self._load_and_fence_put_plan(candidate)
                progress = self._put_progress(candidate, stage_path)
                reusable = (
                    self._reusable_target_blocks(candidate.path)
                    if progress["reuse_target_blocks"]
                    else set()
                )
                satisfied = set(progress["uploaded"]) | reusable
                missing = list(
                    {
                        block.sha256: block
                        for block in plan.blocks
                        if block.sha256 not in satisfied
                    }.values()
                )
                if not missing:
                    continue
                if self._inline_put_eligible(plan, missing):
                    # The commit planner will carry these bytes directly.
                    # Minting tickets here would create unused M632/M1747
                    # admission and cleanup debt for the inline companion.
                    continue
                count = self._put_upload_issue_count(
                    missing,
                    max_concurrency=_upload_concurrency(plan),
                    max_tickets=remaining_tickets,
                )
            except (
                FileProviderSourceUnavailable,
                SourceDrift,
                OSError,
                InvalidTask,
                StateError,
                UnsafePath,
                ValueError,
                StagingRepairPending,
            ):
                continue
            candidate_batch: list[StagedBlock] = []
            for block in missing[:count]:
                if used_bytes + block.size_bytes > byte_budget:
                    break
                candidate_batch.append(block)
                used_bytes += block.size_bytes
                used_blocks += 1
            if candidate_batch:
                items.append((candidate, candidate_batch))
        return items

    def _discard_prefetched_write_tickets(
        self, mutation_id: str, *, reason: str
    ) -> bool:
        """Forget one unused mutation capability without exposing its value."""

        tickets = self._prefetched_write_tickets.pop(mutation_id, None)
        if tickets is None:
            return False
        self.logger.record(
            "fabric_upload_ticket_batch_discarded",
            mutation_id=mutation_id,
            block_count=len(tickets),
            reason=reason,
            prefetched_remaining=len(self._prefetched_write_tickets),
        )
        return True

    def _prune_prefetched_write_tickets(self) -> int:
        """Remove expired or no-longer-sendable companions before gating.

        A prefetched source-backed PUT can be superseded before its exact
        mutation reaches `_initial_put_write_tickets`. Cache liveness therefore
        cannot depend on that pop: terminal, blocked, parked, authority-stale,
        and expired entries are bounded unused capabilities, never reasons to
        disable batching for every later folder burst.
        """

        if not self._prefetched_write_tickets:
            return 0
        now_ns = self._wall_now_ns()
        now_epoch = now_ns / 1_000_000_000
        stale: list[tuple[str, str]] = []
        for mutation_id, tickets in tuple(self._prefetched_write_tickets.items()):
            if not self.database.is_operation_sendable(
                mutation_id, now_ns=now_ns
            ):
                stale.append((mutation_id, "operation_not_sendable"))
                continue
            try:
                headroom = min(
                    _write_ticket_expiry(ticket) for ticket in tickets.values()
                ) - now_epoch
            except (NetworkError, ValueError):
                stale.append((mutation_id, "ticket_invalid"))
                continue
            if not 1.0 < headroom <= MAX_WRITE_TICKET_LIFETIME_SECONDS + 5.0:
                stale.append((mutation_id, "ticket_expired"))
        for mutation_id, reason in stale:
            self._discard_prefetched_write_tickets(mutation_id, reason=reason)
        return len(stale)

    def _edge_read_tickets(
        self, blocks: Sequence[StagedBlock], storage_kind: str | None
    ) -> dict[str, Mapping[str, Any]] | None:
        if storage_kind is None or not self._edge_read_ready():
            return None
        mint = getattr(self.transport, "edge_block_ticket", None)
        if not callable(mint):
            return None
        tickets: dict[str, Mapping[str, Any]] = {}
        for block in blocks:
            ticket = mint(
                method="GET",
                sha256=block.sha256,
                size_bytes=block.size_bytes,
                storage_kind=storage_kind,
            )
            if ticket is None:
                return None
            tickets[block.sha256] = ticket
        return tickets

    def _put_upload_issue_count(
        self,
        missing: Sequence[StagedBlock],
        *,
        max_concurrency: int = 1,
        max_tickets: int = MAX_WRITE_TICKETS_PER_REQUEST,
    ) -> int:
        """Bound one ticket wave by start-time expiry and provider debt.

        Presigned authorization is consumed when a provider PUT starts, not
        when it finishes. The first ``max_concurrency`` payloads start
        immediately and are therefore safe whenever the hard ticket guard
        passed. Only tickets waiting behind an active byte group need measured
        goodput headroom. This lets four 16-MiB source extents use four streams
        under a short attachment lease without reserving a large unused queue.
        """

        if not missing:
            raise StateError("A Fabric upload wave has no missing blocks.")
        if not 1 <= max_concurrency <= UPLOAD_WORKER_CONCURRENCY:
            raise StateError("A Fabric upload wave has an invalid concurrency bound.")
        if not 1 <= max_tickets <= MAX_WRITE_TICKETS_PER_REQUEST:
            raise StateError("A Fabric upload wave has an invalid ticket bound.")
        ticket_bound = min(max_tickets, len(missing))
        immediate = min(max_concurrency, ticket_bound)
        goodput = self._put_upload_goodput_bytes_per_second
        if goodput is None:
            # Bound unknown provider debt to one object. Its completion learns
            # aggregate goodput; the next wave can then fill every safe worker.
            return 1
        usable = max(
            0.0,
            self._put_upload_last_ticket_headroom
            - UPLOAD_TICKET_HARD_GUARD_SECONDS,
        )
        byte_budget = min(
            goodput * usable,
            float(MAX_UPLOAD_TICKET_WAVE_BYTES),
        )
        sizes: list[int] = []
        for block in missing[:ticket_bound]:
            if not 0 <= block.size_bytes <= MAX_CAS_BLOCK_BYTES:
                raise StateError("A Fabric upload wave has an invalid block size.")
            sizes.append(block.size_bytes)
        count = immediate
        for index in range(immediate, ticket_bound):
            # The pool refills only after the active group is empty. This
            # candidate starts after every complete preceding concurrency
            # group, but its transfer may finish after ticket expiry.
            preceding_group_end = (index // max_concurrency) * max_concurrency
            bytes_before_start = sum(sizes[:preceding_group_end])
            if bytes_before_start > byte_budget:
                break
            count += 1
        return count

    def _put_upload_ticket_ttl(self, batch: Sequence[StagedBlock]) -> int:
        """Request enough authority for one measured aggregate byte wave."""

        if not 1 <= len(batch) <= MAX_WRITE_TICKETS_PER_REQUEST:
            raise StateError("A Fabric upload ticket wave exceeds its bound.")
        goodput = self._put_upload_goodput_bytes_per_second
        if goodput is None:
            # The first fixed 4-MiB block is the throughput probe. A 300-second
            # ticket cannot establish progress at the supported 10-15 KiB/s
            # edge floor, so bootstrap with the protocol's bounded maximum.
            return MAX_WRITE_TICKET_LIFETIME_SECONDS
        required = (
            sum(block.size_bytes for block in batch) / max(1.0, goodput)
            + UPLOAD_TICKET_EXPIRY_GUARD_SECONDS
        )
        rounded = int(required)
        if float(rounded) < required:
            rounded += 1
        return max(
            WRITE_TICKET_TTL_SECONDS,
            min(MAX_WRITE_TICKET_LIFETIME_SECONDS, rounded),
        )

    def _schedule_put_upload_group(self, state: _PutUploadState) -> None:
        # Rebalance only at completion boundaries: never cancel a running PUT.
        # Without a fair share, the oldest large file refills all eight slots
        # before its small-file companions ever get to send their first block.
        concurrency = min(
            state.max_concurrency,
            max(1, UPLOAD_WORKER_CONCURRENCY // max(1, len(self._put_upload_states))),
        )
        if not state.pending or len(state.active) >= concurrency:
            return
        now_epoch = self._wall_now_ns() / 1_000_000_000
        # Tickets are minted in several batches while transfers run, so each
        # block is fenced on its own ticket's expiry rather than a wave-wide
        # minimum that would go stale once the earliest batch is consumed.
        next_block = state.pending[0]
        try:
            next_expiry = _write_ticket_expiry(state.tickets[next_block.sha256])
        except (KeyError, NetworkError):
            next_expiry = state.expires_at_epoch
        if now_epoch >= next_expiry - UPLOAD_TICKET_HARD_GUARD_SECONDS:
            state.first_error = NetworkError(
                "The Fabric upload ticket has insufficient expiry headroom."
            )
            return

        def upload_one(block: StagedBlock) -> tuple[str, dict[str, Any]]:
            receipt = self.transport.upload_block(
                state.tickets[block.sha256],
                self._read_put_block(state, block),
            )
            return block.sha256, _upload_part_receipt(receipt, block)

        # Presigned authorization is checked when the PUT starts. A streaming
        # request that began with valid authority may legitimately finish after
        # the URL timestamp, especially on a low-bandwidth edge. Never abandon
        # or reissue that running attempt: it owns one process-wide pool slot
        # until the bounded transport returns a receipt or an error.
        while state.pending and len(state.active) < concurrency:
            block = state.pending[0]
            future = self._put_upload_workers.submit(
                lambda block=block: upload_one(block),
                payload_bytes=block.size_bytes,
            )
            if future is None:
                break
            state.pending.popleft()
            state.active[block.sha256] = (block, future)
            future.add_done_callback(lambda _future: self.wake())

    def _read_put_block(
        self, state: _PutUploadState, block: StagedBlock
    ) -> bytes:
        return self._read_plan_block(state.plan, state.stage_path, block)

    def _read_plan_block(
        self, plan: StagePlan, stage_path: Path, block: StagedBlock
    ) -> bytes:
        if plan.source_kind == "file_provider_fd":
            token = plan.source_token
            if token is None:
                raise StateError("The File Provider source plan has no lease token.")
            with self._file_provider_sources_lock:
                lease = self._file_provider_sources.get(token)
            if lease is None:
                raise FileProviderSourceUnavailable(
                    "the File Provider source must be reattached"
                )
            with lease.lock:
                if lease.cancelled:
                    raise FileProviderSourceUnavailable(
                        "the File Provider source was detached"
                    )
                before = self._descriptor_fingerprint(lease.descriptor)
                if before != lease.fingerprint:
                    raise SourceDrift("the File Provider source changed before block read")
                data = os.pread(
                    lease.descriptor, block.size_bytes, block.offset_bytes
                )
                after = self._descriptor_fingerprint(lease.descriptor)
                if len(data) != block.size_bytes or after != lease.fingerprint:
                    raise SourceDrift("the File Provider source changed during block read")
        elif plan.source_path is None:
            return _read_stage_block(stage_path, block)
        else:
            expected = _fingerprint_from_text(plan.source_fingerprint)
            try:
                data = self.workspace.read_regular_range(
                    plan.source_path,
                    block.offset_bytes,
                    block.size_bytes,
                    expected,
                )
            except (InvalidTask, UnsafePath, OSError) as error:
                raise SourceDrift(
                    "the source-backed upload changed during block read"
                ) from error
        if hashlib.sha256(data).hexdigest() != block.sha256:
            raise SourceDrift(
                "the source-backed upload no longer matches its durable plan"
            )
        return data

    def _poll_put_upload(self, *, allow_signed_control: bool = True) -> bool:
        """Drain every file; spend at most one serialized control turn."""

        calls_before = self._signed_control_calls
        progressed = False
        for state in tuple(self._put_upload_states.values()):
            progressed = self._poll_one_put_upload(
                state,
                allow_signed_control=(allow_signed_control
                    and self._signed_control_calls == calls_before),
            ) or progressed
        return progressed

    def _poll_one_put_upload(
        self, state: _PutUploadState, *, allow_signed_control: bool
    ) -> bool:
        """Drain one byte-wave completion without waiting on stuck futures."""

        operation = self.database.get_operation(state.mutation_id)
        if operation is None or operation.state in ("acked", "conflict", "quarantined"):
            # A running immutable PUT cannot be cancelled. Retain its owner
            # until it settles so stop/replacement never abandons capacity.
            for _block, future in state.active.values():
                future.cancel()
            if any(not future.done() for _block, future in state.active.values()):
                return False
            self._put_upload_states.pop(state.mutation_id, None)
            return True
        completed: list[str] = []
        successful: list[tuple[StagedBlock, dict[str, Any]]] = []
        for digest, (block, future) in tuple(state.active.items()):
            if not future.done():
                continue
            completed.append(digest)
            try:
                result_digest, receipt = future.result()
                if result_digest != digest:
                    raise NetworkError("A Fabric upload worker changed block identity.")
                successful.append((block, receipt))
            except BaseException as error:
                if state.first_error is None:
                    state.first_error = error
        for digest in completed:
            state.active.pop(digest, None)

        if successful:
            progress = self._put_progress(operation, state.stage_path)
            # At most eight receipts enter one append-only frame. This fsync is
            # the boundary after which those provider PUTs are never replayed.
            _append_upload_receipts(
                state.stage_path,
                operation.mutation_id,
                progress,
                tuple((block.sha256, receipt) for block, receipt in successful),
            )
            state.completed_bytes += sum(block.size_bytes for block, _receipt in successful)
            state.completed_blocks += len(successful)

        if state.active and state.first_error is None:
            # Keep the pipeline full while bytes move: refill worker slots
            # from already-minted tickets, mint the next ticket batch before
            # the current one runs dry, and verify landed receipts between
            # transfers instead of after them. Each tick spends at most one
            # signed control call; the transfers never wait for it.
            if state.pending:
                self._schedule_put_upload_group(state)
            if (allow_signed_control and state.first_error is None
                    and self._advance_put_pipeline(operation, state)):
                return True
            return bool(successful)
        if state.first_error is not None:
            if state.active:
                # Do not replay the same mutation while its other immutable
                # PUTs still own sockets; collect their receipts first.
                return bool(successful)
            error = state.first_error
            self._finish_put_upload_state(state)
            self._schedule_operation_retry(operation, error)
            return True
        if state.pending:
            self._schedule_put_upload_group(state)
            if state.first_error is None:
                return bool(successful)
            error = state.first_error
            self._finish_put_upload_state(state)
            self._schedule_operation_retry(operation, error)
            return True

        self._finish_put_upload_state(state)
        self.database.update_operation(
            operation.mutation_id,
            state="retry",
            error="bounded block continuation",
            retry_after_seconds=0.0,
            reset_failures=True,
            now_ns=self._wall_now_ns(),
        )
        return True

    def _advance_put_pipeline(
        self, operation: PendingOperation, state: _PutUploadState
    ) -> bool:
        """Spend one signed control turn on the running upload if it helps.

        Returns ``True`` when a ticket batch was minted or receipts were
        verified. Unverified provider debt is bounded to two waves so a slow
        file keeps renewing server-side proof; ticket minting is bounded by the
        measured lease headroom exactly like the first wave.
        """

        if float(self._clock()) < self._signed_control_not_before:
            return False
        progress = self._put_progress(operation, state.stage_path)
        receipts = progress["receipts"]
        verified = set(progress["verified"])
        unverified = [
            block
            for block in dict(
                (block.sha256, block) for block in state.plan.blocks
            ).values()
            if block.sha256 in receipts and block.sha256 not in verified
        ]
        ticketed = set(state.tickets)
        reusable = (
            self._reusable_target_blocks(operation.path)
            if progress["reuse_target_blocks"]
            else set()
        )
        satisfied = set(progress["uploaded"]) | reusable | ticketed
        missing = list(
            {
                block.sha256: block
                for block in state.plan.blocks
                if block.sha256 not in satisfied
            }.values()
        )
        want_tickets = bool(missing) and not state.pending
        debt_blocks = len(unverified) + len(state.active) + len(state.pending)
        # A file whose whole proof fits one commit never spends a control turn
        # on verification while bytes move: the commit proves it in one call.
        # Larger files verify a full batch at a time, or when unverified debt
        # blocks the next ticket wave.
        if (
            unverified
            and not self._commit_can_verify(state.plan)
            and (
                len(unverified) >= MAX_VERIFY_BLOCKS_PER_REQUEST
                or (want_tickets and debt_blocks > 2 * MAX_WRITE_TICKETS_PER_REQUEST)
                # Nothing left to upload, and this commit cannot prove these
                # blocks itself. Both thresholds above only rise with upload
                # pressure, so with the bytes already delivered they can never
                # be reached and the proof would never be renewed -- the file
                # sits `inflight` on "bounded block continuation" forever.
                #
                # Reachable only under v2 with no inline channel: v1 and the
                # inline lane both let the commit carry the proof, so
                # `_commit_can_verify` is true and this branch is skipped
                # entirely. That combination is exactly what a node meets
                # against a control plane without M1771, which is the case
                # that has to keep working.
                or not (missing or state.active or state.pending)
            )
        ):
            try:
                self._verify_put_receipts(
                    operation,
                    state.stage_path,
                    progress,
                    unverified[:MAX_VERIFY_BLOCKS_PER_REQUEST],
                )
            except (RemoteError, NetworkError, StateError) as error:
                state.first_error = error
            return True
        if (
            want_tickets
            # The first block of a process is the throughput probe; minting
            # behind it one ticket per control turn would spend a signed call
            # per block. Let the probe land, then issue the whole wave.
            and self._put_upload_goodput_bytes_per_second is not None
            and debt_blocks <= 2 * MAX_WRITE_TICKETS_PER_REQUEST
        ):
            try:
                self._mint_put_tickets(operation, state, missing)
            except (RemoteError, NetworkError, StateError) as error:
                state.first_error = error
            return True
        return False

    # Two capabilities, deliberately separate. They were one predicate while
    # the v2 wire could carry neither, and merging the inline channel into
    # that shape is what made a broken cohort look correct: adding a byte
    # channel does not add a verify-list channel, and conflating them either
    # kills inline (refuse everything) or ships a verify list into a field
    # that does not exist (accept everything).

    def _commit_carries_inline_bytes(self) -> bool:
        """Whether the commit request can carry block BYTES.

        v1 carries them on ``mutate_batch``; v2 carries them in
        ``inline_blocks`` on the commit itself, where the server hashes what it
        received, PUTs it into CAS and reads it back before recording the
        entry. A control plane without that field REJECTS the whole request
        (the v2 body is allow-listed with `exactKeys`, which throws rather than
        strips), so the lane can be optimistic: the failure mode is one
        refused request with no effect, never a committed entry with no bytes.
        """

        if self._v2_commit_active():
            return self._inline_supported_now()
        return self._mutate_verifies_blocks

    def _commit_carries_verify_list(self) -> bool:
        """Whether the commit request can carry a client VERIFY LIST.

        v2 cannot, and should not. ``_v2_commit_ops`` sends one op per path
        holding the block layout descriptor only -- index, offset, size,
        digest -- with no field for a list of blocks the client wants proven,
        so anything a caller puts in ``commit_blocks`` would simply not be
        transmitted. The server does that job itself now
        (`resolveFabricV2PresentBlocks` asks the database and reads back from
        the store what it cannot vouch for). Receipt-backed uploads within
        that readback budget therefore commit without a separate verification
        request. Larger unproven files keep the ordinary bounded verify lane.
        """

        return self._mutate_verifies_blocks and not self._v2_commit_active()

    def _commit_can_verify(self, plan: StagePlan) -> bool:
        """True when the commit can prove every block of ``plan`` itself."""

        return (
            self._commit_carries_verify_list()
            and len({block.sha256 for block in plan.blocks})
            <= MAX_VERIFY_BLOCKS_PER_REQUEST
        )

    def _mint_put_tickets(
        self,
        operation: PendingOperation,
        state: _PutUploadState,
        missing: Sequence[StagedBlock],
    ) -> None:
        issue_count = self._put_upload_issue_count(
            missing, max_concurrency=state.max_concurrency
        )
        batch = list(missing[:issue_count])
        edge_tickets = self._edge_write_tickets(batch)
        if edge_tickets is not None:
            tickets = edge_tickets
        else:
            response = self._signed_control_request(
                self.transport.blocks,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "operation": "write_batch",
                    "mutation_id": operation.mutation_id,
                    "ttl_seconds": self._put_upload_ticket_ttl(batch),
                    "blocks": [
                        {"sha256": block.sha256, "size_bytes": block.size_bytes}
                        for block in batch
                    ],
                },
            )
            tickets = _block_tickets(response, operation.mutation_id, batch)
        expiry = min(_write_ticket_expiry(ticket) for ticket in tickets.values())
        headroom = expiry - (self._wall_now_ns() / 1_000_000_000)
        if headroom <= 1.0 or headroom > MAX_WRITE_TICKET_LIFETIME_SECONDS + 5.0:
            raise NetworkError(
                "Meshia returned an expired or excessive Fabric upload ticket."
            )
        self._put_upload_last_ticket_headroom = max(0.0, headroom)
        state.tickets = {**state.tickets, **tickets}
        state.pending.extend(batch)
        state.expires_at_epoch = min(state.expires_at_epoch, expiry)
        self.logger.record(
            "fabric_upload_wave_extended",
            mutation_id=operation.mutation_id,
            path=operation.path,
            scheduled_blocks=len(batch),
            scheduled_bytes=sum(block.size_bytes for block in batch),
            active_blocks=len(state.active),
            ticket_headroom_ms=round(headroom * 1_000),
        )
        self._schedule_put_upload_group(state)

    def _finish_put_upload_state(self, state: _PutUploadState) -> None:
        duration = max(0.0, float(self._clock()) - state.started_at)
        observed: float | None = None
        if state.completed_bytes > 0:
            observed = (
                state.completed_bytes / duration
                if duration > 0
                else float(state.completed_bytes) * 1_000.0
            )
            previous = self._put_upload_goodput_bytes_per_second
            self._put_upload_goodput_bytes_per_second = max(
                1.0,
                (
                    observed
                    if previous is None or observed <= previous
                    # Recover from one slow/provider-scheduler outlier without
                    # jumping straight back to a stale optimistic estimate.
                    else min(observed, previous * 1.5)
                ),
            )
        error = state.first_error
        self.logger.record(
            "fabric_upload_wave_completed",
            mutation_id=state.mutation_id,
            path=state.plan.path,
            outcome="retry" if error is not None else "uploaded",
            completed_blocks=state.completed_blocks,
            completed_bytes=state.completed_bytes,
            duration_ms=round(duration * 1_000),
            observed_goodput_bytes_per_second=(
                round(observed) if observed is not None else 0
            ),
            estimated_goodput_bytes_per_second=round(
                self._put_upload_goodput_bytes_per_second or 0.0
            ),
            max_concurrency=state.max_concurrency,
            aggregate_buffer_limit_bytes=UPLOAD_RESIDENT_PAYLOAD_BYTES,
            uploaded_unique_blocks=(
                state.uploaded_unique_blocks_before + state.completed_blocks
            ),
            verified_unique_blocks=state.verified_unique_blocks_before,
            total_unique_blocks=len(
                {block.sha256 for block in state.plan.blocks}
            ),
            error_code=(
                getattr(error, "code", type(error).__name__)
                if error is not None
                else None
            ),
        )
        self._put_upload_states.pop(state.mutation_id, None)

    def _put_progress(
        self, operation: PendingOperation, stage_path: Path
    ) -> dict[str, Any]:
        key = (operation.mutation_id, str(stage_path))
        if self._put_progress_cache_key != key or self._put_progress_cache is None:
            self._put_progress_cache_key = key
            self._put_progress_cache = _load_progress(
                stage_path, operation.mutation_id
            )
        return self._put_progress_cache

    def _send_path_mutation(
        self,
        operation: PendingOperation,
        *,
        plan: StagePlan | None = None,
        verify_blocks: Sequence[StagedBlock] | None = None,
    ) -> dict[str, Any]:
        # Proactive rebase: our own earlier commits advanced the head since
        # this operation was journaled. Rebinding a never-signed operation
        # locally avoids a BASE_DIVERGED round trip plus a signed refresh for
        # every file after the first in a burst.
        rebased = self.database.rebase_never_sent_operation_to_current_head(
            operation.mutation_id, now_ns=self._wall_now_ns()
        )
        if rebased is not None:
            operation = rebased
        payload = self._path_mutation_payload(
            operation, plan=plan, verify_blocks=verify_blocks
        )
        request_digest = _mutation_request_digest(
            self.authority.session_id, payload
        )
        payload["request_digest"] = request_digest
        # FULL-synchronous SQLite commit is the write-ahead fence: after this
        # point every crash/network failure must query mutation-status before
        # another mutate POST. The digest remains frozen unless an explicit
        # precommit BASE_DIVERGED response and signed refresh atomically prove
        # that the same path expectations can be rebound to a newer head.
        self.database.mark_operation_commit_unknown(
            operation.mutation_id,
            request_digest=request_digest,
            now_ns=self._wall_now_ns(),
        )
        try:
            response = self._signed_control_request(self.transport.mutate, payload)
        except RemoteError as error:
            if _is_precommit_safe_mutation_rejection(error):
                self.database.clear_operation_commit_unknown_for_retry(
                    operation.mutation_id,
                    reason="remote mutation rejection authoritatively proved no commit",
                    now_ns=self._wall_now_ns(),
                )
            raise
        if self._batch_size_limit < 2 and self._batching_enabled():
            # Batches backed off to singles; a commit that lands in time lets
            # the bound grow again.
            self._note_batch_success()
        return _mutation_receipt(
            response,
            operation,
            plan=plan,
            request_digest=request_digest,
        )

    def _path_mutation_payload(
        self,
        operation: PendingOperation,
        *,
        plan: StagePlan | None = None,
        verify_blocks: Sequence[StagedBlock] | None = None,
    ) -> dict[str, Any]:
        """Reconstruct the one canonical wire request bound to a mutation UUID.

        ``verify_blocks`` asks the commit to verify those uploaded blocks
        itself (bounded to one verify call's worth). It rides outside the
        digested ``mutation`` document, so the request digest is unchanged.
        """

        base_generation = operation.base_generation or 0
        mutation: dict[str, Any]
        if operation.kind == "put":
            assert plan is not None
            block_size = (
                _plan_block_size(plan)
                if _plan_is_source_backed(plan) and plan.size_bytes
                else (BLOCK_BYTES if plan.size_bytes else 1)
            )
            mutation = {
                "operation": "put",
                "path": operation.path,
                "expected_source": _expectation(operation.expected_source_digest),
                "descriptor": {
                    "kind": "file",
                    "size_bytes": plan.size_bytes,
                    "sha256": plan.sha256,
                    "modified_at": plan.modified_at,
                    "blocks": _stage_plan_blocks_descriptor(
                        plan,
                        block_size=block_size,
                    ),
                },
            }
        elif operation.kind == "delete":
            mutation = {
                "operation": "delete",
                "path": operation.path,
                "expected_source": _expectation(operation.expected_source_digest),
            }
        else:
            if operation.destination_path is None:
                raise StateError("A queued Fabric rename has no destination.")
            mutation = {
                "operation": "rename",
                "source_path": operation.path,
                "destination_path": operation.destination_path,
                "expected_source": (
                    {"kind": "directory", "digest": None}
                    if operation.directory_rename
                    else _expectation(operation.expected_source_digest)
                ),
                "expected_destination": _expectation(operation.expected_destination_digest),
            }
        payload: dict[str, Any] = {
            "attachment_id": self.authority.attachment_id,
            "workspace": WORKSPACE_MOUNT,
            "mutation_id": operation.mutation_id,
            "base_generation": base_generation,
            "base_manifest_digest": operation.base_digest,
            "mutation": mutation,
        }
        if verify_blocks:
            payload["verify_blocks"] = [
                {"sha256": block.sha256, "size_bytes": block.size_bytes}
                for block in verify_blocks
            ]
            if self._direct_block_admission():
                payload["direct_blocks"] = True
        return payload

    def _v2_commit_ops(
        self, entries: Sequence[_BatchCommitEntry]
    ) -> list[dict[str, Any]]:
        """Build Fabric v2 per-path ops for a planned cohort.

        This is the whole shape change. v1 sent, per mutation, a full
        namespace manifest preimage that the server hashed and validated --
        O(workspace) per file, and the reason a folder upload was O(N^2). A v2
        op names one path, the digest it expects to replace, and (for a put)
        the content identity. Request size becomes O(changed).

        ``expected_source_digest`` is exactly the per-path compare-and-swap
        token the server wants: the node already tracks what it believed the
        remote held, so no new state is needed to move from a global
        generation fence to a per-path one. Two clients touching different
        paths stop contending entirely.

        Pure by construction (no I/O, no journal writes) so it can be tested
        against fixtures without a coordinator or a network.
        """

        ops: list[dict[str, Any]] = []
        for entry in entries:
            operation = entry.operation
            # _digest is a validator, not a normaliser: keep the digest only
            # when it is well formed, so a malformed local value can never be
            # sent as a CAS token.
            raw_prev = operation.expected_source_digest
            prev = raw_prev if _digest(raw_prev) else None
            if operation.kind == "put":
                plan = entry.plan
                if plan is None:
                    raise StateError("A Fabric v2 put op needs a staged plan.")
                block_size = (
                    _plan_block_size(plan)
                    if _plan_is_source_backed(plan) and plan.size_bytes
                    else (BLOCK_BYTES if plan.size_bytes else 1)
                )
                op: dict[str, Any] = {
                    "op": "put",
                    "path": operation.path,
                    "kind": "file",
                    "digest": plan.sha256,
                    "size_bytes": plan.size_bytes,
                    "blocks": _stage_plan_blocks_descriptor(
                        plan, block_size=block_size
                    ),
                }
                if plan.modified_at is not None:
                    op["modified_at"] = plan.modified_at
            elif operation.kind == "delete":
                op = {"op": "delete", "path": operation.path}
            else:
                if operation.destination_path is None:
                    raise StateError("A queued Fabric rename has no destination.")
                op = {
                    "op": "rename",
                    "path": operation.path,
                    "destination_path": operation.destination_path,
                }
                # A directory rename moves a subtree the server walks by
                # prefix; it has no single content digest to fence on, so the
                # per-path CAS token is omitted rather than faked.
                if operation.directory_rename:
                    prev = None
            if prev is not None:
                op["prev_digest"] = prev
            ops.append(op)
        return ops

    def _ack_mutation(
        self,
        operation: PendingOperation,
        receipt: Mapping[str, Any],
        *,
        plan: StagePlan | None = None,
        blocks_provider_verified: bool = False,
    ) -> None:
        """Settle one acknowledged mutation.

        ``blocks_provider_verified`` must be True only when THIS process saw
        the provider confirm every block of ``plan`` through the dedicated
        block-verify endpoint. It is deliberately False for the
        commit-unknown replay path, where the node learns the mutation
        committed but never observed its own bytes land.
        """

        if operation.kind == "put" and plan is not None:
            receipt = dict(receipt)
            receipt.setdefault("entry_modified_at", plan.modified_at)
        entry_digest = plan.sha256 if plan else receipt.get("entry_sha256")
        if entry_digest is not None and not _digest(entry_digest):
            entry_digest = None
        # A published commit proves this node's head belief is usable, exactly
        # as a landed batch proves the batch lane works in `_note_batch_success`.
        # Restore every operation's BASE_INVALID refresh budget so a burst that
        # merely raced one head reset cannot spend it down across files.
        self._base_invalid_refreshes.clear()
        operation_acked = False
        if operation.kind == "put" and plan is not None:
            self._finalize_committed_path(
                operation,
                operation.path,
                committed_digest=plan.sha256,
                committed_fingerprint=(
                    None
                    if plan.source_kind == "file_provider_fd"
                    else _fingerprint_from_text(plan.source_fingerprint)
                ),
                blocks_provider_verified=blocks_provider_verified,
                file_provider_source=(
                    plan.source_kind == "file_provider_fd"
                ),
            )
            if (
                plan.delete_after_ack_path is not None
                and plan.delete_after_ack_digest is not None
            ):
                transfer_intent = (
                    self.database.get_local_transfer_intent_by_id(
                        operation.mutation_id
                    )
                    if plan.transfer_logical_path is not None
                    or _plan_is_source_backed(plan)
                    else None
                )
                if (
                    (
                        plan.transfer_logical_path is not None
                        or _plan_is_source_backed(plan)
                    )
                    and (
                        transfer_intent is None
                        or transfer_intent.delete_mutation_id is None
                    )
                ):
                    raise StateError(
                        "The large rename lost its durable source-delete dependency."
                    )
                if transfer_intent is not None:
                    assert transfer_intent.delete_mutation_id is not None
                    # The transfer intent is the only durable copy of the
                    # deterministic source-delete UUID. Publish the receipt,
                    # successor and intent retirement in one SQLite transaction
                    # so a crash can never strand an acknowledged rename-put.
                    self.database.ack_put_with_dependent_delete(
                        operation.mutation_id,
                        delete_mutation_id=transfer_intent.delete_mutation_id,
                        delete_path=plan.delete_after_ack_path,
                        delete_base_generation=int(receipt["manifest_generation"]),
                        delete_base_digest=_receipt_manifest_digest(receipt),
                        delete_expected_source_digest=plan.delete_after_ack_digest,
                        remote_generation=int(receipt["manifest_generation"]),
                        remote_manifest_digest=_receipt_manifest_digest(receipt),
                        remote_entry_digest=plan.sha256,
                        receipt=dict(receipt),
                        # The dependent delete shares the parent's compact
                        # callback marker.  That keeps both exact receipts
                        # replayable across a process death after a compound
                        # save committed but before Apple observed success.
                        delete_staged_path=(
                            operation.staged_path
                            if plan.source_kind == "file_provider_fd"
                            else None
                        ),
                    )
                    operation_acked = True
                else:
                    self.database.enqueue_delete(
                        plan.delete_after_ack_path,
                        base_generation=int(receipt["manifest_generation"]),
                        base_digest=str(receipt["manifest_digest"]),
                        expected_source_digest=plan.delete_after_ack_digest,
                    )
                self.database.mark_materialized(
                    plan.delete_after_ack_path,
                    state="dirty",
                    clean_digest=plan.delete_after_ack_digest,
                    bytes_on_disk=0,
                )
                self.watch.acknowledge_local_state(
                    {plan.delete_after_ack_path: None}
                )
        elif operation.kind == "delete":
            self._finalize_committed_path(
                operation,
                operation.path,
                committed_digest=None,
            )
        else:
            assert operation.destination_path is not None
            if not operation.directory_rename:
                committed_digest = operation.expected_source_digest
                destination_materialized = self.database.get_materialized(
                    operation.destination_path
                )
                destination_fingerprint = (
                    _fingerprint_from_text(destination_materialized.stat_fingerprint)
                    if destination_materialized is not None
                    and destination_materialized.stat_fingerprint is not None
                    else None
                )
                self._finalize_committed_path(
                    operation,
                    operation.path,
                    committed_digest=None,
                )
                self._finalize_committed_path(
                    operation,
                    operation.destination_path,
                    committed_digest=committed_digest,
                    committed_fingerprint=destination_fingerprint,
                )
        # The stable mutation ID makes replay safe. Finalize local state before
        # recording the ack so a crash can only replay/finalize again; it can
        # never strand an acked operation behind a dirty/staging materialization.
        if not operation_acked:
            self.database.ack_operation(
                operation.mutation_id,
                remote_generation=int(receipt["manifest_generation"]),
                remote_manifest_digest=_receipt_manifest_digest(receipt),
                remote_entry_digest=str(entry_digest) if entry_digest else None,
                receipt=dict(receipt),
            )
        if plan is not None and plan.source_kind == "file_provider_fd":
            self.release_file_provider_source(operation.mutation_id)
        self._discard_prefetched_write_tickets(
            operation.mutation_id, reason="operation_acked"
        )
        if operation.kind == "put" and plan is not None:
            # The read cache is disposable. Never let its SQLite/filesystem
            # cleanup stand between a proven remote commit and the durable
            # operation ACK; bounded acknowledged-stage maintenance retries an
            # interrupted unpin.
            try:
                self.cache.unpin_owner(
                    f"operation:{operation.mutation_id}", plan.sha256
                )
            except (OSError, FabricCacheError) as error:
                self.logger.record(
                    "fabric_acked_cache_cleanup_deferred",
                    mutation_id=operation.mutation_id,
                    error=str(error),
                )
        # Do not manufacture a full local manifest from our one-path receipt:
        # the server may have rebased over disjoint pod writes. The next signed
        # change poll advances through the authoritative complete chain.
        self._receipt_readback_pending = True
        self._next_remote_poll = 0.0

    @staticmethod
    def _operation_effect_digest(
        operation: PendingOperation, path: str
    ) -> str | None:
        """Return the exact namespace result one queued operation promises."""

        if operation.kind == "put" and operation.path == path:
            return operation.staged_digest
        if operation.kind == "delete" and operation.path == path:
            return None
        if operation.kind == "rename":
            if operation.path == path:
                return None
            if operation.destination_path == path:
                return operation.expected_source_digest
        raise StateError("A Fabric successor does not affect the expected path.")

    def _operation_represents_local_state(
        self,
        operation: PendingOperation,
        path: str,
        fingerprint: FileFingerprint | None,
    ) -> bool:
        """Prove that a durable successor already owns the observed local state."""

        if operation.kind == "put" and operation.path == path:
            if fingerprint is None or operation.staged_path is None:
                return False
            plan = _load_plan(Path(operation.staged_path), operation)
            return plan.source_fingerprint == _fingerprint_text(fingerprint)
        if operation.kind == "delete" and operation.path == path:
            return fingerprint is None
        if operation.kind == "rename":
            if operation.path == path:
                return fingerprint is None
            if operation.destination_path == path and fingerprint is not None:
                materialized = self.database.get_materialized(path)
                return (
                    materialized is not None
                    and materialized.state in ("dirty", "staging")
                    and materialized.stat_fingerprint
                    == _fingerprint_text(fingerprint)
                )
        return False

    def _finalize_committed_path(
        self,
        parent: PendingOperation,
        path: str,
        *,
        committed_digest: str | None,
        committed_fingerprint: FileFingerprint | None = None,
        blocks_provider_verified: bool = False,
        file_provider_source: bool = False,
    ) -> None:
        """Classify one receipt path without overwriting a same-edge successor.

        The remote receipt is durable before this method runs.  A user edit,
        delete, or recreate can therefore arrive after the request was sent but
        before its response.  Snapshot that state *before* acknowledging the
        parent; the dependency row lets ``ack_operation`` atomically rebase the
        successor to this receipt's exact generation/digest.  On response-loss
        replay an already-durable successor is recognized by its exact local
        fingerprint, so no second stage is manufactured.
        """

        fingerprint = self.workspace.stat_fingerprint(path)
        latest = self.database.get_latest_nonterminal_operation(path)
        expected_source_digest = committed_digest
        if latest is not None and latest.mutation_id != parent.mutation_id:
            expected_source_digest = self._operation_effect_digest(latest, path)
            if self._operation_represents_local_state(latest, path, fingerprint):
                return

        if file_provider_source:
            # File Provider's APFS working set is a separate cache authority.
            # Absence from the legacy Meshia working-set directory is not a
            # deletion and must never manufacture a tombstone after a
            # successful native upload.  If no legacy inode exists, remember
            # only that the remote version is clean and locally dataless.
            if fingerprint is None:
                self.database.mark_materialized(
                    path,
                    state="absent",
                    clean_digest=committed_digest,
                    bytes_on_disk=0,
                )
            return

        if fingerprint is None:
            if expected_source_digest is None:
                self.database.mark_materialized(
                    path,
                    state="absent",
                    clean_digest=committed_digest,
                    bytes_on_disk=0,
                )
            elif (
                parent.kind == "rename"
                and path == parent.destination_path
                and (remote_only := self.database.get_materialized(path)) is not None
                and remote_only.state == "absent"
                and remote_only.clean_digest == committed_digest
            ):
                # A native File Provider metadata rename intentionally leaves
                # the ordinary working-set cache dataless. Absence in that
                # cache is not a user delete in the separately managed domain.
                self.database.mark_materialized(
                    path,
                    state="absent",
                    clean_digest=committed_digest,
                    bytes_on_disk=0,
                )
            else:
                self._stage_delete(
                    path,
                    expected_source_digest=expected_source_digest,
                )
            return

        if (
            latest is not None
            and latest.mutation_id == parent.mutation_id
            and committed_digest is not None
            and committed_fingerprint == fingerprint
        ):
            # The receipt is durable and ``committed_fingerprint`` proves the
            # visible bytes are exactly what the remote now holds, so this copy
            # is re-fetchable and becomes an ordinary cache entry. It used to
            # stay pinned forever, which made every byte a user ever uploaded
            # permanently unevictable: materialized usage grew without bound,
            # eviction found zero candidates, and once usage passed the cache
            # budget every later hydration was refused for the whole workspace.
            # The pin exists to protect an only-copy; after this point there is
            # a second, authoritative copy.
            self.database.mark_materialized(
                path,
                state="clean",
                clean_digest=committed_digest,
                stat_fingerprint=_fingerprint_text(fingerprint),
                bytes_on_disk=fingerprint.size_bytes,
                pinned=False,
                # Unpinning alone is not licence to delete. The row only
                # becomes evictable once something proves the bytes are
                # retrievable, and a commit receipt is not that proof: it
                # says the control plane recorded the mutation, not that
                # every block reached object storage. Only blocks confirmed
                # by the dedicated HEAD-verify endpoint count here.
                remote_verified=True if blocks_provider_verified else None,
            )
            return

        # Capture first and leave the materialization dirty/staging.  Recording
        # the predecessor as clean before the successor exists would create a
        # crash window in which startup could trust stale bytes and discard the
        # user's later edge.
        self._stage_local_put_bounded(
            path,
            expected_source_digest=expected_source_digest,
        )

    def _defer_operation_conflict_for_refresh(
        self,
        operation: PendingOperation,
        reason: str,
        *,
        remote_code: str | None = None,
        count_failure: bool = False,
    ) -> None:
        """Persist a same-path conflict fence before fetching its winner.

        ``count_failure`` accrues the rejection durably and backs the row off.
        The v1 lane deliberately does not: one BASE_DIVERGED refresh is a
        single ordered step, and zeroing the counter keeps a slow rebase from
        inheriting unrelated network backoff. The v2 per-path lane needs the
        opposite, because a rejection there is re-armed for retry BEFORE this
        runs; without counting, a code that recurs returns to the queue at
        failure_count 0 with a zero retry deadline and burns one signed
        control call every tick forever (measured: 26 identical rejected
        commits in 80 ticks, never converging).
        """

        bounded_reason = str(reason)[:3_000]
        marker_prefix = (
            _AUTHORITATIVE_BASE_DIVERGED_PREFIX
            if remote_code == "FABRIC_MUTATION_BASE_DIVERGED"
            else _AUTHORITATIVE_CONFLICT_PREFIX
        )
        # The refresh itself is driven by `_authoritative_conflicts_waiting`,
        # not by this deadline, so backing the row off delays only a repeat
        # SEND. Recovery still happens on the very next authoritative read.
        delay = (
            _operation_retry_delay(
                operation.mutation_id, operation.failure_count + 1
            )
            if count_failure
            else 0.0
        )
        self.database.update_operation(
            operation.mutation_id,
            state="retry",
            error=f"{marker_prefix}{bounded_reason}",
            retry_after_seconds=delay,
            reset_failures=not count_failure,
            count_failure=count_failure,
            now_ns=self._wall_now_ns(),
        )
        self._authoritative_conflicts_waiting.add(operation.mutation_id)
        self._force_full_remote = True
        self._next_remote_poll = 0.0
        self.logger.record(
            "fabric_conflict_refresh_required",
            mutation_id=operation.mutation_id,
            path=operation.path,
        )

    def _finalize_authoritative_operation_conflicts(self) -> None:
        """Record refreshed winner identity while retaining losing user bytes."""

        # The signed mutation lane admits one operation per poll and the first
        # waiting conflict forces that lane into remote refresh, so this set is
        # normally cardinality one. Keep an explicit bound if that invariant is
        # relaxed later; remaining markers can request another refresh safely.
        pending = tuple(sorted(self._authoritative_conflicts_waiting))[
            : self.max_mutations_per_tick
        ]
        for mutation_id in pending:
            operation = self.database.get_operation(mutation_id)
            if operation is None or operation.state in {
                "acked",
                "conflict",
                "quarantined",
            }:
                self._authoritative_conflicts_waiting.discard(mutation_id)
                continue
            marker = operation.last_error
            marker_prefix = next(
                (
                    prefix
                    for prefix in (
                        _AUTHORITATIVE_BASE_DIVERGED_PREFIX,
                        _AUTHORITATIVE_CONFLICT_PREFIX,
                    )
                    if marker is not None and marker.startswith(prefix)
                ),
                None,
            )
            if marker_prefix is None:
                # A coalesced successor replaced this stale decision while the
                # refresh was in flight; never conflict the newer operation.
                self._authoritative_conflicts_waiting.discard(mutation_id)
                continue
            assert marker is not None
            reason = marker[len(marker_prefix) :]
            try:
                converged = self._converge_equivalent_remote_effect(operation)
                rebased = None
                if (
                    not converged
                    and marker_prefix == _AUTHORITATIVE_BASE_DIVERGED_PREFIX
                ):
                    if operation.request_digest is None:
                        raise StateError(
                            "A base-diverged operation lost its frozen request digest."
                        )
                    rebased = self.database.rebase_precommit_operation_to_current_head(
                        operation.mutation_id,
                        expected_request_digest=operation.request_digest,
                        expected_marker=marker,
                        now_ns=self._wall_now_ns(),
                    )
                    if rebased is not None:
                        batch = (
                            self.database.rebase_compatible_never_sent_operations_to_current_head(
                                rebased.mutation_id,
                                limit=BASE_DIVERGED_REBASE_BATCH,
                                now_ns=self._wall_now_ns(),
                            ) if rebased.base_digest is not None else ()
                        )
                        if (
                            self._namespace_preflight_mutation_id
                            == operation.mutation_id
                        ):
                            self._namespace_preflight_mutation_id = None
                        self.logger.record(
                            "fabric_precommit_base_divergence_rebased",
                            mutation_id=operation.mutation_id,
                            path=operation.path,
                            base_generation=rebased.base_generation,
                        )
                        if batch:
                            self.logger.record(
                                "fabric_precommit_base_divergence_batch_rebased",
                                root_mutation_id=rebased.mutation_id,
                                operation_count=len(batch),
                                base_generation=rebased.base_generation,
                            )
                if not converged and rebased is None:
                    self._record_operation_conflict(operation, reason)
            except (OSError, InvalidTask, StateError, UnsafePath, ValueError):
                # The signed refresh remains authoritative, but local receipt
                # finalization did not complete. Preserve the durable marker
                # and force another refresh; never replay the rejected POST or
                # strand a clean materialization without its ACK row.
                self._force_full_remote = True
                self._next_remote_poll = 0.0
                raise
            self._authoritative_conflicts_waiting.discard(mutation_id)
        if self._authoritative_conflicts_waiting:
            self._force_full_remote = True
            self._next_remote_poll = 0.0

    def _converge_equivalent_remote_effect(
        self, operation: PendingOperation
    ) -> bool:
        """Retire a stale duplicate mutation after proving exact convergence.

        Native filesystem backends may deliver a late destination notification
        after an earlier rename/PUT already published the same bytes, or a
        second delete after the first already removed the path. The stale
        operation then fails its path precondition even though its effect is
        authoritative. Treating that as a user conflict is both noisy and
        sticky; replaying it would be unsafe.

        This fast path is intentionally narrow: the refreshed remote digest and
        size plus immutable PUT stage must all agree, or a DELETE's path must be
        absent. Any mismatch retains the normal conflict path. The authoritative
        effect is acknowledged through the ordinary ACK machinery so
        dependencies and conflict-resolution successors retain their exact
        durable receipt semantics.
        """

        head = self.database.get_remote_manifest_head()
        if head is None:
            return False
        remote = self.database.get_remote_entry(operation.path)
        if operation.kind == "delete":
            if remote is not None:
                return False
            self._ack_mutation(
                operation,
                {
                    "schema": "meshia.fabric.authoritative_effect_receipt.v1",
                    "mutation_id": operation.mutation_id,
                    "manifest_generation": head.generation,
                    "manifest_digest": head.digest,
                    "entry_sha256": None,
                    "effect": "already_absent_after_authoritative_refresh",
                },
            )
            self.logger.record(
                "fabric_redundant_delete_converged",
                mutation_id=operation.mutation_id,
                path=operation.path,
                remote_generation=head.generation,
            )
            return True
        if (
            operation.kind != "put"
            or operation.staged_path is None
            or operation.staged_digest is None
            or operation.staged_size is None
        ):
            return False
        if (
            remote is None
            or remote.digest != operation.staged_digest
            or remote.size_bytes != operation.staged_size
        ):
            return False
        plan = _load_plan(Path(operation.staged_path), operation)
        fingerprint = self.workspace.stat_fingerprint(operation.path)
        if fingerprint is None:
            return False
        if _fingerprint_text(fingerprint) != plan.source_fingerprint:
            # A Finder re-copy replaces the visible inode, so the stat identity
            # captured by this plan no longer matches even when the bytes are
            # unchanged. Identity alone must not refuse convergence: without
            # this fallback an identical re-copy keeps failing its precondition
            # and re-enters the authoritative refresh lane on every poll (the
            # observed ~12 fabric_conflict_refresh_required in 8 s for one
            # path). Content is the authority here, so prove it directly: the
            # remote digest already equals this operation's staged digest, so
            # converge only when the current local bytes hash to that same
            # digest. Any mismatch is a real edge and keeps the conflict path.
            local = self._hash_regular_file(operation.path)
            if (
                local is None
                or local.sha256 != operation.staged_digest
                or fingerprint.size_bytes != operation.staged_size
            ):
                return False

        self._ack_mutation(
            operation,
            {
                "schema": "meshia.fabric.authoritative_effect_receipt.v1",
                "mutation_id": operation.mutation_id,
                "manifest_generation": head.generation,
                "manifest_digest": head.digest,
                "entry_sha256": remote.digest,
                "effect": "already_converged_after_authoritative_refresh",
            },
            plan=plan,
        )
        self.logger.record(
            "fabric_redundant_put_converged",
            mutation_id=operation.mutation_id,
            path=operation.path,
            remote_generation=self._remote_generation(),
        )
        return True

    def _auto_resolve_satisfied_conflicts(self) -> int:
        """Retire/re-arm conflict-state ops the refreshed remote now settles.

        A rename or put can be parked ``state=conflict`` after a rejection --
        e.g. a directory rename the server answered FABRIC_PATH_ABSENT before it
        knew the source -- and then the remote independently reaches the op's
        intended outcome (the same move applied server-side, another client).
        The op then sits conflict forever though there is nothing left to do.
        Run on each remote refresh, re-examine conflict-state rename/put ops
        that never crossed the remote boundary (unsent, no receipt, no unknown
        commit -- so the op cannot itself BE the effect we see):

        * intent already satisfied (rename: destination present, source absent;
          put: path present with the staged digest) -> resolve as satisfied, so
          the resolved-conflict cleanup retires the row;
        * not yet satisfied but now re-submittable (rename whose source is
          present and destination absent) -> re-arm for ONE fresh submit.

        Cheap: only called when the remote actually changed, and it touches only
        ops that are already parked in conflict.
        """

        resolved = 0
        for operation in self.database.list_operations(states=("conflict",)):
            if (
                operation.commit_unknown
                or operation.request_digest is not None
                or operation.kind not in ("rename", "put")
            ):
                continue
            if self._remote_satisfies_conflict_intent(operation):
                if self.database.resolve_satisfied_conflict_operation(
                    operation.mutation_id, now_ns=self._wall_now_ns()
                ):
                    self._conflict_ops_resubmitted.discard(operation.mutation_id)
                    self.logger.record(
                        "fabric_conflict_auto_resolved_satisfied",
                        mutation_id=operation.mutation_id,
                        kind=operation.kind,
                        path=operation.path,
                        destination_path=operation.destination_path,
                    )
                    resolved += 1
                continue
            if (
                operation.kind == "rename"
                and operation.mutation_id not in self._conflict_ops_resubmitted
                and self._remote_allows_rename_resubmit(operation)
            ):
                if self.database.resubmit_conflict_operation_once(
                    operation.mutation_id, now_ns=self._wall_now_ns()
                ):
                    self._conflict_ops_resubmitted.add(operation.mutation_id)
                    self.logger.record(
                        "fabric_conflict_rename_resubmitted_after_refresh",
                        mutation_id=operation.mutation_id,
                        path=operation.path,
                        destination_path=operation.destination_path,
                    )
                    resolved += 1
        if len(self._conflict_ops_resubmitted) > 4096:
            self._conflict_ops_resubmitted.clear()
        return resolved

    def _remote_satisfies_conflict_intent(self, operation: PendingOperation) -> bool:
        """Whether the remote view already holds this op's intended outcome."""

        if operation.kind == "put":
            entry = self.database.get_remote_entry(operation.path)
            return (
                entry is not None
                and operation.staged_digest is not None
                and entry.digest == operation.staged_digest
            )
        destination = operation.destination_path
        if destination is None:
            return False
        source_entry = self.database.get_remote_entry(operation.path)
        if operation.directory_rename:
            # A directory is materialized only through its children: the move is
            # done when the destination subtree exists and the source is gone.
            destination_children = self.database.list_remote_children(
                destination, limit=1
            )
            source_children = self.database.list_remote_children(
                operation.path, limit=1
            )
            return (
                bool(destination_children)
                and not source_children
                and source_entry is None
            )
        return (
            self.database.get_remote_entry(destination) is not None
            and source_entry is None
        )

    def _remote_allows_rename_resubmit(self, operation: PendingOperation) -> bool:
        """Whether a re-submit of this rename could now succeed.

        The rename's source must be present remotely (the FABRIC_PATH_ABSENT the
        server first answered is gone) and its destination not yet occupied, so
        a fresh submit is a move the authority can now apply rather than the same
        rejection.
        """

        destination = operation.destination_path
        if destination is None:
            return False
        if operation.directory_rename:
            source_children = self.database.list_remote_children(
                operation.path, limit=1
            )
            destination_children = self.database.list_remote_children(
                destination, limit=1
            )
            return bool(source_children) and not destination_children
        return (
            self.database.get_remote_entry(operation.path) is not None
            and self.database.get_remote_entry(destination) is None
        )

    def _record_operation_conflict(self, operation: PendingOperation, reason: str) -> None:
        self._v2_path_recovery_attempts.pop(operation.mutation_id, None)
        self._base_invalid_refreshes.pop(operation.mutation_id, None)
        remote = self.database.get_remote_entry(operation.path)
        self.database.record_conflict(
            operation.path,
            reason,
            mutation_id=operation.mutation_id,
            base_digest=operation.expected_source_digest,
            local_digest=operation.staged_digest,
            remote_digest=remote.digest if remote else None,
            remote_generation=self._remote_generation(),
            staged_path=operation.staged_path,
        )
        self._discard_prefetched_write_tickets(
            operation.mutation_id, reason="operation_conflict"
        )
        local = self.database.get_materialized(operation.path)
        self.database.mark_materialized(
            operation.path,
            state="conflict",
            clean_digest=local.clean_digest if local else None,
            stat_fingerprint=local.stat_fingerprint if local else None,
            bytes_on_disk=local.bytes_on_disk if local else 0,
        )

    def _remote_generation(self) -> int | None:
        head = self.database.get_remote_manifest_head()
        # V2's empty workspace sequence is zero; the optional legacy
        # conflict-generation column accepts only positive generations.
        # Absence is the truthful evidence until the first entry commits.
        return head.generation if head is not None and head.generation > 0 else None

    def _reusable_target_blocks(self, path: str) -> set[str]:
        entry = self.database.get_remote_entry(path)
        if (
            entry is None
            or not isinstance(entry.blocks, Mapping)
            or not _complete_object_cas_layout(entry)
        ):
            return set()
        storage = entry.blocks.get("storage")
        if (
            not isinstance(storage, Mapping)
            or storage.get("kind") != CONNECTED_HOST_OBJECT_CAS_KIND
        ):
            # Legacy CAS bytes live outside the writer-exclusive connected-host
            # prefix and cannot prove this mutation's target reuse, even when
            # their content digest is identical.
            return set()
        raw = entry.blocks.get("blocks")
        if not isinstance(raw, list):
            return set()
        reusable: set[str] = set()
        for block in raw:
            if isinstance(block, Mapping) and _digest(block.get("sha256")):
                reusable.add(str(block["sha256"]))
        return reusable

    # --------------------------------------------------------- remote bytes

    def _assert_stream_identity(
        self, entry: RemoteEntry, head: RemoteManifest | RemoteManifestHead
    ) -> None:
        current_head = self.database.get_remote_manifest_head()
        current_entry = self._remote_entry_for_write(entry.path)
        if (
            current_head is None
            or current_entry is None
            or current_head.generation != head.generation
            or current_head.digest != head.digest
            or current_entry.digest != entry.digest
            or current_entry.size_bytes != entry.size_bytes
        ):
            raise OSError(
                errno.ESTALE,
                "The Fabric manifest changed while the remote file was open.",
            )

    def _lookup_v2_descriptor(self, entry: RemoteEntry) -> RemoteEntry:
        """Fetch the block descriptor for one exact v2 entry and persist it.

        Fails closed: any mismatch between the served entry and the local
        identity (path, digest, size) leaves the entry as it was, and the
        caller's read then fails exactly as before rather than reading the
        wrong bytes.
        """

        lookup = getattr(self.transport, "lookup_v2", None)
        if not callable(lookup):
            return entry
        try:
            response = self._signed_control_request(
                lookup,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "path": entry.path,
                },
            )
        except (NetworkError, RemoteError):
            return entry
        served = response.get("entry") if isinstance(response, Mapping) else None
        if not isinstance(served, Mapping):
            return entry
        blocks = served.get("blocks")
        if (
            served.get("path") != entry.path
            or served.get("kind", "file") != "file"
            or served.get("sha256") != entry.digest
            or served.get("size_bytes") != entry.size_bytes
            or not isinstance(blocks, Mapping)
        ):
            return entry
        try:
            enriched = RemoteEntry(
                entry.path, entry.size_bytes, entry.digest, entry.modified, blocks
            )
        except (ValueError, UnsafePath):
            return entry
        try:
            self.database.fill_remote_entry_blocks_v2(
                entry.path,
                expected_file_digest=entry.digest,
                expected_size_bytes=entry.size_bytes,
                blocks=blocks,
            )
        except Exception as error:  # noqa: BLE001 - persistence is an optimization
            self.logger.record(
                "fabric_v2_descriptor_persist_failed",
                path=entry.path,
                error_type=type(error).__name__,
                error=str(error)[:200],
            )
        self.logger.record("fabric_v2_descriptor_fetched", path=entry.path)
        return enriched

    def _mounted_range_blocks(
        self,
        entry: RemoteEntry,
        head: RemoteManifest | RemoteManifestHead,
        *,
        offset: int,
        length: int,
    ) -> tuple[StagedBlock, ...] | None:
        """Resolve only the immutable CAS extents intersecting one mount read."""

        requested_end = offset + length
        complete = _cas_read_blocks(entry)
        if complete is not None:
            return _overlapping_cas_blocks(complete, offset, requested_end)
        summary = _deferred_transfer_block_summary(entry)
        if summary is None or length == 0:
            return None
        block_count = int(summary["block_count"])
        if block_count > MAX_MANIFEST_BLOCKS:
            # Never accumulate a wider remote descriptor map at the edge.
            # These uncommon indexes retain the bounded signed-range lane.
            return None

        state = _ManifestBlockPageState(
            path=entry.path,
            generation=head.generation,
            manifest_digest=head.digest,
            file_digest=entry.digest,
            file_size_bytes=entry.size_bytes,
            summary=summary,
        )
        cached = self._mounted_block_page_cache
        if cached is not None and replace(cached, blocks=()) == state:
            try:
                return _overlapping_cas_blocks(cached.blocks, offset, requested_end)
            except NetworkError:
                # A valid page may cover only an earlier range. Reuse a CDC
                # prefix below, but never mistake partial coverage for a hit.
                pass
        else:
            cached = None
        block_size = int(summary["block_size_bytes"])
        if summary.get("chunking") is None:
            first_index = offset // block_size
            final_index = (requested_end - 1) // block_size
            block_limit = final_index - first_index + 1
            response = self._signed_control_request(
                self.transport.blocks,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "operation": "manifest_blocks",
                    "path": entry.path,
                    "manifest_generation": head.generation,
                    "manifest_digest": head.digest,
                    "block_offset": first_index,
                    "block_limit": block_limit,
                },
            )
            page, _next_offset, _truncated = _manifest_block_page(
                response,
                state=state,
                block_offset=first_index,
                block_limit=block_limit,
                expected_byte_offset=first_index * block_size,
            )
            if len(page) != block_limit or any(
                block.offset_bytes != block.index * block_size
                or block.size_bytes
                != min(block_size, entry.size_bytes - block.offset_bytes)
                for block in page
            ):
                raise NetworkError(
                    "Meshia returned an invalid fixed Fabric block-index range."
                )
            selected = _overlapping_cas_blocks(page, offset, requested_end)
            self._mounted_block_page_cache = replace(state, blocks=tuple(page))
            return selected

        # Content-defined layouts cannot derive a block index from a byte
        # offset. Page their bounded map from the start only until this request
        # is covered, without loading unrelated suffix descriptors.
        blocks: tuple[StagedBlock, ...] = cached.blocks if cached is not None else ()
        while len(blocks) < block_count:
            block_offset = len(blocks)
            block_limit = min(
                MANIFEST_BLOCK_PAGE_SIZE, block_count - block_offset
            )
            response = self._signed_control_request(
                self.transport.blocks,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "operation": "manifest_blocks",
                    "path": entry.path,
                    "manifest_generation": head.generation,
                    "manifest_digest": head.digest,
                    "block_offset": block_offset,
                    "block_limit": block_limit,
                },
            )
            page, _next_offset, _truncated = _manifest_block_page(
                response,
                state=_ManifestBlockPageState(
                    path=state.path,
                    generation=state.generation,
                    manifest_digest=state.manifest_digest,
                    file_digest=state.file_digest,
                    file_size_bytes=state.file_size_bytes,
                    summary=state.summary,
                    blocks=blocks,
                ),
                block_offset=block_offset,
                block_limit=block_limit,
            )
            blocks += page
            # Atomic replacement avoids holding any lock across network I/O.
            # A racing older read may evict this hint, but exact state matching
            # above prevents its descriptors serving a different revision.
            self._mounted_block_page_cache = replace(state, blocks=blocks)
            selected = _overlapping_cas_blocks(
                blocks, offset, requested_end, require_coverage=False
            )
            if selected and (
                selected[-1].offset_bytes + selected[-1].size_bytes
                >= requested_end
            ):
                return selected
        return _overlapping_cas_blocks(blocks, offset, requested_end)

    def _load_remote_entry_blocks(
        self, entry: RemoteEntry, head: RemoteManifestHead
    ) -> tuple[BlockSpec, ...] | None:
        """Fetch at most one 2,048-descriptor page for one exact file head."""

        complete = _fixed_transfer_blocks(entry)
        if complete is not None:
            if (
                self._manifest_block_load is not None
                and self._manifest_block_load.path == entry.path
            ):
                self._manifest_block_load = None
            return complete
        summary = _deferred_transfer_block_summary(entry)
        if summary is None:
            return None
        if (
            entry.size_bytes > MAX_SYNC_FILE_BYTES
            or int(summary["block_count"]) > MAX_MANIFEST_BLOCKS
        ):
            # This is valid server metadata, but intentionally outside the
            # bounded edge staging protocol. Keep it remote-only rather than
            # accumulating up to 131,072 descriptors in this process.
            if (
                self._manifest_block_load is not None
                and self._manifest_block_load.path == entry.path
            ):
                self._manifest_block_load = None
            return None
        state = self._manifest_block_load
        identity = (
            entry.path,
            head.generation,
            head.digest,
            entry.digest,
            entry.size_bytes,
        )
        if state is None or (
            state.path,
            state.generation,
            state.manifest_digest,
            state.file_digest,
            state.file_size_bytes,
        ) != identity:
            state = _ManifestBlockPageState(
                path=entry.path,
                generation=head.generation,
                manifest_digest=head.digest,
                file_digest=entry.digest,
                file_size_bytes=entry.size_bytes,
                summary=summary,
            )
            self._manifest_block_load = state

        block_offset = len(state.blocks)
        block_count = int(summary["block_count"])
        if block_count == 0:
            response_blocks: tuple[StagedBlock, ...] = ()
            truncated = False
            next_offset = 0
        else:
            response = self._signed_control_request(
                self.transport.blocks,
                {
                    "attachment_id": self.authority.attachment_id,
                    "workspace": WORKSPACE_MOUNT,
                    "operation": "manifest_blocks",
                    "path": entry.path,
                    "manifest_generation": head.generation,
                    "manifest_digest": head.digest,
                    "block_offset": block_offset,
                    "block_limit": MANIFEST_BLOCK_PAGE_SIZE,
                },
            )
            response_blocks, next_offset, truncated = _manifest_block_page(
                response,
                state=state,
                block_offset=block_offset,
                block_limit=MANIFEST_BLOCK_PAGE_SIZE,
            )

        combined = state.blocks + response_blocks
        if truncated:
            self._manifest_block_load = _ManifestBlockPageState(
                path=state.path,
                generation=state.generation,
                manifest_digest=state.manifest_digest,
                file_digest=state.file_digest,
                file_size_bytes=state.file_size_bytes,
                summary=state.summary,
                blocks=combined,
            )
            return None
        if next_offset != block_count or len(combined) != block_count:
            raise NetworkError("Meshia returned an incomplete Fabric block index.")
        enriched = dict(summary)
        enriched["blocks_complete"] = True
        enriched["blocks"] = [asdict(block) for block in combined]
        if not self.database.set_remote_entry_blocks(
            entry.path,
            expected_generation=head.generation,
            expected_manifest_digest=head.digest,
            expected_file_digest=entry.digest,
            blocks=enriched,
        ):
            self._manifest_block_load = None
            return None
        self._manifest_block_load = None
        updated = self.database.get_remote_entry(entry.path)
        if updated is None:
            return None
        return _fixed_transfer_blocks(updated)

    @staticmethod
    def _remote_transfer_logical_path(
        path: str, head: RemoteManifestHead, entry: RemoteEntry
    ) -> str:
        identity = hashlib.sha256(
            (
                f"{head.generation}\x00{head.digest}\x00{path}\x00"
                f"{entry.size_bytes}\x00{entry.digest}"
            ).encode("utf-8")
        ).hexdigest()
        return f"remote/{identity}"

    @staticmethod
    def _remote_state_matches(
        state: _RemoteTransferState,
        head: RemoteManifestHead,
        entry: RemoteEntry,
    ) -> bool:
        return (
            state.path == entry.path
            and state.generation == head.generation
            and state.manifest_digest == head.digest
            and state.file_digest == entry.digest
            and state.file_size_bytes == entry.size_bytes
        )

    def _schedule_remote_probe(self, state: _RemoteTransferState) -> None:
        job = state.job
        if job is None:
            raise StateError("The remote transfer lost its durable assembly job.")
        completed = int(job.progress.get("completed_blocks", -1))
        remaining = job.blocks[completed:]
        window = self._direct_read_ticket_window(remaining)
        batch = tuple(job.blocks[completed : completed + window])
        if not batch and job.blocks:
            raise StateError("The remote transfer has no advancing block batch.")
        state.ticket_blocks = ()
        state.tickets = None
        state.ticket_cursor = 0
        state.fetch_count = 0
        state.phase = "probe"
        state.future = _daemon_future(
            "meshia-remote-cache-probe",
            lambda: self._probe_remote_batch(state, batch),
        )
        state.future.add_done_callback(lambda _future: self.wake())

    def _probe_remote_batch(
        self, state: _RemoteTransferState, blocks: Sequence[BlockSpec]
    ) -> _RemoteBatchProbe:
        missing: list[BlockSpec] = []
        for block in blocks:
            hit = self.cache.get(
                state.file_digest,
                state.file_size_bytes,
                block.offset_bytes,
                block.size_bytes,
                manifest_generation=state.generation,
                manifest_digest=state.manifest_digest,
                expected_range_sha256=block.sha256,
            )
            if hit is None:
                # Immutable CAS content may already be present under another
                # offset or file binding. Attach this exact range alias without
                # spending another ticket or provider GET.
                hit = self.cache.get_content(block.sha256, block.size_bytes)
                if hit is not None:
                    self.cache.put(
                        state.file_digest,
                        state.file_size_bytes,
                        block.offset_bytes,
                        hit,
                        block.sha256,
                        manifest_generation=state.generation,
                        manifest_digest=state.manifest_digest,
                    )
                else:
                    missing.append(block)
        # Never retain up to 64 cached 4-MiB values in the control handoff.
        # The four-block byte sub-batch re-reads cache entries just in time.
        return _RemoteBatchProbe(tuple(blocks), tuple(missing))

    def _schedule_remote_ticket_fetch(self, state: _RemoteTransferState) -> None:
        blocks = state.ticket_blocks[
            state.ticket_cursor : state.ticket_cursor + self._direct_read_batch
        ]
        if not blocks:
            self._schedule_remote_probe(state)
            return
        state.fetch_count = len(blocks)
        tickets = state.tickets or {}
        state.phase = "fetch"
        state.future = _daemon_future(
            "meshia-remote-block-stage",
            lambda: self._fetch_and_stage_remote_batch(state, blocks, tickets),
        )
        state.future.add_done_callback(lambda _future: self.wake())

    def _fetch_and_stage_remote_batch(
        self,
        state: _RemoteTransferState,
        blocks: Sequence[BlockSpec],
        tickets: Mapping[str, Mapping[str, Any]],
    ) -> VerifiedStage | None:
        job = state.job
        if job is None:
            raise StateError("The remote transfer lost its durable assembly job.")
        download = getattr(self.transport, "download_block", None)
        if not callable(download):
            raise NetworkError("The Fabric transport cannot read direct blocks.")
        known_data: dict[int, bytes] = {}
        occurrences: dict[str, list[BlockSpec]] = {}
        for block in blocks:
            hit = self.cache.get(
                state.file_digest,
                state.file_size_bytes,
                block.offset_bytes,
                block.size_bytes,
                manifest_generation=state.generation,
                manifest_digest=state.manifest_digest,
                expected_range_sha256=block.sha256,
            )
            if hit is None:
                hit = self.cache.get_content(block.sha256, block.size_bytes)
                if hit is not None:
                    self.cache.put(
                        state.file_digest,
                        state.file_size_bytes,
                        block.offset_bytes,
                        hit,
                        block.sha256,
                        manifest_generation=state.generation,
                        manifest_digest=state.manifest_digest,
                    )
                    known_data[block.index] = hit
                else:
                    if block.sha256 not in tickets:
                        raise NetworkError(
                            "A cached Fabric block was evicted before its ticketed batch."
                        )
                    occurrences.setdefault(block.sha256, []).append(block)
            else:
                known_data[block.index] = hit
        tasks = tuple(
            DirectByteTask(
                matching[0],
                lambda matching=tuple(matching), ticket=tickets[digest]: (
                    self._download_and_cache_direct_block(
                        state.file_digest,
                        state.file_size_bytes,
                        state.generation,
                        state.manifest_digest,
                        matching,
                        ticket,
                        download,
                    )
                ),
            )
            for digest, matching in occurrences.items()
        )
        started_at = float(self._clock())
        result = self._direct_byte_pool.fetch_batch(
            tasks,
            timeout=(
                self._direct_read_active_timeout(
                    tuple(tickets[digest] for digest in occurrences),
                    now_epoch=self._wall_now_ns() / 1_000_000_000,
                )
                if tasks
                else 0.0
            ),
        )
        downloaded = {item.block.sha256: item.data for item in result.completed}
        if downloaded:
            self._record_direct_read_goodput(
                sum(len(data) for data in downloaded.values()),
                max(0.0, float(self._clock()) - started_at),
            )
        for block in blocks:
            data = downloaded.get(block.sha256)
            if data is not None:
                known_data[block.index] = data

        # RemoteAssemblyJob requires an exact contiguous prefix. Persist every
        # such verified completion before reporting a failed/expired sibling;
        # later out-of-order completions are already in the immutable cache and
        # are picked up by the next probe without another provider read.
        received: list[ReceivedBlock] = []
        completed = int(job.progress.get("completed_blocks", -1))
        for block in blocks:
            if block.index != completed + len(received):
                break
            data = known_data.get(block.index)
            if data is None:
                break
            received.append(
                ReceivedBlock(
                    block.index,
                    block.offset_bytes,
                    block.size_bytes,
                    block.sha256,
                    data,
                )
            )
        stage = job.step(received) if received else None
        if stage is not None:
            return stage
        if result.failures or result.timed_out or result.unstarted:
            raise _direct_batch_failure(result)
        if len(received) != len(blocks):
            raise NetworkError("A direct Fabric block ticket returned no bytes.")
        return None

    def _download_and_cache_direct_block(
        self,
        file_digest: str,
        file_size_bytes: int,
        generation: int,
        manifest_digest: str,
        blocks: Sequence[BlockSpec | StagedBlock],
        ticket: Mapping[str, Any],
        download: Any,
    ) -> bytes:
        """Verify and admit one immutable provider result before worker return."""

        if not blocks:
            raise StateError("A direct Fabric cache admission has no block identity.")
        expected = blocks[0]
        data = download(ticket)
        if (
            not isinstance(data, bytes)
            or len(data) != expected.size_bytes
            or hashlib.sha256(data).hexdigest() != expected.sha256
            or any(
                block.sha256 != expected.sha256
                or block.size_bytes != expected.size_bytes
                for block in blocks
            )
        ):
            raise NetworkError("A direct Fabric block failed end-to-end verification.")
        for block in blocks:
            self.cache.put(
                file_digest,
                file_size_bytes,
                block.offset_bytes,
                data,
                block.sha256,
                manifest_generation=generation,
                manifest_digest=manifest_digest,
            )
        return data

    def _direct_read_batches(
        self, blocks: Sequence[StagedBlock]
    ) -> Iterator[list[StagedBlock]]:
        """Split one ticket window into byte-bounded direct-read batches.

        A batch holds at most ``_direct_read_batch`` blocks and, past its
        first block, at most ``_direct_read_batch_bytes`` bytes: a 16 MiB
        block travels alone, four 4 MiB blocks travel together.
        """

        batch: list[StagedBlock] = []
        batch_bytes = 0
        for block in blocks:
            if batch and (
                len(batch) >= self._direct_read_batch
                or batch_bytes + block.size_bytes > self._direct_read_batch_bytes
            ):
                yield batch
                batch, batch_bytes = [], 0
            batch.append(block)
            batch_bytes += block.size_bytes
        if batch:
            yield batch

    def _direct_read_ticket_window(
        self, remaining_blocks: Sequence[BlockSpec | StagedBlock]
    ) -> int:
        if not remaining_blocks:
            return 0
        limit = min(len(remaining_blocks), self._direct_ticket_batch)
        goodput = self._direct_read_goodput_bytes_per_second
        headroom = self._direct_read_last_ticket_headroom_seconds
        if goodput is None or headroom is None:
            byte_budget = float(DIRECT_TICKET_BOOTSTRAP_BYTES)
        else:
            byte_budget = goodput * max(
                0.0, headroom - DIRECT_TICKET_EXPIRY_GUARD_SECONDS
            )
        selected = 0
        selected_bytes = 0
        for block in remaining_blocks[:limit]:
            if selected and selected_bytes + block.size_bytes > byte_budget:
                break
            selected += 1
            selected_bytes += block.size_bytes
        return max(1, selected)

    def _note_direct_read_ticket_headroom(
        self, tickets: Mapping[str, Mapping[str, Any]]
    ) -> None:
        if not tickets:
            return
        now_epoch = self._wall_now_ns() / 1_000_000_000
        earliest = min(_direct_read_ticket_expiry(ticket) for ticket in tickets.values())
        headroom = earliest - now_epoch
        if headroom <= DIRECT_TICKET_EXPIRY_GUARD_SECONDS:
            raise NetworkError("Meshia returned a Fabric block ticket without safe headroom.")
        self._direct_read_last_ticket_headroom_seconds = headroom

    def _direct_read_active_timeout(
        self,
        tickets: Sequence[Mapping[str, Any]],
        *,
        now_epoch: float,
    ) -> float:
        if not tickets:
            return 0.0
        headroom = min(_direct_read_ticket_expiry(ticket) for ticket in tickets) - now_epoch
        usable = headroom - DIRECT_TICKET_EXPIRY_GUARD_SECONDS
        if usable <= 0:
            raise NetworkError("A Fabric block ticket expired before byte transfer.")
        return min(DIRECT_BATCH_TIMEOUT_SECONDS, usable)

    def _record_direct_read_goodput(self, byte_count: int, elapsed: float) -> None:
        if byte_count <= 0:
            return
        observed = byte_count / max(0.001, elapsed)
        previous = self._direct_read_goodput_bytes_per_second
        self._direct_read_goodput_bytes_per_second = (
            observed if previous is None else (previous + observed) / 2.0
        )

    def _begin_remote_publish(self, state: _RemoteTransferState) -> None:
        job = state.job
        if job is None:
            raise StateError("The remote transfer lost its durable assembly job.")
        stage = job.verified_stage()
        # Check the visible-volume temporary-copy reserve before converting the
        # resumable ready stage into a lease. A shortage leaves the complete
        # private copy retryable across the coordinator backoff.
        self._assert_remote_destination_capacity(
            state.file_size_bytes, replacing_path=state.path
        )
        progress_state = job.progress.get("state")
        if progress_state == "ready":
            stage = self._transfer_store.claim_ready(
                stage.logical_path, stage.token
            )
        elif progress_state != "leased" or job.progress.get("token") != stage.token:
            raise StateError("The remote transfer stage lease is inconsistent.")
        state.stage = stage
        state.phase = "publish"
        state.future = _daemon_future(
            "meshia-remote-stage-publish",
            lambda: self._publish_remote_stage(state, stage),
        )
        state.future.add_done_callback(lambda _future: self.wake())

    def _begin_remote_range_transfer(self, state: _RemoteTransferState) -> None:
        """Create a private disposable stage for bounded signed-range reads."""

        if file_digest_algorithm(state.block_descriptor) == FABRIC_FILE_TREE_ALGORITHM:
            entry = self.database.get_remote_entry(state.path)
            head = self.database.get_remote_manifest_head()
            if (entry is None or head is None or entry.digest != state.file_digest
                    or entry.size_bytes != state.file_size_bytes or head.generation != state.generation):
                raise NetworkError("The remote tree changed before materialization.")
            state.tree_reader = self._tree_reader(entry, head)
        verifier = (FabricFileHasher(state.block_descriptor, tree_source=state.tree_reader)
            if file_digest_algorithm(state.block_descriptor) != "sha256" else None)
        transfer_id = str(uuid.uuid4())
        stage_path = self.staging_root / f"{transfer_id}.data"
        try:
            self._reserve_classic_stage(stage_path, state.file_size_bytes)
        except InvalidTask as error:
            # A valid remote object must not become a permanent namespace
            # conflict merely because the local disk is temporarily full.
            raise StagingQuotaExceeded(str(error)) from error
        flags = (
            os.O_WRONLY
            | os.O_CREAT
            | os.O_EXCL
            | getattr(os, "O_BINARY", 0)
            | getattr(os, "O_NOFOLLOW", 0)
        )
        descriptor = os.open(str(stage_path), flags, 0o600)
        try:
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size != 0:
                raise StateError("The private Fabric range stage is unsafe.")
            os.fsync(descriptor)
        except BaseException:
            os.close(descriptor)
            try:
                stage_path.unlink()
            except OSError:
                pass
            self._release_classic_stage(stage_path)
            raise
        else:
            os.close(descriptor)
        _fsync_dir(self.staging_root)
        state.range_stage_path = stage_path
        state.range_stage_device = int(info.st_dev)
        state.range_stage_inode = int(info.st_ino)
        state.range_offset = 0
        state.range_hasher = hashlib.sha256()
        state.range_file_hasher = verifier if verifier is not None else state.range_hasher
        state.range_stage_owned = True
        state.phase = "range"

    def _advance_remote_range_transfer(self, state: _RemoteTransferState) -> None:
        """Append exactly one cached or signed <=8 MiB range to a private stage."""

        stage_path = state.range_stage_path
        digest = state.range_hasher
        if stage_path is None or digest is None:
            raise StateError("The Fabric range transfer lost its private stage.")
        if state.range_offset >= state.file_size_bytes:
            raise StateError("The Fabric range transfer has no advancing byte range.")
        length = min(
            1024 * 1024 if state.tree_reader is not None else LEGACY_RANGE_TRANSFER_BYTES,
            state.file_size_bytes - state.range_offset,
        )
        data = state.tree_reader.read(state.range_offset, length) if state.tree_reader is not None else self.cache.get(
            state.file_digest,
            state.file_size_bytes,
            state.range_offset,
            length,
            manifest_generation=state.generation,
            manifest_digest=state.manifest_digest,
        )
        if data is None and state.manifest_digest is None:
            # A Fabric v2 head has neither a whole-object ticket lane nor a
            # signed range lane (both are minted against a published v1
            # manifest). Its bytes come from the descriptor + block lane,
            # exactly as a mount read does; stream() owns that lane, including
            # the lazy descriptor lookup and the range cache. Until 2026-09-02
            # this fell through to the object reader, which handed the absent
            # digest to the range cache and stalled the sync loop.
            current = self.database.get_remote_entry(state.path)
            if (
                current is None
                or current.digest != state.file_digest
                or current.size_bytes != state.file_size_bytes
            ):
                raise NetworkError(
                    "The remote Fabric file changed during a bounded range transfer."
                )
            data = b"".join(
                self.stream(state.path, offset=state.range_offset, length=length)
            )
        if data is None and self._object_reader is not None:
            # Hydrate plain objects through the ticketed direct lane: parallel
            # 4 MiB units at link rate and one signed call per file, instead of
            # one serialized signed call per MiB that starves every other
            # control turn (and exceeds the signed lane's 1 MiB cap at 8 MiB).
            entry_like = RemoteEntry(
                path=state.path,
                size_bytes=state.file_size_bytes,
                digest=state.file_digest,
            )
            head_like = RemoteManifestHead(
                generation=state.generation,
                digest=state.manifest_digest,
                refreshed_at_ns=0,
            )
            if self._object_reader.serves(entry_like):
                try:
                    data = self._object_reader.read(
                        entry_like, head_like, state.range_offset, length
                    )
                except ObjectReadUnavailable:
                    data = None
                except ObjectReadStale as error:
                    raise NetworkError(
                        "The Fabric manifest changed during a bounded range transfer."
                    ) from error
        if data is None:
            # The signed range lane returns at most one cache chunk per call.
            length = min(length, MAX_SIGNED_RANGE_BYTES)
            data = self.cache.get(
                state.file_digest,
                state.file_size_bytes,
                state.range_offset,
                length,
                manifest_generation=state.generation,
                manifest_digest=state.manifest_digest,
            )
        if data is None:
            fetched = self._fetch_range(
                state.path,
                state.file_digest,
                state.file_size_bytes,
                state.range_offset,
                length,
                manifest_generation=state.generation,
                manifest_digest=state.manifest_digest,
            )
            if (
                fetched.manifest_generation != state.generation
                or fetched.manifest_digest != state.manifest_digest
            ):
                raise NetworkError(
                    "The Fabric manifest changed during a bounded range transfer."
                )
            data = fetched.data
            self.cache.put(
                state.file_digest,
                state.file_size_bytes,
                state.range_offset,
                data,
                fetched.range_sha256,
                manifest_generation=state.generation,
                manifest_digest=state.manifest_digest,
            )
        if len(data) != length:
            raise NetworkError("A bounded Fabric range returned the wrong byte count.")

        flags = (
            os.O_WRONLY
            | getattr(os, "O_BINARY", 0)
            | getattr(os, "O_NOFOLLOW", 0)
        )
        descriptor = os.open(str(stage_path), flags)
        try:
            before = os.fstat(descriptor)
            if (
                not stat.S_ISREG(before.st_mode)
                or before.st_nlink != 1
                or before.st_dev != state.range_stage_device
                or before.st_ino != state.range_stage_inode
                or before.st_size != state.range_offset
            ):
                raise StateError("The private Fabric range stage changed between chunks.")
            os.lseek(descriptor, state.range_offset, os.SEEK_SET)
            _write_all(descriptor, data)
            os.fsync(descriptor)
            after = os.fstat(descriptor)
            if (
                after.st_dev != before.st_dev
                or after.st_ino != before.st_ino
                or after.st_nlink != 1
                or after.st_size != state.range_offset + length
            ):
                raise StateError("The private Fabric range stage changed during append.")
            self._record_classic_stage_committed(stage_path, after)
        finally:
            os.close(descriptor)
        digest.update(data)
        try:
            if state.range_file_hasher is not digest:
                state.range_file_hasher.update(data)
        except ValueError as error:
            raise NetworkError("The bounded Fabric range failed block verification.") from error
        state.range_offset += length
        if state.range_offset != state.file_size_bytes:
            return
        try:
            if state.range_file_hasher.hexdigest() != state.file_digest:
                raise ValueError("file identity mismatch")
        except ValueError as error:
            raise NetworkError("The bounded Fabric range stage failed file verification.") from error
        transfer_id = stage_path.name[: -len(".data")]
        state.stage = VerifiedStage(
            transfer_id=transfer_id,
            token=str(uuid.uuid4()),
            kind="remote-range",
            logical_path=state.logical_path,
            path=stage_path,
            size_bytes=state.file_size_bytes,
            sha256=digest.hexdigest(),
            file_digest=state.file_digest,
        )
        state.phase = "range_ready"
        self._begin_remote_range_publish(state)

    def _begin_remote_range_publish(self, state: _RemoteTransferState) -> None:
        stage = state.stage
        if stage is None or not state.range_stage_owned:
            raise StateError("The Fabric range transfer lost its verified stage.")
        self._assert_remote_destination_capacity(
            state.file_size_bytes, replacing_path=state.path
        )
        state.phase = "range_publish"
        state.future = _daemon_future(
            "meshia-remote-range-publish",
            lambda: self._publish_remote_stage(state, stage),
        )
        state.future.add_done_callback(lambda _future: self.wake())

    def _remove_remote_range_stage(
        self, state: _RemoteTransferState, *, strict: bool
    ) -> None:
        stage_path = state.range_stage_path
        if stage_path is None:
            if strict:
                raise StateError("The Fabric range stage path is missing.")
            return
        try:
            info = stage_path.lstat()
        except FileNotFoundError:
            if strict:
                raise StateError("The Fabric range stage disappeared before cleanup.")
            return
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_nlink != 1
            or info.st_dev != state.range_stage_device
            or info.st_ino != state.range_stage_inode
        ):
            if strict:
                raise StateError("The Fabric range stage changed before cleanup.")
            return
        stage_path.unlink()
        _fsync_dir(self.staging_root)
        self._release_classic_stage(stage_path)
        state.range_stage_owned = False

    def _publish_remote_stage(
        self, state: _RemoteTransferState, stage: VerifiedStage
    ) -> _RemotePublishResult:
        """Publish verified private bytes without a signed control-plane call."""

        with self._namespace_lock(state.path):
            if state.cancelled_by_local_mutation.is_set():
                return _RemotePublishResult("superseded", None)
            return self._publish_remote_stage_locked(state, stage)

    def _publish_remote_stage_locked(
        self, state: _RemoteTransferState, stage: VerifiedStage
    ) -> _RemotePublishResult:
        """Commit one remote stage while owning its namespace stripe."""

        if stage.file_digest != state.file_digest or stage.size_bytes != state.file_size_bytes:
            raise StateError("The verified remote stage has a different file identity.")
        local: HashedRegularFile | None = None
        if state.expected_existing_fingerprint is None:
            local = self.workspace.hash_regular_file(state.path)
            if local is not None and local.sha256 == stage.sha256:
                return _RemotePublishResult("noop", local)
            if local is not None and (
                state.expected_content_sha256 is None
                or local.sha256 != state.expected_content_sha256
            ):
                return _RemotePublishResult("diverged", local)

        apply_token = self.watch.arm_remote_apply(
            state.path, timeout_seconds=300.0
        )
        retired: RetiredRegularFile | None = None
        preserved_path: str | None = None
        try:
            def renewing_chunks() -> Iterator[bytes]:
                for chunk in _verified_stage_chunks(stage):
                    if not self.watch.renew_remote_apply(
                        apply_token, timeout_seconds=300.0
                    ):
                        raise StateError("The Fabric materialization lease expired.")
                    yield chunk

            if state.expected_existing_fingerprint is not None:
                identity_result = self.workspace.replace_stream_by_fingerprint(
                    state.path,
                    renewing_chunks(),
                    expected_size=state.file_size_bytes,
                    expected_sha256=f"sha256:{stage.sha256}",
                    expected_existing_fingerprint=(
                        state.expected_existing_fingerprint
                    ),
                    create_parents=True,
                )
                written = identity_result.written
                preserved_path = identity_result.preserved_path
            else:
                retired = self.workspace.write_stream(
                    state.path,
                    renewing_chunks(),
                    expected_size=state.file_size_bytes,
                    expected_sha256=f"sha256:{stage.sha256}",
                    create_parents=True,
                    overwrite=local is not None,
                    expected_existing_sha256=(
                        f"sha256:{local.sha256}" if local is not None else None
                    ),
                    expected_existing_fingerprint=(
                        local.fingerprint if local is not None else None
                    ),
                    retain_replaced=local is not None,
                    require_retention_capacity=local is not None,
                )
            if not self.watch.renew_remote_apply(
                apply_token, timeout_seconds=300.0
            ):
                raise StateError("The Fabric materialization lease expired after commit.")
            if state.expected_existing_fingerprint is None:
                written = self.workspace.hash_regular_file(state.path)
                if written is None or written.sha256 != stage.sha256:
                    raise StateError("The materialized Fabric file disappeared after commit.")
            if not self.watch.commit_remote_apply(
                apply_token, {state.path: written}
            ):
                raced = self.workspace.hash_regular_file(state.path)
                if retired is not None:
                    preserved_path = self._finish_retired_with_mount_fence(
                        retired,
                        preserve=False,
                    )
                retired = None
                return _RemotePublishResult("race", raced, preserved_path)
        except BaseException:
            self.watch.abort_remote_apply(apply_token)
            if retired is not None:
                self.workspace.finish_retired_file(retired, preserve=True)
            raise
        if retired is not None:
            preserved_path = self._finish_retired_with_mount_fence(
                retired,
                preserve=False,
            )
        return _RemotePublishResult("published", written, preserved_path)

    def _discard_remote_transfer(self, state: _RemoteTransferState) -> None:
        if state.range_stage_owned:
            try:
                self._remove_remote_range_stage(state, strict=False)
            except OSError:
                pass
            self._remote_transfer = None
            return
        job = state.job
        if job is None:
            self._remote_transfer = None
            return
        try:
            progress_state = job.progress.get("state")
            if progress_state == "ready":
                stage = job.verified_stage()
                self._transfer_store.claim_ready(stage.logical_path, stage.token)
                self._transfer_store.consume_ready(stage.logical_path, stage.token)
            elif progress_state == "leased":
                stage = job.verified_stage()
                self._transfer_store.consume_ready(stage.logical_path, stage.token)
            else:
                if progress_state not in ("cancelled", "quarantined"):
                    job.cancel("remote manifest identity advanced")
                self._transfer_store.remove_terminal(
                    job.logical_path, job.transfer_id
                )
        except (OSError, TransferError):
            pass
        self._remote_transfer = None

    def _reset_stale_remote_hydration(self, path: str) -> None:
        """Forget bytes bound to an obsolete head without dropping its intent."""

        if (
            self._manifest_block_load is not None
            and self._manifest_block_load.path == path
        ):
            self._manifest_block_load = None
        state = self._remote_transfer
        if state is not None and state.path == path:
            self._discard_remote_transfer(state)
        # Keep the durable apply intent and in-memory queue head. A full refresh
        # will either retarget it to the new identity or remove it atomically.
        self._force_full_remote = True
        self._next_remote_poll = 0.0

    def _complete_remote_publish(
        self,
        state: _RemoteTransferState,
        result: _RemotePublishResult,
    ) -> int:
        stage = state.stage
        if stage is None:
            raise StateError("The remote publisher lost its verified stage token.")
        if state.cancelled_by_local_mutation.is_set() or result.outcome == "superseded":
            return self._complete_cancelled_remote_transfer(state, result)
        if result.outcome in ("published", "noop"):
            if result.local is None:
                raise StateError("The remote publication has no exact local state.")
            self.database.mark_materialized(
                state.path,
                state="clean",
                clean_digest=state.file_digest,
                content_sha256=result.local.sha256,
                clean_digest_algorithm=file_digest_algorithm(state.block_descriptor),
                stat_fingerprint=_fingerprint_text(result.local.fingerprint),
                bytes_on_disk=result.local.fingerprint.size_bytes,
                pinned=state.pinned,
                # Proof by retrieval: these bytes were just streamed back out
                # of object storage, so they are re-fetchable by construction.
                # "noop" means the local file already matched and nothing was
                # fetched, which proves nothing.
                remote_verified=True if result.outcome == "published" else None,
            )
        elif result.outcome == "diverged":
            self.database.record_conflict(
                state.path,
                "remote materialization refused to overwrite local bytes",
                base_digest=state.expected_clean_digest,
                local_digest=result.local.sha256 if result.local else None,
                remote_digest=state.file_digest,
                remote_generation=state.generation,
            )
            self.database.mark_materialized(
                state.path,
                state="conflict",
                clean_digest=state.expected_clean_digest,
                stat_fingerprint=(
                    _fingerprint_text(result.local.fingerprint)
                    if result.local is not None
                    else None
                ),
                bytes_on_disk=(
                    result.local.fingerprint.size_bytes
                    if result.local is not None
                    else 0
                ),
                pinned=True,
            )
        elif result.outcome == "race":
            if result.local is None:
                self._stage_delete(state.path)
            else:
                self._stage_local_put_bounded(state.path)
        else:
            raise StateError("The remote publisher returned an unknown outcome.")

        if result.preserved_path is not None:
            self._stage_local_put_bounded(result.preserved_path)
        current_head = self.database.get_remote_manifest_head()
        current_entry = self.database.get_remote_entry(state.path)
        still_current = (
            current_head is not None
            and current_entry is not None
            and self._remote_state_matches(state, current_head, current_entry)
        )
        finalized = still_current or result.outcome in ("diverged", "race")
        if finalized:
            # The materialized/conflict/successor state above and remote intent
            # retirement are the durable ACK. Disposable stages are never
            # allowed to make that ACK ambiguous.
            self._drop_remote_apply_head()
        self._remote_transfer = None
        try:
            if state.range_stage_owned:
                self._remove_remote_range_stage(state, strict=True)
            else:
                self._transfer_store.discard_finalized_remote(
                    stage.logical_path,
                    transfer_id=stage.transfer_id,
                    token=stage.token,
                )
        except (OSError, TransferError, StateError) as error:
            # Range stages are covered by the bounded classic orphan sweep.
            # TransferStore stages retain exact final_path/digest metadata and
            # are reclaimed by _reclaim_finalized_remote_transfers after the
            # same SQLite/local identity proof succeeds on a later tick.
            self.logger.record(
                "fabric_remote_stage_cleanup_deferred",
                path=state.path,
                error=str(error),
            )
        return 1 if result.outcome == "published" else 0

    def _complete_cancelled_remote_transfer(
        self,
        state: _RemoteTransferState,
        result: _RemotePublishResult | None = None,
    ) -> int:
        """Retire obsolete remote bytes after a newer local mutation wins."""

        preserved_path = result.preserved_path if result is not None else None
        if preserved_path is not None:
            preserved = self._hash_regular_file(preserved_path)
            successor = self.database.get_latest_nonterminal_operation(state.path)
            deleted_content_sha256 = (
                state.expected_content_sha256
                if successor is not None and successor.expected_source_digest == state.expected_clean_digest
                else state.stage.sha256
                if successor is not None and successor.expected_source_digest == state.file_digest
                and state.stage is not None else None
            )
            discard_exact_deleted_preimage = bool(
                preserved is not None
                and successor is not None
                and successor.kind == "delete"
                and successor.expected_source_digest is not None
                and preserved.sha256 == deleted_content_sha256
            )
            if discard_exact_deleted_preimage and preserved is not None:
                removed = self._remove_exact_with_mount_fence(
                    preserved_path, preserved.fingerprint
                )
                if removed is None:
                    # An open mounted description (or a standalone coordinator
                    # without a path-admission fence) owns ambiguity. Keep the
                    # file visible and durable-journal it instead of parking a
                    # large inode in an unowned hidden survivor.
                    self._stage_local_put_bounded(preserved_path)
                    self.logger.record(
                        "fabric_superseded_retire_preserved_open",
                        path=state.path,
                        preserved_path=preserved_path,
                    )
                elif removed is True:
                    self.watch.acknowledge_local_state({preserved_path: None})
                    self.logger.record(
                        "fabric_superseded_retire_reclaimed",
                        path=state.path,
                        preserved_path=preserved_path,
                    )
                else:
                    self.watch.acknowledge_local_state({preserved_path: None})
                    self.logger.record(
                        "fabric_superseded_retire_already_absent",
                        path=state.path,
                        preserved_path=preserved_path,
                    )
            elif preserved is not None:
                # A changed retired inode is still user data. Preserve and
                # publish it even though the original remote apply lost.
                self._stage_local_put_bounded(preserved_path)

        if self._remote_apply_queue and self._remote_apply_queue[0] == state.path:
            self._drop_remote_apply_head()
        else:
            self.database.complete_remote_apply_intent(state.path)
            self._remote_apply_members.discard(state.path)
            self._remote_apply_priority_members.discard(state.path)
        self._discard_remote_transfer(state)
        self.logger.record(
            "fabric_remote_apply_superseded_by_local_mutation",
            path=state.path,
            generation=state.generation,
        )
        return 0

    def _reconcile_unjournaled_local_snapshots(self) -> int:
        """Preserve or deduplicate one bounded page of complete local stages."""

        future = self._local_recovery_future
        candidate = self._local_recovery_candidate
        plan = self._local_recovery_plan
        if future is not None:
            if not future.done():
                return 0
            self._local_recovery_future = None
            self._local_recovery_candidate = None
            self._local_recovery_plan = None
            if candidate is None or plan is None:
                raise StateError("The local recovery verifier lost its exact owner.")
            try:
                stage = future.result()
            except BaseException as error:
                # Verification failure is corruption evidence, not permission
                # to erase the last complete-looking local snapshot.
                self._local_recovery_scan_blocked = True
                self.logger.record(
                    "fabric_local_snapshot_recovery_blocked",
                    path=plan.path,
                    transfer_id=candidate.transfer_id,
                    error=str(error),
                )
                return 0
            expected_source = FileFingerprint(
                size_bytes=candidate.source_fingerprint.size_bytes,
                mtime_ns=candidate.source_fingerprint.modified_ns,
                ctime_ns=candidate.source_fingerprint.changed_ns,
                device_id=candidate.source_fingerprint.device,
                file_id=candidate.source_fingerprint.inode,
            )
            visible = self.workspace.stat_fingerprint(plan.path)
            if visible == expected_source:
                # LocalSnapshotJob verified the private digest against the
                # anchored source before promotion. The unchanged exact stat
                # identity proves the visible source still owns those bytes;
                # only this proven duplicate may be consumed.
                if candidate.state == "ready":
                    self._transfer_store.claim_ready(
                        candidate.logical_path, candidate.token
                    )
                self._transfer_store.consume_ready(
                    candidate.logical_path, candidate.token
                )
                self.logger.record(
                    "fabric_local_snapshot_duplicate_reclaimed",
                    path=plan.path,
                    transfer_id=candidate.transfer_id,
                )
                return 1

            existing = self.database.get_materialized(plan.path)
            remote = self.database.get_remote_entry(plan.path)
            self.database.record_conflict(
                plan.path,
                "complete unjournaled local snapshot preserved for recovery",
                base_digest=existing.clean_digest if existing else None,
                local_digest=stage.sha256,
                remote_digest=remote.digest if remote else None,
                remote_generation=self._remote_generation(),
                staged_path=stage.path,
            )
            self.database.mark_materialized(
                plan.path,
                state="conflict",
                clean_digest=existing.clean_digest if existing else None,
                stat_fingerprint=(
                    _fingerprint_text(visible) if visible is not None else None
                ),
                bytes_on_disk=visible.size_bytes if visible is not None else 0,
                pinned=True,
            )
            self.logger.record(
                "fabric_local_snapshot_recovery_preserved",
                path=plan.path,
                transfer_id=candidate.transfer_id,
                staged_path=str(stage.path),
            )
            return 1

        if self._local_recovery_cursor is None:
            self._local_recovery_scan_blocked = False
        candidates, next_after = self._transfer_store.page_local_recovery_candidates(
            limit=16, after_job_key=self._local_recovery_cursor
        )
        self._local_recovery_cursor = next_after
        if candidates:
            referenced = self.database.referenced_stage_paths(
                tuple(candidate.stage_path for candidate in candidates)
            )
            for candidate in candidates:
                if str(candidate.stage_path.resolve(strict=False)) in referenced:
                    continue
                try:
                    plan = _load_local_recovery_plan(candidate)
                except (OSError, InvalidTask, StateError, UnsafePath, ValueError) as error:
                    self._local_recovery_scan_blocked = True
                    self.logger.record(
                        "fabric_local_snapshot_recovery_blocked",
                        transfer_id=candidate.transfer_id,
                        staged_path=str(candidate.stage_path),
                        error=str(error),
                    )
                    continue
                intent = self.database.get_local_transfer_intent(plan.path)
                if intent is not None:
                    continue
                self._local_recovery_candidate = candidate
                self._local_recovery_plan = plan
                self._local_recovery_future = _daemon_future(
                    "meshia-local-recovery-verify",
                    lambda candidate=candidate: (
                        self._transfer_store.validate_local_recovery_candidate(
                            candidate,
                            max_sync_verify_bytes=candidate.size_bytes,
                        )
                    ),
                )
                self._local_recovery_future.add_done_callback(
                    lambda _future: self.wake()
                )
                self._local_recovery_pending = True
                return 0

        if next_after is None:
            self._local_recovery_cursor = None
            self._local_recovery_pending = self._local_recovery_scan_blocked
            self._next_local_recovery_scan = (
                float(self._clock()) + ORPHAN_STAGE_SCAN_INTERVAL_SECONDS
            )
        else:
            self._local_recovery_pending = True
        return 0

    def _reclaim_finalized_remote_transfers(self) -> None:
        """Boundedly close the ACK-to-disposable-delete crash window."""

        candidates, next_after = (
            self._transfer_store.page_remote_finalization_candidates(
                limit=16,
                after_job_key=self._remote_finalization_cleanup_cursor,
            )
        )
        self._remote_finalization_cleanup_cursor = next_after
        for candidate in candidates:
            if self.database.has_remote_apply_intent(candidate.final_path):
                continue
            if candidate.state in ("receiving", "cancelled"):
                current_entry = self.database.get_remote_entry(candidate.final_path)
                if (
                    current_entry is not None
                    and current_entry.size_bytes == candidate.size_bytes
                    and current_entry.digest == candidate.file_digest
                ):
                    # The immutable object is still the current remote truth.
                    # A temporarily missing apply intent must not discard its
                    # resumable download state.
                    continue
                active = self._remote_transfer
                owns_active_state = bool(
                    active is not None
                    and not active.range_stage_owned
                    and active.logical_path == candidate.logical_path
                )
                if (
                    owns_active_state
                    and active is not None
                    and active.future is not None
                    and not active.future.done()
                ):
                    # The immutable byte worker may still hold the job object.
                    # Let it reach its bounded terminal handoff; a later tick
                    # can then cancel/remove the obsolete physical owner.
                    continue
                removed = self._transfer_store.discard_abandoned_remote(
                    candidate.logical_path,
                    transfer_id=candidate.transfer_id,
                    final_path=candidate.final_path,
                    size_bytes=candidate.size_bytes,
                    file_digest=candidate.file_digest,
                )
                if removed and owns_active_state:
                    # Physical removal above is the durable terminal boundary.
                    # Retaining only the volatile coordinator pointer would
                    # falsely hold command readiness at transfer_pending.
                    self._remote_transfer = None
                self.logger.record(
                    "fabric_remote_partial_cleanup_recovered",
                    path=candidate.final_path,
                    transfer_id=candidate.transfer_id,
                )
                continue
            materialized = self.database.get_materialized(candidate.final_path)
            if (
                materialized is None
                or materialized.state != "clean"
                or materialized.clean_digest != candidate.file_digest
                or materialized.content_sha256 != candidate.sha256
                or materialized.bytes_on_disk != candidate.size_bytes
                or materialized.stat_fingerprint is None
            ):
                continue
            current = self.workspace.stat_fingerprint(candidate.final_path)
            if (
                current is None
                or _fingerprint_text(current) != materialized.stat_fingerprint
            ):
                continue
            if candidate.token is None:
                raise StateError("The finalized remote stage lost its cleanup token.")
            self._transfer_store.discard_finalized_remote(
                candidate.logical_path,
                transfer_id=candidate.transfer_id,
                token=candidate.token,
            )
            self.logger.record(
                "fabric_remote_stage_cleanup_recovered",
                path=candidate.final_path,
                transfer_id=candidate.transfer_id,
            )

    def _advance_remote_transfer(
        self,
        path: str,
        materialized: MaterializedEntry,
        entry: RemoteEntry,
        head: RemoteManifestHead,
    ) -> int:
        """Advance one bounded remote byte/control phase for the queue head."""

        resolution = self.database.get_applying_conflict_resolution_for_path(path)
        expected_existing_fingerprint = (
            _fingerprint_from_text(resolution.expected_local_fingerprint)
            if resolution is not None
            and resolution.expected_local_fingerprint is not None
            else None
        )
        state = self._remote_transfer
        if state is not None and state.cancelled_by_local_mutation.is_set():
            if state.path != path:
                raise StateError("A cancelled remote transfer lost its queue head.")
            future = state.future
            if future is not None and not future.done():
                return 0
            result: _RemotePublishResult | None = None
            if state.phase == "finalize":
                result = state.publish_result
            elif future is not None and state.phase in ("publish", "range_publish"):
                try:
                    candidate = future.result()
                except BaseException:
                    candidate = None
                if isinstance(candidate, _RemotePublishResult):
                    result = candidate
            return self._complete_cancelled_remote_transfer(state, result)
        if state is not None and state.phase == "finalize":
            if state.path != path:
                raise StateError("The completed remote publish lost its queue head.")
            result = state.publish_result
            if result is None:
                raise StateError("The remote transfer lost its completed publish result.")
            return self._complete_remote_publish(state, result)
        if state is not None and not self._remote_state_matches(state, head, entry):
            if state.future is not None and not state.future.done():
                return 0
            if state.phase in ("publish", "range_publish") and state.future is not None:
                try:
                    result = state.future.result()
                except BaseException:
                    if not state.range_stage_owned and state.stage is not None:
                        try:
                            self._transfer_store.release_ready(
                                state.stage.logical_path, state.stage.token
                            )
                        except TransferError:
                            pass
                    self._discard_remote_transfer(state)
                    return 0
                state.future = None
                state.publish_result = result
                state.phase = "finalize"
                return self._complete_remote_publish(state, result)
            self._discard_remote_transfer(state)
            state = None

        if state is None:
            self._assert_remote_destination_capacity(
                entry.size_bytes, replacing_path=entry.path
            )
            if head.digest is None and entry.blocks is None:
                # A v2 snapshot row may arrive without its block descriptor.
                # Fetch it once (persisted) before choosing a lane: without
                # it a large file fell into the v1 range transfer, whose
                # object-ticket and signed-range lanes are both minted
                # against a published manifest a v2 head never has.
                entry = self._lookup_v2_descriptor(entry)
            blocks = self._load_remote_entry_blocks(entry, head)
            updated = self.database.get_remote_entry(path)
            if updated is None or updated.digest != entry.digest or updated.size_bytes != entry.size_bytes:
                raise NetworkError("The remote file changed while loading its block index.")
            entry = updated
            if blocks is None:
                if _deferred_transfer_block_summary(entry) is not None:
                    # One signed block-index page consumed this control tick.
                    return 0
                if (
                    entry.size_bytes > BLOCK_BYTES
                    or expected_existing_fingerprint is not None
                ):
                    logical_path = self._remote_transfer_logical_path(
                        path, head, entry
                    )
                    state = _RemoteTransferState(
                        path=path,
                        generation=head.generation,
                        manifest_digest=head.digest,
                        file_digest=entry.digest,
                        file_size_bytes=entry.size_bytes,
                        pinned=materialized.pinned,
                        expected_clean_digest=materialized.clean_digest,
                        logical_path=logical_path,
                        expected_content_sha256=materialized.content_sha256,
                        block_descriptor=entry.blocks,
                        expected_existing_fingerprint=expected_existing_fingerprint,
                    )
                    self._begin_remote_range_transfer(state)
                    # Do not expose a half-initialized transfer to the next
                    # tick. Capacity or filesystem setup can fail before the
                    # range stage has an owned inode.
                    self._remote_transfer = state
                    return 0
                if self.materialize(path, pinned=materialized.pinned):
                    self._drop_remote_apply_head()
                    return 1
                self._drop_remote_apply_head()
                return 0
            logical_path = self._remote_transfer_logical_path(path, head, entry)
            state = _RemoteTransferState(
                path=path,
                generation=head.generation,
                manifest_digest=head.digest,
                file_digest=entry.digest,
                file_size_bytes=entry.size_bytes,
                pinned=materialized.pinned,
                expected_clean_digest=materialized.clean_digest,
                logical_path=logical_path,
                expected_content_sha256=materialized.content_sha256,
                block_descriptor=entry.blocks,
                expected_existing_fingerprint=expected_existing_fingerprint,
                cas_storage_kind=_cas_storage_kind(entry),
            )
            try:
                opened = self._transfer_store.open(
                    logical_path, max_sync_verify_bytes=0
                )
            except FileNotFoundError:
                opened = self._transfer_store.create_remote(
                    logical_path,
                    size_bytes=entry.size_bytes,
                    **({"file_digest": entry.digest}
                       if file_digest_algorithm(entry.blocks) != "sha256"
                       else {"sha256": entry.digest}),
                    blocks=blocks,
                    final_path=path,
                )
            except RecoveryDeferred:
                try:
                    state.future = self._transfer_store.open_async(logical_path)
                except TransferBusy:
                    return 0
                state.phase = "open"
                self._remote_transfer = state
                state.future.add_done_callback(lambda _future: self.wake())
                return 0
            if not isinstance(opened, RemoteAssemblyJob):
                raise StateError("A remote transfer reopened as the wrong job kind.")
            state.job = opened
            # Installation is the final setup step: every later tick now sees
            # either an exact job or an exact async reopen future.
            self._remote_transfer = state
            if opened.progress.get("state") in ("ready", "leased"):
                self._begin_remote_publish(state)
            else:
                self._schedule_remote_probe(state)
            return 0

        future = state.future
        if future is None:
            if state.phase == "range":
                self._advance_remote_range_transfer(state)
            elif state.phase == "range_ready":
                self._begin_remote_range_publish(state)
            elif state.phase == "ready":
                self._begin_remote_publish(state)
            elif state.phase == "open" and state.job is not None:
                if state.job.progress.get("state") in ("ready", "leased"):
                    self._begin_remote_publish(state)
                else:
                    self._schedule_remote_probe(state)
            elif state.phase == "probe" and state.job is not None:
                self._schedule_remote_probe(state)
            return 0
        if not future.done():
            return 0
        state.future = None
        if state.phase == "open":
            try:
                opened = future.result()
            except BaseException:
                self._remote_transfer = None
                raise
            if not isinstance(opened, RemoteAssemblyJob):
                raise StateError("A remote transfer reopened as the wrong job kind.")
            state.job = opened
            if opened.progress.get("state") in ("ready", "leased"):
                self._begin_remote_publish(state)
            else:
                self._schedule_remote_probe(state)
            return 0
        if state.phase == "probe":
            try:
                probe = future.result()
            except BaseException:
                self._schedule_remote_probe(state)
                raise
            if not isinstance(probe, _RemoteBatchProbe):
                raise StateError("The remote cache probe returned an invalid result.")
            tickets: Mapping[str, Mapping[str, Any]] = {}
            if probe.missing:
                block_reads = getattr(self.transport, "block_reads", None)
                if not callable(block_reads):
                    raise NetworkError("The Fabric transport cannot mint block reads.")
                # Bootstrap with at most one 4-MiB block-equivalent, then
                # expand only to the number
                # measured aggregate goodput can consume before expiry. This
                # retains the fast-link control-call win without stranding a
                # 64-ticket lease on a slow provider path.
                ticket_blocks = tuple(
                    {block.sha256: block for block in probe.missing}.values()
                )
                edge_tickets = self._edge_read_tickets(
                    ticket_blocks, state.cas_storage_kind
                )
                if edge_tickets is not None:
                    # Meshia object edge: CAS blocks read straight from the
                    # edge under the workspace grant, no signed call.
                    tickets = edge_tickets
                else:
                    response = self._signed_control_request(
                        block_reads,
                        self._block_read_payload(
                            path=state.path,
                            blocks=ticket_blocks,
                            manifest_generation=state.generation,
                            manifest_digest=state.manifest_digest,
                        ),
                    )
                    tickets = _block_read_tickets(response, ticket_blocks)
                self._note_direct_read_ticket_headroom(tickets)
            state.ticket_blocks = probe.blocks
            state.tickets = tickets
            state.ticket_cursor = 0
            self._schedule_remote_ticket_fetch(state)
            return 0
        if state.phase == "fetch":
            try:
                stage = future.result()
            except BaseException:
                self._schedule_remote_probe(state)
                raise
            if stage is None:
                state.ticket_cursor += state.fetch_count
                state.fetch_count = 0
                if state.ticket_cursor < len(state.ticket_blocks):
                    self._schedule_remote_ticket_fetch(state)
                else:
                    self._schedule_remote_probe(state)
            else:
                state.stage = stage
                state.phase = "ready"
                self._begin_remote_publish(state)
            return 0
        if state.phase in ("publish", "range_publish"):
            try:
                result = future.result()
            except BaseException:
                if state.range_stage_owned:
                    # Keep already verified bytes private and retry publication
                    # after the coordinator's bounded error backoff.
                    state.phase = "range_ready"
                elif state.stage is not None:
                    try:
                        self._transfer_store.release_ready(
                            state.stage.logical_path, state.stage.token
                        )
                    except TransferError:
                        pass
                    self._remote_transfer = None
                raise
            state.publish_result = result
            state.phase = "finalize"
            return self._complete_remote_publish(state, result)
        raise StateError("The remote transfer entered an unknown phase.")

    def warm_object_read(self, path: str) -> bool:
        """Prefetch read tickets for a large plain object and its siblings.

        Opening one file in a folder is a strong hint that its neighbours are
        next (Finder previews, a photo library, model shards), so every large
        plain sibling is ticketed in the same signed call.
        """

        reader = self._object_reader
        if reader is None:
            return False
        entry = self.database.get_remote_entry(path)
        head = self.database.get_remote_manifest_head()
        if entry is None or head is None or entry.blocks is not None or not reader.serves(entry):
            return False
        if head.digest is None:
            # Whole-object tickets are minted against a published v1
            # manifest, which a Fabric v2 head never has; its bytes come from
            # the descriptor + block lane on first read instead. Warming here
            # used to hand the v2 head's absent digest to the object reader,
            # whose range cache rejected it and stalled the whole sync loop
            # (2026-09-02: every mount open of a bootstrapped file).
            return False
        candidates: list[RemoteEntry] = [entry]
        parent = path.rsplit("/", 1)[0] if "/" in path else None
        try:
            children = self.database.list_remote_children(parent, limit=1_000)
        except (InvalidTask, StateError, ValueError):
            children = ()
        for child in children:
            if len(candidates) >= OBJECT_WARM_SIBLING_LIMIT:
                break
            if child.is_directory or child.path == path or child.size_bytes < OBJECT_WARM_MIN_BYTES:
                continue
            sibling = self.database.get_remote_entry(child.path)
            if sibling is None or sibling.blocks is not None:
                continue
            candidates.append(sibling)
        if len(candidates) == 1:
            return reader.warm(entry, head)
        return reader.warm_many(candidates, head) > 0

    def stream(
        self, path: str, *, offset: int = 0, length: int | None = None,
        expected_digest: str | None = None,
    ) -> Iterator[bytes]:
        receipt = self.database.get_receipted_entry(path)
        entry = receipt.entry if receipt is not None else self.database.get_remote_entry(path)
        head = self.database.get_remote_manifest_head()
        if entry is None or head is None:
            raise InvalidTask("The remote Fabric file does not exist.")
        # A caller may already have advertised this content version. Bind the
        # exact entry captured for streaming, including an unobserved receipt,
        # before descriptor lookup or byte IO; a later identity check alone
        # would consistently validate a newer version under an older header.
        if expected_digest is not None and entry.digest != expected_digest:
            raise OSError(errno.ESTALE, "The requested Fabric content version changed.")
        # The first ACK can precede the very first journal entry (cursor 0).
        # Bind byte-cache extents to its proven sequence, while the observed
        # head below remains unchanged for read-race detection and convergence.
        byte_head = (
            replace(head, generation=receipt.generation)
            if receipt is not None and receipt.generation > head.generation
            else head
        )
        if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
            raise ValueError("offset must be a non-negative integer")
        if offset > entry.size_bytes:
            raise ValueError("offset exceeds file size")
        if length is None:
            requested_length = entry.size_bytes - offset
        elif isinstance(length, bool) or not isinstance(length, int) or length < 0:
            raise ValueError("length must be a non-negative integer")
        else:
            requested_length = length
        if offset + requested_length > entry.size_bytes:
            raise ValueError("requested range exceeds file size")

        # A Fabric v2 head has no manifest identity, and the v1 range lane is
        # built entirely out of one: `fabric/read` requires a published
        # manifest server-side, and the range cache keys every entry by
        # (manifest_generation, manifest_digest). Neither can represent a v2
        # workspace, and a wiped or brand-new one has no manifest to publish.
        #
        # v2 content is content-addressed instead. The journal record carries
        # the block descriptor, so the block lane resolves extents locally and
        # fetches them by sha256 -- which is why it needs no manifest at all.
        # There is deliberately no degrade-to-v1 path here: falling back would
        # reintroduce exactly the 409 loop this replaces, and silently, as a
        # read that never completes.
        v2_head = head.digest is None
        if v2_head and entry.blocks is None:
            # A file learned through a snapshot page may carry no descriptor;
            # fetch the exact entry once and keep the descriptor locally so
            # this read (and every later one) can use the block lane.
            entry = self._lookup_v2_descriptor(entry)

        def legacy() -> Iterator[bytes]:
            if v2_head:
                raise NetworkError(
                    "A Fabric v2 read cannot fall back to the manifest-scoped "
                    "range lane; the block descriptor is missing."
                )
            yield from self.cache.stream(
                path,
                entry.digest,
                entry.size_bytes,
                manifest_generation=head.generation,
                manifest_digest=head.digest,
                fetch_range=lambda requested_path, digest, size, start, count: self._fetch_range(
                    requested_path,
                    digest,
                    size,
                    start,
                    count,
                    manifest_generation=head.generation,
                    manifest_digest=head.digest,
                ),
                offset=offset,
                length=requested_length,
            )

        def bound_stream() -> Iterator[bytes]:
            self._assert_stream_identity(entry, head)
            if isinstance(entry.blocks, Mapping) and entry.blocks.get("file_digest_algorithm") == FABRIC_FILE_TREE_ALGORITHM:
                yield from self._stream_tree_ranges(entry, head, cache_generation=byte_head.generation,
                    offset=offset, length=requested_length)
                return
            if requested_length == 0:
                return
            cached_range = (
                None
                if v2_head or entry.blocks is not None
                else self.cache.get(
                    entry.digest,
                    entry.size_bytes,
                    offset,
                    requested_length,
                    manifest_generation=head.generation,
                    manifest_digest=head.digest,
                )
            )
            if cached_range is not None:
                self._assert_stream_identity(entry, head)
                yield cached_range
                self._assert_stream_identity(entry, head)
                return
            object_reader = self._object_reader
            if (
                object_reader is not None
                and not v2_head
                and entry.blocks is None
                and object_reader.serves(entry)
            ):
                try:
                    direct_data = object_reader.read(entry, head, offset, requested_length)
                except ObjectReadUnavailable:
                    direct_data = None
                except ObjectReadStale as error:
                    raise OSError(
                        errno.ESTALE,
                        "The Fabric manifest changed during the object read.",
                    ) from error
                if direct_data is not None:
                    self._assert_stream_identity(entry, head)
                    yield direct_data
                    self._assert_stream_identity(entry, head)
                    return
            block_reads = getattr(self.transport, "block_reads", None)
            download_block = getattr(self.transport, "download_block", None)
            blocks: tuple[StagedBlock, ...] | None = None
            if callable(block_reads) and callable(download_block):
                try:
                    blocks = self._mounted_range_blocks(
                        entry,
                        head,
                        offset=offset,
                        length=requested_length,
                    )
                except RemoteError as error:
                    if _is_remote_head_stale(error):
                        raise OSError(
                            errno.ESTALE,
                            "The Fabric manifest changed during block lookup.",
                        ) from error
                except NetworkError:
                    # Legacy and packed objects retain the exact-head signed
                    # range lane when direct block descriptors are unavailable.
                    blocks = None
            if blocks:
                range_download = getattr(self.transport, "download_block_range", None)
                if callable(range_download):
                    for chunk in self._stream_direct_block_ranges(
                        entry, byte_head, blocks, offset=offset, length=requested_length,
                        block_reads=block_reads, download=range_download,
                    ):
                        self._assert_stream_identity(entry, head)
                        yield chunk
                    self._assert_stream_identity(entry, head)
                    return
                direct = self._stream_direct_blocks(
                    entry,
                    byte_head,
                    blocks,
                    block_reads=block_reads,
                    download_block=download_block,
                )
                try:
                    first = next(direct)
                except StopIteration as error:
                    raise NetworkError(
                        "The direct Fabric range returned no overlapping bytes."
                    ) from error
                except RemoteError as error:
                    if _is_remote_head_stale(error):
                        raise OSError(
                            errno.ESTALE,
                            "The Fabric manifest changed during block read.",
                        ) from error
                    self._assert_stream_identity(entry, head)
                    yield from legacy()
                    self._assert_stream_identity(entry, head)
                    return
                except NetworkError:
                    self._assert_stream_identity(entry, head)
                    yield from legacy()
                    self._assert_stream_identity(entry, head)
                    return

                emitted = 0
                for index, block in enumerate(blocks):
                    try:
                        data = first if index == 0 else next(direct)
                    except RemoteError as error:
                        if _is_remote_head_stale(error):
                            raise OSError(
                                errno.ESTALE,
                                "The Fabric manifest changed during block read.",
                            ) from error
                        raise
                    self._assert_stream_identity(entry, head)
                    slice_start = max(offset, block.offset_bytes) - block.offset_bytes
                    slice_end = (
                        min(
                            offset + requested_length,
                            block.offset_bytes + block.size_bytes,
                        )
                        - block.offset_bytes
                    )
                    if slice_end > slice_start:
                        chunk = data[slice_start:slice_end]
                        emitted += len(chunk)
                        yield chunk
                try:
                    next(direct)
                except StopIteration:
                    pass
                else:
                    raise NetworkError(
                        "The direct Fabric range exceeded its descriptor bound."
                    )
                self._assert_stream_identity(entry, head)
                if emitted != requested_length:
                    raise NetworkError(
                        "The direct Fabric range ended before its requested bound."
                    )
                return

            yield from legacy()
            self._assert_stream_identity(entry, head)

        return bound_stream()

    def materialize(self, path: str, *, pinned: bool | None = None) -> bool:
        entry = self.database.get_remote_entry(path)
        head = self.database.get_remote_manifest_head()
        if entry is None or head is None:
            raise InvalidTask("The remote Fabric file does not exist.")
        if head.digest is None and entry.blocks is None:
            entry = self._lookup_v2_descriptor(entry)
        algorithm = file_digest_algorithm(entry.blocks)
        root_identity = algorithm != "sha256"
        tree_reader = self._tree_reader(entry, head) if algorithm == FABRIC_FILE_TREE_ALGORITHM else None
        if root_identity and tree_reader is None:
            for _ in range((MAX_MANIFEST_BLOCKS + MANIFEST_BLOCK_PAGE_SIZE - 1) // MANIFEST_BLOCK_PAGE_SIZE + 1):
                if _deferred_transfer_block_summary(entry) is None:
                    break
                if _requires_remote_only_materialization(entry, materialization_ceiling=self.max_staging_bytes):
                    raise InvalidTask("The block index exceeds this edge's materialization ceiling.")
                self._assert_stream_identity(entry, head)
                self._load_remote_entry_blocks(entry, head)
                self._assert_stream_identity(entry, head)
                entry = self.database.get_remote_entry(path)
                if entry is None:
                    raise NetworkError("The remote file disappeared while loading its block index.")
            else:
                raise NetworkError("The remote block index did not finish within its page bound.")
            if not _complete_object_cas_layout(entry):
                raise NetworkError("The materialization has no complete verified block identity.")
        materialized = self.database.get_materialized(path)
        local = self._hash_regular_file(path)
        if local is not None and self._local_matches_remote(local, entry, materialized):
            self.database.mark_materialized(
                path,
                state="clean",
                clean_digest=entry.digest,
                content_sha256=local.sha256,
                stat_fingerprint=_fingerprint_text(local.fingerprint),
                bytes_on_disk=local.fingerprint.size_bytes,
                pinned=pinned,
            )
            return False
        expected_existing: str | None = None
        if local is not None:
            if materialized is None or materialized.state != "clean" or local.sha256 != materialized.content_sha256:
                self.database.record_conflict(
                    path,
                    "remote materialization refused to overwrite local bytes",
                    base_digest=materialized.clean_digest if materialized else None,
                    local_digest=local.sha256,
                    remote_digest=entry.digest,
                    remote_generation=head.generation,
                )
                self.database.mark_materialized(
                    path,
                    state="conflict",
                    clean_digest=materialized.clean_digest if materialized else None,
                    stat_fingerprint=_fingerprint_text(local.fingerprint),
                    bytes_on_disk=local.fingerprint.size_bytes,
                    pinned=pinned,
                )
                return False
            expected_existing = f"sha256:{local.sha256}"
        if _requires_remote_only_materialization(
            entry, materialization_ceiling=self.max_staging_bytes
        ):
            raise InvalidTask(
                "The remote object exceeds this edge's configured materialization ceiling."
            )
        self._assert_remote_destination_capacity(
            entry.size_bytes, replacing_path=entry.path
        )
        apply_token = self.watch.arm_remote_apply(path, timeout_seconds=300.0)
        retired: RetiredRegularFile | None = None
        content_hasher = hashlib.sha256() if root_identity else None
        try:
            def renewing_stream() -> Iterator[bytes]:
                for chunk in self._materialization_stream(entry, head, tree_reader=tree_reader):
                    if not self.watch.renew_remote_apply(
                        apply_token, timeout_seconds=300.0
                    ):
                        raise StateError("The Fabric materialization lease expired.")
                    if content_hasher is not None:
                        content_hasher.update(chunk)
                    yield chunk

            retired = self.workspace.write_stream(
                path,
                renewing_stream(),
                expected_size=entry.size_bytes,
                **({"expected_file_digest": f"{algorithm}:{entry.digest}",
                    "block_descriptor": entry.blocks, "tree_source": tree_reader} if root_identity else
                   {"expected_sha256": f"sha256:{entry.digest}"}),
                create_parents=True,
                # An absent destination uses the exclusive-publish path. This
                # is the missing half of the local CAS: a user create racing a
                # remote materialization must win rather than be overwritten.
                overwrite=local is not None,
                expected_existing_sha256=expected_existing,
                expected_existing_fingerprint=(
                    local.fingerprint if local is not None else None
                ),
                retain_replaced=local is not None,
                require_retention_capacity=local is not None,
            )
            if not self.watch.renew_remote_apply(
                apply_token, timeout_seconds=300.0
            ):
                raise StateError("The Fabric materialization lease expired after commit.")
            written = self._hash_regular_file(path)
            if not self.watch.renew_remote_apply(
                apply_token, timeout_seconds=300.0
            ):
                raise StateError("The Fabric materialization lease expired during verification.")
            if written is None or written.sha256 != (
                content_hasher.hexdigest() if content_hasher is not None else entry.digest
            ):
                raise StateError("The materialized Fabric file disappeared after commit.")
            if not self.watch.commit_remote_apply(apply_token, {path: written}):
                # Exact watcher verification observed another namespace state.
                # Snapshot that winning local state before returning to the
                # remote queue; never let a timing token discard user bytes.
                raced = self._hash_regular_file(path)
                self._finish_retired_apply(
                    retired, path=path, remote=entry, preserve=False
                )
                retired = None
                if raced is None:
                    self._stage_delete(path)
                else:
                    self._stage_local_put_bounded(path)
                return False
        except (InvalidTask, UnsafePath):
            self.watch.abort_remote_apply(apply_token)
            self._finish_retired_apply(
                retired, path=path, remote=entry, preserve=True
            )
            retired = None
            raced = self._hash_regular_file(path)
            if raced is not None and (
                local is None
                or raced.sha256 != local.sha256
                or raced.fingerprint != local.fingerprint
            ):
                self._stage_local_put_bounded(path)
                return False
            raise
        except BaseException:
            self.watch.abort_remote_apply(apply_token)
            self._finish_retired_apply(
                retired, path=path, remote=entry, preserve=True
            )
            raise
        self._finish_retired_apply(retired, path=path, remote=entry, preserve=False)
        self.database.mark_materialized(
            path,
            state="clean",
            clean_digest=entry.digest,
            content_sha256=written.sha256,
            stat_fingerprint=_fingerprint_text(written.fingerprint),
            bytes_on_disk=written.fingerprint.size_bytes,
            pinned=pinned,
            # Proof by retrieval: this file was just streamed out of object
            # storage and its whole-file digest verified against the manifest.
            remote_verified=True,
        )
        return True

    def _local_matches_remote(
        self, local: HashedRegularFile, entry: RemoteEntry,
        materialized: MaterializedEntry | None = None,
        *, source_path: str | None = None,
    ) -> bool:
        if local.fingerprint.size_bytes != entry.size_bytes:
            return False
        if file_digest_algorithm(entry.blocks) == "sha256":
            return local.sha256 == entry.digest
        if (materialized is not None
                and materialized.clean_digest == entry.digest
                and materialized.content_sha256 == local.sha256):
            return True
        tree_reader = None
        if file_digest_algorithm(entry.blocks) == FABRIC_FILE_TREE_ALGORITHM:
            head = self.database.get_remote_manifest_head()
            if head is None:
                return False
            tree_reader = self._tree_reader(entry, head)
        elif not _complete_object_cas_layout(entry):
            return False
        # First adoption has no durable local checksum baseline. Prove the
        # actual block bytes under the same stable source fingerprint once.
        verifier = FabricFileHasher(entry.blocks, tree_source=tree_reader)
        try:
            for offset in range(0, entry.size_bytes, BLOCK_BYTES):
                verifier.update(self.workspace.read_regular_range(source_path or entry.path, offset,
                    min(BLOCK_BYTES, entry.size_bytes - offset), local.fingerprint))
            return verifier.hexdigest() == entry.digest
        except (ValueError, InvalidTask, UnsafePath):
            return False

    def _finish_retired_apply(
        self,
        retired: RetiredRegularFile | None,
        *,
        path: str,
        remote: RemoteEntry,
        preserve: bool,
    ) -> None:
        if retired is None:
            return
        preserved_path = self._finish_retired_with_mount_fence(
            retired,
            preserve=preserve,
        )
        if preserved_path is None:
            return
        fingerprint = self.workspace.stat_fingerprint(preserved_path)
        local = (
            self._hash_regular_file(preserved_path)
            if fingerprint is not None
            and fingerprint.size_bytes <= BACKGROUND_TRANSFER_THRESHOLD_BYTES
            else None
        )
        self.database.record_conflict(
            path,
            "local bytes changed through an open handle during remote apply",
            base_digest=retired.initial.sha256,
            local_digest=local.sha256 if local else None,
            remote_digest=remote.digest,
            remote_generation=self._remote_generation(),
        )
        if fingerprint is not None:
            self._stage_local_put_bounded(preserved_path)

    def _materialization_stream(
        self, entry: RemoteEntry, head: RemoteManifest | RemoteManifestHead,
        *, tree_reader: FabricTreeReader | None = None,
    ) -> Iterator[bytes]:
        """Prefer direct CAS blocks, with signed range reads as the safe base."""

        if tree_reader is not None:
            yield from tree_reader.stream(0, entry.size_bytes)
            return

        block_reads = getattr(self.transport, "block_reads", None)
        download_block = getattr(self.transport, "download_block", None)
        blocks = _cas_read_blocks(entry)
        if block_reads is None or download_block is None or blocks is None:
            yield from self.stream(entry.path)
            return
        direct = self._stream_direct_blocks(
            entry, head, blocks, block_reads=block_reads, download_block=download_block
        )
        try:
            first = next(direct)
        except StopIteration:
            return
        except (NetworkError, RemoteError):
            # Legacy, packed, or no-longer-referenced objects can reject a
            # ticket before any byte reaches the atomic workspace temp file.
            yield from self.stream(entry.path)
            return
        yield first
        # A later ticket failure aborts the WorkspaceBoundary temp write. A
        # fresh attempt is safe; silently switching mid-stream would duplicate
        # the already yielded prefix.
        yield from direct

    def _tree_reader(self, entry, head, *, cache_generation: int | None = None) -> FabricTreeReader:
        tickets = collections.OrderedDict()
        storage_kind = _cas_storage_kind(entry)

        def fetch(digest, size, start, count, ancestors):
            self._assert_stream_identity(entry, head)
            block = StagedBlock(0, 0, size, digest)
            key = (digest, size)
            ticket = tickets.get(key)
            if ticket is None or _direct_read_ticket_expiry(ticket) <= time.time() + 10:
                issued = self._edge_read_tickets((block,), storage_kind)
                if issued is None:
                    response = self._signed_control_request(self.transport.block_reads, {
                        "attachment_id": self.authority.attachment_id, "workspace": WORKSPACE_MOUNT,
                        "operation": "read_batch_v2", "path": entry.path,
                        "file_digest": entry.digest,
                        "tree_path": [base64.b64encode(node).decode("ascii") for node in ancestors],
                        "blocks": [{"sha256": digest, "size_bytes": size}],
                    })
                    issued = _block_read_tickets(response, (block,))
                ticket = issued[digest]
                tickets[key] = ticket
                while len(tickets) > 128:
                    tickets.popitem(last=False)
            tickets.move_to_end(key)
            data = self.transport.download_block_range(ticket, start, count)
            if not isinstance(data, bytes) or len(data) != count:
                raise NetworkError("A Fabric tree object range returned the wrong byte count.")
            self._assert_stream_identity(entry, head)
            return data

        if cache_generation is None:
            receipt = self.database.get_receipted_entry(entry.path)
            cache_generation = max(head.generation, receipt.generation if receipt is not None else 0)
        return FabricTreeReader(entry.blocks, entry.digest, entry.size_bytes, cache=self.cache,
            generation=cache_generation,
            fetch=fetch, check=lambda: self._assert_stream_identity(entry, head))

    def _stream_tree_ranges(self, entry, head, *, cache_generation: int, offset: int, length: int) -> Iterator[bytes]:
        try:
            reader = self._tree_reader(entry, head, cache_generation=cache_generation)
            yield from reader.stream(offset, length)
        except ValueError as error:
            raise NetworkError("The Fabric tree read failed identity verification.") from error

    def _stream_direct_block_ranges(
        self, entry: RemoteEntry, head: RemoteManifest | RemoteManifestHead,
        blocks: Sequence[StagedBlock], *, offset: int, length: int,
        block_reads: Any, download: Any,
    ) -> Iterator[bytes]:
        """Demand-first CAS reads with bounded, reusable 1 MiB cache extents.

        File extensions never select the transport. Provider checksum receipts
        bind partial bytes to each immutable block; the existing range cache
        hashes local extents and fences them to the manifest's file identity.
        """
        unit = 1024 * 1024
        end = offset + length
        for block in blocks:
            start = max(offset, block.offset_bytes)
            stop = min(end, block.offset_bytes + block.size_bytes)
            ticket = None
            while start < stop:
                relative = start - block.offset_bytes
                unit_start = (relative // unit) * unit
                unit_length = min(unit, block.size_bytes - unit_start)
                absolute = block.offset_bytes + unit_start
                data = self.cache.get(entry.digest, entry.size_bytes, absolute, unit_length,
                    manifest_generation=head.generation, manifest_digest=head.digest)
                if data is None:
                    if ticket is None or _direct_read_ticket_expiry(ticket) <= time.time() + 10:
                        tickets = self._edge_read_tickets((block,), _cas_storage_kind(entry))
                        if tickets is None:
                            response = self._signed_control_request(block_reads, self._block_read_payload(
                                path=entry.path, blocks=(block,), manifest_generation=head.generation,
                                manifest_digest=head.digest,
                            ))
                            tickets = _block_read_tickets(response, (block,))
                        ticket = tickets[block.sha256]
                    data = download(ticket, unit_start, unit_length)
                    if not isinstance(data, bytes) or len(data) != unit_length:
                        raise NetworkError("A Fabric block range returned the wrong byte count.")
                    self.cache.put(entry.digest, entry.size_bytes, absolute, data,
                        hashlib.sha256(data).hexdigest(), manifest_generation=head.generation,
                        manifest_digest=head.digest)
                slice_start = start - absolute
                count = min(stop - start, len(data) - slice_start)
                yield data[slice_start:slice_start + count]
                start += count

    def _stream_direct_blocks(
        self,
        entry: RemoteEntry,
        head: RemoteManifest | RemoteManifestHead,
        blocks: Sequence[StagedBlock],
        *,
        block_reads: Any,
        download_block: Any,
    ) -> Iterator[bytes]:
        transient: dict[str, bytes] = {}
        transient_bytes = 0

        def remember(digest: str, data: bytes) -> None:
            nonlocal transient_bytes
            if digest in transient or len(data) > MAX_CAS_BLOCK_BYTES:
                return
            while transient and transient_bytes + len(data) > MAX_CAS_BLOCK_BYTES:
                retired_digest = next(iter(transient))
                retired_data = transient.pop(retired_digest)
                transient_bytes -= len(retired_data)
            if transient_bytes + len(data) <= MAX_CAS_BLOCK_BYTES:
                transient[digest] = data
                transient_bytes += len(data)

        def reusable(block: StagedBlock) -> bytes | None:
            hit = transient.get(block.sha256)
            if hit is not None and len(hit) != block.size_bytes:
                raise NetworkError(
                    "A repeated Fabric block digest changed its declared size."
                )
            if hit is None:
                hit = self.cache.get_content(block.sha256, block.size_bytes)
                if hit is not None:
                    remember(block.sha256, hit)
            if hit is not None:
                # Bind a content-addressed hit to this exact logical extent so
                # later reads retain manifest/offset identity in the range map.
                self.cache.put(
                    entry.digest,
                    entry.size_bytes,
                    block.offset_bytes,
                    hit,
                    block.sha256,
                    manifest_generation=head.generation,
                    manifest_digest=head.digest,
                )
            return hit

        ticket_start = 0
        while ticket_start < len(blocks):
            window = self._direct_read_ticket_window(blocks[ticket_start:])
            ticket_window = list(
                blocks[ticket_start : ticket_start + window]
            )
            ticket_candidates: dict[str, StagedBlock] = {}
            for block in ticket_window:
                if block.size_bytes == 0:
                    continue
                if self.cache.get(
                    entry.digest,
                    entry.size_bytes,
                    block.offset_bytes,
                    block.size_bytes,
                    manifest_generation=head.generation,
                    manifest_digest=head.digest,
                    expected_range_sha256=block.sha256,
                ) is None and reusable(block) is None:
                    ticket_candidates.setdefault(block.sha256, block)
            tickets: Mapping[str, Mapping[str, Any]] = {}
            if ticket_candidates:
                requested = tuple(ticket_candidates.values())
                response = self._signed_control_request(
                    block_reads,
                    self._block_read_payload(
                        path=entry.path,
                        blocks=requested,
                        manifest_generation=head.generation,
                        manifest_digest=head.digest,
                    ),
                )
                tickets = _block_read_tickets(response, requested)
                self._note_direct_read_ticket_headroom(tickets)
            for logical in self._direct_read_batches(ticket_window):
                cached: dict[str, bytes] = {}
                missing: dict[str, StagedBlock] = {}
                for block in logical:
                    if block.size_bytes == 0:
                        cached[block.sha256] = b""
                        continue
                    hit = self.cache.get(
                        entry.digest,
                        entry.size_bytes,
                        block.offset_bytes,
                        block.size_bytes,
                        manifest_generation=head.generation,
                        manifest_digest=head.digest,
                        expected_range_sha256=block.sha256,
                    )
                    if hit is not None:
                        cached[block.sha256] = hit
                    else:
                        hit = reusable(block)
                        if hit is not None:
                            cached[block.sha256] = hit
                        else:
                            missing.setdefault(block.sha256, block)
                if missing:
                    if any(digest not in tickets for digest in missing):
                        raise NetworkError(
                            "A Fabric cache entry disappeared outside its ticket lease."
                        )
                    ordered = list(missing.items())
                    active_timeout = self._direct_read_active_timeout(
                        tuple(tickets[digest] for digest, _block in ordered),
                        now_epoch=self._wall_now_ns() / 1_000_000_000,
                    )
                    started_at = float(self._clock())
                    result = self._direct_byte_pool.fetch_batch(
                        tuple(
                            DirectByteTask(
                                BlockSpec(
                                    block.index,
                                    block.offset_bytes,
                                    block.size_bytes,
                                    block.sha256,
                                ),
                                lambda block=block, ticket=tickets[digest]: (
                                    self._download_and_cache_direct_block(
                                        entry.digest,
                                        entry.size_bytes,
                                        head.generation,
                                        head.digest,
                                        (block,),
                                        ticket,
                                        download_block,
                                    )
                                ),
                            )
                            for digest, block in ordered
                        ),
                        timeout=active_timeout,
                    )
                    if result.failures or result.timed_out or result.unstarted:
                        raise _direct_batch_failure(result)
                    downloaded_by_digest = {
                        item.block.sha256: item.data for item in result.completed
                    }
                    downloaded = [downloaded_by_digest[digest] for digest, _ in ordered]
                    self._record_direct_read_goodput(
                        sum(len(data) for data in downloaded),
                        max(0.0, float(self._clock()) - started_at),
                    )
                    for (digest, block), data in zip(
                        ordered, downloaded, strict=True
                    ):
                        cached[digest] = data
                        remember(digest, data)
                for block in logical:
                    if block.size_bytes:
                        yield cached[block.sha256]
            ticket_start += len(ticket_window)

    def _fetch_range(
        self,
        path: str,
        file_sha256: str,
        file_size: int,
        offset: int,
        length: int,
        *,
        manifest_generation: int | None = None,
        manifest_digest: str | None = None,
    ) -> FetchedRange:
        if manifest_generation is None or manifest_digest is None:
            head = self.database.get_remote_manifest_head()
            if head is None:
                raise NetworkError("The Fabric manifest disappeared before range read.")
            manifest_generation = head.generation
            manifest_digest = head.digest
        response = self._signed_control_request(
            self.transport.read,
            {
                "attachment_id": self.authority.attachment_id,
                "workspace": WORKSPACE_MOUNT,
                "path": path,
                "offset_bytes": offset,
                "length_bytes": length,
                "manifest_generation": manifest_generation,
                "manifest_digest": manifest_digest,
            },
        )
        encoded = response.get("content_base64") if isinstance(response, dict) else None
        data = decode_canonical_b64(encoded) if isinstance(encoded, str) else None
        if (
            not isinstance(response, dict)
            or response.get("schema") != RANGE_SCHEMA
            or response.get("workspace") != WORKSPACE_MOUNT
            or response.get("path") != path
            or response.get("file_size_bytes") != file_size
            or response.get("offset_bytes") != offset
            or response.get("length_bytes") != length
            or response.get("file_sha256") != file_sha256
            or not _digest(response.get("range_sha256"))
            or data is None
            or len(data) != length
            or hashlib.sha256(data).hexdigest() != response.get("range_sha256")
            or response.get("manifest_generation") != manifest_generation
            or response.get("manifest_digest") != manifest_digest
        ):
            raise NetworkError("Meshia returned an invalid Fabric range.")
        return FetchedRange(
            data=data,
            range_sha256=str(response["range_sha256"]),
            manifest_generation=int(response["manifest_generation"]),
            manifest_digest=str(response["manifest_digest"]),
        )

    # ---------------------------------------------------------- reconciliation

    def _reconcile_local_namespace(self) -> int:
        names, truncated = self.workspace.list(
            ".", max_entries=MAX_REMOTE_FILES, recursive=True
        )
        if truncated:
            raise StateError("The local workspace exceeds the 250,000-entry Fabric bound.")
        local_paths = {name for name in names if not name.endswith("/")}
        staged = 0
        for path in sorted(local_paths):
            remote = self.database.get_remote_entry(path)
            materialized = self.database.get_materialized(path)
            if materialized is not None and materialized.state in ("dirty", "staging", "conflict"):
                if self._durable_adoption_pending and self._strict_authority_adoption:
                    self._authority_adoption_unmatched = True
                continue
            fingerprint = self.workspace.stat_fingerprint(path)
            if fingerprint is None:
                continue
            fingerprint_text = _fingerprint_text(fingerprint)
            if (
                materialized is not None
                and materialized.state == "clean"
                and materialized.stat_fingerprint == fingerprint_text
            ):
                if remote is not None and remote.digest == materialized.clean_digest:
                    # The durable content baseline and exact cheap stat tuple are
                    # unchanged. Periodic bounded watcher probes still detect a
                    # deliberately preserved-metadata edit eventually.
                    continue
                if not self._adoption_reconcile_pending:
                    if (
                        remote is None
                        and self._remote_head_is_v2()
                        and not self.database.has_remote_apply_intent(path)
                    ):
                        # Clean local bytes that the v2 remote has no record
                        # of. Classifying this as a remote apply resolves to a
                        # retire, which is right for a deletion and destructive
                        # for a reset workspace -- and the two are the same
                        # signal here without a durable apply intent. A
                        # projected delete can survive a crash before its cache
                        # retirement; that active-scope intent stays authoritative.
                        self._stage_local_put_bounded(path)
                        staged += 1
                        continue
                    # Local bytes are untouched while the remote namespace
                    # advanced or deleted this path. Preserve the remote-apply
                    # classification without rereading on every restart. An
                    # explicit first-use adoption cannot trust a copied legacy
                    # ledger, so it falls through to content verification.
                    self._queue_remote_applies((path,))
                    continue
            local = self._hash_regular_file(path)
            if local is None:
                continue
            if remote is not None and self._local_matches_remote(local, remote, materialized):
                self.database.mark_materialized(
                    path,
                    state="clean",
                    clean_digest=remote.digest,
                    content_sha256=local.sha256,
                    stat_fingerprint=_fingerprint_text(local.fingerprint),
                    bytes_on_disk=local.fingerprint.size_bytes,
                )
                continue
            if self._durable_adoption_pending:
                if self._strict_authority_adoption:
                    self._authority_adoption_unmatched = True
                    if remote is not None:
                        self._record_adoption_conflict(
                            path,
                            local=local,
                            remote=remote,
                            materialized=materialized,
                        )
                    else:
                        self.database.record_conflict(
                            path,
                            "authority adoption found local bytes absent from the new remote head",
                            base_digest=(
                                materialized.clean_digest
                                if materialized is not None
                                else None
                            ),
                            local_digest=local.sha256,
                            remote_digest=None,
                            remote_generation=self._remote_generation(),
                        )
                        self.database.mark_materialized(
                            path,
                            state="conflict",
                            clean_digest=(
                                materialized.clean_digest
                                if materialized is not None
                                else None
                            ),
                            stat_fingerprint=_fingerprint_text(local.fingerprint),
                            bytes_on_disk=local.fingerprint.size_bytes,
                            pinned=True,
                        )
                # Generation-only changes can legitimately contain offline
                # edits. Strict authority changes cannot infer ownership. In
                # both cases, never create write work before the adoption CAS.
                continue
            if self._adoption_reconcile_pending and remote is not None:
                self._record_adoption_conflict(
                    path,
                    local=local,
                    remote=remote,
                    materialized=materialized,
                )
                staged += 1
                continue
            if materialized is not None and materialized.state == "clean" and local.sha256 == materialized.content_sha256:
                if (
                    remote is None
                    and self._remote_head_is_v2()
                    and not self.database.has_remote_apply_intent(path)
                ):
                    # Clean local bytes the v2 remote has no record of. Queuing
                    # a remote apply here would resolve to "the remote does not
                    # have it" and retire the file -- which is the wipe case,
                    # not a deletion, unless a durable active-scope apply
                    # already owns its retirement across this restart.
                    self._stage_local_put_bounded(path)
                    staged += 1
                    continue
                # Local bytes are untouched; the remote side advanced. Queue a
                # bounded remote apply instead of misclassifying it as upload.
                self._queue_remote_applies((path,))
                continue
            self._stage_local_put_bounded(path)
            staged += 1

        # Page the *materialized* ledger, not the first 10k remote paths. A long
        # remote-only prefix must not hide a missing working-set file, and a
        # zero-byte file with a durable fingerprint is still locally present.
        after_path: str | None = None
        examined = 0
        while examined < MAX_REMOTE_FILES:
            page = self.database.list_materialized_entries(
                states=("clean",), limit=1_000, after_path=after_path
            )
            if not page:
                break
            after_path = page[-1].path
            examined += len(page)
            for materialized in page:
                if materialized.path in local_paths:
                    continue
                remote = self.database.get_remote_entry(materialized.path)
                if (
                    materialized.bytes_on_disk == 0
                    and materialized.stat_fingerprint is None
                ):
                    # This is a crash-recovered pending hydration, not proof of
                    # a user deletion. Restore its volatile apply intent.
                    if remote is not None:
                        self._queue_remote_applies((materialized.path,))
                    else:
                        self.database.mark_materialized(
                            materialized.path,
                            state="absent",
                            clean_digest=materialized.clean_digest,
                            bytes_on_disk=0,
                            pinned=materialized.pinned,
                        )
                    continue
                if self.database.has_eviction_intent(materialized.path):
                    continue
                if self._adoption_reconcile_pending:
                    if remote is not None:
                        self._record_adoption_conflict(
                            materialized.path,
                            local=None,
                            remote=remote,
                            materialized=materialized,
                        )
                        staged += 1
                    else:
                        self.database.mark_materialized(
                            materialized.path,
                            state="absent",
                            clean_digest=materialized.clean_digest,
                            bytes_on_disk=0,
                            pinned=materialized.pinned,
                        )
                        self.watch.acknowledge_local_state(
                            {materialized.path: None}
                        )
                    continue
                self._stage_delete(materialized.path)
                staged += 1
            if len(page) < 1_000:
                break
        return staged

    def _record_adoption_conflict(
        self,
        path: str,
        *,
        local: HashedRegularFile | None,
        remote: RemoteEntry,
        materialized: MaterializedEntry | None,
    ) -> None:
        """Preserve preexisting bytes/absence against the first remote head."""

        self.database.record_conflict(
            path,
            (
                "adopted workspace is missing an authoritative remote file"
                if local is None
                else "adopted workspace differs from authoritative remote bytes"
            ),
            base_digest=(materialized.clean_digest if materialized else None),
            local_digest=(local.sha256 if local is not None else None),
            remote_digest=remote.digest,
            remote_generation=self._remote_generation(),
        )
        self.database.mark_materialized(
            path,
            state="conflict",
            clean_digest=remote.digest,
            stat_fingerprint=(
                _fingerprint_text(local.fingerprint)
                if local is not None
                else None
            ),
            bytes_on_disk=(local.fingerprint.size_bytes if local is not None else 0),
            pinned=True,
        )
        self.watch.acknowledge_local_state({path: local})

    def _hash_regular_file(self, path: str) -> Any:
        """Count coordinator-initiated full-content hashes for diagnostics."""

        self._local_hashes += 1
        return self.workspace.hash_regular_file(path)

    def _queue_remote_applies(self, paths: Iterable[str]) -> None:
        # Preserve the durable restore order and delta cohort order. An unpinned
        # clean zero-byte reservation without a stat baseline is initial prefetch,
        # provided its digest still matches the remote file. A successor edit or
        # deletion is foreground work even before that reservation was hydrated.
        ordered = tuple(dict.fromkeys(paths))
        speculative = set(self.database.filter_materialized_paths(
            ordered, speculative_only=True
        ))
        priority = set(ordered) - speculative
        promoted = priority - self._remote_apply_priority_members
        self._remote_apply_priority_members.update(priority)
        for path in ordered:
            if path not in self._remote_apply_members:
                self._remote_apply_queue.append(path)
                self._remote_apply_members.add(path)
        if promoted:
            # Only a newly queued/promoted cohort changes scheduling order.
            # Re-sorting every tick would undo intentional receipt/eviction
            # rotations and repeatedly put blocked work ahead of other paths.
            owners = {
                owner.path for owner in (self._remote_transfer, self._manifest_block_load)
                if owner is not None
            }
            self._remote_apply_queue = deque(sorted(
                self._remote_apply_queue,
                key=lambda path: (
                    0 if path in owners else
                    1 if path in self._remote_apply_priority_members else 2
                ),
            ))

    def _drop_remote_apply_head(self) -> str:
        path = self._remote_apply_queue[0]
        self.database.complete_remote_apply_intent(path)
        self._remote_apply_queue.popleft()
        self._remote_apply_members.discard(path)
        self._remote_apply_priority_members.discard(path)
        return path

    def _forget_remote_apply_path(self, path: str) -> None:
        """Forget one already-retired durable apply from the bounded queue."""

        if path not in self._remote_apply_members:
            return
        self._remote_apply_queue = deque(
            queued for queued in self._remote_apply_queue if queued != path
        )
        self._remote_apply_members.discard(path)
        self._remote_apply_priority_members.discard(path)

    def _repair_legacy_content_missing_conflicts(self) -> int:
        """Self-heal only empty legacy conflicts after a complete refresh."""

        if (
            self._force_full_remote
            or self.database.get_remote_manifest_load() is not None
            or self.watch.overflow
        ):
            return 0
        head = self.database.get_remote_manifest_head()
        if head is None:
            return 0
        repaired = 0
        candidates = self.database.list_legacy_content_missing_conflicts(
            limit=LEGACY_CONTENT_MISSING_REPAIR_LIMIT,
            after_conflict_id=self._legacy_content_missing_repair_cursor,
        )
        self._legacy_content_missing_repair_cursor = (
            candidates[-1].conflict_id
            if len(candidates) == LEGACY_CONTENT_MISSING_REPAIR_LIMIT
            else 0
        )
        for conflict in candidates:
            if not _is_legacy_content_missing_conflict_reason(conflict.reason):
                continue
            try:
                apply_token = self.watch.arm_remote_apply(conflict.path)
            except RuntimeError:
                # A concurrent watcher overflow owns recovery; wait for its
                # complete local scan instead of weakening the absence proof.
                self._startup_reconcile = True
                break
            try:
                if self.workspace.stat_fingerprint(conflict.path) is not None:
                    continue
                if not self.watch.commit_remote_apply(
                    apply_token, {conflict.path: None}
                ):
                    self._startup_reconcile = True
                    continue
                outcome = self.database.repair_legacy_content_missing_conflict(
                    conflict.conflict_id,
                    expected_reason=conflict.reason,
                    expected_generation=head.generation,
                    expected_manifest_digest=head.digest,
                )
            finally:
                # No namespace mutation occurred. Retire the observation token
                # immediately; normal future local edges must remain visible.
                self.watch.abort_remote_apply(apply_token)
            if outcome is None:
                continue
            if outcome.remote_digest is None:
                self._forget_remote_apply_path(outcome.path)
            else:
                self._queue_remote_applies((outcome.path,))
            repaired += 1
            self.logger.record(
                "fabric_legacy_content_missing_repaired",
                path=outcome.path,
                outcome=(
                    "remote_hydration_requeued"
                    if outcome.remote_digest is not None
                    else "remote_absence_confirmed"
                ),
                manifest_generation=head.generation,
            )
        return repaired

    def _restore_remote_intents(self, *, refresh_priority: bool = False) -> None:
        initial = not self._remote_intents_restored
        (
            pending_apply,
            pending_rename,
        ) = self.database.has_pending_remote_intents()
        self._remote_apply_intents_may_remain = pending_apply
        self._remote_rename_intents_may_remain = pending_rename
        if initial or refresh_priority or (
            not self._remote_apply_queue and pending_apply
        ):
            applies = self.database.list_remote_apply_intents(
                limit=REMOTE_INTENT_RESTORE_BATCH, materialized_first=True
            )
            self._queue_remote_applies(applies)
            self._remote_apply_intents_may_remain = (
                len(applies) == REMOTE_INTENT_RESTORE_BATCH
            )
        if initial or (
            not self._remote_rename_queue and pending_rename
        ):
            renames = self.database.list_remote_rename_intents(
                limit=REMOTE_INTENT_RESTORE_BATCH
            )
            self._queue_remote_renames(
                (
                    intent.source_path,
                    intent.destination_path,
                    intent.digest,
                    intent.size_bytes,
                )
                for intent in renames
            )
            self._remote_rename_intents_may_remain = (
                len(renames) == REMOTE_INTENT_RESTORE_BATCH
            )
            if initial and self._remote_rename_queue:
                # A durable rename may have been inferred from a cursor older
                # than the process. Give it one refresh turn before local
                # apply, then alternate so an always-due remote cadence cannot
                # starve the queued namespace mutation forever.
                self._prefer_remote_control = True
        self._remote_intents_restored = True

    def _seed_remote_entries(self, entries: Iterable[RemoteEntry]) -> None:
        """Select only newly added remote rows within the durable quota."""

        if (
            self.max_auto_materializations == 0
            or self.max_auto_materialized_bytes == 0
        ):
            return
        reserved_entries, reserved = self.database.working_set_reservation()
        remaining = max(
            0,
            self.max_auto_materialized_bytes
            - self._materialized_storage_bytes()
            - reserved,
        )
        selected = 0
        for entry in sorted(entries, key=lambda item: item.path):
            # Explicit v2 directories are namespace metadata, not zero-byte
            # files. A None digest must never enter file materialization; an
            # exception here occurs after the journal cursor was committed and
            # would skip the refresh's notification/apply scheduling tail.
            if entry.kind != "file":
                continue
            if selected + reserved_entries >= self.max_auto_materializations:
                break
            if self.database.get_materialized(entry.path) is not None:
                continue
            if entry.size_bytes > remaining:
                continue
            self.database.mark_materialized(
                entry.path,
                state="clean",
                clean_digest=entry.digest,
                bytes_on_disk=0,
                queue_remote_apply=True,
            )
            self._queue_remote_applies((entry.path,))
            remaining -= entry.size_bytes
            selected += 1

    def _infer_remote_renames(
        self, old: RemoteManifest | None, new: RemoteManifest
    ) -> list[tuple[str, str, str, int]]:
        if old is None:
            return []
        before = {entry.path: entry for entry in old.entries if entry.kind == "file"}
        after = {entry.path: entry for entry in new.entries if entry.kind == "file"}
        removed: dict[str, list[RemoteEntry]] = {}
        added: dict[str, list[RemoteEntry]] = {}
        for path in before.keys() - after.keys():
            removed.setdefault(before[path].digest, []).append(before[path])
        for path in after.keys() - before.keys():
            added.setdefault(after[path].digest, []).append(after[path])
        result: list[tuple[str, str, str, int]] = []
        for digest in removed.keys() & added.keys():
            sources, destinations = removed[digest], added[digest]
            if len(sources) != 1 or len(destinations) != 1:
                continue
            source, destination = sources[0], destinations[0]
            materialized = self.database.get_materialized(source.path)
            if materialized is None or materialized.state != "clean" or materialized.clean_digest != digest:
                continue
            result.append((source.path, destination.path, digest, destination.size_bytes))
        return sorted(result)

    def _queue_remote_renames(
        self, renames: Iterable[tuple[str, str, str, int]]
    ) -> None:
        for rename in renames:
            key = (rename[0], rename[1])
            if key not in self._remote_rename_members:
                self._remote_rename_queue.append(rename)
                self._remote_rename_members.add(key)

    def _drop_remote_rename_head(self) -> tuple[str, str, str, int]:
        rename = self._remote_rename_queue[0]
        self.database.complete_remote_rename_intent(rename[0], rename[1])
        self._remote_rename_queue.popleft()
        self._remote_rename_members.discard((rename[0], rename[1]))
        return rename

    def _prune_directory_rename_source(self) -> None:
        """Remove only empty local source directories before overlay retirement.

        The authoritative directory mutation is represented by per-file apply
        and rename intents. Those moves can leave empty backing directories,
        especially after duplicate-digest entries use the ordinary apply lane.
        Running this idempotent bottom-up pass at the retirement boundary also
        covers a restart after the remote receipt but before local cleanup.
        """

        operation = self.database.get_observable_directory_rename()
        if operation is None:
            return
        self.workspace.prune_empty_directories(operation.path)
        if not self.workspace.directory_exists(operation.path):
            return
        try:
            public_entries, truncated = self.workspace.list(
                operation.path,
                max_entries=MAX_LIST_ENTRIES,
                recursive=True,
            )
        except (InvalidTask, OSError, UnsafePath):
            return
        if truncated or any(not entry.endswith("/") for entry in public_entries):
            return
        # An SMB/open-handle retirement can safely retain hidden inodes after
        # every public child has moved. Persist the same local-only namespace
        # tombstone used by rmdir before retiring the rename overlay, so a
        # service restart cannot resurrect the source folder. The exact-head
        # CAS fails open if a concurrent remote child arrived.
        head = self.database.get_remote_manifest_head()
        self.database.mark_local_directory_removed(
            operation.path,
            expected_generation=(head.generation if head is not None else None),
            expected_manifest_digest=(head.digest if head is not None else None),
        )

    def _apply_remote_renames(self) -> int:
        applied = 0
        examined = 0
        examination_budget = min(
            self.max_remote_applies_per_tick, len(self._remote_rename_queue)
        )
        while (
            self._remote_rename_queue
            and applied < self.max_remote_applies_per_tick
            and examined < examination_budget
        ):
            source, destination, digest, size = self._remote_rename_queue[0]
            examined += 1
            if (
                self.database.get_receipted_entry(source) is not None
                or self.database.get_receipted_entry(destination) is not None
            ):
                # A partial journal page must not replay an older namespace
                # move over a newer exact local ACK. Keep unrelated work live.
                self._remote_rename_queue.rotate(-1)
                continue
            if self.database.has_eviction_intent(
                source
            ) or self.database.has_eviction_intent(destination):
                # A hidden eviction owner and its materialized row are one
                # accounting authority until actual reclaim. Keep the durable
                # rename queued, but rotate so an unrelated path can converge.
                self._remote_rename_queue.rotate(-1)
                continue
            materialized = self.database.get_materialized(source)
            if materialized is None or materialized.state != "clean":
                self._drop_remote_rename_head()
                continue
            current_source = self.database.get_remote_entry(source)
            current_destination = self.database.get_remote_entry(destination)
            if (
                current_source is not None
                or current_destination is None
                or current_destination.digest != digest
                or current_destination.size_bytes != size
            ):
                # This durable intent was inferred from an older delta, but a
                # later cursor changed either endpoint before local apply.
                # Decompose it into exact current-state applies; never mark the
                # old destination digest clean merely because the bytes still
                # exist at the source path.
                self._queue_remote_applies((source,))
                self._queue_current_remote_destination(
                    destination,
                    current_destination,
                    pinned=materialized.pinned,
                )
                self._drop_remote_rename_head()
                continue
            local = self._hash_regular_file(source)
            if local is None:
                self.database.mark_materialized(
                    source,
                    state="absent",
                    clean_digest=digest,
                    bytes_on_disk=0,
                    pinned=False,
                )
                self._queue_remote_destination(
                    destination, digest=digest, size=size, pinned=materialized.pinned
                )
                self._drop_remote_rename_head()
                continue
            if not self._local_matches_remote(local, current_destination, materialized, source_path=source):
                if not self._defer_directory_path(source, "put"):
                    self._stage_local_put_bounded(source)
                self._queue_remote_destination(
                    destination, digest=digest, size=size, pinned=materialized.pinned
                )
                self._drop_remote_rename_head()
                continue
            target = self._hash_regular_file(destination)
            if target is not None and target.sha256 != local.sha256:
                # The pod rename is already authoritative. Preserve the clean
                # source as a local-origin recreate while exposing the blocked
                # remote destination as an explicit conflict.
                if not self._defer_directory_path(source, "put"):
                    self._stage_local_put_bounded(source)
                self.database.record_conflict(
                    destination,
                    "remote rename refused to overwrite its local destination",
                    base_digest=None,
                    local_digest=target.sha256,
                    remote_digest=digest,
                    remote_generation=self._remote_generation(),
                )
                self.database.mark_materialized(
                    destination,
                    state="conflict",
                    clean_digest=(self.database.get_materialized(destination).clean_digest if self.database.get_materialized(destination) else None),
                    stat_fingerprint=_fingerprint_text(target.fingerprint),
                    bytes_on_disk=target.fingerprint.size_bytes,
                    pinned=True,
                )
                self._drop_remote_rename_head()
                continue
            apply_token = self.watch.arm_remote_apply(source, destination)
            duplicate_retired: RetiredRegularFile | None = None
            duplicate_preserved = False
            try:
                if target is not None and target.fingerprint != local.fingerprint:
                    # A distinct destination already contains the exact remote
                    # bytes. Retire the source behind the same watcher/mount
                    # boundaries as remote delete; the legacy remover would
                    # age-promote an unchanged open-handle survivor as a false
                    # recovered edit five minutes later.
                    duplicate_retired = self.workspace.retire_file(
                        source,
                        require_retention_capacity=True,
                        expected_file=local,
                    )
                    if duplicate_retired is None or (
                        duplicate_retired.initial.sha256 != local.sha256
                        or duplicate_retired.initial.fingerprint.device_id
                        != local.fingerprint.device_id
                        or duplicate_retired.initial.fingerprint.file_id
                        != local.fingerprint.file_id
                    ):
                        raise InvalidTask(
                            "The remote rename source changed before duplicate cleanup."
                        )
                    moved = self._hash_regular_file(destination)
                else:
                    self.workspace.rename_file(
                        source,
                        destination,
                        expected_sha256=f"sha256:{local.sha256}",
                        create_parents=True,
                    )
                    moved = self._hash_regular_file(destination)
                if moved is None or moved.sha256 != local.sha256:
                    raise StateError("The remote Fabric rename did not commit locally.")
                if not self.watch.commit_remote_apply(
                    apply_token, {source: None, destination: moved}
                ):
                    duplicate_preserved = self._finish_remote_rename_duplicate(
                        duplicate_retired,
                        source=source,
                        materialized=materialized,
                        preserve=False,
                    )
                    duplicate_retired = None
                    self._preserve_remote_rename_race(
                        source,
                        destination,
                        digest=digest,
                        size=size,
                        pinned=materialized.pinned,
                    )
                    self._drop_remote_rename_head()
                    continue
                duplicate_preserved = self._finish_remote_rename_duplicate(
                    duplicate_retired,
                    source=source,
                    materialized=materialized,
                    preserve=False,
                )
                duplicate_retired = None
            except RetentionCapacityUnavailable:
                self.watch.abort_remote_apply(apply_token)
                # Retention pressure is backpressure, not a namespace race.
                # The source is still untouched, so retain the durable rename
                # and rotate behind unrelated work without publishing an echo.
                self._remote_rename_queue.rotate(-1)
                continue
            except (InvalidTask, UnsafePath):
                self.watch.abort_remote_apply(apply_token)
                self._finish_remote_rename_duplicate(
                    duplicate_retired,
                    source=source,
                    materialized=materialized,
                    preserve=True,
                )
                duplicate_retired = None
                self._preserve_remote_rename_race(
                    source,
                    destination,
                    digest=digest,
                    size=size,
                    pinned=materialized.pinned,
                )
                self._drop_remote_rename_head()
                continue
            except BaseException:
                self.watch.abort_remote_apply(apply_token)
                self._finish_remote_rename_duplicate(
                    duplicate_retired,
                    source=source,
                    materialized=materialized,
                    preserve=True,
                )
                raise
            if not duplicate_preserved:
                self.database.mark_materialized(
                    source,
                    state="absent",
                    clean_digest=digest,
                    bytes_on_disk=0,
                    pinned=False,
                )
            self.database.mark_materialized(
                destination,
                state="clean",
                clean_digest=digest,
                stat_fingerprint=_fingerprint_text(moved.fingerprint),
                content_sha256=moved.sha256,
                bytes_on_disk=size,
                pinned=materialized.pinned,
            )
            self._drop_remote_rename_head()
            applied += 1
        return applied

    def _finish_remote_rename_duplicate(
        self,
        retired: RetiredRegularFile | None,
        *,
        source: str,
        materialized: MaterializedEntry,
        preserve: bool,
    ) -> bool:
        """Finalize one duplicate rename source without manufacturing an echo."""

        if retired is None:
            return False
        preserved_path = self._finish_retired_with_mount_fence(
            retired,
            preserve=preserve,
        )
        if preserved_path is None:
            return False
        fingerprint = self.workspace.stat_fingerprint(preserved_path)
        local = (
            self._hash_regular_file(preserved_path)
            if fingerprint is not None
            and fingerprint.size_bytes <= BACKGROUND_TRANSFER_THRESHOLD_BYTES
            else None
        )
        self.database.record_conflict(
            source,
            "local bytes changed through an open handle during remote rename cleanup",
            base_digest=materialized.clean_digest,
            local_digest=local.sha256 if local else None,
            remote_digest=None,
            remote_generation=self._remote_generation(),
        )
        if fingerprint is not None:
            self._stage_local_put_bounded(preserved_path)
        return True

    def _prune_remote_deleted_parent_directories(self, path: str) -> None:
        """Discard empty cache scaffolding after an authoritative file delete.

        Explicit remote directories and pending local namespace work own their
        parents even with no file bytes. Only walk the deleted path's ancestors
        (never an unrelated subtree), and let the descriptor-confined rmdir
        protect concurrent local additions and retained recovery evidence.
        """
        if self.database.has_unobserved_receipts():
            # An acknowledged mkdir may be newer than this partial page's
            # directory deletion. Metadata receipts carry a watermark, not a
            # per-path file descriptor; defer only physical directory pruning.
            # The file's apply intent retires below, so retain bounded ancestor
            # intents durably rather than orphaning this deferred cleanup.
            ancestors = []
            parent = path.rpartition("/")[0]
            while parent:
                ancestors.append(parent)
                parent = parent.rpartition("/")[0]
            self.database.enqueue_remote_apply_intents(ancestors)
            self._queue_remote_applies(ancestors)
            return
        parent = path.rpartition("/")[0]
        while parent:
            if (
                self.database.is_remote_directory(parent)
                or self.database.has_pending_directory_put(parent)
                or self.database.list_remote_children(parent, limit=1)
                or self.database.list_nonterminal_operations_touching_prefix(
                    parent, limit=1
                )
            ):
                return
            try:
                self.workspace.remove_empty_directory(parent)
            except InvalidTask:
                pass
            except (OSError, UnsafePath):
                # A nonempty, raced, or unsafe directory must remain intact.
                return
            parent = parent.rpartition("/")[0]

    def _apply_remote_working_set(self) -> int:
        applied = self._apply_remote_renames()
        examined = 0
        examination_budget = min(
            self.max_remote_applies_per_tick, len(self._remote_apply_queue)
        )
        while (
            self._remote_apply_queue
            and applied < self.max_remote_applies_per_tick
            and examined < examination_budget
            and not self._stop_requested("remote_apply")
        ):
            path = self._remote_apply_queue[0]
            examined += 1
            if self.database.get_receipted_entry(path) is not None:
                # The raw projection can trail this path's acknowledged write
                # across pages. Retain its apply intent until readback, rather
                # than hydrate old bytes over the just-committed local inode.
                self._remote_apply_queue.rotate(-1)
                continue
            if self.database.has_eviction_intent(path):
                # Do not materialize a successor over a hidden eviction
                # preimage: that would repurpose the row that accounts for the
                # old inode and later misclassify authoritative bytes as a
                # local edit. Preserve the durable apply intent and rotate it
                # behind unrelated work until reclaim/cancel resolves.
                self._remote_apply_queue.rotate(-1)
                continue
            materialized = self.database.get_materialized(path)
            active_transfer = self._remote_transfer
            if (
                active_transfer is not None
                and active_transfer.path == path
                and active_transfer.cancelled_by_local_mutation.is_set()
            ):
                active_remote = self.database.get_remote_entry(path)
                active_head = self.database.get_remote_manifest_head()
                if materialized is None or active_remote is None or active_head is None:
                    future = active_transfer.future
                    if future is not None and not future.done():
                        return applied
                    applied += self._complete_cancelled_remote_transfer(
                        active_transfer
                    )
                else:
                    applied += self._advance_remote_transfer(
                        path, materialized, active_remote, active_head
                    )
                return applied
            if materialized is None:
                # Explicit directory deletions have durable apply intents but
                # no file materialization row. Wait for child file intents to
                # drain, then remove only empty cache directories. Never remove
                # a concurrent local mkdir or a now-authoritative directory.
                if (
                    not self.database.is_remote_directory(path)
                    and not self.database.list_remote_children(path, limit=1)
                    and not self.database.has_pending_directory_put(path)
                    and self.workspace.directory_exists(path)
                ):
                    if self.database.has_unobserved_receipts():
                        self._remote_apply_queue.rotate(-1)
                        continue
                    self.workspace.prune_empty_directories(path)
                    if self.workspace.directory_exists(path):
                        self._remote_apply_queue.rotate(-1)
                        continue
                self._drop_remote_apply_head()
                continue
            if materialized.state == "absent":
                remote_only = self.database.get_remote_entry(path)
                if remote_only is not None:
                    self.database.mark_materialized(
                        path,
                        state="absent",
                        clean_digest=remote_only.digest,
                        bytes_on_disk=0,
                        pinned=False,
                    )
                self._drop_remote_apply_head()
                continue
            if materialized.state in ("dirty", "staging", "conflict"):
                self._drop_remote_apply_head()
                continue
            if self._remote_transfer is not None and self._remote_transfer.path == path:
                active_remote = self.database.get_remote_entry(path)
                active_head = self.database.get_remote_manifest_head()
                if active_remote is None or active_head is None:
                    if (
                        self._remote_transfer.future is not None
                        and not self._remote_transfer.future.done()
                    ):
                        return applied
                    self._discard_remote_transfer(self._remote_transfer)
                    return applied
                applied += self._advance_remote_transfer(
                    path, materialized, active_remote, active_head
                )
                return applied
            resolution = self.database.get_applying_conflict_resolution_for_path(path)
            if (
                resolution is not None
                and resolution.expected_local_fingerprint is not None
            ):
                expected_identity = _fingerprint_from_text(
                    resolution.expected_local_fingerprint
                )
                current_identity = self.workspace.stat_fingerprint(path)
                if current_identity != expected_identity:
                    if current_identity is not None:
                        self.database.record_conflict(
                            path,
                            "protocol-oversize local bytes advanced during keep-remote",
                            local_fingerprint=_fingerprint_text(current_identity),
                            remote_digest=resolution.expected_remote_digest,
                            remote_generation=self._remote_generation(),
                        )
                        self.database.mark_materialized(
                            path,
                            state="conflict",
                            clean_digest=resolution.expected_remote_digest,
                            stat_fingerprint=_fingerprint_text(current_identity),
                            bytes_on_disk=current_identity.size_bytes,
                            pinned=True,
                        )
                    self._block_conflict_resolution(
                        resolution,
                        "the protocol-oversize local identity advanced before apply",
                    )
                    self._drop_remote_apply_head()
                    continue
                remote = self.database.get_remote_entry(path)
                if remote is None or _requires_remote_only_materialization(
                    remote, materialization_ceiling=self.max_staging_bytes
                ):
                    apply_token = self.watch.arm_remote_apply(path)
                    committed = False
                    try:
                        preserved_path = self.workspace.preserve_file_by_fingerprint(
                            path, expected_fingerprint=expected_identity
                        )
                        if self.workspace.stat_fingerprint(path) is not None:
                            raise StateError(
                                "a newer local file appeared during keep-remote"
                            )
                        committed = self.watch.commit_remote_apply(
                            apply_token, {path: None}
                        )
                        if not committed:
                            self._startup_reconcile = True
                        self.database.mark_materialized(
                            path,
                            state="absent",
                            clean_digest=(remote.digest if remote is not None else None),
                            bytes_on_disk=0,
                            pinned=False,
                        )
                        self._stage_local_put_bounded(preserved_path)
                    except (InvalidTask, StateError, UnsafePath) as error:
                        if not committed:
                            self.watch.abort_remote_apply(apply_token)
                        self._block_conflict_resolution(resolution, str(error))
                        self._drop_remote_apply_head()
                        continue
                    self._drop_remote_apply_head()
                    applied += 1
                    continue
                # A bounded remote winner is downloaded normally, but its
                # publisher receives the exact identity-CAS fence instead of
                # hashing the >32-GiB loser.
                head = self.database.get_remote_manifest_head()
                if head is None:
                    raise StateError("The remote Fabric head disappeared during apply.")
                applied += self._advance_remote_transfer(
                    path, materialized, remote, head
                )
                return applied
            fingerprint = self.workspace.stat_fingerprint(path)
            if fingerprint is None:
                local = None
            elif (
                materialized.content_sha256 is not None
                and materialized.stat_fingerprint is not None
                and _fingerprint_from_text(materialized.stat_fingerprint)
                == fingerprint
            ):
                # The durable digest is bound to this exact stat tuple; do not
                # re-read multi-GiB clean bytes on the signed control thread.
                local = HashedRegularFile(fingerprint, materialized.content_sha256)
            elif fingerprint.size_bytes > BACKGROUND_TRANSFER_THRESHOLD_BYTES:
                if not self._defer_directory_path(path, "put"):
                    self._stage_local_put_bounded(
                        path,
                        expected_source_digest=materialized.clean_digest,
                    )
                self._drop_remote_apply_head()
                continue
            else:
                local = self._hash_regular_file(path)
            if local is not None and local.sha256 != materialized.content_sha256:
                if not self._defer_directory_path(path, "put"):
                    self._stage_local_put_bounded(
                        path,
                        expected_source_digest=materialized.clean_digest,
                    )
                self._drop_remote_apply_head()
                continue
            remote = self.database.get_remote_entry(path)
            if remote is None:
                if local is not None:
                    apply_token = self.watch.arm_remote_apply(path)
                    retired: RetiredRegularFile | None = None
                    try:
                        retired = self.workspace.retire_file(
                            path,
                            require_retention_capacity=True,
                            expected_file=local,
                        )
                        if retired is None:
                            raise InvalidTask(
                                "The workspace file disappeared before remote delete."
                            )
                        if (
                            retired.initial.sha256 != local.sha256
                            or retired.initial.fingerprint.device_id
                            != local.fingerprint.device_id
                            or retired.initial.fingerprint.file_id
                            != local.fingerprint.file_id
                        ):
                            self._finish_retired_delete(
                                retired, path=path, materialized=materialized, preserve=True
                            )
                            retired = None
                            self.watch.abort_remote_apply(apply_token)
                            self._drop_remote_apply_head()
                            continue
                        raced = self.workspace.stat_fingerprint(path)
                        if raced is not None or not self.watch.commit_remote_apply(
                            apply_token, {path: None}
                        ):
                            self.watch.abort_remote_apply(apply_token)
                            self._finish_retired_delete(
                                retired,
                                path=path,
                                materialized=materialized,
                                preserve=False,
                            )
                            retired = None
                            if raced is not None:
                                if not self._defer_directory_path(path, "put"):
                                    self._stage_local_put_bounded(path)
                            self._drop_remote_apply_head()
                            continue
                        self._finish_retired_delete(
                            retired,
                            path=path,
                            materialized=materialized,
                            preserve=False,
                        )
                        retired = None
                    except RetentionCapacityUnavailable:
                        self.watch.abort_remote_apply(apply_token)
                        # No namespace mutation occurs before the reservation.
                        # Keep the authoritative delete pending and allow an
                        # unrelated path to make progress this tick.
                        self._remote_apply_queue.rotate(-1)
                        continue
                    except (InvalidTask, UnsafePath):
                        self.watch.abort_remote_apply(apply_token)
                        self._finish_retired_delete(
                            retired,
                            path=path,
                            materialized=materialized,
                            preserve=True,
                        )
                        raced = self.workspace.stat_fingerprint(path)
                        if raced is not None:
                            if not self._defer_directory_path(path, "put"):
                                self._stage_local_put_bounded(path)
                        self._drop_remote_apply_head()
                        continue
                    except BaseException:
                        self.watch.abort_remote_apply(apply_token)
                        self._finish_retired_delete(
                            retired,
                            path=path,
                            materialized=materialized,
                            preserve=True,
                        )
                        raise
                self.database.mark_materialized(
                    path,
                    state="absent",
                    clean_digest=materialized.clean_digest,
                    bytes_on_disk=0,
                    pinned=materialized.pinned,
                )
                self._prune_remote_deleted_parent_directories(path)
                self._drop_remote_apply_head()
                applied += 1
                continue
            if local is not None and self._local_matches_remote(local, remote, materialized):
                self.database.mark_materialized(
                    path,
                    state="clean",
                    clean_digest=remote.digest,
                    content_sha256=local.sha256,
                    stat_fingerprint=_fingerprint_text(local.fingerprint),
                    bytes_on_disk=local.fingerprint.size_bytes,
                    pinned=materialized.pinned,
                )
                self._drop_remote_apply_head()
                continue
            if _requires_remote_only_materialization(
                remote, materialization_ceiling=self.max_staging_bytes
            ):
                resolution = (
                    self.database.get_applying_conflict_resolution_for_path(path)
                )
                if (
                    resolution is not None
                    and resolution.phase == "applying_remote"
                    and resolution.expected_remote_digest == remote.digest
                ):
                    if self._accept_resolution_remote_only(
                        path, materialized, local, remote
                    ):
                        applied += 1
                    return applied
                if local is None:
                    self.database.mark_materialized(
                        path,
                        state="absent",
                        clean_digest=remote.digest,
                        stat_fingerprint=None,
                        bytes_on_disk=0,
                        pinned=False,
                    )
                else:
                    # A previous local working-set copy cannot be replaced by
                    # the bounded 32-GiB edge stage. Preserve those visible
                    # bytes, make the divergence explicit, and keep the wider
                    # authoritative object available through the remote index.
                    self.database.record_conflict(
                        path,
                        "remote object exceeds the bounded edge materialization protocol; local bytes retained",
                        base_digest=materialized.clean_digest,
                        local_digest=local.sha256,
                        remote_digest=remote.digest,
                        remote_generation=self._remote_generation(),
                    )
                    self.database.mark_materialized(
                        path,
                        state="conflict",
                        clean_digest=materialized.clean_digest,
                        stat_fingerprint=_fingerprint_text(local.fingerprint),
                        bytes_on_disk=local.fingerprint.size_bytes,
                        pinned=True,
                    )
                self._drop_remote_apply_head()
                continue
            try:
                head = self.database.get_remote_manifest_head()
                if head is None:
                    raise StateError("The remote Fabric head disappeared during apply.")
                # The byte lane owns one queue head and one <=4-block step.
                # It may consume one signed manifest-block or read-ticket call,
                # then returns immediately while direct bytes/fsync/publish run
                # on daemon workers.
                applied += self._advance_remote_transfer(
                    path, materialized, remote, head
                )
                if (
                    self._remote_transfer is not None
                    or (
                        self._remote_apply_queue
                        and self._remote_apply_queue[0] == path
                    )
                ):
                    return applied
                continue
            except RemoteError as error:
                if _is_remote_head_stale(error):
                    self._reset_stale_remote_hydration(path)
                    return applied
                if _is_remote_content_missing(error):
                    # Preserve the durable intent and let another path become
                    # the next bounded attempt after authority-wide backoff.
                    self._remote_apply_queue.rotate(-1)
                    raise
                if _is_transient_remote_error(error):
                    raise
                self._record_remote_apply_conflict(path, materialized, str(error))
                self._drop_remote_apply_head()
            except (FabricCacheError, NetworkError, OSError, StagingQuotaExceeded):
                raise
            except (InvalidTask, StateError, UnsafePath, ValueError) as error:
                self._record_remote_apply_conflict(path, materialized, str(error))
                self._drop_remote_apply_head()
        return applied

    def _accept_resolution_remote_only(
        self,
        path: str,
        materialized: MaterializedEntry,
        local: HashedRegularFile | None,
        remote: RemoteEntry,
    ) -> bool:
        """Retire an exact rejected loser for an explicitly accepted remote-only file."""

        if local is not None:
            apply_token = self.watch.arm_remote_apply(path)
            retired: RetiredRegularFile | None = None
            apply_resolved = False
            try:
                retired = self.workspace.retire_file(
                    path,
                    require_retention_capacity=True,
                    expected_file=local,
                )
                if retired is None:
                    raise InvalidTask(
                        "The local conflict file disappeared before remote-only acceptance."
                    )
                if (
                    retired.initial.sha256 != local.sha256
                    or retired.initial.fingerprint.device_id
                    != local.fingerprint.device_id
                    or retired.initial.fingerprint.file_id
                    != local.fingerprint.file_id
                ):
                    self._finish_retired_delete(
                        retired,
                        path=path,
                        materialized=materialized,
                        preserve=True,
                    )
                    retired = None
                    self.watch.abort_remote_apply(apply_token)
                    apply_resolved = True
                    self._drop_remote_apply_head()
                    return False
                raced = self.workspace.stat_fingerprint(path)
                if raced is not None or not self.watch.commit_remote_apply(
                    apply_token, {path: None}
                ):
                    self.watch.abort_remote_apply(apply_token)
                    apply_resolved = True
                    self._finish_retired_delete(
                        retired,
                        path=path,
                        materialized=materialized,
                        preserve=False,
                    )
                    retired = None
                    if raced is not None:
                        self._stage_local_put_bounded(path)
                    self._drop_remote_apply_head()
                    return False
                apply_resolved = True
                self._finish_retired_delete(
                    retired,
                    path=path,
                    materialized=materialized,
                    preserve=False,
                )
                retired = None
            except BaseException:
                if not apply_resolved:
                    self.watch.abort_remote_apply(apply_token)
                if retired is not None:
                    self.workspace.finish_retired_file(retired, preserve=True)
                raise
        self.database.mark_materialized(
            path,
            state="absent",
            clean_digest=remote.digest,
            bytes_on_disk=0,
            pinned=False,
        )
        self._drop_remote_apply_head()
        return True

    def _finish_retired_delete(
        self,
        retired: RetiredRegularFile | None,
        *,
        path: str,
        materialized: MaterializedEntry,
        preserve: bool,
    ) -> None:
        if retired is None:
            return
        preserved_path = self._finish_retired_with_mount_fence(
            retired,
            preserve=preserve,
        )
        if preserved_path is None:
            return
        fingerprint = self.workspace.stat_fingerprint(preserved_path)
        local = (
            self._hash_regular_file(preserved_path)
            if fingerprint is not None
            and fingerprint.size_bytes <= BACKGROUND_TRANSFER_THRESHOLD_BYTES
            else None
        )
        self.database.record_conflict(
            path,
            "local bytes changed through an open handle during remote delete",
            base_digest=materialized.clean_digest,
            local_digest=local.sha256 if local else None,
            remote_digest=None,
            remote_generation=self._remote_generation(),
        )
        if fingerprint is not None:
            self._stage_local_put_bounded(preserved_path)

    def _queue_remote_destination(
        self, path: str, *, digest: str, size: int, pinned: bool
    ) -> None:
        self.database.mark_materialized(
            path,
            state="clean",
            clean_digest=digest,
            bytes_on_disk=0,
            pinned=pinned,
            queue_remote_apply=True,
        )
        self._queue_remote_applies((path,))

    def _queue_current_remote_destination(
        self,
        path: str,
        remote: RemoteEntry | None,
        *,
        pinned: bool,
    ) -> None:
        """Preserve a local destination while retiring a stale rename intent."""

        local = self._hash_regular_file(path)
        if remote is None:
            if local is not None:
                self._stage_local_put_bounded(path)
            elif self.database.get_materialized(path) is not None:
                self._queue_remote_applies((path,))
            return
        if local is None:
            self._queue_remote_destination(
                path, digest=remote.digest, size=remote.size_bytes, pinned=pinned
            )
            return
        if self._local_matches_remote(local, remote, self.database.get_materialized(path)):
            self.database.mark_materialized(
                path,
                state="clean",
                clean_digest=remote.digest,
                stat_fingerprint=_fingerprint_text(local.fingerprint),
                content_sha256=local.sha256,
                bytes_on_disk=local.fingerprint.size_bytes,
                pinned=pinned,
            )
            return
        self.database.record_conflict(
            path,
            "stale remote rename destination advanced before local apply",
            local_digest=local.sha256,
            remote_digest=remote.digest,
            remote_generation=self._remote_generation(),
        )
        self._stage_local_put_bounded(path)

    def _preserve_remote_rename_race(
        self, source: str, destination: str, *, digest: str, size: int, pinned: bool
    ) -> None:
        current_source = self._hash_regular_file(source)
        if current_source is not None:
            self._stage_local_put_bounded(source)
        else:
            self.database.mark_materialized(
                source,
                state="absent",
                clean_digest=digest,
                bytes_on_disk=0,
                pinned=False,
            )
        current_destination = self._hash_regular_file(destination)
        remote_destination = self.database.get_remote_entry(destination)
        if current_destination is None:
            self._queue_remote_destination(
                destination, digest=digest, size=size, pinned=pinned
            )
        elif (remote_destination is not None and remote_destination.digest == digest
              and self._local_matches_remote(current_destination, remote_destination,
                                             self.database.get_materialized(destination))):
            self.database.mark_materialized(
                destination,
                state="clean",
                clean_digest=digest,
                stat_fingerprint=_fingerprint_text(current_destination.fingerprint),
                content_sha256=current_destination.sha256,
                bytes_on_disk=current_destination.fingerprint.size_bytes,
                pinned=pinned,
            )
        else:
            self.database.record_conflict(
                destination,
                "remote rename destination raced a local edit",
                local_digest=current_destination.sha256,
                remote_digest=digest,
                remote_generation=self._remote_generation(),
            )
            self.database.mark_materialized(
                destination,
                state="conflict",
                clean_digest=(self.database.get_materialized(destination).clean_digest if self.database.get_materialized(destination) else None),
                stat_fingerprint=_fingerprint_text(current_destination.fingerprint),
                bytes_on_disk=current_destination.fingerprint.size_bytes,
                pinned=True,
            )

    def _record_remote_apply_conflict(
        self, path: str, materialized: Any, reason: str
    ) -> None:
        remote = self.database.get_remote_entry(path)
        local = self._hash_regular_file(path)
        self.database.record_conflict(
            path,
            f"remote apply cannot continue safely: {reason}",
            base_digest=materialized.clean_digest,
            local_digest=local.sha256 if local else None,
            remote_digest=remote.digest if remote else None,
            remote_generation=self._remote_generation(),
        )
        self.database.mark_materialized(
            path,
            state="conflict",
            clean_digest=materialized.clean_digest,
            stat_fingerprint=(_fingerprint_text(local.fingerprint) if local else None),
            bytes_on_disk=(local.fingerprint.size_bytes if local else 0),
            pinned=True,
        )

    def maintain_materialized_cache(self, *, force: bool = False) -> int:
        """Run one proactive cache pass: low-water reclaim plus an idle sweep.

        This is the background half of the policy. Eviction used to happen only
        when a reservation was about to fail, so a device could sit at 100% of
        its budget indefinitely and every hydration paid a synchronous eviction
        first. Here the cadence, the low-water mark and the idle age all come
        from the current free-space tier, so a filling disk cleans itself up
        ahead of the pressure instead of behind it.
        """

        policy = self.cache_policy()
        if not policy.enforced:
            return 0
        now = float(self._clock())
        if not force and now < self._next_cache_maintenance:
            return 0
        self._next_cache_maintenance = now + policy.maintenance_interval_seconds
        freed = self._evict_materialized_working_set(
            policy=policy, low_water=True
        )
        if policy.idle_evict_seconds is not None:
            freed += self._evict_idle_materialized_entries(policy)
        return freed

    def _evict_idle_materialized_entries(
        self, policy: MaterializedCachePolicy
    ) -> int:
        """Reclaim clean, re-fetchable content nothing has opened in a while.

        Recency here is recency of ACCESS: ``note_materialized_access`` stamps
        every mount open, so a file that is read often survives even if it was
        written long ago, and a file written once and never read again does
        not.
        """

        idle_seconds = policy.idle_evict_seconds
        if idle_seconds is None:
            return 0
        cutoff = self._wall_now_ns() - int(idle_seconds * 1_000_000_000)
        if cutoff <= 0:
            cutoff = self._wall_now_ns() if idle_seconds == 0 else 0
        if cutoff <= 0:
            return 0
        candidates = self.database.free_candidates(
            limit=MAX_IDLE_EVICTIONS_PER_PASS,
            not_accessed_since_ns=cutoff,
            exclude_paths=self._eviction_exclusions(None),
        )
        if not candidates:
            return 0
        return self._evict_candidates(candidates, budget=None)

    def _eviction_exclusions(self, exclude_path: str | None) -> list[str]:
        active_transfer = self._remote_transfer
        return [
            path
            for path in (
                active_transfer.path if active_transfer is not None else None,
                exclude_path,
            )
            if path is not None
        ]

    def _evict_materialized_working_set(
        self,
        *,
        policy: MaterializedCachePolicy | None = None,
        bytes_needed: int = 0,
        exclude_path: str | None = None,
        low_water: bool = False,
    ) -> int:
        """Reclaim least-recently-accessed re-fetchable materialized content.

        ``bytes_needed`` is additional headroom an admission check needs on top
        of repairing existing over-budget pressure. ``exclude_path`` is the
        destination that admission is about to write, which must never be
        evicted to make room for itself. ``low_water`` reclaims past the limit
        down to the tier's low-water mark so the next writes do not each pay
        for their own eviction.
        """

        if (
            isinstance(bytes_needed, bool)
            or not isinstance(bytes_needed, int)
            or bytes_needed < 0
        ):
            raise ValueError("bytes_needed must be a non-negative integer")
        if policy is None:
            policy = self.cache_policy()
        # ``enforced`` gates ADMISSION, not reclamation: a pinned budget of
        # zero has always meant "hold no cache", and that stays true here.
        usage = self._materialized_storage_bytes()
        ceiling = policy.limit_bytes
        target = policy.low_water_bytes if low_water else ceiling
        excess = bytes_needed
        if usage > ceiling:
            excess += usage - target
        if excess <= 0:
            return 0
        if any(
            self.workspace.has_retained_retirement(intent.path)
            for intent in self.database.list_eviction_intents(limit=10_000)
        ):
            # A retained eviction has hidden a clean inode but reclaimed no
            # physical storage. Do not begin a fresh wave on each poll and
            # accumulate hidden owners while pressure remains unchanged.
            # Recovery/promotion runs earlier in the poll and releases this
            # gate only after exact reclaim or preservation resolves the intent.
            return 0
        candidates = self.database.free_candidates(
            bytes_needed=excess,
            exclude_paths=self._eviction_exclusions(exclude_path),
        )
        if not candidates:
            # Over budget with nothing reclaimable is a state an operator has
            # to be able to see, because the usual cause is content whose
            # re-fetchability is unproven rather than genuine dirty data.
            held_rows, held_bytes = self.database.unproven_materialized_summary()
            if held_rows and not self._unproven_cache_reported:
                self._unproven_cache_reported = True
                self.logger.record(
                    "fabric_cache_unreclaimable",
                    excess_bytes=excess,
                    unproven_rows=held_rows,
                    unproven_bytes=held_bytes,
                )
            return 0
        self._unproven_cache_reported = False
        return self._evict_candidates(candidates, budget=excess)

    def _evict_candidates(
        self,
        candidates: Sequence[MaterializedEntry],
        *,
        budget: int | None,
    ) -> int:
        """Reclaim an already-selected, already-safety-filtered candidate page.

        Every candidate reaching here has been proven clean, unpinned and
        backed by a remote entry at its exact digest (see
        ``FabricDatabase.free_candidates``); this method re-proves the local
        bytes immediately before it takes each durable eviction intent.
        """

        freed = 0
        for candidate in candidates:
            if self.database.has_remote_apply_intent(candidate.path):
                # The durable apply row and in-memory transfer jointly own the
                # old visible preimage until publish/cleanup completes. Evicting
                # it would make the apply lane drop its intent as remote-only
                # while leaving the transfer permanently orphaned. The indexed
                # candidate query excludes both owners; this recheck closes a
                # concurrent intent insertion before namespace mutation.
                continue
            local = self._observe_clean_file_without_rehash(
                candidate.path,
                content_sha256=candidate.content_sha256,
                stat_fingerprint=candidate.stat_fingerprint,
            )
            if local is None:
                # A clean row missing without a pre-existing eviction intent is
                # ambiguous: it can be a user delete. Recovery, not eviction,
                # will journal it on the next bounded namespace scan.
                continue
            if local.sha256 != candidate.content_sha256:
                self._stage_local_put_bounded(candidate.path)
                continue
            fingerprint = _fingerprint_text(local.fingerprint)
            intent = self.database.begin_eviction(
                candidate.path,
                observed_clean_digest=candidate.clean_digest,
                observed_content_sha256=local.sha256,
                observed_stat_fingerprint=fingerprint,
                observed_bytes=local.fingerprint.size_bytes,
            )
            if intent is None:
                # The DB observation or stat fingerprint changed after the LRU
                # query. Refresh the clean hint and defer; never delete through
                # a lost compare-and-swap.
                refreshed = self.workspace.hash_regular_file(candidate.path)
                if refreshed is not None and refreshed.sha256 == candidate.content_sha256:
                    self.database.mark_materialized(
                        candidate.path,
                        state="clean",
                        clean_digest=candidate.clean_digest,
                        content_sha256=refreshed.sha256,
                        stat_fingerprint=_fingerprint_text(refreshed.fingerprint),
                        bytes_on_disk=refreshed.fingerprint.size_bytes,
                        pinned=candidate.pinned,
                        accessed_at_ns=candidate.accessed_at_ns,
                    )
                continue
            # Reuse the stable hash that established the durable intent. The
            # guarded remover performs the required second, immediately-before-
            # unlink verification; a redundant third full-file read would add
            # eviction latency and compute without closing another race.
            reclaimed = self._finish_eviction(intent, observed_local=local)
            freed += reclaimed
            if reclaimed == 0 and self.workspace.has_retained_retirement(
                candidate.path
            ):
                # Hiding another healthy cache entry cannot satisfy pressure:
                # this process has no authority to release even the first
                # allocation yet. Wait for mount RELEASE/recovery proof instead
                # of converting the rest of the working set into hidden owners.
                break
            if budget is not None and freed >= budget:
                break
        return freed

    def _recover_evictions(self) -> int:
        recovered = 0
        for intent in self.database.list_eviction_intents(limit=10_000):
            recovered += self._finish_eviction(intent)
        return recovered

    def _finish_eviction(
        self,
        intent: EvictionIntent,
        *,
        observed_local: HashedRegularFile | None = None,
    ) -> int:
        """Resume or finish one exact eviction intent without losing edits."""

        local = (
            observed_local
            if observed_local is not None
            else self._observe_clean_file_without_rehash(
                intent.path,
                content_sha256=intent.expected_content_sha256,
                stat_fingerprint=intent.expected_stat_fingerprint,
            )
        )
        if local is None:
            if self.workspace.has_retained_retirement(intent.path):
                # A mounted or untracked writer may still own the hidden inode.
                # Keep the durable eviction intent pending: no physical bytes
                # were freed, and reporting expected_bytes would let the cache
                # admission loop overcommit the workspace volume.
                return 0
            if self.workspace.retire_recovery_blocked(intent.path):
                # Startup found an owned-looking retire marker for this exact
                # path but could not prove it abandoned (live/reused PID,
                # malformed metadata, or inaccessible marker).  The hidden
                # inode may still contain user bytes, so absence is not a safe
                # eviction receipt and the durable intent remains pending.
                return 0
            if getattr(self.workspace, "stream_recovery_pending", False):
                return 0
            # A prior process may have crashed after unlink and before the DB
            # transition. Verify the exact absent post-state before retiring
            # any delayed watcher echo. If the watcher is overflowed or its
            # bounded token table is busy, retain the durable intent and retry
            # after recovery instead of weakening this observation boundary.
            try:
                apply_token = self.watch.arm_remote_apply(intent.path)
            except RuntimeError:
                return 0
            apply_resolved = False
            try:
                watcher_verified = self.watch.commit_remote_apply(
                    apply_token, {intent.path: None}
                )
                apply_resolved = True
                if not watcher_verified:
                    self._startup_reconcile = True
                self.database.complete_eviction(intent.eviction_id)
            finally:
                if not apply_resolved:
                    self.watch.abort_remote_apply(apply_token)
            return intent.expected_bytes

        observed_fingerprint = _fingerprint_text(local.fingerprint)
        if (
            local.sha256 != intent.expected_content_sha256
            or observed_fingerprint != intent.expected_stat_fingerprint
        ):
            self.database.cancel_eviction(intent.eviction_id)
            if local.sha256 == intent.expected_content_sha256:
                # Metadata/identity changed but bytes did not. Preserve the file
                # and refresh its hint; a later LRU pass may reconsider it.
                current = self.database.get_materialized(intent.path)
                self.database.mark_materialized(
                    intent.path,
                    state="clean",
                    clean_digest=intent.expected_clean_digest,
                    content_sha256=local.sha256,
                    stat_fingerprint=observed_fingerprint,
                    bytes_on_disk=local.fingerprint.size_bytes,
                    pinned=current.pinned if current else False,
                    accessed_at_ns=current.accessed_at_ns if current else None,
                )
            else:
                # A content edit won the race. Snapshot and journal it before
                # any future remote work rather than discarding user bytes.
                self._stage_local_put_bounded(intent.path)
            return 0

        try:
            apply_token = self.watch.arm_remote_apply(intent.path)
        except RuntimeError:
            # A committed watcher transaction or overflow can temporarily own
            # the path. Keep the durable eviction intent and retry only after
            # that exact observation boundary has cleared.
            return 0
        apply_resolved = False
        retired: RetiredRegularFile | None = None
        try:
            # Atomically move the exact namespace entry behind a durable marker.
            # Keeping that inode linked until watcher commit lets us detect and
            # preserve writes through an already-open descriptor instead of
            # deleting them through a hash-then-unlink race.
            retired = self.workspace.retire_file(
                intent.path,
                require_retention_capacity=True,
                expected_file=local,
                accounting_owner=RETAINED_STORAGE_ACCOUNT_MATERIALIZED_ROW,
            )
            if retired is None:
                watcher_verified = self.watch.commit_remote_apply(
                    apply_token, {intent.path: None}
                )
                apply_resolved = True
                if not watcher_verified:
                    self._startup_reconcile = True
                self.database.complete_eviction(intent.eviction_id)
                return intent.expected_bytes
            if (
                retired.initial.sha256 != local.sha256
                or retired.initial.fingerprint.device_id
                != local.fingerprint.device_id
                or retired.initial.fingerprint.file_id != local.fingerprint.file_id
            ):
                self.watch.abort_remote_apply(apply_token)
                apply_resolved = True
                preserved = self.workspace.finish_retired_file(
                    retired, preserve=True
                )
                retired = None
                self._cancel_eviction_preserving_local(
                    intent, preserved, intent.path
                )
                return 0

            recreated = self.workspace.stat_fingerprint(intent.path)
            if recreated is not None:
                self.watch.abort_remote_apply(apply_token)
                apply_resolved = True
                preserved = self._finish_retired_with_mount_fence(
                    retired,
                    preserve=False,
                )
                retired = None
                self._cancel_eviction_preserving_local(
                    intent, preserved, intent.path
                )
                return 0

            watcher_verified = self.watch.commit_remote_apply(
                apply_token, {intent.path: None}
            )
            apply_resolved = True
            if not watcher_verified:
                self._startup_reconcile = True

            preserved = self._finish_retired_with_mount_fence(
                retired,
                preserve=False,
            )
            retired = None
            if preserved is not None:
                # An already-open writer changed the retired inode while the
                # namespace deletion was in flight. It has been restored (or
                # placed at a visible conflict path); journal it synchronously.
                survivor_fingerprint = self.workspace.stat_fingerprint(preserved)
                survivor = (
                    self._hash_regular_file(preserved)
                    if survivor_fingerprint is not None
                    and survivor_fingerprint.size_bytes
                    <= BACKGROUND_TRANSFER_THRESHOLD_BYTES
                    else None
                )
                self.database.record_conflict(
                    intent.path,
                    "local bytes changed through an open handle during eviction",
                    base_digest=intent.expected_clean_digest,
                    local_digest=(
                        survivor.sha256
                        if survivor
                        else None
                    ),
                    remote_digest=intent.expected_clean_digest,
                    remote_generation=self._remote_generation(),
                )
                self._cancel_eviction_preserving_local(
                    intent, preserved, intent.path
                )
                return 0

            if self.workspace.has_retained_retirement(intent.path):
                recreated = self.workspace.stat_fingerprint(intent.path)
                if recreated is not None:
                    # A new visible file won after the watcher delete boundary.
                    # The hidden clean preimage remains separately accounted;
                    # cancel eviction and journal only the newly visible bytes.
                    self._cancel_eviction_preserving_local(
                        intent, None, intent.path
                    )
                    return 0
                # The namespace is absent, but the old allocation remains
                # privately owned until a mount fence proves all handles closed
                # (or maintenance promotes a late write). Keep the intent as the
                # durable retry owner and report zero reclaimed bytes.
                return 0

            # The path is absent and the durable intent proves why. Completing
            # is safe whether our unlink or a concurrent delete won the race.
            self.database.complete_eviction(intent.eviction_id)
            recreated = self.workspace.hash_regular_file(intent.path)
            if recreated is not None:
                self._stage_local_put_bounded(intent.path)
                return 0
            return intent.expected_bytes
        except (InvalidTask, UnsafePath):
            if not apply_resolved:
                self.watch.abort_remote_apply(apply_token)
                apply_resolved = True
            preserved: str | None = None
            if retired is not None:
                preserved = self.workspace.finish_retired_file(
                    retired, preserve=True
                )
                retired = None
            self._cancel_eviction_preserving_local(
                intent, preserved, intent.path
            )
            return 0
        except BaseException:
            if not apply_resolved:
                self.watch.abort_remote_apply(apply_token)
                apply_resolved = True
            if retired is not None:
                # Best effort keeps captured user bytes visible; the durable
                # retire marker remains recoverable if this itself fails.
                self.workspace.finish_retired_file(retired, preserve=True)
            raise
        finally:
            if not apply_resolved:
                self.watch.abort_remote_apply(apply_token)

    def _cancel_eviction_preserving_local(
        self,
        intent: EvictionIntent,
        *candidate_paths: str | None,
    ) -> None:
        """Cancel an eviction and durably classify every surviving local file."""

        self.database.cancel_eviction(intent.eviction_id)
        current = self.database.get_materialized(intent.path)
        seen: set[str] = set()
        for path in candidate_paths:
            if path is None or path in seen:
                continue
            seen.add(path)
            fingerprint = self.workspace.stat_fingerprint(path)
            if fingerprint is None:
                continue
            if fingerprint.size_bytes > BACKGROUND_TRANSFER_THRESHOLD_BYTES:
                self._stage_local_put_bounded(path)
                continue
            local = self._hash_regular_file(path)
            if local is None:
                continue
            if path == intent.path and local.sha256 == intent.expected_content_sha256:
                # A same-content replacement is still a clean cache copy. Keep
                # its new exact fingerprint without manufacturing an upload.
                self.database.mark_materialized(
                    path,
                    state="clean",
                    clean_digest=intent.expected_clean_digest,
                    content_sha256=local.sha256,
                    stat_fingerprint=_fingerprint_text(local.fingerprint),
                    bytes_on_disk=local.fingerprint.size_bytes,
                    pinned=current.pinned if current else False,
                    accessed_at_ns=current.accessed_at_ns if current else None,
                )
            else:
                self._stage_local_put_bounded(path)

    def _cleanup_acked_stages(self) -> None:
        self._cleanup_inactive_stages()
        self._cleanup_resolved_conflict_stages()
        self._cleanup_resolved_standalone_conflict_stages()
        self._compact_inactive_authorities()
        prunable: list[str] = []
        changed = False
        operations = self.database.list_acked_operations_for_cleanup(
            limit=ACKED_STAGE_CLEANUP_BATCH,
            after=self._acked_cleanup_cursor,
        )
        if not operations:
            # Wrap only after reaching the end. Rows whose files were unsafe to
            # remove are retried on a later cycle without pinning every newer
            # acknowledged operation behind the oldest page.
            self._acked_cleanup_cursor = None
            return
        last = operations[-1]
        self._acked_cleanup_cursor = (
            (last.created_at_ns, last.mutation_id)
            if len(operations) == ACKED_STAGE_CLEANUP_BATCH
            else None
        )
        for operation in operations:
            if self._file_provider_receipt_is_held(operation.mutation_id):
                continue
            callback_marker = (
                _file_provider_callback_path(Path(operation.staged_path))
                if operation.staged_path is not None
                else None
            )
            if (
                callback_marker is not None
                and callback_marker.exists()
                and self._file_provider_callback_result_is_current(operation)
            ):
                self._compact_file_provider_callback_stage(
                    Path(operation.staged_path), callback_marker
                )
                continue
            if (
                operation.staged_path is not None
                and callback_marker is not None
                and callback_marker.exists()
            ):
                try:
                    callback_marker.unlink()
                    changed = True
                except FileNotFoundError:
                    pass
            stages = {
                Path(stage.staged_path)
                for stage in self.database.list_operation_stages(operation.mutation_id)
            }
            if operation.staged_path is not None:
                stages.add(Path(operation.staged_path))
            complete = True
            for stage in sorted(stages, key=str):
                if self.database.stage_path_has_external_reference(
                    stage, excluding_mutation_id=operation.mutation_id
                ):
                    # This acknowledged operation can retire its own metadata,
                    # but another operation/conflict still owns the bytes.
                    continue
                family_complete, family_changed = self._remove_stage_family(stage)
                complete = complete and family_complete
                changed = changed or family_changed
            if complete:
                if operation.staged_digest is not None:
                    self.cache.unpin_owner(
                        f"operation:{operation.mutation_id}",
                        operation.staged_digest,
                    )
                prunable.append(operation.mutation_id)
        if changed:
            _fsync_dir(self.staging_root)
        if prunable:
            self.database.prune_acked_operations(prunable)

    def _file_provider_callback_result_is_current(
        self, operation: PendingOperation
    ) -> bool:
        """Whether an exact native write retry must still replay its ACK."""

        if operation.staged_path is None:
            return False
        marker = _file_provider_callback_path(Path(operation.staged_path))
        try:
            encoded, _info = _read_bounded_regular_file(
                marker, FILE_PROVIDER_CALLBACK_MAX_BYTES
            )
            document = json.loads(encoded.decode("utf-8"))
        except (OSError, UnicodeDecodeError, ValueError):
            # Legacy zero-byte markers and damaged metadata are retained rather
            # than risking a false stale-base conflict after callback loss.
            return True
        if operation.kind == "delete":
            # Compound File Provider saves persist their dependent source
            # delete against the same marker as the destination put.  Cleanup
            # visits operations in journal order, so the parent removes the
            # marker only after its exact result stops being current; the next
            # bounded cleanup pass can then prune this dependent receipt too.
            matches_dependency = (
                isinstance(document, Mapping)
                and document.get("version") == 1
                and document.get("delete_after_ack_path") == operation.path
                and document.get("delete_after_ack_mutation_id")
                == operation.mutation_id
            )
            # A mismatched/corrupt shared marker is also retained. The parent
            # PUT owns the decision to remove this one marker; letting a
            # dependent row unlink it first would re-open the callback-loss
            # window solely because cleanup page/order changed.
            return matches_dependency or marker.exists()
        if operation.kind != "put":
            return False
        if (
            not isinstance(document, Mapping)
            or document.get("version") != 1
            or document.get("path") != operation.path
            or document.get("sha256") != operation.staged_digest
            or document.get("size_bytes") != operation.staged_size
        ):
            return True

        if self.database.has_later_receipted_operation(
            operation.path, operation.journal_seq
        ):
            # This test is independent of v1 manifest projection and the v2
            # read-your-write overlay.  A later exact receipt is sufficient to
            # bound old callback records immediately, even for identical bytes.
            return False

        latest = self.database.get_receipted_entry(operation.path)
        if latest is not None:
            # A later exact mutation on this path supersedes this callback even
            # when it happens to write identical bytes.
            return latest.mutation_id == operation.mutation_id
        receipt = self.database.get_receipt(operation.mutation_id)
        head = self.database.get_remote_manifest_head()
        if (
            receipt is not None
            and head is not None
            and receipt.remote_generation is not None
            and receipt.remote_generation > head.generation
        ):
            return True
        current = self.database.get_remote_entry(operation.path)
        if (
            current is None
            or current.digest != operation.staged_digest
            or current.size_bytes != operation.staged_size
        ):
            return False
        expected_modified = document.get("modified_at")
        if expected_modified is None:
            # Legacy marker: content identity is the strongest available fence.
            # A newer local receipt above still supersedes it immediately.
            return True
        try:
            return _normalized_modified_at(current.modified) == _normalized_modified_at(
                expected_modified
            )
        except ValueError:
            return True

    def _compact_file_provider_callback_stage(
        self, stage: Path, marker: Path
    ) -> None:
        """Drop bulky upload journals while retaining one tiny replay marker."""

        changed = False
        for candidate in (stage, _plan_path(stage), _progress_path(stage)):
            try:
                info = candidate.lstat()
            except FileNotFoundError:
                continue
            except OSError:
                return
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                return
            try:
                candidate.unlink()
                changed = True
            except FileNotFoundError:
                pass
            except OSError:
                return
        if changed and marker.exists():
            _fsync_dir(self.staging_root)

    def _cleanup_resolved_conflict_stages(self) -> None:
        """Reclaim one bounded page of fully resolved operation evidence."""

        operations = self.database.list_resolved_conflict_operations_for_cleanup(
            limit=ACKED_STAGE_CLEANUP_BATCH,
            after=self._resolved_conflict_cleanup_cursor,
        )
        if not operations:
            self._resolved_conflict_cleanup_cursor = None
            return
        last = operations[-1]
        self._resolved_conflict_cleanup_cursor = (
            (last.created_at_ns, last.mutation_id)
            if len(operations) == ACKED_STAGE_CLEANUP_BATCH
            else None
        )
        finalizable: list[str] = []
        changed = False
        for operation in operations:
            stages = {
                Path(stage.staged_path)
                for stage in self.database.list_operation_stages(
                    operation.mutation_id
                )
            }
            if operation.staged_path is not None:
                stages.add(Path(operation.staged_path))
            complete = True
            for stage in sorted(stages, key=str):
                if self.database.stage_path_has_external_reference(
                    stage, excluding_mutation_id=operation.mutation_id
                ):
                    continue
                family_complete, family_changed = self._remove_stage_family(stage)
                complete = complete and family_complete
                changed = changed or family_changed
            if complete:
                if operation.staged_digest is not None:
                    try:
                        self.cache.unpin_owner(
                            f"operation:{operation.mutation_id}",
                            operation.staged_digest,
                        )
                    except (OSError, FabricCacheError) as error:
                        self.logger.record(
                            "fabric_resolved_conflict_cache_cleanup_deferred",
                            mutation_id=operation.mutation_id,
                            error=str(error),
                        )
                finalizable.append(operation.mutation_id)
        if changed:
            _fsync_dir(self.staging_root)
        if finalizable:
            self.database.finalize_resolved_conflict_cleanup(finalizable)

    def _cleanup_resolved_standalone_conflict_stages(self) -> None:
        conflicts = self.database.list_resolved_standalone_conflicts_for_cleanup(
            limit=ACKED_STAGE_CLEANUP_BATCH,
            after_conflict_id=self._standalone_conflict_cleanup_cursor,
        )
        if not conflicts:
            self._standalone_conflict_cleanup_cursor = 0
            return
        self._standalone_conflict_cleanup_cursor = (
            conflicts[-1].conflict_id
            if len(conflicts) == ACKED_STAGE_CLEANUP_BATCH
            else 0
        )
        finalizable: list[int] = []
        changed = False
        for conflict in conflicts:
            assert conflict.staged_path is not None
            stage = Path(conflict.staged_path)
            referenced = self.database.referenced_stage_paths((stage,))
            if str(stage.expanduser().resolve(strict=False)) in referenced:
                # Another durable owner is sufficient; detach this resolved
                # standalone row without deleting shared bytes.
                finalizable.append(conflict.conflict_id)
                continue
            complete, family_changed = self._remove_stage_family(stage)
            changed = changed or family_changed
            if complete:
                finalizable.append(conflict.conflict_id)
        if changed:
            _fsync_dir(self.staging_root)
        if finalizable:
            self.database.finalize_resolved_standalone_conflict_cleanup(
                finalizable
            )

    def _compact_inactive_authorities(self) -> None:
        page = self.database.compact_inactive_authorities(
            limit=16,
            after_scope_id=self._inactive_authority_compaction_cursor,
        )
        self._inactive_authority_compaction_cursor = (
            page.next_after_scope_id or 0
        )

    def _cleanup_inactive_stages(self) -> None:
        """Boundedly reclaim coalesced stages before their operation is sent."""

        stages = self.database.list_inactive_operation_stages(
            limit=ACKED_STAGE_CLEANUP_BATCH,
            after_stage_id=self._inactive_stage_cleanup_cursor,
        )
        if not stages:
            self._inactive_stage_cleanup_cursor = 0
            return
        self._inactive_stage_cleanup_cursor = (
            stages[-1].stage_id
            if len(stages) == ACKED_STAGE_CLEANUP_BATCH
            else 0
        )
        prunable: list[int] = []
        changed = False
        for stage in stages:
            complete, family_changed = self._remove_stage_family(
                Path(stage.staged_path)
            )
            changed = changed or family_changed
            if complete:
                # Coalescing keeps one stable mutation id while replacing its
                # immutable stage.  Each staged digest was pinned under that
                # owner when captured; once the superseded stage family is
                # gone, release its cache lease unless the active successor
                # still uses the same digest.
                active_digests = {
                    candidate.staged_digest
                    for candidate in self.database.list_operation_stages(
                        stage.mutation_id
                    )
                    if candidate.active
                }
                if stage.staged_digest not in active_digests:
                    self.cache.unpin_owner(
                        f"operation:{stage.mutation_id}", stage.staged_digest
                    )
                prunable.append(stage.stage_id)
        if changed:
            _fsync_dir(self.staging_root)
        if prunable:
            self.database.prune_inactive_operation_stages(prunable)

    def _remove_stage_family(self, stage: Path) -> tuple[bool, bool]:
        """Remove one private stage family, returning (complete, changed)."""

        if self._is_transfer_stage_path(stage):
            if not stage.exists() and not _plan_path(stage).exists() and not _progress_path(stage).exists():
                return True, False
            try:
                raw = json.loads(_plan_path(stage).read_text(encoding="utf-8"))
                logical_path = raw.get("transfer_logical_path")
                token = raw.get("transfer_token")
                if (
                    not isinstance(logical_path, str)
                    or not isinstance(token, str)
                    or re.fullmatch(r"[a-f0-9]{32}", token) is None
                ):
                    return False, False
                cleanup_key = str(stage)
                pending = self._stage_cleanup_futures.get(cleanup_key)
                if pending is not None:
                    if not pending.done():
                        return False, False
                    self._stage_cleanup_futures.pop(cleanup_key, None)
                    job = pending.result()
                else:
                    try:
                        job = self._transfer_store.open(
                            logical_path, max_sync_verify_bytes=0
                        )
                    except RecoveryDeferred:
                        try:
                            pending = self._transfer_store.open_async(logical_path)
                        except TransferBusy:
                            return False, False
                        self._stage_cleanup_futures[cleanup_key] = pending
                        pending.add_done_callback(lambda _future: self.wake())
                        return False, False
                verified = job.verified_stage()
                if (
                    verified.path.resolve(strict=True) != stage.resolve(strict=True)
                    or verified.token != token
                ):
                    return False, False
                state = job.progress.get("state")
                if state == "ready":
                    self._transfer_store.claim_ready(logical_path, token)
                elif state != "leased":
                    return False, False
                self._transfer_store.consume_ready(logical_path, token)
                return True, True
            except (OSError, ValueError, TransferError):
                return False, False
        if not self._owned_stage_path(stage):
            return False, False
        complete = True
        changed = False
        for candidate in (
            stage,
            _plan_path(stage),
            _progress_path(stage),
            _file_provider_callback_path(stage),
        ):
            try:
                info = candidate.lstat()
            except FileNotFoundError:
                continue
            except OSError:
                complete = False
                continue
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                complete = False
                continue
            try:
                candidate.unlink()
                changed = True
            except FileNotFoundError:
                continue
            except OSError:
                complete = False
        if complete:
            self._release_classic_stage(stage)
        return complete, changed

    def _scavenge_unjournaled_stages(self) -> int:
        """Boundedly remove old private stage artifacts with no journal owner."""

        now = time.time()
        removed = 0
        candidates: list[tuple[Path, str, bool]] = []
        try:
            # Iterate lazily: a corrupted or adversarial directory must not
            # defeat the entry cap by first allocating/sorting every name. Keep
            # the single iterator across periodic pages so an orphan after a
            # large unrelated prefix is eventually reached without rescanning
            # or retaining the whole directory in memory.
            if self._orphan_stage_scan is None:
                self._orphan_stage_scan = iter(os.scandir(self.staging_root))
            for _ in range(ORPHAN_STAGE_SCAN_MAX_ENTRIES):
                try:
                    entry = next(self._orphan_stage_scan)
                except StopIteration:
                    self._close_orphan_stage_scan()
                    break
                match = _OWNED_STAGE_FILE_RE.fullmatch(entry.name)
                is_temporary = False
                if match is None:
                    match = _OWNED_STAGE_TEMP_RE.fullmatch(entry.name)
                    is_temporary = match is not None
                if match is None:
                    continue
                candidates.append(
                    (Path(entry.path), match.group("id"), is_temporary)
                )
        except OSError as error:
            self._close_orphan_stage_scan()
            raise StateError("The Fabric staging area cannot be scavenged safely.") from error

        # Query only the bounded UUID page we actually inspected. A long-lived
        # database may retain large conflict/quarantine histories, none of which
        # should make one startup scan allocate an unbounded reference set.
        base_paths = tuple(
            (self.staging_root / f"{stage_id}.data").expanduser().resolve(strict=False)
            for _path, stage_id, is_temporary in candidates
            if not is_temporary
        )
        referenced = self.database.referenced_stage_paths(base_paths)
        active_range_stage = (
            str(self._remote_transfer.range_stage_path.resolve(strict=False))
            if self._remote_transfer is not None
            and self._remote_transfer.range_stage_owned
            and self._remote_transfer.range_stage_path is not None
            else None
        )
        for candidate, stage_id, is_temporary in candidates:
            base_path = str(
                (self.staging_root / f"{stage_id}.data")
                .expanduser()
                .resolve(strict=False)
            )
            # Atomic-writer temporary names are never the journal payload. A
            # crash can leave one beside an otherwise live stage family, so its
            # age/ownership checks stand on their own instead of inheriting the
            # base stage's reference forever.
            if not is_temporary and (
                base_path in referenced or base_path == active_range_stage
            ):
                continue
            try:
                info = candidate.lstat()
            except FileNotFoundError:
                continue
            except OSError:
                continue
            if (
                not stat.S_ISREG(info.st_mode)
                or info.st_nlink != 1
                or now - float(info.st_mtime) < ORPHAN_STAGE_GRACE_SECONDS
            ):
                continue
            try:
                candidate.unlink()
                removed += 1
                if candidate.name == f"{stage_id}.data":
                    self._release_classic_stage(
                        self.staging_root / f"{stage_id}.data"
                    )
            except FileNotFoundError:
                continue
            except OSError:
                continue
        if removed:
            _fsync_dir(self.staging_root)
        return removed

    def _close_orphan_stage_scan(self) -> None:
        scan = self._orphan_stage_scan
        self._orphan_stage_scan = None
        close = getattr(scan, "close", None)
        if callable(close):
            close()

    def _owned_stage_path(self, stage: Path) -> bool:
        try:
            parent = stage.parent.resolve(strict=True)
            root = self.staging_root.resolve(strict=True)
        except OSError:
            return False
        return parent == root and _OWNED_STAGE_FILE_RE.fullmatch(stage.name) is not None

    def _is_transfer_stage_path(self, stage: Path) -> bool:
        if stage.name != "stage.ready":
            return False
        try:
            parent = stage.parent.resolve(strict=False)
            jobs_root = self._transfer_store.jobs_root.resolve(strict=True)
        except OSError:
            return False
        return (
            parent.parent == jobs_root
            and re.fullmatch(r"[a-f0-9]{64}", parent.name) is not None
        )


# ------------------------------------------------------------------ contracts


def _adaptive_upload_block_bytes(size_bytes: int) -> int:
    """Choose a bounded CAS extent for both manifest size and control latency."""
    try:
        return adaptive_upload_block_bytes(size_bytes)
    except ValueError:
        raise ValueError(
            f"size_bytes must be between 0 and {MAX_LOCAL_UPLOAD_FILE_BYTES}"
        ) from None


def _legacy_adaptive_upload_block_bytes(size_bytes: int) -> int:
    """Return the pre-parallel policy solely to validate durable old plans."""

    manifest_required = (
        size_bytes + MAX_MANIFEST_BLOCKS - 1
    ) // MAX_MANIFEST_BLOCKS
    latency_required = min(
        MAX_CAS_BLOCK_BYTES,
        (size_bytes + TARGET_LOCAL_UPLOAD_BLOCKS - 1)
        // TARGET_LOCAL_UPLOAD_BLOCKS,
    )
    required = max(BLOCK_BYTES, manifest_required, latency_required)
    block_size = BLOCK_BYTES
    while block_size < required:
        block_size *= 2
    return block_size


def _source_plan_block_size(plan: StagePlan) -> int:
    """Read one frozen source-plan extent size with upgrade compatibility."""

    if not _plan_is_source_backed(plan) or plan.size_bytes <= 0 or not plan.blocks:
        raise StateError("The source-backed Fabric plan has no block size.")
    if plan.preserved_target_extents:
        block_size = max(block.size_bytes for block in plan.blocks)
        if not 1 <= block_size <= MAX_CAS_BLOCK_BYTES:
            raise StateError(
                "The source-backed Fabric plan has an unsupported block size."
            )
        return block_size
    block_size = plan.blocks[0].size_bytes
    if block_size not in {
        min(plan.size_bytes, _adaptive_upload_block_bytes(plan.size_bytes)),
        min(plan.size_bytes, _legacy_adaptive_upload_block_bytes(plan.size_bytes)),
    }:
        raise StateError("The source-backed Fabric plan has an unsupported block size.")
    return block_size


def _plan_block_size(plan: StagePlan) -> int:
    if plan.size_bytes == 0:
        return 1
    if _plan_is_source_backed(plan):
        return _source_plan_block_size(plan)
    return BLOCK_BYTES


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _small_edit_gear_table() -> tuple[int, ...]:
    """Generate the browser writer's deterministic 32-bit gear table."""

    state = FABRIC_SMALL_TEXT_CDC_GEAR_SEED
    values: list[int] = []
    for _ in range(256):
        state ^= (state << 13) & FABRIC_SMALL_TEXT_CDC_GEAR_MASK
        state ^= state >> 17
        state ^= (state << 5) & FABRIC_SMALL_TEXT_CDC_GEAR_MASK
        state &= FABRIC_SMALL_TEXT_CDC_GEAR_MASK
        values.append(state)
    return tuple(values)


_SMALL_EDIT_GEAR = _small_edit_gear_table()


def _small_edit_content_defined_blocks(
    descriptor: int,
    size_bytes: int,
    *,
    is_cancelled: Callable[[], bool] | None = None,
) -> tuple[StagedBlock, ...]:
    """Hash the browser-compatible CDC layout from one bounded local stage."""

    if not 0 < size_bytes <= SMALL_EDIT_CDC_FILE_MAX_BYTES:
        raise StateError("The small-edit CDC source is outside its bounded size.")
    data = bytearray()
    while len(data) < size_bytes:
        if is_cancelled is not None and is_cancelled():
            raise InvalidTask("The small-edit write was cancelled during planning.")
        read_size = min(FILE_PROVIDER_PLAN_READ_BYTES, size_bytes - len(data))
        if hasattr(os, "pread"):
            chunk = os.pread(descriptor, read_size, len(data))
        else:  # pragma: no cover - Windows has no os.pread
            os.lseek(descriptor, len(data), os.SEEK_SET)
            chunk = os.read(descriptor, read_size)
        if not chunk:
            break
        data.extend(chunk)
    if len(data) != size_bytes:
        raise StateError("The small-edit CDC stage was truncated.")
    blocks: list[StagedBlock] = []
    start = 0
    rolling = 0
    for offset, byte in enumerate(data, start=1):
        if offset % 4096 == 0 and is_cancelled is not None and is_cancelled():
            raise InvalidTask("The small-edit write was cancelled during planning.")
        rolling = ((rolling << 1) + _SMALL_EDIT_GEAR[byte]) & FABRIC_SMALL_TEXT_CDC_GEAR_MASK
        extent_size = offset - start
        if extent_size < SMALL_EDIT_CDC_MIN_BYTES:
            continue
        if (
            rolling & SMALL_EDIT_CDC_MASK
            and extent_size < SMALL_EDIT_CDC_MAX_BYTES
        ):
            continue
        payload = data[start:offset]
        blocks.append(
            StagedBlock(
                index=len(blocks),
                offset_bytes=start,
                size_bytes=len(payload),
                sha256=hashlib.sha256(payload).hexdigest(),
            )
        )
        start = offset
        rolling = 0
    if start < size_bytes:
        payload = data[start:]
        blocks.append(
            StagedBlock(
                index=len(blocks),
                offset_bytes=start,
                size_bytes=len(payload),
                sha256=hashlib.sha256(payload).hexdigest(),
            )
        )
    return tuple(blocks)


def _source_plan_hash_concurrency(block_size: int) -> int:
    """Bound one source planner's retained extent payload to 128 MiB."""

    if block_size <= 0 or block_size > MAX_CAS_BLOCK_BYTES:
        raise StateError("The Fabric source plan has an invalid extent size.")
    return max(
        1,
        min(
            SOURCE_PLAN_HASH_WORKERS,
            SOURCE_PLAN_RESIDENT_PAYLOAD_BYTES // block_size,
        ),
    )


def _upload_concurrency(plan: StagePlan) -> int:
    """Keep aggregate resident upload payloads at or below 128 MiB."""

    largest = max((block.size_bytes for block in plan.blocks), default=0)
    if largest < 0 or largest > MAX_CAS_BLOCK_BYTES:
        raise StateError("The Fabric upload plan has an invalid extent size.")
    return max(
        1,
        min(
            UPLOAD_WORKER_CONCURRENCY,
            UPLOAD_RESIDENT_PAYLOAD_BYTES // max(1, largest),
        ),
    )


def _receipt_manifest_digest(receipt: Mapping[str, Any]) -> str | None:
    """The head digest a receipt reports, or None for a Fabric v2 commit.

    v2 identifies a head by its journal sequence and has no per-commit content
    hash. Passing str(None) here would record the literal "None" as the head
    digest, which would then compare equal to itself and satisfy a digest fence
    that is actually checking nothing.
    """

    value = receipt.get("manifest_digest")
    return str(value) if isinstance(value, str) and value else None


def _normalized_modified_at(value: object) -> str | None:
    """Validate and canonicalize one RFC3339 timestamp for item identity."""

    if value is None:
        return None
    if not isinstance(value, str) or not 1 <= len(value.encode("utf-8")) <= 64:
        raise ValueError("modified_at must be a bounded RFC3339 timestamp")
    match = re.fullmatch(
        r"(?P<whole>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})"
        r"(?:\.(?P<fraction>\d{1,9}))?"
        r"(?P<zone>Z|[+-]\d{2}:\d{2})",
        value,
    )
    if match is None:
        raise ValueError("modified_at must be an RFC3339 timestamp with timezone")
    fraction = match.group("fraction") or ""
    nanoseconds = int(fraction.ljust(9, "0")) if fraction else 0
    rounded_microseconds = (nanoseconds + 500) // 1000
    carry_seconds, microseconds = divmod(rounded_microseconds, 1_000_000)
    try:
        parsed = datetime.fromisoformat(
            match.group("whole") + match.group("zone").replace("Z", "+00:00")
        )
        if parsed.tzinfo is None:
            raise ValueError
        parsed = parsed.replace(microsecond=microseconds) + timedelta(
            seconds=carry_seconds
        )
        normalized = parsed.astimezone(timezone.utc).isoformat(timespec="microseconds")
    except (OverflowError, ValueError):
        raise ValueError(
            "modified_at must be an RFC3339 timestamp with timezone"
        ) from None
    return normalized.replace("+00:00", "Z")


def _digest(value: object) -> bool:
    return isinstance(value, str) and RAW_SHA256_RE.fullmatch(value) is not None


def _v2_op_wire_estimate(operation: PendingOperation, block_count: int) -> int:
    """Upper estimate of one v2 op's serialized JSON size, PATH-AWARE.

    The flat ``V2_OP_WIRE_ESTIMATE_BYTES`` under-counts an op whose path is long
    (a copy of a copy nests deeply) or whose file has many blocks, so a cohort
    the count-based reservation called "safe" can still overflow the edge body
    limit. This adds the real path/destination length (JSON-escaped, generous)
    and one estimate per block descriptor, so the selector budgets by what the
    wire actually carries. Slightly generous is the safe error.
    """

    path_chars = len(operation.path or "") + len(operation.destination_path or "")
    path_bytes = (path_chars * V2_OP_PATH_WIRE_FACTOR_NUM) // V2_OP_PATH_WIRE_FACTOR_DEN
    block_extra = max(0, block_count - 1) * V2_OP_BLOCK_WIRE_ESTIMATE_BYTES
    # One aligned verification UUID (or null) also rides the native cohort.
    return V2_OP_WIRE_ESTIMATE_BYTES + 40 + path_bytes + block_extra


def _fabric_v2_request_digest(session_id: str, ops: Sequence[Mapping[str, Any]]) -> str:
    """Hash a Fabric v2 cohort over its ACTUAL ops.

    This must not reuse `_mutation_request_digest`: that helper digests only a
    v1 document's mutation_id/base/mutation fields, so a v2 payload hashes
    identically no matter what it contains. Deriving the cohort id from such a
    digest made every cohort share one id, and the server -- correctly
    idempotent -- replayed the first verdict and silently dropped every later
    commit.

    Attempt identity stays outside this semantic digest. Unknown outcomes
    replay the same frozen cohort. An authoritative FABRIC_BLOCK_ABSENT
    rejection instead durably renews the cohort seed before repairing bytes;
    identical ops can then succeed without replaying the rejected receipt.
    The journal mutation ID and semantic digest remain stable across repair.
    """

    return fabric_v2_request_digest(session_id, ops)


# A 400-class rejection naming the inline field means this control plane will
# not take inline bytes at all: the field is unknown (exactKeys refuses
# unlisted keys with no code we can match on) or its shape is refused. A 413
# is a DIFFERENT thing -- the channel works, this payload was too big -- and
# must shrink the budget rather than disable the lane, which is why the two
# are classified apart below.
_INLINE_FIELD_REJECTION_CODES = frozenset({
    "FABRIC_INLINE_BLOCKS_INVALID",
    "FABRIC_INLINE_BLOCK_DIGEST_MISMATCH",
    "FABRIC_INLINE_BLOCKS_UNAVAILABLE",
    "BAD_REQUEST",
})


def _remote_code(error: RemoteError) -> str:
    # RemoteError.code is the CLASS's error code ("REMOTE_ERROR"); the code the
    # control plane actually sent is remote_code. Reading the wrong one made
    # this classifier fall through to a substring match on the message.
    return str(getattr(error, "remote_code", "") or "").upper()


def _is_inline_field_rejection(error: RemoteError) -> bool:
    """The control plane will not accept inline bytes on the v2 commit."""

    if error.status != 400:
        return False
    if _remote_code(error) in _INLINE_FIELD_REJECTION_CODES:
        return True
    # An older deployment answers exactKeys with a generic message and no
    # matching code. The disable is bounded and re-probed either way.
    return "unsupported field" in str(error).lower()


def _is_inline_payload_oversized(error: RemoteError) -> bool:
    """This payload was too large -- the channel itself is fine."""

    return error.status == 413 or _remote_code(error) in {
        "PAYLOAD_TOO_LARGE",
        "FABRIC_INLINE_BLOCKS_TOO_LARGE",
        "FABRIC_INLINE_BLOCK_TOO_LARGE",
    }


def _v2_cohort_mutation_id(request_digest: str, mutation_ids: Sequence[str]) -> str:
    identity = json.dumps([request_digest, sorted(mutation_ids)], separators=(",", ":"))
    return str(uuid.uuid5(_FABRIC_V2_COHORT_NAMESPACE, identity))


def _is_v2_commit_fence(operation: PendingOperation) -> bool:
    """Whether a durable fence was frozen by the v2 commit lane.

    V2 cohort ids are uuid5s derived from request and durable journal identity;
    older clients used the request alone. V1 batch ids are always random
    uuid4s. Preserve that lane distinction when recovering either v2 format.

    It matters because the two lanes hash different documents into one
    ``request_digest`` column, so a fence must be resolved by the lane that
    wrote it.
    """

    digest = operation.request_digest
    batch_id = operation.commit_batch_id
    if not digest or not batch_id:
        return False
    try:
        return uuid.UUID(str(batch_id)).version == 5
    except ValueError:
        return False


def _mutation_request_digest(
    session_id: str, payload: Mapping[str, Any]
) -> str:
    """Hash the exact semantic v2 mutation request shared with the server.

    Recursive key sorting removes language/object insertion-order differences;
    unescaped Unicode is required to match JavaScript's UTF-8 JSON encoding for
    canonical NFC workspace paths.
    """

    document = {
        "schema": "meshiafabric.connected_host_path_mutation_request.v2",
        "session_id": session_id,
        "mutation_id": payload.get("mutation_id"),
        "base_generation": payload.get("base_generation"),
        "base_manifest_digest": payload.get("base_manifest_digest"),
        "mutation": payload.get("mutation"),
    }
    encoded = json.dumps(
        document,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _validate_mutation_receipt_identity(
    response: Mapping[str, Any],
    operation: PendingOperation,
    *,
    schema: str,
) -> None:
    """Bind both immediate and readback receipts to exact journal work."""

    expected_paths = (
        [operation.path, operation.destination_path]
        if operation.kind == "rename"
        else [operation.path]
    )
    manifest_id = response.get("manifest_id")
    generation = response.get("manifest_generation")
    if (
        response.get("schema") != schema
        or response.get("workspace") != WORKSPACE_MOUNT
        or response.get("mutation_id") != operation.mutation_id
        or response.get("operation") != operation.kind
        or response.get("touched_paths") != expected_paths
        or not isinstance(manifest_id, str)
        or UUID_RE.fullmatch(manifest_id) is None
        or str(uuid.UUID(manifest_id)) != manifest_id
        or isinstance(generation, bool)
        or not isinstance(generation, int)
        or generation < 1
        or not _digest(response.get("manifest_digest"))
    ):
        raise NetworkError("Meshia returned a mismatched Fabric mutation receipt.")


def _mutation_receipt(
    response: object,
    operation: PendingOperation,
    *,
    plan: StagePlan | None,
    request_digest: str,
) -> dict[str, Any]:
    keys = {
        "schema",
        "workspace",
        "mutation_id",
        "operation",
        "touched_paths",
        "entry_sha256",
        "manifest_id",
        "manifest_digest",
        "manifest_generation",
        "replayed",
        "path_index_deferred",
        "request_digest",
    }
    if not isinstance(response, Mapping) or set(response) != keys:
        raise NetworkError("Meshia returned an invalid Fabric mutation receipt.")
    _validate_mutation_receipt_identity(response, operation, schema=MUTATION_SCHEMA)
    expected_entry_digest = (
        plan.sha256
        if operation.kind == "put" and plan is not None
        else operation.expected_source_digest
    )
    if (
        (operation.kind == "put" and plan is None)
        or response.get("request_digest") != request_digest
        or response.get("entry_sha256") != expected_entry_digest
        or not isinstance(response.get("replayed"), bool)
        or not isinstance(response.get("path_index_deferred"), bool)
    ):
        raise NetworkError("Meshia returned an inconsistent Fabric mutation receipt.")
    return dict(response)


def _mutation_status_receipt(
    response: object,
    operation: PendingOperation,
    *,
    request_digest: str,
) -> dict[str, Any] | None:
    """Validate the exact production mutation-status wire.

    ``None`` is an authoritative request-bound miss. A found response is
    retained verbatim as the durable receipt; synthesizing fields from the
    request would weaken the readback proof and hide server/client drift.
    """

    common_keys = {
        "schema",
        "workspace",
        "mutation_id",
        "request_digest",
        "found",
    }
    if (
        not isinstance(response, Mapping)
        or response.get("schema") != MUTATION_STATUS_SCHEMA
        or response.get("workspace") != WORKSPACE_MOUNT
        or response.get("mutation_id") != operation.mutation_id
        or response.get("request_digest") != request_digest
        or not isinstance(response.get("found"), bool)
    ):
        raise NetworkError("Meshia returned an invalid Fabric mutation status.")
    if response["found"] is False:
        if set(response) != common_keys:
            raise NetworkError("Meshia returned an invalid missing mutation status.")
        return None

    found_keys = common_keys | {
        "operation",
        "touched_paths",
        "manifest_id",
        "manifest_digest",
        "manifest_generation",
    }
    if set(response) != found_keys:
        raise NetworkError("Meshia returned an invalid found mutation status.")
    _validate_mutation_receipt_identity(
        response, operation, schema=MUTATION_STATUS_SCHEMA
    )
    return dict(response)


def _mutation_batch_items(
    response: object,
    prepared: Sequence[tuple[_BatchCommitEntry, dict[str, Any], str]],
) -> list[dict[str, Any]]:
    """Validate the mutate_batch envelope and bind every item to its request."""

    keys = {
        "schema",
        "workspace",
        "item_count",
        "applied_count",
        "rejected_count",
        "skipped_count",
        "head",
        "items",
    }
    if (
        not isinstance(response, Mapping)
        or set(response) != keys
        or response.get("schema") != MUTATION_BATCH_SCHEMA
        or response.get("workspace") != WORKSPACE_MOUNT
        or response.get("item_count") != len(prepared)
        or not isinstance(response.get("items"), list)
        or len(response["items"]) != len(prepared)
    ):
        raise NetworkError("Meshia returned an invalid Fabric mutation batch response.")
    items: list[dict[str, Any]] = []
    for index, ((entry, _payload, _digest), item) in enumerate(
        zip(prepared, response["items"])
    ):
        if (
            not isinstance(item, Mapping)
            or item.get("index") != index
            or item.get("mutation_id") != entry.operation.mutation_id
            or item.get("status") not in {"applied", "rejected", "skipped"}
            or (item["status"] == "applied") != isinstance(item.get("receipt"), Mapping)
            or (item["status"] != "applied" and not isinstance(item.get("error"), Mapping))
        ):
            raise NetworkError("Meshia returned a mismatched Fabric mutation batch item.")
        items.append(dict(item))
    return items


def _is_fabric_v2_path_conflict(error: RemoteError) -> bool:
    """Return true for a v2 per-path verdict a refresh can still resolve.

    Matched on the code alone rather than on (status, code): these codes are
    unique to the v2 commit RPC, and `_send_commit_v2` synthesises the status
    itself, so pinning a status here would only make the classification depend
    on a number no server chose.
    """

    return error.remote_code in FABRIC_V2_REBASE_CODES | FABRIC_V2_REFRESH_CODES


def _direct_batch_failure(result: DirectBatchResult) -> NetworkError:
    """Explain WHY a bounded direct block batch did not complete.

    The pool already records the exact exception per block
    (``ObjectEdgeNotFound: ...``, ``ObjectEdgeUnavailable: ...``), and both
    call sites used to discard it and raise one fixed sentence. So "the object
    this manifest entry names does not exist" and "the network is down" were
    the same NETWORK_UNAVAILABLE line in the service log -- indistinguishable
    at exactly the moment the difference matters, because the first means the
    file can never be read back and the second resolves itself.

    Absence is called out separately: it is permanent, and no amount of
    retrying is going to produce the bytes.
    """

    reasons = sorted({text for text in result.failures.values() if text})
    absent = bool(reasons) and all(
        reason.startswith("ObjectEdgeNotFound") for reason in reasons
    )
    detail = "; ".join(reasons)[:_MAX_DIRECT_BATCH_REASON_BYTES]
    parts: list[str] = []
    if detail:
        parts.append(detail)
    if result.timed_out:
        parts.append(f"{len(result.timed_out)} timed out")
    if result.unstarted:
        parts.append(f"{len(result.unstarted)} never started")
    summary = f" ({'; '.join(parts)})" if parts else ""
    if absent and not result.timed_out and not result.unstarted:
        return NetworkError(
            "The Fabric blocks this entry names are absent from object "
            f"storage, so its bytes cannot be read back{summary}."
        )
    return NetworkError(
        f"A bounded direct Fabric block batch did not complete{summary}."
    )


def _is_mutation_conflict(error: RemoteError) -> bool:
    return error.status == 409 and error.remote_code in {
        "FABRIC_MUTATION_BASE_DIVERGED",
        "FABRIC_MUTATION_IDEMPOTENCY_CONFLICT",
        "FABRIC_MUTATION_PATH_CONFLICT",
        "FABRIC_MUTATION_DIRECTORY_UNSUPPORTED",
        "FABRIC_MUTATION_LEGACY_RENAME_UNSUPPORTED",
        "FABRIC_MUTATION_RENAME_SAME_PATH",
        "FABRIC_MUTATION_NAMESPACE_TOO_LARGE",
    }


def _is_precommit_safe_mutation_rejection(error: RemoteError) -> bool:
    """Return true only for responses produced before durable publication.

    Authority/binding revalidation can fail *after* the server has persisted a
    receipt, so generic 4xx/409 handling is unsafe. An explicit idempotency
    conflict is a proven rejection and must never be blessed via status.
    """

    return error.remote_code in {
        "FABRIC_MUTATION_BASE_INVALID",
        "FABRIC_MUTATION_DESCRIPTOR_INVALID",
        "FABRIC_MUTATION_OPERATION_INVALID",
        "FABRIC_MUTATION_PRECONDITION_INVALID",
        "FABRIC_MUTATION_REQUEST_DIGEST_INVALID",
        "FABRIC_MUTATION_INVALID_ID",
        "FABRIC_MUTATION_INVALID_BASE",
        "FABRIC_MUTATION_INVALID_BINDING",
        "FABRIC_MUTATION_LATEST_INVALID",
        "FABRIC_MUTATION_BASE_DIVERGED",
        "FABRIC_MUTATION_IDEMPOTENCY_CONFLICT",
        "FABRIC_MUTATION_PATH_CONFLICT",
        "FABRIC_MUTATION_DIRECTORY_UNSUPPORTED",
        "FABRIC_MUTATION_LEGACY_RENAME_UNSUPPORTED",
        "FABRIC_MUTATION_PUT_REQUIRES_BLOCK_CAS",
        "FABRIC_MUTATION_RENAME_SAME_PATH",
        "FABRIC_MUTATION_BLOCKS_NOT_VERIFIED",
        "CONNECTED_HOST_FABRIC_BLOCKS_NOT_VERIFIED",
        # /blocks-stage authority answers (admission, verification authorize/
        # record) are produced strictly before any manifest persist, so a
        # stale-authority rejection can never hide a durable commit.
        "FABRIC_BLOCK_WRITE_AUTHORITY_STALE",
        "FABRIC_MUTATION_NAMESPACE_TOO_LARGE",
        "FABRIC_MUTATION_PERSIST_REJECTED",
        "WORKSPACE_STORAGE_QUOTA_EXCEEDED",
        "TIMESTAMP_OUT_OF_RANGE",
        "SEQUENCE_REPLAYED",
    }


def _is_put_verification_expired(error: RemoteError) -> bool:
    return error.status == 409 and error.remote_code in {
        "FABRIC_MUTATION_BLOCKS_NOT_VERIFIED",
        "CONNECTED_HOST_FABRIC_BLOCKS_NOT_VERIFIED",
    }


def _demote_unconfirmed_receipts(progress: dict[str, Any]) -> int:
    """Forget receipts whose PUT the provider never acknowledged.

    Returns how many receipts were dropped. ``stored`` (2xx) and
    ``canonical_exists`` (412) receipts stay: those objects were confirmed by
    the provider at PUT time.
    """

    receipts = progress.get("receipts")
    if not isinstance(receipts, dict):
        return 0
    unconfirmed = [
        digest
        for digest, receipt in receipts.items()
        if not isinstance(receipt, dict)
        or receipt.get("outcome") not in {"stored", "canonical_exists"}
    ]
    for digest in unconfirmed:
        receipts.pop(digest, None)
        progress["uploaded"].discard(digest)
    return len(unconfirmed)


def _is_reupload_verification_error(error: RemoteError) -> bool:
    """Codes that mean "the bytes are not there; send them again".

    All of these are the provider or the control plane saying a block it was
    asked to stand behind is absent or is not the bytes it claims. The right
    answer is always the same: forget every assumption about what the store
    already holds, and re-upload from the source.

    FABRIC_BLOCK_ABSENT is the v2 commit's per-op verdict for exactly that,
    and it reaches a client that has done nothing wrong: `_reusable_target_
    blocks` offers a new put the PREVIOUS entry's digests as already-verified,
    so overwriting a path whose old blocks are missing from the store proposes
    blocks the node can never prove. Without this classification the node
    re-offers the same unprovable digests until the retry bound and then
    parks -- a user overwriting a file watches it fail when re-uploading the
    bytes they already have locally would have worked.
    """

    return error.status == 409 and error.remote_code in {
        "FABRIC_BLOCK_ABSENT",
        "CONNECTED_HOST_FABRIC_BLOCK_MISSING",
        "CONNECTED_HOST_FABRIC_BLOCK_SIZE_METADATA_MISSING_OR_MISMATCHED",
        "CONNECTED_HOST_FABRIC_BLOCK_SIZE_MISMATCH",
        "CONNECTED_HOST_FABRIC_BLOCK_SHA256_MISMATCH",
        "CONNECTED_HOST_FABRIC_BLOCK_PROVIDER_PROOF_MISMATCH",
    }


def _is_v2_absent_block_rejection(error: RemoteError) -> bool:
    """Only the v2 commit's own absent-block verdict.

    Deliberately narrower than `_is_reupload_verification_error`. That
    predicate is safe to broaden because its call sites only DEMOTE cached
    proof, but routing on it inside `_handle_operation_remote_error` would
    change how the pre-existing CONNECTED_HOST_FABRIC_BLOCK_* codes are
    parked, which four unrelated tests correctly noticed. New behaviour for a
    new code; nothing else moves.
    """

    return error.status == 409 and error.remote_code == "FABRIC_BLOCK_ABSENT"


def _is_v2_block_proof_required(error: RemoteError) -> bool:
    """The commit named more unproven blocks than one commit may read back.

    ``fabric_commit_v2_1762`` caps a commit at FABRIC_V2_MAX_COMMIT_READBACKS
    unproven-block readbacks and rejects the WHOLE request (fast, nothing
    applied) with this code. Matched on the code alone, not the status, so a
    control plane that answers 400 or 409 is handled the same -- it is treated
    exactly like a 413: the cohort must carry fewer unproven blocks.
    """

    return _remote_code(error) == "FABRIC_BLOCK_PROOF_REQUIRED"


def _is_v2_commit_gateway_timeout(error: RemoteError) -> bool:
    """A gateway/proxy cut the v2 commit call before the origin answered.

    The outcome is genuinely unknown (the commit may have applied), so this is
    NOT treated as a clean 413: the ops keep their idempotent per-path replay.
    Only the item cap shrinks, so a cohort that overran the route deadline
    re-plans smaller instead of re-sending the identical oversized request into
    the same timeout forever.
    """

    return error.status in _V2_COMMIT_GATEWAY_TIMEOUT_STATUSES


def _is_remote_head_stale(error: RemoteError) -> bool:
    return error.status == 409 and error.remote_code in {
        "FABRIC_BLOCK_READ_CURSOR_STALE",
        "FABRIC_MANIFEST_CHANGED",
    }


def _is_remote_content_missing(error: RemoteError) -> bool:
    return error.status == 409 and error.remote_code == "FABRIC_CONTENT_MISSING"


def _is_legacy_content_missing_conflict_reason(reason: str) -> bool:
    """Recognize only the exact historical server error recorded by the node."""

    prefix = (
        "remote apply cannot continue safely: "
        "Meshia request failed (HTTP 409): "
    )
    if not reason.startswith(prefix):
        return False
    document_text = reason[len(prefix) :]
    if document_text.endswith(")") and " (request_id=" in document_text:
        document_text, _separator, request_id = document_text.rpartition(
            " (request_id="
        )
        if not request_id[:-1] or len(request_id) > 257:
            return False
    try:
        document = json.loads(document_text)
    except (json.JSONDecodeError, TypeError):
        return False
    return bool(
        isinstance(document, Mapping)
        and document.get("code") == "FABRIC_CONTENT_MISSING"
        and document.get("error") == LEGACY_CONTENT_MISSING_ERROR
    )


def _traceback_tail(error: BaseException, *, frames: int = 4) -> str:
    """The innermost frames of an error, compact enough for one log field.

    A retry event that carries only ``str(error)`` cannot be traced back to
    its raise site (2026-09-02: a bare ``ValueError`` text took an afternoon
    to locate). Innermost frame first; ``log.py`` caps a field at 256 bytes.
    """

    summary = traceback.extract_tb(error.__traceback__)[-frames:]
    return " < ".join(
        f"{Path(frame.filename).name}:{frame.lineno} {frame.name}"
        for frame in reversed(summary)
    )


def _fabric_readiness_reason(error: BaseException) -> str:
    """Project internal retry detail onto one stable, user-facing state."""

    if isinstance(error, RemoteError):
        if error.remote_code == "FABRIC_ATTACHMENT_INACTIVE":
            return "workspace_authority_refresh"
        if error.remote_code == "FABRIC_BINDING_INACTIVE":
            return "workspace_storage_waiting"
        if error.remote_code == "FABRIC_MANIFEST_UNAVAILABLE":
            return "workspace_manifest_waiting"
        if error.remote_code in {"FABRIC_BINDING_CHANGED", "FABRIC_AUTHORITY_STALE"}:
            return "workspace_authority_refresh"
        if error.status == 429:
            return "rate_limited"
    if isinstance(error, NetworkError):
        return "network_retry"
    if isinstance(error, StagingQuotaExceeded) and not isinstance(
        error, StagingRepairPending
    ):
        # "sync_error" sent the owner and an engineer hunting a permissions
        # bug for three rounds. Local capacity is its own state and says what
        # to do about it.
        return "local_cache_full"
    return "sync_error"


def _is_transient_remote_error(error: RemoteError) -> bool:
    return (
        error.status in (408, 425, 429)
        or error.status >= 500
        or (
            error.status == 409
            and error.remote_code
            in {
                # Heartbeat renews the same attachment id; these must remain
                # retryable until that independent lease lane succeeds or the
                # outer runner declares the attachment offline.
                "FABRIC_ATTACHMENT_INACTIVE",
                "FABRIC_ATTACHMENT_LEASE_TOO_SHORT",
                "FABRIC_BLOCK_TICKET_AUTHORITY_STALE",
                # The write reservation raced attachment/lease renewal or a
                # GC candidate for the same immutable block (delete a file,
                # re-add identical bytes). Both clear on their own; a
                # permanent conflict here strands user data locally.
                "FABRIC_BLOCK_WRITE_AUTHORITY_STALE",
                "FABRIC_BLOCK_GC_IN_PROGRESS",
                "FABRIC_BINDING_CHANGED",
                "FABRIC_BINDING_INACTIVE",
                "FABRIC_MANIFEST_UNAVAILABLE",
                "FABRIC_PATH_INDEX_STALE",
                "FABRIC_AUTHORITY_STALE",
                "FABRIC_CONTENT_MISSING",
                "FABRIC_MUTATION_PERSIST_CONFLICT",
                "FABRIC_MUTATION_CONFLICT_RETRY_EXHAUSTED",
                # The v2 journal trigger refused a prune because no checkpoint
                # at or above that sequence has been written yet. A checkpoint
                # is written by an independent lane, so this clears on its own.
                "FABRIC_JOURNAL_UNCHECKPOINTED",
                # Verification proved the immutable object missing or corrupt.
                # _send_put durably demotes its uploaded/verified assumptions
                # before this retry classification is reached.
                "CONNECTED_HOST_FABRIC_BLOCK_MISSING",
                "CONNECTED_HOST_FABRIC_BLOCK_SIZE_METADATA_MISSING_OR_MISMATCHED",
                "CONNECTED_HOST_FABRIC_BLOCK_SIZE_MISMATCH",
                "CONNECTED_HOST_FABRIC_BLOCK_SHA256_MISMATCH",
                "CONNECTED_HOST_FABRIC_BLOCK_PROVIDER_PROOF_MISMATCH",
            }
        )
        or error.remote_code == "CONNECTED_HOST_FABRIC_BLOCK_VERIFY_ABORTED"
        # SignedClient normally repairs a server-proven clock/sequence hint and
        # retries once under its cross-process lock. If that bounded repair is
        # unavailable or fails, coordinator fallback must remain retryable and
        # must never turn an authentication envelope issue into a path conflict.
        or error.remote_code in {"TIMESTAMP_OUT_OF_RANGE", "SEQUENCE_REPLAYED"}
    )


def _operation_retry_delay(mutation_id: str, failure_count: int) -> float:
    """Return deterministic capped exponential backoff with per-operation jitter."""

    exponent = min(max(0, failure_count - 1), 30)
    base = min(OPERATION_RETRY_MAX_SECONDS, OPERATION_RETRY_BASE_SECONDS * (2**exponent))
    seed = hashlib.sha256(f"{mutation_id}:{failure_count}".encode("ascii")).digest()[0]
    jitter = 0.8 + (float(seed) / 255.0) * 0.4
    return min(OPERATION_RETRY_MAX_SECONDS, base * jitter)


class _ManifestScopedCacheGate:
    """Passes a range cache through, refusing only the v1 range-fetch lane.

    Range bindings (`get`/`put`) are keyed by the immutable whole-file digest,
    so they serve a Fabric v2 head exactly as they serve a v1 one; the cache
    labels a v2 admission (`manifest_digest=None`) itself. Until 2026-09-02
    this gate turned both into misses and no-ops under v2, which silently
    re-downloaded every block on every read of every v2 workspace -- the
    default lane -- while looking like a cache. Only `stream` stays refused:
    it is the v1 signed range-fetch lane, which needs a published manifest a
    v2 workspace never has.
    """

    __slots__ = ("_cache", "_unscoped")

    def __init__(self, cache: Any, unscoped: Callable[[], bool]) -> None:
        self._cache = cache
        self._unscoped = unscoped

    def get(self, *args: Any, **kwargs: Any) -> Any:
        return self._cache.get(*args, **kwargs)

    def put(self, *args: Any, **kwargs: Any) -> Any:
        return self._cache.put(*args, **kwargs)

    def stream(self, *args: Any, **kwargs: Any) -> Any:
        if self._unscoped():
            raise NetworkError(
                "A Fabric v2 read cannot use the manifest-scoped range cache."
            )
        return self._cache.stream(*args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._cache, name)

    def __setattr__(self, name: str, value: Any) -> None:
        # The proxy owns only its own two slots; everything else is the
        # wrapped cache's state and must be written through, or a caller
        # tuning the real cache would silently configure the wrapper instead.
        if name in _ManifestScopedCacheGate.__slots__:
            object.__setattr__(self, name, value)
        else:
            setattr(self._cache, name, value)


def _remote_entry(raw: object) -> RemoteEntry:
    if not isinstance(raw, Mapping):
        raise NetworkError("Meshia returned an invalid Fabric file descriptor.")
    path = raw.get("path")
    size = raw.get("size_bytes")
    digest = raw.get("sha256")
    modified = raw.get("modified_at")
    blocks = raw.get("blocks")
    if (
        not isinstance(path, str)
        or isinstance(size, bool)
        or not isinstance(size, int)
        or not 0 <= size <= MAX_REMOTE_FILE_BYTES
        or not _digest(digest)
        or (modified is not None and not isinstance(modified, str))
        or (blocks is not None and not isinstance(blocks, Mapping))
    ):
        raise NetworkError("Meshia returned an invalid Fabric file descriptor.")
    try:
        return RemoteEntry(path, size, str(digest), modified, blocks)
    except (ValueError, UnsafePath) as error:
        raise NetworkError("Meshia returned an unsafe Fabric file descriptor.") from error


def _v2_remote_entry(raw: Mapping[str, Any], path: str) -> RemoteEntry | None:
    """A Fabric v2 journal `put` record as a remote entry.

    The v2 wire names differ from v1's on purpose -- these are the journal's
    own columns (`digest`, `size_bytes`), not a manifest descriptor's
    (`sha256`, `modified_at`) -- so this parses them rather than reusing
    `_remote_entry` against a shape it was not written for.

    A directory has no content identity; retain it as namespace metadata,
    never as a file to hydrate.
    """

    if raw.get("kind") == "dir":
        if raw.get("digest") is not None or raw.get("size_bytes", 0) != 0 or raw.get("blocks") is not None:
            raise NetworkError("Meshia returned directory metadata carrying file content.")
        return RemoteEntry(path, 0, None, kind="directory")
    size = raw.get("size_bytes")
    digest = raw.get("digest")
    blocks = raw.get("blocks")
    modified = raw.get("modified_at")
    if (
        isinstance(size, bool)
        or not isinstance(size, int)
        or not 0 <= size <= MAX_REMOTE_FILE_BYTES
        or not _digest(digest)
        or (modified is not None and not isinstance(modified, str))
        or (blocks is not None and not isinstance(blocks, Mapping))
    ):
        raise NetworkError("Meshia returned an invalid Fabric v2 change record.")
    try:
        return RemoteEntry(
            path, size, str(digest), _normalized_modified_at(modified), blocks
        )
    except (ValueError, UnsafePath) as error:
        raise NetworkError("Meshia returned an unsafe Fabric v2 change record.") from error


def _v2_snapshot_entry(raw: object, path: str) -> RemoteEntry | None:
    """One row of the v2 tree walk (fabric_subtree_1763's projection).

    Directory entries retain empty namespace shape but never become hydrated files.
    """

    if not isinstance(raw, Mapping):
        raise NetworkError("Meshia returned an invalid Fabric v2 snapshot entry.")
    if raw.get("kind") == "dir":
        if raw.get("sha256") is not None or raw.get("size_bytes", 0) != 0 or raw.get("blocks") is not None:
            raise NetworkError("Meshia returned directory metadata carrying file content.")
        return RemoteEntry(path, 0, None, kind="directory")
    size = raw.get("size_bytes")
    digest = raw.get("sha256")
    updated = raw.get("modified_at", raw.get("updated_at"))
    # The block descriptor, when the control plane attaches it. A file learned
    # only through a snapshot has no other source of block extents: v2 has no
    # manifest-scoped range lane to fall back to, so without it every read of
    # such a file failed on the mount (2026-09-02).
    blocks = raw.get("blocks")
    if (
        isinstance(size, bool)
        or not isinstance(size, int)
        or not 0 <= size <= MAX_REMOTE_FILE_BYTES
        or not _digest(digest)
        or (updated is not None and not isinstance(updated, str))
        or (blocks is not None and not isinstance(blocks, Mapping))
    ):
        raise NetworkError("Meshia returned an invalid Fabric v2 snapshot entry.")
    try:
        return RemoteEntry(
            path, size, str(digest), _normalized_modified_at(updated), blocks
        )
    except (ValueError, UnsafePath) as error:
        raise NetworkError("Meshia returned an unsafe Fabric v2 snapshot entry.") from error


def _delta_entry(raw: object) -> tuple[str, RemoteEntry | None]:
    if not isinstance(raw, Mapping) or not isinstance(raw.get("path"), str):
        raise NetworkError("Meshia returned an invalid Fabric delta entry.")
    kind = raw.get("kind")
    path = str(raw["path"])
    if kind == "file":
        return path, _remote_entry(raw)
    if kind in ("directory", "tombstone"):
        # FabricDatabase indexes files; directories are implicit and durable
        # tombstones are represented by absence in the active namespace.
        try:
            from .workspace import split_relative

            split_relative(path)
        except UnsafePath as error:
            raise NetworkError("Meshia returned an unsafe Fabric delta path.") from error
        return path, None
    raise NetworkError("Meshia returned an invalid Fabric delta kind.")


def _head_fields(
    head: RemoteManifest | RemoteManifestHead | None,
) -> tuple[int | None, str | None]:
    return (head.generation, head.digest) if head else (None, None)


def _expectation(digest: str | None) -> dict[str, Any]:
    return {"kind": "file", "digest": digest} if digest else {"kind": "absent", "digest": None}


def _portable_paths_alias(left: str, right: str) -> bool:
    if left == right:
        return False
    left_nfc = unicodedata.normalize("NFC", left)
    right_nfc = unicodedata.normalize("NFC", right)
    for left_key, right_key in (
        (
            unicodedata.normalize("NFC", left_nfc.upper()),
            unicodedata.normalize("NFC", right_nfc.upper()),
        ),
        (
            unicodedata.normalize("NFC", left_nfc.lower()),
            unicodedata.normalize("NFC", right_nfc.lower()),
        ),
    ):
        if (
            left_key == right_key
            or left_key.startswith(right_key + "/")
            or right_key.startswith(left_key + "/")
        ):
            return True
    return False


def _directory_rename_delta_bytes(
    entries: Sequence[RemoteEntry],
    *,
    source_path: str,
    destination_path: str,
) -> int:
    """Conservatively size file moves plus bounded prefix marker rows."""

    maximum_timestamp = "9999-12-31T23:59:59.999Z"
    documents: list[dict[str, Any]] = [
        {
            "path": source_path,
            "kind": "tombstone",
            "sizeBytes": 0,
            "sha256": hashlib.sha256(
                (
                    "meshiafabric.directory-prefix.v1\0" + source_path
                ).encode("utf-8")
            ).hexdigest(),
            "modifiedAt": maximum_timestamp,
        },
        {
            "path": destination_path,
            "kind": "directory",
            "sizeBytes": 0,
            "sha256": None,
            "modifiedAt": maximum_timestamp,
        },
    ]
    for entry in entries:
        if not entry.path.startswith(source_path + "/"):
            continue
        destination = destination_path + entry.path[len(source_path) :]
        documents.append(
            {
                "path": entry.path,
                "kind": "tombstone",
                "sizeBytes": 0,
                "sha256": entry.digest,
                "modifiedAt": None,
            }
        )
        moved: dict[str, Any] = {
            "path": destination,
            "kind": "file",
            "sizeBytes": entry.size_bytes,
            "sha256": entry.digest,
            "modifiedAt": entry.modified,
        }
        if entry.blocks is not None:
            moved["blocks"] = entry.blocks
        documents.append(moved)
    # The server normalizes these entries, adds counts/digests/authority, and
    # serializes the complete delta under the same 2-MiB hard ceiling. Reserve
    # both a maximum-path wrapper and a per-entry normalization margin so the
    # client can only reject early; it must never durably journal a mutation the
    # server will deterministically reject as oversized.
    return (
        DIRECTORY_RENAME_DELTA_HEADER_MARGIN_BYTES
        + len(documents) * MUTATION_PREIMAGE_ENTRY_MARGIN_BYTES
        + len(
        json.dumps(
            documents,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        )
    )


def _stage_plan_blocks_descriptor(
    plan: StagePlan,
    *,
    block_size: int | None = None,
) -> dict[str, Any]:
    """Return the canonical directly indexed CAS descriptor for one PUT plan."""

    effective_block_size = block_size
    if effective_block_size is None:
        effective_block_size = _plan_block_size(plan)
    return {
        "version": 1,
        "algorithm": "sha256",
        "block_size_bytes": effective_block_size,
        "block_count": len(plan.blocks),
        "total_bytes": plan.size_bytes,
        "blocks": [
            {
                "index": block.index,
                "offset_bytes": block.offset_bytes,
                "size_bytes": block.size_bytes,
                "sha256": block.sha256,
            }
            for block in plan.blocks
        ],
        "storage": {"kind": CONNECTED_HOST_OBJECT_CAS_KIND},
    }


def _staged_remote_entry(operation: PendingOperation) -> RemoteEntry:
    """Project the final remote descriptor of a durable pending PUT."""

    if operation.kind != "put" or operation.staged_path is None:
        raise StateError("A directory rename predecessor is not a durable PUT.")
    plan = _load_plan(Path(operation.staged_path), operation)
    return RemoteEntry(
        operation.path,
        plan.size_bytes,
        plan.sha256,
        plan.modified_at,
        _stage_plan_blocks_descriptor(plan),
    )


def _projected_mutation_namespace_usage(
    entries: Sequence[RemoteEntry],
    operation: PendingOperation,
    *,
    plan: StagePlan | None,
    session_id: str,
) -> tuple[int, int]:
    """Return live-file count and a bounded observable preimage upper estimate."""

    if len(entries) > MAX_MUTATION_LIVE_FILES:
        return len(entries), MAX_MUTATION_PREIMAGE_BYTES + 1
    projected = {entry.path: entry for entry in entries}
    candidate_document: dict[str, Any] | None = None
    if operation.kind == "put":
        if plan is None:
            raise StateError("A Fabric put namespace preflight has no stage plan.")
        candidate_document = {
            "path": operation.path,
            "kind": "file",
            "sizeBytes": plan.size_bytes,
            "sha256": plan.sha256,
            "modifiedAt": plan.modified_at,
            "blocks": {
                "version": 1,
                "algorithm": "sha256",
                "blockSizeBytes": (
                    _plan_block_size(plan)
                    if _plan_is_source_backed(plan) and plan.size_bytes
                    else (BLOCK_BYTES if plan.size_bytes else 1)
                ),
                "blockCount": len(plan.blocks),
                "totalBytes": plan.size_bytes,
                "storage": {"kind": CONNECTED_HOST_OBJECT_CAS_KIND},
                "blocks": [
                    {
                        "index": block.index,
                        "offsetBytes": block.offset_bytes,
                        "sizeBytes": block.size_bytes,
                        "sha256": block.sha256,
                    }
                    for block in plan.blocks
                ],
            },
        }
        projected.pop(operation.path, None)
    elif operation.kind == "rename":
        if operation.destination_path is None:
            raise StateError("A Fabric rename namespace preflight has no destination.")
        if operation.directory_rename:
            source_prefix = operation.path + "/"
            destination_prefix = operation.destination_path + "/"
            sources = [
                entry
                for path, entry in projected.items()
                if path.startswith(source_prefix)
            ]
            if not sources or any(
                path == operation.destination_path
                or path.startswith(destination_prefix)
                for path in projected
            ):
                return len(projected), MAX_MUTATION_PREIMAGE_BYTES + 1
            for source in sources:
                projected.pop(source.path, None)
            for source in sources:
                destination = operation.destination_path + source.path[len(operation.path) :]
                projected[destination] = RemoteEntry(
                    destination,
                    source.size_bytes,
                    source.digest,
                    source.modified,
                    source.blocks,
                )
        else:
            source = projected.pop(operation.path, None)
            projected.pop(operation.destination_path, None)
            if source is not None:
                projected[operation.destination_path] = RemoteEntry(
                    operation.destination_path,
                    source.size_bytes,
                    source.digest,
                    source.modified,
                    source.blocks,
                )
    else:
        return len(projected), 0

    file_count = len(projected) + (1 if candidate_document is not None else 0)
    if file_count > MAX_MUTATION_LIVE_FILES:
        return file_count, MAX_MUTATION_PREIMAGE_BYTES + 1
    # The exact object prefix is authority-private and explicit empty
    # directories are not present in the connected-host file index. Reserve a
    # documented 2-KiB envelope and add every observable file plus each derived
    # parent. A small per-entry margin covers comma/shape normalization without
    # the disastrous multi-megabyte false-positive tax of a max-path margin.
    estimated = MUTATION_PREIMAGE_HEADER_MARGIN_BYTES + len(session_id.encode("utf-8"))
    parents: set[str] = set()

    def include_path_parents(path: str) -> None:
        segments = path.split("/")
        prefix = ""
        for segment in segments[:-1]:
            prefix = f"{prefix}/{segment}" if prefix else segment
            if prefix in parents:
                continue
            parents.add(prefix)

    def encoded_size(document: Mapping[str, Any]) -> int:
        return len(
            json.dumps(
                document,
                ensure_ascii=False,
                sort_keys=False,
                separators=(",", ":"),
                allow_nan=False,
            ).encode("utf-8")
        )

    for entry in projected.values():
        document: dict[str, Any] = {
            "path": entry.path,
            "kind": "file",
            "sizeBytes": entry.size_bytes,
            "sha256": entry.digest,
            "modifiedAt": entry.modified,
        }
        if entry.blocks is not None:
            document["blocks"] = entry.blocks
        estimated += encoded_size(document) + MUTATION_PREIMAGE_ENTRY_MARGIN_BYTES
        include_path_parents(entry.path)
        if estimated > MAX_MUTATION_PREIMAGE_BYTES:
            return file_count, estimated
    if candidate_document is not None:
        estimated += encoded_size(candidate_document) + MUTATION_PREIMAGE_ENTRY_MARGIN_BYTES
        include_path_parents(operation.path)
    for parent in parents:
        estimated += encoded_size(
            {
                "path": parent,
                "kind": "directory",
                "sizeBytes": 0,
                "sha256": None,
                "modifiedAt": None,
            }
        ) + MUTATION_PREIMAGE_ENTRY_MARGIN_BYTES
        if estimated > MAX_MUTATION_PREIMAGE_BYTES:
            break
    return file_count, estimated


def _fingerprint_text(value: FileFingerprint) -> str:
    return json.dumps(asdict(value), sort_keys=True, separators=(",", ":"))


def _same_byte_visible_fingerprint(
    before: FileFingerprint, after: FileFingerprint
) -> bool:
    """Require one inode, size, and mtime across an explicit metadata syscall."""

    return (
        before.device_id == after.device_id
        and before.file_id == after.file_id
        and before.size_bytes == after.size_bytes
        and before.mtime_ns == after.mtime_ns
    )


def _same_local_file_storage(
    before: FileFingerprint, after: FileFingerprint
) -> bool:
    """Prove the pinned inode/length around an explicit mtime syscall."""

    return (
        before.device_id == after.device_id
        and before.file_id == after.file_id
        and before.size_bytes == after.size_bytes
    )


def _fingerprint_from_text(value: str) -> FileFingerprint:
    try:
        raw = json.loads(value)
        result = FileFingerprint(
            size_bytes=int(raw["size_bytes"]),
            mtime_ns=int(raw["mtime_ns"]),
            ctime_ns=int(raw["ctime_ns"]),
            device_id=int(raw["device_id"]),
            file_id=int(raw["file_id"]),
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise StateError("The durable Fabric source fingerprint is invalid.") from error
    if min(asdict(result).values()) < 0:
        raise StateError("The durable Fabric source fingerprint is invalid.")
    return result


def _rename_verification_fingerprint(marker: str) -> FileFingerprint:
    if not marker.startswith(_RENAME_VERIFY_PREFIX):
        raise StateError("The large rename verification marker is invalid.")
    return _fingerprint_from_text(marker[len(_RENAME_VERIFY_PREFIX) :])


def _daemon_future(name: str, function: Any) -> Future[Any]:
    """Run byte-only work without making process shutdown wait for a stuck disk."""

    future: Future[Any] = Future()

    def run() -> None:
        try:
            if future.set_running_or_notify_cancel():
                future.set_result(function())
        except BaseException as error:
            future.set_exception(error)

    threading.Thread(target=run, name=name, daemon=True).start()
    return future


def _verified_stage_chunks(stage: VerifiedStage) -> Iterator[bytes]:
    """Stream one token-bound private stage without following links."""

    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(str(stage.path), flags)
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size != stage.size_bytes
        ):
            raise StateError("The verified remote stage changed before publication.")
        total = 0
        while total < stage.size_bytes:
            chunk = os.read(descriptor, min(_IO_BYTES, stage.size_bytes - total))
            if not chunk:
                raise StateError("The verified remote stage was truncated.")
            total += len(chunk)
            yield chunk
        after = os.fstat(descriptor)
        if (
            after.st_dev != before.st_dev
            or after.st_ino != before.st_ino
            or after.st_size != before.st_size
            or after.st_mtime_ns != before.st_mtime_ns
            or after.st_ctime_ns != before.st_ctime_ns
        ):
            raise StateError("The verified remote stage changed during publication.")
    finally:
        os.close(descriptor)


def _read_up_to(descriptor: int, limit: int) -> bytes:
    chunks: list[bytes] = []
    remaining = limit
    while remaining:
        chunk = os.read(descriptor, min(_IO_BYTES, remaining))
        if not chunk:
            break
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _read_bounded_regular_file(
    path: Path, limit: int
) -> tuple[bytes, os.stat_result]:
    """Read one private metadata file without following links or overallocating."""

    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(str(path), flags)
    try:
        info = os.fstat(descriptor)
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_nlink != 1
            or info.st_size < 0
            or info.st_size > limit
        ):
            raise StateError("The Fabric metadata file exceeds its safe bound.")
        encoded = _read_up_to(descriptor, info.st_size + 1)
        after = os.fstat(descriptor)
        if (
            len(encoded) != info.st_size
            or after.st_dev != info.st_dev
            or after.st_ino != info.st_ino
            or after.st_size != info.st_size
            or after.st_mtime_ns != info.st_mtime_ns
            or after.st_ctime_ns != info.st_ctime_ns
        ):
            raise StateError("The Fabric metadata file changed while being read.")
        return encoded, after
    finally:
        os.close(descriptor)


def _write_all(descriptor: int, data: bytes) -> None:
    """Write one already-bounded byte range without accepting short writes."""

    view = memoryview(data)
    written = 0
    while written < len(view):
        count = os.write(descriptor, view[written:])
        if count <= 0:
            raise OSError("the Fabric staging write made no progress")
        written += count


def _fsync_dir(path: Path) -> None:
    # Windows does not provide a portable directory-fsync primitive.  On
    # POSIX, however, the directory sync is the durability boundary for every
    # stage rename: suppressing EIO/ENOSPC here could let the SQLite journal
    # advertise bytes whose directory entry was never made durable.
    if os.name == "nt":
        return
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    descriptor = os.open(str(path), flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _plan_path(stage: Path) -> Path:
    return stage.with_suffix(stage.suffix + ".plan.json")


def _file_provider_callback_path(stage: Path) -> Path:
    """Durable fence retained until Apple's mutation callback is answered."""

    return stage.with_suffix(stage.suffix + ".file-provider-callback")


def _progress_path(stage: Path) -> Path:
    return stage.with_suffix(stage.suffix + ".progress.json")


def _plan_version(plan: StagePlan) -> int:
    if plan.source_kind == "file_provider_fd" or (
        plan.source_path is not None and plan.preserved_target_extents
    ):
        return 3
    return 2 if plan.source_path is not None else 1


def _plan_document(plan: StagePlan) -> dict[str, Any]:
    return {
        "version": _plan_version(plan),
        "path": plan.path,
        "size_bytes": plan.size_bytes,
        "sha256": plan.sha256,
        "source_fingerprint": plan.source_fingerprint,
        "blocks": [asdict(block) for block in plan.blocks],
        "delete_after_ack_path": plan.delete_after_ack_path,
        "delete_after_ack_digest": plan.delete_after_ack_digest,
        "transfer_logical_path": plan.transfer_logical_path,
        "transfer_token": plan.transfer_token,
        "source_path": plan.source_path,
        "preserved_target_extents": plan.preserved_target_extents,
        "source_kind": plan.source_kind,
        "source_token": plan.source_token,
        "delete_after_ack_mutation_id": plan.delete_after_ack_mutation_id,
        "modified_at": plan.modified_at,
    }


def _write_json(path: Path, value: object) -> None:
    write_private_file(
        path,
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8"),
    )


def _load_plan(stage: Path, operation: PendingOperation) -> StagePlan:
    try:
        encoded, _info = _read_bounded_regular_file(
            _plan_path(stage), MAX_MUTATION_PREIMAGE_BYTES
        )
        raw = json.loads(encoded.decode("utf-8"))
    except (OSError, UnicodeDecodeError, ValueError) as error:
        raise StateError("The durable Fabric stage plan is missing or invalid.") from error
    raw_preserved_target_extents = raw.get("preserved_target_extents", False)
    if not isinstance(raw_preserved_target_extents, bool):
        raise StateError("The durable Fabric stage plan is malformed.")
    try:
        raw_blocks = raw["blocks"]
        blocks = tuple(
            StagedBlock(
                index=int(item["index"]),
                offset_bytes=int(item["offset_bytes"]),
                size_bytes=int(item["size_bytes"]),
                sha256=str(item["sha256"]),
            )
            for item in raw_blocks
        )
        plan = StagePlan(
            path=str(raw["path"]),
            size_bytes=int(raw["size_bytes"]),
            sha256=str(raw["sha256"]),
            source_fingerprint=str(raw["source_fingerprint"]),
            blocks=blocks,
            delete_after_ack_path=(
                str(raw["delete_after_ack_path"])
                if raw.get("delete_after_ack_path") is not None
                else None
            ),
            delete_after_ack_digest=(
                str(raw["delete_after_ack_digest"])
                if raw.get("delete_after_ack_digest") is not None
                else None
            ),
            transfer_logical_path=(
                str(raw["transfer_logical_path"])
                if raw.get("transfer_logical_path") is not None
                else None
            ),
            transfer_token=(
                str(raw["transfer_token"])
                if raw.get("transfer_token") is not None
                else None
            ),
            source_path=(
                str(raw["source_path"])
                if raw.get("source_path") is not None
                else None
            ),
            preserved_target_extents=raw_preserved_target_extents,
            source_kind=(
                str(raw["source_kind"])
                if raw.get("source_kind") is not None
                else None
            ),
            source_token=(
                str(raw["source_token"])
                if raw.get("source_token") is not None
                else None
            ),
            delete_after_ack_mutation_id=(
                str(raw["delete_after_ack_mutation_id"])
                if raw.get("delete_after_ack_mutation_id") is not None
                else None
            ),
            modified_at=_normalized_modified_at(raw.get("modified_at")),
        )
    except (KeyError, TypeError, ValueError) as error:
        raise StateError("The durable Fabric stage plan is malformed.") from error
    expected_offset = 0
    if (
        raw.get("version")
        != _plan_version(plan)
        or plan.path != operation.path
        or plan.size_bytes != operation.staged_size
        or plan.sha256 != operation.staged_digest
        or not _digest(plan.sha256)
        or not blocks
        or len(blocks) > MAX_MANIFEST_BLOCKS
        or ((plan.delete_after_ack_path is None) != (plan.delete_after_ack_digest is None))
        or ((plan.transfer_logical_path is None) != (plan.transfer_token is None))
        or (plan.source_path is not None and plan.transfer_logical_path is not None)
        or (plan.preserved_target_extents and not _plan_is_source_backed(plan))
        or (
            plan.source_kind not in (None, "file_provider_fd")
            or (plan.source_kind is None) != (plan.source_token is None)
            or (plan.source_kind is not None and plan.source_path is not None)
            or (plan.source_kind is not None and plan.transfer_logical_path is not None)
            or (
                plan.source_kind == "file_provider_fd"
                and (
                    plan.source_token is None
                    or UUID_RE.fullmatch(plan.source_token) is None
                )
            )
            or (
                plan.delete_after_ack_mutation_id is not None
                and UUID_RE.fullmatch(plan.delete_after_ack_mutation_id) is None
            )
            or (
                (plan.delete_after_ack_mutation_id is None)
                != (plan.delete_after_ack_path is None)
                and plan.source_kind == "file_provider_fd"
            )
        )
        or (
            plan.transfer_token is not None
            and re.fullmatch(r"[a-f0-9]{32}", plan.transfer_token) is None
        )
        or (
            plan.delete_after_ack_digest is not None
            and not _digest(plan.delete_after_ack_digest)
        )
        or (
            plan.source_path is not None
            and (
                not plan.source_path
                or len(plan.source_path.encode("utf-8")) > 4_096
                or plan.source_path.startswith(("/", "\\"))
                or "\\" in plan.source_path
                or any(part in ("", ".", "..") for part in plan.source_path.split("/"))
            )
        )
        or plan.size_bytes > (
            MAX_LOCAL_UPLOAD_FILE_BYTES
            if _plan_is_source_backed(plan)
            else MAX_SYNC_FILE_BYTES
        )
    ):
        raise StateError("The durable Fabric stage plan does not match its journal row.")
    block_ceiling = MAX_CAS_BLOCK_BYTES if _plan_is_source_backed(plan) else BLOCK_BYTES
    source_block_size = (
        _source_plan_block_size(plan)
        if _plan_is_source_backed(plan) and plan.size_bytes
        else (BLOCK_BYTES if plan.size_bytes else 1)
    )
    for index, block in enumerate(blocks):
        expected_block_size = min(
            source_block_size, max(0, plan.size_bytes - expected_offset)
        )
        if (
            block.index != index
            or block.offset_bytes != expected_offset
            or block.size_bytes < 0
            or block.size_bytes > block_ceiling
            or (plan.size_bytes > 0 and block.size_bytes == 0)
            or (
                _plan_is_source_backed(plan)
                and not plan.preserved_target_extents
                and block.size_bytes != expected_block_size
            )
            or not _digest(block.sha256)
        ):
            raise StateError("The durable Fabric stage block map is invalid.")
        expected_offset += block.size_bytes
    if expected_offset != plan.size_bytes:
        raise StateError("The durable Fabric stage block map is incomplete.")
    try:
        info = stage.stat()
    except OSError as error:
        raise StateError("The durable Fabric staged bytes are missing.") from error
    expected_stage_size = 0 if _plan_is_source_backed(plan) else plan.size_bytes
    if (
        not stat.S_ISREG(info.st_mode)
        or info.st_nlink != 1
        or info.st_size != expected_stage_size
    ):
        raise StateError("The durable Fabric staged bytes changed size.")
    return plan


def _load_local_recovery_plan(candidate: LocalRecoveryCandidate) -> StagePlan:
    """Validate an unjournaled local data+plan family without trusting names."""

    try:
        encoded, _info = _read_bounded_regular_file(
            _plan_path(candidate.stage_path), MAX_MUTATION_PREIMAGE_BYTES
        )
        raw = json.loads(encoded.decode("utf-8"))
    except (OSError, UnicodeDecodeError, ValueError) as error:
        raise StateError(
            "The complete local snapshot has no valid bounded publication plan."
        ) from error
    path = raw.get("path") if isinstance(raw, Mapping) else None
    if (
        not isinstance(path, str)
        or not path
        or len(path.encode("utf-8")) > 4_096
        or path.startswith(("/", "\\"))
        or "\\" in path
        or any(part in ("", ".", "..") for part in path.split("/"))
    ):
        raise StateError("The recovered local snapshot path is invalid.")
    synthetic = PendingOperation(
        mutation_id=str(uuid.uuid4()),
        journal_seq=1,
        predecessor_mutation_id=None,
        kind="put",
        path=path,
        destination_path=None,
        base_generation=None,
        base_digest=None,
        expected_source_digest=None,
        expected_destination_digest=None,
        staged_path=str(candidate.stage_path),
        staged_digest=candidate.sha256,
        staged_size=candidate.size_bytes,
        state="quarantined",
        commit_unknown=False,
        request_digest=None,
        attempt_count=0,
        failure_count=0,
        last_error=None,
        created_at_ns=0,
        updated_at_ns=0,
        claimed_at_ns=None,
        next_attempt_at_ns=None,
    )
    plan = _load_plan(candidate.stage_path, synthetic)
    expected_source = FileFingerprint(
        size_bytes=candidate.source_fingerprint.size_bytes,
        mtime_ns=candidate.source_fingerprint.modified_ns,
        ctime_ns=candidate.source_fingerprint.changed_ns,
        device_id=candidate.source_fingerprint.device,
        file_id=candidate.source_fingerprint.inode,
    )
    if (
        plan.source_fingerprint != _fingerprint_text(expected_source)
        or plan.transfer_logical_path != candidate.logical_path
        or plan.transfer_token != candidate.token
    ):
        raise StateError(
            "The recovered local snapshot plan does not match its exact transfer identity."
        )
    return plan


def _load_progress(stage: Path, mutation_id: str) -> dict[str, Any]:
    progress_path = _progress_path(stage)
    try:
        encoded, info = _read_bounded_regular_file(
            progress_path, MAX_UPLOAD_PROGRESS_BYTES
        )
    except FileNotFoundError:
        return {
            "uploaded": set(),
            "verified": set(),
            "receipts": {},
            "reuse_target_blocks": True,
            "_journal_valid_bytes": None,
        }
    except (OSError, UnicodeError, ValueError) as error:
        raise StateError("The Fabric upload progress journal is invalid.") from error

    # Version 3 is an append-only newline-delimited JSON journal. Each block
    # receipt is written once and each verification digest once, so 8,192
    # blocks remain O(N) metadata I/O instead of rewriting a multi-megabyte
    # object after every 64-block batch.
    if b"\n" in encoded:
        try:
            return _load_progress_v3(encoded, info, mutation_id)
        except (UnicodeError, ValueError) as error:
            raise StateError("The Fabric upload progress journal is invalid.") from error
    try:
        raw = json.loads(encoded.decode("utf-8"))
    except (UnicodeError, ValueError) as error:
        raise StateError("The Fabric upload progress journal is invalid.") from error
    if not isinstance(raw, Mapping) or raw.get("mutation_id") != mutation_id:
        raise StateError("The Fabric upload progress belongs to another mutation.")
    if raw.get("version") in {1, 2}:
        # Pre-journal formats either lack upload-attempt records or require a
        # quadratic whole-object rewrite. They are readable only as a safe
        # upgrade fence: reissue missing blocks and immediately create v3.
        return {
            "uploaded": set(),
            "verified": set(),
            "receipts": {},
            "reuse_target_blocks": False,
            "_journal_valid_bytes": None,
        }
    raise StateError("The Fabric upload progress version is unsupported.")


def _ensure_progress_journal(
    stage: Path, mutation_id: str, progress: dict[str, Any]
) -> None:
    if progress.get("_journal_valid_bytes") is not None:
        return
    if progress["uploaded"] or progress["verified"] or progress["receipts"]:
        # Legacy/nonincremental callers use the general reset writer below.
        _write_progress(stage, mutation_id, progress)
        return
    header = _compact_json_line(
        {
            "version": 3,
            "mutation_id": mutation_id,
            "reuse_target_blocks": bool(progress["reuse_target_blocks"]),
        }
    )
    progress_path = _progress_path(stage)
    write_private_file(progress_path, header)
    info = progress_path.lstat()
    progress["_journal_valid_bytes"] = len(header)
    progress["_journal_device"] = int(info.st_dev)
    progress["_journal_inode"] = int(info.st_ino)
    progress["_journal_receipts"] = {}
    progress["_journal_verified"] = set()
    progress["_journal_reuse"] = bool(progress["reuse_target_blocks"])


def _append_upload_receipts(
    stage: Path,
    mutation_id: str,
    progress: dict[str, Any],
    additions: Sequence[tuple[str, Mapping[str, Any]]],
) -> None:
    """Fsync <=4 new upload-attempt records without scanning prior progress."""

    if not 1 <= len(additions) <= UPLOAD_WORKER_CONCURRENCY:
        raise StateError("A Fabric upload receipt wave exceeds its byte-lane bound.")
    receipts: dict[str, dict[str, Any]] = progress["receipts"]
    uploaded: set[str] = progress["uploaded"]
    normalized: dict[str, dict[str, Any]] = {}
    for digest, receipt in additions:
        if digest in uploaded or digest in normalized:
            raise StateError("A Fabric upload receipt was replayed after completion.")
        normalized[digest] = _durable_upload_part_receipt(
            receipt, expected_digest=digest
        )
    if len(uploaded) + len(normalized) > MAX_MANIFEST_BLOCKS:
        raise StateError("The Fabric upload progress exceeds its block bound.")
    _ensure_progress_journal(stage, mutation_id, progress)
    frame = _compact_json_line(
        {
            "add": {
                digest: _compact_upload_part_receipt(receipt)
                for digest, receipt in sorted(normalized.items())
            }
        }
    )
    valid_bytes = int(progress["_journal_valid_bytes"])
    info = _append_progress_frame(
        _progress_path(stage),
        frame,
        valid_bytes=valid_bytes,
        expected_device=int(progress["_journal_device"]),
        expected_inode=int(progress["_journal_inode"]),
    )
    # Mutate the in-memory view only after the receipt frame is durable.
    receipts.update(normalized)
    uploaded.update(normalized)
    progress["_journal_receipts"].update(normalized)
    progress["_journal_valid_bytes"] = valid_bytes + len(frame)
    progress["_journal_device"] = int(info.st_dev)
    progress["_journal_inode"] = int(info.st_ino)


def _append_verified_upload_blocks(
    stage: Path,
    mutation_id: str,
    progress: dict[str, Any],
    digests: Sequence[str],
) -> None:
    """Durably verify <=4 exact receipts while retaining replay proof."""

    if (
        not 1 <= len(digests) <= MAX_VERIFY_BLOCKS_PER_REQUEST
        or len(set(digests)) != len(digests)
    ):
        raise StateError("A Fabric verification frame exceeds its batch bound.")
    receipts: dict[str, dict[str, Any]] = progress["receipts"]
    verified: set[str] = progress["verified"]
    if any(not _digest(digest) or digest not in receipts for digest in digests):
        raise StateError("A Fabric verification has no durable upload receipt.")
    _ensure_progress_journal(stage, mutation_id, progress)
    frame = _compact_json_line({"verify": list(digests)})
    valid_bytes = int(progress["_journal_valid_bytes"])
    info = _append_progress_frame(
        _progress_path(stage),
        frame,
        valid_bytes=valid_bytes,
        expected_device=int(progress["_journal_device"]),
        expected_inode=int(progress["_journal_inode"]),
    )
    for digest in digests:
        verified.add(digest)
        progress["_journal_verified"].add(digest)
    progress["_journal_valid_bytes"] = valid_bytes + len(frame)
    progress["_journal_device"] = int(info.st_dev)
    progress["_journal_inode"] = int(info.st_ino)


def _write_progress(stage: Path, mutation_id: str, progress: Mapping[str, Any]) -> None:
    uploaded = set(progress["uploaded"])
    verified = set(progress["verified"])
    receipts = {
        str(digest): _durable_upload_part_receipt(
            receipt, expected_digest=str(digest)
        )
        for digest, receipt in dict(progress["receipts"]).items()
    }
    if (
        len(uploaded) > MAX_MANIFEST_BLOCKS
        or len(verified) > MAX_MANIFEST_BLOCKS
        or len(receipts) > MAX_MANIFEST_BLOCKS
        or any(not _digest(value) for value in uploaded | verified)
        or set(receipts) != uploaded
        or not verified.issubset(uploaded)
    ):
        raise StateError("The Fabric upload progress exceeds its bounded schema.")
    reuse = bool(progress["reuse_target_blocks"])
    valid_bytes = progress.get("_journal_valid_bytes")
    persisted_receipts = dict(progress.get("_journal_receipts", {}))
    persisted_verified = set(progress.get("_journal_verified", set()))
    persisted_reuse = progress.get("_journal_reuse")
    reset = bool(
        valid_bytes is not None
        and (
            not persisted_verified.issubset(verified)
            or any(
                digest not in receipts and digest not in verified
                for digest in persisted_receipts
            )
            or any(
                digest in receipts and receipts[digest] != receipt
                for digest, receipt in persisted_receipts.items()
            )
        )
    )
    if reset:
        persisted_receipts = {}
        persisted_verified = set()
    elif valid_bytes is None:
        persisted_receipts = {}
        persisted_verified = set()
        persisted_reuse = reuse
    additions = {
        digest: _compact_upload_part_receipt(receipts[digest])
        for digest in sorted(set(receipts) - set(persisted_receipts))
    }
    verified_additions = sorted(verified - persisted_verified)
    event: dict[str, Any] = {}
    if reset:
        event["reset"] = True
    if persisted_reuse is not reuse:
        event["reuse_target_blocks"] = reuse
    if additions and len(additions) <= 256:
        event["add"] = additions
    if verified_additions and len(verified_additions) <= 256:
        event["verify"] = verified_additions

    header = {
        "version": 3,
        "mutation_id": mutation_id,
        "reuse_target_blocks": reuse,
    }
    if valid_bytes is None:
        frames = [_compact_json_line(header)]
        if event:
            frames.append(_compact_json_line(event))
        if len(additions) > 256:
            addition_items = list(additions.items())
            for start in range(0, len(addition_items), 256):
                frames.append(
                    _compact_json_line(
                        {"add": dict(addition_items[start : start + 256])}
                    )
                )
        if len(verified_additions) > 256:
            # This can only be a caller-created synthetic initial state; live
            # Live v3 verification advances in <=4-receipt frames. Refuse to
            # manufacture proof without the corresponding receipt additions.
            raise StateError("Initial Fabric verification progress is invalid.")
        encoded = b"".join(frames)
        if len(encoded) > MAX_UPLOAD_PROGRESS_BYTES:
            raise StateError("The Fabric upload progress exceeds its byte bound.")
        progress_path = _progress_path(stage)
        write_private_file(progress_path, encoded)
        info = progress_path.lstat()
        _update_progress_journal_snapshot(
            progress,
            valid_bytes=len(encoded),
            info=info,
            receipts=receipts,
            verified=verified,
            reuse=reuse,
        )
        return
    if not event:
        return
    info = _append_progress_frame(
        _progress_path(stage),
        _compact_json_line(event),
        valid_bytes=int(valid_bytes),
        expected_device=int(progress["_journal_device"]),
        expected_inode=int(progress["_journal_inode"]),
    )
    _update_progress_journal_snapshot(
        progress,
        valid_bytes=int(valid_bytes) + len(_compact_json_line(event)),
        info=info,
        receipts=receipts,
        verified=verified,
        reuse=reuse,
    )


def _update_progress_journal_snapshot(
    progress: Mapping[str, Any],
    *,
    valid_bytes: int,
    info: os.stat_result,
    receipts: Mapping[str, Mapping[str, Any]],
    verified: set[str],
    reuse: bool,
) -> None:
    if not isinstance(progress, dict):
        return
    progress["_journal_valid_bytes"] = valid_bytes
    progress["_journal_device"] = int(info.st_dev)
    progress["_journal_inode"] = int(info.st_ino)
    progress["_journal_receipts"] = {
        digest: dict(receipt) for digest, receipt in receipts.items()
    }
    progress["_journal_verified"] = set(verified)
    progress["_journal_reuse"] = reuse


def _load_progress_v3(
    encoded: bytes,
    info: os.stat_result,
    mutation_id: str,
) -> dict[str, Any]:
    last_newline = encoded.rfind(b"\n")
    if last_newline < 0:
        raise StateError("The Fabric upload progress header is incomplete.")
    valid = encoded[: last_newline + 1]
    lines = valid.splitlines()
    if not lines:
        raise StateError("The Fabric upload progress journal is empty.")
    header = json.loads(lines[0].decode("utf-8"))
    if (
        not isinstance(header, Mapping)
        or set(header) != {"version", "mutation_id", "reuse_target_blocks"}
        or header.get("version") != 3
        or header.get("mutation_id") != mutation_id
        or not isinstance(header.get("reuse_target_blocks"), bool)
    ):
        raise StateError("The Fabric upload progress header is invalid.")
    receipts: dict[str, dict[str, Any]] = {}
    verified: set[str] = set()
    reuse = bool(header["reuse_target_blocks"])
    for raw_line in lines[1:]:
        event = json.loads(raw_line.decode("utf-8"))
        if (
            not isinstance(event, Mapping)
            or not event
            or not set(event).issubset(
                {"reset", "reuse_target_blocks", "add", "verify"}
            )
            or ("reset" in event and event["reset"] is not True)
            or (
                "reuse_target_blocks" in event
                and not isinstance(event["reuse_target_blocks"], bool)
            )
        ):
            raise StateError("The Fabric upload progress event is invalid.")
        if event.get("reset") is True:
            receipts.clear()
            verified.clear()
        if "reuse_target_blocks" in event:
            reuse = bool(event["reuse_target_blocks"])
        additions = event.get("add", {})
        verification = event.get("verify", [])
        if (
            not isinstance(additions, Mapping)
            or len(additions) > 256
            or not isinstance(verification, list)
            or len(verification) > 256
            or len(set(verification)) != len(verification)
        ):
            raise StateError("The Fabric upload progress event exceeds its batch bound.")
        for digest, compact in additions.items():
            if not _digest(digest) or digest in verified:
                raise StateError("The Fabric upload progress addition is invalid.")
            receipt = _expand_upload_part_receipt(str(digest), compact)
            previous = receipts.get(str(digest))
            if previous is not None and previous != receipt:
                raise StateError("The Fabric upload receipt identity changed.")
            receipts[str(digest)] = receipt
        for digest in verification:
            if not _digest(digest) or digest not in receipts:
                raise StateError("The Fabric upload verification has no receipt.")
            verified.add(str(digest))
        if len(receipts) > MAX_MANIFEST_BLOCKS:
            raise StateError("The Fabric upload progress exceeds its block bound.")
    uploaded = set(receipts)
    return {
        "uploaded": uploaded,
        "verified": verified,
        "receipts": receipts,
        "reuse_target_blocks": reuse,
        "_journal_valid_bytes": len(valid),
        "_journal_device": int(info.st_dev),
        "_journal_inode": int(info.st_ino),
        "_journal_receipts": dict(receipts),
        "_journal_verified": set(verified),
        "_journal_reuse": reuse,
    }


def _compact_upload_part_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "size_bytes": receipt["size_bytes"],
        "outcome": receipt["outcome"],
    }


def _expand_upload_part_receipt(
    digest: str, value: object
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != {"size_bytes", "outcome"}:
        raise StateError("The compact Fabric upload receipt is invalid.")
    return _durable_upload_part_receipt(
        {"sha256": digest, **dict(value)}, expected_digest=digest
    )


def _compact_json_line(value: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
        + "\n"
    ).encode("utf-8")


def _append_progress_frame(
    path: Path,
    frame: bytes,
    *,
    valid_bytes: int,
    expected_device: int,
    expected_inode: int,
) -> os.stat_result:
    if valid_bytes + len(frame) > MAX_UPLOAD_PROGRESS_BYTES:
        raise StateError("The Fabric upload progress exceeds its byte bound.")
    flags = os.O_RDWR | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(str(path), flags)
    try:
        info = os.fstat(descriptor)
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_nlink != 1
            or info.st_dev != expected_device
            or info.st_ino != expected_inode
            or info.st_size < valid_bytes
            or info.st_size > MAX_UPLOAD_PROGRESS_BYTES
        ):
            raise StateError("The Fabric upload progress changed before append.")
        if info.st_size != valid_bytes:
            # A process crash can leave only the final JSON frame incomplete.
            # The preceding newline is the durable commit boundary.
            os.ftruncate(descriptor, valid_bytes)
        os.lseek(descriptor, valid_bytes, os.SEEK_SET)
        _write_all(descriptor, frame)
        os.fsync(descriptor)
        return os.fstat(descriptor)
    finally:
        os.close(descriptor)


def _upload_part_receipt(
    value: object, block: StagedBlock
) -> dict[str, Any]:
    if not isinstance(value, Mapping) or value.get("schema") != UPLOAD_PART_RECEIPT_SCHEMA:
        raise NetworkError("The Fabric provider returned an invalid upload receipt.")
    try:
        return _durable_upload_part_receipt(
            {key: item for key, item in value.items() if key != "schema"},
            expected_digest=block.sha256,
            expected_size=block.size_bytes,
        )
    except StateError as error:
        raise NetworkError("The Fabric provider returned an invalid upload receipt.") from error


def _durable_upload_part_receipt(
    value: object,
    *,
    expected_digest: str,
    expected_size: int | None = None,
) -> dict[str, Any]:
    keys = {"sha256", "size_bytes", "outcome"}
    if not isinstance(value, Mapping) or set(value) != keys:
        raise StateError("The durable Fabric upload receipt has invalid fields.")
    size = value.get("size_bytes")
    outcome = value.get("outcome")
    if (
        value.get("sha256") != expected_digest
        or isinstance(size, bool)
        or not isinstance(size, int)
        or not 0 <= size <= MAX_CAS_BLOCK_BYTES
        or (expected_size is not None and size != expected_size)
        or outcome not in {"stored", "canonical_exists", "unknown"}
    ):
        raise StateError("The durable Fabric upload receipt is invalid.")
    return {
        "sha256": expected_digest,
        "size_bytes": size,
        "outcome": outcome,
    }


def _read_stage_block(stage: Path, block: StagedBlock) -> bytes:
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(str(stage), flags)
    try:
        os.lseek(descriptor, block.offset_bytes, os.SEEK_SET)
        data = _read_up_to(descriptor, block.size_bytes)
    finally:
        os.close(descriptor)
    if len(data) != block.size_bytes or hashlib.sha256(data).hexdigest() != block.sha256:
        raise StateError("The durable Fabric stage block failed verification.")
    return data


def _block_tickets(
    response: object, mutation_id: str, blocks: Sequence[StagedBlock]
) -> dict[str, Mapping[str, Any]]:
    tickets = response.get("tickets") if isinstance(response, Mapping) else None
    if (
        not isinstance(response, Mapping)
        or response.get("schema") != BLOCK_WRITE_SCHEMA
        or response.get("operation") != "write_batch"
        or response.get("mutation_id") != mutation_id
        or not isinstance(tickets, list)
    ):
        raise NetworkError("Meshia returned an invalid Fabric block ticket batch.")
    return _block_ticket_values(tickets, blocks)


def _block_ticket_batch_items(
    response: object,
    expected: Sequence[tuple[PendingOperation, Sequence[StagedBlock]]],
) -> tuple[
    dict[str, dict[str, Mapping[str, Any]]],
    dict[str, RemoteError],
]:
    """Validate the additive v1 multi-mutation write ticket response."""

    response_items = response.get("items") if isinstance(response, Mapping) else None
    requested = sum(len({block.sha256 for block in blocks}) for _op, blocks in expected)
    unique = {
        block.sha256 for _operation, blocks in expected for block in blocks
    }
    if (
        not isinstance(response, Mapping)
        or set(response)
        != {
            "schema",
            "operation",
            "item_count",
            "requested_block_count",
            "unique_block_count",
            "recommended_block_bytes",
            "items",
        }
        or response.get("schema") != BLOCK_WRITE_SCHEMA
        or response.get("operation") != "write_batch"
        or response.get("item_count") != len(expected)
        or response.get("requested_block_count") != requested
        or response.get("unique_block_count") != len(unique)
        or not isinstance(response.get("recommended_block_bytes"), int)
        or not isinstance(response_items, list)
        or len(response_items) != len(expected)
    ):
        raise NetworkError("Meshia returned an invalid multi-mutation Fabric ticket batch.")
    issued: dict[str, dict[str, Mapping[str, Any]]] = {}
    rejected: dict[str, RemoteError] = {}
    for index, ((operation, blocks), item) in enumerate(zip(expected, response_items)):
        if (
            not isinstance(item, Mapping)
            or item.get("index") != index
            or item.get("mutation_id") != operation.mutation_id
        ):
            raise NetworkError("Meshia returned a misbound Fabric ticket batch item.")
        if item.get("status") == "issued":
            if set(item) != {"index", "mutation_id", "status", "tickets"}:
                raise NetworkError("Meshia returned an ambiguous Fabric ticket batch item.")
            tickets = item.get("tickets")
            if not isinstance(tickets, list):
                raise NetworkError("Meshia returned an invalid Fabric ticket batch item.")
            issued[operation.mutation_id] = _block_ticket_values(tickets, blocks)
            continue
        if item.get("status") != "rejected" or set(item) != {
            "index",
            "mutation_id",
            "status",
            "error",
        }:
            raise NetworkError("Meshia returned an invalid Fabric ticket batch outcome.")
        error = item.get("error")
        status = error.get("status") if isinstance(error, Mapping) else None
        code = error.get("code") if isinstance(error, Mapping) else None
        message = error.get("message") if isinstance(error, Mapping) else None
        if (
            not isinstance(error, Mapping)
            or set(error) != {"code", "message", "status"}
            or isinstance(status, bool)
            or not isinstance(status, int)
            or not 400 <= status <= 599
            or not isinstance(code, str)
            or not code
            or not isinstance(message, str)
            or not message
        ):
            raise NetworkError("Meshia returned an invalid Fabric ticket rejection.")
        rejected[operation.mutation_id] = RemoteError(status, code, message)
    return issued, rejected


def _block_ticket_values(
    tickets: Sequence[object], blocks: Sequence[StagedBlock]
) -> dict[str, Mapping[str, Any]]:
    """Bind exact six-field PUT capabilities to one mutation's descriptors."""

    unique = {block.sha256: block for block in blocks}
    if len(tickets) != len(unique):
        raise NetworkError("Meshia returned an invalid Fabric block ticket batch.")
    result: dict[str, Mapping[str, Any]] = {}
    for ticket in tickets:
        digest = ticket.get("sha256") if isinstance(ticket, Mapping) else None
        block = unique.get(str(digest))
        if (
            not isinstance(ticket, Mapping)
            or block is None
            or digest in result
            or set(ticket)
            != {"sha256", "size_bytes", "method", "url", "headers", "expires_at"}
            or ticket.get("size_bytes") != block.size_bytes
            or ticket.get("method") != "PUT"
            or not isinstance(ticket.get("url"), str)
            or not isinstance(ticket.get("headers"), Mapping)
        ):
            raise NetworkError("Meshia returned an invalid Fabric block ticket.")
        result[str(digest)] = ticket
    return result


def _write_ticket_expiry(ticket: Mapping[str, Any]) -> float:
    value = ticket.get("expires_at")
    if not isinstance(value, str):
        raise NetworkError("Meshia returned a Fabric upload ticket without expiry.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError
        expiry = parsed.timestamp()
    except (OverflowError, ValueError):
        raise NetworkError("Meshia returned an invalid Fabric upload ticket expiry.") from None
    if not 0 < expiry < 253_402_300_800:
        raise NetworkError("Meshia returned an invalid Fabric upload ticket expiry.")
    return expiry


def _direct_read_ticket_expiry(ticket: Mapping[str, Any]) -> float:
    value = ticket.get("expires_at")
    if not isinstance(value, str):
        raise NetworkError("Meshia returned a Fabric block read ticket without expiry.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError
        expiry = parsed.timestamp()
    except (OverflowError, ValueError):
        raise NetworkError("Meshia returned an invalid Fabric block read ticket expiry.") from None
    if not 0 < expiry < 253_402_300_800:
        raise NetworkError("Meshia returned an invalid Fabric block read ticket expiry.")
    return expiry


def _cas_storage_kind(entry: RemoteEntry) -> str | None:
    """The readable CAS storage kind of a remote entry, if it names one."""

    value = entry.blocks
    storage = value.get("storage") if isinstance(value, Mapping) else None
    kind = storage.get("kind") if isinstance(storage, Mapping) else None
    return kind if isinstance(kind, str) and kind in READABLE_OBJECT_CAS_KINDS else None


def _cas_read_blocks(entry: RemoteEntry) -> tuple[StagedBlock, ...] | None:
    """Parse the sanitized explicit CAS block map, rejecting ambiguous shapes."""

    value = entry.blocks
    if not isinstance(value, Mapping):
        return None
    try:
        if file_digest_algorithm(value) == FABRIC_BLOCK_FILE_DIGEST_ALGORITHM and block_file_sha256(value) != entry.digest:
            return None
    except ValueError:
        return None
    raw_blocks = value.get("blocks")
    block_count = value.get("block_count")
    total_bytes = value.get("total_bytes")
    storage = value.get("storage")
    block_size = value.get("block_size_bytes")
    chunking = value.get("chunking")
    if (
        value.get("version") != 1
        or value.get("algorithm") != "sha256"
        or not isinstance(storage, Mapping)
        or storage.get("kind") not in READABLE_OBJECT_CAS_KINDS
        or isinstance(block_size, bool)
        or not isinstance(block_size, int)
        or not 1 <= block_size <= MAX_CAS_BLOCK_BYTES
        or not _valid_chunking_summary(chunking, block_size)
        or not isinstance(raw_blocks, list)
        or isinstance(block_count, bool)
        or not isinstance(block_count, int)
        or block_count != len(raw_blocks)
        or not 1 <= block_count <= MAX_MANIFEST_BLOCKS
        or total_bytes != entry.size_bytes
    ):
        return None
    content_defined_block_ceiling = (
        block_size if chunking is None else int(chunking["max_bytes"])
    )
    blocks: list[StagedBlock] = []
    sizes_by_digest: dict[str, int] = {}
    expected_offset = 0
    for index, raw in enumerate(raw_blocks):
        if not isinstance(raw, Mapping):
            return None
        offset = raw.get("offset_bytes")
        size = raw.get("size_bytes")
        digest = raw.get("sha256")
        if (
            raw.get("index") != index
            or offset != expected_offset
            or isinstance(size, bool)
            or not isinstance(size, int)
            or size < 0
            or size > block_size
            or size > content_defined_block_ceiling
            or (entry.size_bytes > 0 and size == 0)
            or not _digest(digest)
        ):
            return None
        previous_size = sizes_by_digest.get(str(digest))
        if previous_size is not None and previous_size != size:
            return None
        sizes_by_digest[str(digest)] = size
        blocks.append(StagedBlock(index, int(offset), size, str(digest)))
        expected_offset += size
    if expected_offset != entry.size_bytes:
        return None
    if entry.size_bytes == 0 and (
        block_size != 1
        or block_count != 1
        or chunking is not None
        or blocks[0].size_bytes != 0
        or blocks[0].sha256 != FABRIC_EMPTY_SHA256
    ):
        return None
    return tuple(blocks)


def _fixed_transfer_blocks(entry: RemoteEntry) -> tuple[BlockSpec, ...] | None:
    """Return the strict fixed-4-MiB layout accepted by TransferStore."""

    value = entry.blocks
    if not isinstance(value, Mapping):
        return None
    raw_blocks = value.get("blocks")
    count = value.get("block_count")
    if (
        value.get("version") != 1
        or value.get("algorithm") != "sha256"
        or value.get("block_size_bytes") != BLOCK_BYTES
        or value.get("total_bytes") != entry.size_bytes
        or value.get("blocks_complete", True) is not True
        or not isinstance(value.get("storage"), Mapping)
        or value["storage"].get("kind") not in READABLE_OBJECT_CAS_KINDS
        or isinstance(count, bool)
        or not isinstance(count, int)
        or count != (entry.size_bytes + BLOCK_BYTES - 1) // BLOCK_BYTES
        or not 0 <= count <= MAX_MANIFEST_BLOCKS
        or not isinstance(raw_blocks, list)
        or len(raw_blocks) != count
    ):
        return None
    result: list[BlockSpec] = []
    for index, raw in enumerate(raw_blocks):
        expected_size = min(BLOCK_BYTES, entry.size_bytes - index * BLOCK_BYTES)
        if (
            not isinstance(raw, Mapping)
            or raw.get("index") != index
            or raw.get("offset_bytes") != index * BLOCK_BYTES
            or raw.get("size_bytes") != expected_size
            or not _digest(raw.get("sha256"))
        ):
            return None
        result.append(
            BlockSpec(index, index * BLOCK_BYTES, expected_size, str(raw["sha256"]))
        )
    return tuple(result)


def _deferred_transfer_block_summary(entry: RemoteEntry) -> Mapping[str, Any] | None:
    """Validate a deferred object-CAS layout without allocating descriptors."""

    value = entry.blocks
    if not isinstance(value, Mapping) or value.get("blocks_complete") is not False:
        return None
    storage = value.get("storage")
    count = value.get("block_count")
    raw_blocks = value.get("blocks")
    block_size = value.get("block_size_bytes")
    chunking = value.get("chunking")
    if (
        value.get("version") != 1
        or value.get("algorithm") != "sha256"
        or value.get("total_bytes") != entry.size_bytes
        or not isinstance(storage, Mapping)
        or storage.get("kind") not in READABLE_OBJECT_CAS_KINDS
        or isinstance(block_size, bool)
        or not isinstance(block_size, int)
        or not 1 <= block_size <= 64 * 1024 * 1024
        or isinstance(count, bool)
        or not isinstance(count, int)
        or not 1 <= count <= MAX_REMOTE_MANIFEST_BLOCKS
        or raw_blocks != []
        or not _valid_chunking_summary(chunking, block_size)
    ):
        raise NetworkError("Meshia returned an invalid deferred Fabric block layout.")
    return value


def _requires_remote_only_materialization(
    entry: RemoteEntry, *, materialization_ceiling: int = MAX_SYNC_FILE_BYTES
) -> bool:
    """Recognize valid metadata wider than the bounded edge staging format."""

    if (
        isinstance(materialization_ceiling, bool)
        or not isinstance(materialization_ceiling, int)
        or materialization_ceiling < 0
    ):
        raise ValueError("materialization_ceiling must be a non-negative integer")
    if entry.size_bytes > min(MAX_SYNC_FILE_BYTES, materialization_ceiling):
        return True
    value = entry.blocks
    if not isinstance(value, Mapping):
        return False
    count = value.get("block_count")
    if (
        isinstance(count, bool)
        or not isinstance(count, int)
        or count <= MAX_MANIFEST_BLOCKS
        or count > MAX_REMOTE_MANIFEST_BLOCKS
    ):
        return False
    # Deferred summaries are the production representation for large indexes;
    # reuse its strict constant-space validator before deciding not to page it.
    return _deferred_transfer_block_summary(entry) is not None


def _valid_chunking_summary(value: object, block_size: int) -> bool:
    if value is None:
        return True
    if not isinstance(value, Mapping) or value.get("kind") != "content_defined_v1":
        return False
    minimum = value.get("min_bytes")
    average = value.get("avg_bytes")
    maximum = value.get("max_bytes")
    return bool(
        not isinstance(minimum, bool)
        and isinstance(minimum, int)
        and not isinstance(average, bool)
        and isinstance(average, int)
        and not isinstance(maximum, bool)
        and isinstance(maximum, int)
        and 0 < minimum <= average <= maximum <= block_size
    )


def _complete_object_cas_layout(entry: RemoteEntry) -> bool:
    value = entry.blocks
    if not isinstance(value, Mapping):
        return False
    try:
        if file_digest_algorithm(value) == FABRIC_BLOCK_FILE_DIGEST_ALGORITHM and block_file_sha256(value) != entry.digest:
            return False
    except ValueError:
        return False
    raw = value.get("blocks")
    count = value.get("block_count")
    block_size = value.get("block_size_bytes")
    storage = value.get("storage")
    if (
        value.get("version") != 1
        or value.get("algorithm") != "sha256"
        or value.get("blocks_complete", True) is not True
        or value.get("total_bytes") != entry.size_bytes
        or not isinstance(storage, Mapping)
        or storage.get("kind") not in READABLE_OBJECT_CAS_KINDS
        or isinstance(block_size, bool)
        or not isinstance(block_size, int)
        or not 1 <= block_size <= 64 * 1024 * 1024
        or isinstance(count, bool)
        or not isinstance(count, int)
        or not 1 <= count <= MAX_REMOTE_MANIFEST_BLOCKS
        or not isinstance(raw, list)
        or len(raw) != count
        or not _valid_chunking_summary(value.get("chunking"), block_size)
    ):
        return False
    chunking = value.get("chunking")
    content_defined_block_ceiling = (
        block_size if chunking is None else int(chunking["max_bytes"])
    )
    expected_offset = 0
    for index, block in enumerate(raw):
        size = block.get("size_bytes") if isinstance(block, Mapping) else None
        if (
            not isinstance(block, Mapping)
            or block.get("index") != index
            or block.get("offset_bytes") != expected_offset
            or isinstance(size, bool)
            or not isinstance(size, int)
            or size < 0
            or size > block_size
            or size > content_defined_block_ceiling
            or (entry.size_bytes > 0 and size == 0)
            or not _digest(block.get("sha256"))
        ):
            return False
        expected_offset += size
    if expected_offset != entry.size_bytes:
        return False
    if entry.size_bytes == 0:
        only_block = raw[0]
        return bool(
            block_size == 1
            and count == 1
            and chunking is None
            and isinstance(only_block, Mapping)
            and only_block.get("size_bytes") == 0
            and only_block.get("sha256") == FABRIC_EMPTY_SHA256
        )
    return True


def _manifest_block_page(
    response: object,
    *,
    state: _ManifestBlockPageState,
    block_offset: int,
    block_limit: int,
    expected_byte_offset: int | None = None,
) -> tuple[tuple[StagedBlock, ...], int, bool]:
    """Validate one exact identity-bound block-index continuation page."""

    raw_blocks = response.get("blocks") if isinstance(response, Mapping) else None
    summary = state.summary
    block_count = int(summary["block_count"])
    if (
        not isinstance(response, Mapping)
        or response.get("schema") != MANIFEST_BLOCKS_SCHEMA
        or response.get("workspace") != WORKSPACE_MOUNT
        or response.get("operation") != "manifest_blocks"
        or response.get("path") != state.path
        or response.get("file_size_bytes") != state.file_size_bytes
        or response.get("file_sha256") != state.file_digest
        or response.get("file_digest_algorithm", "sha256") != summary.get("file_digest_algorithm", "sha256")
        or response.get("manifest_generation") != state.generation
        or response.get("manifest_digest") != state.manifest_digest
        or response.get("block_size_bytes") != summary.get("block_size_bytes")
        or response.get("block_count") != block_count
        or response.get("total_bytes") != state.file_size_bytes
        or response.get("storage") != summary.get("storage")
        or response.get("chunking") != summary.get("chunking")
        or response.get("block_offset") != block_offset
        or response.get("block_limit") != block_limit
        or not isinstance(raw_blocks, list)
        or len(raw_blocks) > block_limit
    ):
        raise NetworkError("Meshia returned an invalid Fabric block-index page.")
    parsed: list[StagedBlock] = []
    expected_offset = (
        expected_byte_offset
        if expected_byte_offset is not None
        else (
            state.blocks[-1].offset_bytes + state.blocks[-1].size_bytes
            if state.blocks
            else 0
        )
    )
    block_size = int(summary["block_size_bytes"])
    for position, raw in enumerate(raw_blocks):
        index = block_offset + position
        size = raw.get("size_bytes") if isinstance(raw, Mapping) else None
        if (
            index >= block_count
            or not isinstance(raw, Mapping)
            or raw.get("index") != index
            or raw.get("offset_bytes") != expected_offset
            or isinstance(size, bool)
            or not isinstance(size, int)
            or size < 0
            or size > block_size
            or (state.file_size_bytes > 0 and size == 0)
            or expected_offset + size > state.file_size_bytes
            or not _digest(raw.get("sha256"))
        ):
            raise NetworkError("Meshia returned a non-contiguous Fabric block index.")
        parsed.append(
            StagedBlock(index, expected_offset, size, str(raw["sha256"]))
        )
        expected_offset += size
    next_offset = block_offset + len(parsed)
    truncated = next_offset < block_count
    if (
        response.get("next_block_offset") != next_offset
        or response.get("truncated") is not truncated
        or next_offset > block_count
        or (truncated and not parsed)
        or (not truncated and expected_offset != state.file_size_bytes)
    ):
        raise NetworkError("Meshia returned inconsistent Fabric block pagination.")
    return tuple(parsed), next_offset, truncated


def _block_read_tickets(
    response: object, blocks: Sequence[StagedBlock]
) -> dict[str, Mapping[str, Any]]:
    tickets = response.get("tickets") if isinstance(response, Mapping) else None
    unique = {block.sha256: block for block in blocks}
    if (
        not isinstance(response, Mapping)
        or response.get("schema") != BLOCK_READ_SCHEMA
        # M1769: the v2 lane proves membership against the entry tree instead
        # of a manifest and answers with its own operation name. Both are
        # accepted here; nothing else about the ticket contract changes.
        or response.get("operation") not in ("read_batch", "read_batch_v2")
        or not isinstance(tickets, list)
        or len(tickets) != len(unique)
    ):
        raise NetworkError("Meshia returned an invalid Fabric block read batch.")
    result: dict[str, Mapping[str, Any]] = {}
    for ticket in tickets:
        if not isinstance(ticket, Mapping):
            raise NetworkError("Meshia returned an invalid Fabric block read ticket.")
        digest = ticket.get("sha256")
        expected = unique.get(str(digest))
        if (
            expected is None
            or digest in result
            or ticket.get("size_bytes") != expected.size_bytes
            or not isinstance(ticket.get("url"), str)
            or not isinstance(ticket.get("headers"), Mapping)
        ):
            raise NetworkError("Meshia returned a mismatched Fabric block read ticket.")
        _direct_read_ticket_expiry(ticket)
        result[str(digest)] = ticket
    return result


def _overlapping_cas_blocks(
    blocks: Sequence[StagedBlock],
    requested_start: int,
    requested_end: int,
    *,
    require_coverage: bool = True,
) -> tuple[StagedBlock, ...]:
    selected = tuple(
        block
        for block in blocks
        if block.offset_bytes < requested_end
        and block.offset_bytes + block.size_bytes > requested_start
    )
    if require_coverage and (
        not selected
        or selected[0].offset_bytes > requested_start
        or selected[-1].offset_bytes + selected[-1].size_bytes < requested_end
        or any(
            left.offset_bytes + left.size_bytes != right.offset_bytes
            for left, right in zip(selected, selected[1:])
        )
    ):
        raise NetworkError("The Fabric block map does not cover the requested range.")
    return selected


def _verified_blocks(response: object, blocks: Sequence[StagedBlock]) -> None:
    raw = response.get("blocks") if isinstance(response, Mapping) else None
    expected = {block.sha256: block.size_bytes for block in blocks}
    actual = (
        {str(item.get("sha256")): item.get("size_bytes") for item in raw}
        if isinstance(raw, list) and all(isinstance(item, Mapping) for item in raw)
        else None
    )
    if (
        not isinstance(response, Mapping)
        or response.get("schema") != BLOCK_VERIFY_SCHEMA
        or response.get("verified_block_count") != len(expected)
        or actual != expected
    ):
        raise NetworkError("Meshia could not verify the uploaded Fabric blocks.")
