"""Meshia projects, agents, MCP and native workspace files in one installable."""

from __future__ import annotations

__version__ = "1.3.25"
__all__ = ["__version__"]
